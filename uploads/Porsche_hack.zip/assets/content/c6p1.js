(function (lib, img, cjs, ss) {

var p; // shortcut to reference prototypes
lib.webFontTxtFilters = {}; 

// library properties:
lib.properties = {
	width: 1218,
	height: 703,
	fps: 25,
	color: "#FFFFFF",
	opacity: 1.00,
	webfonts: {},
	manifest: [
		{src:"assets/content/images/c6p1_pic01.jpg", id:"c6p1_pic01"},
		{src:"assets/content/images/c6p1_pic02.jpg", id:"c6p1_pic02"},
		{src:"assets/content/images/c6p1_pic03.jpg", id:"c6p1_pic03"},
		{src:"assets/content/images/c6p1_pic04.png", id:"c6p1_pic04"},
		{src:"assets/content/images/c6p1_pic05.jpg", id:"c6p1_pic05"},
		{src:"assets/content/images/c6p1_pic06.png", id:"c6p1_pic06"},
		{src:"assets/content/images/c6p1_pic07.png", id:"c6p1_pic07"},
		{src:"assets/content/images/c6p1_pic32.jpg", id:"c6p1_pic32"},
		{src:"assets/content/images/cycle0001.png", id:"cycle0001"},
		{src:"assets/content/images/cycle0002.png", id:"cycle0002"},
		{src:"assets/content/images/cycle0003.png", id:"cycle0003"},
		{src:"assets/content/images/cycle0004.png", id:"cycle0004"},
		{src:"assets/content/images/cycle0005.png", id:"cycle0005"},
		{src:"assets/content/images/cycle0006.png", id:"cycle0006"},
		{src:"assets/content/images/cycle0007.png", id:"cycle0007"},
		{src:"assets/content/images/cycle0008.png", id:"cycle0008"},
		{src:"assets/content/images/cycle0009.png", id:"cycle0009"},
		{src:"assets/content/images/cycle0010.png", id:"cycle0010"},
		{src:"assets/content/images/cycle0011.png", id:"cycle0011"},
		{src:"assets/content/images/cycle0012.png", id:"cycle0012"},
		{src:"assets/content/images/cycle0013.png", id:"cycle0013"},
		{src:"assets/content/images/cycle0014.png", id:"cycle0014"},
		{src:"assets/content/images/cycle0015.png", id:"cycle0015"},
		{src:"assets/content/images/cycle0016.png", id:"cycle0016"},
		{src:"assets/content/images/cycle0017.png", id:"cycle0017"},
		{src:"assets/content/images/cycle0018.png", id:"cycle0018"},
		{src:"assets/content/images/cycle0019.png", id:"cycle0019"},
		{src:"assets/content/images/cycle0020.png", id:"cycle0020"},
		{src:"assets/content/images/cycle0021.png", id:"cycle0021"},
		{src:"assets/content/images/cycle0022.png", id:"cycle0022"},
		{src:"assets/content/images/cycle0023.png", id:"cycle0023"},
		{src:"assets/content/images/cycle0024.png", id:"cycle0024"}
	]
};



lib.ssMetadata = [];


lib.webfontAvailable = function(family) { 
	lib.properties.webfonts[family] = true;
	var txtFilters = lib.webFontTxtFilters && lib.webFontTxtFilters[family] || [];
	for(var f = 0; f < txtFilters.length; ++f) {
		txtFilters[f].updateCache();
	}
};
// symbols:



(lib.c6p1_pic01 = function() {
	this.initialize(img.c6p1_pic01);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1218,703);


(lib.c6p1_pic02 = function() {
	this.initialize(img.c6p1_pic02);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,730,450);


(lib.c6p1_pic03 = function() {
	this.initialize(img.c6p1_pic03);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1218,703);


(lib.c6p1_pic04 = function() {
	this.initialize(img.c6p1_pic04);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,200,72);


(lib.c6p1_pic05 = function() {
	this.initialize(img.c6p1_pic05);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1218,482);


(lib.c6p1_pic06 = function() {
	this.initialize(img.c6p1_pic06);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,603,275);


(lib.c6p1_pic07 = function() {
	this.initialize(img.c6p1_pic07);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,603,278);


(lib.c6p1_pic32 = function() {
	this.initialize(img.c6p1_pic32);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,123,123);


(lib.cycle0001 = function() {
	this.initialize(img.cycle0001);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,124,124);


(lib.cycle0002 = function() {
	this.initialize(img.cycle0002);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,124,124);


(lib.cycle0003 = function() {
	this.initialize(img.cycle0003);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,124,124);


(lib.cycle0004 = function() {
	this.initialize(img.cycle0004);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,124,124);


(lib.cycle0005 = function() {
	this.initialize(img.cycle0005);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,124,124);


(lib.cycle0006 = function() {
	this.initialize(img.cycle0006);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,124,124);


(lib.cycle0007 = function() {
	this.initialize(img.cycle0007);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,124,124);


(lib.cycle0008 = function() {
	this.initialize(img.cycle0008);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,124,124);


(lib.cycle0009 = function() {
	this.initialize(img.cycle0009);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,124,124);


(lib.cycle0010 = function() {
	this.initialize(img.cycle0010);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,124,124);


(lib.cycle0011 = function() {
	this.initialize(img.cycle0011);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,124,124);


(lib.cycle0012 = function() {
	this.initialize(img.cycle0012);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,124,124);


(lib.cycle0013 = function() {
	this.initialize(img.cycle0013);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,124,124);


(lib.cycle0014 = function() {
	this.initialize(img.cycle0014);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,124,124);


(lib.cycle0015 = function() {
	this.initialize(img.cycle0015);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,124,124);


(lib.cycle0016 = function() {
	this.initialize(img.cycle0016);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,124,124);


(lib.cycle0017 = function() {
	this.initialize(img.cycle0017);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,124,124);


(lib.cycle0018 = function() {
	this.initialize(img.cycle0018);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,124,124);


(lib.cycle0019 = function() {
	this.initialize(img.cycle0019);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,124,124);


(lib.cycle0020 = function() {
	this.initialize(img.cycle0020);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,124,124);


(lib.cycle0021 = function() {
	this.initialize(img.cycle0021);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,124,124);


(lib.cycle0022 = function() {
	this.initialize(img.cycle0022);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,124,124);


(lib.cycle0023 = function() {
	this.initialize(img.cycle0023);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,124,124);


(lib.cycle0024 = function() {
	this.initialize(img.cycle0024);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,124,124);


(lib.scroller_handle = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D5001C").s().p("AgsCVIAAkqIBZAAIAAEqg");
	this.shape.setTransform(4.5,15);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,9,30);


(lib.scroller_back_500 = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CCCCCC").s().p("EgAYAnEMAAAhOHIAxAAMAAABOHg");
	this.shape.setTransform(2.5,250);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,5,500);


(lib.pics_button_play = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhpicIDTCcIjTCdg");
	this.shape.setTransform(34.7,32.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#D5001C").s().p("AhpicIDTCcIjTCdg");
	this.shape_1.setTransform(34.7,32.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[]},1).to({state:[{t:this.shape_1}]},1).to({state:[]},1).wait(1));

	// Ebene 2
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#FFFFFF").ss(2,1,1).p("AFFAAQAACHhgBeQheBgiHAAQiGAAhfhgQhfheAAiHQAAiGBfhfQBfhfCGAAQCHAABeBfQBgBfAACGg");
	this.shape_2.setTransform(32.5,32.5);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("rgba(255,255,255,0)").s().p("AjkDlQhfhfgBiGQABiFBfhfQBfhfCFgBQCGABBfBfQBfBfAACFQAACGhfBfQhfBfiGAAQiFAAhfhfg");
	this.shape_3.setTransform(32.5,32.5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#D5001C").ss(2,1,1).p("AFFAAQAACHhgBeQheBgiHAAQiGAAhfhgQhfheAAiHQAAiGBfhfQBfhfCGAAQCHAABeBfQBgBfAACGg");
	this.shape_4.setTransform(32.5,32.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2}]}).to({state:[]},1).to({state:[{t:this.shape_3},{t:this.shape_4}]},1).to({state:[]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-1,67,67);


(lib.pic_shadow_occlusionRound = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#000000","rgba(0,0,0,0)"],[0,1],0,0,0,0,0,102.5).s().p("AsTMUQlGlHgBnNQABnMFGlHQFHlGHMgBQHNABFHFGQFGFHABHMQgBHNlGFHQlHFGnNABQnMgBlHlGg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-111.5,-111.5,223,223);


(lib.pic_plane_white = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EhadApaMAAAhSzMC07AAAMAAABSzg");
	this.shape.setTransform(579,265);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,1158,530);


(lib.pic_lightGlowing = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D5001C").s().p("AAZg+QBIgbAVgDQAUgDAAABQAAACgQAMQgQALgLAEQgKADgsAXQgqAWgoAcQgpAegkAiIgTATIgBABQBfiDBEgag");
	this.shape.setTransform(14,0);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0.1,-9.6,27.8,19.1);


(lib.container_text = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// Ebene 71
	this.text_41 = new cjs.Text("Der Spurhalteassistent ist im Geschwindigkeitsbereich von 65–250 km/h aktiv. Bei Annährung an die Spurmarkierung erhält der Fahrer eine Lenkunterstützung durch das System, um der erfassten Spur weiterhin zu folgen. Der Lenkeingriff ist jederzeit durch den Fahrer übersteuerbar.\n\nNötiger Sensor für den Spurhalteassistent ist: \n• Frontkamera", "16px 'Porsche Next TT'");
	this.text_41.name = "text_41";
	this.text_41.lineHeight = 23;
	this.text_41.lineWidth = 336;
	this.text_41.setTransform(2,2);
	this.text_41._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_41).wait(40).to({_off:false},0).to({_off:true},1).wait(100));

	// Ebene 70
	this.text_40 = new cjs.Text("Spurhalteassistent", "32px 'Porsche Next TT Thin'");
	this.text_40.name = "text_40";
	this.text_40.lineHeight = 47;
	this.text_40.lineWidth = 996;
	this.text_40.setTransform(2,2);
	this.text_40._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_40).wait(39).to({_off:false},0).to({_off:true},1).wait(101));

	// Ebene 25
	this.text_31 = new cjs.Text("Der Stauassistent ist bis zu 60 km/h funktionsfähig. Er hilft dem Fahrer, auf gut ausgebauten Landstraßen oder Autobahnen eine vom System berechnete Fahrspur zu halten. Dabei orientiert er sich an Fahrbahnmarkierungen und anderen Fahrzeugen auf der Fahrbahn.\n\nBei eingeschaltetem Abstandsregeltempostat (ACC) steuert der Stauassistent selbstständig die Lenkung durch sanfte Lenkeingriffe. Der Fahrer kann den Lenkeingriff jederzeit übersteuern.\n\nNötige Sensoren für den Stauassistenten sind:\n• Ultraschallsensoren\n• Frontradar \n• Frontkamera ", "16px 'Porsche Next TT'");
	this.text_31.name = "text_31";
	this.text_31.lineHeight = 23;
	this.text_31.lineWidth = 336;
	this.text_31.setTransform(2,2);
	this.text_31._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_31).wait(30).to({_off:false},0).to({_off:true},1).wait(110));

	// Ebene 82
	this.text_30 = new cjs.Text("Stauassistent", "32px 'Porsche Next TT Thin'");
	this.text_30.name = "text_30";
	this.text_30.lineHeight = 47;
	this.text_30.lineWidth = 996;
	this.text_30.setTransform(2,2);
	this.text_30._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_30).wait(29).to({_off:false},0).to({_off:true},1).wait(111));

	// Ebene 78
	this.text_27 = new cjs.Text("Notbremsung", "16px 'Porsche Next TT'");
	this.text_27.name = "text_27";
	this.text_27.lineHeight = 23;
	this.text_27.lineWidth = 226;
	this.text_27.setTransform(2,2);
	this.text_27._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_27).wait(26).to({_off:false},0).to({_off:true},1).wait(114));

	// Ebene 63
	this.text_26 = new cjs.Text("Zielbremsung", "16px 'Porsche Next TT'");
	this.text_26.name = "text_26";
	this.text_26.lineHeight = 23;
	this.text_26.lineWidth = 226;
	this.text_26.setTransform(2,2);
	this.text_26._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_26).wait(25).to({_off:false},0).to({_off:true},1).wait(115));

	// Ebene 66
	this.text_25 = new cjs.Text("Warnung", "16px 'Porsche Next TT'");
	this.text_25.name = "text_25";
	this.text_25.lineHeight = 23;
	this.text_25.lineWidth = 226;
	this.text_25.setTransform(2,2);
	this.text_25._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_25).wait(24).to({_off:false},0).to({_off:true},1).wait(116));

	// Ebene 67
	this.text_24 = new cjs.Text("Prefill", "16px 'Porsche Next TT'");
	this.text_24.name = "text_24";
	this.text_24.lineHeight = 23;
	this.text_24.lineWidth = 226;
	this.text_24.setTransform(2,2);
	this.text_24._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_24).wait(23).to({_off:false},0).to({_off:true},1).wait(117));

	// Ebene 65
	this.text_23 = new cjs.Text("480 Nm", "16px 'Porsche Next TT'");
	this.text_23.name = "text_23";
	this.text_23.lineHeight = 23;
	this.text_23.lineWidth = 296;
	this.text_23.setTransform(2,2);
	this.text_23._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_23).wait(22).to({_off:false},0).to({_off:true},1).wait(118));

	// Ebene 64
	this.text_22 = new cjs.Text("Der Fahrer wird unterstützt durch:\n\n• Fahrzeugkonditionierung: zur Verkürzung des Bremswegs werden mittels Prefill-Funktion die Bremsbacken an die Bremsscheiben angelegt.\n• optische Warnung im Kombiinstrument\n• akustisches Signal (Warnton)\n• haptische Warnung (Bremsruck)\n• Bei Bedarf Verstärkung der fahrerinitiierten Bremsung (autonome Notbremsung)\n\nNötige Sensoren für die Anhaltewegverkürzung sind:\n• Frontkamera \n• Radarsensor", "16px 'Porsche Next TT'");
	this.text_22.name = "text_22";
	this.text_22.lineHeight = 23;
	this.text_22.lineWidth = 336;
	this.text_22.setTransform(2,2);
	this.text_22._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_22).wait(21).to({_off:false},0).to({_off:true},1).wait(119));

	// Ebene 20
	this.text_21 = new cjs.Text("Die Anhaltewegverkürzung (AWV) erfasst permanent das Umfeld vor dem Fahrzeug. Bei erkannter Kollisionsgefahr wird situationsabhängig eine mehrstufige Funktionskette (Fahrzeug-Konditionierung, Warnfunktionen, Bremsfunktionen) aktiviert, wodurch die Folgen einer Kollision gemindert werden.", "16px 'Porsche Next TT'");
	this.text_21.name = "text_21";
	this.text_21.lineHeight = 23;
	this.text_21.lineWidth = 726;
	this.text_21.setTransform(2,2);
	this.text_21._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_21).wait(20).to({_off:false},0).to({_off:true},1).wait(120));

	// Ebene 8
	this.text_140 = new cjs.Text("Klicken Sie oben rechts auf \"Themenübersicht\", um ein anderes Thema zu auszuwählen.", "16px 'Porsche Next TT'", "#FFFFFF");
	this.text_140.name = "text_140";
	this.text_140.lineHeight = 23;
	this.text_140.lineWidth = 306;
	this.text_140.setTransform(2,2);
	this.text_140._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_140).wait(139).to({_off:false},0).to({_off:true},1).wait(1));

	// Ebene 19
	this.text_20 = new cjs.Text("Anhaltewegverkürzung", "32px 'Porsche Next TT Thin'");
	this.text_20.name = "text_20";
	this.text_20.lineHeight = 47;
	this.text_20.lineWidth = 996;
	this.text_20.setTransform(2,2);
	this.text_20._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_20).wait(19).to({_off:false},0).to({_off:true},1).wait(121));

	// Ebene 13
	this.text_12 = new cjs.Text("Der Fahrer wird unterstützt durch:\n\n• Fahrzeugkonditionierung: zur Verkürzung des Bremswegs werden mittels Prefill-Funktion die Bremsbacken an die Bremsscheiben angelegt.\n• optische Warnung im Kombiinstrument\n• akustisches Signal (Warnton)\n• haptische Warnung (Bremsruck)\n\nNötige Sensoren für die Fußgängerwarnung sind:\n• Frontkamera \n• Radarsensor", "16px 'Porsche Next TT'");
	this.text_12.name = "text_12";
	this.text_12.lineHeight = 23;
	this.text_12.lineWidth = 336;
	this.text_12.setTransform(2,2);
	this.text_12._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_12).wait(11).to({_off:false},0).to({_off:true},1).wait(129));

	// Ebene 12
	this.text_11 = new cjs.Text("Die Fußgängerwarnung ist im Fahrgeschwindigkeitsbereich zwischen ca. 12 und 65 km/h einsatzfähig. Die Warnung erfolgt bei einem Fußgänger im Kollisionsbereich vor dem Fahrzeug. ", "16px 'Porsche Next TT'");
	this.text_11.name = "text_11";
	this.text_11.lineHeight = 23;
	this.text_11.lineWidth = 726;
	this.text_11.setTransform(2,2);
	this.text_11._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_11).wait(10).to({_off:false},0).to({_off:true},1).wait(130));

	// Ebene 7
	this.text_10 = new cjs.Text("Fußgängerwarnung", "32px 'Porsche Next TT Thin'");
	this.text_10.name = "text_10";
	this.text_10.lineHeight = 47;
	this.text_10.lineWidth = 996;
	this.text_10.setTransform(2,2);
	this.text_10._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_10).wait(9).to({_off:false},0).to({_off:true},1).wait(131));

	// Ebene 6
	this.text_06 = new cjs.Text("Spurhalteassistent", "16px 'Porsche Next TT'", "#FFFFFF");
	this.text_06.name = "text_06";
	this.text_06.lineHeight = 23;
	this.text_06.lineWidth = 246;
	this.text_06.setTransform(2,2);
	this.text_06._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_06).wait(5).to({_off:false},0).to({_off:true},1).wait(135));

	// Ebene 5
	this.text_05 = new cjs.Text("Stauassistent", "16px 'Porsche Next TT'", "#FFFFFF");
	this.text_05.name = "text_05";
	this.text_05.lineHeight = 23;
	this.text_05.lineWidth = 246;
	this.text_05.setTransform(2,2);
	this.text_05._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_05).wait(4).to({_off:false},0).to({_off:true},1).wait(136));

	// Ebene 4
	this.text_04 = new cjs.Text("Anhaltewegverkürzung (AWV)", "16px 'Porsche Next TT'", "#FFFFFF");
	this.text_04.name = "text_04";
	this.text_04.lineHeight = 23;
	this.text_04.lineWidth = 246;
	this.text_04.setTransform(2,2);
	this.text_04._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_04).wait(3).to({_off:false},0).to({_off:true},1).wait(137));

	// Ebene 3
	this.text_03 = new cjs.Text("Fußgängerwarnung", "16px 'Porsche Next TT'", "#FFFFFF");
	this.text_03.name = "text_03";
	this.text_03.lineHeight = 23;
	this.text_03.lineWidth = 246;
	this.text_03.setTransform(2,2);
	this.text_03._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_03).wait(2).to({_off:false},0).to({_off:true},1).wait(138));

	// Ebene 2
	this.text_02 = new cjs.Text("Die Assistenzsysteme wurden im neuen Macan (MJ 19) weiter ergänzt um:\n\nFußgängerwarnung\nAnhaltewegverkürzung (AWV)\nStauassistent\nSpurhalteassistent\n\nDetails erhalten Sie per Klick auf die Buttons.\n", "16px 'Porsche Next TT'");
	this.text_02.name = "text_02";
	this.text_02.lineHeight = 23;
	this.text_02.lineWidth = 336;
	this.text_02.setTransform(2,2);
	this.text_02._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_02).wait(1).to({_off:false},0).to({_off:true},1).wait(139));

	// Ebene 1
	this.text_01 = new cjs.Text("Assistenzsysteme", "32px 'Porsche Next TT Thin'");
	this.text_01.name = "text_01";
	this.text_01.lineHeight = 47;
	this.text_01.lineWidth = 356;
	this.text_01.setTransform(2,2);

	this.timeline.addTween(cjs.Tween.get(this.text_01).to({_off:true},1).wait(140));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,360,50.9);


(lib.btn_blind_rectangle = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("Aj5D6IAAnzIHzAAIAAHzg");
	this.shape.setTransform(25,25);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(3).to({_off:false},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.btn_blind_circular = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,255,255,0.976)").s().p("AiwCwQhIhJgBhnQABhmBIhJQBKhKBmAAQBnAABJBKQBJBJABBmQgBBnhJBJQhJBKhnAAQhmAAhKhKg");
	this.shape.setTransform(25,25);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(3).to({_off:false},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.btn_blind = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#002F6C").s().p("Aj5D6IAAnzIHzAAIAAHzg");
	this.shape.setTransform(25,25);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(3).to({_off:false},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.btn_arrow_openSideBar = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{out:0,over:4,down:9});

	// Ebene 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ag/B9IBkh9Ihkh8IAbAAIBlB8IhlB9g");
	this.shape.setTransform(25,35);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(10));

	// Ebene 3
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#D5001C").s().p("Aj5FeIAAq7IHzAAIAAK7g");
	this.shape_1.setTransform(25,35);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(10));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,50,70);


(lib.ani_range02_ = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("EB7ugVtQA9K2AAK3QAAK4g9K2Mj4XgVug");
	mask.setTransform(797.9,0.4);

	// Ebene 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("rgba(213,0,28,0.2)").ss(50,2,0,3).p("ECscAAAUAAABHbgyhAygUgygAyhhHbAAAUhHaAAAgyhgyhUgyggygAAAhHbUAAAhHaAyggyhUAyhgygBHaAAAUBHbAAAAygAygUAyhAyhAAABHag");

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("rgba(213,0,28,0.255)").ss(50,2,0,3).p("EihVAAAUAAAhC0AvQgvRUAvRgvQBC0AAAUBC1AAAAvQAvQUAvRAvRAAABC0UAAABC1gvRAvQUgvQAvRhC1AAAUhC0AAAgvRgvRUgvQgvQAAAhC1g");

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("rgba(213,0,28,0.306)").ss(50,2,0,3).p("EiWPAAAUAAAg+OAsAgsAUAsBgsBA+OAAAUA+PAAAAsAAsBUAsBAsAAAAA+OUAAAA+PgsBAsAUgsAAsBg+PAAAUg+OAAAgsBgsBUgsAgsAAAAg+Pg");

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("rgba(213,0,28,0.361)").ss(50,2,0,3).p("EiLJAAAUAAAg5nAowgoxUAoxgowA5oAAAUA5pAAAAowAowUAoxAoxAAAA5nUAAAA5pgoxAovUgowAoxg5pAAAUg5oAAAgoxgoxUgowgovAAAg5pg");

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("rgba(213,0,28,0.412)").ss(50,2,0,3).p("EiADAAAUAAAg1BAlgglhUAlhglgA1CAAAUA1DAAAAlgAlgUAlhAlhAAAA1BUAAAA1DglhAlfUglgAlhg1DAAAUg1CAAAglhglhUglgglfAAAg1Dg");

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("rgba(213,0,28,0.467)").ss(50,2,0,3).p("Eh09AAAUAAAgwbAiRgiRUAiQgiQAwcAAAUAwdAAAAiQAiQUAiRAiRAAAAwbUAAAAwcgiRAiQUgiQAiRgwdAAAUgwcAAAgiQgiRUgiRgiQAAAgwcg");

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("rgba(213,0,28,0.522)").ss(50,2,0,3).p("Ehp3AAAUAAAgr1AfBgfBUAfBgfAAr1AAAUAr2AAAAfBAfAUAfBAfBAAAAr1UAAAAr2gfBAfAUgfBAfBgr2AAAUgr1AAAgfBgfBUgfBgfAAAAgr2g");

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("rgba(213,0,28,0.573)").ss(50,2,0,3).p("EhewAAAUAAAgnPAbwgbxUAbxgbwAnPAAAUAnQAAAAbxAbwUAbwAbxAAAAnPUAAAAnRgbwAbwUgbxAbwgnQAAAUgnPAAAgbxgbwUgbwgbwAAAgnRg");

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("rgba(213,0,28,0.678)").ss(50,2,0,3).p("EhIkAAAQAA+DVQ1RQVR1QeDAAQeEAAVQVQQVRVRAAeDQAAeE1RVQQ1QVR+EAAQ+DAA1R1RQ1Q1QAA+Eg");

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("rgba(213,0,28,0.733)").ss(50,2,0,3).p("Eg9eAAAQAA5dSAyAQSByBZdAAQZeAASASBQSBSAAAZdQAAZeyBSAQyASB5eAAQ5dAAyByBQyAyAAA5eg");

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("rgba(213,0,28,0.788)").ss(50,2,0,3).p("EgyYAAAQAA03OxuwQOwuxU3AAQU4AAOwOxQOxOwAAU3QAAU4uxOwQuwOx04AAQ03AAuwuxQuxuwAA04g");

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("rgba(213,0,28,0.839)").ss(50,2,0,3).p("EgnSAAAQAAwRLhrgQLgrhQRAAQQSAALgLhQLhLgAAQRQAAQSrhLgQrgLhwSAAQwRAArgrhQrhrgAAwSg");

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("rgba(213,0,28,0.894)").ss(50,2,0,3).p("A8LAAQAArqIQoRQIQoQLrAAQLsAAIQIQQIQIRAALqQAALsoQIQQoQIQrsAAQrrAAoQoQQoQoQAArsg");

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("rgba(213,0,28,0.945)").ss(50,2,0,3).p("AxFAAQAAnEFAlBQFBlAHEAAQHFAAFBFAQFAFBAAHEQAAHFlAFBQlBFAnFAAQnEAAlBlAQlAlBAAnFg");

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("rgba(213,0,28,0.627)").ss(50,2,0,3).p("EhTqAAAUAAAgipAYggYhUAYhgYgAipAAAUAiqAAAAYgAYgUAYhAYhAAAAipUAAAAiqgYhAYgUgYgAYhgiqAAAUgipAAAgYhgYhUgYggYgAAAgiqg");

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#D5001C").ss(50,2,0,3).p("AGAAAQAACfhwBxQhxBwifAAQieAAhxhwQhwhxAAifQAAieBwhxQBxhwCeAAQCfAABxBwQBwBxAACeg");

	this.shape.mask = this.shape_1.mask = this.shape_2.mask = this.shape_3.mask = this.shape_4.mask = this.shape_5.mask = this.shape_6.mask = this.shape_7.mask = this.shape_8.mask = this.shape_9.mask = this.shape_10.mask = this.shape_11.mask = this.shape_12.mask = this.shape_13.mask = this.shape_14.mask = this.shape_15.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,-139.1,1128.7,278.4);


(lib.ani_linesFlag = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#09AFC1").s().p("AgUAVQgIgIAAgMIAAgBQAAgLAIgJQAJgJALAAQAMAAAIAJQAKAJgBALQABAMgKAJQgIAJgMAAQgLAAgJgJg");
	this.shape.setTransform(221.3,40.6);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(21).to({_off:false},0).wait(1));

	// Ebene 2
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#09AFC1").ss(2,2,0,3).p("AAAgJIAAAT");
	this.shape_1.setTransform(221.3,1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#09AFC1").ss(2,2,0,3).p("AAAAlIAAhJ");
	this.shape_2.setTransform(221.3,3.8);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#09AFC1").ss(2,2,0,3).p("AAABBIAAiB");
	this.shape_3.setTransform(221.3,6.5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#09AFC1").ss(2,2,0,3).p("AAABcIAAi3");
	this.shape_4.setTransform(221.3,9.3);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#09AFC1").ss(2,2,0,3).p("AAAB4IAAjv");
	this.shape_5.setTransform(221.3,12.1);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#09AFC1").ss(2,2,0,3).p("AAACTIAAkl");
	this.shape_6.setTransform(221.3,14.8);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#09AFC1").ss(2,2,0,3).p("AAACvIAAlc");
	this.shape_7.setTransform(221.3,17.6);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#09AFC1").ss(2,2,0,3).p("AAAjJIAAGT");
	this.shape_8.setTransform(221.3,20.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_1}]},14).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).wait(1));

	// Ebene 1
	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#09AFC1").ss(2,2,0,3).p("AAFAAIgJAA");
	this.shape_9.setTransform(0.5,0.1);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#09AFC1").ss(2,2,0,3).p("AhSAAIClAA");
	this.shape_10.setTransform(8.4,0.1);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#09AFC1").ss(2,2,0,3).p("AihAAIFDAA");
	this.shape_11.setTransform(16.2,0.1);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#09AFC1").ss(2,2,0,3).p("AjwAAIHhAA");
	this.shape_12.setTransform(24.1,0.1);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#09AFC1").ss(2,2,0,3).p("Ak+AAIJ9AA");
	this.shape_13.setTransform(32,0.1);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#09AFC1").ss(2,2,0,3).p("AmNAAIMbAA");
	this.shape_14.setTransform(39.9,0.1);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#09AFC1").ss(2,2,0,3).p("AncAAIO5AA");
	this.shape_15.setTransform(47.7,0.1);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#09AFC1").ss(2,2,0,3).p("AoqAAIRVAA");
	this.shape_16.setTransform(55.6,0.1);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().s("#09AFC1").ss(2,2,0,3).p("Ap5AAITzAA");
	this.shape_17.setTransform(63.5,0.1);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("#09AFC1").ss(2,2,0,3).p("ArIAAIWRAA");
	this.shape_18.setTransform(71.3,0.1);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f().s("#09AFC1").ss(2,2,0,3).p("AsWAAIYtAA");
	this.shape_19.setTransform(79.2,0.1);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f().s("#09AFC1").ss(2,2,0,3).p("AtlAAIbLAA");
	this.shape_20.setTransform(87.1,0.1);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f().s("#09AFC1").ss(2,2,0,3).p("Au0AAIdpAA");
	this.shape_21.setTransform(94.9,0.1);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f().s("#09AFC1").ss(2,2,0,3).p("AwCAAMAgFAAA");
	this.shape_22.setTransform(102.8,0.1);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f().s("#09AFC1").ss(2,2,0,3).p("AxRAAMAijAAA");
	this.shape_23.setTransform(110.7,0.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9}]}).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).wait(8));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-0.9,3,2);


(lib.warningSystem02_startpic01 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.instance = new lib.ani_linesFlag("single",21);
	this.instance.setTransform(370.3,185.7,0.6,0.6,-90,0,0,-0.1,0);

	this.instance_1 = new lib.ani_linesFlag("single",21);
	this.instance_1.setTransform(246.9,168.6,0.6,0.6,-90,0,0,-0.1,0.1);

	this.instance_2 = new lib.ani_linesFlag("single",21);
	this.instance_2.setTransform(122.9,151.6,0.6,0.6,-90);

	this.instance_3 = new lib.ani_linesFlag("single",21);
	this.instance_3.setTransform(0,134.7,0.6,0.6,-90,0,0,-0.1,0.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,0,397.4,186.6);


(lib.scrollerContent_text_sideBar = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.instance = new lib.container_text("single",1);
	this.instance.setTransform(51.3,14.2,1,1,0,0,0,51.3,14.2);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,340,262);


(lib.scroller_500 = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.slider = new lib.scroller_handle();

	this.bg = new lib.scroller_back_500();
	this.bg.setTransform(2,0);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.bg},{t:this.slider}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,9,500);


(lib.pic_text_sideBar01 = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// Ebene 6
	this.scrollerItem = new lib.scroller_500();
	this.scrollerItem.setTransform(350,60);

	this.timeline.addTween(cjs.Tween.get(this.scrollerItem).wait(1));

	// container_text
	this.instance = new lib.container_text("single",0);
	this.instance.setTransform(51.3,14.2,1,1,0,0,0,51.3,14.2);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// container_text
	this.scrollerContent = new lib.scrollerContent_text_sideBar();
	this.scrollerContent.setTransform(0,60);

	this.timeline.addTween(cjs.Tween.get(this.scrollerContent).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,360,560);


(lib.pic_text_sideBar_back = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.instance = new lib.pic_plane_white();
	this.instance.setTransform(209,325,1,1,0,0,0,209,325);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,1158,530);


(lib.container_pics = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// Ebene 2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_41 = new cjs.Graphics().p("AnCGkQhGhGgqhSQCYkJAAlHQAAhBgGg+QCjiODggBQD0AACuCuQCuCvAAD1QAAD2iuCuQiuCuj0AAQj3AAiuiug");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(41).to({graphics:mask_graphics_41,x:60,y:61.8}).wait(1).to({graphics:null,x:0,y:0}).wait(144));

	// Ebene 4
	this.instance = new lib.c6p1_pic04();
	this.instance.setTransform(24,0);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(10,0,0,3).p("EBBHAAAIaCAAAZvAAIaCAAEhbIAAAIY3AAEg08AAAIaCAAAtmAAIaBAA");
	this.shape.setTransform(583.4,351.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#FFFFFF").ss(1,1,0,3,true).p("Egu/AAAQABizAQhpQARhpAGgvQAGgvANgxQANgxAZg8QAag9ATgnQCekbB4g7QCLhECZgiQBXgNBWgMQBYgKBMgEQBLgFBoAAQBQgFBRABQArAAApABQCHAHDVAMQCxAQBXABQBXABApADQApADBHACQAyhNBOg2QBOg2BJAKQAWAEAVAEIgzCbQFkAcFwgEQBCgtAoAAQAnAABAADQBAACBNA1QBNAAA0ACQA1ABCTgmQBEgkGtgIQGugICUAmQCVAmBpAmQBpAmCjBWQCkBWA/BEQBCBIArCyQArCyAJBQQAJBQAVENQgVEOgJBQQgJBQgrCyQgrCyhCBIQg/BEikBVQijBXhpAmQhpAmiVAmQiUAmmugIQmtgJhEgjQiTgmg1ABQg0AChNAAQhNA1hAACQhAADgnAAQgoAAhCgtQlwgElkAcIAzCbQgVAEgWAEQhJAKhOg3QhOg1gyhNQhHACgpADQgpADhXABQhXABixAQQjVAMiHAHQgpAAgrABQhRABhQgFQhoAAhLgFQhMgEhYgKQhWgNhXgMQiZgiiLhEQh4g7iekbQgTgngag9QgZg9gNgwQgNgxgGgwQgGgugRhpQgQhpgBiz");
	this.shape_1.setTransform(302.5,139.8);

	this.instance_1 = new lib.pic_lightGlowing();
	this.instance_1.setTransform(29.1,235,1,1,0,180,0,14,0);
	this.instance_1.shadow = new cjs.Shadow("rgba(213,0,28,1)",0,0,4);

	this.instance_2 = new lib.pic_lightGlowing();
	this.instance_2.setTransform(29.1,235,1,1,0,180,0,14,0);
	this.instance_2.shadow = new cjs.Shadow("rgba(213,0,28,1)",0,0,4);

	this.instance_3 = new lib.pic_lightGlowing();
	this.instance_3.setTransform(29.1,235,1,1,0,180,0,14,0);
	this.instance_3.shadow = new cjs.Shadow("rgba(213,0,28,1)",0,0,4);

	this.instance_4 = new lib.pic_lightGlowing();
	this.instance_4.setTransform(29.1,46.1,1,1,0,0,0,14,0);
	this.instance_4.shadow = new cjs.Shadow("rgba(213,0,28,1)",0,0,4);

	this.instance_5 = new lib.pic_lightGlowing();
	this.instance_5.setTransform(29.1,46.1,1,1,0,0,0,14,0);
	this.instance_5.shadow = new cjs.Shadow("rgba(213,0,28,1)",0,0,4);

	this.instance_6 = new lib.pic_lightGlowing();
	this.instance_6.setTransform(29.1,46.1,1,1,0,0,0,14,0);
	this.instance_6.shadow = new cjs.Shadow("rgba(213,0,28,1)",0,0,4);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#FFFFFF").ss(10,0,0,3).p("EBBHAAAIaCAAAZvAAIaCAAEhbIAAAIY3AAEg08AAAIaCAAAtmAAIaBAA");
	this.shape_2.setTransform(609,317.1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#FFFFFF").ss(10,0,0,3).p("EhfIAjZMC+RAAAEhfIgjYMC+RAAA");
	this.shape_3.setTransform(609,241.6);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#FFFFFF").ss(1,1,0,3,true).p("EAvAAAAQgBizgQhpQgRhpgGgvQgGgvgNgxQgNgxgZg8Qgag9gTgnQiekbh4g7QiLhEiZgiQhXgNhWgMQhYgKhMgEQhLgFhoAAQhQgFhRABQgrAAgpABQiHAHjVAMQixAQhXABQhXABgpADQgpADhHACQgyhNhOg2QhOg2hJAKQgWAEgVAEIAzCbQlkAclwgEQhCgtgoAAQgnAAhAADQhAAChNA1QhNAAg0ACQg1ABiTgmQhEgkmtgIQmugIiUAmQiVAmhpAmQhpAmijBWQikBWg/BEQhCBIgrCyQgrCygJBQQgJBQgVENQAVEOAJBQQAJBQArCyQArCyBCBIQA/BECkBVQCjBXBpAmQBpAmCVAmQCUAmGugIQGtgJBEgjQCTgmA1ABQA0ACBNAAQBNA1BAACQBAADAnAAQAoAABCgtQFwgEFkAcIgzCbQAVAEAWAEQBJAKBOg3QBOg1AyhNQBHACApADQApADBXABQBXABCxAQQDVAMCHAHQApAAArABQBRABBQgFQBoAABLgFQBMgEBYgKQBWgNBXgMQCZgiCLhEQB4g7CekbQATgnAag9QAZg9ANgwQANgxAGgwQAGguARhpQAQhpABiz");
	this.shape_4.setTransform(300.8,139.8);

	this.instance_7 = new lib.c6p1_pic32();

	this.instance.mask = this.shape.mask = this.shape_1.mask = this.instance_1.mask = this.instance_2.mask = this.instance_3.mask = this.instance_4.mask = this.instance_5.mask = this.instance_6.mask = this.shape_2.mask = this.shape_3.mask = this.shape_4.mask = this.instance_7.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance}]},3).to({state:[{t:this.shape,p:{x:583.4,y:351.5}}]},1).to({state:[{t:this.shape_1}]},1).to({state:[]},1).to({state:[{t:this.instance_6,p:{x:29.1}},{t:this.instance_5,p:{x:29.1}},{t:this.instance_4,p:{x:29.1}},{t:this.instance_3,p:{x:29.1}},{t:this.instance_2,p:{x:29.1}},{t:this.instance_1,p:{x:29.1}}]},1).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape,p:{x:609,y:166.1}}]},1).to({state:[]},1).to({state:[{t:this.instance_6,p:{x:52.6}},{t:this.instance_5,p:{x:52.6}},{t:this.instance_4,p:{x:52.6}},{t:this.instance_3,p:{x:52.6}},{t:this.instance_2,p:{x:52.6}},{t:this.instance_1,p:{x:52.6}},{t:this.shape_4}]},1).to({state:[]},1).to({state:[{t:this.instance_6,p:{x:29.1}},{t:this.instance_5,p:{x:29.1}},{t:this.instance_4,p:{x:29.1}},{t:this.instance_3,p:{x:29.1}},{t:this.instance_2,p:{x:29.1}},{t:this.instance_1,p:{x:29.1}}]},29).to({state:[{t:this.instance_7}]},1).to({state:[]},1).wait(144));

	// Ebene 3
	this.instance_8 = new lib.c6p1_pic01();

	this.instance_9 = new lib.c6p1_pic02();

	this.instance_10 = new lib.c6p1_pic03();

	this.instance_11 = new lib.pic_shadow_occlusionRound();
	this.instance_11.setTransform(167.7,70.7,0.412,0.052,0,0,0,0,1);
	this.instance_11.alpha = 0.5;

	this.instance_12 = new lib.pic_shadow_occlusionRound();
	this.instance_12.setTransform(76.4,70.7,0.412,0.052,0,0,0,-0.1,1);
	this.instance_12.alpha = 0.5;

	this.instance_13 = new lib.pic_shadow_occlusionRound();
	this.instance_13.setTransform(109.4,70.7,0.708,0.052,0,0,0,0,1);
	this.instance_13.alpha = 0.5;

	this.instance_14 = new lib.pic_shadow_occlusionRound();
	this.instance_14.setTransform(154.6,70.7,0.896,0.052,0,0,0,0,1);
	this.instance_14.alpha = 0.5;

	this.instance_15 = new lib.pic_shadow_occlusionRound();
	this.instance_15.setTransform(99.8,70.7,0.896,0.052,0,0,0,-0.1,1);
	this.instance_15.alpha = 0.5;

	this.instance_16 = new lib.pic_shadow_occlusionRound();
	this.instance_16.setTransform(130.4,70.7,0.896,0.052,0,0,0,0.1,1);
	this.instance_16.alpha = 0.5;

	this.instance_17 = new lib.pic_shadow_occlusionRound();
	this.instance_17.setTransform(62.4,70.6,0.211,0.026,0,0,0,-0.5,0);

	this.instance_18 = new lib.pic_shadow_occlusionRound();
	this.instance_18.setTransform(188.4,70.6,0.211,0.026,0,0,0,-0.3,0);

	this.instance_19 = new lib.c6p1_pic05();
	this.instance_19.setTransform(0,111);

	this.instance_20 = new lib.c6p1_pic06();

	this.instance_21 = new lib.c6p1_pic07();

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_8}]}).to({state:[{t:this.instance_9}]},1).to({state:[{t:this.instance_10}]},1).to({state:[{t:this.instance_18},{t:this.instance_17},{t:this.instance_16},{t:this.instance_15},{t:this.instance_14},{t:this.instance_13},{t:this.instance_12},{t:this.instance_11}]},1).to({state:[{t:this.instance_19,p:{y:111}}]},1).to({state:[{t:this.instance_20,p:{skewY:0,x:0}}]},1).to({state:[]},1).to({state:[{t:this.instance_21}]},1).to({state:[{t:this.instance_19,p:{y:0}}]},1).to({state:[]},1).to({state:[{t:this.instance_20,p:{skewY:180,x:603}}]},1).to({state:[]},1).to({state:[{t:this.instance_21}]},29).to({state:[]},1).wait(145));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,1218,703);


(lib.button04 = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{"out":0,"over":1,"down":2,visited:3});

	// Ebene 1
	this.instance = new lib.container_text("single",5);
	this.instance.setTransform(585.5,266.8,1,1,0,0,0,555.5,258);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(4));

	// Ebene 4
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D5001C").s().p("AgtBZIgBgBIBKhYIhKhXIABgBIARAAIBLBYIhLBZg");
	this.shape.setTransform(14.7,22.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#737278").s().p("AgtBZIgBgBIBKhYIhKhXIABgBIARAAIBLBYIhLBZg");
	this.shape_1.setTransform(14.7,22.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},3).wait(1));

	// btn_blind_rectangle
	this.instance_1 = new lib.btn_blind_rectangle();
	this.instance_1.setTransform(0,0.1,6.8,0.9,0,0,0,0,0.1);
	new cjs.ButtonHelper(this.instance_1, 0, 1, 2, false, new lib.btn_blind_rectangle(), 3);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(4));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,340,45);


(lib.button03 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"out":0,"over":1,"down":2,"visited":3});

	// Ebene 1
	this.instance = new lib.container_text("single",4);
	this.instance.setTransform(585.5,266.8,1,1,0,0,0,555.5,258);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(4));

	// Ebene 4
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D5001C").s().p("AgtBZIgBgBIBKhYIhKhXIABgBIARAAIBLBYIhLBZg");
	this.shape.setTransform(14.7,22.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#737278").s().p("AgtBZIgBgBIBKhYIhKhXIABgBIARAAIBLBYIhLBZg");
	this.shape_1.setTransform(14.7,22.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},3).wait(1));

	// btn_blind_rectangle
	this.instance_1 = new lib.btn_blind_rectangle();
	this.instance_1.setTransform(0,0.1,6.8,0.9,0,0,0,0,0.1);
	new cjs.ButtonHelper(this.instance_1, 0, 1, 2, false, new lib.btn_blind_rectangle(), 3);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(4));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,340,45);


(lib.button02 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"out":0,"over":1,"down":2,"visited":3});

	// Ebene 1
	this.instance = new lib.container_text("single",3);
	this.instance.setTransform(585.5,266.8,1,1,0,0,0,555.5,258);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(4));

	// Ebene 4
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D5001C").s().p("AgtBZIgBgBIBKhYIhKhXIABgBIARAAIBLBYIhLBZg");
	this.shape.setTransform(14.7,22.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#737278").s().p("AgtBZIgBgBIBKhYIhKhXIABgBIARAAIBLBYIhLBZg");
	this.shape_1.setTransform(14.7,22.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},3).wait(1));

	// btn_blind_rectangle
	this.instance_1 = new lib.btn_blind_rectangle();
	this.instance_1.setTransform(0,0,6.8,0.9);
	new cjs.ButtonHelper(this.instance_1, 0, 1, 2, false, new lib.btn_blind_rectangle(), 3);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(4));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,340,45);


(lib.button01 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"out":0,"over":1,"down":2,"visited":3});

	// Ebene 1
	this.instance = new lib.container_text("single",2);
	this.instance.setTransform(585.5,266.8,1,1,0,0,0,555.5,258);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(4));

	// Ebene 4
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D5001C").s().p("AgtBZIgBgBIBKhYIhKhXIABgBIARAAIBLBYIhLBZg");
	this.shape.setTransform(14.7,22.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#737278").s().p("AgtBZIgBgBIBKhYIhKhXIABgBIARAAIBLBYIhLBZg");
	this.shape_1.setTransform(14.7,22.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},3).wait(1));

	// btn_blind_rectangle
	this.instance_1 = new lib.btn_blind_rectangle();
	this.instance_1.setTransform(0,0,6.8,0.9);
	new cjs.ButtonHelper(this.instance_1, 0, 1, 2, false, new lib.btn_blind_rectangle(), 3);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(4));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,340,45);


(lib.button_play_dark = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// Ebene 2
	this.instance = new lib.btn_blind_circular();
	this.instance.setTransform(0,0,1.3,1.3);
	new cjs.ButtonHelper(this.instance, 0, 1, 2, false, new lib.btn_blind_circular(), 3);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Ebene 1
	this.instance_1 = new lib.pics_button_play("single",2);
	this.instance_1.setTransform(10.6,15.7,1,1,0,0,0,10.6,15.7);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-1,67,67);


(lib.button_play = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// Ebene 2
	this.instance = new lib.btn_blind_circular();
	this.instance.setTransform(0,0,1.3,1.3);
	new cjs.ButtonHelper(this.instance, 0, 1, 2, false, new lib.btn_blind_circular(), 3);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Ebene 1
	this.instance_1 = new lib.pics_button_play("single",0);
	this.instance_1.setTransform(10.6,15.7,1,1,0,0,0,10.6,15.7);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-1,67,67);


(lib.btn_close02 = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// background
	this.instance = new lib.btn_blind();
	this.instance.setTransform(12,11.7,0.48,0.48,0,0,0,24.9,25);
	new cjs.ButtonHelper(this.instance, 0, 1, 2, false, new lib.btn_blind(), 3);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Ebene 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#333333").ss(1.5,2,1).p("Ah0h1IB0B0Ih3B3AAAgBIB3B3AB0h1Ih0B0");
	this.shape.setTransform(12,11.8);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1.4,-1.4,26.8,26.5);


(lib.ani_warningSystem03 = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{step1:12});

	// timeline functions:
	this.frame_3 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(3).call(this.frame_3).wait(112));

	// Ebene 21 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("EhfJAlqMAAAhLTMC+SAAAMAAABLTgEBbJAL4I6CAAgEAzxAL4I6CAAgAMbL4I6AAAgA66L4I6CAAgEhCRAL4I43AAgEBbJgLsI6CAAgEAzxgLsI6CAAgAMbrsI6AAAgA66rsI6CAAgEhCRgLsI43AAg");
	mask.setTransform(609,241);

	// Ebene 16
	this.button_gotoAndPlay_parent_step1 = new lib.button_play();
	this.button_gotoAndPlay_parent_step1.setTransform(1300.4,369.5,1,1,0,0,0,31.7,31.7);
	this.button_gotoAndPlay_parent_step1._off = true;

	this.button_gotoAndPlay_parent_step1.mask = mask;

	this.timeline.addTween(cjs.Tween.get(this.button_gotoAndPlay_parent_step1).wait(3).to({_off:false},0).wait(111).to({x:1162.6,y:411.7},0).wait(1));

	// Ebene 14
	this.instance = new lib.container_pics("single",41);
	this.instance.setTransform(353,57.2,1,1,0,0,0,0,0.2);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(115));

	// container_pics
	this.instance_1 = new lib.container_pics("single",10);
	this.instance_1.setTransform(541,28.1,0.398,0.398,0,0,0,-0.1,-0.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(12).to({startPosition:10},0).to({alpha:0},7).to({_off:true},1).wait(95));

	// mask
	this.instance_2 = new lib.container_pics("single",10);
	this.instance_2.setTransform(952.4,28.1,0.398,0.398,0,0,0,-0.1,-0.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(12).to({startPosition:10},0).to({alpha:0},7).to({_off:true},1).wait(95));

	// container_pics
	this.instance_3 = new lib.container_pics("single",10);
	this.instance_3.setTransform(80,332.1,0.398,0.398,0,0,0,-0.1,-0.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(12).to({startPosition:10},0).to({alpha:0},7).to({_off:true},1).wait(95));

	// Ebene 9
	this.instance_4 = new lib.container_pics("single",10);
	this.instance_4.setTransform(71,28.1,0.398,0.398,0,0,0,-0.1,-0.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(12).to({startPosition:10},0).to({alpha:0},7).to({_off:true},1).wait(95));

	// container_pics
	this.instance_5 = new lib.container_pics("single",10);
	this.instance_5.setTransform(560,182.1,0.398,0.398,0,0,0,-0.1,-0.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(12).to({startPosition:10},0).to({alpha:0},7).to({_off:true},1).wait(95));

	// container_pics
	this.instance_6 = new lib.container_pics("single",10);
	this.instance_6.setTransform(904.5,182.1,0.398,0.398,0,0,0,-0.1,-0.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(12).to({startPosition:10},0).to({alpha:0},7).to({_off:true},1).wait(95));

	// container_pics
	this.instance_7 = new lib.container_pics("single",10);
	this.instance_7.setTransform(403.5,332.1,0.398,0.398,0,0,0,-0.1,-0.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(12).to({startPosition:10},0).to({alpha:0},7).to({_off:true},1).wait(95));

	// Ebene 6
	this.instance_8 = new lib.container_pics("single",10);
	this.instance_8.setTransform(748,332.1,0.398,0.398,0,0,0,-0.1,-0.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(12).to({startPosition:10},0).to({alpha:0},7).to({_off:true},1).wait(95));

	// Ebene 2 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_0 = new cjs.Graphics().p("Eg5AAPTIAA+mMByBAAAIAAemg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:mask_1_graphics_0,x:365,y:242}).wait(20).to({graphics:null,x:0,y:0}).wait(95));

	// mask
	this.instance_9 = new lib.ani_range02_("single",0);
	this.instance_9.setTransform(357.7,234,0.5,0.5);
	this.instance_9.alpha = 0.5;

	this.instance_9.mask = mask_1;

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(12).to({startPosition:0},0).to({alpha:0},7).to({_off:true},1).wait(95));

	// Ebene 4
	this.instance_10 = new lib.container_pics("single",40);
	this.instance_10.setTransform(212,182.1,0.398,0.398,0,0,0,-0.1,-0.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(12).to({startPosition:40},0).to({alpha:0},7).to({_off:true},1).wait(95));

	// mask
	this.instance_11 = new lib.container_pics("single",8);
	this.instance_11.setTransform(667.5,351.5,1,1,0,0,0,667.5,351.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(12).to({startPosition:8},0).to({scaleX:1,x:669.9,alpha:0},7).to({_off:true},1).wait(95));

	// Ebene 1
	this.instance_12 = new lib.container_pics("single",10);
	this.instance_12.setTransform(498,28.1,0.398,0.398,0,0,0,-0.1,-0.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(73).to({startPosition:10},0).to({regX:0,regY:0,x:541},32,cjs.Ease.get(-1)).wait(10));

	// Ebene 11
	this.instance_13 = new lib.container_pics("single",10);
	this.instance_13.setTransform(816.5,28.1,0.398,0.398,0,0,0,-0.1,-0.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_13).wait(44).to({startPosition:10},0).to({x:952.4},61,cjs.Ease.get(-1)).wait(10));

	// Ebene 13
	this.instance_14 = new lib.container_pics("single",10);
	this.instance_14.setTransform(30,332.1,0.398,0.398,0,0,0,-0.1,-0.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_14).wait(20).to({startPosition:10},0).to({x:80},48,cjs.Ease.get(1)).wait(47));

	// Ebene 15
	this.instance_15 = new lib.container_pics("single",10);
	this.instance_15.setTransform(71,28.1,0.398,0.398,0,0,0,-0.1,-0.1);

	this.instance_16 = new lib.container_pics("single",10);
	this.instance_16.setTransform(560,182.1,0.398,0.398,0,0,0,-0.1,-0.1);

	this.instance_17 = new lib.container_pics("single",10);
	this.instance_17.setTransform(904.5,182.1,0.398,0.398,0,0,0,-0.1,-0.1);

	this.instance_18 = new lib.container_pics("single",10);
	this.instance_18.setTransform(403.5,332.1,0.398,0.398,0,0,0,-0.1,-0.1);

	this.instance_19 = new lib.container_pics("single",10);
	this.instance_19.setTransform(748,332.1,0.398,0.398,0,0,0,-0.1,-0.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_19},{t:this.instance_18},{t:this.instance_17},{t:this.instance_16},{t:this.instance_15}]}).wait(115));

	// mask (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	mask_2.graphics.p("Eg5AAPTIAA+mMByBAAAIAAemg");
	mask_2.setTransform(365,242);

	// Ebene 18
	this.instance_20 = new lib.ani_range02_("single",0);
	this.instance_20.setTransform(191.7,234,0.5,0.5);
	this.instance_20.alpha = 0.5;

	this.instance_20.mask = mask_2;

	this.timeline.addTween(cjs.Tween.get(this.instance_20).wait(20).to({startPosition:0},0).to({x:357.7},85,cjs.Ease.get(1)).wait(10));

	// Ebene 19
	this.instance_21 = new lib.container_pics("single",40);
	this.instance_21.setTransform(52,182.1,0.398,0.398,0,0,0,-0.1,-0.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_21).wait(20).to({startPosition:40},0).to({x:212},85,cjs.Ease.get(1)).wait(10));

	// Ebene 20
	this.instance_22 = new lib.container_pics("single",8);
	this.instance_22.setTransform(641.1,351.5,1,1,0,0,0,641.1,351.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_22).wait(115));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-5,0,1228,482);


(lib.ani_text_sideBar01_ = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{end:12});

	// timeline functions:
	this.frame_1 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(1).call(this.frame_1).wait(12));

	// pic_arrow_textbox
	this.button_play_parent = new lib.btn_arrow_openSideBar();
	this.button_play_parent.setTransform(20,320,1,1,0,0,0,20,20);

	this.timeline.addTween(cjs.Tween.get(this.button_play_parent).wait(2).to({visible:false},0).wait(11));

	// pic_arrow_textbox
	this.button_back_parent = new lib.btn_arrow_openSideBar();
	this.button_back_parent.setTransform(-485.9,276.9,1,1,0,0,0,20,20);
	this.button_back_parent.visible = false;

	this.timeline.addTween(cjs.Tween.get(this.button_back_parent).wait(12).to({regX:25,regY:35,skewY:180,x:443,y:335,visible:true},0).wait(1));

	// Ebene 5
	this.scrollerWidget = new lib.pic_text_sideBar01();
	this.scrollerWidget.setTransform(-218,330,1,1,0,0,0,160,280);

	this.timeline.addTween(cjs.Tween.get(this.scrollerWidget).wait(2).to({x:200},10).wait(1));

	// pic_plane_white
	this.instance = new lib.pic_text_sideBar_back();
	this.instance.setTransform(-337.7,431.1,0.361,1.326,0,0,0,222.3,325);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(2).to({regX:222.5,x:80.3},10).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-505.9,0,556,703);


(lib.ani_text_sideBar01 = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{I:12});

	// Ebene 1
	this.instance = new lib.ani_text_sideBar01_("synched",2,false);
	this.instance.setTransform(209,325,1,1,0,0,0,209,325);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(12).to({mode:"independent"},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-505.9,0,556,703);


(lib.ani_range02 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.instance = new lib.ani_range02_("single",0);
	this.instance.setTransform(0,0,0.5,0.5);
	this.instance.alpha = 0.5;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(13).to({startPosition:0},0).wait(1).to({regX:564.3,regY:0.4,rotation:0.2,x:282.2,y:1.1},0).wait(1).to({rotation:0.7,x:282.1,y:3.6},0).wait(1).to({rotation:1.5,y:7.4},0).wait(1).to({rotation:2.4,x:281.9,y:12.2},0).wait(1).to({rotation:3.6,x:281.6,y:17.8},0).wait(1).to({rotation:4.8,x:281.1,y:23.7},0).wait(1).to({rotation:6,x:280.5,y:29.6},0).wait(1).to({rotation:7.1,x:279.9,y:35},0).wait(1).to({rotation:8,x:279.3,y:39.4},0).wait(1).to({rotation:8.6,x:278.8,y:42.3},0).wait(1).to({regX:0,regY:0,rotation:8.8,x:0,y:0},0).wait(1).to({regX:564.3,regY:0.4,x:278.7,y:43.3},0).wait(1).to({y:43.1},0).wait(1).to({rotation:8.7,y:42.8},0).wait(1).to({rotation:8.6,x:278.8,y:42.3},0).wait(1).to({rotation:8.5,x:278.9,y:41.8},0).wait(1).to({rotation:8.3,x:279,y:41.1},0).wait(1).to({rotation:8.2,x:279.1,y:40.4},0).wait(1).to({rotation:8,x:279.2,y:39.5},0).wait(1).to({rotation:7.8,x:279.3,y:38.6},0).wait(1).to({rotation:7.6,x:279.5,y:37.7},0).wait(1).to({rotation:7.4,x:279.6,y:36.6},0).wait(1).to({rotation:7.2,x:279.8,y:35.5},0).wait(1).to({rotation:7,x:280,y:34.4},0).wait(1).to({rotation:6.7,x:280.1,y:33.2},0).wait(1).to({rotation:6.5,x:280.2,y:31.9},0).wait(1).to({rotation:6.2,x:280.4,y:30.6},0).wait(1).to({rotation:5.9,x:280.5,y:29.3},0).wait(1).to({rotation:5.6,x:280.7,y:27.9},0).wait(1).to({rotation:5.3,x:280.8,y:26.4},0).wait(1).to({rotation:5,x:281,y:25},0).wait(1).to({rotation:4.7,x:281.1,y:23.5},0).wait(1).to({rotation:4.4,x:281.2,y:21.9},0).wait(1).to({rotation:4.1,x:281.3,y:20.3},0).wait(1).to({rotation:3.8,x:281.4,y:18.7},0).wait(1).to({rotation:3.4,x:281.5,y:17.1},0).wait(1).to({rotation:3.1,x:281.6,y:15.4},0).wait(1).to({rotation:2.8,x:281.7,y:13.8},0).wait(1).to({rotation:2.4,x:281.8,y:12.1},0).wait(1).to({rotation:2.1,x:281.9,y:10.3},0).wait(1).to({rotation:1.7,y:8.6},0).wait(1).to({rotation:1.3,x:282,y:6.8},0).wait(1).to({rotation:1,y:5.1},0).wait(1).to({rotation:0.6,y:3.3},0).wait(1).to({rotation:0.3,x:282.1,y:1.5},0).wait(1).to({rotation:-0.1,y:-0.3},0).wait(1).to({rotation:-0.5,y:-2.2},0).wait(1).to({rotation:-0.9,x:282,y:-4},0).wait(1).to({rotation:-1.2,y:-5.8},0).wait(1).to({rotation:-1.6,y:-7.7},0).wait(1).to({rotation:-2,x:281.9,y:-9.5},0).wait(1).to({rotation:-2.3,x:281.8,y:-11.3},0).wait(1).to({rotation:-2.7,y:-13.1},0).wait(1).to({rotation:-3.1,x:281.7,y:-14.9},0).wait(1).to({rotation:-3.4,x:281.6,y:-16.7},0).wait(1).to({rotation:-3.8,x:281.5,y:-18.4},0).wait(1).to({rotation:-4.1,x:281.3,y:-20},0).wait(1).to({rotation:-4.4,x:281.2,y:-21.6},0).wait(1).to({regX:0,regY:0,rotation:-4.8,x:0,y:0},0).to({scaleX:0.5,scaleY:0.5,rotation:-26.3},57).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0.1,-69.5,564.3,139.1);


(lib.ani_fadeIn = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.loop = true;
	}
	this.frame_9 = function() {
		this.loop = true;
	}
	this.frame_10 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(9).call(this.frame_9).wait(1).call(this.frame_10).wait(1));

	// Ebene 1
	this.instance = new lib.pic_plane_white();
	this.instance.setTransform(609,351.5,1.052,1.326,0,0,0,579,265);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({alpha:0},9).to({_off:true},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,1218,703);


(lib.ani_cycle = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 2
	this.instance = new lib.cycle0001();

	this.instance_1 = new lib.cycle0002();

	this.instance_2 = new lib.cycle0003();

	this.instance_3 = new lib.cycle0004();

	this.instance_4 = new lib.cycle0005();

	this.instance_5 = new lib.cycle0006();

	this.instance_6 = new lib.cycle0007();

	this.instance_7 = new lib.cycle0008();

	this.instance_8 = new lib.cycle0009();

	this.instance_9 = new lib.cycle0010();

	this.instance_10 = new lib.cycle0011();

	this.instance_11 = new lib.cycle0012();

	this.instance_12 = new lib.cycle0013();

	this.instance_13 = new lib.cycle0014();

	this.instance_14 = new lib.cycle0015();

	this.instance_15 = new lib.cycle0016();

	this.instance_16 = new lib.cycle0017();

	this.instance_17 = new lib.cycle0018();

	this.instance_18 = new lib.cycle0019();

	this.instance_19 = new lib.cycle0020();

	this.instance_20 = new lib.cycle0021();

	this.instance_21 = new lib.cycle0022();

	this.instance_22 = new lib.cycle0023();

	this.instance_23 = new lib.cycle0024();

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_9}]},1).to({state:[{t:this.instance_10}]},1).to({state:[{t:this.instance_11}]},1).to({state:[{t:this.instance_12}]},1).to({state:[{t:this.instance_13}]},1).to({state:[{t:this.instance_14}]},1).to({state:[{t:this.instance_15}]},1).to({state:[{t:this.instance_16}]},1).to({state:[{t:this.instance_17}]},1).to({state:[{t:this.instance_18}]},1).to({state:[{t:this.instance_19}]},1).to({state:[{t:this.instance_20}]},1).to({state:[{t:this.instance_21}]},1).to({state:[{t:this.instance_22}]},1).to({state:[{t:this.instance_23}]},1).wait(1));

	// Ebene 3
	this.instance_24 = new lib.pic_shadow_occlusionRound();
	this.instance_24.setTransform(56,59,0.432,0.432);
	this.instance_24.alpha = 0.5;

	this.instance_25 = new lib.pic_shadow_occlusionRound();
	this.instance_25.setTransform(56,59);
	this.instance_25.alpha = 0.5;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_25},{t:this.instance_24}]}).wait(24));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-55.5,-52.5,223,223);


(lib.warningSystem02_startpic02 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.instance = new lib.container_text("single",24);
	this.instance.setTransform(216.7,17.1,1,1,0,0,0,0,0.1);

	this.instance_1 = new lib.container_text("single",23);
	this.instance_1.setTransform(93.8,0);

	this.instance_2 = new lib.container_pics("single",3);
	this.instance_2.setTransform(0,125.8,0.31,0.31,0,0,0,0,0.1);

	this.instance_3 = new lib.container_pics("single",3);
	this.instance_3.setTransform(123.3,125.8,0.31,0.31,0,0,0,0.1,0.1);

	this.instance_4 = new lib.container_pics("single",3);
	this.instance_4.setTransform(246.6,125.8,0.31,0.31,0,0,0,0.1,0.1);

	this.instance_5 = new lib.container_pics("single",3);
	this.instance_5.setTransform(369.9,125.8,0.31,0.31,0,0,0,0.1,0.1);

	this.instance_6 = new lib.container_text("single",26);
	this.instance_6.setTransform(464,51);

	this.instance_7 = new lib.container_text("single",25);
	this.instance_7.setTransform(340.7,34,1,1,0,0,0,0.1,0);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(9,175,193,0.498)").s().p("AmzBvIAAgPINojOIAADdg");
	this.shape.setTransform(485.4,126.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,694,149.5);


(lib.popup04 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AALAyQgWAAAAgaIAAgqIgLAAIAAgLIALAAIAAgTIALAAIAAATIAXAAIAAALIgXAAIAAAqQAAAIACADQADAEAIAAIAKAAIAAALg");
	this.shape.setTransform(1421.4,214.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AAQApIAAgxQAAgLgEgEQgDgFgJAAQgGAAgEAFQgFADAAAMIAAAxIgMAAIAAhPIALAAIAAAKQAFgMAOABQANAAAGAHQAHAIgBANIAAA0g");
	this.shape_1.setTransform(1414.8,215);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgMAnQgFgDgFgFQgEgFgBgIQgCgIAAgKQAAgVAHgJQAJgKAOAAQAIAAAGACQAFADADAFQAEAFABAHQACAIAAAJIAAACIguAAIABAPQABAGACADQADADADABIAHABQAIAAAEgDQAEgDABgIIALAAQgBAMgGAGQgGAHgPAAQgGAAgHgCgAgFgcQgDABgDADIgDAGIgCALIAiAAQgBgHgBgEQgBgEgCgCQgCgDgDgBIgIAAIgFAAg");
	this.shape_2.setTransform(1407.1,215);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AALAyQgWAAAAgaIAAgqIgLAAIAAgLIALAAIAAgTIALAAIAAATIAXAAIAAALIgXAAIAAAqQAAAIACADQADAEAIAAIAKAAIAAALg");
	this.shape_3.setTransform(1400.6,214.1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgMAnQgFgCgDgDQgDgDgBgEIgCgKIALAAQABAIAEADQAEADAGAAQAIAAAEgDQADgDAAgGIgBgFQAAgBAAAAQAAgBgBAAQAAgBAAAAQgBAAAAgBIgEgCIgIgCIgGgCQgJgCgFgEQgGgFAAgKQAAgMAHgGQAIgFALAAQAMAAAHAFQAHAGAAAOIgLAAQgBgIgDgDQgEgDgHAAQgHAAgDADQgDADAAAGQAAAFADADQACACAIACIAGACQAMADAFAEQAEAFAAAKQAAAFgBAEQgCAEgDADQgDADgGABQgFACgHAAQgGAAgGgCg");
	this.shape_4.setTransform(1394.5,215);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AgFA5IAAhPIALAAIAABPgAgFgoIAAgQIALAAIAAAQg");
	this.shape_5.setTransform(1389.4,213.4);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgMAnQgFgCgDgDQgDgDgBgEIgCgKIALAAQABAIAEADQAEADAGAAQAIAAAEgDQADgDAAgGIgBgFQAAgBAAAAQAAgBgBAAQAAgBAAAAQgBAAAAgBIgEgCIgIgCIgGgCQgJgCgFgEQgGgFAAgKQAAgMAHgGQAIgFALAAQAMAAAHAFQAHAGAAAOIgLAAQgBgIgDgDQgEgDgHAAQgHAAgDADQgDADAAAGQAAAFADADQACACAIACIAGACQAMADAFAEQAEAFAAAKQAAAFgBAEQgCAEgDADQgDADgGABQgFACgHAAQgGAAgGgCg");
	this.shape_6.setTransform(1384.2,215);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AgMAnQgFgCgDgDQgDgDgBgEIgCgKIALAAQABAIAEADQAEADAGAAQAIAAAEgDQADgDAAgGIgBgFQAAgBAAAAQAAgBgBAAQAAgBAAAAQgBAAAAgBIgEgCIgIgCIgGgCQgJgCgFgEQgGgFAAgKQAAgMAHgGQAIgFALAAQAMAAAHAFQAHAGAAAOIgLAAQgBgIgDgDQgEgDgHAAQgHAAgDADQgDADAAAGQAAAFADADQACACAIACIAGACQAMADAFAEQAEAFAAAKQAAAFgBAEQgCAEgDADQgDADgGABQgFACgHAAQgGAAgGgCg");
	this.shape_7.setTransform(1377.4,215);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AgVAjQgGgFAAgKQAAgHACgEQADgEAEgDQAEgCAFgBIAMgEIAMgCIAAgFQAAgIgDgFQgDgEgJAAQgGAAgEADQgDAEAAAJIgMAAQABgNAGgHQAGgHAOAAQAHAAAFACQAFACADADQADAEABAFQACAFAAAGIAAA1IgNAAIAAgKQgCAEgFAEQgFADgGAAQgMAAgGgGgAAEADIgIACIgGAEQgCABgBADIgBAFQAAANAOAAQAGAAAEgFQAFgFAAgIIAAgLg");
	this.shape_8.setTransform(1370.1,215);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AgMAnQgFgDgFgFQgEgFgBgIQgCgIAAgKQAAgVAHgJQAIgKAPAAQAIAAAFACQAGADADAFQAEAFABAHQACAIAAAJIAAACIguAAIABAPQABAGACADQADADADABIAHABQAIAAAEgDQAEgDABgIIALAAQgBAMgGAGQgGAHgPAAQgGAAgHgCgAgFgcQgDABgCADIgEAGIgCALIAiAAQgBgHgBgEQgBgEgCgCQgCgDgDgBIgIAAIgFAAg");
	this.shape_9.setTransform(1363,215);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AALAyQgWAAAAgaIAAgqIgLAAIAAgLIALAAIAAgTIALAAIAAATIAXAAIAAALIgXAAIAAAqQAAAIACADQADAEAIAAIAKAAIAAALg");
	this.shape_10.setTransform(1356.5,214.1);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AgFA5IAAhxIALAAIAABxg");
	this.shape_11.setTransform(1352.1,213.4);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AgVAjQgGgFAAgKQAAgHACgEQADgEAEgDQAEgCAFgBIAMgEIAMgCIAAgFQAAgIgDgFQgDgEgJAAQgGAAgEADQgDAEAAAJIgMAAQABgNAGgHQAGgHAOAAQAHAAAFACQAFACADADQADAEABAFQACAFAAAGIAAA1IgNAAIAAgKQgCAEgFAEQgFADgGAAQgMAAgGgGgAAEADIgIACIgGAEQgCABgBADIgBAFQAAANAOAAQAGAAAEgFQAFgFAAgIIAAgLg");
	this.shape_12.setTransform(1346.6,215);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("AAQA5IAAgzQAAgJgEgEQgEgFgIAAQgHAAgDAFQgFADAAAJIAAA0IgMAAIAAhxIAMAAIAAArQADgFAFgDQAFgDAFABQANAAAHAHQAFAIAAALIAAA2g");
	this.shape_13.setTransform(1339.2,213.4);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AgRAoIAAg3QAAgLAHgHQAFgGALAAIAMAAIAAALIgMAAQgKAAAAAMIAAA4g");
	this.shape_14.setTransform(1333.1,215);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("AgVAhQgHgHAAgOIAAg0IANAAIAAAxQAAALAEAFQADAFAIgBQAIABAEgFQAEgFAAgLIAAgxIANAAIAABPIgNAAIAAgKQgCAFgFADQgFADgGABQgNAAgGgIg");
	this.shape_15.setTransform(1326.2,215.1);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("AgeA5IAAhwIAMAAIAAALQAGgMAMAAQAJAAAGACQAFADAFAFQADAFABAIQACAIAAAKQAAAUgHAKQgIAKgQAAQgMAAgFgKIAAAqgAgHgrQgEABgCAEQgCADgBAGQgCAGABAIIABAPIADAIQACADAEACQADABAEAAQAFAAAEgBQADgCADgDQACgEABgEIAAgPIAAgOQgBgGgCgDQgDgEgDgBIgJgBIgHABg");
	this.shape_16.setTransform(1318.4,216.6);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AgMAnQgFgCgDgDQgDgDgBgEIgCgKIALAAQABAIAEADQAEADAGAAQAIAAAEgDQADgDAAgGIgBgFQAAgBAAAAQAAgBgBAAQAAgBAAAAQgBAAAAgBIgEgCIgIgCIgGgCQgJgCgFgEQgGgFAAgKQAAgMAHgGQAIgFALAAQAMAAAHAFQAHAGAAAOIgLAAQgBgIgDgDQgEgDgHAAQgHAAgDADQgDADAAAGQAAAFADADQACACAIACIAGACQAMADAFAEQAEAFAAAKQAAAFgBAEQgCAEgDADQgDADgGABQgFACgHAAQgGAAgGgCg");
	this.shape_17.setTransform(1310.7,215);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#000000").s().p("AgnAFIAAgJIBPAAIAAAJg");
	this.shape_18.setTransform(1302.7,219.8);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#000000").s().p("AALA5IAAgbIgyAAIAAgJIAshNIASAAIAABLIARAAIAAALIgRAAIAAAbgAgZATIAkAAIAAg+g");
	this.shape_19.setTransform(1293.6,213.4);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#000000").s().p("AgQA4QgHgDgFgHQgEgHgCgMQgCgLAAgQQAAgPACgLQABgLAFgHQAEgHAHgDQAIgDAJgBQAKABAIADQAHADAEAHQAFAHABALQACALAAAPQAAAQgCALQgCALgEAIQgFAHgHADQgHACgKAAQgJAAgHgCgAgKgrQgFACgDAFQgCAFgBAKQgCAIAAANIABAWQABAKADAGQADAFAEADQAFACAGAAQAHAAAFgCQAEgDADgFQADgGABgKIABgWIgBgVQgCgKgCgFQgDgFgFgCQgEgCgHAAQgGAAgEACg");
	this.shape_20.setTransform(1284.6,213.4);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#000000").s().p("AgeA5IAAhwIAMAAIAAALQAGgMANAAQAIAAAGACQAFADAEAFQAEAFACAIQABAIAAAKQAAAUgHAKQgIAKgQAAQgLAAgHgKIAAAqgAgHgrQgDABgDAEQgCADgBAGQgCAGAAAIIABAPIAEAIQACADAEACQADABAEAAQAFAAAEgBQADgCACgDQACgEACgEIABgPIgBgOQgCgGgCgDQgCgEgDgBIgJgBIgHABg");
	this.shape_21.setTransform(1276.3,216.6);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#000000").s().p("AgVAhQgHgHAAgOIAAg0IANAAIAAAxQAAALAEAFQADAFAIgBQAIABAEgFQAEgFAAgLIAAgxIANAAIAABPIgNAAIAAgKQgCAFgFADQgFADgGABQgNAAgGgIg");
	this.shape_22.setTransform(1268,215.1);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#000000").s().p("AgeA5IAAhwIAMAAIAAALQAGgMANAAQAIAAAGACQAFADAEAFQAEAFACAIQABAIAAAKQAAAUgHAKQgIAKgQAAQgMAAgFgKIAAAqgAgHgrQgDABgDAEQgCADgBAGQgBAGAAAIIABAPIADAIQACADAEACQADABAEAAQAFAAAEgBQADgCACgDQACgEACgEIABgPIgBgOQgCgGgCgDQgCgEgDgBIgJgBIgHABg");
	this.shape_23.setTransform(1260.2,216.6);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#000000").s().p("AgNAnQgGgDgEgFQgEgFgBgIQgCgIAAgKQAAgJACgIQABgIAEgFQAEgFAGgDQAGgCAHAAQAIAAAGACQAGADAEAFQAEAFACAIQABAIAAAJQAAAVgHAKQgIAKgQAAQgHAAgGgCgAgHgbQgEABgCAEQgCADgBAGIgBANIABAOQABAGACAEQACADAEACQADABAEAAQAFAAADgBQAEgCACgDQACgEABgGIABgOIgBgNQgBgGgCgDQgCgEgEgBIgIgBIgHABg");
	this.shape_24.setTransform(1252,215);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#000000").s().p("AgeA5IAAhwIAMAAIAAALQAGgMAMAAQAJAAAGACQAFADAFAFQADAFABAIQACAIAAAKQAAAUgHAKQgHAKgRAAQgMAAgFgKIAAAqgAgHgrQgEABgCAEQgCADgBAGQgCAGABAIIAAAPIAEAIQACADAEACQAEABADAAQAFAAAEgBQADgCADgDQACgEAAgEIABgPIgBgOQAAgGgCgDQgDgEgDgBIgJgBIgHABg");
	this.shape_25.setTransform(1244.3,216.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(10));

	// Ebene 4
	this.instance = new lib.container_text("single",39);
	this.instance.setTransform(645,278.8,1,1,0,0,0,585,188.8);

	this.instance_1 = new lib.container_text("single",40);
	this.instance_1.setTransform(800,146);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_1},{t:this.instance}]},4).wait(6));

	// Ebene 2
	this.closeBtn = new lib.btn_close02();
	this.closeBtn.setTransform(1162,58.2,1,1,0,0,0,12,11.8);
	this.closeBtn._off = true;

	this.timeline.addTween(cjs.Tween.get(this.closeBtn).wait(4).to({_off:false},0).wait(6));

	// scrollerWidget_1
	this.instance_2 = new lib.container_pics("single",1);
	this.instance_2.setTransform(669,497.3,1,1,0,0,0,609,351.3);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(4).to({_off:false},0).wait(6));

	// scrollerWidget_1
	this.instance_3 = new lib.pic_plane_white();
	this.instance_3.setTransform(609,336,0.993,1.132,0,0,0,579,265);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(4).to({_off:false},0).wait(6));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(1238,200.7,232,27.4);


(lib.popup03 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AALAyQgWAAAAgZIAAgrIgLAAIAAgLIALAAIAAgUIALAAIAAAUIAXAAIAAALIgXAAIAAAqQAAAJACACQADAEAIAAIAKAAIAAALg");
	this.shape.setTransform(1389.4,184.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AAQApIAAgxQAAgLgEgFQgDgDgJAAQgHAAgEADQgEAFAAALIAAAxIgNAAIAAhPIAMAAIAAALQAGgNANAAQANAAAGAIQAGAHABAOIAAA0g");
	this.shape_1.setTransform(1382.8,185);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgLAnQgHgDgDgFQgFgFgBgIQgCgIAAgKQAAgVAIgJQAHgKAPAAQAIAAAFACQAGADADAFQAEAFABAHQACAIAAAJIAAACIguAAIABAPQABAGADADQABADAEABIAHABQAIAAAEgDQAEgDABgIIAMAAQgBAMgHAGQgGAHgPAAQgHAAgFgCgAgFgcQgDABgDADIgDAGIgCALIAhAAQAAgHgBgEQgBgEgCgCQgCgDgDgBIgIAAIgFAAg");
	this.shape_2.setTransform(1375.1,185);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AALAyQgWAAAAgZIAAgrIgLAAIAAgLIALAAIAAgUIALAAIAAAUIAXAAIAAALIgXAAIAAAqQAAAJACACQADAEAIAAIAKAAIAAALg");
	this.shape_3.setTransform(1368.6,184.1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgMAnQgFgCgDgDQgDgDgBgEIgCgKIALAAQABAIAEADQAEADAGAAQAIAAAEgDQADgDAAgGIgBgFQAAgBAAAAQAAgBgBAAQAAgBAAAAQgBAAAAgBIgEgCIgIgCIgGgCQgJgCgFgEQgGgFAAgKQAAgMAHgGQAIgFALAAQAMAAAHAFQAHAGAAAOIgLAAQgBgIgDgDQgEgDgHAAQgHAAgDADQgDADAAAGQAAAFADADQACACAIACIAGACQAMADAFAEQAEAFAAAKQAAAFgBAEQgCAEgDADQgDADgGABQgFACgHAAQgGAAgGgCg");
	this.shape_4.setTransform(1362.5,185);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AgFA5IAAhPIALAAIAABPgAgFgoIAAgPIALAAIAAAPg");
	this.shape_5.setTransform(1357.4,183.4);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgMAnQgFgCgDgDQgDgDgBgEIgCgKIALAAQABAIAEADQAEADAGAAQAIAAAEgDQADgDAAgGIgBgFQAAgBAAAAQAAgBgBAAQAAgBAAAAQgBAAAAgBIgEgCIgIgCIgGgCQgJgCgFgEQgGgFAAgKQAAgMAHgGQAIgFALAAQAMAAAHAFQAHAGAAAOIgLAAQgBgIgDgDQgEgDgHAAQgHAAgDADQgDADAAAGQAAAFADADQACACAIACIAGACQAMADAFAEQAEAFAAAKQAAAFgBAEQgCAEgDADQgDADgGABQgFACgHAAQgGAAgGgCg");
	this.shape_6.setTransform(1352.2,185);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AgMAnQgFgCgDgDQgDgDgBgEIgCgKIALAAQABAIAEADQAEADAGAAQAIAAAEgDQADgDAAgGIgBgFQAAgBAAAAQAAgBgBAAQAAgBAAAAQgBAAAAgBIgEgCIgIgCIgGgCQgJgCgFgEQgGgFAAgKQAAgMAHgGQAIgFALAAQAMAAAHAFQAHAGAAAOIgLAAQgBgIgDgDQgEgDgHAAQgHAAgDADQgDADAAAGQAAAFADADQACACAIACIAGACQAMADAFAEQAEAFAAAKQAAAFgBAEQgCAEgDADQgDADgGABQgFACgHAAQgGAAgGgCg");
	this.shape_7.setTransform(1345.4,185);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AgVAjQgGgFAAgKQAAgHACgEQADgEAEgDQAEgCAFgBIAMgEIAMgCIAAgFQAAgIgDgFQgDgEgJAAQgGAAgEADQgDAEAAAJIgMAAQABgNAGgHQAGgHAOAAQAHAAAFACQAFACADADQADAEABAFQACAFAAAGIAAA1IgNAAIAAgKQgCAEgFAEQgFADgGAAQgMAAgGgGgAAEADIgIACIgGAEQgCABgBADIgBAFQAAANAOAAQAGAAAEgFQAFgFAAgIIAAgLg");
	this.shape_8.setTransform(1338.1,185);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AgVAhQgHgIAAgNIAAg0IANAAIAAAxQAAALAEAFQADAEAIAAQAIAAAEgEQAEgEAAgMIAAgxIANAAIAABPIgNAAIAAgKQgCAGgFADQgFACgGAAQgNAAgGgHg");
	this.shape_9.setTransform(1330.7,185.1);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AgVAjQgGgFAAgKQAAgHACgEQADgEAEgDQAEgCAFgBIAMgEIAMgCIAAgFQAAgIgDgFQgDgEgJAAQgGAAgEADQgDAEAAAJIgMAAQABgNAGgHQAGgHAOAAQAHAAAFACQAFACADADQADAEABAFQACAFAAAGIAAA1IgNAAIAAgKQgCAEgFAEQgFADgGAAQgMAAgGgGgAAEADIgIACIgGAEQgCABgBADIgBAFQAAANAOAAQAGAAAEgFQAFgFAAgIIAAgLg");
	this.shape_10.setTransform(1322.9,185);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AALAyQgWAAAAgZIAAgrIgLAAIAAgLIALAAIAAgUIALAAIAAAUIAXAAIAAALIgXAAIAAAqQAAAJACACQADAEAIAAIAKAAIAAALg");
	this.shape_11.setTransform(1316.8,184.1);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AgMAnQgFgCgDgDQgDgDgBgEIgCgKIALAAQABAIAEADQAEADAGAAQAIAAAEgDQADgDAAgGIgBgFQAAgBAAAAQAAgBgBAAQAAgBAAAAQgBAAAAgBIgEgCIgIgCIgGgCQgJgCgFgEQgGgFAAgKQAAgMAHgGQAIgFALAAQAMAAAHAFQAHAGAAAOIgLAAQgBgIgDgDQgEgDgHAAQgHAAgDADQgDADAAAGQAAAFADADQACACAIACIAGACQAMADAFAEQAEAFAAAKQAAAFgBAEQgCAEgDADQgDADgGABQgFACgHAAQgGAAgGgCg");
	this.shape_12.setTransform(1310.7,185);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("AgnAFIAAgJIBPAAIAAAJg");
	this.shape_13.setTransform(1302.7,189.8);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AgZAyQgKgJAAgTIAMAAQABAOAGAGQAFAGALAAQAMAAAGgFQAFgFAAgMQABgLgGgFQgGgGgMABIgKAAIAAgKIAKAAQALAAAFgFQAFgGAAgJQAAgLgGgEQgGgFgJAAQgKAAgGAGQgGAFgBAPIgMAAQAAgJADgHQABgHAFgFQAEgFAHgCQAGgDAJAAQARgBAJAJQAIAJAAAPQAAAHgEAIQgDAGgIADQAIABAFAHQAEAGABANQgBAPgIAJQgKAJgSAAQgRgBgIgIg");
	this.shape_14.setTransform(1293.6,183.4);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("AgQA3QgHgCgFgIQgEgGgCgMQgCgMAAgPQAAgPACgLQABgLAFgHQAEgHAHgDQAIgEAJABQAKgBAIAEQAHADAEAHQAFAHABALQACALAAAPQAAAPgCAMQgCAMgEAGQgFAIgHACQgHAEgKAAQgJAAgHgEgAgKgrQgFACgDAFQgCAFgBAKQgCAIAAANIABAXQABAJADAFQADAGAEACQAFADAGAAQAHAAAFgDQAEgCADgGQADgFABgJIABgXIgBgVQgCgKgCgFQgDgFgFgCQgEgCgHAAQgGAAgEACg");
	this.shape_15.setTransform(1284.6,183.4);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("AgeA5IAAhwIAMAAIAAALQAGgMANAAQAIAAAGACQAFADAEAFQAEAFACAIQABAIAAAKQAAAUgHAKQgIAKgQAAQgLAAgHgKIAAAqgAgHgrQgDABgDAEQgCADgBAGQgCAGAAAIIABAPIAEAIQACADAEACQADABAEAAQAFAAAEgBQADgCACgDQACgEACgEIABgPIgBgOQgCgGgCgDQgCgEgDgBIgJgBIgHABg");
	this.shape_16.setTransform(1276.3,186.6);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AgVAhQgHgIAAgNIAAg0IANAAIAAAxQAAALAEAFQADAEAIAAQAIAAAEgEQAEgEAAgMIAAgxIANAAIAABPIgNAAIAAgKQgCAGgFADQgFACgGAAQgNAAgGgHg");
	this.shape_17.setTransform(1268,185.1);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#000000").s().p("AgeA5IAAhwIAMAAIAAALQAGgMANAAQAIAAAGACQAFADAEAFQAEAFACAIQABAIAAAKQAAAUgHAKQgIAKgQAAQgMAAgFgKIAAAqgAgHgrQgDABgDAEQgCADgBAGQgBAGAAAIIABAPIADAIQACADAEACQADABAEAAQAFAAAEgBQADgCACgDQACgEACgEIABgPIgBgOQgCgGgCgDQgCgEgDgBIgJgBIgHABg");
	this.shape_18.setTransform(1260.2,186.6);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#000000").s().p("AgNAnQgGgDgEgFQgEgFgBgIQgCgIAAgKQAAgJACgIQABgIAEgFQAEgFAGgDQAGgCAHAAQAIAAAGACQAGADAEAFQAEAFACAIQABAIAAAJQAAAVgHAKQgIAKgQAAQgHAAgGgCgAgHgbQgEABgCAEQgCADgBAGIgBANIABAOQABAGACAEQACADAEACQADABAEAAQAFAAADgBQAEgCACgDQACgEABgGIABgOIgBgNQgBgGgCgDQgCgEgEgBIgIgBIgHABg");
	this.shape_19.setTransform(1252,185);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#000000").s().p("AgeA5IAAhwIAMAAIAAALQAGgMAMAAQAJAAAGACQAFADAFAFQADAFABAIQACAIAAAKQAAAUgHAKQgHAKgRAAQgMAAgFgKIAAAqgAgHgrQgEABgCAEQgCADgBAGQgCAGABAIIAAAPIAEAIQACADAEACQAEABADAAQAFAAAEgBQADgCADgDQACgEAAgEIABgPIgBgOQAAgGgCgDQgDgEgDgBIgJgBIgHABg");
	this.shape_20.setTransform(1244.3,186.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(121));

	// Ebene 4
	this.instance = new lib.container_text("single",29);
	this.instance.setTransform(645,278.8,1,1,0,0,0,585,188.8);

	this.instance_1 = new lib.container_text("single",30);
	this.instance_1.setTransform(800,146);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_1},{t:this.instance}]},4).wait(117));

	// Ebene 2
	this.closeBtn = new lib.btn_close02();
	this.closeBtn.setTransform(1162,58.2,1,1,0,0,0,12,11.8);
	this.closeBtn._off = true;

	this.timeline.addTween(cjs.Tween.get(this.closeBtn).wait(4).to({_off:false},0).wait(117));

	// scrollerWidget_1
	this.instance_2 = new lib.ani_warningSystem03("synched",19,false);
	this.instance_2.setTransform(272.3,406.7,0.599,0.599,0,0,0,354.3,435.1);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(4).to({_off:false},0).wait(116).to({regX:0.1,regY:0.1,x:59.9,y:146,mode:"independent"},0).wait(1));

	// scrollerWidget_1
	this.instance_3 = new lib.pic_plane_white();
	this.instance_3.setTransform(609,336,0.993,1.132,0,0,0,579,265);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(4).to({_off:false},0).wait(117));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(1238,170.7,232,27.4);


(lib.ani_warningSystem02 = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{"step1":9});

	// timeline functions:
	this.frame_3 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(3).call(this.frame_3).wait(279));

	// Ebene 16 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Eg5FAg9MAAAhB5MByKAAAMAAABB5g");
	mask.setTransform(365.4,210.9);

	// Ebene 14
	this.button_gotoAndPlay_parent_step1 = new lib.button_play();
	this.button_gotoAndPlay_parent_step1.setTransform(697.6,263.7,0.6,0.6,0,0,0,31.8,31.8);

	this.button_gotoAndPlay_parent_step1_1 = new lib.button_play_dark();
	this.button_gotoAndPlay_parent_step1_1.setTransform(697.6,263.7,0.6,0.6,0,0,0,31.8,31.8);

	this.button_gotoAndPlay_parent_step1.mask = this.button_gotoAndPlay_parent_step1_1.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.button_gotoAndPlay_parent_step1,p:{x:697.6}}]},3).to({state:[{t:this.button_gotoAndPlay_parent_step1,p:{x:799}}]},6).to({state:[{t:this.button_gotoAndPlay_parent_step1_1}]},272).wait(1));

	// popup_10
	this.instance = new lib.container_text("single",26);
	this.instance.setTransform(457.6,225.9);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(245).to({_off:false},0).wait(37));

	// mask
	this.instance_1 = new lib.container_text("single",25);
	this.instance_1.setTransform(334.2,208.9,1,1,0,0,0,0.1,0);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(196).to({_off:false},0).wait(86));

	// popup_10
	this.instance_2 = new lib.container_pics("single",13);
	this.instance_2.setTransform(834,444.7,0.6,0.6,0,0,0,640.9,139.1);

	this.instance_3 = new lib.container_text("single",24);
	this.instance_3.setTransform(210.3,191.9,1,1,0,0,0,0,0.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_3},{t:this.instance_2}]},145).wait(137));

	// Ebene 9
	this.instance_4 = new lib.container_text("single",23);
	this.instance_4.setTransform(87.3,174.9);
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(83).to({_off:false},0).wait(199));

	// mask (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("Egs5AOfIAA8+MBZyAAAIAAc+g");
	mask_1.setTransform(304,215.3);

	// Ebene 3
	this.instance_5 = new lib.warningSystem02_startpic01("single",0);
	this.instance_5.setTransform(253,279.1,1,1,0,0,0,197.8,93.2);
	this.instance_5._off = true;

	this.instance_6 = new lib.ani_linesFlag("synched",0,false);
	this.instance_6.setTransform(425.5,371.5,0.6,0.6,-90,0,0,-0.1,0);

	this.instance_5.mask = this.instance_6.mask = mask_1;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_5}]},9).to({state:[{t:this.instance_5}]},10).to({state:[]},1).to({state:[{t:this.instance_6}]},204).wait(58));
	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(9).to({_off:false},0).to({alpha:0},10).to({_off:true},1).wait(262));

	// Ebene 8
	this.instance_7 = new lib.ani_linesFlag("synched",0,false);
	this.instance_7.setTransform(302.1,354.5,0.6,0.6,-90,0,0,-0.1,0.1);
	this.instance_7._off = true;

	this.instance_7.mask = mask_1;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(175).to({_off:false},0).wait(107));

	// Ebene 6
	this.instance_8 = new lib.ani_linesFlag("synched",0,false);
	this.instance_8.setTransform(178.1,337.5,0.6,0.6,-90);
	this.instance_8._off = true;

	this.instance_8.mask = mask_1;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(124).to({_off:false},0).wait(158));

	// Ebene 2
	this.instance_9 = new lib.ani_linesFlag("synched",0,false);
	this.instance_9.setTransform(55.2,320.5,0.6,0.6,-90,0,0,-0.1,0.1);
	this.instance_9._off = true;

	this.instance_9.mask = mask_1;

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(62).to({_off:false},0).wait(220));

	// Ebene 5
	this.instance_10 = new lib.warningSystem02_startpic02("single",0);
	this.instance_10.setTransform(340.6,249.6,1,1,0,0,0,347,74.7);
	this.instance_10._off = true;

	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(9,175,193,0.498)").s().p("AgJAIIAAgOIATAAIAAAOg");
	this.shape.setTransform(64.4,312.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(9,175,193,0.498)").s().p("AjdARIAAgQIG7gRIAAAhg");
	this.shape_1.setTransform(85.7,311.2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("rgba(9,175,193,0.498)").s().p("AmnAaIAAgPINPgkIAAAzg");
	this.shape_2.setTransform(105.9,310.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("rgba(9,175,193,0.498)").s().p("ApnAjIAAgQITPg1IAABFg");
	this.shape_3.setTransform(125.1,309.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("rgba(9,175,193,0.498)").s().p("AsdArIAAgPIY7hGIAABVg");
	this.shape_4.setTransform(143.2,308.5);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("rgba(9,175,193,0.498)").s().p("AvIAzIAAgQIeRhVIAABlg");
	this.shape_5.setTransform(160.3,307.8);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("rgba(9,175,193,0.498)").s().p("AxoA6IAAgPMAjRgBkIAABzg");
	this.shape_6.setTransform(176.4,307);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("rgba(9,175,193,0.498)").s().p("Az/BBIAAgQMAn/gBxIAACBg");
	this.shape_7.setTransform(191.4,306.4);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("rgba(9,175,193,0.498)").s().p("A2LBHIAAgPMAsWgB+IAACNg");
	this.shape_8.setTransform(205.4,305.7);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("rgba(9,175,193,0.498)").s().p("A4MBNIAAgPMAwZgCKIAACZg");
	this.shape_9.setTransform(218.4,305.1);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("rgba(9,175,193,0.498)").s().p("A6EBTIAAgQMA0IgCVIAAClg");
	this.shape_10.setTransform(230.3,304.6);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("rgba(9,175,193,0.498)").s().p("A7wBYIAAgQMA3hgCfIAACvg");
	this.shape_11.setTransform(241.2,304.1);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("rgba(9,175,193,0.498)").s().p("A9TBcIAAgQMA6ngCnIAAC3g");
	this.shape_12.setTransform(251,303.7);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("rgba(9,175,193,0.498)").s().p("A+rBgIAAgQMA9XgCvIAAC/g");
	this.shape_13.setTransform(259.9,303.3);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("rgba(9,175,193,0.498)").s().p("A/5BkIAAgQMA/zgC3IAADHg");
	this.shape_14.setTransform(267.6,302.9);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("rgba(9,175,193,0.498)").s().p("Egg8ABnIAAgQMBB5gC8IAADMg");
	this.shape_15.setTransform(274.4,302.6);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("rgba(9,175,193,0.498)").s().p("Egh1ABpIAAgPMBDrgDCIAADRg");
	this.shape_16.setTransform(280.1,302.3);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("rgba(9,175,193,0.498)").s().p("EgikABrIAAgPMBFJgDGIAADVg");
	this.shape_17.setTransform(284.7,302.1);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("rgba(9,175,193,0.498)").s().p("EgjIABtIAAgQMBGRgDJIAADZg");
	this.shape_18.setTransform(288.4,302);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("rgba(9,175,193,0.498)").s().p("EgjiABuIAAgQMBHFgDLIAADbg");
	this.shape_19.setTransform(291,301.9);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("rgba(9,175,193,0.498)").s().p("EgjyABvIAAgQMBHlgDNIAADdg");
	this.shape_20.setTransform(292.5,301.8);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("rgba(9,175,193,0.498)").s().p("Egj3ABvIAAgQMBHvgDNIAADdg");
	this.shape_21.setTransform(293,301.8);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("rgba(9,175,193,0.498)").s().p("EgjCABvIAAgQMBGFgDNIAADdg");
	this.shape_22.setTransform(298.3,301.8);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("rgba(9,175,193,0.498)").s().p("EgiQABvIAAgQMBEhgDNIAADdg");
	this.shape_23.setTransform(303.3,301.8);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("rgba(9,175,193,0.498)").s().p("EghfABvIAAgQMBC/gDNIAADdg");
	this.shape_24.setTransform(308.2,301.8);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("rgba(9,175,193,0.498)").s().p("EggyABvIAAgQMBBlgDNIAADdg");
	this.shape_25.setTransform(312.7,301.8);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("rgba(9,175,193,0.498)").s().p("EggHABvIAAgQMBAOgDNIAADdg");
	this.shape_26.setTransform(317.1,301.8);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("rgba(9,175,193,0.498)").s().p("A/eBvIAAgQMA+8gDNIAADdg");
	this.shape_27.setTransform(321.2,301.8);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("rgba(9,175,193,0.498)").s().p("A+3BvIAAgQMA9vgDNIAADdg");
	this.shape_28.setTransform(325,301.8);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("rgba(9,175,193,0.498)").s().p("A+TBvIAAgQMA8mgDNIAADdg");
	this.shape_29.setTransform(328.7,301.8);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("rgba(9,175,193,0.498)").s().p("A9wBvIAAgQMA7hgDNIAADdg");
	this.shape_30.setTransform(332.1,301.8);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("rgba(9,175,193,0.498)").s().p("A9RBvIAAgQMA6jgDNIAADdg");
	this.shape_31.setTransform(335.2,301.8);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("rgba(9,175,193,0.498)").s().p("A80BvIAAgQMA5pgDNIAADdg");
	this.shape_32.setTransform(338.1,301.8);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("rgba(9,175,193,0.498)").s().p("A8ZBvIAAgQMA4zgDNIAADdg");
	this.shape_33.setTransform(340.8,301.8);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("rgba(9,175,193,0.498)").s().p("A8ABvIAAgQMA4BgDNIAADdg");
	this.shape_34.setTransform(343.3,301.8);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("rgba(9,175,193,0.498)").s().p("A7qBvIAAgQMA3VgDNIAADdg");
	this.shape_35.setTransform(345.5,301.8);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("rgba(9,175,193,0.498)").s().p("A7WBvIAAgQMA2tgDNIAADdg");
	this.shape_36.setTransform(347.5,301.8);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("rgba(9,175,193,0.498)").s().p("A7EBvIAAgQMA2JgDNIAADdg");
	this.shape_37.setTransform(349.3,301.8);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("rgba(9,175,193,0.498)").s().p("A61BvIAAgQMA1rgDNIAADdg");
	this.shape_38.setTransform(350.8,301.8);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("rgba(9,175,193,0.498)").s().p("A6oBvIAAgQMA1RgDNIAADdg");
	this.shape_39.setTransform(352.1,301.8);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("rgba(9,175,193,0.498)").s().p("A6eBvIAAgQMA09gDNIAADdg");
	this.shape_40.setTransform(353.1,301.8);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("rgba(9,175,193,0.498)").s().p("A6WBvIAAgQMA0sgDNIAADdg");
	this.shape_41.setTransform(354,301.8);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("rgba(9,175,193,0.498)").s().p("A6QBvIAAgQMA0hgDNIAADdg");
	this.shape_42.setTransform(354.5,301.8);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("rgba(9,175,193,0.498)").s().p("A6MBvIAAgQMA0ZgDNIAADdg");
	this.shape_43.setTransform(354.9,301.8);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("rgba(9,175,193,0.498)").s().p("A6LBvIAAgQMA0XgDNIAADdg");
	this.shape_44.setTransform(355,301.8);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("rgba(9,175,193,0.498)").s().p("A5SBvIAAgQMAykgDNIAADdg");
	this.shape_45.setTransform(360.8,301.8);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("rgba(9,175,193,0.498)").s().p("A4aBvIAAgQMAw1gDNIAADdg");
	this.shape_46.setTransform(366.3,301.8);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("rgba(9,175,193,0.498)").s().p("A3nBvIAAgQMAvOgDNIAADdg");
	this.shape_47.setTransform(371.5,301.8);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("rgba(9,175,193,0.498)").s().p("A22BvIAAgQMAtsgDNIAADdg");
	this.shape_48.setTransform(376.4,301.8);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("rgba(9,175,193,0.498)").s().p("A2HBvIAAgQMAsPgDNIAADdg");
	this.shape_49.setTransform(381,301.8);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("rgba(9,175,193,0.498)").s().p("A1cBvIAAgQMAq4gDNIAADdg");
	this.shape_50.setTransform(385.4,301.8);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("rgba(9,175,193,0.498)").s().p("A0zBvIAAgQMApngDNIAADdg");
	this.shape_51.setTransform(389.4,301.8);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("rgba(9,175,193,0.498)").s().p("A0NBvIAAgQMAobgDNIAADdg");
	this.shape_52.setTransform(393.2,301.8);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("rgba(9,175,193,0.498)").s().p("AzqBvIAAgQMAnUgDNIAADdg");
	this.shape_53.setTransform(396.8,301.8);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("rgba(9,175,193,0.498)").s().p("AzJBvIAAgQMAmTgDNIAADdg");
	this.shape_54.setTransform(400,301.8);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("rgba(9,175,193,0.498)").s().p("AysBvIAAgQMAlZgDNIAADdg");
	this.shape_55.setTransform(402.9,301.8);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("rgba(9,175,193,0.498)").s().p("AyRBvIAAgQMAkjgDNIAADdg");
	this.shape_56.setTransform(405.6,301.8);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("rgba(9,175,193,0.498)").s().p("Ax5BvIAAgQMAjzgDNIAADdg");
	this.shape_57.setTransform(408,301.8);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("rgba(9,175,193,0.498)").s().p("AxkBvIAAgQMAjJgDNIAADdg");
	this.shape_58.setTransform(410.1,301.8);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("rgba(9,175,193,0.498)").s().p("AxSBvIAAgQMAilgDNIAADdg");
	this.shape_59.setTransform(411.9,301.8);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("rgba(9,175,193,0.498)").s().p("AxCBvIAAgQMAiFgDNIAADdg");
	this.shape_60.setTransform(413.5,301.8);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("rgba(9,175,193,0.498)").s().p("Aw2BvIAAgQMAhtgDNIAADdg");
	this.shape_61.setTransform(414.7,301.8);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("rgba(9,175,193,0.498)").s().p("AwsBvIAAgQMAhZgDNIAADdg");
	this.shape_62.setTransform(415.7,301.8);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("rgba(9,175,193,0.498)").s().p("AwlBvIAAgQMAhLgDNIAADdg");
	this.shape_63.setTransform(416.4,301.8);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("rgba(9,175,193,0.498)").s().p("AwhBvIAAgQMAhDgDNIAADdg");
	this.shape_64.setTransform(416.8,301.8);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("rgba(9,175,193,0.498)").s().p("AwfBvIAAgQMAg/gDNIAADdg");
	this.shape_65.setTransform(417,301.8);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("rgba(9,175,193,0.498)").s().p("AvcBvIAAgQIe5jNIAADdg");
	this.shape_66.setTransform(423.7,301.8);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("rgba(9,175,193,0.498)").s().p("AudBvIAAgQIc7jNIAADdg");
	this.shape_67.setTransform(430,301.8);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("rgba(9,175,193,0.498)").s().p("AtiBvIAAgQIbFjNIAADdg");
	this.shape_68.setTransform(435.9,301.8);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("rgba(9,175,193,0.498)").s().p("AsqBvIAAgQIZVjNIAADdg");
	this.shape_69.setTransform(441.5,301.8);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("rgba(9,175,193,0.498)").s().p("Ar3BvIAAgQIXvjNIAADdg");
	this.shape_70.setTransform(446.6,301.8);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("rgba(9,175,193,0.498)").s().p("ArHBvIAAgQIWPjNIAADdg");
	this.shape_71.setTransform(451.4,301.8);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("rgba(9,175,193,0.498)").s().p("AqbBvIAAgQIU3jNIAADdg");
	this.shape_72.setTransform(455.8,301.8);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("rgba(9,175,193,0.498)").s().p("ApzBvIAAgQITnjNIAADdg");
	this.shape_73.setTransform(459.8,301.8);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("rgba(9,175,193,0.498)").s().p("ApOBvIAAgQISdjNIAADdg");
	this.shape_74.setTransform(463.5,301.8);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("rgba(9,175,193,0.498)").s().p("AouBvIAAgQIRdjNIAADdg");
	this.shape_75.setTransform(466.7,301.8);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("rgba(9,175,193,0.498)").s().p("AoRBvIAAgQIQjjNIAADdg");
	this.shape_76.setTransform(469.6,301.8);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("rgba(9,175,193,0.498)").s().p("An4BvIAAgQIPxjNIAADdg");
	this.shape_77.setTransform(472.1,301.8);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("rgba(9,175,193,0.498)").s().p("AnjBvIAAgQIPHjNIAADdg");
	this.shape_78.setTransform(474.2,301.8);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("rgba(9,175,193,0.498)").s().p("AnSBvIAAgQIOljNIAADdg");
	this.shape_79.setTransform(475.9,301.8);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("rgba(9,175,193,0.498)").s().p("AnFBvIAAgQIOLjNIAADdg");
	this.shape_80.setTransform(477.2,301.8);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("rgba(9,175,193,0.498)").s().p("Am7BvIAAgQIN3jNIAADdg");
	this.shape_81.setTransform(478.2,301.8);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("rgba(9,175,193,0.498)").s().p("Am1BvIAAgQINrjNIAADdg");
	this.shape_82.setTransform(478.8,301.8);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("rgba(9,175,193,0.498)").s().p("Am0BvIAAgQINojNIAADdg");
	this.shape_83.setTransform(479,301.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_10}]},9).to({state:[{t:this.instance_10}]},10).to({state:[]},1).to({state:[{t:this.shape}]},9).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_21}]},47).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_35}]},1).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_37}]},1).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_42}]},1).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_44}]},1).to({state:[{t:this.shape_44}]},31).to({state:[{t:this.shape_45}]},1).to({state:[{t:this.shape_46}]},1).to({state:[{t:this.shape_47}]},1).to({state:[{t:this.shape_48}]},1).to({state:[{t:this.shape_49}]},1).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_52}]},1).to({state:[{t:this.shape_53}]},1).to({state:[{t:this.shape_54}]},1).to({state:[{t:this.shape_55}]},1).to({state:[{t:this.shape_56}]},1).to({state:[{t:this.shape_57}]},1).to({state:[{t:this.shape_58}]},1).to({state:[{t:this.shape_59}]},1).to({state:[{t:this.shape_60}]},1).to({state:[{t:this.shape_61}]},1).to({state:[{t:this.shape_62}]},1).to({state:[{t:this.shape_63}]},1).to({state:[{t:this.shape_64}]},1).to({state:[{t:this.shape_65}]},1).to({state:[{t:this.shape_65}]},30).to({state:[{t:this.shape_66}]},1).to({state:[{t:this.shape_67}]},1).to({state:[{t:this.shape_68}]},1).to({state:[{t:this.shape_69}]},1).to({state:[{t:this.shape_70}]},1).to({state:[{t:this.shape_71}]},1).to({state:[{t:this.shape_72}]},1).to({state:[{t:this.shape_73}]},1).to({state:[{t:this.shape_74}]},1).to({state:[{t:this.shape_75}]},1).to({state:[{t:this.shape_76}]},1).to({state:[{t:this.shape_77}]},1).to({state:[{t:this.shape_78}]},1).to({state:[{t:this.shape_79}]},1).to({state:[{t:this.shape_80}]},1).to({state:[{t:this.shape_81}]},1).to({state:[{t:this.shape_82}]},1).to({state:[{t:this.shape_83}]},1).wait(62));
	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(9).to({_off:false},0).to({alpha:0},10).to({_off:true},1).wait(262));

	// mask (mask)
	var mask_4 = new cjs.Shape();
	mask_4._off = true;
	mask_4.graphics.p("Eg5FAg9MAAAhB5MByKAAAMAAABB5g");
	mask_4.setTransform(365.4,210.9);

	// Ebene 11
	this.instance_11 = new lib.container_pics("single",3);
	this.instance_11.setTransform(-83.8,300.7,0.31,0.31,0,0,0,0,0.1);
	this.instance_11._off = true;

	this.instance_11.mask = mask_4;

	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(19).to({_off:false},0).to({x:-6.4},10,cjs.Ease.get(1)).wait(253));

	// Ebene 13
	this.instance_12 = new lib.container_pics("single",3);
	this.instance_12.setTransform(-6.4,300.7,0.31,0.31,0,0,0,0.1,0.1);
	this.instance_12._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(97).to({_off:false},0).to({x:116.9},23,cjs.Ease.get(1)).wait(162));

	// Ebene 15
	this.instance_13 = new lib.container_pics("single",3);
	this.instance_13.setTransform(116.9,300.7,0.31,0.31,0,0,0,0.3,0.1);
	this.instance_13._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_13).wait(151).to({_off:false},0).to({regX:0.1,x:240.2},21,cjs.Ease.get(1)).wait(110));

	// Ebene 17
	this.instance_14 = new lib.container_pics("single",3);
	this.instance_14.setTransform(240.2,300.7,0.31,0.31,0,0,0,0.1,0.1);
	this.instance_14._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_14).wait(202).to({_off:false},0).to({x:363.4},18,cjs.Ease.get(1)).wait(62));

	// Ebene 18
	this.instance_15 = new lib.container_pics("single",3);
	this.instance_15.setTransform(519.2,300.7,0.31,0.31,0,0,0,0.1,0.1);

	this.instance_16 = new lib.container_pics("single",3);
	this.instance_16.setTransform(587.1,300.7,0.31,0.31,0,0,0,0.1,0.1);

	this.instance_17 = new lib.container_pics("single",3);
	this.instance_17.setTransform(653.7,300.7,0.31,0.31,0,0,0,0.1,0.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_17},{t:this.instance_16},{t:this.instance_15}]}).wait(282));

	// Ebene 19
	this.instance_18 = new lib.container_pics("single",3);
	this.instance_18.setTransform(541.8,293.5,0.247,0.247,0,0,0,0.2,0.4);

	this.instance_19 = new lib.container_pics("single",3);
	this.instance_19.setTransform(596.1,293.5,0.247,0.247,0,0,0,0.2,0.4);

	this.instance_20 = new lib.container_pics("single",3);
	this.instance_20.setTransform(649.2,293.5,0.247,0.247,0,0,0,0,0.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_20},{t:this.instance_19},{t:this.instance_18}]}).wait(282));

	// Ebene 21
	this.instance_21 = new lib.container_pics("single",2);
	this.instance_21.setTransform(384.6,210.9,0.6,0.6,0,0,0,641,351.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_21).wait(282));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,732.4,421.8);


(lib.ani_warningSystem = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{"step1":9});

	// timeline functions:
	this.frame_3 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(3).call(this.frame_3).wait(157));

	// Ebene 16 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("EhfJAlqMAAAhLTMC+SAAAMAAABLTg");
	mask.setTransform(609,241);

	// Ebene 14
	this.button_gotoAndPlay_parent_step1 = new lib.button_play();
	this.button_gotoAndPlay_parent_step1.setTransform(1162.6,439.5,1,1,0,0,0,31.7,31.7);
	this.button_gotoAndPlay_parent_step1._off = true;

	this.button_gotoAndPlay_parent_step1.mask = mask;

	this.timeline.addTween(cjs.Tween.get(this.button_gotoAndPlay_parent_step1).wait(3).to({_off:false},0).wait(6).to({x:1331.6},0).wait(150).to({x:1162.6,y:411.7},0).wait(1));

	// Ebene 13
	this.instance = new lib.container_pics("single",13);
	this.instance.setTransform(1730.8,328,1,1,0,0,0,640.8,139);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(9).to({startPosition:13},0).to({alpha:0},9).to({_off:true},1).wait(141));

	// mask
	this.instance_1 = new lib.ani_cycle("single",11);
	this.instance_1.setTransform(791.5,179,0.679,0.679,0,0,0,58.5,47);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(9).to({startPosition:11},0).to({alpha:0},9).to({_off:true},1).wait(141));

	// Ebene 10 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_0 = new cjs.Graphics().p("EA7GABeQBEC6AtDAQAtC/AXDDQAXDCAADDQAADEgXDCQgXDDgtC/QgtC/hEC7MgxigSCg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:mask_1_graphics_0,x:398.6,y:240.1}).wait(19).to({graphics:null,x:0,y:0}).wait(141));

	// Ebene 9
	this.instance_2 = new lib.ani_range02("single",129);
	this.instance_2.setTransform(739.4,502.4,1,1,0,0,0,229.4,139.2);

	this.instance_2.mask = mask_1;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(9).to({startPosition:129},0).to({alpha:0},9).to({_off:true},1).wait(141));

	// Ebene 7
	this.instance_3 = new lib.container_pics("single",7);
	this.instance_3.setTransform(267.4,271,0.658,0.658,0,0,0,-0.1,0.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(9).to({startPosition:7},0).to({alpha:0},9).to({_off:true},1).wait(141));

	// Ebene 3
	this.instance_4 = new lib.container_pics("single",4);
	this.instance_4.setTransform(641.1,240.5,1,1,0,0,0,641.1,351.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(9).to({startPosition:4},0).to({alpha:0},9).to({_off:true},1).wait(19).to({_off:false,regX:640.8,regY:139,x:1730.8,y:328,startPosition:13},0).to({alpha:1},7).wait(115));

	// Ebene 8 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	mask_2.graphics.p("EhfJAlqMAAAhLTMC+SAAAMAAABLTg");
	mask_2.setTransform(609,241);

	// Ebene 6
	this.instance_5 = new lib.container_pics("single",5);
	this.instance_5.setTransform(1222.4,20.1,0.658,0.658,0,0,0,0,0.1);

	this.instance_5.mask = mask_2;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(19).to({startPosition:5},0).to({x:-414.6},131).wait(10));

	// Ebene 2
	this.instance_6 = new lib.ani_cycle("single",0);
	this.instance_6.setTransform(791.5,519,0.679,0.679,0,0,0,58.5,47);

	this.instance_6.mask = mask_2;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(19).to({mode:"synched"},0).to({y:179,mode:"single",startPosition:11},131).wait(10));

	// mask (mask)
	var mask_3 = new cjs.Shape();
	mask_3._off = true;
	var mask_3_graphics_0 = new cjs.Graphics().p("EhfJAlqMAAAhLTMC+SAAAMAAABLTg");
	var mask_3_graphics_42 = new cjs.Graphics().p("EA4agSzQB2FHBQFPQBPFPAnFSQAoFVAAFWQAAFWgoFUQgnFVhPFPQhQFPh2FGMhWsgfjg");
	var mask_3_graphics_43 = new cjs.Graphics().p("EA4dgSZQB2FEBOFMQBPFMAnFQQAnFRAAFTQAAFUgnFRQgnFRhPFNQhOFMh2FEMhV8gfTg");
	var mask_3_graphics_44 = new cjs.Graphics().p("EA4hgR/QB0FBBOFJQBOFKAnFMQAnFPAAFQQAAFQgnFPQgnFOhOFKQhOFJh0FBMhVNgfBg");
	var mask_3_graphics_45 = new cjs.Graphics().p("EA4kgRlQB0E+BNFHQBNFGAmFKQAnFLAAFOQAAFNgnFMQgmFLhNFHQhNFGh0E+MhUdgevg");
	var mask_3_graphics_46 = new cjs.Graphics().p("EA4ngRLQBzE7BNFEQBMFEAmFGQAmFJAAFKQAAFLgmFIQgmFJhMFEQhNFDhzE8MhTtgefg");
	var mask_3_graphics_47 = new cjs.Graphics().p("EA4rgQxQByE5BLFAQBMFBAmFEQAmFGAAFHQAAFHgmFGQgmFGhMFBQhLFAhyE5MhS+geNg");
	var mask_3_graphics_48 = new cjs.Graphics().p("EA4ugQXQBxE2BLE+QBLE9AmFBQAlFDAAFFQAAFEglFDQgmFDhLE+QhLE+hxE1MhSOgd7g");
	var mask_3_graphics_49 = new cjs.Graphics().p("EA4ygP9QBvEzBLE7QBKE7AlE+QAmFAAAFBQAAFCgmFAQglFAhKE7QhLE7hvEzMhRfgdrg");
	var mask_3_graphics_50 = new cjs.Graphics().p("EA41gPjQBvEwBKE4QBJE4AlE7QAlE9AAE/QAAE/glE9QglE9hJE4QhKE4hvEwMhQvgdZg");
	var mask_3_graphics_51 = new cjs.Graphics().p("EA45gPJQBtEtBJE2QBJE1AlE4QAkE6AAE8QAAE7gkE6QglE7hJE1QhJE1htEtMhQAgdHg");
	var mask_3_graphics_52 = new cjs.Graphics().p("EA48gOvQBtEqBIEzQBIEyAlE1QAkE4AAE4QAAE5gkE3QglE3hIEzQhIEyhtErMhPQgc3g");
	var mask_3_graphics_53 = new cjs.Graphics().p("EA5AgOVQBrEoBIEvQBHEwAkEyQAkE0AAE2QAAE2gkE0QgkE0hHEwQhIEvhrEoMhOhgclg");
	var mask_3_graphics_54 = new cjs.Graphics().p("EA5DgN7QBrElBHEsQBHErAjExQAkEyAAEzQAAEygkEyQgjExhHEtQhHEshrElMhNxgcTg");
	var mask_3_graphics_55 = new cjs.Graphics().p("EA5GgNhQBqEiBGEqQBHEnAjEvQAjEuAAEwQAAEwgjEvQgjEuhHEqQhGEqhqEiMhNBgcDg");
	var mask_3_graphics_56 = new cjs.Graphics().p("EA5KgNHQBoEfBGEnQBGElAjErQAiEsAAEtQAAEtgiErQgjEshGEnQhGEnhoEfMhMSgbxg");
	var mask_3_graphics_57 = new cjs.Graphics().p("EA5NgMtQBoEcBFEkQBFEiAiEpQAjEoAAErQAAEqgjEoQgiEphFEkQhFEkhoEcMhLhgbfg");
	var mask_3_graphics_58 = new cjs.Graphics().p("EA5RgMTQBmEZBFEiQBEEfAiElQAiEmAAEnQAAEngiEmQgiEmhEEhQhFEhhmEaMhKygbPg");
	var mask_3_graphics_59 = new cjs.Graphics().p("EA5UgL5QBmEXBDEeQBEEcAiEjQAiEjAAEkQAAEkgiEjQgiEjhEEeQhDEehmEXMhKCga9g");
	var mask_3_graphics_60 = new cjs.Graphics().p("EA5YgLfQBkEUBDEbQBDEaAhEfQAiEgAAEiQAAEhgiEgQghEfhDEcQhDEbhkEUMhJTgarg");
	var mask_3_graphics_61 = new cjs.Graphics().p("EA5bgLFQBkERBCEZQBCEWAhEdQAhEdAAEeQAAEfghEcQghEdhCEZQhCEYhkESMhIjgabg");
	var mask_3_graphics_62 = new cjs.Graphics().p("EA5fgKrQBiEOBCEWQBBETAhEaQAhEaAAEcQAAEbghEaQghEahBEWQhCEVhiEPMhH0gaJg");
	var mask_3_graphics_63 = new cjs.Graphics().p("EA5igKRQBhELBBETQBBERAhEXQAgEXAAEYQAAEZggEXQghEXhBETQhBEThhELMhHEgZ4g");
	var mask_3_graphics_64 = new cjs.Graphics().p("EA5mgJ3QBgEJBAEPQBAEOAgEUQAhEVAAEVQAAEWghEUQggEUhAEQQhAEQhgEJMhGVgZng");
	var mask_3_graphics_65 = new cjs.Graphics().p("EA5pgJdQBfEGBAENQA/ELAgERQAgERAAETQAAESggESQggERg/ENQhAENhfEGMhFlgZVg");
	var mask_3_graphics_66 = new cjs.Graphics().p("EA5sgJDQBfEDA/EKQA+EIAgEOQAfEPAAEPQAAEQgfEOQggEPg+EKQg/EKhfEDMhE1gZEg");
	var mask_3_graphics_67 = new cjs.Graphics().p("EA5wgIpQBdEAA+EHQA/EGAfELQAfELAAENQAAENgfELQgfEMg/EHQg+EHhdEBMhEGgYzg");
	var mask_3_graphics_68 = new cjs.Graphics().p("EA5zgIPQBdD9A9EFQA+ECAeEIQAfEJAAEKQAAEKgfEIQgeEIg+EFQg9EEhdD+MhDWgYhg");
	var mask_3_graphics_69 = new cjs.Graphics().p("EA53gH1QBbD6A9EAQA9EBAeEGQAfEGAAEGQAAEHgfEGQgeEFg9ECQg9EBhbD7MhCngYQg");
	var mask_3_graphics_70 = new cjs.Graphics().p("EA56gHbQBaD4A9D8QA8D/AeEDQAeECAAEEQAAEEgeEDQgeECg8D/Qg9D/haD4MhB3gX/g");
	var mask_3_graphics_71 = new cjs.Graphics().p("EA5+gHBQBZD1A7D6QA8D7AeEAQAdEAAAEBQAAEBgdD/QgeEAg8D8Qg7D8hZD1MhBIgXtg");
	var mask_3_graphics_72 = new cjs.Graphics().p("EA6BgGnQBYDyA7D3QA7D5AdD9QAeD8AAD+QAAD+geD9QgdD9g7D5Qg7D5hYDyMhAYgXcg");
	var mask_3_graphics_73 = new cjs.Graphics().p("EA6FgGNQBXDvA6D0QA6D2AdD6QAdD6AAD7QAAD7gdD6QgdD6g6D2Qg6D2hXDwMg/pgXLg");
	var mask_3_graphics_74 = new cjs.Graphics().p("EA6IgF0QBWDtA6DxQA5D0AdD3QAcD2AAD5QAAD4gcD3QgdD3g5DzQg6DzhWDtMg+5gW5g");
	var mask_3_graphics_75 = new cjs.Graphics().p("EA6MgFaQBVDqA4DvQA5DwAdD0QAcD0AAD1QAAD2gcD0QgdD0g5DwQg4DwhVDqMg+KgWog");
	var mask_3_graphics_76 = new cjs.Graphics().p("EA6PgFAQBUDoA4DrQA4DtAcDyQAcDxAADyQAADygcDxQgcDyg4DtQg4DthUDoMg9ZgWXg");
	var mask_3_graphics_77 = new cjs.Graphics().p("EA6SgEmQBTDlA4DoQA3DrAcDuQAcDuAADwQAADvgcDuQgcDug3DrQg4DqhTDlMg8pgWFg");
	var mask_3_graphics_78 = new cjs.Graphics().p("EA6WgEMQBSDiA3DmQA2DnAcDsQAbDrAADsQAADtgbDrQgcDrg2DoQg3DohSDhMg76gV0g");
	var mask_3_graphics_79 = new cjs.Graphics().p("EA6ZgDyQBRDfA2DjQA2DlAbDoQAbDoAADqQAADpgbDpQgbDog2DlQg2DlhRDfMg7KgVjg");
	var mask_3_graphics_80 = new cjs.Graphics().p("EA6dgDYQBQDaA1DiQA2DiAaDmQAbDlAADnQAADmgbDmQgaDlg2DiQg1DihQDcMg6dgVRg");
	var mask_3_graphics_81 = new cjs.Graphics().p("EA6ggC+QBPDYA1DfQA1DfAaDiQAaDjAADjQAADkgaDiQgaDjg1DfQg1DfhPDZMg5tgVAg");
	var mask_3_graphics_82 = new cjs.Graphics().p("EA6kgCkQBODVA0DcQA0DcAaDgQAaDfAADhQAADhgaDfQgaDgg0DcQg0DchODXMg4+gUvg");
	var mask_3_graphics_83 = new cjs.Graphics().p("EA6ngCKQBNDSAzDZQA0DZAZDdQAaDdAADeQAADdgaDdQgZDdg0DZQgzDZhNDUMg4OgUdg");
	var mask_3_graphics_84 = new cjs.Graphics().p("EA6rgBwQBMDPAyDWQAzDXAZDaQAZDZAADbQAADbgZDaQgZDagzDWQgyDWhMDRMg3fgUMg");
	var mask_3_graphics_85 = new cjs.Graphics().p("EA6ugBWQBLDMAyDUQAyDTAZDXQAZDXAADYQAADYgZDXQgZDWgyDUQgyDUhLDOMg2vgT7g");
	var mask_3_graphics_86 = new cjs.Graphics().p("EA6xgA8QBKDJAyDRQAxDRAZDUQAYDUAADVQAADVgYDTQgZDUgxDRQgyDRhKDLMg1/gTpg");
	var mask_3_graphics_87 = new cjs.Graphics().p("EA61gAiQBJDHAwDNQAxDOAYDRQAZDRAADSQAADSgZDRQgYDRgxDOQgwDOhJDIMg1QgTYg");
	var mask_3_graphics_88 = new cjs.Graphics().p("EA64gAIQBIDEAwDLQAwDLAYDOQAYDOAADPQAADPgYDOQgYDOgwDLQgwDLhIDGMg0ggTHg");
	var mask_3_graphics_89 = new cjs.Graphics().p("EA68AAQQBHDDAvDIQAvDIAYDLQAXDLAADNQAADMgXDLQgYDLgvDIQgvDIhHDDMgzxgS1g");
	var mask_3_graphics_90 = new cjs.Graphics().p("EA6/AAqQBGDAAvDFQAuDFAYDJQAXDIAADJQAADJgXDJQgYDIguDFQgvDFhGDAMgzBgSkg");
	var mask_3_graphics_91 = new cjs.Graphics().p("EA7DABEQBFC9AtDDQAuDCAXDFQAXDFAADHQAADGgXDFQgXDGguDCQgtDChFC+MgySgSTg");
	var mask_3_graphics_92 = new cjs.Graphics().p("EA7GABeQBEC6AtDAQAtC/AXDDQAXDCAADDQAADEgXDCQgXDDgtC/QgtC/hEC7MgxigSCg");

	this.timeline.addTween(cjs.Tween.get(mask_3).to({graphics:mask_3_graphics_0,x:609,y:241}).wait(42).to({graphics:mask_3_graphics_42,x:396.6,y:283.5}).wait(1).to({graphics:mask_3_graphics_43,x:396.7,y:282.6}).wait(1).to({graphics:mask_3_graphics_44,x:396.7,y:281.7}).wait(1).to({graphics:mask_3_graphics_45,x:396.7,y:280.9}).wait(1).to({graphics:mask_3_graphics_46,x:396.8,y:280}).wait(1).to({graphics:mask_3_graphics_47,x:396.8,y:279.1}).wait(1).to({graphics:mask_3_graphics_48,x:396.9,y:278.3}).wait(1).to({graphics:mask_3_graphics_49,x:396.9,y:277.4}).wait(1).to({graphics:mask_3_graphics_50,x:396.9,y:276.5}).wait(1).to({graphics:mask_3_graphics_51,x:397,y:275.7}).wait(1).to({graphics:mask_3_graphics_52,x:397,y:274.8}).wait(1).to({graphics:mask_3_graphics_53,x:397.1,y:273.9}).wait(1).to({graphics:mask_3_graphics_54,x:397.1,y:273.1}).wait(1).to({graphics:mask_3_graphics_55,x:397.1,y:272.2}).wait(1).to({graphics:mask_3_graphics_56,x:397.2,y:271.3}).wait(1).to({graphics:mask_3_graphics_57,x:397.2,y:270.5}).wait(1).to({graphics:mask_3_graphics_58,x:397.3,y:269.6}).wait(1).to({graphics:mask_3_graphics_59,x:397.3,y:268.7}).wait(1).to({graphics:mask_3_graphics_60,x:397.3,y:267.9}).wait(1).to({graphics:mask_3_graphics_61,x:397.4,y:267}).wait(1).to({graphics:mask_3_graphics_62,x:397.4,y:266.1}).wait(1).to({graphics:mask_3_graphics_63,x:397.5,y:265.3}).wait(1).to({graphics:mask_3_graphics_64,x:397.5,y:264.4}).wait(1).to({graphics:mask_3_graphics_65,x:397.5,y:263.5}).wait(1).to({graphics:mask_3_graphics_66,x:397.6,y:262.7}).wait(1).to({graphics:mask_3_graphics_67,x:397.6,y:261.8}).wait(1).to({graphics:mask_3_graphics_68,x:397.7,y:260.9}).wait(1).to({graphics:mask_3_graphics_69,x:397.7,y:260.1}).wait(1).to({graphics:mask_3_graphics_70,x:397.7,y:259.2}).wait(1).to({graphics:mask_3_graphics_71,x:397.8,y:258.3}).wait(1).to({graphics:mask_3_graphics_72,x:397.8,y:257.5}).wait(1).to({graphics:mask_3_graphics_73,x:397.9,y:256.6}).wait(1).to({graphics:mask_3_graphics_74,x:397.9,y:255.7}).wait(1).to({graphics:mask_3_graphics_75,x:397.9,y:254.9}).wait(1).to({graphics:mask_3_graphics_76,x:398,y:254}).wait(1).to({graphics:mask_3_graphics_77,x:398,y:253.1}).wait(1).to({graphics:mask_3_graphics_78,x:398.1,y:252.3}).wait(1).to({graphics:mask_3_graphics_79,x:398.1,y:251.4}).wait(1).to({graphics:mask_3_graphics_80,x:398.1,y:250.5}).wait(1).to({graphics:mask_3_graphics_81,x:398.2,y:249.7}).wait(1).to({graphics:mask_3_graphics_82,x:398.2,y:248.8}).wait(1).to({graphics:mask_3_graphics_83,x:398.3,y:247.9}).wait(1).to({graphics:mask_3_graphics_84,x:398.3,y:247.1}).wait(1).to({graphics:mask_3_graphics_85,x:398.3,y:246.2}).wait(1).to({graphics:mask_3_graphics_86,x:398.4,y:245.3}).wait(1).to({graphics:mask_3_graphics_87,x:398.4,y:244.5}).wait(1).to({graphics:mask_3_graphics_88,x:398.5,y:243.6}).wait(1).to({graphics:mask_3_graphics_89,x:398.5,y:242.7}).wait(1).to({graphics:mask_3_graphics_90,x:398.5,y:241.9}).wait(1).to({graphics:mask_3_graphics_91,x:398.6,y:241}).wait(1).to({graphics:mask_3_graphics_92,x:398.6,y:240.1}).wait(68));

	// Ebene 4
	this.instance_7 = new lib.ani_range02("single",0);
	this.instance_7.setTransform(68.6,502.4,1,1,0,0,0,229.4,139.2);

	this.instance_7.mask = mask_3;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(19).to({mode:"synched",loop:false},0).to({x:739.4,startPosition:73},73,cjs.Ease.get(1)).wait(68));

	// mask (mask)
	var mask_4 = new cjs.Shape();
	mask_4._off = true;
	mask_4.graphics.p("EhfJAlqMAAAhLTMC+SAAAMAAABLTg");
	mask_4.setTransform(609,241);

	// Ebene 5
	this.instance_8 = new lib.container_pics("single",7);
	this.instance_8.setTransform(-402.5,271,0.658,0.658,0,0,0,0,0.1);

	this.instance_8.mask = mask_4;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(19).to({startPosition:7},0).to({regX:-0.1,x:267.4},73,cjs.Ease.get(1)).wait(68));

	// Ebene 1
	this.instance_9 = new lib.container_pics("single",4);
	this.instance_9.setTransform(641.1,240.5,1,1,0,0,0,641.1,351.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(19).to({startPosition:4},0).wait(141));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-5,0,1223,482);


(lib.ani_inLine = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 20
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#002F6C").s().p("AgMAnQgFgCgDgDQgDgDgBgEIgCgKIALAAQABAIAEADQAEADAGAAQAIAAAEgDQADgDAAgGIgBgFQAAgBAAAAQAAgBgBAAQAAgBAAAAQgBAAAAgBIgEgCIgIgCIgGgCQgJgCgFgEQgGgFAAgKQAAgMAHgGQAIgFALAAQAMAAAHAFQAHAGAAAOIgLAAQgBgIgDgDQgEgDgHAAQgHAAgDADQgDADAAAGQAAAFADADQACACAIACIAGACQAMADAFAEQAEAFAAAKQAAAFgBAEQgCAEgDADQgDADgGABQgFACgHAAQgGAAgGgCg");
	this.shape.setTransform(1381.3,43);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#002F6C").s().p("AgeA5IAAhwIAMAAIAAALQAGgMANAAQAIAAAGACQAFADAEAFQAEAFACAIQABAIAAAKQAAAUgHAKQgIAKgQAAQgLAAgHgKIAAAqgAgHgrQgDABgDAEQgCADgBAGQgCAGAAAIIACAPIADAIQACADAEACQADABAEAAQAFAAAEgBQADgCACgDQACgEACgEIABgPIgBgOQgCgGgCgDQgCgEgDgBIgJgBIgHABg");
	this.shape_1.setTransform(1374,44.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#002F6C").s().p("AgMAnQgGgDgEgFQgEgFgBgIQgCgIAAgKQAAgVAHgJQAJgKAOAAQAIAAAFACQAGADADAFQAEAFACAHQABAIAAAJIAAACIguAAIABAPQABAGACADQACADAEABIAHABQAIAAAEgDQAEgDABgIIALAAQgBAMgGAGQgGAHgPAAQgGAAgHgCgAgFgcQgDABgDADIgDAGIgCALIAiAAQgBgHgBgEQgBgEgCgCQgCgDgDgBIgIAAIgFAAg");
	this.shape_2.setTransform(1366,43);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#002F6C").s().p("AALAyQgWAAAAgaIAAgqIgLAAIAAgLIALAAIAAgTIALAAIAAATIAXAAIAAALIgXAAIAAAqQAAAJACACQADAEAIAAIAKAAIAAALg");
	this.shape_3.setTransform(1359.6,42.1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#002F6C").s().p("AgaAxQgIgJgBgSIAMAAQABAOAGAGQAFAGALAAQALAAAGgFQAGgFAAgKIgBgIQgCgEgDgDQgCgCgEgBIgJgEIgHgCIgLgDQgGgBgDgEQgEgDgCgGQgDgFAAgJQAAgOAJgIQAJgIAQAAQAKgBAGADQAHADAEAFQAEAEACAHQACAHAAAJIgMAAIgCgLQgCgGgDgCQgCgDgFgCIgJgBQgJAAgGAFQgFAEAAAJQAAAGABADIAEAGQADADAEABIAIADIAHACIAMADQAGACAEAEQADADACAGQACAFAAAIQAAAOgJAIQgJAIgSAAQgRABgJgKg");
	this.shape_4.setTransform(1352.5,41.4);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#002F6C").s().p("AAQApIAAgxQAAgLgEgFQgEgDgIgBQgHABgDADQgFAFAAALIAAAxIgNAAIAAhPIAMAAIAAAKQAGgLANAAQANgBAHAIQAFAIABANIAAA0g");
	this.shape_5.setTransform(1340.9,43);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#002F6C").s().p("AgFA5IAAhxIALAAIAABxg");
	this.shape_6.setTransform(1334.9,41.4);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#002F6C").s().p("AgLA4QgGgCgDgDQgDgEgCgFQgCgFAAgGIAMAAQABAJADAEQAEADAHAAQAKAAAEgEQAEgDAAgKIAAgRQgGAMgNAAQgIAAgFgDQgGgCgDgFQgEgFgCgIQgBgGAAgLQAAgWAHgKQAIgKAPAAQAGAAAFADQAFADADAGIAAgKIAMAAIAABVQAAAOgHAHQgIAHgPAAQgHAAgFgCgAgHgsQgEACgCADQgCAEgBAGIgBAOIABAPQABAEACADQACAEAEABQADACAEAAIAIgBQADgCADgDQACgEABgEIABgPIgBgOQgBgGgCgEQgCgDgEgCIgIgBIgHABg");
	this.shape_7.setTransform(1325.3,44.7);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#002F6C").s().p("AAQApIAAgxQAAgLgEgFQgEgDgIgBQgHABgDADQgFAFAAALIAAAxIgNAAIAAhPIAMAAIAAAKQAGgLANAAQANgBAHAIQAFAIAAANIAAA0g");
	this.shape_8.setTransform(1317.5,43);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#002F6C").s().p("AgFA5IAAhPIALAAIAABPgAgFgoIAAgQIALAAIAAAQg");
	this.shape_9.setTransform(1311.7,41.4);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#002F6C").s().p("AgOA3QgGgDgDgFQgEgFgCgIQgBgIAAgLQAAgTAHgKQAIgKAPAAQANAAAFAKIAAgqIANAAIAABwIgMAAIAAgMQgGANgOAAQgIAAgFgCgAgHgLQgEABgCAEQgCADgBAEIgBAOIABAPQABAGACAEQACADAEACQADABAEAAQAFAAADgBQAEgCACgDQACgEABgGIABgPIgBgOQgBgEgCgDQgCgEgEgBIgIgBIgHABg");
	this.shape_10.setTransform(1305.7,41.4);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#002F6C").s().p("AgVAjQgGgFAAgKQAAgHACgEQADgEAEgDQAEgCAFgBIAMgEIAMgCIAAgFQAAgIgDgFQgDgEgJAAQgGAAgEADQgDAEAAAJIgMAAQABgNAGgHQAGgHAOAAQAHAAAFACQAFACADADQADAEABAFQACAFAAAGIAAA1IgNAAIAAgKQgCAEgFAEQgFADgGAAQgMAAgGgGgAAEADIgIACIgGAEQgCABgBADIgBAFQAAANAOAAQAGAAAEgFQAFgFAAgIIAAgLg");
	this.shape_11.setTransform(1298,43);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#002F6C").s().p("AgLA5IAAhEIgKAAIAAgLIAKAAIAAgIQAAgMAGgHQAFgGAMgBIAKAAIAAAMIgJAAQgHAAgDAEQgDACAAAIIAAAIIAUAAIAAALIgUAAIAABEg");
	this.shape_12.setTransform(1292.2,41.4);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#002F6C").s().p("AgnAFIAAgJIBPAAIAAAJg");
	this.shape_13.setTransform(1285,47.8);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#002F6C").s().p("AgFA5IAAhPIALAAIAABPgAgFgoIAAgQIALAAIAAAQg");
	this.shape_14.setTransform(1278.6,41.4);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#002F6C").s().p("AAQApIAAgxQAAgLgEgFQgEgDgIgBQgGABgEADQgFAFAAALIAAAxIgMAAIAAhPIAMAAIAAAKQAEgLAOAAQANgBAGAIQAHAIgBANIAAA0g");
	this.shape_15.setTransform(1273,43);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#002F6C").s().p("AAdA5IgJgcIgpAAIgIAcIgMAAIAjhxIANAAIAjBxgAgRASIAiAAIgRg6g");
	this.shape_16.setTransform(1264.5,41.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).to({state:[]},10).wait(140));

	// Ebene 1
	this.instance = new lib.ani_fadeIn();
	this.instance.setTransform(609,351.5,1,1,0,0,0,609,351.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({_off:true},10).wait(140));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,1425,703);


(lib.popup02 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgLA4QgGgCgDgDQgDgEgCgFQgCgFAAgGIAMAAQABAJADAEQAEADAHAAQAKAAAEgEQAEgDAAgKIAAgRQgGAMgNAAQgIAAgFgDQgGgCgDgFQgEgFgCgIQgBgGAAgLQAAgWAHgKQAIgKAPAAQAGAAAFADQAFADADAGIAAgKIAMAAIAABVQAAAOgHAHQgIAHgPAAQgHAAgFgCgAgHgsQgEACgCADQgCAEgBAGIgBAOIABAPQABAEACADQACAEAEABQADACAEAAIAIgBQADgCADgDQACgEABgEIABgPIgBgOQgBgGgCgEQgCgDgEgCIgIgBIgHABg");
	this.shape.setTransform(1448.3,156.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AAQAoIAAgwQAAgLgEgEQgDgEgJgBQgGABgFAEQgEADAAAMIAAAwIgNAAIAAhOIANAAIAAAKQAEgLAOgBQANABAGAHQAHAHAAANIAAA0g");
	this.shape_1.setTransform(1440.5,155);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgVAhQgHgHAAgNIAAg0IANAAIAAAwQAAALAEAFQADAFAIAAQAIAAAEgFQAEgFAAgLIAAgwIANAAIAABOIgNAAIAAgKQgCAGgFADQgFADgGAAQgNgBgGgHg");
	this.shape_2.setTransform(1432.5,155.1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgZAoIAAgIIAjg8IgjAAIAAgLIAzAAIAAAHIgjA9IAiAAIAAALg");
	this.shape_3.setTransform(1425.4,155);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgRAoIAAg3QAAgLAGgHQAGgGALAAIAMAAIAAALIgMAAQgKAAAAAMIAAA4g");
	this.shape_4.setTransform(1420.1,155);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AgVAwQgHgHAAgNIAAg0IANAAIAAAwQAAALAEAFQADAFAIAAQAIAAAEgFQAEgFAAgLIAAgwIANAAIAABOIgNAAIAAgKQgCAGgFADQgFADgGAAQgNgBgGgHgAAHgoIAAgPIANAAIAAAPgAgRgoIAAgPIAMAAIAAAPg");
	this.shape_5.setTransform(1413.2,153.6);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AAPA4IgUglIgLAMIAAAZIgNAAIAAhvIANAAIAABHIAfgmIAPAAIgdAgIAdAug");
	this.shape_6.setTransform(1406.1,153.4);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AgRAoIAAg3QAAgLAGgHQAGgGAKAAIANAAIAAALIgMAAQgKAAAAAMIAAA4g");
	this.shape_7.setTransform(1399.9,155);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AgLAnQgHgDgDgFQgEgFgCgIQgCgIAAgKQAAgVAIgJQAHgKAPAAQAIAAAGACQAFADAEAFQADAFABAHQACAIAAAJIAAACIguAAIABAPQABAGADADQACADADABIAHABQAIAAAEgDQAEgDABgIIALAAQgBAMgGAGQgGAHgPAAQgHAAgFgCgAgFgcQgDABgCADIgEAGIgCALIAhAAQABgHgCgEQgBgEgCgCQgCgDgDgBIgIAAIgFAAg");
	this.shape_8.setTransform(1393.3,155);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AgEAoIgchPIAOAAIASA9IAVg9IAMAAIgcBPg");
	this.shape_9.setTransform(1386,155);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AgLA4QgGgCgDgDQgDgEgCgFQgCgFAAgGIAMAAQABAJADAEQAEADAHAAQAKAAAEgEQAEgDAAgKIAAgRQgGAMgNAAQgIAAgFgDQgGgCgDgFQgEgFgCgIQgBgGAAgLQAAgWAHgKQAIgKAPAAQAGAAAFADQAFADADAGIAAgKIAMAAIAABVQAAAOgHAHQgIAHgPAAQgHAAgFgCgAgHgsQgEACgCADQgCAEgBAGIgBAOIABAPQABAEACADQACAEAEABQADACAEAAIAIgBQADgCADgDQACgEABgEIABgPIgBgOQgBgGgCgEQgCgDgEgCIgIgBIgHABg");
	this.shape_10.setTransform(1378.2,156.7);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AgMAnQgFgDgFgFQgEgFgBgIQgCgIAAgKQAAgVAHgJQAIgKAPAAQAIAAAFACQAGADAEAFQADAFABAHQACAIAAAJIAAACIguAAIABAPQABAGACADQADADADABIAHABQAIAAAEgDQAEgDABgIIALAAQgBAMgGAGQgHAHgOAAQgGAAgHgCgAgFgcQgDABgCADIgEAGIgCALIAiAAQgBgHgBgEQgBgEgCgCQgCgDgDgBIgIAAIgFAAg");
	this.shape_11.setTransform(1370.6,155);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AARAoIgRg4IgQA4IgMAAIgYhPIANAAIASA8IASg8IAIAAIASA8IASg8IAMAAIgYBPg");
	this.shape_12.setTransform(1361.3,155);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("AgLAnQgHgDgDgFQgFgFgBgIQgCgIAAgKQAAgVAIgJQAHgKAPAAQAIAAAGACQAFADAEAFQADAFABAHQACAIAAAJIAAACIguAAIABAPQABAGADADQABADAEABIAHABQAIAAAEgDQAEgDABgIIAMAAQgCAMgGAGQgGAHgPAAQgHAAgFgCgAgFgcQgDABgCADIgEAGIgCALIAhAAQAAgHgBgEQgBgEgCgCQgCgDgDgBIgIAAIgFAAg");
	this.shape_13.setTransform(1352,155);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AALAxQgWAAAAgZIAAgqIgLAAIAAgLIALAAIAAgUIALAAIAAAUIAXAAIAAALIgXAAIAAAqQAAAIACAEQADADAIAAIAKAAIAAAKg");
	this.shape_14.setTransform(1345.6,154.1);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("AgFA4IAAhvIALAAIAABvg");
	this.shape_15.setTransform(1341.2,153.4);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("AgVAjQgGgFAAgKQAAgHACgEQADgEAEgDQAEgCAFgBIAMgEIAMgCIAAgFQAAgIgDgFQgDgEgJAAQgGAAgEADQgDAEAAAJIgMAAQABgNAGgHQAGgHAOAAQAHAAAFACQAFACADADQADAEABAFQACAFAAAGIAAA1IgNAAIAAgKQgCAEgFAEQgFADgGAAQgMAAgGgGgAAEADIgIACIgGAEQgCABgBADIgBAFQAAANAOAAQAGAAAEgFQAFgFAAgIIAAgLg");
	this.shape_16.setTransform(1335.6,155);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AAQA4IAAgyQAAgJgEgEQgDgEgJgBQgHABgEAEQgEADAAAKIAAAyIgNAAIAAhvIANAAIAAAqQADgFAFgDQAFgCAFgBQANABAHAHQAFAHABALIAAA2g");
	this.shape_17.setTransform(1328.3,153.4);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#000000").s().p("AAQAoIAAgwQAAgLgEgEQgDgEgJgBQgGABgEAEQgFADAAAMIAAAwIgMAAIAAhOIALAAIAAAKQAFgLAOgBQANABAGAHQAHAHgBANIAAA0g");
	this.shape_18.setTransform(1320.3,155);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#000000").s().p("AAdA4IgJgbIgpAAIgIAbIgMAAIAjhvIANAAIAjBvgAgRASIAiAAIgRg6g");
	this.shape_19.setTransform(1311.8,153.4);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#000000").s().p("AgnAFIAAgJIBPAAIAAAJg");
	this.shape_20.setTransform(1302.7,159.8);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#000000").s().p("AgfA5IAAgKQAAgGABgGQACgFADgEIAHgIIAJgHIALgIIAHgDQADgCADgEQADgDACgFQACgEgBgGQAAgKgFgGQgGgEgKAAIgIABQgEABgDADQgDAEgCAEIgCANIgMAAQAAgKACgGQACgIAFgFQAEgEAGgDQAHgDAIAAQARAAAKAJQAIAJAAAPQAAAIgDAFQgCAGgCAEIgIAFIgJAGIgLAJIgIAHIgGAFIgDAHIgBAHIAAACIA0AAIAAAKg");
	this.shape_21.setTransform(1293.6,153.3);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#000000").s().p("AgQA3QgHgCgFgIQgEgGgCgMQgCgLAAgQQAAgPACgLQABgLAFgHQAEgHAHgDQAIgEAJAAQAKAAAIAEQAHADAEAHQAFAHABALQACALAAAPQAAAQgCALQgCALgEAHQgFAIgHACQgHADgKAAQgJAAgHgDgAgKgrQgFACgDAGQgCAFgBAIQgCAJAAANIABAWQABAKADAFQADAGAEACQAFADAGAAQAHAAAFgDQAEgCADgGQADgFABgKIABgWIgBgWQgCgIgCgFQgDgGgFgCQgEgCgHAAQgGAAgEACg");
	this.shape_22.setTransform(1284.6,153.4);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#000000").s().p("AgeA5IAAhwIAMAAIAAALQAGgMANAAQAIAAAGACQAFADAEAFQAEAFACAIQABAIAAAKQAAAUgHAKQgIAKgQAAQgLAAgHgKIAAAqgAgHgrQgDABgDAEQgCADgBAGQgCAGAAAIIABAPIAEAIQACADAEACQADABAEAAQAFAAAEgBQADgCACgDQACgEACgEIABgPIgBgOQgCgGgCgDQgCgEgDgBIgJgBIgHABg");
	this.shape_23.setTransform(1276.3,156.6);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#000000").s().p("AgVAhQgHgHAAgNIAAg0IANAAIAAAwQAAALAEAFQADAFAIAAQAIAAAEgFQAEgFAAgLIAAgwIANAAIAABOIgNAAIAAgKQgCAGgFADQgFADgGAAQgNgBgGgHg");
	this.shape_24.setTransform(1268,155.1);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#000000").s().p("AgeA5IAAhwIAMAAIAAALQAGgMANAAQAIAAAGACQAFADAEAFQAEAFACAIQABAIAAAKQAAAUgHAKQgIAKgQAAQgMAAgFgKIAAAqgAgHgrQgDABgDAEQgCADgBAGQgBAGAAAIIABAPIADAIQACADAEACQADABAEAAQAFAAAEgBQADgCACgDQACgEACgEIABgPIgBgOQgCgGgCgDQgCgEgDgBIgJgBIgHABg");
	this.shape_25.setTransform(1260.2,156.6);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#000000").s().p("AgNAnQgGgDgEgFQgEgFgBgIQgCgIAAgKQAAgJACgIQABgIAEgFQAEgFAGgDQAGgCAHAAQAIAAAGACQAGADAEAFQAEAFACAIQABAIAAAJQAAAVgHAKQgIAKgQAAQgHAAgGgCgAgHgbQgEABgCAEQgCADgBAGIgBANIABAOQABAGACAEQACADAEACQADABAEAAQAFAAADgBQAEgCACgDQACgEABgGIABgOIgBgNQgBgGgCgDQgCgEgEgBIgIgBIgHABg");
	this.shape_26.setTransform(1252,155);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#000000").s().p("AgeA5IAAhwIAMAAIAAALQAGgMAMAAQAJAAAGACQAFADAFAFQADAFABAIQACAIAAAKQAAAUgHAKQgHAKgRAAQgMAAgFgKIAAAqgAgHgrQgEABgCAEQgCADgBAGQgCAGABAIIAAAPIAEAIQACADAEACQAEABADAAQAFAAAEgBQADgCADgDQACgEAAgEIABgPIgBgOQAAgGgCgDQgDgEgDgBIgJgBIgHABg");
	this.shape_27.setTransform(1244.3,156.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(242));

	// Ebene 2
	this.instance = new lib.container_text("single",20);
	this.instance.setTransform(645,681.8,1,1,0,0,0,585,188.8);

	this.instance_1 = new lib.container_text("single",19);
	this.instance_1.setTransform(645,278.8,1,1,0,0,0,585,188.8);

	this.instance_2 = new lib.container_text("single",21);
	this.instance_2.setTransform(800,146);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_2},{t:this.instance_1},{t:this.instance}]},4).wait(238));

	// scrollerWidget_1
	this.closeBtn = new lib.btn_close02();
	this.closeBtn.setTransform(1162,58.2,1,1,0,0,0,12,11.8);
	this.closeBtn._off = true;

	this.timeline.addTween(cjs.Tween.get(this.closeBtn).wait(4).to({_off:false},0).wait(238));

	// scrollerWidget_1
	this.instance_3 = new lib.ani_warningSystem02("synched",19,false);
	this.instance_3.setTransform(59.9,146);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(4).to({_off:false},0).wait(237).to({mode:"independent"},0).wait(1));

	// scrollerWidget_1
	this.instance_4 = new lib.pic_plane_white();
	this.instance_4.setTransform(609,336,0.993,1.132,0,0,0,579,265);
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(4).to({_off:false},0).wait(238));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(1238,140.7,232,27.4);


(lib.popup01 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgLA4QgGgCgDgDQgDgEgCgFQgCgFAAgGIAMAAQABAJADAEQAEADAHAAQAKAAAEgEQAEgDAAgKIAAgRQgGAMgNAAQgIAAgFgDQgGgCgDgFQgEgFgCgIQgBgGAAgLQAAgWAHgKQAIgKAPAAQAGAAAFADQAFADADAGIAAgKIAMAAIAABVQAAAOgHAHQgIAHgPAAQgHAAgFgCgAgHgsQgEACgCADQgCAEgBAGIgBAOIABAPQABAEACADQACAEAEABQADACAEAAIAIgBQADgCADgDQACgEABgEIABgPIgBgOQgBgGgCgEQgCgDgEgCIgIgBIgHABg");
	this.shape.setTransform(1426.6,126.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AAQApIAAgxQAAgLgEgEQgDgFgJAAQgHAAgEAFQgEADAAAMIAAAxIgNAAIAAhPIAMAAIAAAKQAGgMANABQANAAAGAHQAGAIABANIAAA0g");
	this.shape_1.setTransform(1418.8,125);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgVAhQgHgHAAgOIAAg0IANAAIAAAxQAAALAEAFQADAFAIgBQAIABAEgFQAEgFAAgLIAAgxIANAAIAABPIgNAAIAAgKQgCAFgFADQgFADgGABQgNAAgGgIg");
	this.shape_2.setTransform(1410.8,125.1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AAQApIAAgxQAAgLgEgEQgEgFgIAAQgGAAgFAFQgEADAAAMIAAAxIgMAAIAAhPIAMAAIAAAKQAEgMAOABQANAAAGAHQAHAIgBANIAAA0g");
	this.shape_3.setTransform(1402.9,125);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgRAoIAAg3QAAgLAHgHQAFgGALAAIAMAAIAAALIgMAAQgKAAAAAMIAAA4g");
	this.shape_4.setTransform(1396.8,125);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AgVAjQgGgFAAgKQAAgHACgEQADgEAEgDQAEgCAFgBIAMgEIAMgCIAAgFQAAgIgDgFQgDgEgJAAQgGAAgEADQgDAEAAAJIgMAAQABgNAGgHQAGgHAOAAQAHAAAFACQAFACADADQADAEABAFQACAFAAAGIAAA1IgNAAIAAgKQgCAEgFAEQgFADgGAAQgMAAgGgGgAAEADIgIACIgGAEQgCABgBADIgBAFQAAANAOAAQAGAAAEgFQAFgFAAgIIAAgLg");
	this.shape_5.setTransform(1390.1,125);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AARAoIgRg4IgQA4IgLAAIgZhPIAOAAIARA8IATg8IAHAAIATA8IARg8IAMAAIgZBPg");
	this.shape_6.setTransform(1381.2,125);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AgRAoIAAg3QAAgLAHgHQAFgGALAAIAMAAIAAALIgMAAQgKAAAAAMIAAA4g");
	this.shape_7.setTransform(1373.5,125);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AgMAnQgFgDgFgFQgEgFgBgIQgCgIAAgKQAAgVAHgJQAJgKAOAAQAIAAAFACQAGADADAFQAEAFABAHQACAIAAAJIAAACIguAAIABAPQABAGACADQACADAEABIAHABQAIAAAEgDQAEgDABgIIALAAQgBAMgGAGQgGAHgPAAQgGAAgHgCgAgFgcQgDABgDADIgDAGIgCALIAiAAQgBgHgBgEQgBgEgCgCQgCgDgDgBIgIAAIgFAAg");
	this.shape_8.setTransform(1366.9,125);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AgLA4QgGgCgDgDQgDgEgCgFQgCgFAAgGIAMAAQABAJADAEQAEADAHAAQAKAAAEgEQAEgDAAgKIAAgRQgGAMgNAAQgIAAgFgDQgGgCgDgFQgEgFgCgIQgBgGAAgLQAAgWAHgKQAIgKAPAAQAGAAAFADQAFADADAGIAAgKIAMAAIAABVQAAAOgHAHQgIAHgPAAQgHAAgFgCgAgHgsQgEACgCADQgCAEgBAGIgBAOIABAPQABAEACADQACAEAEABQADACAEAAIAIgBQADgCADgDQACgEABgEIABgPIgBgOQgBgGgCgEQgCgDgEgCIgIgBIgHABg");
	this.shape_9.setTransform(1358.9,126.7);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AAQApIAAgxQAAgLgEgEQgEgFgIAAQgGAAgFAFQgEADAAAMIAAAxIgNAAIAAhPIANAAIAAAKQAEgMAOABQANAAAGAHQAHAIAAANIAAA0g");
	this.shape_10.setTransform(1351.1,125);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AgVAyQgGgGAAgKQAAgGACgFQADgEAEgDQAEgDAFgCIAMgEIAMgCIAAgFQAAgGgDgEQgDgEgJAAQgGAAgEADQgDADAAAIIgMAAQABgMAGgHQAGgHAOAAQAHAAAFACQAFACADADQADAEABAFQACAFAAAFIAAA2IgNAAIAAgKQgCAEgFAEQgFAEgGAAQgMgBgGgFgAAEARIgIADIgGADQgCACgBACIgBAGQAAAMAOAAQAGAAAEgEQAFgFAAgJIAAgLgAAIgnIAAgQIAMAAIAAAQgAgRgnIAAgQIANAAIAAAQg");
	this.shape_11.setTransform(1343.2,123.6);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AgLA4QgGgCgDgDQgDgEgCgFQgCgFAAgGIAMAAQABAJADAEQAEADAHAAQAKAAAEgEQAEgDAAgKIAAgRQgGAMgNAAQgIAAgFgDQgGgCgDgFQgEgFgCgIQgBgGAAgLQAAgWAHgKQAIgKAPAAQAGAAAFADQAFADADAGIAAgKIAMAAIAABVQAAAOgHAHQgIAHgPAAQgHAAgFgCgAgHgsQgEACgCADQgCAEgBAGIgBAOIABAPQABAEACADQACAEAEABQADACAEAAIAIgBQADgCADgDQACgEABgEIABgPIgBgOQgBgGgCgEQgCgDgEgCIgIgBIgHABg");
	this.shape_12.setTransform(1335.5,126.7);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("AAAA6IAAgLIAEAAIAJgBQAEgBADgDQACgCACgEIABgLIgBgLQgBgEgDgDQgCgCgEgBIgJgBIgFAAIAAgJIADAAQAKAAADgFQAEgEAAgLQAAgKgEgEQgEgFgKAAIgHABQgDABgCADIgDAEIgBAIIAABWIgMAAIAAhEIgLAAIAAgLIALAAIAAgHQAAgHABgEQACgGADgDQAEgEAFgDQAGgBAHgBQAIABAGABQAGADAEAEQADADACAGQABAGAAAHQAAASgLAGQAKACADAGQAEAIAAALQAAAQgIAJQgIAIgSAAg");
	this.shape_13.setTransform(1327.2,123.3);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AgVAhQgHgHAAgOIAAg0IANAAIAAAxQAAALAEAFQADAFAIgBQAIABAEgFQAEgFAAgLIAAgxIANAAIAABPIgNAAIAAgKQgCAFgFADQgFADgGABQgNAAgGgIg");
	this.shape_14.setTransform(1319,125.1);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("AgcA5IAAhxIA5AAIAAANIgsAAIAAAmIApAAIAAAIIgpAAIAAA2g");
	this.shape_15.setTransform(1311.6,123.4);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("AgnAFIAAgJIBPAAIAAAJg");
	this.shape_16.setTransform(1302.7,129.8);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AAJA5IAAhiIgeALIAAgMIAggOIALAAIAABxg");
	this.shape_17.setTransform(1293.1,123.4);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#000000").s().p("AgQA4QgHgDgFgHQgEgHgCgMQgCgLAAgQQAAgPACgLQABgLAFgHQAEgHAHgDQAIgDAJgBQAKABAIADQAHADAEAHQAFAHABALQACALAAAPQAAAQgCALQgCALgEAIQgFAHgHADQgHACgKAAQgJAAgHgCgAgKgrQgFACgDAFQgCAFgBAJQgCAJAAANIABAWQABAKADAGQADAFAEADQAFACAGAAQAHAAAFgCQAEgDADgFQADgGABgKIABgWIgBgWQgCgJgCgFQgDgFgFgCQgEgCgHAAQgGAAgEACg");
	this.shape_18.setTransform(1284.6,123.4);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#000000").s().p("AgeA5IAAhwIAMAAIAAALQAGgMANAAQAIAAAGACQAFADAEAFQAEAFACAIQABAIAAAKQAAAUgHAKQgIAKgQAAQgLAAgHgKIAAAqgAgHgrQgDABgDAEQgCADgBAGQgCAGAAAIIABAPIAEAIQACADAEACQADABAEAAQAFAAAEgBQADgCACgDQACgEACgEIABgPIgBgOQgCgGgCgDQgCgEgDgBIgJgBIgHABg");
	this.shape_19.setTransform(1276.3,126.6);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#000000").s().p("AgVAhQgHgHAAgOIAAg0IANAAIAAAxQAAALAEAFQADAFAIgBQAIABAEgFQAEgFAAgLIAAgxIANAAIAABPIgNAAIAAgKQgCAFgFADQgFADgGABQgNAAgGgIg");
	this.shape_20.setTransform(1268,125.1);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#000000").s().p("AgeA5IAAhwIAMAAIAAALQAGgMANAAQAIAAAGACQAFADAEAFQAEAFACAIQABAIAAAKQAAAUgHAKQgIAKgQAAQgMAAgFgKIAAAqgAgHgrQgDABgDAEQgCADgBAGQgBAGAAAIIABAPIADAIQACADAEACQADABAEAAQAFAAAEgBQADgCACgDQACgEACgEIABgPIgBgOQgCgGgCgDQgCgEgDgBIgJgBIgHABg");
	this.shape_21.setTransform(1260.2,126.6);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#000000").s().p("AgNAnQgGgDgEgFQgEgFgBgIQgCgIAAgKQAAgJACgIQABgIAEgFQAEgFAGgDQAGgCAHAAQAIAAAGACQAGADAEAFQAEAFACAIQABAIAAAJQAAAVgHAKQgIAKgQAAQgHAAgGgCgAgHgbQgEABgCAEQgCADgBAGIgBANIABAOQABAGACAEQACADAEACQADABAEAAQAFAAADgBQAEgCACgDQACgEABgGIABgOIgBgNQgBgGgCgDQgCgEgEgBIgIgBIgHABg");
	this.shape_22.setTransform(1252,125);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#000000").s().p("AgeA5IAAhwIAMAAIAAALQAGgMAMAAQAJAAAGACQAFADAFAFQADAFABAIQACAIAAAKQAAAUgHAKQgHAKgRAAQgMAAgFgKIAAAqgAgHgrQgEABgCAEQgCADgBAGQgCAGABAIIAAAPIAEAIQACADAEACQAEABADAAQAFAAAEgBQADgCADgDQACgEAAgEIABgPIgBgOQAAgGgCgDQgDgEgDgBIgJgBIgHABg");
	this.shape_23.setTransform(1244.3,126.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(146));

	// Ebene 2
	this.instance = new lib.container_text("single",10);
	this.instance.setTransform(645,631.8,1,1,0,0,0,585,188.8);

	this.instance_1 = new lib.container_text("single",9);
	this.instance_1.setTransform(645,278.8,1,1,0,0,0,585,188.8);

	this.instance_2 = new lib.container_text("single",11);
	this.instance_2.setTransform(800,146);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_2},{t:this.instance_1},{t:this.instance}]},4).wait(142));

	// Ebene 5
	this.closeBtn = new lib.btn_close02();
	this.closeBtn.setTransform(1162,58.2,1,1,0,0,0,12,11.8);
	this.closeBtn._off = true;

	this.timeline.addTween(cjs.Tween.get(this.closeBtn).wait(4).to({_off:false},0).wait(142));

	// scrollerWidget_1
	this.instance_3 = new lib.ani_warningSystem("synched",19,false);
	this.instance_3.setTransform(272.3,406.7,0.599,0.599,0,0,0,354.3,435.1);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(4).to({_off:false},0).wait(141).to({regY:435.2,y:406.8,mode:"independent"},0).wait(1));

	// Ebene 1
	this.instance_4 = new lib.pic_plane_white();
	this.instance_4.setTransform(609,336,0.993,1.132,0,0,0,579,265);
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(4).to({_off:false},0).wait(142));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(1238,110.7,232,27.4);


(lib.popupCluster01 = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.popup_4 = new lib.popup04();
	this.popup_4.setTransform(1354,124.4,1,1,0,0,0,1354,124.4);

	this.timeline.addTween(cjs.Tween.get(this.popup_4).wait(1));

	// popup_3
	this.popup_3 = new lib.popup03();
	this.popup_3.setTransform(1354,124.4,1,1,0,0,0,1354,124.4);

	this.timeline.addTween(cjs.Tween.get(this.popup_3).wait(1));

	// popup_2
	this.popup_2 = new lib.popup02();
	this.popup_2.setTransform(1354,124.4,1,1,0,0,0,1354,124.4);

	this.timeline.addTween(cjs.Tween.get(this.popup_2).wait(1));

	// popup_1
	this.popup_1 = new lib.popup01();
	this.popup_1.setTransform(1354,124.4,1,1,0,0,0,1354,124.4);

	this.timeline.addTween(cjs.Tween.get(this.popup_1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(1238,110.7,232,117.5);


(lib.timelineJumpWidget = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{"step1":0});

	// fadeIn
	this.instance = new lib.ani_inLine("synched",0);
	this.instance.setTransform(609,351.5,1,1,0,0,0,609,351.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(10));

	// popup_09
	this.instance_1 = new lib.ani_text_sideBar01();
	this.instance_1.setTransform(-104.5,351.5,1,1,0,0,0,-104.5,351.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(10));

	// popup_09
	this.instance_2 = new lib.popupCluster01();
	this.instance_2.setTransform(161,43.7,1,1,0,0,0,161,43.7);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(10));

	// popup_09
	this.instance_3 = new lib.container_text("single",139);
	this.instance_3.setTransform(1430,824.8,1,1,0,0,0,540,224.8);

	this.clickPopup_4 = new lib.button04();
	this.clickPopup_4.setTransform(1031,525.2,1,1,0,0,0,170,30);

	this.clickPopup_3 = new lib.button03();
	this.clickPopup_3.setTransform(1031,470.2,1,1,0,0,0,170,30);

	this.clickPopup_2 = new lib.button02();
	this.clickPopup_2.setTransform(1031,415.2,1,1,0,0,0,170,30);

	this.clickPopup_1 = new lib.button01();
	this.clickPopup_1.setTransform(1031,360.2,1,1,0,0,0,170,30);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.clickPopup_1},{t:this.clickPopup_2},{t:this.clickPopup_3},{t:this.clickPopup_4},{t:this.instance_3}]}).wait(10));

	// popup_10
	this.instance_4 = new lib.container_pics("single",0);
	this.instance_4.setTransform(549.3,321.5,1,1,0,0,0,549.3,321.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(10));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-505.9,-1,1976,705);


// stage content:
(lib.c6p1 = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{"I":6});

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_2 = new cjs.Graphics().p("EhfJA26MAAAht0MC+SAAAMAAABt0g");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(2).to({graphics:mask_graphics_2,x:609,y:351.5}).wait(8));

	// timelineJumpWidget
	this.timelineJumpWidget = new lib.timelineJumpWidget();
	this.timelineJumpWidget._off = true;

	this.timelineJumpWidget.mask = mask;

	this.timeline.addTween(cjs.Tween.get(this.timelineJumpWidget).wait(2).to({_off:false},0).wait(8));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;

})(lib = lib||{}, images = images||{}, createjs = createjs||{}, ss = ss||{});
var lib, images, createjs, ss;