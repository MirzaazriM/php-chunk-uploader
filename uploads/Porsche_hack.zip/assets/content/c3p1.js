(function (lib, img, cjs, ss) {

var p; // shortcut to reference prototypes
lib.webFontTxtFilters = {}; 

// library properties:
lib.properties = {
	width: 1218,
	height: 703,
	fps: 25,
	color: "#FFFFFF",
	opacity: 1.00,
	webfonts: {},
	manifest: [
		{src:"assets/content/images/c3p1_pic01.jpg", id:"c3p1_pic01"},
		{src:"assets/content/images/c3p1_pic02.jpg", id:"c3p1_pic02"},
		{src:"assets/content/images/c3p1_pic03.jpg", id:"c3p1_pic03"},
		{src:"assets/content/images/c3p1_pic04.jpg", id:"c3p1_pic04"},
		{src:"assets/content/images/c3p1_pic05.jpg", id:"c3p1_pic05"},
		{src:"assets/content/images/c3p1_pic06.jpg", id:"c3p1_pic06"},
		{src:"assets/content/images/c3p1_pic07.jpg", id:"c3p1_pic07"},
		{src:"assets/content/images/c3p1_pic08.jpg", id:"c3p1_pic08"}
	]
};



lib.ssMetadata = [];


lib.webfontAvailable = function(family) { 
	lib.properties.webfonts[family] = true;
	var txtFilters = lib.webFontTxtFilters && lib.webFontTxtFilters[family] || [];
	for(var f = 0; f < txtFilters.length; ++f) {
		txtFilters[f].updateCache();
	}
};
// symbols:



(lib.c3p1_pic01 = function() {
	this.initialize(img.c3p1_pic01);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1218,703);


(lib.c3p1_pic02 = function() {
	this.initialize(img.c3p1_pic02);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1218,703);


(lib.c3p1_pic03 = function() {
	this.initialize(img.c3p1_pic03);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,550,450);


(lib.c3p1_pic04 = function() {
	this.initialize(img.c3p1_pic04);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,480,358);


(lib.c3p1_pic05 = function() {
	this.initialize(img.c3p1_pic05);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,550,450);


(lib.c3p1_pic06 = function() {
	this.initialize(img.c3p1_pic06);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,550,450);


(lib.c3p1_pic07 = function() {
	this.initialize(img.c3p1_pic07);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,550,450);


(lib.c3p1_pic08 = function() {
	this.initialize(img.c3p1_pic08);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,550,450);


(lib.SliderConstraint01 = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,51,0,0)").s().p("EhXNAAEIAAgIMCubAAAIAAAIg");
	this.shape.setTransform(558.3,0.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,1116.5,1);


(lib.scroller_handle = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D5001C").s().p("AgsCVIAAkqIBZAAIAAEqg");
	this.shape.setTransform(4.5,15);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,9,30);


(lib.scroller_back_500 = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CCCCCC").s().p("EgAYAnEMAAAhOHIAxAAMAAABOHg");
	this.shape.setTransform(2.5,250);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,5,500);


(lib.scroller_back_450 = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CCCCCC").s().p("EgAYAjKMAAAhGTIAxAAMAAABGTg");
	this.shape.setTransform(2.5,225);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,5,450);


(lib.PreviousBtn_dark = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// text
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D5001C").s().p("ABOEsIj8knIEDkwIBaAAIkCEwID7Eng");
	this.shape.setTransform(27.6,62.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AnzJxIAAzhIPmAAIAAThg");
	this.shape_1.setTransform(50,62.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},3).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(10,32.5,35.1,60);


(lib.pic_shadow_occlusionRound = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#000000","rgba(0,0,0,0)"],[0,1],0,0,0,0,0,102.5).s().p("AsTMUQlGlHgBnNQABnMFGlHQFHlGHMgBQHNABFHFGQFGFHABHMQgBHNlGFHQlHFGnNABQnMgBlHlGg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-111.5,-111.5,223,223);


(lib.pic_plane_white = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EhadApaMAAAhSzMC07AAAMAAABSzg");
	this.shape.setTransform(579,265);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,1158,530);


(lib.pic_circle03 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D5001C").s().p("AizCuQhFhFgBhpQABhnBFhMQBMhFBngBQBjABBLBFQBMBMAABnQAABphMBFQhLBMhjAAQhnAAhMhMg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-25,-25,50,50);


(lib.pic_circle02_ = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#002F6C").s().p("AizCuQhFhFgBhpQABhnBFhMQBMhFBngBQBjABBLBFQBMBMAABnQAABphMBFQhLBMhjAAQhnAAhMhMg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-25,-25,50,50);


(lib.container_text = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// Ebene 10
	this.text_140 = new cjs.Text("Klicken Sie oben rechts auf \"Themenübersicht\", um ein anderes Thema zu auszuwählen.", "16px 'Porsche Next TT'", "#FFFFFF");
	this.text_140.name = "text_140";
	this.text_140.lineHeight = 23;
	this.text_140.lineWidth = 306;
	this.text_140.setTransform(2,2);
	this.text_140._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_140).wait(139).to({_off:false},0).to({_off:true},1).wait(1));

	// Ebene 25
	this.text_31 = new cjs.Text("Optional steht das Multifunktions-GT-Sportlenkrad mit Schaltpaddles inklusive Lenkradheizung in Leder zur Verfügung.\nDas optionale Sport Chrono-Paket beinhaltet den Mode-Schalter für Normal-, Sport-, Sport Plus- oder Individual-Fahrweise.", "16px 'Porsche Next TT'");
	this.text_31.name = "text_31";
	this.text_31.lineHeight = 23;
	this.text_31.lineWidth = 496;
	this.text_31.setTransform(2,2);
	this.text_31._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_31).wait(30).to({_off:false},0).to({_off:true},1).wait(110));

	// Ebene 82
	this.text_30 = new cjs.Text("Multifunktions-GT-Sportlenkrad", "32px 'Porsche Next TT Thin'");
	this.text_30.name = "text_30";
	this.text_30.lineHeight = 47;
	this.text_30.lineWidth = 996;
	this.text_30.setTransform(2,2);
	this.text_30._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_30).wait(29).to({_off:false},0).to({_off:true},1).wait(111));

	// Ebene 9
	this.text_24 = new cjs.Text("Anti-Allergen-Filter", "16px 'Porsche Next TT'");
	this.text_24.name = "text_24";
	this.text_24.lineHeight = 23;
	this.text_24.lineWidth = 279;
	this.text_24.setTransform(2,2);
	this.text_24._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_24).wait(23).to({_off:false},0).to({_off:true},1).wait(117));

	// Ebene 8
	this.text_23 = new cjs.Text("Ionisator", "16px 'Porsche Next TT'");
	this.text_23.name = "text_23";
	this.text_23.lineHeight = 23;
	this.text_23.lineWidth = 279;
	this.text_23.setTransform(2,2);
	this.text_23._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_23).wait(22).to({_off:false},0).to({_off:true},1).wait(118));

	// Ebene 64
	this.text_22 = new cjs.Text("Luftführung Klimaautomatik mit Anti-Allergen-Filter und Ionisator", "16px 'Porsche Next TT'");
	this.text_22.name = "text_22";
	this.text_22.lineHeight = 23;
	this.text_22.lineWidth = 279;
	this.text_22.setTransform(2,2);
	this.text_22._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_22).wait(21).to({_off:false},0).to({_off:true},1).wait(119));

	// Ebene 20
	this.text_21 = new cjs.Text("Der neue, serienmäßig eingebaute Anti-Allergen-Filter entfernt Schadstoffe aus der Frischluft. Er besteht aus drei Schichten:\n• Filtrationsschicht aus Mikrofaser reduziert Feinstaub, Pollen und Dieselrußpartikel\n• Aktivkohleschicht reduziert Gase, Ozon und Gerüche \n• biofunktionale Trägerschicht reduziert Allergene, Pilze und Bakterien \n\nBitte beachten Sie die spezifischen Wartungsintervalle der verschiedenen Länder, nähere Infos dazu erhalten Sie in PCSS.\n\nErstmalig wird beim Porsche Macan (MJ 19) optional für die Luftreinigung im Innenraum ein Ionisator mit zwei Emitter-Abgängen in den seitlichen Luftführungen verbaut. \n\nDie Außenluft wird in der Klimaautomatik durch den Ionisator geleitet, bevor sie ins Wageninnere strömt. Die vom Ionisator erzeugten negativen Ionen binden schädliche Partikel und verbessern so die Luftqualität im Fahrzeuginnern.", "16px 'Porsche Next TT'");
	this.text_21.name = "text_21";
	this.text_21.lineHeight = 23;
	this.text_21.lineWidth = 496;
	this.text_21.setTransform(2,2);
	this.text_21._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_21).wait(20).to({_off:false},0).to({_off:true},1).wait(120));

	// Ebene 19
	this.text_20 = new cjs.Text("Luftreinigung", "32px 'Porsche Next TT Thin'");
	this.text_20.name = "text_20";
	this.text_20.lineHeight = 47;
	this.text_20.lineWidth = 1076;
	this.text_20.setTransform(2,2);
	this.text_20._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_20).wait(19).to({_off:false},0).to({_off:true},1).wait(121));

	// Ebene 16
	this.text_16 = new cjs.Text("Luftführungskanäle Sitze (hinten links)", "16px 'Porsche Next TT'");
	this.text_16.name = "text_16";
	this.text_16.lineHeight = 23;
	this.text_16.lineWidth = 446;
	this.text_16.setTransform(2,2);
	this.text_16._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_16).wait(15).to({_off:false},0).to({_off:true},1).wait(125));

	// Ebene 34
	this.text_15 = new cjs.Text("Luftführungskanal Mittelkonsole (hinten)", "16px 'Porsche Next TT'");
	this.text_15.name = "text_15";
	this.text_15.lineHeight = 23;
	this.text_15.lineWidth = 446;
	this.text_15.setTransform(2,2);
	this.text_15._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_15).wait(14).to({_off:false},0).to({_off:true},1).wait(126));

	// Ebene 30
	this.text_14 = new cjs.Text("Luftführungskanäle Sitze (hinten rechts)", "16px 'Porsche Next TT'");
	this.text_14.name = "text_14";
	this.text_14.lineHeight = 23;
	this.text_14.lineWidth = 446;
	this.text_14.setTransform(2,2);
	this.text_14._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_14).wait(13).to({_off:false},0).to({_off:true},1).wait(127));

	// Ebene 29
	this.text_13 = new cjs.Text("Luftführungskanal Personen Mitte (vorne)", "16px 'Porsche Next TT'");
	this.text_13.name = "text_13";
	this.text_13.lineHeight = 23;
	this.text_13.lineWidth = 446;
	this.text_13.setTransform(2,2);
	this.text_13._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_13).wait(12).to({_off:false},0).to({_off:true},1).wait(128));

	// Ebene 28
	this.text_12 = new cjs.Text("Luftführungskanal (vorne rechts)", "16px 'Porsche Next TT'");
	this.text_12.name = "text_12";
	this.text_12.lineHeight = 23;
	this.text_12.lineWidth = 446;
	this.text_12.setTransform(2,2);
	this.text_12._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_12).wait(11).to({_off:false},0).to({_off:true},1).wait(129));

	// Ebene 27
	this.text_11 = new cjs.Text("Luftführungskanal (vorne links)", "16px 'Porsche Next TT'");
	this.text_11.name = "text_11";
	this.text_11.lineHeight = 23;
	this.text_11.lineWidth = 446;
	this.text_11.setTransform(2,2);
	this.text_11._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_11).wait(10).to({_off:false},0).to({_off:true},1).wait(130));

	// Ebene 23
	this.text_10 = new cjs.Text("LED PDLS+-Scheinwerfer", "24px 'Porsche Next TT'");
	this.text_10.name = "text_10";
	this.text_10.lineHeight = 35;
	this.text_10.lineWidth = 476;
	this.text_10.setTransform(2,2);
	this.text_10._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_10).wait(9).to({_off:false},0).to({_off:true},1).wait(131));

	// Ebene 12
	this.text_08 = new cjs.Text("Das 10,9-Zoll-Touchdisplay erforderte eine Umgestaltung der Luftführung in der Klimaanlage. Neu ist die Luftführung der „Personendüse Mitte“ (roter Luftführungskanal im Bild).", "16px 'Porsche Next TT'");
	this.text_08.name = "text_08";
	this.text_08.lineHeight = 23;
	this.text_08.lineWidth = 1076;
	this.text_08.setTransform(2,2);
	this.text_08._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_08).wait(7).to({_off:false},0).to({_off:true},1).wait(133));

	// Ebene 7
	this.text_07 = new cjs.Text("Luftführung", "32px 'Porsche Next TT Thin'");
	this.text_07.name = "text_07";
	this.text_07.lineHeight = 47;
	this.text_07.lineWidth = 1076;
	this.text_07.setTransform(2,2);
	this.text_07._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_07).wait(6).to({_off:false},0).to({_off:true},1).wait(134));

	// Ebene 6
	this.text_06 = new cjs.Text("Der neue Zentralrechner PCM 5.1 besitzt als Anzeige- und Bedieneinheit ein hochauflösendes 10,9-Zoll-Touchdisplay.\nDarüber lassen sich die zahlreichen Funktionen Media, Telefon, Navigation und Fahrzeug Connect steuern.\nDie Bedienung erfolgt über Multi-Touch-Gestensteuerung.", "16px 'Porsche Next TT'");
	this.text_06.name = "text_06";
	this.text_06.lineHeight = 23;
	this.text_06.lineWidth = 496;
	this.text_06.setTransform(2,2);
	this.text_06._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_06).wait(5).to({_off:false},0).to({_off:true},1).wait(135));

	// Ebene 5
	this.text_05 = new cjs.Text("10,9-Zoll-Touchdisplay", "32px 'Porsche Next TT Thin'");
	this.text_05.name = "text_05";
	this.text_05.lineHeight = 47;
	this.text_05.lineWidth = 996;
	this.text_05.setTransform(2,2);
	this.text_05._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_05).wait(4).to({_off:false},0).to({_off:true},1).wait(136));

	// Ebene 4
	this.text_04 = new cjs.Text("Porsche Macan (MJ 19)", "16px 'Porsche Next TT'", "#FFFFFF");
	this.text_04.name = "text_04";
	this.text_04.textAlign = "center";
	this.text_04.lineHeight = 23;
	this.text_04.lineWidth = 316;
	this.text_04.setTransform(160,2);
	this.text_04._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_04).wait(3).to({_off:false},0).to({_off:true},1).wait(137));

	// Ebene 3
	this.text_03 = new cjs.Text("Porsche Macan (MJ 17)", "16px 'Porsche Next TT'", "#FFFFFF");
	this.text_03.name = "text_03";
	this.text_03.textAlign = "center";
	this.text_03.lineHeight = 23;
	this.text_03.lineWidth = 316;
	this.text_03.setTransform(160,2);
	this.text_03._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_03).wait(2).to({_off:false},0).to({_off:true},1).wait(138));

	// Ebene 2
	this.text_02 = new cjs.Text("Das innovative Bedienkonzept „Porsche Advanced Cockpit“ (PAC) wurde nun auch im Macan (MJ 19) eingeführt. \nGrößtes Highlight im Interieur ist das neue Full-HD-Touchdisplay. Dazu wurden extra die Bedienleiste unterhalb des Displays und die Luftausströmer neu designt.\n\nWeitere Highlights im Interieur sind: \n• Frontscheibenheizung\n• neue Luftführung „Personen Mitte“\n• der neue Anti-Allergen-Filter\n• optional der Ionisator der 2. Generation für die Luftreinigung\n• serienmäßig Multifunktionslenkrad\n• optional Multifunktions-GT-Sportlenkrad \n• optional Sport Chrono-Paket inkl. Mode-Schalter\n\nBitte bewegen Sie den Schieberegler und klicken Sie auf die Hotspots.", "16px 'Porsche Next TT'");
	this.text_02.name = "text_02";
	this.text_02.lineHeight = 23;
	this.text_02.lineWidth = 336;
	this.text_02.setTransform(2,2);
	this.text_02._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_02).wait(1).to({_off:false},0).to({_off:true},1).wait(139));

	// Ebene 1
	this.text_01 = new cjs.Text("Interieur", "32px 'Porsche Next TT Thin'");
	this.text_01.name = "text_01";
	this.text_01.lineHeight = 47;
	this.text_01.lineWidth = 356;
	this.text_01.setTransform(2,2);

	this.timeline.addTween(cjs.Tween.get(this.text_01).to({_off:true},1).wait(140));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,360,50.9);


(lib.container_pics = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// Ebene 4
	this.instance = new lib.c3p1_pic01();

	this.instance_1 = new lib.c3p1_pic02();

	this.instance_2 = new lib.c3p1_pic03();

	this.instance_3 = new lib.c3p1_pic04();

	this.instance_4 = new lib.c3p1_pic07();

	this.instance_5 = new lib.c3p1_pic08();

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[]},1).to({state:[{t:this.instance_4}]},2).to({state:[{t:this.instance_5}]},1).wait(1));

	// Ebene 3
	this.instance_6 = new lib.c3p1_pic05();

	this.instance_7 = new lib.c3p1_pic06();

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_6}]},4).to({state:[{t:this.instance_7}]},1).to({state:[]},1).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,1218,703);


(lib.btn_blind_circle = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AmDGEQiiihAAjjQAAjiCiihQChiiDiAAQDjAAChCiQCiChgBDiQABDjiiChQihChjjAAQjiAAihihg");
	this.shape.setTransform(55,55);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(3).to({_off:false},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.btn_blind = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#002F6C").s().p("Aj5D6IAAnzIHzAAIAAHzg");
	this.shape.setTransform(25,25);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(3).to({_off:false},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.btn_arrow_openSideBar = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{out:0,over:4,down:9});

	// Ebene 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ag/B9IBkh9Ihkh8IAbAAIBlB8IhlB9g");
	this.shape.setTransform(25,35);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(10));

	// Ebene 3
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#D5001C").s().p("Aj5FeIAAq7IHzAAIAAK7g");
	this.shape_1.setTransform(25,35);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(10));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,50,70);


(lib.ani_highlight_sliderHandle_ = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["rgba(213,0,28,0)","rgba(213,0,28,0.498)"],[0,1],0,0,0,0,0,27.3).s().p("AAADXQhYAAg+g/IgBAAQg/g/AAhZQAAhYBAg/QA+g/BYAAIAHABIACAAQBTADA8A7QA/A/AABYQAABZg/A/Qg9A7hTAEIgIAAg");

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.rf(["rgba(213,0,28,0)","rgba(213,0,28,0.498)"],[0,1],0,0,0,0,0,27.7).s().p("AAADfQhbAAhBhBIgBAAQhBhCAAhcQAAhbBChCQBBhBBbAAIAIAAIABAAQBXADA+A+QBBBCAABbQAABchBBCQg/A+hWADIgJAAg");

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.rf(["rgba(213,0,28,0)","rgba(213,0,28,0.498)"],[0,1],0,0,0,0,0,28).s().p("AAADoQhfgBhDhEIAAAAQhEhEgBhfQAAheBFhEQBDhEBfgBIAIABIABAAQBaACBABCQBEBEABBeQgBBfhEBEQhBBChZADIgJAAg");

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.rf(["rgba(213,0,28,0)","rgba(213,0,28,0.498)"],[0,1],0,0,0,0,0,28.4).s().p("AAADvQhiAAhGhGIAAAAQhGhHAAhiQAAhhBGhHQBGhGBiAAIAIAAIACAAQBdADBCBDQBGBHAABhQAABihGBHQhDBDhdADIgJAAg");

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.rf(["rgba(213,0,28,0)","rgba(213,0,28,0.498)"],[0,1],0,0,0,0,0,28.7).s().p("AAAD2QhlAAhHhIIgBAAQhIhIAAhmQgBhlBKhIQBHhIBlAAIAIAAIACAAQBgADBEBFQBIBIAABlQAABmhIBIQhFBFhfADIgKAAg");

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.rf(["rgba(213,0,28,0)","rgba(213,0,28,0.498)"],[0,1],0,0,0,0,0,29).s().p("AAAD9QhnABhLhLIAAAAQhLhKABhpQAAhoBKhKQBLhLBnABIAIAAIACAAQBjADBGBHQBLBKgBBoQABBphLBKQhHBHhiADIgKAAg");

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.rf(["rgba(213,0,28,0)","rgba(213,0,28,0.498)"],[0,1],0,0,0,0,0,29.3).s().p("AAAEEQhqAAhMhNIAAAAQhNhMAAhrQAAhqBNhMQBMhNBqAAIAIABIADAAQBkADBIBJQBNBMAABqQAABrhNBMQhIBJhlAEIgKAAg");

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.rf(["rgba(213,0,28,0)","rgba(213,0,28,0.498)"],[0,1],0,0,0,0,0,29.5).s().p("AAAEKQhtAAhNhOIgBAAQhOhPAAhtQAAhsBPhPQBNhOBtAAIAIABIADAAQBnADBKBKQBOBPAABsQAABthOBPQhLBKhnAEIgKAAg");

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.rf(["rgba(213,0,28,0)","rgba(213,0,28,0.498)"],[0,1],0,0,0,0,0,29.8).s().p("AAAEPQhvAAhPhQIAAAAQhQhPAAhwQAAhvBQhPQBPhQBvAAIAIABIADAAQBqACBKBNQBQBPAABvQAABwhQBPQhLBMhpAEIgLAAg");

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.rf(["rgba(213,0,28,0)","rgba(213,0,28,0.498)"],[0,1],0,0,0,0,0,30).s().p("AAAEUQhxAAhRhRIAAAAQhRhRAAhyQAAhxBRhRQBRhRBxAAIAJAAIACAAQBsAEBMBNQBRBRAABxQAAByhRBRQhOBNhqAEIgLAAg");

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.rf(["rgba(213,0,28,0)","rgba(213,0,28,0.498)"],[0,1],0,0,0,0,0,30.2).s().p("AAAEYQhzABhShTIAAAAQhThTABhzQAAhyBShTQBShTBzABIAJAAIACAAQBtAEBOBOQBTBTgBByQABBzhTBTQhOBOhtAEIgLAAg");

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.rf(["rgba(213,0,28,0)","rgba(213,0,28,0.498)"],[0,1],0,0,0,0,0,30.3).s().p("AAAEdQh1AAhShUIgBAAQhUhTAAh2QAAh1BVhTQBShUB1AAIAJABIADAAQBuADBPBQQBUBTAAB1QAAB2hUBTQhQBPhuAFIgLAAg");

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.rf(["rgba(213,0,28,0)","rgba(213,0,28,0.498)"],[0,1],0,0,0,0,0,30.5).s().p("AAAEgQh2AAhUhUIgBAAQhUhWAAh2QAAh1BVhWQBUhUB2AAIAJAAIADAAQBwAEBQBQQBUBWAAB1QAAB2hUBWQhRBQhwAEIgLAAg");

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.rf(["rgba(213,0,28,0)","rgba(213,0,28,0.498)"],[0,1],0,0,0,0,0,30.6).s().p("AAAEjQh3AAhVhVIgBAAQhVhWAAh4QAAh3BWhWQBVhVB3AAIAJABIADAAQBxADBRBRQBVBWAAB3QAAB4hVBWQhSBRhxAEIgLAAg");

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.rf(["rgba(213,0,28,0)","rgba(213,0,28,0.498)"],[0,1],0,0,0,0,0,30.7).s().p("AAAEmQh4gBhWhWIAAAAQhWhWgBh5QAAh4BXhWQBWhWB4gBIAJABIADAAQBzADBQBTQBWBWABB4QgBB5hWBWQhSBShxAFIgMAAg");

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.rf(["rgba(213,0,28,0)","rgba(213,0,28,0.498)"],[0,1],0,0,0,0,0,30.8).s().p("AAAEoQh5gBhWhWIgBAAQhWhXgBh6QAAh5BYhXQBWhWB5gBIAJABIADAAQB0ADBRBTQBWBXABB5QgBB6hWBXQhTBThyAEIgMAAg");

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.rf(["rgba(213,0,28,0)","rgba(213,0,28,0.498)"],[0,1],0,0,0,0,0,30.9).s().p("AAAEpQh6AAhWhXIgBAAQhXhYAAh6QgBh5BZhYQBWhXB6AAIAJAAIADAAQB0AEBSBTQBXBYAAB5QAAB6hXBYQhUBUhyADIgMAAg");

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.rf(["rgba(213,0,28,0)","rgba(213,0,28,0.498)"],[0,1],0,0,0,0,0,30.9).s().p("AAAEqQh6AAhXhXIgBAAQhXhYAAh7QgBh6BZhYQBXhXB6AAIAJAAIADAAQB1AEBSBTQBXBYAAB6QAAB7hXBYQhUBThzAEIgMAAg");

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.rf(["rgba(213,0,28,0)","rgba(213,0,28,0.498)"],[0,1],0,0,0,0,0,31).s().p("AAAErQh7AAhXhXIgBAAQhXhZAAh7QgBh6BZhZQBXhXB7AAIAJAAIADAAQB1ADBTBUQBXBZAAB6QAAB7hXBZQhVBUhzADIgMAAg");

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.rf(["rgba(213,0,28,0)","rgba(213,0,28,0.447)"],[0.094,1],0,0,0,0,0,31).s().p("AAAErQh7AAhXhXIgBAAQhXhZAAh7QgBh6BZhZQBXhXB7AAIAJAAIADAAQB1ADBTBUQBXBZAAB6QAAB7hXBZQhVBUhzADIgMAAg");

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.rf(["rgba(213,0,28,0)","rgba(213,0,28,0.4)"],[0.188,1],0,0,0,0,0,31).s().p("AAAErQh7AAhXhXIgBAAQhXhZAAh7QgBh6BZhZQBXhXB7AAIAJAAIADAAQB1ADBTBUQBXBZAAB6QAAB7hXBZQhVBUhzADIgMAAg");

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.rf(["rgba(213,0,28,0)","rgba(213,0,28,0.349)"],[0.282,1],0,0,0,0,0,31).s().p("AAAErQh7AAhXhXIgBAAQhXhZAAh7QgBh6BZhZQBXhXB7AAIAJAAIADAAQB1ADBTBUQBXBZAAB6QAAB7hXBZQhVBUhzADIgMAAg");

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.rf(["rgba(213,0,28,0)","rgba(213,0,28,0.298)"],[0.376,1],0,0,0,0,0,31).s().p("AAAErQh7AAhXhXIgBAAQhXhZAAh7QgBh6BZhZQBXhXB7AAIAJAAIADAAQB1ADBTBUQBXBZAAB6QAAB7hXBZQhVBUhzADIgMAAg");

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.rf(["rgba(213,0,28,0)","rgba(213,0,28,0.251)"],[0.475,1],0,0,0,0,0,31).s().p("AAAErQh7AAhXhXIgBAAQhXhZAAh7QgBh6BZhZQBXhXB7AAIAJAAIADAAQB1ADBTBUQBXBZAAB6QAAB7hXBZQhVBUhzADIgMAAg");

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.rf(["rgba(213,0,28,0)","rgba(213,0,28,0.2)"],[0.569,1],0,0,0,0,0,31).s().p("AAAErQh7AAhXhXIgBAAQhXhZAAh7QgBh6BZhZQBXhXB7AAIAJAAIADAAQB1ADBTBUQBXBZAAB6QAAB7hXBZQhVBUhzADIgMAAg");

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.rf(["rgba(213,0,28,0)","rgba(213,0,28,0.149)"],[0.663,1],0,0,0,0,0,31).s().p("AAAErQh7AAhXhXIgBAAQhXhZAAh7QgBh6BZhZQBXhXB7AAIAJAAIADAAQB1ADBTBUQBXBZAAB6QAAB7hXBZQhVBUhzADIgMAAg");

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.rf(["rgba(213,0,28,0)","rgba(213,0,28,0.098)"],[0.757,1],0,0,0,0,0,31).s().p("AAAErQh7AAhXhXIgBAAQhXhZAAh7QgBh6BZhZQBXhXB7AAIAJAAIADAAQB1ADBTBUQBXBZAAB6QAAB7hXBZQhVBUhzADIgMAAg");

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.rf(["rgba(213,0,28,0)","rgba(213,0,28,0.051)"],[0.851,1],0,0,0,0,0,31).s().p("AAAErQh7AAhXhXIgBAAQhXhZAAh7QgBh6BZhZQBXhXB7AAIAJAAIADAAQB1ADBTBUQBXBZAAB6QAAB7hXBZQhVBUhzADIgMAAg");

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-21.5,-21.5,43,43);


(lib.text21 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.instance = new lib.container_text("single",20);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,500,426.1);


(lib.scrollerContent_text_sideBar = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.instance = new lib.container_text("single",1);
	this.instance.setTransform(51.3,14.2,1,1,0,0,0,51.3,14.2);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,340,473);


(lib.scroller_500 = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.slider = new lib.scroller_handle();

	this.bg = new lib.scroller_back_500();
	this.bg.setTransform(2,0);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.bg},{t:this.slider}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,9,500);


(lib.scroller_450 = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.slider = new lib.scroller_handle();

	this.bg = new lib.scroller_back_450();
	this.bg.setTransform(2,0);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.bg},{t:this.slider}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,9,450);


(lib.pic_text_sideBar01 = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// Ebene 6
	this.scrollerItem = new lib.scroller_500();
	this.scrollerItem.setTransform(350,60);

	this.timeline.addTween(cjs.Tween.get(this.scrollerItem).wait(1));

	// container_text
	this.instance = new lib.container_text("single",0);
	this.instance.setTransform(51.3,14.2,1,1,0,0,0,51.3,14.2);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// container_text
	this.scrollerContent = new lib.scrollerContent_text_sideBar();
	this.scrollerContent.setTransform(0,60);

	this.timeline.addTween(cjs.Tween.get(this.scrollerContent).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,360,560);


(lib.pic_text_sideBar_back = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.instance = new lib.pic_plane_white();
	this.instance.setTransform(209,325,1,1,0,0,0,209,325);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,1158,530);


(lib.pic_circle = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#737278").s().p("AizCuQhFhFgBhpQABhnBFhMQBMhFBngBQBjABBLBFQBMBMAABnQAABphMBFQhLBMhjAAQhnAAhMhMg");

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#002F6C").s().p("AizCuQhFhFgBhpQABhnBFhMQBMhFBngBQBjABBLBFQBMBMAABnQAABphMBFQhLBMhjAAQhnAAhMhMg");

	this.instance = new lib.pic_circle02_();
	this.instance.shadow = new cjs.Shadow("#FFFFFF",0,0,4);

	this.instance_1 = new lib.pic_circle02_();
	this.instance_1.shadow = new cjs.Shadow("#FFFFFF",0,0,4);

	this.instance_2 = new lib.pic_circle03();
	this.instance_2.shadow = new cjs.Shadow("#FFFFFF",0,0,4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.instance_1},{t:this.instance}]},1).to({state:[{t:this.instance},{t:this.instance_2}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-25,-25,50,50);


(lib.croller_text21 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 2
	this.scrollerItem = new lib.scroller_450();
	this.scrollerItem.setTransform(515,0);

	this.timeline.addTween(cjs.Tween.get(this.scrollerItem).wait(1));

	// Ebene 1
	this.scrollerContent = new lib.text21();

	this.timeline.addTween(cjs.Tween.get(this.scrollerContent).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,524,450);


(lib.button_general = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{"out":0,"over":1,"down":2,visited:3});

	// timeline functions:
	this.frame_0 = function() {
		/*this.dispatchEvent(new createjs.Event("RESET"),true);*/
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(4));

	// Ebene 3
	this.instance = new lib.btn_blind_circle();
	this.instance.setTransform(0,0,0.515,0.515,0,0,0,55,54.9);
	new cjs.ButtonHelper(this.instance, 0, 1, 2, false, new lib.btn_blind_circle(), 3);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(4));

	// Ebene 4
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgOBKIAAg7Ig7AAIAAgdIA7AAIAAg7IAdAAIAAA7IA7AAIAAAdIg7AAIAAA7g");

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#FFFFFF").ss(1,0,0,4).p("AAAiuQBIAAAzA0QA0AzAABHQAABIg0AzQgzA0hIAAQhHAAgzg0Qg0gzAAhIQAAhHA0gzQAzg0BHAAg");

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#D5001C").s().p("Ah6B7QgzgzAAhIQAAhHAzgzQAzgzBHAAQBIAAAzAzQAzAzAABHQAABIgzAzQgzAzhIAAQhHAAgzgzg");

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#737278").s().p("Ah6B7QgzgzAAhIQAAhHAzgzQAzgzBHAAQBIAAAzAzQAzAzAABHQAABIgzAzQgzAzhIAAQhHAAgzgzg");

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_3},{t:this.shape_1},{t:this.shape}]},3).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-28.3,-28.3,56.7,56.7);


(lib.btn_close02 = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// background
	this.instance = new lib.btn_blind();
	this.instance.setTransform(12,11.7,0.48,0.48,0,0,0,24.9,25);
	new cjs.ButtonHelper(this.instance, 0, 1, 2, false, new lib.btn_blind(), 3);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Ebene 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#333333").ss(1.5,2,1).p("Ah0h1IB0B0Ih3B3AAAgBIB3B3AB0h1Ih0B0");
	this.shape.setTransform(12,11.8);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1.4,-1.4,26.8,26.5);


(lib.ani_text_sideBar01_ = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{end:12});

	// timeline functions:
	this.frame_1 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(1).call(this.frame_1).wait(12));

	// pic_arrow_textbox
	this.button_play_parent = new lib.btn_arrow_openSideBar();
	this.button_play_parent.setTransform(20,320,1,1,0,0,0,20,20);

	this.timeline.addTween(cjs.Tween.get(this.button_play_parent).wait(2).to({visible:false},0).wait(11));

	// pic_arrow_textbox
	this.button_back_parent = new lib.btn_arrow_openSideBar();
	this.button_back_parent.setTransform(-485.9,276.9,1,1,0,0,0,20,20);
	this.button_back_parent.visible = false;

	this.timeline.addTween(cjs.Tween.get(this.button_back_parent).wait(12).to({regX:25,regY:35,skewY:180,x:443,y:335,visible:true},0).wait(1));

	// Ebene 5
	this.scrollerWidget = new lib.pic_text_sideBar01();
	this.scrollerWidget.setTransform(-218,330,1,1,0,0,0,160,280);

	this.timeline.addTween(cjs.Tween.get(this.scrollerWidget).wait(2).to({x:200},10).wait(1));

	// pic_plane_white
	this.instance = new lib.pic_text_sideBar_back();
	this.instance.setTransform(-337.7,431.1,0.361,1.326,0,0,0,222.3,325);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(2).to({regX:222.5,x:80.3},10).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-505.9,0,556,703);


(lib.ani_text_sideBar01 = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{I:12});

	// Ebene 1
	this.instance = new lib.ani_text_sideBar01_("synched",2,false);
	this.instance.setTransform(209,325,1,1,0,0,0,209,325);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(12).to({mode:"independent"},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-505.9,0,556,703);


(lib.ani_slider_filters = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{slide1:0,slide2:14,slide3:29});

	// Ebene 6
	this.instance = new lib.container_text("single",23);
	this.instance.setTransform(10,370);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(14).to({_off:false},0).to({alpha:1},15).wait(11));

	// Ebene 3
	this.instance_1 = new lib.container_pics("single",5);
	this.instance_1.setTransform(0.4,0.4,1,1,0,0,0,0.4,0.4);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(14).to({_off:false},0).to({alpha:1},15).wait(11));

	// Ebene 5
	this.instance_2 = new lib.container_text("single",22);
	this.instance_2.setTransform(10,370);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1).to({_off:false},0).to({alpha:1},13).wait(26));

	// Ebene 2
	this.instance_3 = new lib.container_pics("single",4);
	this.instance_3.setTransform(0.4,0.4,1,1,0,0,0,0.4,0.4);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(1).to({_off:false},0).to({alpha:1},13).wait(26));

	// container_text
	this.instance_4 = new lib.container_text("single",21);
	this.instance_4.setTransform(10,370);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(40));

	// Ebene 1
	this.instance_5 = new lib.container_pics("single",6);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(40));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,550,450);


(lib.ani_highlight_sliderHandle = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.dispatchEvent(new createjs.Event("RESET"),true);
	}
	this.frame_89 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(89).call(this.frame_89).wait(1));

	// Ebene 1
	this.instance = new lib.ani_highlight_sliderHandle_("synched",0);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(29).to({startPosition:0},0).wait(29).to({startPosition:0},0).to({_off:true},29).wait(3));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-21.5,-21.5,43,43);


(lib.ani_fadeIn = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.loop = true;
	}
	this.frame_9 = function() {
		this.loop = true;
	}
	this.frame_10 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(9).call(this.frame_9).wait(1).call(this.frame_10).wait(1));

	// Ebene 1
	this.instance = new lib.pic_plane_white();
	this.instance.setTransform(609,351.5,1.052,1.326,0,0,0,579,265);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({alpha:0},9).to({_off:true},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,1218,703);


(lib.ani_comparison_Front_ = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// mask_red -> revealing (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("EgITA26MAAAht0IQnAAMAAABt0g");
	var mask_graphics_1 = new cjs.Graphics().p("EgIYA26MAAAht0IQxAAMAAABt0g");
	var mask_graphics_2 = new cjs.Graphics().p("EgIeA26MAAAht0IQ9AAMAAABt0g");
	var mask_graphics_3 = new cjs.Graphics().p("EgIjA26MAAAht0IRHAAMAAABt0g");
	var mask_graphics_4 = new cjs.Graphics().p("EgIpA26MAAAht0IRTAAMAAABt0g");
	var mask_graphics_5 = new cjs.Graphics().p("EgIuA26MAAAht0IRdAAMAAABt0g");
	var mask_graphics_6 = new cjs.Graphics().p("EgI0A26MAAAht0IRpAAMAAABt0g");
	var mask_graphics_7 = new cjs.Graphics().p("EgI5A26MAAAht0IRzAAMAAABt0g");
	var mask_graphics_8 = new cjs.Graphics().p("EgI/A26MAAAht0IR/AAMAAABt0g");
	var mask_graphics_9 = new cjs.Graphics().p("EgJEA26MAAAht0ISJAAMAAABt0g");
	var mask_graphics_10 = new cjs.Graphics().p("EgJJA26MAAAht0ISTAAMAAABt0g");
	var mask_graphics_11 = new cjs.Graphics().p("EgJPA26MAAAht0ISfAAMAAABt0g");
	var mask_graphics_12 = new cjs.Graphics().p("EgJUA26MAAAht0ISpAAMAAABt0g");
	var mask_graphics_13 = new cjs.Graphics().p("EgJZA26MAAAht0IS0AAMAAABt0g");
	var mask_graphics_14 = new cjs.Graphics().p("EgJfA26MAAAht0IS/AAMAAABt0g");
	var mask_graphics_15 = new cjs.Graphics().p("EgJlA26MAAAht0ITLAAMAAABt0g");
	var mask_graphics_16 = new cjs.Graphics().p("EgJqA26MAAAht0ITVAAMAAABt0g");
	var mask_graphics_17 = new cjs.Graphics().p("EgJvA26MAAAht0ITfAAMAAABt0g");
	var mask_graphics_18 = new cjs.Graphics().p("EgJ1A26MAAAht0ITrAAMAAABt0g");
	var mask_graphics_19 = new cjs.Graphics().p("EgJ6A26MAAAht0IT1AAMAAABt0g");
	var mask_graphics_20 = new cjs.Graphics().p("EgJ/A26MAAAht0IT/AAMAAABt0g");
	var mask_graphics_21 = new cjs.Graphics().p("EgKFA26MAAAht0IULAAMAAABt0g");
	var mask_graphics_22 = new cjs.Graphics().p("EgKLA26MAAAht0IUWAAMAAABt0g");
	var mask_graphics_23 = new cjs.Graphics().p("EgKQA26MAAAht0IUhAAMAAABt0g");
	var mask_graphics_24 = new cjs.Graphics().p("EgKVA26MAAAht0IUrAAMAAABt0g");
	var mask_graphics_25 = new cjs.Graphics().p("EgKbA27MAAAht0IU3AAMAAABt0g");
	var mask_graphics_26 = new cjs.Graphics().p("EgKgA27MAAAht0IVBAAMAAABt0g");
	var mask_graphics_27 = new cjs.Graphics().p("EgKmA27MAAAht0IVNAAMAAABt0g");
	var mask_graphics_28 = new cjs.Graphics().p("EgKrA27MAAAht0IVXAAMAAABt0g");
	var mask_graphics_29 = new cjs.Graphics().p("EgKwA27MAAAht0IViAAMAAABt0g");
	var mask_graphics_30 = new cjs.Graphics().p("EgK2A27MAAAht0IVtAAMAAABt0g");
	var mask_graphics_31 = new cjs.Graphics().p("EgK7A27MAAAht0IV3AAMAAABt0g");
	var mask_graphics_32 = new cjs.Graphics().p("EgLBA27MAAAht0IWDAAMAAABt0g");
	var mask_graphics_33 = new cjs.Graphics().p("EgLGA27MAAAht0IWNAAMAAABt0g");
	var mask_graphics_34 = new cjs.Graphics().p("EgLMA27MAAAht0IWZAAMAAABt0g");
	var mask_graphics_35 = new cjs.Graphics().p("EgLRA27MAAAht0IWjAAMAAABt0g");
	var mask_graphics_36 = new cjs.Graphics().p("EgLWA27MAAAht0IWtAAMAAABt0g");
	var mask_graphics_37 = new cjs.Graphics().p("EgLcA27MAAAht0IW5AAMAAABt0g");
	var mask_graphics_38 = new cjs.Graphics().p("EgLhA27MAAAht0IXDAAMAAABt0g");
	var mask_graphics_39 = new cjs.Graphics().p("EgLnA27MAAAht0IXPAAMAAABt0g");
	var mask_graphics_40 = new cjs.Graphics().p("EgLsA27MAAAht0IXZAAMAAABt0g");
	var mask_graphics_41 = new cjs.Graphics().p("EgLyA27MAAAht0IXlAAMAAABt0g");
	var mask_graphics_42 = new cjs.Graphics().p("EgL3A27MAAAht0IXvAAMAAABt0g");
	var mask_graphics_43 = new cjs.Graphics().p("EgL8A27MAAAht0IX5AAMAAABt0g");
	var mask_graphics_44 = new cjs.Graphics().p("EgMCA27MAAAht0IYFAAMAAABt0g");
	var mask_graphics_45 = new cjs.Graphics().p("EgMHA27MAAAht0IYPAAMAAABt0g");
	var mask_graphics_46 = new cjs.Graphics().p("EgMMA27MAAAht0IYaAAMAAABt0g");
	var mask_graphics_47 = new cjs.Graphics().p("EgMSA27MAAAht0IYlAAMAAABt0g");
	var mask_graphics_48 = new cjs.Graphics().p("EgMYA27MAAAht0IYxAAMAAABt0g");
	var mask_graphics_49 = new cjs.Graphics().p("EgMdA27MAAAht0IY7AAMAAABt0g");
	var mask_graphics_50 = new cjs.Graphics().p("EgMiA27MAAAht0IZGAAMAAABt0g");
	var mask_graphics_51 = new cjs.Graphics().p("EgMoA27MAAAht0IZRAAMAAABt0g");
	var mask_graphics_52 = new cjs.Graphics().p("EgMtA27MAAAht0IZbAAMAAABt0g");
	var mask_graphics_53 = new cjs.Graphics().p("EgMzA27MAAAht0IZnAAMAAABt0g");
	var mask_graphics_54 = new cjs.Graphics().p("EgM4A27MAAAht0IZxAAMAAABt0g");
	var mask_graphics_55 = new cjs.Graphics().p("EgM9A27MAAAht0IZ7AAMAAABt0g");
	var mask_graphics_56 = new cjs.Graphics().p("EgNDA27MAAAht0IaHAAMAAABt0g");
	var mask_graphics_57 = new cjs.Graphics().p("EgNJA27MAAAht0IaSAAMAAABt0g");
	var mask_graphics_58 = new cjs.Graphics().p("EgNOA27MAAAht0IadAAMAAABt0g");
	var mask_graphics_59 = new cjs.Graphics().p("EgNTA27MAAAht0IanAAMAAABt0g");
	var mask_graphics_60 = new cjs.Graphics().p("EgNZA27MAAAht0IazAAMAAABt0g");
	var mask_graphics_61 = new cjs.Graphics().p("EgNeA27MAAAht0Ia9AAMAAABt0g");
	var mask_graphics_62 = new cjs.Graphics().p("EgNjA27MAAAht0IbIAAMAAABt0g");
	var mask_graphics_63 = new cjs.Graphics().p("EgNpA27MAAAht0IbTAAMAAABt0g");
	var mask_graphics_64 = new cjs.Graphics().p("EgNvA27MAAAht0IbfAAMAAABt0g");
	var mask_graphics_65 = new cjs.Graphics().p("EgN0A27MAAAht0IbpAAMAAABt0g");
	var mask_graphics_66 = new cjs.Graphics().p("EgN5A27MAAAht0IbzAAMAAABt0g");
	var mask_graphics_67 = new cjs.Graphics().p("EgN/A27MAAAht0Ib/AAMAAABt0g");
	var mask_graphics_68 = new cjs.Graphics().p("EgOEA27MAAAht0IcJAAMAAABt0g");
	var mask_graphics_69 = new cjs.Graphics().p("EgOKA27MAAAht0IcVAAMAAABt0g");
	var mask_graphics_70 = new cjs.Graphics().p("EgOPA27MAAAht0IcfAAMAAABt0g");
	var mask_graphics_71 = new cjs.Graphics().p("EgOUA27MAAAht0IcpAAMAAABt0g");
	var mask_graphics_72 = new cjs.Graphics().p("EgOaA27MAAAht0Ic1AAMAAABt0g");
	var mask_graphics_73 = new cjs.Graphics().p("EgOfA27MAAAht0Ic/AAMAAABt0g");
	var mask_graphics_74 = new cjs.Graphics().p("EgOlA27MAAAht0IdLAAMAAABt0g");
	var mask_graphics_75 = new cjs.Graphics().p("EgOqA26MAAAht0IdVAAMAAABt0g");
	var mask_graphics_76 = new cjs.Graphics().p("EgOvA26MAAAht0IdgAAMAAABt0g");
	var mask_graphics_77 = new cjs.Graphics().p("EgO1A26MAAAht0IdrAAMAAABt0g");
	var mask_graphics_78 = new cjs.Graphics().p("EgO6A26MAAAht0Id1AAMAAABt0g");
	var mask_graphics_79 = new cjs.Graphics().p("EgPAA26MAAAht0IeBAAMAAABt0g");
	var mask_graphics_80 = new cjs.Graphics().p("EgPFA26MAAAht0IeLAAMAAABt0g");
	var mask_graphics_81 = new cjs.Graphics().p("EgPLA26MAAAht0IeWAAMAAABt0g");
	var mask_graphics_82 = new cjs.Graphics().p("EgPQA26MAAAht0IehAAMAAABt0g");
	var mask_graphics_83 = new cjs.Graphics().p("EgPWA26MAAAht0IesAAMAAABt0g");
	var mask_graphics_84 = new cjs.Graphics().p("EgPbA26MAAAht0Ie3AAMAAABt0g");
	var mask_graphics_85 = new cjs.Graphics().p("EgPgA26MAAAht0IfBAAMAAABt0g");
	var mask_graphics_86 = new cjs.Graphics().p("EgPmA26MAAAht0IfNAAMAAABt0g");
	var mask_graphics_87 = new cjs.Graphics().p("EgPrA26MAAAht0IfXAAMAAABt0g");
	var mask_graphics_88 = new cjs.Graphics().p("EgPwA26MAAAht0IfhAAMAAABt0g");
	var mask_graphics_89 = new cjs.Graphics().p("EgP2A26MAAAht0IftAAMAAABt0g");
	var mask_graphics_90 = new cjs.Graphics().p("EgP8A26MAAAht0If4AAMAAABt0g");
	var mask_graphics_91 = new cjs.Graphics().p("EgQBA26MAAAht0MAgDAAAMAAABt0g");
	var mask_graphics_92 = new cjs.Graphics().p("EgQGA26MAAAht0MAgNAAAMAAABt0g");
	var mask_graphics_93 = new cjs.Graphics().p("EgQMA26MAAAht0MAgZAAAMAAABt0g");
	var mask_graphics_94 = new cjs.Graphics().p("EgQRA26MAAAht0MAgjAAAMAAABt0g");
	var mask_graphics_95 = new cjs.Graphics().p("EgQXA26MAAAht0MAgvAAAMAAABt0g");
	var mask_graphics_96 = new cjs.Graphics().p("EgQcA26MAAAht0MAg5AAAMAAABt0g");
	var mask_graphics_97 = new cjs.Graphics().p("EgQiA26MAAAht0MAhFAAAMAAABt0g");
	var mask_graphics_98 = new cjs.Graphics().p("EgQnA26MAAAht0MAhPAAAMAAABt0g");
	var mask_graphics_99 = new cjs.Graphics().p("EgQtA26MAAAht0MAhbAAAMAAABt0g");
	var mask_graphics_100 = new cjs.Graphics().p("EgQyA26MAAAht0MAhlAAAMAAABt0g");
	var mask_graphics_101 = new cjs.Graphics().p("EgQ3A26MAAAht0MAhvAAAMAAABt0g");
	var mask_graphics_102 = new cjs.Graphics().p("EgQ9A26MAAAht0MAh7AAAMAAABt0g");
	var mask_graphics_103 = new cjs.Graphics().p("EgRCA26MAAAht0MAiFAAAMAAABt0g");
	var mask_graphics_104 = new cjs.Graphics().p("EgRIA26MAAAht0MAiRAAAMAAABt0g");
	var mask_graphics_105 = new cjs.Graphics().p("EgRNA26MAAAht0MAibAAAMAAABt0g");
	var mask_graphics_106 = new cjs.Graphics().p("EgRSA26MAAAht0MAilAAAMAAABt0g");
	var mask_graphics_107 = new cjs.Graphics().p("EgRYA26MAAAht0MAixAAAMAAABt0g");
	var mask_graphics_108 = new cjs.Graphics().p("EgRdA26MAAAht0MAi7AAAMAAABt0g");
	var mask_graphics_109 = new cjs.Graphics().p("EgRjA26MAAAht0MAjHAAAMAAABt0g");
	var mask_graphics_110 = new cjs.Graphics().p("EgRoA26MAAAht0MAjRAAAMAAABt0g");
	var mask_graphics_111 = new cjs.Graphics().p("EgRuA26MAAAht0MAjdAAAMAAABt0g");
	var mask_graphics_112 = new cjs.Graphics().p("EgRzA26MAAAht0MAjnAAAMAAABt0g");
	var mask_graphics_113 = new cjs.Graphics().p("EgR4A26MAAAht0MAjxAAAMAAABt0g");
	var mask_graphics_114 = new cjs.Graphics().p("EgR+A26MAAAht0MAj9AAAMAAABt0g");
	var mask_graphics_115 = new cjs.Graphics().p("EgSDA26MAAAht0MAkHAAAMAAABt0g");
	var mask_graphics_116 = new cjs.Graphics().p("EgSJA26MAAAht0MAkSAAAMAAABt0g");
	var mask_graphics_117 = new cjs.Graphics().p("EgSOA26MAAAht0MAkdAAAMAAABt0g");
	var mask_graphics_118 = new cjs.Graphics().p("EgSTA26MAAAht0MAknAAAMAAABt0g");
	var mask_graphics_119 = new cjs.Graphics().p("EgSZA26MAAAht0MAkzAAAMAAABt0g");
	var mask_graphics_120 = new cjs.Graphics().p("EgSeA26MAAAht0MAk9AAAMAAABt0g");
	var mask_graphics_121 = new cjs.Graphics().p("EgSkA26MAAAht0MAlJAAAMAAABt0g");
	var mask_graphics_122 = new cjs.Graphics().p("EgSpA26MAAAht0MAlTAAAMAAABt0g");
	var mask_graphics_123 = new cjs.Graphics().p("EgSvA26MAAAht0MAlfAAAMAAABt0g");
	var mask_graphics_124 = new cjs.Graphics().p("EgS0A26MAAAht0MAlpAAAMAAABt0g");
	var mask_graphics_125 = new cjs.Graphics().p("EgS5A27MAAAht1MAl0AAAMAAABt1g");
	var mask_graphics_126 = new cjs.Graphics().p("EgS/A27MAAAht1MAl/AAAMAAABt1g");
	var mask_graphics_127 = new cjs.Graphics().p("EgTEA27MAAAht1MAmJAAAMAAABt1g");
	var mask_graphics_128 = new cjs.Graphics().p("EgTKA27MAAAht1MAmVAAAMAAABt1g");
	var mask_graphics_129 = new cjs.Graphics().p("EgTPA27MAAAht1MAmfAAAMAAABt1g");
	var mask_graphics_130 = new cjs.Graphics().p("EgTUA27MAAAht1MAmqAAAMAAABt1g");
	var mask_graphics_131 = new cjs.Graphics().p("EgTaA27MAAAht1MAm1AAAMAAABt1g");
	var mask_graphics_132 = new cjs.Graphics().p("EgTgA27MAAAht1MAnBAAAMAAABt1g");
	var mask_graphics_133 = new cjs.Graphics().p("EgTlA27MAAAht1MAnLAAAMAAABt1g");
	var mask_graphics_134 = new cjs.Graphics().p("EgTqA27MAAAht1MAnWAAAMAAABt1g");
	var mask_graphics_135 = new cjs.Graphics().p("EgTwA27MAAAht1MAnhAAAMAAABt1g");
	var mask_graphics_136 = new cjs.Graphics().p("EgT1A27MAAAht1MAnrAAAMAAABt1g");
	var mask_graphics_137 = new cjs.Graphics().p("EgT7A27MAAAht1MAn3AAAMAAABt1g");
	var mask_graphics_138 = new cjs.Graphics().p("EgUAA27MAAAht1MAoBAAAMAAABt1g");
	var mask_graphics_139 = new cjs.Graphics().p("EgUGA27MAAAht1MAoMAAAMAAABt1g");
	var mask_graphics_140 = new cjs.Graphics().p("EgULA27MAAAht1MAoXAAAMAAABt1g");
	var mask_graphics_141 = new cjs.Graphics().p("EgUQA27MAAAht1MAohAAAMAAABt1g");
	var mask_graphics_142 = new cjs.Graphics().p("EgUWA27MAAAht1MAotAAAMAAABt1g");
	var mask_graphics_143 = new cjs.Graphics().p("EgUbA27MAAAht1MAo3AAAMAAABt1g");
	var mask_graphics_144 = new cjs.Graphics().p("EgUhA27MAAAht1MApDAAAMAAABt1g");
	var mask_graphics_145 = new cjs.Graphics().p("EgUmA27MAAAht1MApNAAAMAAABt1g");
	var mask_graphics_146 = new cjs.Graphics().p("EgUsA27MAAAht1MApZAAAMAAABt1g");
	var mask_graphics_147 = new cjs.Graphics().p("EgUxA27MAAAht1MApjAAAMAAABt1g");
	var mask_graphics_148 = new cjs.Graphics().p("EgU2A27MAAAht1MAptAAAMAAABt1g");
	var mask_graphics_149 = new cjs.Graphics().p("EgU8A27MAAAht1MAp5AAAMAAABt1g");
	var mask_graphics_150 = new cjs.Graphics().p("EgVBA27MAAAht1MAqDAAAMAAABt1g");
	var mask_graphics_151 = new cjs.Graphics().p("EgVGA27MAAAht1MAqNAAAMAAABt1g");
	var mask_graphics_152 = new cjs.Graphics().p("EgVMA27MAAAht1MAqZAAAMAAABt1g");
	var mask_graphics_153 = new cjs.Graphics().p("EgVSA27MAAAht1MAqkAAAMAAABt1g");
	var mask_graphics_154 = new cjs.Graphics().p("EgVXA27MAAAht1MAqvAAAMAAABt1g");
	var mask_graphics_155 = new cjs.Graphics().p("EgVcA27MAAAht1MAq5AAAMAAABt1g");
	var mask_graphics_156 = new cjs.Graphics().p("EgViA27MAAAht1MArFAAAMAAABt1g");
	var mask_graphics_157 = new cjs.Graphics().p("EgVnA27MAAAht1MArPAAAMAAABt1g");
	var mask_graphics_158 = new cjs.Graphics().p("EgVtA27MAAAht1MArbAAAMAAABt1g");
	var mask_graphics_159 = new cjs.Graphics().p("EgVyA27MAAAht1MArlAAAMAAABt1g");
	var mask_graphics_160 = new cjs.Graphics().p("EgV3A27MAAAht1MArwAAAMAAABt1g");
	var mask_graphics_161 = new cjs.Graphics().p("EgV9A27MAAAht1MAr7AAAMAAABt1g");
	var mask_graphics_162 = new cjs.Graphics().p("EgWCA27MAAAht1MAsFAAAMAAABt1g");
	var mask_graphics_163 = new cjs.Graphics().p("EgWIA27MAAAht1MAsRAAAMAAABt1g");
	var mask_graphics_164 = new cjs.Graphics().p("EgWNA27MAAAht1MAsbAAAMAAABt1g");
	var mask_graphics_165 = new cjs.Graphics().p("EgWTA27MAAAht1MAsnAAAMAAABt1g");
	var mask_graphics_166 = new cjs.Graphics().p("EgWYA27MAAAht1MAsxAAAMAAABt1g");
	var mask_graphics_167 = new cjs.Graphics().p("EgWdA27MAAAht1MAs8AAAMAAABt1g");
	var mask_graphics_168 = new cjs.Graphics().p("EgWjA27MAAAht1MAtHAAAMAAABt1g");
	var mask_graphics_169 = new cjs.Graphics().p("EgWpA27MAAAht1MAtTAAAMAAABt1g");
	var mask_graphics_170 = new cjs.Graphics().p("EgWuA27MAAAht1MAtdAAAMAAABt1g");
	var mask_graphics_171 = new cjs.Graphics().p("EgWzA27MAAAht1MAtnAAAMAAABt1g");
	var mask_graphics_172 = new cjs.Graphics().p("EgW5A27MAAAht1MAtyAAAMAAABt1g");
	var mask_graphics_173 = new cjs.Graphics().p("EgW+A27MAAAht1MAt9AAAMAAABt1g");
	var mask_graphics_174 = new cjs.Graphics().p("EgXEA27MAAAht1MAuIAAAMAAABt1g");
	var mask_graphics_175 = new cjs.Graphics().p("EgXJA26MAAAhtzMAuTAAAMAAABtzg");
	var mask_graphics_176 = new cjs.Graphics().p("EgXOA26MAAAhtzMAudAAAMAAABtzg");
	var mask_graphics_177 = new cjs.Graphics().p("EgXUA26MAAAhtzMAupAAAMAAABtzg");
	var mask_graphics_178 = new cjs.Graphics().p("EgXZA26MAAAhtzMAuzAAAMAAABtzg");
	var mask_graphics_179 = new cjs.Graphics().p("EgXfA26MAAAhtzMAu/AAAMAAABtzg");
	var mask_graphics_180 = new cjs.Graphics().p("EgXkA26MAAAhtzMAvJAAAMAAABtzg");
	var mask_graphics_181 = new cjs.Graphics().p("EgXpA26MAAAhtzMAvTAAAMAAABtzg");
	var mask_graphics_182 = new cjs.Graphics().p("EgXvA26MAAAhtzMAvfAAAMAAABtzg");
	var mask_graphics_183 = new cjs.Graphics().p("EgX0A26MAAAhtzMAvpAAAMAAABtzg");
	var mask_graphics_184 = new cjs.Graphics().p("EgX6A26MAAAhtzMAv1AAAMAAABtzg");
	var mask_graphics_185 = new cjs.Graphics().p("EgX/A26MAAAhtzMAv/AAAMAAABtzg");
	var mask_graphics_186 = new cjs.Graphics().p("EgYFA26MAAAhtzMAwKAAAMAAABtzg");
	var mask_graphics_187 = new cjs.Graphics().p("EgYKA26MAAAhtzMAwVAAAMAAABtzg");
	var mask_graphics_188 = new cjs.Graphics().p("EgYPA26MAAAhtzMAwfAAAMAAABtzg");
	var mask_graphics_189 = new cjs.Graphics().p("EgYVA26MAAAhtzMAwrAAAMAAABtzg");
	var mask_graphics_190 = new cjs.Graphics().p("EgYaA26MAAAhtzMAw1AAAMAAABtzg");
	var mask_graphics_191 = new cjs.Graphics().p("EgYgA26MAAAhtzMAxBAAAMAAABtzg");
	var mask_graphics_192 = new cjs.Graphics().p("EgYlA26MAAAhtzMAxLAAAMAAABtzg");
	var mask_graphics_193 = new cjs.Graphics().p("EgYqA26MAAAhtzMAxWAAAMAAABtzg");
	var mask_graphics_194 = new cjs.Graphics().p("EgYwA26MAAAhtzMAxhAAAMAAABtzg");
	var mask_graphics_195 = new cjs.Graphics().p("EgY2A26MAAAhtzMAxtAAAMAAABtzg");
	var mask_graphics_196 = new cjs.Graphics().p("EgY7A26MAAAhtzMAx3AAAMAAABtzg");
	var mask_graphics_197 = new cjs.Graphics().p("EgZAA26MAAAhtzMAyBAAAMAAABtzg");
	var mask_graphics_198 = new cjs.Graphics().p("EgZGA26MAAAhtzMAyNAAAMAAABtzg");
	var mask_graphics_199 = new cjs.Graphics().p("EgZLA26MAAAhtzMAyXAAAMAAABtzg");
	var mask_graphics_200 = new cjs.Graphics().p("EgZQA26MAAAhtzMAyhAAAMAAABtzg");
	var mask_graphics_201 = new cjs.Graphics().p("EgZWA26MAAAhtzMAytAAAMAAABtzg");
	var mask_graphics_202 = new cjs.Graphics().p("EgZcA26MAAAhtzMAy4AAAMAAABtzg");
	var mask_graphics_203 = new cjs.Graphics().p("EgZhA26MAAAhtzMAzDAAAMAAABtzg");
	var mask_graphics_204 = new cjs.Graphics().p("EgZnA26MAAAhtzMAzOAAAMAAABtzg");
	var mask_graphics_205 = new cjs.Graphics().p("EgZsA26MAAAhtzMAzZAAAMAAABtzg");
	var mask_graphics_206 = new cjs.Graphics().p("EgZxA26MAAAhtzMAzjAAAMAAABtzg");
	var mask_graphics_207 = new cjs.Graphics().p("EgZ3A26MAAAhtzMAzvAAAMAAABtzg");
	var mask_graphics_208 = new cjs.Graphics().p("EgZ8A26MAAAhtzMAz5AAAMAAABtzg");
	var mask_graphics_209 = new cjs.Graphics().p("EgaBA26MAAAhtzMA0DAAAMAAABtzg");
	var mask_graphics_210 = new cjs.Graphics().p("EgaHA26MAAAhtzMA0PAAAMAAABtzg");
	var mask_graphics_211 = new cjs.Graphics().p("EgaMA26MAAAhtzMA0ZAAAMAAABtzg");
	var mask_graphics_212 = new cjs.Graphics().p("EgaSA26MAAAhtzMA0lAAAMAAABtzg");
	var mask_graphics_213 = new cjs.Graphics().p("EgaXA26MAAAhtzMA0vAAAMAAABtzg");
	var mask_graphics_214 = new cjs.Graphics().p("EgadA26MAAAhtzMA07AAAMAAABtzg");
	var mask_graphics_215 = new cjs.Graphics().p("EgaiA26MAAAhtzMA1FAAAMAAABtzg");
	var mask_graphics_216 = new cjs.Graphics().p("EganA26MAAAhtzMA1PAAAMAAABtzg");
	var mask_graphics_217 = new cjs.Graphics().p("EgatA26MAAAhtzMA1bAAAMAAABtzg");
	var mask_graphics_218 = new cjs.Graphics().p("EgayA26MAAAhtzMA1lAAAMAAABtzg");
	var mask_graphics_219 = new cjs.Graphics().p("Ega4A26MAAAhtzMA1xAAAMAAABtzg");
	var mask_graphics_220 = new cjs.Graphics().p("Ega9A26MAAAhtzMA17AAAMAAABtzg");
	var mask_graphics_221 = new cjs.Graphics().p("EgbDA26MAAAhtzMA2HAAAMAAABtzg");
	var mask_graphics_222 = new cjs.Graphics().p("EgbIA26MAAAhtzMA2RAAAMAAABtzg");
	var mask_graphics_223 = new cjs.Graphics().p("EgbNA26MAAAhtzMA2bAAAMAAABtzg");
	var mask_graphics_224 = new cjs.Graphics().p("EgbTA26MAAAhtzMA2nAAAMAAABtzg");
	var mask_graphics_225 = new cjs.Graphics().p("EgbYA26MAAAht0MA2xAAAMAAABt0g");
	var mask_graphics_226 = new cjs.Graphics().p("EgbdA26MAAAht0MA28AAAMAAABt0g");
	var mask_graphics_227 = new cjs.Graphics().p("EgbjA26MAAAht0MA3HAAAMAAABt0g");
	var mask_graphics_228 = new cjs.Graphics().p("EgbpA26MAAAht0MA3TAAAMAAABt0g");
	var mask_graphics_229 = new cjs.Graphics().p("EgbuA26MAAAht0MA3dAAAMAAABt0g");
	var mask_graphics_230 = new cjs.Graphics().p("EgbzA26MAAAht0MA3nAAAMAAABt0g");
	var mask_graphics_231 = new cjs.Graphics().p("Egb5A26MAAAht0MA3zAAAMAAABt0g");
	var mask_graphics_232 = new cjs.Graphics().p("Egb+A26MAAAht0MA39AAAMAAABt0g");
	var mask_graphics_233 = new cjs.Graphics().p("EgcEA26MAAAht0MA4IAAAMAAABt0g");
	var mask_graphics_234 = new cjs.Graphics().p("EgcJA26MAAAht0MA4TAAAMAAABt0g");
	var mask_graphics_235 = new cjs.Graphics().p("EgcOA26MAAAht0MA4dAAAMAAABt0g");
	var mask_graphics_236 = new cjs.Graphics().p("EgcUA26MAAAht0MA4pAAAMAAABt0g");
	var mask_graphics_237 = new cjs.Graphics().p("EgcaA26MAAAht0MA40AAAMAAABt0g");
	var mask_graphics_238 = new cjs.Graphics().p("EgcfA26MAAAht0MA4/AAAMAAABt0g");
	var mask_graphics_239 = new cjs.Graphics().p("EgckA26MAAAht0MA5JAAAMAAABt0g");
	var mask_graphics_240 = new cjs.Graphics().p("EgcqA26MAAAht0MA5VAAAMAAABt0g");
	var mask_graphics_241 = new cjs.Graphics().p("EgcvA26MAAAht0MA5fAAAMAAABt0g");
	var mask_graphics_242 = new cjs.Graphics().p("Egc0A26MAAAht0MA5qAAAMAAABt0g");
	var mask_graphics_243 = new cjs.Graphics().p("Egc6A26MAAAht0MA51AAAMAAABt0g");
	var mask_graphics_244 = new cjs.Graphics().p("EgdAA26MAAAht0MA6BAAAMAAABt0g");
	var mask_graphics_245 = new cjs.Graphics().p("EgdFA26MAAAht0MA6LAAAMAAABt0g");
	var mask_graphics_246 = new cjs.Graphics().p("EgdKA26MAAAht0MA6VAAAMAAABt0g");
	var mask_graphics_247 = new cjs.Graphics().p("EgdQA26MAAAht0MA6hAAAMAAABt0g");
	var mask_graphics_248 = new cjs.Graphics().p("EgdVA26MAAAht0MA6rAAAMAAABt0g");
	var mask_graphics_249 = new cjs.Graphics().p("EgdbA26MAAAht0MA63AAAMAAABt0g");
	var mask_graphics_250 = new cjs.Graphics().p("EgdgA26MAAAht0MA7BAAAMAAABt0g");
	var mask_graphics_251 = new cjs.Graphics().p("EgdlA26MAAAht0MA7MAAAMAAABt0g");
	var mask_graphics_252 = new cjs.Graphics().p("EgdrA26MAAAht0MA7XAAAMAAABt0g");
	var mask_graphics_253 = new cjs.Graphics().p("EgdwA26MAAAht0MA7hAAAMAAABt0g");
	var mask_graphics_254 = new cjs.Graphics().p("Egd2A26MAAAht0MA7tAAAMAAABt0g");
	var mask_graphics_255 = new cjs.Graphics().p("Egd7A26MAAAht0MA73AAAMAAABt0g");
	var mask_graphics_256 = new cjs.Graphics().p("EgeBA26MAAAht0MA8DAAAMAAABt0g");
	var mask_graphics_257 = new cjs.Graphics().p("EgeGA26MAAAht0MA8NAAAMAAABt0g");
	var mask_graphics_258 = new cjs.Graphics().p("EgeLA26MAAAht0MA8XAAAMAAABt0g");
	var mask_graphics_259 = new cjs.Graphics().p("EgeRA26MAAAht0MA8jAAAMAAABt0g");
	var mask_graphics_260 = new cjs.Graphics().p("EgeWA26MAAAht0MA8tAAAMAAABt0g");
	var mask_graphics_261 = new cjs.Graphics().p("EgecA26MAAAht0MA85AAAMAAABt0g");
	var mask_graphics_262 = new cjs.Graphics().p("EgehA26MAAAht0MA9DAAAMAAABt0g");
	var mask_graphics_263 = new cjs.Graphics().p("EgenA26MAAAht0MA9PAAAMAAABt0g");
	var mask_graphics_264 = new cjs.Graphics().p("EgesA26MAAAht0MA9ZAAAMAAABt0g");
	var mask_graphics_265 = new cjs.Graphics().p("EgexA26MAAAht0MA9jAAAMAAABt0g");
	var mask_graphics_266 = new cjs.Graphics().p("Ege3A26MAAAht0MA9vAAAMAAABt0g");
	var mask_graphics_267 = new cjs.Graphics().p("Ege8A26MAAAht0MA95AAAMAAABt0g");
	var mask_graphics_268 = new cjs.Graphics().p("EgfBA26MAAAht0MA+DAAAMAAABt0g");
	var mask_graphics_269 = new cjs.Graphics().p("EgfHA26MAAAht0MA+PAAAMAAABt0g");
	var mask_graphics_270 = new cjs.Graphics().p("EgfNA26MAAAht0MA+aAAAMAAABt0g");
	var mask_graphics_271 = new cjs.Graphics().p("EgfSA26MAAAht0MA+lAAAMAAABt0g");
	var mask_graphics_272 = new cjs.Graphics().p("EgfXA26MAAAht0MA+vAAAMAAABt0g");
	var mask_graphics_273 = new cjs.Graphics().p("EgfdA26MAAAht0MA+7AAAMAAABt0g");
	var mask_graphics_274 = new cjs.Graphics().p("EgfiA26MAAAht0MA/FAAAMAAABt0g");
	var mask_graphics_275 = new cjs.Graphics().p("EgfnA27MAAAht0MA/QAAAMAAABt0g");
	var mask_graphics_276 = new cjs.Graphics().p("EgftA27MAAAht0MA/bAAAMAAABt0g");
	var mask_graphics_277 = new cjs.Graphics().p("EgfzA27MAAAht0MA/nAAAMAAABt0g");
	var mask_graphics_278 = new cjs.Graphics().p("Egf4A27MAAAht0MA/xAAAMAAABt0g");
	var mask_graphics_279 = new cjs.Graphics().p("Egf+A27MAAAht0MA/9AAAMAAABt0g");
	var mask_graphics_280 = new cjs.Graphics().p("EggDA27MAAAht0MBAHAAAMAAABt0g");
	var mask_graphics_281 = new cjs.Graphics().p("EggIA27MAAAht0MBARAAAMAAABt0g");
	var mask_graphics_282 = new cjs.Graphics().p("EggOA27MAAAht0MBAdAAAMAAABt0g");
	var mask_graphics_283 = new cjs.Graphics().p("EggTA27MAAAht0MBAnAAAMAAABt0g");
	var mask_graphics_284 = new cjs.Graphics().p("EggYA27MAAAht0MBAyAAAMAAABt0g");
	var mask_graphics_285 = new cjs.Graphics().p("EggeA27MAAAht0MBA9AAAMAAABt0g");
	var mask_graphics_286 = new cjs.Graphics().p("EggkA27MAAAht0MBBJAAAMAAABt0g");
	var mask_graphics_287 = new cjs.Graphics().p("EggpA27MAAAht0MBBTAAAMAAABt0g");
	var mask_graphics_288 = new cjs.Graphics().p("EgguA27MAAAht0MBBdAAAMAAABt0g");
	var mask_graphics_289 = new cjs.Graphics().p("Egg0A27MAAAht0MBBpAAAMAAABt0g");
	var mask_graphics_290 = new cjs.Graphics().p("Egg5A27MAAAht0MBBzAAAMAAABt0g");
	var mask_graphics_291 = new cjs.Graphics().p("Egg/A27MAAAht0MBB/AAAMAAABt0g");
	var mask_graphics_292 = new cjs.Graphics().p("EghEA27MAAAht0MBCJAAAMAAABt0g");
	var mask_graphics_293 = new cjs.Graphics().p("EghJA27MAAAht0MBCTAAAMAAABt0g");
	var mask_graphics_294 = new cjs.Graphics().p("EghPA27MAAAht0MBCfAAAMAAABt0g");
	var mask_graphics_295 = new cjs.Graphics().p("EghUA27MAAAht0MBCpAAAMAAABt0g");
	var mask_graphics_296 = new cjs.Graphics().p("EghaA27MAAAht0MBC1AAAMAAABt0g");
	var mask_graphics_297 = new cjs.Graphics().p("EghfA27MAAAht0MBC/AAAMAAABt0g");
	var mask_graphics_298 = new cjs.Graphics().p("EghkA27MAAAht0MBDJAAAMAAABt0g");
	var mask_graphics_299 = new cjs.Graphics().p("EghqA27MAAAht0MBDVAAAMAAABt0g");
	var mask_graphics_300 = new cjs.Graphics().p("EghvA27MAAAht0MBDfAAAMAAABt0g");
	var mask_graphics_301 = new cjs.Graphics().p("Egh1A27MAAAht0MBDrAAAMAAABt0g");
	var mask_graphics_302 = new cjs.Graphics().p("Egh6A27MAAAht0MBD1AAAMAAABt0g");
	var mask_graphics_303 = new cjs.Graphics().p("EgiAA27MAAAht0MBEAAAAMAAABt0g");
	var mask_graphics_304 = new cjs.Graphics().p("EgiFA27MAAAht0MBELAAAMAAABt0g");
	var mask_graphics_305 = new cjs.Graphics().p("EgiKA27MAAAht0MBEVAAAMAAABt0g");
	var mask_graphics_306 = new cjs.Graphics().p("EgiQA27MAAAht0MBEhAAAMAAABt0g");
	var mask_graphics_307 = new cjs.Graphics().p("EgiWA27MAAAht0MBEsAAAMAAABt0g");
	var mask_graphics_308 = new cjs.Graphics().p("EgibA27MAAAht0MBE3AAAMAAABt0g");
	var mask_graphics_309 = new cjs.Graphics().p("EgigA27MAAAht0MBFBAAAMAAABt0g");
	var mask_graphics_310 = new cjs.Graphics().p("EgilA27MAAAht0MBFMAAAMAAABt0g");
	var mask_graphics_311 = new cjs.Graphics().p("EgirA27MAAAht0MBFXAAAMAAABt0g");
	var mask_graphics_312 = new cjs.Graphics().p("EgixA27MAAAht0MBFjAAAMAAABt0g");
	var mask_graphics_313 = new cjs.Graphics().p("Egi2A27MAAAht0MBFtAAAMAAABt0g");
	var mask_graphics_314 = new cjs.Graphics().p("Egi7A27MAAAht0MBF4AAAMAAABt0g");
	var mask_graphics_315 = new cjs.Graphics().p("EgjBA27MAAAht0MBGDAAAMAAABt0g");
	var mask_graphics_316 = new cjs.Graphics().p("EgjGA27MAAAht0MBGNAAAMAAABt0g");
	var mask_graphics_317 = new cjs.Graphics().p("EgjMA27MAAAht0MBGZAAAMAAABt0g");
	var mask_graphics_318 = new cjs.Graphics().p("EgjRA27MAAAht0MBGjAAAMAAABt0g");
	var mask_graphics_319 = new cjs.Graphics().p("EgjXA27MAAAht0MBGuAAAMAAABt0g");
	var mask_graphics_320 = new cjs.Graphics().p("EgjcA27MAAAht0MBG5AAAMAAABt0g");
	var mask_graphics_321 = new cjs.Graphics().p("EgjhA27MAAAht0MBHDAAAMAAABt0g");
	var mask_graphics_322 = new cjs.Graphics().p("EgjnA27MAAAht0MBHPAAAMAAABt0g");
	var mask_graphics_323 = new cjs.Graphics().p("EgjsA27MAAAht0MBHZAAAMAAABt0g");
	var mask_graphics_324 = new cjs.Graphics().p("EgjyA27MAAAht0MBHlAAAMAAABt0g");
	var mask_graphics_325 = new cjs.Graphics().p("Egj3A26MAAAht0MBHvAAAMAAABt0g");
	var mask_graphics_326 = new cjs.Graphics().p("Egj8A26MAAAht0MBH5AAAMAAABt0g");
	var mask_graphics_327 = new cjs.Graphics().p("EgkCA26MAAAht0MBIFAAAMAAABt0g");
	var mask_graphics_328 = new cjs.Graphics().p("EgkHA26MAAAht0MBIPAAAMAAABt0g");
	var mask_graphics_329 = new cjs.Graphics().p("EgkNA26MAAAht0MBIbAAAMAAABt0g");
	var mask_graphics_330 = new cjs.Graphics().p("EgkSA26MAAAht0MBIlAAAMAAABt0g");
	var mask_graphics_331 = new cjs.Graphics().p("EgkYA26MAAAht0MBIxAAAMAAABt0g");
	var mask_graphics_332 = new cjs.Graphics().p("EgkdA26MAAAht0MBI7AAAMAAABt0g");
	var mask_graphics_333 = new cjs.Graphics().p("EgkjA26MAAAht0MBJGAAAMAAABt0g");
	var mask_graphics_334 = new cjs.Graphics().p("EgkoA26MAAAht0MBJRAAAMAAABt0g");
	var mask_graphics_335 = new cjs.Graphics().p("EgktA26MAAAht0MBJbAAAMAAABt0g");
	var mask_graphics_336 = new cjs.Graphics().p("EgkzA26MAAAht0MBJnAAAMAAABt0g");
	var mask_graphics_337 = new cjs.Graphics().p("Egk4A26MAAAht0MBJxAAAMAAABt0g");
	var mask_graphics_338 = new cjs.Graphics().p("Egk+A26MAAAht0MBJ9AAAMAAABt0g");
	var mask_graphics_339 = new cjs.Graphics().p("EglDA26MAAAht0MBKHAAAMAAABt0g");
	var mask_graphics_340 = new cjs.Graphics().p("EglIA26MAAAht0MBKSAAAMAAABt0g");
	var mask_graphics_341 = new cjs.Graphics().p("EglOA26MAAAht0MBKdAAAMAAABt0g");
	var mask_graphics_342 = new cjs.Graphics().p("EglUA26MAAAht0MBKpAAAMAAABt0g");
	var mask_graphics_343 = new cjs.Graphics().p("EglZA26MAAAht0MBKzAAAMAAABt0g");
	var mask_graphics_344 = new cjs.Graphics().p("EgleA26MAAAht0MBK9AAAMAAABt0g");
	var mask_graphics_345 = new cjs.Graphics().p("EglkA26MAAAht0MBLJAAAMAAABt0g");
	var mask_graphics_346 = new cjs.Graphics().p("EglpA26MAAAht0MBLTAAAMAAABt0g");
	var mask_graphics_347 = new cjs.Graphics().p("EgluA26MAAAht0MBLeAAAMAAABt0g");
	var mask_graphics_348 = new cjs.Graphics().p("Egl0A26MAAAht0MBLpAAAMAAABt0g");
	var mask_graphics_349 = new cjs.Graphics().p("Egl6A26MAAAht0MBL1AAAMAAABt0g");
	var mask_graphics_350 = new cjs.Graphics().p("Egl/A26MAAAht0MBL/AAAMAAABt0g");
	var mask_graphics_351 = new cjs.Graphics().p("EgmEA26MAAAht0MBMJAAAMAAABt0g");
	var mask_graphics_352 = new cjs.Graphics().p("EgmKA26MAAAht0MBMVAAAMAAABt0g");
	var mask_graphics_353 = new cjs.Graphics().p("EgmPA26MAAAht0MBMfAAAMAAABt0g");
	var mask_graphics_354 = new cjs.Graphics().p("EgmVA26MAAAht0MBMqAAAMAAABt0g");
	var mask_graphics_355 = new cjs.Graphics().p("EgmaA26MAAAht0MBM1AAAMAAABt0g");
	var mask_graphics_356 = new cjs.Graphics().p("EgmfA26MAAAht0MBM/AAAMAAABt0g");
	var mask_graphics_357 = new cjs.Graphics().p("EgmlA26MAAAht0MBNLAAAMAAABt0g");
	var mask_graphics_358 = new cjs.Graphics().p("EgmqA26MAAAht0MBNVAAAMAAABt0g");
	var mask_graphics_359 = new cjs.Graphics().p("EgmwA26MAAAht0MBNhAAAMAAABt0g");
	var mask_graphics_360 = new cjs.Graphics().p("Egm1A26MAAAht0MBNrAAAMAAABt0g");
	var mask_graphics_361 = new cjs.Graphics().p("Egm7A26MAAAht0MBN3AAAMAAABt0g");
	var mask_graphics_362 = new cjs.Graphics().p("EgnAA26MAAAht0MBOBAAAMAAABt0g");
	var mask_graphics_363 = new cjs.Graphics().p("EgnFA26MAAAht0MBOLAAAMAAABt0g");
	var mask_graphics_364 = new cjs.Graphics().p("EgnLA26MAAAht0MBOXAAAMAAABt0g");
	var mask_graphics_365 = new cjs.Graphics().p("EgnQA26MAAAht0MBOhAAAMAAABt0g");
	var mask_graphics_366 = new cjs.Graphics().p("EgnWA26MAAAht0MBOtAAAMAAABt0g");
	var mask_graphics_367 = new cjs.Graphics().p("EgnbA26MAAAht0MBO3AAAMAAABt0g");
	var mask_graphics_368 = new cjs.Graphics().p("EgngA26MAAAht0MBPBAAAMAAABt0g");
	var mask_graphics_369 = new cjs.Graphics().p("EgnmA26MAAAht0MBPNAAAMAAABt0g");
	var mask_graphics_370 = new cjs.Graphics().p("EgnrA26MAAAht0MBPXAAAMAAABt0g");
	var mask_graphics_371 = new cjs.Graphics().p("EgnxA26MAAAht0MBPjAAAMAAABt0g");
	var mask_graphics_372 = new cjs.Graphics().p("Egn2A26MAAAht0MBPtAAAMAAABt0g");
	var mask_graphics_373 = new cjs.Graphics().p("Egn7A26MAAAht0MBP4AAAMAAABt0g");
	var mask_graphics_374 = new cjs.Graphics().p("EgoBA26MAAAht0MBQDAAAMAAABt0g");
	var mask_graphics_375 = new cjs.Graphics().p("EgoHA27MAAAht0MBQPAAAMAAABt0g");
	var mask_graphics_376 = new cjs.Graphics().p("EgoMA27MAAAht0MBQZAAAMAAABt0g");
	var mask_graphics_377 = new cjs.Graphics().p("EgoRA27MAAAht0MBQjAAAMAAABt0g");
	var mask_graphics_378 = new cjs.Graphics().p("EgoXA27MAAAht0MBQvAAAMAAABt0g");
	var mask_graphics_379 = new cjs.Graphics().p("EgocA27MAAAht0MBQ5AAAMAAABt0g");
	var mask_graphics_380 = new cjs.Graphics().p("EgohA27MAAAht0MBREAAAMAAABt0g");
	var mask_graphics_381 = new cjs.Graphics().p("EgonA27MAAAht0MBRPAAAMAAABt0g");
	var mask_graphics_382 = new cjs.Graphics().p("EgotA27MAAAht0MBRbAAAMAAABt0g");
	var mask_graphics_383 = new cjs.Graphics().p("EgoyA27MAAAht0MBRlAAAMAAABt0g");
	var mask_graphics_384 = new cjs.Graphics().p("Ego4A27MAAAht0MBRxAAAMAAABt0g");
	var mask_graphics_385 = new cjs.Graphics().p("Ego9A27MAAAht0MBR7AAAMAAABt0g");
	var mask_graphics_386 = new cjs.Graphics().p("EgpCA27MAAAht0MBSFAAAMAAABt0g");
	var mask_graphics_387 = new cjs.Graphics().p("EgpIA27MAAAht0MBSRAAAMAAABt0g");
	var mask_graphics_388 = new cjs.Graphics().p("EgpNA27MAAAht0MBSbAAAMAAABt0g");
	var mask_graphics_389 = new cjs.Graphics().p("EgpSA27MAAAht0MBSlAAAMAAABt0g");
	var mask_graphics_390 = new cjs.Graphics().p("EgpYA27MAAAht0MBSxAAAMAAABt0g");
	var mask_graphics_391 = new cjs.Graphics().p("EgpeA27MAAAht0MBS8AAAMAAABt0g");
	var mask_graphics_392 = new cjs.Graphics().p("EgpjA27MAAAht0MBTHAAAMAAABt0g");
	var mask_graphics_393 = new cjs.Graphics().p("EgpoA27MAAAht0MBTRAAAMAAABt0g");
	var mask_graphics_394 = new cjs.Graphics().p("EgpuA27MAAAht0MBTdAAAMAAABt0g");
	var mask_graphics_395 = new cjs.Graphics().p("EgpzA27MAAAht0MBTnAAAMAAABt0g");
	var mask_graphics_396 = new cjs.Graphics().p("Egp4A27MAAAht0MBTyAAAMAAABt0g");
	var mask_graphics_397 = new cjs.Graphics().p("Egp+A27MAAAht0MBT9AAAMAAABt0g");
	var mask_graphics_398 = new cjs.Graphics().p("EgqDA27MAAAht0MBUHAAAMAAABt0g");
	var mask_graphics_399 = new cjs.Graphics().p("EgqJA27MAAAht0MBUTAAAMAAABt0g");
	var mask_graphics_400 = new cjs.Graphics().p("EgqOA27MAAAht0MBUdAAAMAAABt0g");
	var mask_graphics_401 = new cjs.Graphics().p("EgqUA27MAAAht0MBUpAAAMAAABt0g");
	var mask_graphics_402 = new cjs.Graphics().p("EgqZA27MAAAht0MBUzAAAMAAABt0g");
	var mask_graphics_403 = new cjs.Graphics().p("EgqeA27MAAAht0MBU9AAAMAAABt0g");
	var mask_graphics_404 = new cjs.Graphics().p("EgqkA27MAAAht0MBVJAAAMAAABt0g");
	var mask_graphics_405 = new cjs.Graphics().p("EgqpA27MAAAht0MBVTAAAMAAABt0g");
	var mask_graphics_406 = new cjs.Graphics().p("EgqvA27MAAAht0MBVfAAAMAAABt0g");
	var mask_graphics_407 = new cjs.Graphics().p("Egq0A27MAAAht0MBVpAAAMAAABt0g");
	var mask_graphics_408 = new cjs.Graphics().p("Egq6A27MAAAht0MBV1AAAMAAABt0g");
	var mask_graphics_409 = new cjs.Graphics().p("Egq/A27MAAAht0MBV/AAAMAAABt0g");
	var mask_graphics_410 = new cjs.Graphics().p("EgrEA27MAAAht0MBWKAAAMAAABt0g");
	var mask_graphics_411 = new cjs.Graphics().p("EgrKA27MAAAht0MBWVAAAMAAABt0g");
	var mask_graphics_412 = new cjs.Graphics().p("EgrPA27MAAAht0MBWfAAAMAAABt0g");
	var mask_graphics_413 = new cjs.Graphics().p("EgrVA27MAAAht0MBWqAAAMAAABt0g");
	var mask_graphics_414 = new cjs.Graphics().p("EgraA27MAAAht0MBW1AAAMAAABt0g");
	var mask_graphics_415 = new cjs.Graphics().p("EgrfA27MAAAht0MBW/AAAMAAABt0g");
	var mask_graphics_416 = new cjs.Graphics().p("EgrlA27MAAAht0MBXLAAAMAAABt0g");
	var mask_graphics_417 = new cjs.Graphics().p("EgrrA27MAAAht0MBXWAAAMAAABt0g");
	var mask_graphics_418 = new cjs.Graphics().p("EgrwA27MAAAht0MBXhAAAMAAABt0g");
	var mask_graphics_419 = new cjs.Graphics().p("Egr1A27MAAAht0MBXrAAAMAAABt0g");
	var mask_graphics_420 = new cjs.Graphics().p("Egr7A27MAAAht0MBX3AAAMAAABt0g");
	var mask_graphics_421 = new cjs.Graphics().p("EgsAA27MAAAht0MBYBAAAMAAABt0g");
	var mask_graphics_422 = new cjs.Graphics().p("EgsFA27MAAAht0MBYLAAAMAAABt0g");
	var mask_graphics_423 = new cjs.Graphics().p("EgsLA27MAAAht0MBYXAAAMAAABt0g");
	var mask_graphics_424 = new cjs.Graphics().p("EgsRA27MAAAht0MBYiAAAMAAABt0g");
	var mask_graphics_425 = new cjs.Graphics().p("EgsWA26MAAAht0MBYtAAAMAAABt0g");
	var mask_graphics_426 = new cjs.Graphics().p("EgsbA26MAAAht0MBY3AAAMAAABt0g");
	var mask_graphics_427 = new cjs.Graphics().p("EgshA26MAAAht0MBZDAAAMAAABt0g");
	var mask_graphics_428 = new cjs.Graphics().p("EgsmA26MAAAht0MBZNAAAMAAABt0g");
	var mask_graphics_429 = new cjs.Graphics().p("EgssA26MAAAht0MBZZAAAMAAABt0g");
	var mask_graphics_430 = new cjs.Graphics().p("EgsxA26MAAAht0MBZjAAAMAAABt0g");
	var mask_graphics_431 = new cjs.Graphics().p("Egs2A26MAAAht0MBZuAAAMAAABt0g");
	var mask_graphics_432 = new cjs.Graphics().p("Egs8A26MAAAht0MBZ5AAAMAAABt0g");
	var mask_graphics_433 = new cjs.Graphics().p("EgtBA26MAAAht0MBaDAAAMAAABt0g");
	var mask_graphics_434 = new cjs.Graphics().p("EgtHA26MAAAht0MBaPAAAMAAABt0g");
	var mask_graphics_435 = new cjs.Graphics().p("EgtMA26MAAAht0MBaZAAAMAAABt0g");
	var mask_graphics_436 = new cjs.Graphics().p("EgtSA26MAAAht0MBalAAAMAAABt0g");
	var mask_graphics_437 = new cjs.Graphics().p("EgtXA26MAAAht0MBavAAAMAAABt0g");
	var mask_graphics_438 = new cjs.Graphics().p("EgtdA26MAAAht0MBa7AAAMAAABt0g");
	var mask_graphics_439 = new cjs.Graphics().p("EgtiA26MAAAht0MBbFAAAMAAABt0g");
	var mask_graphics_440 = new cjs.Graphics().p("EgtnA26MAAAht0MBbPAAAMAAABt0g");
	var mask_graphics_441 = new cjs.Graphics().p("EgttA26MAAAht0MBbbAAAMAAABt0g");
	var mask_graphics_442 = new cjs.Graphics().p("EgtyA26MAAAht0MBblAAAMAAABt0g");
	var mask_graphics_443 = new cjs.Graphics().p("Egt4A26MAAAht0MBbxAAAMAAABt0g");
	var mask_graphics_444 = new cjs.Graphics().p("Egt9A26MAAAht0MBb7AAAMAAABt0g");
	var mask_graphics_445 = new cjs.Graphics().p("EguCA26MAAAht0MBcGAAAMAAABt0g");
	var mask_graphics_446 = new cjs.Graphics().p("EguIA26MAAAht0MBcRAAAMAAABt0g");
	var mask_graphics_447 = new cjs.Graphics().p("EguNA26MAAAht0MBcbAAAMAAABt0g");
	var mask_graphics_448 = new cjs.Graphics().p("EguTA26MAAAht0MBcnAAAMAAABt0g");
	var mask_graphics_449 = new cjs.Graphics().p("EguYA26MAAAht0MBcxAAAMAAABt0g");
	var mask_graphics_450 = new cjs.Graphics().p("EgueA26MAAAht0MBc8AAAMAAABt0g");
	var mask_graphics_451 = new cjs.Graphics().p("EgujA26MAAAht0MBdHAAAMAAABt0g");
	var mask_graphics_452 = new cjs.Graphics().p("EguoA26MAAAht0MBdRAAAMAAABt0g");
	var mask_graphics_453 = new cjs.Graphics().p("EguuA26MAAAht0MBddAAAMAAABt0g");
	var mask_graphics_454 = new cjs.Graphics().p("EguzA26MAAAht0MBdnAAAMAAABt0g");
	var mask_graphics_455 = new cjs.Graphics().p("Egu5A26MAAAht0MBdzAAAMAAABt0g");
	var mask_graphics_456 = new cjs.Graphics().p("Egu+A26MAAAht0MBd9AAAMAAABt0g");
	var mask_graphics_457 = new cjs.Graphics().p("EgvEA26MAAAht0MBeIAAAMAAABt0g");
	var mask_graphics_458 = new cjs.Graphics().p("EgvJA26MAAAht0MBeTAAAMAAABt0g");
	var mask_graphics_459 = new cjs.Graphics().p("EgvPA26MAAAht0MBeeAAAMAAABt0g");
	var mask_graphics_460 = new cjs.Graphics().p("EgvUA26MAAAht0MBepAAAMAAABt0g");
	var mask_graphics_461 = new cjs.Graphics().p("EgvZA26MAAAht0MBezAAAMAAABt0g");
	var mask_graphics_462 = new cjs.Graphics().p("EgvfA26MAAAht0MBe/AAAMAAABt0g");
	var mask_graphics_463 = new cjs.Graphics().p("EgvkA26MAAAht0MBfJAAAMAAABt0g");
	var mask_graphics_464 = new cjs.Graphics().p("EgvpA26MAAAht0MBfUAAAMAAABt0g");
	var mask_graphics_465 = new cjs.Graphics().p("EgvvA26MAAAht0MBffAAAMAAABt0g");
	var mask_graphics_466 = new cjs.Graphics().p("Egv1A26MAAAht0MBfrAAAMAAABt0g");
	var mask_graphics_467 = new cjs.Graphics().p("Egv6A26MAAAht0MBf1AAAMAAABt0g");
	var mask_graphics_468 = new cjs.Graphics().p("Egv/A26MAAAht0MBf/AAAMAAABt0g");
	var mask_graphics_469 = new cjs.Graphics().p("EgwFA26MAAAht0MBgLAAAMAAABt0g");
	var mask_graphics_470 = new cjs.Graphics().p("EgwKA26MAAAht0MBgVAAAMAAABt0g");
	var mask_graphics_471 = new cjs.Graphics().p("EgwQA26MAAAht0MBghAAAMAAABt0g");
	var mask_graphics_472 = new cjs.Graphics().p("EgwVA26MAAAht0MBgrAAAMAAABt0g");
	var mask_graphics_473 = new cjs.Graphics().p("EgwaA26MAAAht0MBg1AAAMAAABt0g");
	var mask_graphics_474 = new cjs.Graphics().p("EgwgA26MAAAht0MBhBAAAMAAABt0g");
	var mask_graphics_475 = new cjs.Graphics().p("EgwlA27MAAAht0MBhLAAAMAAABt0g");
	var mask_graphics_476 = new cjs.Graphics().p("EgwrA27MAAAht0MBhXAAAMAAABt0g");
	var mask_graphics_477 = new cjs.Graphics().p("EgwwA27MAAAht0MBhhAAAMAAABt0g");
	var mask_graphics_478 = new cjs.Graphics().p("Egw1A27MAAAht0MBhsAAAMAAABt0g");
	var mask_graphics_479 = new cjs.Graphics().p("Egw7A27MAAAht0MBh3AAAMAAABt0g");
	var mask_graphics_480 = new cjs.Graphics().p("EgxBA27MAAAht0MBiDAAAMAAABt0g");
	var mask_graphics_481 = new cjs.Graphics().p("EgxGA27MAAAht0MBiNAAAMAAABt0g");
	var mask_graphics_482 = new cjs.Graphics().p("EgxLA27MAAAht0MBiXAAAMAAABt0g");
	var mask_graphics_483 = new cjs.Graphics().p("EgxRA27MAAAht0MBijAAAMAAABt0g");
	var mask_graphics_484 = new cjs.Graphics().p("EgxWA27MAAAht0MBitAAAMAAABt0g");
	var mask_graphics_485 = new cjs.Graphics().p("EgxbA27MAAAht0MBi3AAAMAAABt0g");
	var mask_graphics_486 = new cjs.Graphics().p("EgxhA27MAAAht0MBjDAAAMAAABt0g");
	var mask_graphics_487 = new cjs.Graphics().p("EgxnA27MAAAht0MBjOAAAMAAABt0g");
	var mask_graphics_488 = new cjs.Graphics().p("EgxsA27MAAAht0MBjZAAAMAAABt0g");
	var mask_graphics_489 = new cjs.Graphics().p("EgxxA27MAAAht0MBjjAAAMAAABt0g");
	var mask_graphics_490 = new cjs.Graphics().p("Egx3A27MAAAht0MBjvAAAMAAABt0g");
	var mask_graphics_491 = new cjs.Graphics().p("Egx8A27MAAAht0MBj5AAAMAAABt0g");
	var mask_graphics_492 = new cjs.Graphics().p("EgyCA27MAAAht0MBkFAAAMAAABt0g");
	var mask_graphics_493 = new cjs.Graphics().p("EgyHA27MAAAht0MBkPAAAMAAABt0g");
	var mask_graphics_494 = new cjs.Graphics().p("EgyMA27MAAAht0MBkaAAAMAAABt0g");
	var mask_graphics_495 = new cjs.Graphics().p("EgySA27MAAAht0MBklAAAMAAABt0g");
	var mask_graphics_496 = new cjs.Graphics().p("EgyXA27MAAAht0MBkvAAAMAAABt0g");
	var mask_graphics_497 = new cjs.Graphics().p("EgydA27MAAAht0MBk7AAAMAAABt0g");
	var mask_graphics_498 = new cjs.Graphics().p("EgyiA27MAAAht0MBlFAAAMAAABt0g");
	var mask_graphics_499 = new cjs.Graphics().p("EgyoA27MAAAht0MBlRAAAMAAABt0g");
	var mask_graphics_500 = new cjs.Graphics().p("EgytA27MAAAht0MBlbAAAMAAABt0g");
	var mask_graphics_501 = new cjs.Graphics().p("EgyyA27MAAAht0MBlmAAAMAAABt0g");
	var mask_graphics_502 = new cjs.Graphics().p("Egy4A27MAAAht0MBlxAAAMAAABt0g");
	var mask_graphics_503 = new cjs.Graphics().p("Egy9A27MAAAht0MBl7AAAMAAABt0g");
	var mask_graphics_504 = new cjs.Graphics().p("EgzDA27MAAAht0MBmHAAAMAAABt0g");
	var mask_graphics_505 = new cjs.Graphics().p("EgzIA27MAAAht0MBmRAAAMAAABt0g");
	var mask_graphics_506 = new cjs.Graphics().p("EgzNA27MAAAht0MBmbAAAMAAABt0g");
	var mask_graphics_507 = new cjs.Graphics().p("EgzTA27MAAAht0MBmnAAAMAAABt0g");
	var mask_graphics_508 = new cjs.Graphics().p("EgzYA27MAAAht0MBmxAAAMAAABt0g");
	var mask_graphics_509 = new cjs.Graphics().p("EgzeA27MAAAht0MBm9AAAMAAABt0g");
	var mask_graphics_510 = new cjs.Graphics().p("EgzjA27MAAAht0MBnHAAAMAAABt0g");
	var mask_graphics_511 = new cjs.Graphics().p("EgzpA27MAAAht0MBnTAAAMAAABt0g");
	var mask_graphics_512 = new cjs.Graphics().p("EgzuA27MAAAht0MBndAAAMAAABt0g");
	var mask_graphics_513 = new cjs.Graphics().p("Egz0A27MAAAht0MBnoAAAMAAABt0g");
	var mask_graphics_514 = new cjs.Graphics().p("Egz5A27MAAAht0MBnzAAAMAAABt0g");
	var mask_graphics_515 = new cjs.Graphics().p("Egz+A27MAAAht0MBn9AAAMAAABt0g");
	var mask_graphics_516 = new cjs.Graphics().p("Eg0EA27MAAAht0MBoJAAAMAAABt0g");
	var mask_graphics_517 = new cjs.Graphics().p("Eg0JA27MAAAht0MBoTAAAMAAABt0g");
	var mask_graphics_518 = new cjs.Graphics().p("Eg0PA27MAAAht0MBoeAAAMAAABt0g");
	var mask_graphics_519 = new cjs.Graphics().p("Eg0UA27MAAAht0MBopAAAMAAABt0g");
	var mask_graphics_520 = new cjs.Graphics().p("Eg0ZA27MAAAht0MBozAAAMAAABt0g");
	var mask_graphics_521 = new cjs.Graphics().p("Eg0fA27MAAAht0MBo/AAAMAAABt0g");
	var mask_graphics_522 = new cjs.Graphics().p("Eg0kA27MAAAht0MBpJAAAMAAABt0g");
	var mask_graphics_523 = new cjs.Graphics().p("Eg0qA27MAAAht0MBpVAAAMAAABt0g");
	var mask_graphics_524 = new cjs.Graphics().p("Eg0vA27MAAAht0MBpfAAAMAAABt0g");
	var mask_graphics_525 = new cjs.Graphics().p("Eg01A26MAAAht0MBprAAAMAAABt0g");
	var mask_graphics_526 = new cjs.Graphics().p("Eg06A26MAAAht0MBp1AAAMAAABt0g");
	var mask_graphics_527 = new cjs.Graphics().p("Eg0/A26MAAAht0MBqAAAAMAAABt0g");
	var mask_graphics_528 = new cjs.Graphics().p("Eg1FA26MAAAht0MBqLAAAMAAABt0g");
	var mask_graphics_529 = new cjs.Graphics().p("Eg1LA26MAAAht0MBqXAAAMAAABt0g");
	var mask_graphics_530 = new cjs.Graphics().p("Eg1QA26MAAAht0MBqhAAAMAAABt0g");
	var mask_graphics_531 = new cjs.Graphics().p("Eg1VA26MAAAht0MBqrAAAMAAABt0g");
	var mask_graphics_532 = new cjs.Graphics().p("Eg1bA26MAAAht0MBq3AAAMAAABt0g");
	var mask_graphics_533 = new cjs.Graphics().p("Eg1gA26MAAAht0MBrBAAAMAAABt0g");
	var mask_graphics_534 = new cjs.Graphics().p("Eg1mA26MAAAht0MBrMAAAMAAABt0g");
	var mask_graphics_535 = new cjs.Graphics().p("Eg1rA26MAAAht0MBrXAAAMAAABt0g");
	var mask_graphics_536 = new cjs.Graphics().p("Eg1wA26MAAAht0MBrhAAAMAAABt0g");
	var mask_graphics_537 = new cjs.Graphics().p("Eg12A26MAAAht0MBrtAAAMAAABt0g");
	var mask_graphics_538 = new cjs.Graphics().p("Eg17A26MAAAht0MBr3AAAMAAABt0g");
	var mask_graphics_539 = new cjs.Graphics().p("Eg2BA26MAAAht0MBsDAAAMAAABt0g");
	var mask_graphics_540 = new cjs.Graphics().p("Eg2GA26MAAAht0MBsNAAAMAAABt0g");
	var mask_graphics_541 = new cjs.Graphics().p("Eg2MA26MAAAht0MBsYAAAMAAABt0g");
	var mask_graphics_542 = new cjs.Graphics().p("Eg2RA26MAAAht0MBsjAAAMAAABt0g");
	var mask_graphics_543 = new cjs.Graphics().p("Eg2WA26MAAAht0MBstAAAMAAABt0g");
	var mask_graphics_544 = new cjs.Graphics().p("Eg2cA26MAAAht0MBs5AAAMAAABt0g");
	var mask_graphics_545 = new cjs.Graphics().p("Eg2hA26MAAAht0MBtDAAAMAAABt0g");
	var mask_graphics_546 = new cjs.Graphics().p("Eg2nA26MAAAht0MBtPAAAMAAABt0g");
	var mask_graphics_547 = new cjs.Graphics().p("Eg2sA26MAAAht0MBtZAAAMAAABt0g");
	var mask_graphics_548 = new cjs.Graphics().p("Eg2yA26MAAAht0MBtkAAAMAAABt0g");
	var mask_graphics_549 = new cjs.Graphics().p("Eg23A26MAAAht0MBtvAAAMAAABt0g");
	var mask_graphics_550 = new cjs.Graphics().p("Eg28A26MAAAht0MBt5AAAMAAABt0g");
	var mask_graphics_551 = new cjs.Graphics().p("Eg3CA26MAAAht0MBuFAAAMAAABt0g");
	var mask_graphics_552 = new cjs.Graphics().p("Eg3HA26MAAAht0MBuPAAAMAAABt0g");
	var mask_graphics_553 = new cjs.Graphics().p("Eg3MA26MAAAht0MBuaAAAMAAABt0g");
	var mask_graphics_554 = new cjs.Graphics().p("Eg3SA26MAAAht0MBulAAAMAAABt0g");
	var mask_graphics_555 = new cjs.Graphics().p("Eg3YA26MAAAht0MBuxAAAMAAABt0g");
	var mask_graphics_556 = new cjs.Graphics().p("Eg3dA26MAAAht0MBu7AAAMAAABt0g");
	var mask_graphics_557 = new cjs.Graphics().p("Eg3iA26MAAAht0MBvFAAAMAAABt0g");
	var mask_graphics_558 = new cjs.Graphics().p("Eg3oA26MAAAht0MBvRAAAMAAABt0g");
	var mask_graphics_559 = new cjs.Graphics().p("Eg3tA26MAAAht0MBvbAAAMAAABt0g");
	var mask_graphics_560 = new cjs.Graphics().p("Eg3yA26MAAAht0MBvmAAAMAAABt0g");
	var mask_graphics_561 = new cjs.Graphics().p("Eg34A26MAAAht0MBvxAAAMAAABt0g");
	var mask_graphics_562 = new cjs.Graphics().p("Eg3+A26MAAAht0MBv9AAAMAAABt0g");
	var mask_graphics_563 = new cjs.Graphics().p("Eg4DA26MAAAht0MBwHAAAMAAABt0g");
	var mask_graphics_564 = new cjs.Graphics().p("Eg4IA26MAAAht0MBwRAAAMAAABt0g");
	var mask_graphics_565 = new cjs.Graphics().p("Eg4OA26MAAAht0MBwdAAAMAAABt0g");
	var mask_graphics_566 = new cjs.Graphics().p("Eg4TA26MAAAht0MBwnAAAMAAABt0g");
	var mask_graphics_567 = new cjs.Graphics().p("Eg4ZA26MAAAht0MBwyAAAMAAABt0g");
	var mask_graphics_568 = new cjs.Graphics().p("Eg4eA26MAAAht0MBw9AAAMAAABt0g");
	var mask_graphics_569 = new cjs.Graphics().p("Eg4jA26MAAAht0MBxHAAAMAAABt0g");
	var mask_graphics_570 = new cjs.Graphics().p("Eg4pA26MAAAht0MBxTAAAMAAABt0g");
	var mask_graphics_571 = new cjs.Graphics().p("Eg4vA26MAAAht0MBxeAAAMAAABt0g");
	var mask_graphics_572 = new cjs.Graphics().p("Eg40A26MAAAht0MBxpAAAMAAABt0g");
	var mask_graphics_573 = new cjs.Graphics().p("Eg45A26MAAAht0MBxzAAAMAAABt0g");
	var mask_graphics_574 = new cjs.Graphics().p("Eg4/A26MAAAht0MBx/AAAMAAABt0g");
	var mask_graphics_575 = new cjs.Graphics().p("Eg5EA27MAAAht1MByJAAAMAAABt1g");
	var mask_graphics_576 = new cjs.Graphics().p("Eg5JA27MAAAht1MByTAAAMAAABt1g");
	var mask_graphics_577 = new cjs.Graphics().p("Eg5PA27MAAAht1MByfAAAMAAABt1g");
	var mask_graphics_578 = new cjs.Graphics().p("Eg5UA27MAAAht1MBypAAAMAAABt1g");
	var mask_graphics_579 = new cjs.Graphics().p("Eg5aA27MAAAht1MBy1AAAMAAABt1g");
	var mask_graphics_580 = new cjs.Graphics().p("Eg5fA27MAAAht1MBy/AAAMAAABt1g");
	var mask_graphics_581 = new cjs.Graphics().p("Eg5lA27MAAAht1MBzLAAAMAAABt1g");
	var mask_graphics_582 = new cjs.Graphics().p("Eg5qA27MAAAht1MBzVAAAMAAABt1g");
	var mask_graphics_583 = new cjs.Graphics().p("Eg5vA27MAAAht1MBzfAAAMAAABt1g");
	var mask_graphics_584 = new cjs.Graphics().p("Eg51A27MAAAht1MBzrAAAMAAABt1g");
	var mask_graphics_585 = new cjs.Graphics().p("Eg56A27MAAAht1MBz1AAAMAAABt1g");
	var mask_graphics_586 = new cjs.Graphics().p("Eg6AA27MAAAht1MB0BAAAMAAABt1g");
	var mask_graphics_587 = new cjs.Graphics().p("Eg6FA27MAAAht1MB0LAAAMAAABt1g");
	var mask_graphics_588 = new cjs.Graphics().p("Eg6LA27MAAAht1MB0XAAAMAAABt1g");
	var mask_graphics_589 = new cjs.Graphics().p("Eg6QA27MAAAht1MB0hAAAMAAABt1g");
	var mask_graphics_590 = new cjs.Graphics().p("Eg6VA27MAAAht1MB0sAAAMAAABt1g");
	var mask_graphics_591 = new cjs.Graphics().p("Eg6bA27MAAAht1MB03AAAMAAABt1g");
	var mask_graphics_592 = new cjs.Graphics().p("Eg6gA27MAAAht1MB1BAAAMAAABt1g");
	var mask_graphics_593 = new cjs.Graphics().p("Eg6mA27MAAAht1MB1NAAAMAAABt1g");
	var mask_graphics_594 = new cjs.Graphics().p("Eg6rA27MAAAht1MB1XAAAMAAABt1g");
	var mask_graphics_595 = new cjs.Graphics().p("Eg6wA27MAAAht1MB1iAAAMAAABt1g");
	var mask_graphics_596 = new cjs.Graphics().p("Eg62A27MAAAht1MB1tAAAMAAABt1g");
	var mask_graphics_597 = new cjs.Graphics().p("Eg68A27MAAAht1MB15AAAMAAABt1g");
	var mask_graphics_598 = new cjs.Graphics().p("Eg7BA27MAAAht1MB2DAAAMAAABt1g");
	var mask_graphics_599 = new cjs.Graphics().p("Eg7GA27MAAAht1MB2NAAAMAAABt1g");
	var mask_graphics_600 = new cjs.Graphics().p("Eg7MA27MAAAht1MB2ZAAAMAAABt1g");
	var mask_graphics_601 = new cjs.Graphics().p("Eg7RA27MAAAht1MB2jAAAMAAABt1g");
	var mask_graphics_602 = new cjs.Graphics().p("Eg7WA27MAAAht1MB2tAAAMAAABt1g");
	var mask_graphics_603 = new cjs.Graphics().p("Eg7cA27MAAAht1MB25AAAMAAABt1g");
	var mask_graphics_604 = new cjs.Graphics().p("Eg7iA27MAAAht1MB3EAAAMAAABt1g");
	var mask_graphics_605 = new cjs.Graphics().p("Eg7nA27MAAAht1MB3PAAAMAAABt1g");
	var mask_graphics_606 = new cjs.Graphics().p("Eg7sA27MAAAht1MB3ZAAAMAAABt1g");
	var mask_graphics_607 = new cjs.Graphics().p("Eg7yA27MAAAht1MB3lAAAMAAABt1g");
	var mask_graphics_608 = new cjs.Graphics().p("Eg73A27MAAAht1MB3vAAAMAAABt1g");
	var mask_graphics_609 = new cjs.Graphics().p("Eg79A27MAAAht1MB37AAAMAAABt1g");
	var mask_graphics_610 = new cjs.Graphics().p("Eg8CA27MAAAht1MB4FAAAMAAABt1g");
	var mask_graphics_611 = new cjs.Graphics().p("Eg8HA27MAAAht1MB4QAAAMAAABt1g");
	var mask_graphics_612 = new cjs.Graphics().p("Eg8NA27MAAAht1MB4bAAAMAAABt1g");
	var mask_graphics_613 = new cjs.Graphics().p("Eg8SA27MAAAht1MB4lAAAMAAABt1g");
	var mask_graphics_614 = new cjs.Graphics().p("Eg8YA27MAAAht1MB4xAAAMAAABt1g");
	var mask_graphics_615 = new cjs.Graphics().p("Eg8dA27MAAAht1MB47AAAMAAABt1g");
	var mask_graphics_616 = new cjs.Graphics().p("Eg8jA27MAAAht1MB5HAAAMAAABt1g");
	var mask_graphics_617 = new cjs.Graphics().p("Eg8oA27MAAAht1MB5RAAAMAAABt1g");
	var mask_graphics_618 = new cjs.Graphics().p("Eg8tA27MAAAht1MB5bAAAMAAABt1g");
	var mask_graphics_619 = new cjs.Graphics().p("Eg8zA27MAAAht1MB5nAAAMAAABt1g");
	var mask_graphics_620 = new cjs.Graphics().p("Eg84A27MAAAht1MB5xAAAMAAABt1g");
	var mask_graphics_621 = new cjs.Graphics().p("Eg8+A27MAAAht1MB59AAAMAAABt1g");
	var mask_graphics_622 = new cjs.Graphics().p("Eg9DA27MAAAht1MB6HAAAMAAABt1g");
	var mask_graphics_623 = new cjs.Graphics().p("Eg9JA27MAAAht1MB6TAAAMAAABt1g");
	var mask_graphics_624 = new cjs.Graphics().p("Eg9OA27MAAAht1MB6dAAAMAAABt1g");
	var mask_graphics_625 = new cjs.Graphics().p("Eg9TA26MAAAhtzMB6oAAAMAAABtzg");
	var mask_graphics_626 = new cjs.Graphics().p("Eg9ZA26MAAAhtzMB6zAAAMAAABtzg");
	var mask_graphics_627 = new cjs.Graphics().p("Eg9eA26MAAAhtzMB69AAAMAAABtzg");
	var mask_graphics_628 = new cjs.Graphics().p("Eg9kA26MAAAhtzMB7JAAAMAAABtzg");
	var mask_graphics_629 = new cjs.Graphics().p("Eg9pA26MAAAhtzMB7TAAAMAAABtzg");
	var mask_graphics_630 = new cjs.Graphics().p("Eg9vA26MAAAhtzMB7eAAAMAAABtzg");
	var mask_graphics_631 = new cjs.Graphics().p("Eg90A26MAAAhtzMB7pAAAMAAABtzg");
	var mask_graphics_632 = new cjs.Graphics().p("Eg95A26MAAAhtzMB7zAAAMAAABtzg");
	var mask_graphics_633 = new cjs.Graphics().p("Eg9/A26MAAAhtzMB7/AAAMAAABtzg");
	var mask_graphics_634 = new cjs.Graphics().p("Eg+EA26MAAAhtzMB8JAAAMAAABtzg");
	var mask_graphics_635 = new cjs.Graphics().p("Eg+KA26MAAAhtzMB8VAAAMAAABtzg");
	var mask_graphics_636 = new cjs.Graphics().p("Eg+PA26MAAAhtzMB8fAAAMAAABtzg");
	var mask_graphics_637 = new cjs.Graphics().p("Eg+VA26MAAAhtzMB8qAAAMAAABtzg");
	var mask_graphics_638 = new cjs.Graphics().p("Eg+aA26MAAAhtzMB81AAAMAAABtzg");
	var mask_graphics_639 = new cjs.Graphics().p("Eg+gA26MAAAhtzMB9AAAAMAAABtzg");
	var mask_graphics_640 = new cjs.Graphics().p("Eg+lA26MAAAhtzMB9LAAAMAAABtzg");
	var mask_graphics_641 = new cjs.Graphics().p("Eg+qA26MAAAhtzMB9VAAAMAAABtzg");
	var mask_graphics_642 = new cjs.Graphics().p("Eg+wA26MAAAhtzMB9hAAAMAAABtzg");
	var mask_graphics_643 = new cjs.Graphics().p("Eg+1A26MAAAhtzMB9rAAAMAAABtzg");
	var mask_graphics_644 = new cjs.Graphics().p("Eg+6A26MAAAhtzMB92AAAMAAABtzg");
	var mask_graphics_645 = new cjs.Graphics().p("Eg/AA26MAAAhtzMB+BAAAMAAABtzg");
	var mask_graphics_646 = new cjs.Graphics().p("Eg/GA26MAAAhtzMB+NAAAMAAABtzg");
	var mask_graphics_647 = new cjs.Graphics().p("Eg/LA26MAAAhtzMB+XAAAMAAABtzg");
	var mask_graphics_648 = new cjs.Graphics().p("Eg/QA26MAAAhtzMB+hAAAMAAABtzg");
	var mask_graphics_649 = new cjs.Graphics().p("Eg/WA26MAAAhtzMB+tAAAMAAABtzg");
	var mask_graphics_650 = new cjs.Graphics().p("Eg/bA26MAAAhtzMB+3AAAMAAABtzg");
	var mask_graphics_651 = new cjs.Graphics().p("Eg/hA26MAAAhtzMB/DAAAMAAABtzg");
	var mask_graphics_652 = new cjs.Graphics().p("Eg/mA26MAAAhtzMB/NAAAMAAABtzg");
	var mask_graphics_653 = new cjs.Graphics().p("Eg/rA26MAAAhtzMB/XAAAMAAABtzg");
	var mask_graphics_654 = new cjs.Graphics().p("Eg/xA26MAAAhtzMB/jAAAMAAABtzg");
	var mask_graphics_655 = new cjs.Graphics().p("Eg/2A26MAAAhtzMB/tAAAMAAABtzg");
	var mask_graphics_656 = new cjs.Graphics().p("Eg/8A26MAAAhtzMB/5AAAMAAABtzg");
	var mask_graphics_657 = new cjs.Graphics().p("EhABA26MAAAhtzMCADAAAMAAABtzg");
	var mask_graphics_658 = new cjs.Graphics().p("EhAGA26MAAAhtzMCAOAAAMAAABtzg");
	var mask_graphics_659 = new cjs.Graphics().p("EhAMA26MAAAhtzMCAZAAAMAAABtzg");
	var mask_graphics_660 = new cjs.Graphics().p("EhARA26MAAAhtzMCAjAAAMAAABtzg");
	var mask_graphics_661 = new cjs.Graphics().p("EhAXA26MAAAhtzMCAvAAAMAAABtzg");
	var mask_graphics_662 = new cjs.Graphics().p("EhAcA26MAAAhtzMCA5AAAMAAABtzg");
	var mask_graphics_663 = new cjs.Graphics().p("EhAiA26MAAAhtzMCBEAAAMAAABtzg");
	var mask_graphics_664 = new cjs.Graphics().p("EhAnA26MAAAhtzMCBPAAAMAAABtzg");
	var mask_graphics_665 = new cjs.Graphics().p("EhAsA26MAAAhtzMCBZAAAMAAABtzg");
	var mask_graphics_666 = new cjs.Graphics().p("EhAyA26MAAAhtzMCBlAAAMAAABtzg");
	var mask_graphics_667 = new cjs.Graphics().p("EhA4A26MAAAhtzMCBwAAAMAAABtzg");
	var mask_graphics_668 = new cjs.Graphics().p("EhA9A26MAAAhtzMCB7AAAMAAABtzg");
	var mask_graphics_669 = new cjs.Graphics().p("EhBCA26MAAAhtzMCCFAAAMAAABtzg");
	var mask_graphics_670 = new cjs.Graphics().p("EhBIA26MAAAhtzMCCRAAAMAAABtzg");
	var mask_graphics_671 = new cjs.Graphics().p("EhBNA26MAAAhtzMCCbAAAMAAABtzg");
	var mask_graphics_672 = new cjs.Graphics().p("EhBTA26MAAAhtzMCCnAAAMAAABtzg");
	var mask_graphics_673 = new cjs.Graphics().p("EhBYA26MAAAhtzMCCxAAAMAAABtzg");
	var mask_graphics_674 = new cjs.Graphics().p("EhBdA26MAAAhtzMCC8AAAMAAABtzg");
	var mask_graphics_675 = new cjs.Graphics().p("EhBjA26MAAAht0MCDHAAAMAAABt0g");
	var mask_graphics_676 = new cjs.Graphics().p("EhBpA26MAAAht0MCDTAAAMAAABt0g");
	var mask_graphics_677 = new cjs.Graphics().p("EhBuA26MAAAht0MCDdAAAMAAABt0g");
	var mask_graphics_678 = new cjs.Graphics().p("EhBzA26MAAAht0MCDnAAAMAAABt0g");
	var mask_graphics_679 = new cjs.Graphics().p("EhB5A26MAAAht0MCDzAAAMAAABt0g");
	var mask_graphics_680 = new cjs.Graphics().p("EhB+A26MAAAht0MCD9AAAMAAABt0g");
	var mask_graphics_681 = new cjs.Graphics().p("EhCDA26MAAAht0MCEIAAAMAAABt0g");
	var mask_graphics_682 = new cjs.Graphics().p("EhCJA26MAAAht0MCETAAAMAAABt0g");
	var mask_graphics_683 = new cjs.Graphics().p("EhCOA26MAAAht0MCEdAAAMAAABt0g");
	var mask_graphics_684 = new cjs.Graphics().p("EhCUA26MAAAht0MCEpAAAMAAABt0g");
	var mask_graphics_685 = new cjs.Graphics().p("EhCZA26MAAAht0MCEzAAAMAAABt0g");
	var mask_graphics_686 = new cjs.Graphics().p("EhCfA26MAAAht0MCE/AAAMAAABt0g");
	var mask_graphics_687 = new cjs.Graphics().p("EhCkA26MAAAht0MCFJAAAMAAABt0g");
	var mask_graphics_688 = new cjs.Graphics().p("EhCpA26MAAAht0MCFTAAAMAAABt0g");
	var mask_graphics_689 = new cjs.Graphics().p("EhCvA26MAAAht0MCFfAAAMAAABt0g");
	var mask_graphics_690 = new cjs.Graphics().p("EhC0A26MAAAht0MCFpAAAMAAABt0g");
	var mask_graphics_691 = new cjs.Graphics().p("EhC6A26MAAAht0MCF1AAAMAAABt0g");
	var mask_graphics_692 = new cjs.Graphics().p("EhC/A26MAAAht0MCF/AAAMAAABt0g");
	var mask_graphics_693 = new cjs.Graphics().p("EhDFA26MAAAht0MCGLAAAMAAABt0g");
	var mask_graphics_694 = new cjs.Graphics().p("EhDKA26MAAAht0MCGVAAAMAAABt0g");
	var mask_graphics_695 = new cjs.Graphics().p("EhDPA26MAAAht0MCGfAAAMAAABt0g");
	var mask_graphics_696 = new cjs.Graphics().p("EhDVA26MAAAht0MCGrAAAMAAABt0g");
	var mask_graphics_697 = new cjs.Graphics().p("EhDaA26MAAAht0MCG1AAAMAAABt0g");
	var mask_graphics_698 = new cjs.Graphics().p("EhDgA26MAAAht0MCHAAAAMAAABt0g");
	var mask_graphics_699 = new cjs.Graphics().p("EhDlA26MAAAht0MCHLAAAMAAABt0g");
	var mask_graphics_700 = new cjs.Graphics().p("EhDqA26MAAAht0MCHVAAAMAAABt0g");
	var mask_graphics_701 = new cjs.Graphics().p("EhDwA26MAAAht0MCHhAAAMAAABt0g");
	var mask_graphics_702 = new cjs.Graphics().p("EhD1A26MAAAht0MCHrAAAMAAABt0g");
	var mask_graphics_703 = new cjs.Graphics().p("EhD7A26MAAAht0MCH3AAAMAAABt0g");
	var mask_graphics_704 = new cjs.Graphics().p("EhEAA26MAAAht0MCIBAAAMAAABt0g");
	var mask_graphics_705 = new cjs.Graphics().p("EhEGA26MAAAht0MCINAAAMAAABt0g");
	var mask_graphics_706 = new cjs.Graphics().p("EhELA26MAAAht0MCIXAAAMAAABt0g");
	var mask_graphics_707 = new cjs.Graphics().p("EhEQA26MAAAht0MCIiAAAMAAABt0g");
	var mask_graphics_708 = new cjs.Graphics().p("EhEWA26MAAAht0MCItAAAMAAABt0g");
	var mask_graphics_709 = new cjs.Graphics().p("EhEcA26MAAAht0MCI5AAAMAAABt0g");
	var mask_graphics_710 = new cjs.Graphics().p("EhEhA26MAAAht0MCJDAAAMAAABt0g");
	var mask_graphics_711 = new cjs.Graphics().p("EhEmA26MAAAht0MCJNAAAMAAABt0g");
	var mask_graphics_712 = new cjs.Graphics().p("EhEsA26MAAAht0MCJZAAAMAAABt0g");
	var mask_graphics_713 = new cjs.Graphics().p("EhExA26MAAAht0MCJjAAAMAAABt0g");
	var mask_graphics_714 = new cjs.Graphics().p("EhE3A26MAAAht0MCJvAAAMAAABt0g");
	var mask_graphics_715 = new cjs.Graphics().p("EhE8A26MAAAht0MCJ5AAAMAAABt0g");
	var mask_graphics_716 = new cjs.Graphics().p("EhFBA26MAAAht0MCKEAAAMAAABt0g");
	var mask_graphics_717 = new cjs.Graphics().p("EhFHA26MAAAht0MCKPAAAMAAABt0g");
	var mask_graphics_718 = new cjs.Graphics().p("EhFMA26MAAAht0MCKZAAAMAAABt0g");
	var mask_graphics_719 = new cjs.Graphics().p("EhFSA26MAAAht0MCKlAAAMAAABt0g");
	var mask_graphics_720 = new cjs.Graphics().p("EhFXA26MAAAht0MCKvAAAMAAABt0g");
	var mask_graphics_721 = new cjs.Graphics().p("EhFdA26MAAAht0MCK7AAAMAAABt0g");
	var mask_graphics_722 = new cjs.Graphics().p("EhFiA26MAAAht0MCLFAAAMAAABt0g");
	var mask_graphics_723 = new cjs.Graphics().p("EhFnA26MAAAht0MCLPAAAMAAABt0g");
	var mask_graphics_724 = new cjs.Graphics().p("EhFtA26MAAAht0MCLbAAAMAAABt0g");
	var mask_graphics_725 = new cjs.Graphics().p("EhFyA27MAAAht0MCLlAAAMAAABt0g");
	var mask_graphics_726 = new cjs.Graphics().p("EhF4A27MAAAht0MCLxAAAMAAABt0g");
	var mask_graphics_727 = new cjs.Graphics().p("EhF9A27MAAAht0MCL7AAAMAAABt0g");
	var mask_graphics_728 = new cjs.Graphics().p("EhGDA27MAAAht0MCMGAAAMAAABt0g");
	var mask_graphics_729 = new cjs.Graphics().p("EhGIA27MAAAht0MCMRAAAMAAABt0g");
	var mask_graphics_730 = new cjs.Graphics().p("EhGNA27MAAAht0MCMbAAAMAAABt0g");
	var mask_graphics_731 = new cjs.Graphics().p("EhGTA27MAAAht0MCMnAAAMAAABt0g");
	var mask_graphics_732 = new cjs.Graphics().p("EhGYA27MAAAht0MCMxAAAMAAABt0g");
	var mask_graphics_733 = new cjs.Graphics().p("EhGdA27MAAAht0MCM7AAAMAAABt0g");
	var mask_graphics_734 = new cjs.Graphics().p("EhGjA27MAAAht0MCNHAAAMAAABt0g");
	var mask_graphics_735 = new cjs.Graphics().p("EhGpA27MAAAht0MCNSAAAMAAABt0g");
	var mask_graphics_736 = new cjs.Graphics().p("EhGuA27MAAAht0MCNdAAAMAAABt0g");
	var mask_graphics_737 = new cjs.Graphics().p("EhGzA27MAAAht0MCNnAAAMAAABt0g");
	var mask_graphics_738 = new cjs.Graphics().p("EhG5A27MAAAht0MCNzAAAMAAABt0g");
	var mask_graphics_739 = new cjs.Graphics().p("EhG+A27MAAAht0MCN9AAAMAAABt0g");
	var mask_graphics_740 = new cjs.Graphics().p("EhHDA27MAAAht0MCOIAAAMAAABt0g");
	var mask_graphics_741 = new cjs.Graphics().p("EhHJA27MAAAht0MCOTAAAMAAABt0g");
	var mask_graphics_742 = new cjs.Graphics().p("EhHPA27MAAAht0MCOfAAAMAAABt0g");
	var mask_graphics_743 = new cjs.Graphics().p("EhHUA27MAAAht0MCOpAAAMAAABt0g");
	var mask_graphics_744 = new cjs.Graphics().p("EhHaA27MAAAht0MCO1AAAMAAABt0g");
	var mask_graphics_745 = new cjs.Graphics().p("EhHfA27MAAAht0MCO/AAAMAAABt0g");
	var mask_graphics_746 = new cjs.Graphics().p("EhHkA27MAAAht0MCPJAAAMAAABt0g");
	var mask_graphics_747 = new cjs.Graphics().p("EhHqA27MAAAht0MCPUAAAMAAABt0g");
	var mask_graphics_748 = new cjs.Graphics().p("EhHvA27MAAAht0MCPfAAAMAAABt0g");
	var mask_graphics_749 = new cjs.Graphics().p("EhH0A27MAAAht0MCPpAAAMAAABt0g");
	var mask_graphics_750 = new cjs.Graphics().p("EhH6A27MAAAht0MCP1AAAMAAABt0g");
	var mask_graphics_751 = new cjs.Graphics().p("EhIAA27MAAAht0MCQAAAAMAAABt0g");
	var mask_graphics_752 = new cjs.Graphics().p("EhIFA27MAAAht0MCQLAAAMAAABt0g");
	var mask_graphics_753 = new cjs.Graphics().p("EhIKA27MAAAht0MCQVAAAMAAABt0g");
	var mask_graphics_754 = new cjs.Graphics().p("EhIQA27MAAAht0MCQhAAAMAAABt0g");
	var mask_graphics_755 = new cjs.Graphics().p("EhIVA27MAAAht0MCQrAAAMAAABt0g");
	var mask_graphics_756 = new cjs.Graphics().p("EhIaA27MAAAht0MCQ1AAAMAAABt0g");
	var mask_graphics_757 = new cjs.Graphics().p("EhIgA27MAAAht0MCRBAAAMAAABt0g");
	var mask_graphics_758 = new cjs.Graphics().p("EhImA27MAAAht0MCRMAAAMAAABt0g");
	var mask_graphics_759 = new cjs.Graphics().p("EhIrA27MAAAht0MCRXAAAMAAABt0g");
	var mask_graphics_760 = new cjs.Graphics().p("EhIwA27MAAAht0MCRhAAAMAAABt0g");
	var mask_graphics_761 = new cjs.Graphics().p("EhI2A27MAAAht0MCRtAAAMAAABt0g");
	var mask_graphics_762 = new cjs.Graphics().p("EhI7A27MAAAht0MCR3AAAMAAABt0g");
	var mask_graphics_763 = new cjs.Graphics().p("EhJBA27MAAAht0MCSDAAAMAAABt0g");
	var mask_graphics_764 = new cjs.Graphics().p("EhJGA27MAAAht0MCSNAAAMAAABt0g");
	var mask_graphics_765 = new cjs.Graphics().p("EhJLA27MAAAht0MCSXAAAMAAABt0g");
	var mask_graphics_766 = new cjs.Graphics().p("EhJRA27MAAAht0MCSjAAAMAAABt0g");
	var mask_graphics_767 = new cjs.Graphics().p("EhJWA27MAAAht0MCStAAAMAAABt0g");
	var mask_graphics_768 = new cjs.Graphics().p("EhJcA27MAAAht0MCS5AAAMAAABt0g");
	var mask_graphics_769 = new cjs.Graphics().p("EhJhA27MAAAht0MCTDAAAMAAABt0g");
	var mask_graphics_770 = new cjs.Graphics().p("EhJmA27MAAAht0MCTNAAAMAAABt0g");
	var mask_graphics_771 = new cjs.Graphics().p("EhJsA27MAAAht0MCTZAAAMAAABt0g");
	var mask_graphics_772 = new cjs.Graphics().p("EhJxA27MAAAht0MCTjAAAMAAABt0g");
	var mask_graphics_773 = new cjs.Graphics().p("EhJ3A27MAAAht0MCTvAAAMAAABt0g");
	var mask_graphics_774 = new cjs.Graphics().p("EhJ8A27MAAAht0MCT5AAAMAAABt0g");
	var mask_graphics_775 = new cjs.Graphics().p("EhKBA26MAAAht0MCUEAAAMAAABt0g");
	var mask_graphics_776 = new cjs.Graphics().p("EhKHA26MAAAht0MCUPAAAMAAABt0g");
	var mask_graphics_777 = new cjs.Graphics().p("EhKNA26MAAAht0MCUbAAAMAAABt0g");
	var mask_graphics_778 = new cjs.Graphics().p("EhKSA26MAAAht0MCUlAAAMAAABt0g");
	var mask_graphics_779 = new cjs.Graphics().p("EhKXA26MAAAht0MCUwAAAMAAABt0g");
	var mask_graphics_780 = new cjs.Graphics().p("EhKdA26MAAAht0MCU7AAAMAAABt0g");
	var mask_graphics_781 = new cjs.Graphics().p("EhKiA26MAAAht0MCVFAAAMAAABt0g");
	var mask_graphics_782 = new cjs.Graphics().p("EhKnA26MAAAht0MCVPAAAMAAABt0g");
	var mask_graphics_783 = new cjs.Graphics().p("EhKtA26MAAAht0MCVbAAAMAAABt0g");
	var mask_graphics_784 = new cjs.Graphics().p("EhKzA26MAAAht0MCVmAAAMAAABt0g");
	var mask_graphics_785 = new cjs.Graphics().p("EhK4A26MAAAht0MCVxAAAMAAABt0g");
	var mask_graphics_786 = new cjs.Graphics().p("EhK9A26MAAAht0MCV7AAAMAAABt0g");
	var mask_graphics_787 = new cjs.Graphics().p("EhLDA26MAAAht0MCWHAAAMAAABt0g");
	var mask_graphics_788 = new cjs.Graphics().p("EhLIA26MAAAht0MCWRAAAMAAABt0g");
	var mask_graphics_789 = new cjs.Graphics().p("EhLOA26MAAAht0MCWdAAAMAAABt0g");
	var mask_graphics_790 = new cjs.Graphics().p("EhLTA26MAAAht0MCWnAAAMAAABt0g");
	var mask_graphics_791 = new cjs.Graphics().p("EhLYA26MAAAht0MCWyAAAMAAABt0g");
	var mask_graphics_792 = new cjs.Graphics().p("EhLeA26MAAAht0MCW9AAAMAAABt0g");
	var mask_graphics_793 = new cjs.Graphics().p("EhLkA26MAAAht0MCXJAAAMAAABt0g");
	var mask_graphics_794 = new cjs.Graphics().p("EhLpA26MAAAht0MCXTAAAMAAABt0g");
	var mask_graphics_795 = new cjs.Graphics().p("EhLuA26MAAAht0MCXdAAAMAAABt0g");
	var mask_graphics_796 = new cjs.Graphics().p("EhL0A26MAAAht0MCXpAAAMAAABt0g");
	var mask_graphics_797 = new cjs.Graphics().p("EhL5A26MAAAht0MCXzAAAMAAABt0g");
	var mask_graphics_798 = new cjs.Graphics().p("EhL+A26MAAAht0MCX+AAAMAAABt0g");
	var mask_graphics_799 = new cjs.Graphics().p("EhMEA26MAAAht0MCYJAAAMAAABt0g");
	var mask_graphics_800 = new cjs.Graphics().p("EhMJA26MAAAht0MCYTAAAMAAABt0g");
	var mask_graphics_801 = new cjs.Graphics().p("EhMPA26MAAAht0MCYfAAAMAAABt0g");
	var mask_graphics_802 = new cjs.Graphics().p("EhMUA26MAAAht0MCYpAAAMAAABt0g");
	var mask_graphics_803 = new cjs.Graphics().p("EhMaA26MAAAht0MCY1AAAMAAABt0g");
	var mask_graphics_804 = new cjs.Graphics().p("EhMfA26MAAAht0MCY/AAAMAAABt0g");
	var mask_graphics_805 = new cjs.Graphics().p("EhMkA26MAAAht0MCZKAAAMAAABt0g");
	var mask_graphics_806 = new cjs.Graphics().p("EhMqA26MAAAht0MCZVAAAMAAABt0g");
	var mask_graphics_807 = new cjs.Graphics().p("EhMvA26MAAAht0MCZfAAAMAAABt0g");
	var mask_graphics_808 = new cjs.Graphics().p("EhM1A26MAAAht0MCZrAAAMAAABt0g");
	var mask_graphics_809 = new cjs.Graphics().p("EhM6A26MAAAht0MCZ1AAAMAAABt0g");
	var mask_graphics_810 = new cjs.Graphics().p("EhNAA26MAAAht0MCaBAAAMAAABt0g");
	var mask_graphics_811 = new cjs.Graphics().p("EhNFA26MAAAht0MCaLAAAMAAABt0g");
	var mask_graphics_812 = new cjs.Graphics().p("EhNKA26MAAAht0MCaWAAAMAAABt0g");
	var mask_graphics_813 = new cjs.Graphics().p("EhNQA26MAAAht0MCahAAAMAAABt0g");
	var mask_graphics_814 = new cjs.Graphics().p("EhNWA26MAAAht0MCatAAAMAAABt0g");
	var mask_graphics_815 = new cjs.Graphics().p("EhNbA26MAAAht0MCa3AAAMAAABt0g");
	var mask_graphics_816 = new cjs.Graphics().p("EhNgA26MAAAht0MCbBAAAMAAABt0g");
	var mask_graphics_817 = new cjs.Graphics().p("EhNmA26MAAAht0MCbNAAAMAAABt0g");
	var mask_graphics_818 = new cjs.Graphics().p("EhNrA26MAAAht0MCbXAAAMAAABt0g");
	var mask_graphics_819 = new cjs.Graphics().p("EhNxA26MAAAht0MCbiAAAMAAABt0g");
	var mask_graphics_820 = new cjs.Graphics().p("EhN2A26MAAAht0MCbtAAAMAAABt0g");
	var mask_graphics_821 = new cjs.Graphics().p("EhN7A26MAAAht0MCb3AAAMAAABt0g");
	var mask_graphics_822 = new cjs.Graphics().p("EhOBA26MAAAht0MCcDAAAMAAABt0g");
	var mask_graphics_823 = new cjs.Graphics().p("EhOGA26MAAAht0MCcNAAAMAAABt0g");
	var mask_graphics_824 = new cjs.Graphics().p("EhOMA26MAAAht0MCcZAAAMAAABt0g");
	var mask_graphics_825 = new cjs.Graphics().p("EhORA27MAAAht0MCcjAAAMAAABt0g");
	var mask_graphics_826 = new cjs.Graphics().p("EhOXA27MAAAht0MCcvAAAMAAABt0g");
	var mask_graphics_827 = new cjs.Graphics().p("EhOcA27MAAAht0MCc5AAAMAAABt0g");
	var mask_graphics_828 = new cjs.Graphics().p("EhOhA27MAAAht0MCdEAAAMAAABt0g");
	var mask_graphics_829 = new cjs.Graphics().p("EhOnA27MAAAht0MCdPAAAMAAABt0g");
	var mask_graphics_830 = new cjs.Graphics().p("EhOsA27MAAAht0MCdZAAAMAAABt0g");
	var mask_graphics_831 = new cjs.Graphics().p("EhOyA27MAAAht0MCdlAAAMAAABt0g");
	var mask_graphics_832 = new cjs.Graphics().p("EhO3A27MAAAht0MCdvAAAMAAABt0g");
	var mask_graphics_833 = new cjs.Graphics().p("EhO9A27MAAAht0MCd7AAAMAAABt0g");
	var mask_graphics_834 = new cjs.Graphics().p("EhPCA27MAAAht0MCeFAAAMAAABt0g");
	var mask_graphics_835 = new cjs.Graphics().p("EhPHA27MAAAht0MCePAAAMAAABt0g");
	var mask_graphics_836 = new cjs.Graphics().p("EhPNA27MAAAht0MCebAAAMAAABt0g");
	var mask_graphics_837 = new cjs.Graphics().p("EhPSA27MAAAht0MCelAAAMAAABt0g");
	var mask_graphics_838 = new cjs.Graphics().p("EhPYA27MAAAht0MCexAAAMAAABt0g");
	var mask_graphics_839 = new cjs.Graphics().p("EhPdA27MAAAht0MCe7AAAMAAABt0g");
	var mask_graphics_840 = new cjs.Graphics().p("EhPiA27MAAAht0MCfFAAAMAAABt0g");
	var mask_graphics_841 = new cjs.Graphics().p("EhPoA27MAAAht0MCfRAAAMAAABt0g");
	var mask_graphics_842 = new cjs.Graphics().p("EhPtA27MAAAht0MCfbAAAMAAABt0g");
	var mask_graphics_843 = new cjs.Graphics().p("EhPzA27MAAAht0MCfnAAAMAAABt0g");
	var mask_graphics_844 = new cjs.Graphics().p("EhP4A27MAAAht0MCfxAAAMAAABt0g");
	var mask_graphics_845 = new cjs.Graphics().p("EhP9A27MAAAht0MCf7AAAMAAABt0g");
	var mask_graphics_846 = new cjs.Graphics().p("EhQDA27MAAAht0MCgHAAAMAAABt0g");
	var mask_graphics_847 = new cjs.Graphics().p("EhQJA27MAAAht0MCgSAAAMAAABt0g");
	var mask_graphics_848 = new cjs.Graphics().p("EhQOA27MAAAht0MCgdAAAMAAABt0g");
	var mask_graphics_849 = new cjs.Graphics().p("EhQTA27MAAAht0MCgnAAAMAAABt0g");
	var mask_graphics_850 = new cjs.Graphics().p("EhQYA27MAAAht0MCgxAAAMAAABt0g");
	var mask_graphics_851 = new cjs.Graphics().p("EhQeA27MAAAht0MCg9AAAMAAABt0g");
	var mask_graphics_852 = new cjs.Graphics().p("EhQkA27MAAAht0MChIAAAMAAABt0g");
	var mask_graphics_853 = new cjs.Graphics().p("EhQpA27MAAAht0MChTAAAMAAABt0g");
	var mask_graphics_854 = new cjs.Graphics().p("EhQuA27MAAAht0MChdAAAMAAABt0g");
	var mask_graphics_855 = new cjs.Graphics().p("EhQ0A27MAAAht0MChpAAAMAAABt0g");
	var mask_graphics_856 = new cjs.Graphics().p("EhQ5A27MAAAht0MChzAAAMAAABt0g");
	var mask_graphics_857 = new cjs.Graphics().p("EhQ/A27MAAAht0MCh/AAAMAAABt0g");
	var mask_graphics_858 = new cjs.Graphics().p("EhREA27MAAAht0MCiJAAAMAAABt0g");
	var mask_graphics_859 = new cjs.Graphics().p("EhRKA27MAAAht0MCiVAAAMAAABt0g");
	var mask_graphics_860 = new cjs.Graphics().p("EhRPA27MAAAht0MCifAAAMAAABt0g");
	var mask_graphics_861 = new cjs.Graphics().p("EhRUA27MAAAht0MCiqAAAMAAABt0g");
	var mask_graphics_862 = new cjs.Graphics().p("EhRaA27MAAAht0MCi1AAAMAAABt0g");
	var mask_graphics_863 = new cjs.Graphics().p("EhRgA27MAAAht0MCjBAAAMAAABt0g");
	var mask_graphics_864 = new cjs.Graphics().p("EhRlA27MAAAht0MCjLAAAMAAABt0g");
	var mask_graphics_865 = new cjs.Graphics().p("EhRqA27MAAAht0MCjVAAAMAAABt0g");
	var mask_graphics_866 = new cjs.Graphics().p("EhRwA27MAAAht0MCjhAAAMAAABt0g");
	var mask_graphics_867 = new cjs.Graphics().p("EhR1A27MAAAht0MCjrAAAMAAABt0g");
	var mask_graphics_868 = new cjs.Graphics().p("EhR7A27MAAAht0MCj2AAAMAAABt0g");
	var mask_graphics_869 = new cjs.Graphics().p("EhSAA27MAAAht0MCkBAAAMAAABt0g");
	var mask_graphics_870 = new cjs.Graphics().p("EhSFA27MAAAht0MCkLAAAMAAABt0g");
	var mask_graphics_871 = new cjs.Graphics().p("EhSLA27MAAAht0MCkXAAAMAAABt0g");
	var mask_graphics_872 = new cjs.Graphics().p("EhSQA27MAAAht0MCkhAAAMAAABt0g");
	var mask_graphics_873 = new cjs.Graphics().p("EhSWA27MAAAht0MCktAAAMAAABt0g");
	var mask_graphics_874 = new cjs.Graphics().p("EhSbA27MAAAht0MCk3AAAMAAABt0g");
	var mask_graphics_875 = new cjs.Graphics().p("EhSgA26MAAAht0MClBAAAMAAABt0g");
	var mask_graphics_876 = new cjs.Graphics().p("EhSmA26MAAAht0MClNAAAMAAABt0g");
	var mask_graphics_877 = new cjs.Graphics().p("EhSrA26MAAAht0MClXAAAMAAABt0g");
	var mask_graphics_878 = new cjs.Graphics().p("EhSxA26MAAAht0MCljAAAMAAABt0g");
	var mask_graphics_879 = new cjs.Graphics().p("EhS2A26MAAAht0MCltAAAMAAABt0g");
	var mask_graphics_880 = new cjs.Graphics().p("EhS7A26MAAAht0MCl3AAAMAAABt0g");
	var mask_graphics_881 = new cjs.Graphics().p("EhTBA26MAAAht0MCmDAAAMAAABt0g");
	var mask_graphics_882 = new cjs.Graphics().p("EhTHA26MAAAht0MCmOAAAMAAABt0g");
	var mask_graphics_883 = new cjs.Graphics().p("EhTMA26MAAAht0MCmZAAAMAAABt0g");
	var mask_graphics_884 = new cjs.Graphics().p("EhTRA26MAAAht0MCmjAAAMAAABt0g");
	var mask_graphics_885 = new cjs.Graphics().p("EhTXA26MAAAht0MCmuAAAMAAABt0g");
	var mask_graphics_886 = new cjs.Graphics().p("EhTcA26MAAAht0MCm5AAAMAAABt0g");
	var mask_graphics_887 = new cjs.Graphics().p("EhThA26MAAAht0MCnDAAAMAAABt0g");
	var mask_graphics_888 = new cjs.Graphics().p("EhTnA26MAAAht0MCnPAAAMAAABt0g");
	var mask_graphics_889 = new cjs.Graphics().p("EhTtA26MAAAht0MCnaAAAMAAABt0g");
	var mask_graphics_890 = new cjs.Graphics().p("EhTyA26MAAAht0MCnlAAAMAAABt0g");
	var mask_graphics_891 = new cjs.Graphics().p("EhT3A26MAAAht0MCnvAAAMAAABt0g");
	var mask_graphics_892 = new cjs.Graphics().p("EhT9A26MAAAht0MCn7AAAMAAABt0g");
	var mask_graphics_893 = new cjs.Graphics().p("EhUCA26MAAAht0MCoFAAAMAAABt0g");
	var mask_graphics_894 = new cjs.Graphics().p("EhUIA26MAAAht0MCoRAAAMAAABt0g");
	var mask_graphics_895 = new cjs.Graphics().p("EhUNA26MAAAht0MCobAAAMAAABt0g");
	var mask_graphics_896 = new cjs.Graphics().p("EhUSA26MAAAht0MComAAAMAAABt0g");
	var mask_graphics_897 = new cjs.Graphics().p("EhUYA26MAAAht0MCoxAAAMAAABt0g");
	var mask_graphics_898 = new cjs.Graphics().p("EhUdA26MAAAht0MCo7AAAMAAABt0g");
	var mask_graphics_899 = new cjs.Graphics().p("EhUjA26MAAAht0MCpHAAAMAAABt0g");
	var mask_graphics_900 = new cjs.Graphics().p("EhUoA26MAAAht0MCpRAAAMAAABt0g");
	var mask_graphics_901 = new cjs.Graphics().p("EhUuA26MAAAht0MCpcAAAMAAABt0g");
	var mask_graphics_902 = new cjs.Graphics().p("EhUzA26MAAAht0MCpnAAAMAAABt0g");
	var mask_graphics_903 = new cjs.Graphics().p("EhU4A26MAAAht0MCpxAAAMAAABt0g");
	var mask_graphics_904 = new cjs.Graphics().p("EhU+A26MAAAht0MCp9AAAMAAABt0g");
	var mask_graphics_905 = new cjs.Graphics().p("EhVDA26MAAAht0MCqHAAAMAAABt0g");
	var mask_graphics_906 = new cjs.Graphics().p("EhVJA26MAAAht0MCqTAAAMAAABt0g");
	var mask_graphics_907 = new cjs.Graphics().p("EhVOA26MAAAht0MCqdAAAMAAABt0g");
	var mask_graphics_908 = new cjs.Graphics().p("EhVUA26MAAAht0MCqpAAAMAAABt0g");
	var mask_graphics_909 = new cjs.Graphics().p("EhVZA26MAAAht0MCqzAAAMAAABt0g");
	var mask_graphics_910 = new cjs.Graphics().p("EhVeA26MAAAht0MCq9AAAMAAABt0g");
	var mask_graphics_911 = new cjs.Graphics().p("EhVkA26MAAAht0MCrJAAAMAAABt0g");
	var mask_graphics_912 = new cjs.Graphics().p("EhVpA26MAAAht0MCrTAAAMAAABt0g");
	var mask_graphics_913 = new cjs.Graphics().p("EhVvA26MAAAht0MCrfAAAMAAABt0g");
	var mask_graphics_914 = new cjs.Graphics().p("EhV0A26MAAAht0MCrpAAAMAAABt0g");
	var mask_graphics_915 = new cjs.Graphics().p("EhV6A26MAAAht0MCr0AAAMAAABt0g");
	var mask_graphics_916 = new cjs.Graphics().p("EhV/A26MAAAht0MCr/AAAMAAABt0g");
	var mask_graphics_917 = new cjs.Graphics().p("EhWEA26MAAAht0MCsJAAAMAAABt0g");
	var mask_graphics_918 = new cjs.Graphics().p("EhWKA26MAAAht0MCsVAAAMAAABt0g");
	var mask_graphics_919 = new cjs.Graphics().p("EhWPA26MAAAht0MCsfAAAMAAABt0g");
	var mask_graphics_920 = new cjs.Graphics().p("EhWUA26MAAAht0MCsqAAAMAAABt0g");
	var mask_graphics_921 = new cjs.Graphics().p("EhWaA26MAAAht0MCs1AAAMAAABt0g");
	var mask_graphics_922 = new cjs.Graphics().p("EhWgA26MAAAht0MCtBAAAMAAABt0g");
	var mask_graphics_923 = new cjs.Graphics().p("EhWlA26MAAAht0MCtLAAAMAAABt0g");
	var mask_graphics_924 = new cjs.Graphics().p("EhWrA26MAAAht0MCtXAAAMAAABt0g");
	var mask_graphics_925 = new cjs.Graphics().p("EhWwA27MAAAht0MCthAAAMAAABt0g");
	var mask_graphics_926 = new cjs.Graphics().p("EhW1A27MAAAht0MCtrAAAMAAABt0g");
	var mask_graphics_927 = new cjs.Graphics().p("EhW7A27MAAAht0MCt3AAAMAAABt0g");
	var mask_graphics_928 = new cjs.Graphics().p("EhXAA27MAAAht0MCuBAAAMAAABt0g");
	var mask_graphics_929 = new cjs.Graphics().p("EhXFA27MAAAht0MCuMAAAMAAABt0g");
	var mask_graphics_930 = new cjs.Graphics().p("EhXLA27MAAAht0MCuXAAAMAAABt0g");
	var mask_graphics_931 = new cjs.Graphics().p("EhXRA27MAAAht0MCujAAAMAAABt0g");
	var mask_graphics_932 = new cjs.Graphics().p("EhXWA27MAAAht0MCutAAAMAAABt0g");
	var mask_graphics_933 = new cjs.Graphics().p("EhXbA27MAAAht0MCu3AAAMAAABt0g");
	var mask_graphics_934 = new cjs.Graphics().p("EhXhA27MAAAht0MCvDAAAMAAABt0g");
	var mask_graphics_935 = new cjs.Graphics().p("EhXmA27MAAAht0MCvNAAAMAAABt0g");
	var mask_graphics_936 = new cjs.Graphics().p("EhXrA27MAAAht0MCvXAAAMAAABt0g");
	var mask_graphics_937 = new cjs.Graphics().p("EhXxA27MAAAht0MCvjAAAMAAABt0g");
	var mask_graphics_938 = new cjs.Graphics().p("EhX3A27MAAAht0MCvuAAAMAAABt0g");
	var mask_graphics_939 = new cjs.Graphics().p("EhX8A27MAAAht0MCv5AAAMAAABt0g");
	var mask_graphics_940 = new cjs.Graphics().p("EhYBA27MAAAht0MCwDAAAMAAABt0g");
	var mask_graphics_941 = new cjs.Graphics().p("EhYHA27MAAAht0MCwPAAAMAAABt0g");
	var mask_graphics_942 = new cjs.Graphics().p("EhYMA27MAAAht0MCwZAAAMAAABt0g");
	var mask_graphics_943 = new cjs.Graphics().p("EhYSA27MAAAht0MCwlAAAMAAABt0g");
	var mask_graphics_944 = new cjs.Graphics().p("EhYXA27MAAAht0MCwvAAAMAAABt0g");
	var mask_graphics_945 = new cjs.Graphics().p("EhYcA27MAAAht0MCw5AAAMAAABt0g");
	var mask_graphics_946 = new cjs.Graphics().p("EhYiA27MAAAht0MCxFAAAMAAABt0g");
	var mask_graphics_947 = new cjs.Graphics().p("EhYnA27MAAAht0MCxPAAAMAAABt0g");
	var mask_graphics_948 = new cjs.Graphics().p("EhYtA27MAAAht0MCxbAAAMAAABt0g");
	var mask_graphics_949 = new cjs.Graphics().p("EhYyA27MAAAht0MCxlAAAMAAABt0g");
	var mask_graphics_950 = new cjs.Graphics().p("EhY3A27MAAAht0MCxvAAAMAAABt0g");
	var mask_graphics_951 = new cjs.Graphics().p("EhY9A27MAAAht0MCx7AAAMAAABt0g");
	var mask_graphics_952 = new cjs.Graphics().p("EhZCA27MAAAht0MCyFAAAMAAABt0g");
	var mask_graphics_953 = new cjs.Graphics().p("EhZIA27MAAAht0MCyRAAAMAAABt0g");
	var mask_graphics_954 = new cjs.Graphics().p("EhZNA27MAAAht0MCybAAAMAAABt0g");
	var mask_graphics_955 = new cjs.Graphics().p("EhZSA27MAAAht0MCymAAAMAAABt0g");
	var mask_graphics_956 = new cjs.Graphics().p("EhZYA27MAAAht0MCyxAAAMAAABt0g");
	var mask_graphics_957 = new cjs.Graphics().p("EhZeA27MAAAht0MCy9AAAMAAABt0g");
	var mask_graphics_958 = new cjs.Graphics().p("EhZjA27MAAAht0MCzHAAAMAAABt0g");
	var mask_graphics_959 = new cjs.Graphics().p("EhZoA27MAAAht0MCzSAAAMAAABt0g");
	var mask_graphics_960 = new cjs.Graphics().p("EhZuA27MAAAht0MCzdAAAMAAABt0g");
	var mask_graphics_961 = new cjs.Graphics().p("EhZzA27MAAAht0MCznAAAMAAABt0g");
	var mask_graphics_962 = new cjs.Graphics().p("EhZ5A27MAAAht0MCzzAAAMAAABt0g");
	var mask_graphics_963 = new cjs.Graphics().p("EhZ+A27MAAAht0MCz9AAAMAAABt0g");
	var mask_graphics_964 = new cjs.Graphics().p("EhaEA27MAAAht0MC0IAAAMAAABt0g");
	var mask_graphics_965 = new cjs.Graphics().p("EhaJA27MAAAht0MC0TAAAMAAABt0g");
	var mask_graphics_966 = new cjs.Graphics().p("EhaOA27MAAAht0MC0dAAAMAAABt0g");
	var mask_graphics_967 = new cjs.Graphics().p("EhaUA27MAAAht0MC0pAAAMAAABt0g");
	var mask_graphics_968 = new cjs.Graphics().p("EhaZA27MAAAht0MC0zAAAMAAABt0g");
	var mask_graphics_969 = new cjs.Graphics().p("EhafA27MAAAht0MC0/AAAMAAABt0g");
	var mask_graphics_970 = new cjs.Graphics().p("EhakA27MAAAht0MC1JAAAMAAABt0g");
	var mask_graphics_971 = new cjs.Graphics().p("EhapA27MAAAht0MC1TAAAMAAABt0g");
	var mask_graphics_972 = new cjs.Graphics().p("EhavA27MAAAht0MC1fAAAMAAABt0g");
	var mask_graphics_973 = new cjs.Graphics().p("Eha1A27MAAAht0MC1qAAAMAAABt0g");
	var mask_graphics_974 = new cjs.Graphics().p("Eha6A27MAAAht0MC11AAAMAAABt0g");
	var mask_graphics_975 = new cjs.Graphics().p("Eha/A26MAAAht0MC1/AAAMAAABt0g");
	var mask_graphics_976 = new cjs.Graphics().p("EhbFA26MAAAht0MC2LAAAMAAABt0g");
	var mask_graphics_977 = new cjs.Graphics().p("EhbKA26MAAAht0MC2VAAAMAAABt0g");
	var mask_graphics_978 = new cjs.Graphics().p("EhbPA26MAAAht0MC2gAAAMAAABt0g");
	var mask_graphics_979 = new cjs.Graphics().p("EhbVA26MAAAht0MC2rAAAMAAABt0g");
	var mask_graphics_980 = new cjs.Graphics().p("EhbaA26MAAAht0MC21AAAMAAABt0g");
	var mask_graphics_981 = new cjs.Graphics().p("EhbgA26MAAAht0MC3BAAAMAAABt0g");
	var mask_graphics_982 = new cjs.Graphics().p("EhblA26MAAAht0MC3LAAAMAAABt0g");
	var mask_graphics_983 = new cjs.Graphics().p("EhbrA26MAAAht0MC3XAAAMAAABt0g");
	var mask_graphics_984 = new cjs.Graphics().p("EhbwA26MAAAht0MC3hAAAMAAABt0g");
	var mask_graphics_985 = new cjs.Graphics().p("Ehb1A26MAAAht0MC3sAAAMAAABt0g");
	var mask_graphics_986 = new cjs.Graphics().p("Ehb7A26MAAAht0MC33AAAMAAABt0g");
	var mask_graphics_987 = new cjs.Graphics().p("EhcAA26MAAAht0MC4BAAAMAAABt0g");
	var mask_graphics_988 = new cjs.Graphics().p("EhcGA26MAAAht0MC4NAAAMAAABt0g");
	var mask_graphics_989 = new cjs.Graphics().p("EhcLA26MAAAht0MC4XAAAMAAABt0g");
	var mask_graphics_990 = new cjs.Graphics().p("EhcRA26MAAAht0MC4jAAAMAAABt0g");
	var mask_graphics_991 = new cjs.Graphics().p("EhcWA26MAAAht0MC4tAAAMAAABt0g");
	var mask_graphics_992 = new cjs.Graphics().p("EhcbA26MAAAht0MC44AAAMAAABt0g");
	var mask_graphics_993 = new cjs.Graphics().p("EhchA26MAAAht0MC5DAAAMAAABt0g");
	var mask_graphics_994 = new cjs.Graphics().p("EhcmA26MAAAht0MC5NAAAMAAABt0g");
	var mask_graphics_995 = new cjs.Graphics().p("EhcsA26MAAAht0MC5ZAAAMAAABt0g");
	var mask_graphics_996 = new cjs.Graphics().p("EhcxA26MAAAht0MC5jAAAMAAABt0g");
	var mask_graphics_997 = new cjs.Graphics().p("Ehc3A26MAAAht0MC5uAAAMAAABt0g");
	var mask_graphics_998 = new cjs.Graphics().p("Ehc8A26MAAAht0MC55AAAMAAABt0g");
	var mask_graphics_999 = new cjs.Graphics().p("EhdCA26MAAAht0MC6EAAAMAAABt0g");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:23.3,y:352.5}).wait(1).to({graphics:mask_graphics_1,x:23.9,y:352.5}).wait(1).to({graphics:mask_graphics_2,x:24.5,y:352.5}).wait(1).to({graphics:mask_graphics_3,x:25,y:352.5}).wait(1).to({graphics:mask_graphics_4,x:25.6,y:352.5}).wait(1).to({graphics:mask_graphics_5,x:26.2,y:352.5}).wait(1).to({graphics:mask_graphics_6,x:26.8,y:352.5}).wait(1).to({graphics:mask_graphics_7,x:27.3,y:352.5}).wait(1).to({graphics:mask_graphics_8,x:27.9,y:352.5}).wait(1).to({graphics:mask_graphics_9,x:28.5,y:352.5}).wait(1).to({graphics:mask_graphics_10,x:29,y:352.5}).wait(1).to({graphics:mask_graphics_11,x:29.6,y:352.5}).wait(1).to({graphics:mask_graphics_12,x:30.2,y:352.5}).wait(1).to({graphics:mask_graphics_13,x:30.8,y:352.5}).wait(1).to({graphics:mask_graphics_14,x:31.3,y:352.5}).wait(1).to({graphics:mask_graphics_15,x:31.9,y:352.5}).wait(1).to({graphics:mask_graphics_16,x:32.5,y:352.5}).wait(1).to({graphics:mask_graphics_17,x:33,y:352.5}).wait(1).to({graphics:mask_graphics_18,x:33.6,y:352.5}).wait(1).to({graphics:mask_graphics_19,x:34.2,y:352.5}).wait(1).to({graphics:mask_graphics_20,x:34.8,y:352.5}).wait(1).to({graphics:mask_graphics_21,x:35.4,y:352.5}).wait(1).to({graphics:mask_graphics_22,x:35.9,y:352.5}).wait(1).to({graphics:mask_graphics_23,x:36.5,y:352.5}).wait(1).to({graphics:mask_graphics_24,x:37,y:352.5}).wait(1).to({graphics:mask_graphics_25,x:37.6,y:352.5}).wait(1).to({graphics:mask_graphics_26,x:38.2,y:352.5}).wait(1).to({graphics:mask_graphics_27,x:38.8,y:352.5}).wait(1).to({graphics:mask_graphics_28,x:39.4,y:352.5}).wait(1).to({graphics:mask_graphics_29,x:39.9,y:352.5}).wait(1).to({graphics:mask_graphics_30,x:40.5,y:352.5}).wait(1).to({graphics:mask_graphics_31,x:41.1,y:352.5}).wait(1).to({graphics:mask_graphics_32,x:41.6,y:352.5}).wait(1).to({graphics:mask_graphics_33,x:42.2,y:352.5}).wait(1).to({graphics:mask_graphics_34,x:42.8,y:352.5}).wait(1).to({graphics:mask_graphics_35,x:43.4,y:352.5}).wait(1).to({graphics:mask_graphics_36,x:43.9,y:352.5}).wait(1).to({graphics:mask_graphics_37,x:44.5,y:352.5}).wait(1).to({graphics:mask_graphics_38,x:45.1,y:352.5}).wait(1).to({graphics:mask_graphics_39,x:45.6,y:352.5}).wait(1).to({graphics:mask_graphics_40,x:46.2,y:352.5}).wait(1).to({graphics:mask_graphics_41,x:46.8,y:352.5}).wait(1).to({graphics:mask_graphics_42,x:47.4,y:352.5}).wait(1).to({graphics:mask_graphics_43,x:47.9,y:352.5}).wait(1).to({graphics:mask_graphics_44,x:48.5,y:352.5}).wait(1).to({graphics:mask_graphics_45,x:49.1,y:352.5}).wait(1).to({graphics:mask_graphics_46,x:49.7,y:352.5}).wait(1).to({graphics:mask_graphics_47,x:50.2,y:352.5}).wait(1).to({graphics:mask_graphics_48,x:50.8,y:352.5}).wait(1).to({graphics:mask_graphics_49,x:51.4,y:352.5}).wait(1).to({graphics:mask_graphics_50,x:52,y:352.5}).wait(1).to({graphics:mask_graphics_51,x:52.5,y:352.5}).wait(1).to({graphics:mask_graphics_52,x:53.1,y:352.5}).wait(1).to({graphics:mask_graphics_53,x:53.7,y:352.5}).wait(1).to({graphics:mask_graphics_54,x:54.2,y:352.5}).wait(1).to({graphics:mask_graphics_55,x:54.8,y:352.5}).wait(1).to({graphics:mask_graphics_56,x:55.4,y:352.5}).wait(1).to({graphics:mask_graphics_57,x:56,y:352.5}).wait(1).to({graphics:mask_graphics_58,x:56.5,y:352.5}).wait(1).to({graphics:mask_graphics_59,x:57.1,y:352.5}).wait(1).to({graphics:mask_graphics_60,x:57.7,y:352.5}).wait(1).to({graphics:mask_graphics_61,x:58.3,y:352.5}).wait(1).to({graphics:mask_graphics_62,x:58.8,y:352.5}).wait(1).to({graphics:mask_graphics_63,x:59.4,y:352.5}).wait(1).to({graphics:mask_graphics_64,x:60,y:352.5}).wait(1).to({graphics:mask_graphics_65,x:60.5,y:352.5}).wait(1).to({graphics:mask_graphics_66,x:61.1,y:352.5}).wait(1).to({graphics:mask_graphics_67,x:61.7,y:352.5}).wait(1).to({graphics:mask_graphics_68,x:62.3,y:352.5}).wait(1).to({graphics:mask_graphics_69,x:62.8,y:352.5}).wait(1).to({graphics:mask_graphics_70,x:63.4,y:352.5}).wait(1).to({graphics:mask_graphics_71,x:64,y:352.5}).wait(1).to({graphics:mask_graphics_72,x:64.5,y:352.5}).wait(1).to({graphics:mask_graphics_73,x:65.1,y:352.5}).wait(1).to({graphics:mask_graphics_74,x:65.7,y:352.5}).wait(1).to({graphics:mask_graphics_75,x:66.3,y:352.4}).wait(1).to({graphics:mask_graphics_76,x:66.9,y:352.4}).wait(1).to({graphics:mask_graphics_77,x:67.4,y:352.4}).wait(1).to({graphics:mask_graphics_78,x:68,y:352.4}).wait(1).to({graphics:mask_graphics_79,x:68.6,y:352.4}).wait(1).to({graphics:mask_graphics_80,x:69.1,y:352.4}).wait(1).to({graphics:mask_graphics_81,x:69.7,y:352.4}).wait(1).to({graphics:mask_graphics_82,x:70.3,y:352.4}).wait(1).to({graphics:mask_graphics_83,x:70.9,y:352.4}).wait(1).to({graphics:mask_graphics_84,x:71.4,y:352.4}).wait(1).to({graphics:mask_graphics_85,x:72,y:352.4}).wait(1).to({graphics:mask_graphics_86,x:72.6,y:352.4}).wait(1).to({graphics:mask_graphics_87,x:73.1,y:352.4}).wait(1).to({graphics:mask_graphics_88,x:73.7,y:352.4}).wait(1).to({graphics:mask_graphics_89,x:74.3,y:352.4}).wait(1).to({graphics:mask_graphics_90,x:74.9,y:352.4}).wait(1).to({graphics:mask_graphics_91,x:75.4,y:352.4}).wait(1).to({graphics:mask_graphics_92,x:76,y:352.4}).wait(1).to({graphics:mask_graphics_93,x:76.6,y:352.4}).wait(1).to({graphics:mask_graphics_94,x:77.1,y:352.4}).wait(1).to({graphics:mask_graphics_95,x:77.7,y:352.4}).wait(1).to({graphics:mask_graphics_96,x:78.3,y:352.4}).wait(1).to({graphics:mask_graphics_97,x:78.9,y:352.4}).wait(1).to({graphics:mask_graphics_98,x:79.5,y:352.4}).wait(1).to({graphics:mask_graphics_99,x:80,y:352.4}).wait(1).to({graphics:mask_graphics_100,x:80.6,y:352.4}).wait(1).to({graphics:mask_graphics_101,x:81.2,y:352.4}).wait(1).to({graphics:mask_graphics_102,x:81.7,y:352.4}).wait(1).to({graphics:mask_graphics_103,x:82.3,y:352.4}).wait(1).to({graphics:mask_graphics_104,x:82.9,y:352.4}).wait(1).to({graphics:mask_graphics_105,x:83.5,y:352.4}).wait(1).to({graphics:mask_graphics_106,x:84,y:352.4}).wait(1).to({graphics:mask_graphics_107,x:84.6,y:352.4}).wait(1).to({graphics:mask_graphics_108,x:85.2,y:352.4}).wait(1).to({graphics:mask_graphics_109,x:85.7,y:352.4}).wait(1).to({graphics:mask_graphics_110,x:86.3,y:352.4}).wait(1).to({graphics:mask_graphics_111,x:86.9,y:352.4}).wait(1).to({graphics:mask_graphics_112,x:87.5,y:352.4}).wait(1).to({graphics:mask_graphics_113,x:88,y:352.4}).wait(1).to({graphics:mask_graphics_114,x:88.6,y:352.4}).wait(1).to({graphics:mask_graphics_115,x:89.2,y:352.4}).wait(1).to({graphics:mask_graphics_116,x:89.8,y:352.4}).wait(1).to({graphics:mask_graphics_117,x:90.3,y:352.4}).wait(1).to({graphics:mask_graphics_118,x:90.9,y:352.4}).wait(1).to({graphics:mask_graphics_119,x:91.5,y:352.4}).wait(1).to({graphics:mask_graphics_120,x:92,y:352.4}).wait(1).to({graphics:mask_graphics_121,x:92.6,y:352.4}).wait(1).to({graphics:mask_graphics_122,x:93.2,y:352.4}).wait(1).to({graphics:mask_graphics_123,x:93.8,y:352.4}).wait(1).to({graphics:mask_graphics_124,x:94.3,y:352.4}).wait(1).to({graphics:mask_graphics_125,x:94.9,y:352.4}).wait(1).to({graphics:mask_graphics_126,x:95.5,y:352.4}).wait(1).to({graphics:mask_graphics_127,x:96,y:352.4}).wait(1).to({graphics:mask_graphics_128,x:96.6,y:352.4}).wait(1).to({graphics:mask_graphics_129,x:97.2,y:352.4}).wait(1).to({graphics:mask_graphics_130,x:97.8,y:352.4}).wait(1).to({graphics:mask_graphics_131,x:98.4,y:352.4}).wait(1).to({graphics:mask_graphics_132,x:98.9,y:352.4}).wait(1).to({graphics:mask_graphics_133,x:99.5,y:352.4}).wait(1).to({graphics:mask_graphics_134,x:100.1,y:352.4}).wait(1).to({graphics:mask_graphics_135,x:100.6,y:352.4}).wait(1).to({graphics:mask_graphics_136,x:101.2,y:352.4}).wait(1).to({graphics:mask_graphics_137,x:101.8,y:352.4}).wait(1).to({graphics:mask_graphics_138,x:102.4,y:352.4}).wait(1).to({graphics:mask_graphics_139,x:102.9,y:352.4}).wait(1).to({graphics:mask_graphics_140,x:103.5,y:352.4}).wait(1).to({graphics:mask_graphics_141,x:104.1,y:352.4}).wait(1).to({graphics:mask_graphics_142,x:104.6,y:352.4}).wait(1).to({graphics:mask_graphics_143,x:105.2,y:352.4}).wait(1).to({graphics:mask_graphics_144,x:105.8,y:352.4}).wait(1).to({graphics:mask_graphics_145,x:106.4,y:352.4}).wait(1).to({graphics:mask_graphics_146,x:107,y:352.4}).wait(1).to({graphics:mask_graphics_147,x:107.5,y:352.4}).wait(1).to({graphics:mask_graphics_148,x:108.1,y:352.4}).wait(1).to({graphics:mask_graphics_149,x:108.7,y:352.4}).wait(1).to({graphics:mask_graphics_150,x:109.2,y:352.4}).wait(1).to({graphics:mask_graphics_151,x:109.8,y:352.4}).wait(1).to({graphics:mask_graphics_152,x:110.4,y:352.4}).wait(1).to({graphics:mask_graphics_153,x:111,y:352.4}).wait(1).to({graphics:mask_graphics_154,x:111.5,y:352.4}).wait(1).to({graphics:mask_graphics_155,x:112.1,y:352.4}).wait(1).to({graphics:mask_graphics_156,x:112.7,y:352.4}).wait(1).to({graphics:mask_graphics_157,x:113.2,y:352.4}).wait(1).to({graphics:mask_graphics_158,x:113.8,y:352.4}).wait(1).to({graphics:mask_graphics_159,x:114.4,y:352.4}).wait(1).to({graphics:mask_graphics_160,x:115,y:352.4}).wait(1).to({graphics:mask_graphics_161,x:115.5,y:352.4}).wait(1).to({graphics:mask_graphics_162,x:116.1,y:352.4}).wait(1).to({graphics:mask_graphics_163,x:116.7,y:352.4}).wait(1).to({graphics:mask_graphics_164,x:117.2,y:352.4}).wait(1).to({graphics:mask_graphics_165,x:117.8,y:352.4}).wait(1).to({graphics:mask_graphics_166,x:118.4,y:352.4}).wait(1).to({graphics:mask_graphics_167,x:119,y:352.4}).wait(1).to({graphics:mask_graphics_168,x:119.5,y:352.4}).wait(1).to({graphics:mask_graphics_169,x:120.1,y:352.4}).wait(1).to({graphics:mask_graphics_170,x:120.7,y:352.4}).wait(1).to({graphics:mask_graphics_171,x:121.3,y:352.4}).wait(1).to({graphics:mask_graphics_172,x:121.8,y:352.4}).wait(1).to({graphics:mask_graphics_173,x:122.4,y:352.4}).wait(1).to({graphics:mask_graphics_174,x:123,y:352.4}).wait(1).to({graphics:mask_graphics_175,x:123.5,y:352.3}).wait(1).to({graphics:mask_graphics_176,x:124.1,y:352.3}).wait(1).to({graphics:mask_graphics_177,x:124.7,y:352.3}).wait(1).to({graphics:mask_graphics_178,x:125.3,y:352.3}).wait(1).to({graphics:mask_graphics_179,x:125.8,y:352.3}).wait(1).to({graphics:mask_graphics_180,x:126.4,y:352.3}).wait(1).to({graphics:mask_graphics_181,x:127,y:352.3}).wait(1).to({graphics:mask_graphics_182,x:127.5,y:352.3}).wait(1).to({graphics:mask_graphics_183,x:128.1,y:352.3}).wait(1).to({graphics:mask_graphics_184,x:128.7,y:352.3}).wait(1).to({graphics:mask_graphics_185,x:129.3,y:352.3}).wait(1).to({graphics:mask_graphics_186,x:129.9,y:352.3}).wait(1).to({graphics:mask_graphics_187,x:130.4,y:352.3}).wait(1).to({graphics:mask_graphics_188,x:131,y:352.3}).wait(1).to({graphics:mask_graphics_189,x:131.6,y:352.3}).wait(1).to({graphics:mask_graphics_190,x:132.1,y:352.3}).wait(1).to({graphics:mask_graphics_191,x:132.7,y:352.3}).wait(1).to({graphics:mask_graphics_192,x:133.3,y:352.3}).wait(1).to({graphics:mask_graphics_193,x:133.9,y:352.3}).wait(1).to({graphics:mask_graphics_194,x:134.4,y:352.3}).wait(1).to({graphics:mask_graphics_195,x:135,y:352.3}).wait(1).to({graphics:mask_graphics_196,x:135.6,y:352.3}).wait(1).to({graphics:mask_graphics_197,x:136.1,y:352.3}).wait(1).to({graphics:mask_graphics_198,x:136.7,y:352.3}).wait(1).to({graphics:mask_graphics_199,x:137.3,y:352.3}).wait(1).to({graphics:mask_graphics_200,x:137.9,y:352.3}).wait(1).to({graphics:mask_graphics_201,x:138.5,y:352.3}).wait(1).to({graphics:mask_graphics_202,x:139,y:352.3}).wait(1).to({graphics:mask_graphics_203,x:139.6,y:352.3}).wait(1).to({graphics:mask_graphics_204,x:140.2,y:352.3}).wait(1).to({graphics:mask_graphics_205,x:140.7,y:352.3}).wait(1).to({graphics:mask_graphics_206,x:141.3,y:352.3}).wait(1).to({graphics:mask_graphics_207,x:141.9,y:352.3}).wait(1).to({graphics:mask_graphics_208,x:142.5,y:352.3}).wait(1).to({graphics:mask_graphics_209,x:143,y:352.3}).wait(1).to({graphics:mask_graphics_210,x:143.6,y:352.3}).wait(1).to({graphics:mask_graphics_211,x:144.2,y:352.3}).wait(1).to({graphics:mask_graphics_212,x:144.7,y:352.3}).wait(1).to({graphics:mask_graphics_213,x:145.3,y:352.3}).wait(1).to({graphics:mask_graphics_214,x:145.9,y:352.3}).wait(1).to({graphics:mask_graphics_215,x:146.5,y:352.3}).wait(1).to({graphics:mask_graphics_216,x:147,y:352.3}).wait(1).to({graphics:mask_graphics_217,x:147.6,y:352.3}).wait(1).to({graphics:mask_graphics_218,x:148.2,y:352.3}).wait(1).to({graphics:mask_graphics_219,x:148.7,y:352.3}).wait(1).to({graphics:mask_graphics_220,x:149.3,y:352.3}).wait(1).to({graphics:mask_graphics_221,x:149.9,y:352.3}).wait(1).to({graphics:mask_graphics_222,x:150.5,y:352.3}).wait(1).to({graphics:mask_graphics_223,x:151,y:352.3}).wait(1).to({graphics:mask_graphics_224,x:151.6,y:352.3}).wait(1).to({graphics:mask_graphics_225,x:152.2,y:352.3}).wait(1).to({graphics:mask_graphics_226,x:152.8,y:352.3}).wait(1).to({graphics:mask_graphics_227,x:153.3,y:352.3}).wait(1).to({graphics:mask_graphics_228,x:153.9,y:352.3}).wait(1).to({graphics:mask_graphics_229,x:154.5,y:352.3}).wait(1).to({graphics:mask_graphics_230,x:155,y:352.3}).wait(1).to({graphics:mask_graphics_231,x:155.6,y:352.3}).wait(1).to({graphics:mask_graphics_232,x:156.2,y:352.3}).wait(1).to({graphics:mask_graphics_233,x:156.8,y:352.3}).wait(1).to({graphics:mask_graphics_234,x:157.3,y:352.3}).wait(1).to({graphics:mask_graphics_235,x:157.9,y:352.3}).wait(1).to({graphics:mask_graphics_236,x:158.5,y:352.3}).wait(1).to({graphics:mask_graphics_237,x:159.1,y:352.3}).wait(1).to({graphics:mask_graphics_238,x:159.6,y:352.3}).wait(1).to({graphics:mask_graphics_239,x:160.2,y:352.3}).wait(1).to({graphics:mask_graphics_240,x:160.8,y:352.3}).wait(1).to({graphics:mask_graphics_241,x:161.4,y:352.3}).wait(1).to({graphics:mask_graphics_242,x:161.9,y:352.3}).wait(1).to({graphics:mask_graphics_243,x:162.5,y:352.3}).wait(1).to({graphics:mask_graphics_244,x:163.1,y:352.3}).wait(1).to({graphics:mask_graphics_245,x:163.6,y:352.3}).wait(1).to({graphics:mask_graphics_246,x:164.2,y:352.3}).wait(1).to({graphics:mask_graphics_247,x:164.8,y:352.3}).wait(1).to({graphics:mask_graphics_248,x:165.4,y:352.3}).wait(1).to({graphics:mask_graphics_249,x:165.9,y:352.3}).wait(1).to({graphics:mask_graphics_250,x:166.5,y:352.3}).wait(1).to({graphics:mask_graphics_251,x:167.1,y:352.3}).wait(1).to({graphics:mask_graphics_252,x:167.7,y:352.3}).wait(1).to({graphics:mask_graphics_253,x:168.2,y:352.3}).wait(1).to({graphics:mask_graphics_254,x:168.8,y:352.3}).wait(1).to({graphics:mask_graphics_255,x:169.4,y:352.3}).wait(1).to({graphics:mask_graphics_256,x:169.9,y:352.3}).wait(1).to({graphics:mask_graphics_257,x:170.5,y:352.3}).wait(1).to({graphics:mask_graphics_258,x:171.1,y:352.3}).wait(1).to({graphics:mask_graphics_259,x:171.7,y:352.3}).wait(1).to({graphics:mask_graphics_260,x:172.2,y:352.3}).wait(1).to({graphics:mask_graphics_261,x:172.8,y:352.3}).wait(1).to({graphics:mask_graphics_262,x:173.4,y:352.3}).wait(1).to({graphics:mask_graphics_263,x:174,y:352.3}).wait(1).to({graphics:mask_graphics_264,x:174.5,y:352.3}).wait(1).to({graphics:mask_graphics_265,x:175.1,y:352.3}).wait(1).to({graphics:mask_graphics_266,x:175.7,y:352.3}).wait(1).to({graphics:mask_graphics_267,x:176.2,y:352.3}).wait(1).to({graphics:mask_graphics_268,x:176.8,y:352.3}).wait(1).to({graphics:mask_graphics_269,x:177.4,y:352.3}).wait(1).to({graphics:mask_graphics_270,x:178,y:352.3}).wait(1).to({graphics:mask_graphics_271,x:178.5,y:352.3}).wait(1).to({graphics:mask_graphics_272,x:179.1,y:352.3}).wait(1).to({graphics:mask_graphics_273,x:179.7,y:352.3}).wait(1).to({graphics:mask_graphics_274,x:180.2,y:352.3}).wait(1).to({graphics:mask_graphics_275,x:180.8,y:352.2}).wait(1).to({graphics:mask_graphics_276,x:181.4,y:352.2}).wait(1).to({graphics:mask_graphics_277,x:182,y:352.2}).wait(1).to({graphics:mask_graphics_278,x:182.5,y:352.2}).wait(1).to({graphics:mask_graphics_279,x:183.1,y:352.2}).wait(1).to({graphics:mask_graphics_280,x:183.7,y:352.2}).wait(1).to({graphics:mask_graphics_281,x:184.2,y:352.2}).wait(1).to({graphics:mask_graphics_282,x:184.8,y:352.2}).wait(1).to({graphics:mask_graphics_283,x:185.4,y:352.2}).wait(1).to({graphics:mask_graphics_284,x:186,y:352.2}).wait(1).to({graphics:mask_graphics_285,x:186.6,y:352.2}).wait(1).to({graphics:mask_graphics_286,x:187.1,y:352.2}).wait(1).to({graphics:mask_graphics_287,x:187.7,y:352.2}).wait(1).to({graphics:mask_graphics_288,x:188.3,y:352.2}).wait(1).to({graphics:mask_graphics_289,x:188.8,y:352.2}).wait(1).to({graphics:mask_graphics_290,x:189.4,y:352.2}).wait(1).to({graphics:mask_graphics_291,x:190,y:352.2}).wait(1).to({graphics:mask_graphics_292,x:190.6,y:352.2}).wait(1).to({graphics:mask_graphics_293,x:191.1,y:352.2}).wait(1).to({graphics:mask_graphics_294,x:191.7,y:352.2}).wait(1).to({graphics:mask_graphics_295,x:192.3,y:352.2}).wait(1).to({graphics:mask_graphics_296,x:192.8,y:352.2}).wait(1).to({graphics:mask_graphics_297,x:193.4,y:352.2}).wait(1).to({graphics:mask_graphics_298,x:194,y:352.2}).wait(1).to({graphics:mask_graphics_299,x:194.6,y:352.2}).wait(1).to({graphics:mask_graphics_300,x:195.1,y:352.2}).wait(1).to({graphics:mask_graphics_301,x:195.7,y:352.2}).wait(1).to({graphics:mask_graphics_302,x:196.3,y:352.2}).wait(1).to({graphics:mask_graphics_303,x:196.9,y:352.2}).wait(1).to({graphics:mask_graphics_304,x:197.4,y:352.2}).wait(1).to({graphics:mask_graphics_305,x:198,y:352.2}).wait(1).to({graphics:mask_graphics_306,x:198.6,y:352.2}).wait(1).to({graphics:mask_graphics_307,x:199.2,y:352.2}).wait(1).to({graphics:mask_graphics_308,x:199.7,y:352.2}).wait(1).to({graphics:mask_graphics_309,x:200.3,y:352.2}).wait(1).to({graphics:mask_graphics_310,x:200.9,y:352.2}).wait(1).to({graphics:mask_graphics_311,x:201.4,y:352.2}).wait(1).to({graphics:mask_graphics_312,x:202,y:352.2}).wait(1).to({graphics:mask_graphics_313,x:202.6,y:352.2}).wait(1).to({graphics:mask_graphics_314,x:203.2,y:352.2}).wait(1).to({graphics:mask_graphics_315,x:203.7,y:352.2}).wait(1).to({graphics:mask_graphics_316,x:204.3,y:352.2}).wait(1).to({graphics:mask_graphics_317,x:204.9,y:352.2}).wait(1).to({graphics:mask_graphics_318,x:205.5,y:352.2}).wait(1).to({graphics:mask_graphics_319,x:206,y:352.2}).wait(1).to({graphics:mask_graphics_320,x:206.6,y:352.2}).wait(1).to({graphics:mask_graphics_321,x:207.2,y:352.2}).wait(1).to({graphics:mask_graphics_322,x:207.7,y:352.2}).wait(1).to({graphics:mask_graphics_323,x:208.3,y:352.2}).wait(1).to({graphics:mask_graphics_324,x:208.9,y:352.2}).wait(1).to({graphics:mask_graphics_325,x:209.5,y:352.2}).wait(1).to({graphics:mask_graphics_326,x:210,y:352.2}).wait(1).to({graphics:mask_graphics_327,x:210.6,y:352.2}).wait(1).to({graphics:mask_graphics_328,x:211.2,y:352.2}).wait(1).to({graphics:mask_graphics_329,x:211.7,y:352.2}).wait(1).to({graphics:mask_graphics_330,x:212.3,y:352.2}).wait(1).to({graphics:mask_graphics_331,x:212.9,y:352.2}).wait(1).to({graphics:mask_graphics_332,x:213.5,y:352.2}).wait(1).to({graphics:mask_graphics_333,x:214.1,y:352.2}).wait(1).to({graphics:mask_graphics_334,x:214.6,y:352.2}).wait(1).to({graphics:mask_graphics_335,x:215.2,y:352.2}).wait(1).to({graphics:mask_graphics_336,x:215.8,y:352.2}).wait(1).to({graphics:mask_graphics_337,x:216.3,y:352.2}).wait(1).to({graphics:mask_graphics_338,x:216.9,y:352.2}).wait(1).to({graphics:mask_graphics_339,x:217.5,y:352.2}).wait(1).to({graphics:mask_graphics_340,x:218.1,y:352.2}).wait(1).to({graphics:mask_graphics_341,x:218.6,y:352.2}).wait(1).to({graphics:mask_graphics_342,x:219.2,y:352.2}).wait(1).to({graphics:mask_graphics_343,x:219.8,y:352.2}).wait(1).to({graphics:mask_graphics_344,x:220.3,y:352.2}).wait(1).to({graphics:mask_graphics_345,x:220.9,y:352.2}).wait(1).to({graphics:mask_graphics_346,x:221.5,y:352.2}).wait(1).to({graphics:mask_graphics_347,x:222.1,y:352.2}).wait(1).to({graphics:mask_graphics_348,x:222.6,y:352.2}).wait(1).to({graphics:mask_graphics_349,x:223.2,y:352.2}).wait(1).to({graphics:mask_graphics_350,x:223.8,y:352.2}).wait(1).to({graphics:mask_graphics_351,x:224.3,y:352.2}).wait(1).to({graphics:mask_graphics_352,x:224.9,y:352.2}).wait(1).to({graphics:mask_graphics_353,x:225.5,y:352.2}).wait(1).to({graphics:mask_graphics_354,x:226.1,y:352.2}).wait(1).to({graphics:mask_graphics_355,x:226.7,y:352.2}).wait(1).to({graphics:mask_graphics_356,x:227.2,y:352.2}).wait(1).to({graphics:mask_graphics_357,x:227.8,y:352.2}).wait(1).to({graphics:mask_graphics_358,x:228.4,y:352.2}).wait(1).to({graphics:mask_graphics_359,x:228.9,y:352.2}).wait(1).to({graphics:mask_graphics_360,x:229.5,y:352.2}).wait(1).to({graphics:mask_graphics_361,x:230.1,y:352.2}).wait(1).to({graphics:mask_graphics_362,x:230.7,y:352.2}).wait(1).to({graphics:mask_graphics_363,x:231.2,y:352.2}).wait(1).to({graphics:mask_graphics_364,x:231.8,y:352.2}).wait(1).to({graphics:mask_graphics_365,x:232.4,y:352.2}).wait(1).to({graphics:mask_graphics_366,x:232.9,y:352.2}).wait(1).to({graphics:mask_graphics_367,x:233.5,y:352.2}).wait(1).to({graphics:mask_graphics_368,x:234.1,y:352.2}).wait(1).to({graphics:mask_graphics_369,x:234.7,y:352.2}).wait(1).to({graphics:mask_graphics_370,x:235.2,y:352.2}).wait(1).to({graphics:mask_graphics_371,x:235.8,y:352.2}).wait(1).to({graphics:mask_graphics_372,x:236.4,y:352.2}).wait(1).to({graphics:mask_graphics_373,x:237,y:352.2}).wait(1).to({graphics:mask_graphics_374,x:237.5,y:352.2}).wait(1).to({graphics:mask_graphics_375,x:238.1,y:352.1}).wait(1).to({graphics:mask_graphics_376,x:238.7,y:352.1}).wait(1).to({graphics:mask_graphics_377,x:239.2,y:352.1}).wait(1).to({graphics:mask_graphics_378,x:239.8,y:352.1}).wait(1).to({graphics:mask_graphics_379,x:240.4,y:352.1}).wait(1).to({graphics:mask_graphics_380,x:241,y:352.1}).wait(1).to({graphics:mask_graphics_381,x:241.5,y:352.1}).wait(1).to({graphics:mask_graphics_382,x:242.1,y:352.1}).wait(1).to({graphics:mask_graphics_383,x:242.7,y:352.1}).wait(1).to({graphics:mask_graphics_384,x:243.3,y:352.1}).wait(1).to({graphics:mask_graphics_385,x:243.8,y:352.1}).wait(1).to({graphics:mask_graphics_386,x:244.4,y:352.1}).wait(1).to({graphics:mask_graphics_387,x:245,y:352.1}).wait(1).to({graphics:mask_graphics_388,x:245.6,y:352.1}).wait(1).to({graphics:mask_graphics_389,x:246.1,y:352.1}).wait(1).to({graphics:mask_graphics_390,x:246.7,y:352.1}).wait(1).to({graphics:mask_graphics_391,x:247.3,y:352.1}).wait(1).to({graphics:mask_graphics_392,x:247.8,y:352.1}).wait(1).to({graphics:mask_graphics_393,x:248.4,y:352.1}).wait(1).to({graphics:mask_graphics_394,x:249,y:352.1}).wait(1).to({graphics:mask_graphics_395,x:249.6,y:352.1}).wait(1).to({graphics:mask_graphics_396,x:250.1,y:352.1}).wait(1).to({graphics:mask_graphics_397,x:250.7,y:352.1}).wait(1).to({graphics:mask_graphics_398,x:251.3,y:352.1}).wait(1).to({graphics:mask_graphics_399,x:251.8,y:352.1}).wait(1).to({graphics:mask_graphics_400,x:252.4,y:352.1}).wait(1).to({graphics:mask_graphics_401,x:253,y:352.1}).wait(1).to({graphics:mask_graphics_402,x:253.6,y:352.1}).wait(1).to({graphics:mask_graphics_403,x:254.1,y:352.1}).wait(1).to({graphics:mask_graphics_404,x:254.7,y:352.1}).wait(1).to({graphics:mask_graphics_405,x:255.3,y:352.1}).wait(1).to({graphics:mask_graphics_406,x:255.8,y:352.1}).wait(1).to({graphics:mask_graphics_407,x:256.4,y:352.1}).wait(1).to({graphics:mask_graphics_408,x:257,y:352.1}).wait(1).to({graphics:mask_graphics_409,x:257.6,y:352.1}).wait(1).to({graphics:mask_graphics_410,x:258.2,y:352.1}).wait(1).to({graphics:mask_graphics_411,x:258.7,y:352.1}).wait(1).to({graphics:mask_graphics_412,x:259.3,y:352.1}).wait(1).to({graphics:mask_graphics_413,x:259.9,y:352.1}).wait(1).to({graphics:mask_graphics_414,x:260.4,y:352.1}).wait(1).to({graphics:mask_graphics_415,x:261,y:352.1}).wait(1).to({graphics:mask_graphics_416,x:261.6,y:352.1}).wait(1).to({graphics:mask_graphics_417,x:262.2,y:352.1}).wait(1).to({graphics:mask_graphics_418,x:262.7,y:352.1}).wait(1).to({graphics:mask_graphics_419,x:263.3,y:352.1}).wait(1).to({graphics:mask_graphics_420,x:263.9,y:352.1}).wait(1).to({graphics:mask_graphics_421,x:264.4,y:352.1}).wait(1).to({graphics:mask_graphics_422,x:265,y:352.1}).wait(1).to({graphics:mask_graphics_423,x:265.6,y:352.1}).wait(1).to({graphics:mask_graphics_424,x:266.2,y:352.1}).wait(1).to({graphics:mask_graphics_425,x:266.7,y:352.1}).wait(1).to({graphics:mask_graphics_426,x:267.3,y:352.1}).wait(1).to({graphics:mask_graphics_427,x:267.9,y:352.1}).wait(1).to({graphics:mask_graphics_428,x:268.5,y:352.1}).wait(1).to({graphics:mask_graphics_429,x:269,y:352.1}).wait(1).to({graphics:mask_graphics_430,x:269.6,y:352.1}).wait(1).to({graphics:mask_graphics_431,x:270.2,y:352.1}).wait(1).to({graphics:mask_graphics_432,x:270.8,y:352.1}).wait(1).to({graphics:mask_graphics_433,x:271.3,y:352.1}).wait(1).to({graphics:mask_graphics_434,x:271.9,y:352.1}).wait(1).to({graphics:mask_graphics_435,x:272.5,y:352.1}).wait(1).to({graphics:mask_graphics_436,x:273,y:352.1}).wait(1).to({graphics:mask_graphics_437,x:273.6,y:352.1}).wait(1).to({graphics:mask_graphics_438,x:274.2,y:352.1}).wait(1).to({graphics:mask_graphics_439,x:274.8,y:352.1}).wait(1).to({graphics:mask_graphics_440,x:275.3,y:352.1}).wait(1).to({graphics:mask_graphics_441,x:275.9,y:352.1}).wait(1).to({graphics:mask_graphics_442,x:276.5,y:352.1}).wait(1).to({graphics:mask_graphics_443,x:277.1,y:352.1}).wait(1).to({graphics:mask_graphics_444,x:277.6,y:352.1}).wait(1).to({graphics:mask_graphics_445,x:278.2,y:352.1}).wait(1).to({graphics:mask_graphics_446,x:278.8,y:352.1}).wait(1).to({graphics:mask_graphics_447,x:279.3,y:352.1}).wait(1).to({graphics:mask_graphics_448,x:279.9,y:352.1}).wait(1).to({graphics:mask_graphics_449,x:280.5,y:352.1}).wait(1).to({graphics:mask_graphics_450,x:281.1,y:352.1}).wait(1).to({graphics:mask_graphics_451,x:281.6,y:352.1}).wait(1).to({graphics:mask_graphics_452,x:282.2,y:352.1}).wait(1).to({graphics:mask_graphics_453,x:282.8,y:352.1}).wait(1).to({graphics:mask_graphics_454,x:283.3,y:352.1}).wait(1).to({graphics:mask_graphics_455,x:283.9,y:352.1}).wait(1).to({graphics:mask_graphics_456,x:284.5,y:352.1}).wait(1).to({graphics:mask_graphics_457,x:285.1,y:352.1}).wait(1).to({graphics:mask_graphics_458,x:285.7,y:352.1}).wait(1).to({graphics:mask_graphics_459,x:286.2,y:352.1}).wait(1).to({graphics:mask_graphics_460,x:286.8,y:352.1}).wait(1).to({graphics:mask_graphics_461,x:287.3,y:352.1}).wait(1).to({graphics:mask_graphics_462,x:287.9,y:352.1}).wait(1).to({graphics:mask_graphics_463,x:288.5,y:352.1}).wait(1).to({graphics:mask_graphics_464,x:289.1,y:352.1}).wait(1).to({graphics:mask_graphics_465,x:289.7,y:352.1}).wait(1).to({graphics:mask_graphics_466,x:290.2,y:352.1}).wait(1).to({graphics:mask_graphics_467,x:290.8,y:352.1}).wait(1).to({graphics:mask_graphics_468,x:291.4,y:352.1}).wait(1).to({graphics:mask_graphics_469,x:291.9,y:352.1}).wait(1).to({graphics:mask_graphics_470,x:292.5,y:352.1}).wait(1).to({graphics:mask_graphics_471,x:293.1,y:352.1}).wait(1).to({graphics:mask_graphics_472,x:293.7,y:352.1}).wait(1).to({graphics:mask_graphics_473,x:294.2,y:352.1}).wait(1).to({graphics:mask_graphics_474,x:294.8,y:352.1}).wait(1).to({graphics:mask_graphics_475,x:295.4,y:352}).wait(1).to({graphics:mask_graphics_476,x:295.9,y:352}).wait(1).to({graphics:mask_graphics_477,x:296.5,y:352}).wait(1).to({graphics:mask_graphics_478,x:297.1,y:352}).wait(1).to({graphics:mask_graphics_479,x:297.7,y:352}).wait(1).to({graphics:mask_graphics_480,x:298.3,y:352}).wait(1).to({graphics:mask_graphics_481,x:298.8,y:352}).wait(1).to({graphics:mask_graphics_482,x:299.4,y:352}).wait(1).to({graphics:mask_graphics_483,x:300,y:352}).wait(1).to({graphics:mask_graphics_484,x:300.5,y:352}).wait(1).to({graphics:mask_graphics_485,x:301.1,y:352}).wait(1).to({graphics:mask_graphics_486,x:301.7,y:352}).wait(1).to({graphics:mask_graphics_487,x:302.3,y:352}).wait(1).to({graphics:mask_graphics_488,x:302.8,y:352}).wait(1).to({graphics:mask_graphics_489,x:303.4,y:352}).wait(1).to({graphics:mask_graphics_490,x:304,y:352}).wait(1).to({graphics:mask_graphics_491,x:304.5,y:352}).wait(1).to({graphics:mask_graphics_492,x:305.1,y:352}).wait(1).to({graphics:mask_graphics_493,x:305.7,y:352}).wait(1).to({graphics:mask_graphics_494,x:306.3,y:352}).wait(1).to({graphics:mask_graphics_495,x:306.8,y:352}).wait(1).to({graphics:mask_graphics_496,x:307.4,y:352}).wait(1).to({graphics:mask_graphics_497,x:308,y:352}).wait(1).to({graphics:mask_graphics_498,x:308.6,y:352}).wait(1).to({graphics:mask_graphics_499,x:309.1,y:352}).wait(1).to({graphics:mask_graphics_500,x:309.7,y:352}).wait(1).to({graphics:mask_graphics_501,x:310.3,y:352}).wait(1).to({graphics:mask_graphics_502,x:310.8,y:352}).wait(1).to({graphics:mask_graphics_503,x:311.4,y:352}).wait(1).to({graphics:mask_graphics_504,x:312,y:352}).wait(1).to({graphics:mask_graphics_505,x:312.6,y:352}).wait(1).to({graphics:mask_graphics_506,x:313.1,y:352}).wait(1).to({graphics:mask_graphics_507,x:313.7,y:352}).wait(1).to({graphics:mask_graphics_508,x:314.3,y:352}).wait(1).to({graphics:mask_graphics_509,x:314.8,y:352}).wait(1).to({graphics:mask_graphics_510,x:315.4,y:352}).wait(1).to({graphics:mask_graphics_511,x:316,y:352}).wait(1).to({graphics:mask_graphics_512,x:316.6,y:352}).wait(1).to({graphics:mask_graphics_513,x:317.2,y:352}).wait(1).to({graphics:mask_graphics_514,x:317.7,y:352}).wait(1).to({graphics:mask_graphics_515,x:318.3,y:352}).wait(1).to({graphics:mask_graphics_516,x:318.8,y:352}).wait(1).to({graphics:mask_graphics_517,x:319.4,y:352}).wait(1).to({graphics:mask_graphics_518,x:320,y:352}).wait(1).to({graphics:mask_graphics_519,x:320.6,y:352}).wait(1).to({graphics:mask_graphics_520,x:321.2,y:352}).wait(1).to({graphics:mask_graphics_521,x:321.7,y:352}).wait(1).to({graphics:mask_graphics_522,x:322.3,y:352}).wait(1).to({graphics:mask_graphics_523,x:322.9,y:352}).wait(1).to({graphics:mask_graphics_524,x:323.4,y:352}).wait(1).to({graphics:mask_graphics_525,x:324,y:352}).wait(1).to({graphics:mask_graphics_526,x:324.6,y:352}).wait(1).to({graphics:mask_graphics_527,x:325.2,y:352}).wait(1).to({graphics:mask_graphics_528,x:325.7,y:352}).wait(1).to({graphics:mask_graphics_529,x:326.3,y:352}).wait(1).to({graphics:mask_graphics_530,x:326.9,y:352}).wait(1).to({graphics:mask_graphics_531,x:327.4,y:352}).wait(1).to({graphics:mask_graphics_532,x:328,y:352}).wait(1).to({graphics:mask_graphics_533,x:328.6,y:352}).wait(1).to({graphics:mask_graphics_534,x:329.2,y:352}).wait(1).to({graphics:mask_graphics_535,x:329.8,y:352}).wait(1).to({graphics:mask_graphics_536,x:330.3,y:352}).wait(1).to({graphics:mask_graphics_537,x:330.9,y:352}).wait(1).to({graphics:mask_graphics_538,x:331.5,y:352}).wait(1).to({graphics:mask_graphics_539,x:332,y:352}).wait(1).to({graphics:mask_graphics_540,x:332.6,y:352}).wait(1).to({graphics:mask_graphics_541,x:333.2,y:352}).wait(1).to({graphics:mask_graphics_542,x:333.8,y:352}).wait(1).to({graphics:mask_graphics_543,x:334.3,y:352}).wait(1).to({graphics:mask_graphics_544,x:334.9,y:352}).wait(1).to({graphics:mask_graphics_545,x:335.5,y:352}).wait(1).to({graphics:mask_graphics_546,x:336,y:352}).wait(1).to({graphics:mask_graphics_547,x:336.6,y:352}).wait(1).to({graphics:mask_graphics_548,x:337.2,y:352}).wait(1).to({graphics:mask_graphics_549,x:337.8,y:352}).wait(1).to({graphics:mask_graphics_550,x:338.3,y:352}).wait(1).to({graphics:mask_graphics_551,x:338.9,y:352}).wait(1).to({graphics:mask_graphics_552,x:339.5,y:352}).wait(1).to({graphics:mask_graphics_553,x:340.1,y:352}).wait(1).to({graphics:mask_graphics_554,x:340.6,y:352}).wait(1).to({graphics:mask_graphics_555,x:341.2,y:352}).wait(1).to({graphics:mask_graphics_556,x:341.8,y:352}).wait(1).to({graphics:mask_graphics_557,x:342.3,y:352}).wait(1).to({graphics:mask_graphics_558,x:342.9,y:352}).wait(1).to({graphics:mask_graphics_559,x:343.5,y:352}).wait(1).to({graphics:mask_graphics_560,x:344.1,y:352}).wait(1).to({graphics:mask_graphics_561,x:344.6,y:352}).wait(1).to({graphics:mask_graphics_562,x:345.2,y:352}).wait(1).to({graphics:mask_graphics_563,x:345.8,y:352}).wait(1).to({graphics:mask_graphics_564,x:346.3,y:352}).wait(1).to({graphics:mask_graphics_565,x:346.9,y:352}).wait(1).to({graphics:mask_graphics_566,x:347.5,y:352}).wait(1).to({graphics:mask_graphics_567,x:348.1,y:352}).wait(1).to({graphics:mask_graphics_568,x:348.7,y:352}).wait(1).to({graphics:mask_graphics_569,x:349.2,y:352}).wait(1).to({graphics:mask_graphics_570,x:349.8,y:352}).wait(1).to({graphics:mask_graphics_571,x:350.4,y:352}).wait(1).to({graphics:mask_graphics_572,x:350.9,y:352}).wait(1).to({graphics:mask_graphics_573,x:351.5,y:352}).wait(1).to({graphics:mask_graphics_574,x:352.1,y:352}).wait(1).to({graphics:mask_graphics_575,x:352.7,y:351.9}).wait(1).to({graphics:mask_graphics_576,x:353.2,y:351.9}).wait(1).to({graphics:mask_graphics_577,x:353.8,y:351.9}).wait(1).to({graphics:mask_graphics_578,x:354.4,y:351.9}).wait(1).to({graphics:mask_graphics_579,x:354.9,y:351.9}).wait(1).to({graphics:mask_graphics_580,x:355.5,y:351.9}).wait(1).to({graphics:mask_graphics_581,x:356.1,y:351.9}).wait(1).to({graphics:mask_graphics_582,x:356.7,y:351.9}).wait(1).to({graphics:mask_graphics_583,x:357.3,y:351.9}).wait(1).to({graphics:mask_graphics_584,x:357.8,y:351.9}).wait(1).to({graphics:mask_graphics_585,x:358.4,y:351.9}).wait(1).to({graphics:mask_graphics_586,x:359,y:351.9}).wait(1).to({graphics:mask_graphics_587,x:359.5,y:351.9}).wait(1).to({graphics:mask_graphics_588,x:360.1,y:351.9}).wait(1).to({graphics:mask_graphics_589,x:360.7,y:351.9}).wait(1).to({graphics:mask_graphics_590,x:361.3,y:351.9}).wait(1).to({graphics:mask_graphics_591,x:361.8,y:351.9}).wait(1).to({graphics:mask_graphics_592,x:362.4,y:351.9}).wait(1).to({graphics:mask_graphics_593,x:363,y:351.9}).wait(1).to({graphics:mask_graphics_594,x:363.5,y:351.9}).wait(1).to({graphics:mask_graphics_595,x:364.1,y:351.9}).wait(1).to({graphics:mask_graphics_596,x:364.7,y:351.9}).wait(1).to({graphics:mask_graphics_597,x:365.3,y:351.9}).wait(1).to({graphics:mask_graphics_598,x:365.8,y:351.9}).wait(1).to({graphics:mask_graphics_599,x:366.4,y:351.9}).wait(1).to({graphics:mask_graphics_600,x:367,y:351.9}).wait(1).to({graphics:mask_graphics_601,x:367.5,y:351.9}).wait(1).to({graphics:mask_graphics_602,x:368.1,y:351.9}).wait(1).to({graphics:mask_graphics_603,x:368.7,y:351.9}).wait(1).to({graphics:mask_graphics_604,x:369.3,y:351.9}).wait(1).to({graphics:mask_graphics_605,x:369.8,y:351.9}).wait(1).to({graphics:mask_graphics_606,x:370.4,y:351.9}).wait(1).to({graphics:mask_graphics_607,x:371,y:351.9}).wait(1).to({graphics:mask_graphics_608,x:371.6,y:351.9}).wait(1).to({graphics:mask_graphics_609,x:372.1,y:351.9}).wait(1).to({graphics:mask_graphics_610,x:372.7,y:351.9}).wait(1).to({graphics:mask_graphics_611,x:373.3,y:351.9}).wait(1).to({graphics:mask_graphics_612,x:373.8,y:351.9}).wait(1).to({graphics:mask_graphics_613,x:374.4,y:351.9}).wait(1).to({graphics:mask_graphics_614,x:375,y:351.9}).wait(1).to({graphics:mask_graphics_615,x:375.6,y:351.9}).wait(1).to({graphics:mask_graphics_616,x:376.1,y:351.9}).wait(1).to({graphics:mask_graphics_617,x:376.7,y:351.9}).wait(1).to({graphics:mask_graphics_618,x:377.3,y:351.9}).wait(1).to({graphics:mask_graphics_619,x:377.9,y:351.9}).wait(1).to({graphics:mask_graphics_620,x:378.4,y:351.9}).wait(1).to({graphics:mask_graphics_621,x:379,y:351.9}).wait(1).to({graphics:mask_graphics_622,x:379.6,y:351.9}).wait(1).to({graphics:mask_graphics_623,x:380.2,y:351.9}).wait(1).to({graphics:mask_graphics_624,x:380.7,y:351.9}).wait(1).to({graphics:mask_graphics_625,x:381.3,y:351.9}).wait(1).to({graphics:mask_graphics_626,x:381.9,y:351.9}).wait(1).to({graphics:mask_graphics_627,x:382.4,y:351.9}).wait(1).to({graphics:mask_graphics_628,x:383,y:351.9}).wait(1).to({graphics:mask_graphics_629,x:383.6,y:351.9}).wait(1).to({graphics:mask_graphics_630,x:384.2,y:351.9}).wait(1).to({graphics:mask_graphics_631,x:384.7,y:351.9}).wait(1).to({graphics:mask_graphics_632,x:385.3,y:351.9}).wait(1).to({graphics:mask_graphics_633,x:385.9,y:351.9}).wait(1).to({graphics:mask_graphics_634,x:386.4,y:351.9}).wait(1).to({graphics:mask_graphics_635,x:387,y:351.9}).wait(1).to({graphics:mask_graphics_636,x:387.6,y:351.9}).wait(1).to({graphics:mask_graphics_637,x:388.2,y:351.9}).wait(1).to({graphics:mask_graphics_638,x:388.8,y:351.9}).wait(1).to({graphics:mask_graphics_639,x:389.3,y:351.9}).wait(1).to({graphics:mask_graphics_640,x:389.9,y:351.9}).wait(1).to({graphics:mask_graphics_641,x:390.5,y:351.9}).wait(1).to({graphics:mask_graphics_642,x:391,y:351.9}).wait(1).to({graphics:mask_graphics_643,x:391.6,y:351.9}).wait(1).to({graphics:mask_graphics_644,x:392.2,y:351.9}).wait(1).to({graphics:mask_graphics_645,x:392.8,y:351.9}).wait(1).to({graphics:mask_graphics_646,x:393.3,y:351.9}).wait(1).to({graphics:mask_graphics_647,x:393.9,y:351.9}).wait(1).to({graphics:mask_graphics_648,x:394.5,y:351.9}).wait(1).to({graphics:mask_graphics_649,x:395,y:351.9}).wait(1).to({graphics:mask_graphics_650,x:395.6,y:351.9}).wait(1).to({graphics:mask_graphics_651,x:396.2,y:351.9}).wait(1).to({graphics:mask_graphics_652,x:396.8,y:351.9}).wait(1).to({graphics:mask_graphics_653,x:397.3,y:351.9}).wait(1).to({graphics:mask_graphics_654,x:397.9,y:351.9}).wait(1).to({graphics:mask_graphics_655,x:398.5,y:351.9}).wait(1).to({graphics:mask_graphics_656,x:399,y:351.9}).wait(1).to({graphics:mask_graphics_657,x:399.6,y:351.9}).wait(1).to({graphics:mask_graphics_658,x:400.2,y:351.9}).wait(1).to({graphics:mask_graphics_659,x:400.8,y:351.9}).wait(1).to({graphics:mask_graphics_660,x:401.3,y:351.9}).wait(1).to({graphics:mask_graphics_661,x:401.9,y:351.9}).wait(1).to({graphics:mask_graphics_662,x:402.5,y:351.9}).wait(1).to({graphics:mask_graphics_663,x:403.1,y:351.9}).wait(1).to({graphics:mask_graphics_664,x:403.6,y:351.9}).wait(1).to({graphics:mask_graphics_665,x:404.2,y:351.9}).wait(1).to({graphics:mask_graphics_666,x:404.8,y:351.9}).wait(1).to({graphics:mask_graphics_667,x:405.4,y:351.9}).wait(1).to({graphics:mask_graphics_668,x:405.9,y:351.9}).wait(1).to({graphics:mask_graphics_669,x:406.5,y:351.9}).wait(1).to({graphics:mask_graphics_670,x:407.1,y:351.9}).wait(1).to({graphics:mask_graphics_671,x:407.6,y:351.9}).wait(1).to({graphics:mask_graphics_672,x:408.2,y:351.9}).wait(1).to({graphics:mask_graphics_673,x:408.8,y:351.9}).wait(1).to({graphics:mask_graphics_674,x:409.4,y:351.9}).wait(1).to({graphics:mask_graphics_675,x:409.9,y:351.8}).wait(1).to({graphics:mask_graphics_676,x:410.5,y:351.8}).wait(1).to({graphics:mask_graphics_677,x:411.1,y:351.8}).wait(1).to({graphics:mask_graphics_678,x:411.7,y:351.8}).wait(1).to({graphics:mask_graphics_679,x:412.2,y:351.8}).wait(1).to({graphics:mask_graphics_680,x:412.8,y:351.8}).wait(1).to({graphics:mask_graphics_681,x:413.4,y:351.8}).wait(1).to({graphics:mask_graphics_682,x:413.9,y:351.8}).wait(1).to({graphics:mask_graphics_683,x:414.5,y:351.8}).wait(1).to({graphics:mask_graphics_684,x:415.1,y:351.8}).wait(1).to({graphics:mask_graphics_685,x:415.7,y:351.8}).wait(1).to({graphics:mask_graphics_686,x:416.2,y:351.8}).wait(1).to({graphics:mask_graphics_687,x:416.8,y:351.8}).wait(1).to({graphics:mask_graphics_688,x:417.4,y:351.8}).wait(1).to({graphics:mask_graphics_689,x:418,y:351.8}).wait(1).to({graphics:mask_graphics_690,x:418.5,y:351.8}).wait(1).to({graphics:mask_graphics_691,x:419.1,y:351.8}).wait(1).to({graphics:mask_graphics_692,x:419.7,y:351.8}).wait(1).to({graphics:mask_graphics_693,x:420.3,y:351.8}).wait(1).to({graphics:mask_graphics_694,x:420.8,y:351.8}).wait(1).to({graphics:mask_graphics_695,x:421.4,y:351.8}).wait(1).to({graphics:mask_graphics_696,x:422,y:351.8}).wait(1).to({graphics:mask_graphics_697,x:422.5,y:351.8}).wait(1).to({graphics:mask_graphics_698,x:423.1,y:351.8}).wait(1).to({graphics:mask_graphics_699,x:423.7,y:351.8}).wait(1).to({graphics:mask_graphics_700,x:424.3,y:351.8}).wait(1).to({graphics:mask_graphics_701,x:424.8,y:351.8}).wait(1).to({graphics:mask_graphics_702,x:425.4,y:351.8}).wait(1).to({graphics:mask_graphics_703,x:426,y:351.8}).wait(1).to({graphics:mask_graphics_704,x:426.5,y:351.8}).wait(1).to({graphics:mask_graphics_705,x:427.1,y:351.8}).wait(1).to({graphics:mask_graphics_706,x:427.7,y:351.8}).wait(1).to({graphics:mask_graphics_707,x:428.3,y:351.8}).wait(1).to({graphics:mask_graphics_708,x:428.8,y:351.8}).wait(1).to({graphics:mask_graphics_709,x:429.4,y:351.8}).wait(1).to({graphics:mask_graphics_710,x:430,y:351.8}).wait(1).to({graphics:mask_graphics_711,x:430.5,y:351.8}).wait(1).to({graphics:mask_graphics_712,x:431.1,y:351.8}).wait(1).to({graphics:mask_graphics_713,x:431.7,y:351.8}).wait(1).to({graphics:mask_graphics_714,x:432.3,y:351.8}).wait(1).to({graphics:mask_graphics_715,x:432.9,y:351.8}).wait(1).to({graphics:mask_graphics_716,x:433.4,y:351.8}).wait(1).to({graphics:mask_graphics_717,x:434,y:351.8}).wait(1).to({graphics:mask_graphics_718,x:434.6,y:351.8}).wait(1).to({graphics:mask_graphics_719,x:435.1,y:351.8}).wait(1).to({graphics:mask_graphics_720,x:435.7,y:351.8}).wait(1).to({graphics:mask_graphics_721,x:436.3,y:351.8}).wait(1).to({graphics:mask_graphics_722,x:436.9,y:351.8}).wait(1).to({graphics:mask_graphics_723,x:437.4,y:351.8}).wait(1).to({graphics:mask_graphics_724,x:438,y:351.8}).wait(1).to({graphics:mask_graphics_725,x:438.6,y:351.8}).wait(1).to({graphics:mask_graphics_726,x:439.1,y:351.8}).wait(1).to({graphics:mask_graphics_727,x:439.7,y:351.8}).wait(1).to({graphics:mask_graphics_728,x:440.3,y:351.8}).wait(1).to({graphics:mask_graphics_729,x:440.9,y:351.8}).wait(1).to({graphics:mask_graphics_730,x:441.4,y:351.8}).wait(1).to({graphics:mask_graphics_731,x:442,y:351.8}).wait(1).to({graphics:mask_graphics_732,x:442.6,y:351.8}).wait(1).to({graphics:mask_graphics_733,x:443.2,y:351.8}).wait(1).to({graphics:mask_graphics_734,x:443.7,y:351.8}).wait(1).to({graphics:mask_graphics_735,x:444.3,y:351.8}).wait(1).to({graphics:mask_graphics_736,x:444.9,y:351.8}).wait(1).to({graphics:mask_graphics_737,x:445.4,y:351.8}).wait(1).to({graphics:mask_graphics_738,x:446,y:351.8}).wait(1).to({graphics:mask_graphics_739,x:446.6,y:351.8}).wait(1).to({graphics:mask_graphics_740,x:447.2,y:351.8}).wait(1).to({graphics:mask_graphics_741,x:447.7,y:351.8}).wait(1).to({graphics:mask_graphics_742,x:448.3,y:351.8}).wait(1).to({graphics:mask_graphics_743,x:448.9,y:351.8}).wait(1).to({graphics:mask_graphics_744,x:449.5,y:351.8}).wait(1).to({graphics:mask_graphics_745,x:450,y:351.8}).wait(1).to({graphics:mask_graphics_746,x:450.6,y:351.8}).wait(1).to({graphics:mask_graphics_747,x:451.2,y:351.8}).wait(1).to({graphics:mask_graphics_748,x:451.8,y:351.8}).wait(1).to({graphics:mask_graphics_749,x:452.3,y:351.8}).wait(1).to({graphics:mask_graphics_750,x:452.9,y:351.8}).wait(1).to({graphics:mask_graphics_751,x:453.5,y:351.8}).wait(1).to({graphics:mask_graphics_752,x:454,y:351.8}).wait(1).to({graphics:mask_graphics_753,x:454.6,y:351.8}).wait(1).to({graphics:mask_graphics_754,x:455.2,y:351.8}).wait(1).to({graphics:mask_graphics_755,x:455.8,y:351.8}).wait(1).to({graphics:mask_graphics_756,x:456.3,y:351.8}).wait(1).to({graphics:mask_graphics_757,x:456.9,y:351.8}).wait(1).to({graphics:mask_graphics_758,x:457.5,y:351.8}).wait(1).to({graphics:mask_graphics_759,x:458,y:351.8}).wait(1).to({graphics:mask_graphics_760,x:458.6,y:351.8}).wait(1).to({graphics:mask_graphics_761,x:459.2,y:351.8}).wait(1).to({graphics:mask_graphics_762,x:459.8,y:351.8}).wait(1).to({graphics:mask_graphics_763,x:460.3,y:351.8}).wait(1).to({graphics:mask_graphics_764,x:460.9,y:351.8}).wait(1).to({graphics:mask_graphics_765,x:461.5,y:351.8}).wait(1).to({graphics:mask_graphics_766,x:462.1,y:351.8}).wait(1).to({graphics:mask_graphics_767,x:462.6,y:351.8}).wait(1).to({graphics:mask_graphics_768,x:463.2,y:351.8}).wait(1).to({graphics:mask_graphics_769,x:463.8,y:351.8}).wait(1).to({graphics:mask_graphics_770,x:464.4,y:351.8}).wait(1).to({graphics:mask_graphics_771,x:464.9,y:351.8}).wait(1).to({graphics:mask_graphics_772,x:465.5,y:351.8}).wait(1).to({graphics:mask_graphics_773,x:466.1,y:351.8}).wait(1).to({graphics:mask_graphics_774,x:466.6,y:351.8}).wait(1).to({graphics:mask_graphics_775,x:467.2,y:351.7}).wait(1).to({graphics:mask_graphics_776,x:467.8,y:351.7}).wait(1).to({graphics:mask_graphics_777,x:468.4,y:351.7}).wait(1).to({graphics:mask_graphics_778,x:468.9,y:351.7}).wait(1).to({graphics:mask_graphics_779,x:469.5,y:351.7}).wait(1).to({graphics:mask_graphics_780,x:470.1,y:351.7}).wait(1).to({graphics:mask_graphics_781,x:470.6,y:351.7}).wait(1).to({graphics:mask_graphics_782,x:471.2,y:351.7}).wait(1).to({graphics:mask_graphics_783,x:471.8,y:351.7}).wait(1).to({graphics:mask_graphics_784,x:472.4,y:351.7}).wait(1).to({graphics:mask_graphics_785,x:472.9,y:351.7}).wait(1).to({graphics:mask_graphics_786,x:473.5,y:351.7}).wait(1).to({graphics:mask_graphics_787,x:474.1,y:351.7}).wait(1).to({graphics:mask_graphics_788,x:474.6,y:351.7}).wait(1).to({graphics:mask_graphics_789,x:475.2,y:351.7}).wait(1).to({graphics:mask_graphics_790,x:475.8,y:351.7}).wait(1).to({graphics:mask_graphics_791,x:476.4,y:351.7}).wait(1).to({graphics:mask_graphics_792,x:476.9,y:351.7}).wait(1).to({graphics:mask_graphics_793,x:477.5,y:351.7}).wait(1).to({graphics:mask_graphics_794,x:478.1,y:351.7}).wait(1).to({graphics:mask_graphics_795,x:478.7,y:351.7}).wait(1).to({graphics:mask_graphics_796,x:479.2,y:351.7}).wait(1).to({graphics:mask_graphics_797,x:479.8,y:351.7}).wait(1).to({graphics:mask_graphics_798,x:480.4,y:351.7}).wait(1).to({graphics:mask_graphics_799,x:481,y:351.7}).wait(1).to({graphics:mask_graphics_800,x:481.5,y:351.7}).wait(1).to({graphics:mask_graphics_801,x:482.1,y:351.7}).wait(1).to({graphics:mask_graphics_802,x:482.7,y:351.7}).wait(1).to({graphics:mask_graphics_803,x:483.2,y:351.7}).wait(1).to({graphics:mask_graphics_804,x:483.8,y:351.7}).wait(1).to({graphics:mask_graphics_805,x:484.4,y:351.7}).wait(1).to({graphics:mask_graphics_806,x:485,y:351.7}).wait(1).to({graphics:mask_graphics_807,x:485.5,y:351.7}).wait(1).to({graphics:mask_graphics_808,x:486.1,y:351.7}).wait(1).to({graphics:mask_graphics_809,x:486.7,y:351.7}).wait(1).to({graphics:mask_graphics_810,x:487.3,y:351.7}).wait(1).to({graphics:mask_graphics_811,x:487.8,y:351.7}).wait(1).to({graphics:mask_graphics_812,x:488.4,y:351.7}).wait(1).to({graphics:mask_graphics_813,x:489,y:351.7}).wait(1).to({graphics:mask_graphics_814,x:489.6,y:351.7}).wait(1).to({graphics:mask_graphics_815,x:490.1,y:351.7}).wait(1).to({graphics:mask_graphics_816,x:490.7,y:351.7}).wait(1).to({graphics:mask_graphics_817,x:491.3,y:351.7}).wait(1).to({graphics:mask_graphics_818,x:491.8,y:351.7}).wait(1).to({graphics:mask_graphics_819,x:492.4,y:351.7}).wait(1).to({graphics:mask_graphics_820,x:493,y:351.7}).wait(1).to({graphics:mask_graphics_821,x:493.6,y:351.7}).wait(1).to({graphics:mask_graphics_822,x:494.1,y:351.7}).wait(1).to({graphics:mask_graphics_823,x:494.7,y:351.7}).wait(1).to({graphics:mask_graphics_824,x:495.3,y:351.7}).wait(1).to({graphics:mask_graphics_825,x:495.9,y:351.7}).wait(1).to({graphics:mask_graphics_826,x:496.4,y:351.7}).wait(1).to({graphics:mask_graphics_827,x:497,y:351.7}).wait(1).to({graphics:mask_graphics_828,x:497.6,y:351.7}).wait(1).to({graphics:mask_graphics_829,x:498.1,y:351.7}).wait(1).to({graphics:mask_graphics_830,x:498.7,y:351.7}).wait(1).to({graphics:mask_graphics_831,x:499.3,y:351.7}).wait(1).to({graphics:mask_graphics_832,x:499.9,y:351.7}).wait(1).to({graphics:mask_graphics_833,x:500.4,y:351.7}).wait(1).to({graphics:mask_graphics_834,x:501,y:351.7}).wait(1).to({graphics:mask_graphics_835,x:501.6,y:351.7}).wait(1).to({graphics:mask_graphics_836,x:502.1,y:351.7}).wait(1).to({graphics:mask_graphics_837,x:502.7,y:351.7}).wait(1).to({graphics:mask_graphics_838,x:503.3,y:351.7}).wait(1).to({graphics:mask_graphics_839,x:503.9,y:351.7}).wait(1).to({graphics:mask_graphics_840,x:504.4,y:351.7}).wait(1).to({graphics:mask_graphics_841,x:505,y:351.7}).wait(1).to({graphics:mask_graphics_842,x:505.6,y:351.7}).wait(1).to({graphics:mask_graphics_843,x:506.1,y:351.7}).wait(1).to({graphics:mask_graphics_844,x:506.7,y:351.7}).wait(1).to({graphics:mask_graphics_845,x:507.3,y:351.7}).wait(1).to({graphics:mask_graphics_846,x:507.9,y:351.7}).wait(1).to({graphics:mask_graphics_847,x:508.5,y:351.7}).wait(1).to({graphics:mask_graphics_848,x:509,y:351.7}).wait(1).to({graphics:mask_graphics_849,x:509.6,y:351.7}).wait(1).to({graphics:mask_graphics_850,x:510.2,y:351.7}).wait(1).to({graphics:mask_graphics_851,x:510.7,y:351.7}).wait(1).to({graphics:mask_graphics_852,x:511.3,y:351.7}).wait(1).to({graphics:mask_graphics_853,x:511.9,y:351.7}).wait(1).to({graphics:mask_graphics_854,x:512.5,y:351.7}).wait(1).to({graphics:mask_graphics_855,x:513,y:351.7}).wait(1).to({graphics:mask_graphics_856,x:513.6,y:351.7}).wait(1).to({graphics:mask_graphics_857,x:514.2,y:351.7}).wait(1).to({graphics:mask_graphics_858,x:514.7,y:351.7}).wait(1).to({graphics:mask_graphics_859,x:515.3,y:351.7}).wait(1).to({graphics:mask_graphics_860,x:515.9,y:351.7}).wait(1).to({graphics:mask_graphics_861,x:516.5,y:351.7}).wait(1).to({graphics:mask_graphics_862,x:517,y:351.7}).wait(1).to({graphics:mask_graphics_863,x:517.6,y:351.7}).wait(1).to({graphics:mask_graphics_864,x:518.2,y:351.7}).wait(1).to({graphics:mask_graphics_865,x:518.8,y:351.7}).wait(1).to({graphics:mask_graphics_866,x:519.3,y:351.7}).wait(1).to({graphics:mask_graphics_867,x:519.9,y:351.7}).wait(1).to({graphics:mask_graphics_868,x:520.5,y:351.7}).wait(1).to({graphics:mask_graphics_869,x:521.1,y:351.7}).wait(1).to({graphics:mask_graphics_870,x:521.6,y:351.7}).wait(1).to({graphics:mask_graphics_871,x:522.2,y:351.7}).wait(1).to({graphics:mask_graphics_872,x:522.8,y:351.7}).wait(1).to({graphics:mask_graphics_873,x:523.3,y:351.7}).wait(1).to({graphics:mask_graphics_874,x:523.9,y:351.7}).wait(1).to({graphics:mask_graphics_875,x:524.5,y:351.6}).wait(1).to({graphics:mask_graphics_876,x:525.1,y:351.6}).wait(1).to({graphics:mask_graphics_877,x:525.6,y:351.6}).wait(1).to({graphics:mask_graphics_878,x:526.2,y:351.6}).wait(1).to({graphics:mask_graphics_879,x:526.8,y:351.6}).wait(1).to({graphics:mask_graphics_880,x:527.4,y:351.6}).wait(1).to({graphics:mask_graphics_881,x:527.9,y:351.6}).wait(1).to({graphics:mask_graphics_882,x:528.5,y:351.6}).wait(1).to({graphics:mask_graphics_883,x:529.1,y:351.6}).wait(1).to({graphics:mask_graphics_884,x:529.6,y:351.6}).wait(1).to({graphics:mask_graphics_885,x:530.2,y:351.6}).wait(1).to({graphics:mask_graphics_886,x:530.8,y:351.6}).wait(1).to({graphics:mask_graphics_887,x:531.4,y:351.6}).wait(1).to({graphics:mask_graphics_888,x:531.9,y:351.6}).wait(1).to({graphics:mask_graphics_889,x:532.5,y:351.6}).wait(1).to({graphics:mask_graphics_890,x:533.1,y:351.6}).wait(1).to({graphics:mask_graphics_891,x:533.6,y:351.6}).wait(1).to({graphics:mask_graphics_892,x:534.2,y:351.6}).wait(1).to({graphics:mask_graphics_893,x:534.8,y:351.6}).wait(1).to({graphics:mask_graphics_894,x:535.4,y:351.6}).wait(1).to({graphics:mask_graphics_895,x:535.9,y:351.6}).wait(1).to({graphics:mask_graphics_896,x:536.5,y:351.6}).wait(1).to({graphics:mask_graphics_897,x:537.1,y:351.6}).wait(1).to({graphics:mask_graphics_898,x:537.6,y:351.6}).wait(1).to({graphics:mask_graphics_899,x:538.2,y:351.6}).wait(1).to({graphics:mask_graphics_900,x:538.8,y:351.6}).wait(1).to({graphics:mask_graphics_901,x:539.4,y:351.6}).wait(1).to({graphics:mask_graphics_902,x:540,y:351.6}).wait(1).to({graphics:mask_graphics_903,x:540.5,y:351.6}).wait(1).to({graphics:mask_graphics_904,x:541.1,y:351.6}).wait(1).to({graphics:mask_graphics_905,x:541.7,y:351.6}).wait(1).to({graphics:mask_graphics_906,x:542.2,y:351.6}).wait(1).to({graphics:mask_graphics_907,x:542.8,y:351.6}).wait(1).to({graphics:mask_graphics_908,x:543.4,y:351.6}).wait(1).to({graphics:mask_graphics_909,x:544,y:351.6}).wait(1).to({graphics:mask_graphics_910,x:544.5,y:351.6}).wait(1).to({graphics:mask_graphics_911,x:545.1,y:351.6}).wait(1).to({graphics:mask_graphics_912,x:545.7,y:351.6}).wait(1).to({graphics:mask_graphics_913,x:546.2,y:351.6}).wait(1).to({graphics:mask_graphics_914,x:546.8,y:351.6}).wait(1).to({graphics:mask_graphics_915,x:547.4,y:351.6}).wait(1).to({graphics:mask_graphics_916,x:548,y:351.6}).wait(1).to({graphics:mask_graphics_917,x:548.6,y:351.6}).wait(1).to({graphics:mask_graphics_918,x:549.1,y:351.6}).wait(1).to({graphics:mask_graphics_919,x:549.7,y:351.6}).wait(1).to({graphics:mask_graphics_920,x:550.3,y:351.6}).wait(1).to({graphics:mask_graphics_921,x:550.8,y:351.6}).wait(1).to({graphics:mask_graphics_922,x:551.4,y:351.6}).wait(1).to({graphics:mask_graphics_923,x:552,y:351.6}).wait(1).to({graphics:mask_graphics_924,x:552.6,y:351.6}).wait(1).to({graphics:mask_graphics_925,x:553.1,y:351.6}).wait(1).to({graphics:mask_graphics_926,x:553.7,y:351.6}).wait(1).to({graphics:mask_graphics_927,x:554.3,y:351.6}).wait(1).to({graphics:mask_graphics_928,x:554.8,y:351.6}).wait(1).to({graphics:mask_graphics_929,x:555.4,y:351.6}).wait(1).to({graphics:mask_graphics_930,x:556,y:351.6}).wait(1).to({graphics:mask_graphics_931,x:556.6,y:351.6}).wait(1).to({graphics:mask_graphics_932,x:557.1,y:351.6}).wait(1).to({graphics:mask_graphics_933,x:557.7,y:351.6}).wait(1).to({graphics:mask_graphics_934,x:558.3,y:351.6}).wait(1).to({graphics:mask_graphics_935,x:558.9,y:351.6}).wait(1).to({graphics:mask_graphics_936,x:559.4,y:351.6}).wait(1).to({graphics:mask_graphics_937,x:560,y:351.6}).wait(1).to({graphics:mask_graphics_938,x:560.6,y:351.6}).wait(1).to({graphics:mask_graphics_939,x:561.1,y:351.6}).wait(1).to({graphics:mask_graphics_940,x:561.7,y:351.6}).wait(1).to({graphics:mask_graphics_941,x:562.3,y:351.6}).wait(1).to({graphics:mask_graphics_942,x:562.9,y:351.6}).wait(1).to({graphics:mask_graphics_943,x:563.4,y:351.6}).wait(1).to({graphics:mask_graphics_944,x:564,y:351.6}).wait(1).to({graphics:mask_graphics_945,x:564.6,y:351.6}).wait(1).to({graphics:mask_graphics_946,x:565.1,y:351.6}).wait(1).to({graphics:mask_graphics_947,x:565.7,y:351.6}).wait(1).to({graphics:mask_graphics_948,x:566.3,y:351.6}).wait(1).to({graphics:mask_graphics_949,x:566.9,y:351.6}).wait(1).to({graphics:mask_graphics_950,x:567.5,y:351.6}).wait(1).to({graphics:mask_graphics_951,x:568,y:351.6}).wait(1).to({graphics:mask_graphics_952,x:568.6,y:351.6}).wait(1).to({graphics:mask_graphics_953,x:569.2,y:351.6}).wait(1).to({graphics:mask_graphics_954,x:569.7,y:351.6}).wait(1).to({graphics:mask_graphics_955,x:570.3,y:351.6}).wait(1).to({graphics:mask_graphics_956,x:570.9,y:351.6}).wait(1).to({graphics:mask_graphics_957,x:571.5,y:351.6}).wait(1).to({graphics:mask_graphics_958,x:572,y:351.6}).wait(1).to({graphics:mask_graphics_959,x:572.6,y:351.6}).wait(1).to({graphics:mask_graphics_960,x:573.2,y:351.6}).wait(1).to({graphics:mask_graphics_961,x:573.7,y:351.6}).wait(1).to({graphics:mask_graphics_962,x:574.3,y:351.6}).wait(1).to({graphics:mask_graphics_963,x:574.9,y:351.6}).wait(1).to({graphics:mask_graphics_964,x:575.5,y:351.6}).wait(1).to({graphics:mask_graphics_965,x:576.1,y:351.6}).wait(1).to({graphics:mask_graphics_966,x:576.6,y:351.6}).wait(1).to({graphics:mask_graphics_967,x:577.2,y:351.6}).wait(1).to({graphics:mask_graphics_968,x:577.7,y:351.6}).wait(1).to({graphics:mask_graphics_969,x:578.3,y:351.6}).wait(1).to({graphics:mask_graphics_970,x:578.9,y:351.6}).wait(1).to({graphics:mask_graphics_971,x:579.5,y:351.6}).wait(1).to({graphics:mask_graphics_972,x:580.1,y:351.6}).wait(1).to({graphics:mask_graphics_973,x:580.6,y:351.6}).wait(1).to({graphics:mask_graphics_974,x:581.2,y:351.6}).wait(1).to({graphics:mask_graphics_975,x:581.8,y:351.5}).wait(1).to({graphics:mask_graphics_976,x:582.3,y:351.5}).wait(1).to({graphics:mask_graphics_977,x:582.9,y:351.5}).wait(1).to({graphics:mask_graphics_978,x:583.5,y:351.5}).wait(1).to({graphics:mask_graphics_979,x:584.1,y:351.5}).wait(1).to({graphics:mask_graphics_980,x:584.6,y:351.5}).wait(1).to({graphics:mask_graphics_981,x:585.2,y:351.5}).wait(1).to({graphics:mask_graphics_982,x:585.8,y:351.5}).wait(1).to({graphics:mask_graphics_983,x:586.3,y:351.5}).wait(1).to({graphics:mask_graphics_984,x:586.9,y:351.5}).wait(1).to({graphics:mask_graphics_985,x:587.5,y:351.5}).wait(1).to({graphics:mask_graphics_986,x:588.1,y:351.5}).wait(1).to({graphics:mask_graphics_987,x:588.6,y:351.5}).wait(1).to({graphics:mask_graphics_988,x:589.2,y:351.5}).wait(1).to({graphics:mask_graphics_989,x:589.8,y:351.5}).wait(1).to({graphics:mask_graphics_990,x:590.4,y:351.5}).wait(1).to({graphics:mask_graphics_991,x:590.9,y:351.5}).wait(1).to({graphics:mask_graphics_992,x:591.5,y:351.5}).wait(1).to({graphics:mask_graphics_993,x:592.1,y:351.5}).wait(1).to({graphics:mask_graphics_994,x:592.6,y:351.5}).wait(1).to({graphics:mask_graphics_995,x:593.2,y:351.5}).wait(1).to({graphics:mask_graphics_996,x:593.8,y:351.5}).wait(1).to({graphics:mask_graphics_997,x:594.4,y:351.5}).wait(1).to({graphics:mask_graphics_998,x:594.9,y:351.5}).wait(1).to({graphics:mask_graphics_999,x:595.5,y:351.5}).wait(1));

	// startContent
	this.instance = new lib.container_text("single",2);
	this.instance.setTransform(997,802.8,1,1,0,0,0,548,182.8);

	this.instance.mask = mask;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1000));

	// Ebene 3
	this.instance_1 = new lib.pic_shadow_occlusionRound();
	this.instance_1.setTransform(648.9,713.9,2.757,1);
	this.instance_1.alpha = 0.5;

	this.instance_2 = new lib.pic_shadow_occlusionRound();
	this.instance_2.setTransform(472.9,678.9,2.757,1);
	this.instance_2.alpha = 0.5;

	this.instance_3 = new lib.pic_shadow_occlusionRound();
	this.instance_3.setTransform(641.7,629.9,2.757,1);
	this.instance_3.alpha = 0.5;

	this.instance_4 = new lib.pic_shadow_occlusionRound();
	this.instance_4.setTransform(562.7,629.9,2.757,1);
	this.instance_4.alpha = 0.5;

	this.instance_1.mask = this.instance_2.mask = this.instance_3.mask = this.instance_4.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1}]}).wait(1000));

	// container_pics
	this.instance_5 = new lib.container_pics("single",0);

	this.instance_5.mask = mask;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(1000));

	// mask_green-> covering (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_0 = new cjs.Graphics().p("EhZbA26MAAAht0MC+1AAAMAAABt0g");
	var mask_1_graphics_1 = new cjs.Graphics().p("EhfUA26MAAAht0MC+pAAAMAAABt0g");
	var mask_1_graphics_2 = new cjs.Graphics().p("EhfOA26MAAAht0MC+dAAAMAAABt0g");
	var mask_1_graphics_3 = new cjs.Graphics().p("EhfIA26MAAAht0MC+RAAAMAAABt0g");
	var mask_1_graphics_4 = new cjs.Graphics().p("EhfCA26MAAAht0MC+FAAAMAAABt0g");
	var mask_1_graphics_5 = new cjs.Graphics().p("Ehe8A26MAAAht0MC95AAAMAAABt0g");
	var mask_1_graphics_6 = new cjs.Graphics().p("Ehe2A26MAAAht0MC9tAAAMAAABt0g");
	var mask_1_graphics_7 = new cjs.Graphics().p("EhewA26MAAAht0MC9hAAAMAAABt0g");
	var mask_1_graphics_8 = new cjs.Graphics().p("EheqA26MAAAht0MC9VAAAMAAABt0g");
	var mask_1_graphics_9 = new cjs.Graphics().p("EhekA26MAAAht0MC9JAAAMAAABt0g");
	var mask_1_graphics_10 = new cjs.Graphics().p("EheeA26MAAAht0MC89AAAMAAABt0g");
	var mask_1_graphics_11 = new cjs.Graphics().p("EheYA26MAAAht0MC8xAAAMAAABt0g");
	var mask_1_graphics_12 = new cjs.Graphics().p("EheSA26MAAAht0MC8lAAAMAAABt0g");
	var mask_1_graphics_13 = new cjs.Graphics().p("EheMA26MAAAht0MC8ZAAAMAAABt0g");
	var mask_1_graphics_14 = new cjs.Graphics().p("EheGA26MAAAht0MC8NAAAMAAABt0g");
	var mask_1_graphics_15 = new cjs.Graphics().p("EheAA26MAAAht0MC8BAAAMAAABt0g");
	var mask_1_graphics_16 = new cjs.Graphics().p("Ehd6A26MAAAht0MC71AAAMAAABt0g");
	var mask_1_graphics_17 = new cjs.Graphics().p("Ehd0A26MAAAht0MC7pAAAMAAABt0g");
	var mask_1_graphics_18 = new cjs.Graphics().p("EhduA26MAAAht0MC7dAAAMAAABt0g");
	var mask_1_graphics_19 = new cjs.Graphics().p("EhdoA26MAAAht0MC7RAAAMAAABt0g");
	var mask_1_graphics_20 = new cjs.Graphics().p("EhdiA26MAAAht0MC7FAAAMAAABt0g");
	var mask_1_graphics_21 = new cjs.Graphics().p("EhdcA26MAAAht0MC65AAAMAAABt0g");
	var mask_1_graphics_22 = new cjs.Graphics().p("EhdWA26MAAAht0MC6tAAAMAAABt0g");
	var mask_1_graphics_23 = new cjs.Graphics().p("EhdQA26MAAAht0MC6hAAAMAAABt0g");
	var mask_1_graphics_24 = new cjs.Graphics().p("EhdLA26MAAAht0MC6XAAAMAAABt0g");
	var mask_1_graphics_25 = new cjs.Graphics().p("EhdEA26MAAAht0MC6JAAAMAAABt0g");
	var mask_1_graphics_26 = new cjs.Graphics().p("Ehc+A26MAAAht0MC59AAAMAAABt0g");
	var mask_1_graphics_27 = new cjs.Graphics().p("Ehc4A26MAAAht0MC5yAAAMAAABt0g");
	var mask_1_graphics_28 = new cjs.Graphics().p("EhcyA26MAAAht0MC5lAAAMAAABt0g");
	var mask_1_graphics_29 = new cjs.Graphics().p("EhcsA26MAAAht0MC5ZAAAMAAABt0g");
	var mask_1_graphics_30 = new cjs.Graphics().p("EhcmA26MAAAht0MC5NAAAMAAABt0g");
	var mask_1_graphics_31 = new cjs.Graphics().p("EhcgA26MAAAht0MC5BAAAMAAABt0g");
	var mask_1_graphics_32 = new cjs.Graphics().p("EhcaA26MAAAht0MC41AAAMAAABt0g");
	var mask_1_graphics_33 = new cjs.Graphics().p("EhcUA26MAAAht0MC4pAAAMAAABt0g");
	var mask_1_graphics_34 = new cjs.Graphics().p("EhcPA26MAAAht0MC4fAAAMAAABt0g");
	var mask_1_graphics_35 = new cjs.Graphics().p("EhcIA26MAAAht0MC4SAAAMAAABt0g");
	var mask_1_graphics_36 = new cjs.Graphics().p("EhcDA26MAAAht0MC4HAAAMAAABt0g");
	var mask_1_graphics_37 = new cjs.Graphics().p("Ehb9A26MAAAht0MC37AAAMAAABt0g");
	var mask_1_graphics_38 = new cjs.Graphics().p("Ehb3A26MAAAht0MC3vAAAMAAABt0g");
	var mask_1_graphics_39 = new cjs.Graphics().p("EhbxA26MAAAht0MC3jAAAMAAABt0g");
	var mask_1_graphics_40 = new cjs.Graphics().p("EhbrA26MAAAht0MC3XAAAMAAABt0g");
	var mask_1_graphics_41 = new cjs.Graphics().p("EhblA26MAAAht0MC3KAAAMAAABt0g");
	var mask_1_graphics_42 = new cjs.Graphics().p("EhbfA26MAAAht0MC2/AAAMAAABt0g");
	var mask_1_graphics_43 = new cjs.Graphics().p("EhbZA26MAAAht0MC2zAAAMAAABt0g");
	var mask_1_graphics_44 = new cjs.Graphics().p("EhbTA26MAAAht0MC2nAAAMAAABt0g");
	var mask_1_graphics_45 = new cjs.Graphics().p("EhbNA26MAAAht0MC2bAAAMAAABt0g");
	var mask_1_graphics_46 = new cjs.Graphics().p("EhbHA26MAAAht0MC2PAAAMAAABt0g");
	var mask_1_graphics_47 = new cjs.Graphics().p("EhbBA26MAAAht0MC2DAAAMAAABt0g");
	var mask_1_graphics_48 = new cjs.Graphics().p("Eha7A26MAAAht0MC13AAAMAAABt0g");
	var mask_1_graphics_49 = new cjs.Graphics().p("Eha1A26MAAAht0MC1rAAAMAAABt0g");
	var mask_1_graphics_50 = new cjs.Graphics().p("EhavA26MAAAht0MC1fAAAMAAABt0g");
	var mask_1_graphics_51 = new cjs.Graphics().p("EhapA26MAAAht0MC1TAAAMAAABt0g");
	var mask_1_graphics_52 = new cjs.Graphics().p("EhajA26MAAAht0MC1HAAAMAAABt0g");
	var mask_1_graphics_53 = new cjs.Graphics().p("EhadA26MAAAht0MC07AAAMAAABt0g");
	var mask_1_graphics_54 = new cjs.Graphics().p("EhaXA26MAAAht0MC0vAAAMAAABt0g");
	var mask_1_graphics_55 = new cjs.Graphics().p("EhaRA26MAAAht0MC0jAAAMAAABt0g");
	var mask_1_graphics_56 = new cjs.Graphics().p("EhaLA26MAAAht0MC0XAAAMAAABt0g");
	var mask_1_graphics_57 = new cjs.Graphics().p("EhaFA26MAAAht0MC0LAAAMAAABt0g");
	var mask_1_graphics_58 = new cjs.Graphics().p("EhZ/A26MAAAht0MCz/AAAMAAABt0g");
	var mask_1_graphics_59 = new cjs.Graphics().p("EhZ5A26MAAAht0MCzzAAAMAAABt0g");
	var mask_1_graphics_60 = new cjs.Graphics().p("EhZzA26MAAAht0MCznAAAMAAABt0g");
	var mask_1_graphics_61 = new cjs.Graphics().p("EhZtA26MAAAht0MCzbAAAMAAABt0g");
	var mask_1_graphics_62 = new cjs.Graphics().p("EhZnA26MAAAht0MCzPAAAMAAABt0g");
	var mask_1_graphics_63 = new cjs.Graphics().p("EhZhA26MAAAht0MCzDAAAMAAABt0g");
	var mask_1_graphics_64 = new cjs.Graphics().p("EhZbA26MAAAht0MCy3AAAMAAABt0g");
	var mask_1_graphics_65 = new cjs.Graphics().p("EhZVA26MAAAht0MCyrAAAMAAABt0g");
	var mask_1_graphics_66 = new cjs.Graphics().p("EhZPA26MAAAht0MCyfAAAMAAABt0g");
	var mask_1_graphics_67 = new cjs.Graphics().p("EhZJA26MAAAht0MCyTAAAMAAABt0g");
	var mask_1_graphics_68 = new cjs.Graphics().p("EhZDA26MAAAht0MCyHAAAMAAABt0g");
	var mask_1_graphics_69 = new cjs.Graphics().p("EhY9A26MAAAht0MCx7AAAMAAABt0g");
	var mask_1_graphics_70 = new cjs.Graphics().p("EhY3A26MAAAht0MCxvAAAMAAABt0g");
	var mask_1_graphics_71 = new cjs.Graphics().p("EhYxA26MAAAht0MCxjAAAMAAABt0g");
	var mask_1_graphics_72 = new cjs.Graphics().p("EhYsA26MAAAht0MCxZAAAMAAABt0g");
	var mask_1_graphics_73 = new cjs.Graphics().p("EhYlA26MAAAht0MCxLAAAMAAABt0g");
	var mask_1_graphics_74 = new cjs.Graphics().p("EhYgA26MAAAht0MCxAAAAMAAABt0g");
	var mask_1_graphics_75 = new cjs.Graphics().p("EhYZA26MAAAht0MCwzAAAMAAABt0g");
	var mask_1_graphics_76 = new cjs.Graphics().p("EhYTA26MAAAht0MCwnAAAMAAABt0g");
	var mask_1_graphics_77 = new cjs.Graphics().p("EhYNA26MAAAht0MCwbAAAMAAABt0g");
	var mask_1_graphics_78 = new cjs.Graphics().p("EhYHA26MAAAht0MCwPAAAMAAABt0g");
	var mask_1_graphics_79 = new cjs.Graphics().p("EhYBA26MAAAht0MCwEAAAMAAABt0g");
	var mask_1_graphics_80 = new cjs.Graphics().p("EhX7A26MAAAht0MCv4AAAMAAABt0g");
	var mask_1_graphics_81 = new cjs.Graphics().p("EhX2A26MAAAht0MCvtAAAMAAABt0g");
	var mask_1_graphics_82 = new cjs.Graphics().p("EhXwA26MAAAht0MCvhAAAMAAABt0g");
	var mask_1_graphics_83 = new cjs.Graphics().p("EhXqA26MAAAht0MCvVAAAMAAABt0g");
	var mask_1_graphics_84 = new cjs.Graphics().p("EhXkA26MAAAht0MCvJAAAMAAABt0g");
	var mask_1_graphics_85 = new cjs.Graphics().p("EhXeA26MAAAht0MCu9AAAMAAABt0g");
	var mask_1_graphics_86 = new cjs.Graphics().p("EhXYA26MAAAht0MCuwAAAMAAABt0g");
	var mask_1_graphics_87 = new cjs.Graphics().p("EhXSA26MAAAht0MCulAAAMAAABt0g");
	var mask_1_graphics_88 = new cjs.Graphics().p("EhXMA26MAAAht0MCuZAAAMAAABt0g");
	var mask_1_graphics_89 = new cjs.Graphics().p("EhXGA26MAAAht0MCuNAAAMAAABt0g");
	var mask_1_graphics_90 = new cjs.Graphics().p("EhXAA26MAAAht0MCuBAAAMAAABt0g");
	var mask_1_graphics_91 = new cjs.Graphics().p("EhW6A26MAAAht0MCt1AAAMAAABt0g");
	var mask_1_graphics_92 = new cjs.Graphics().p("EhW0A26MAAAht0MCtpAAAMAAABt0g");
	var mask_1_graphics_93 = new cjs.Graphics().p("EhWuA26MAAAht0MCtdAAAMAAABt0g");
	var mask_1_graphics_94 = new cjs.Graphics().p("EhWoA26MAAAht0MCtRAAAMAAABt0g");
	var mask_1_graphics_95 = new cjs.Graphics().p("EhWiA26MAAAht0MCtFAAAMAAABt0g");
	var mask_1_graphics_96 = new cjs.Graphics().p("EhWcA26MAAAht0MCs5AAAMAAABt0g");
	var mask_1_graphics_97 = new cjs.Graphics().p("EhWWA26MAAAht0MCstAAAMAAABt0g");
	var mask_1_graphics_98 = new cjs.Graphics().p("EhWQA26MAAAht0MCshAAAMAAABt0g");
	var mask_1_graphics_99 = new cjs.Graphics().p("EhWKA26MAAAht0MCsVAAAMAAABt0g");
	var mask_1_graphics_100 = new cjs.Graphics().p("EhWEA26MAAAht0MCsJAAAMAAABt0g");
	var mask_1_graphics_101 = new cjs.Graphics().p("EhV+A26MAAAht0MCr9AAAMAAABt0g");
	var mask_1_graphics_102 = new cjs.Graphics().p("EhV4A26MAAAht0MCrxAAAMAAABt0g");
	var mask_1_graphics_103 = new cjs.Graphics().p("EhVyA26MAAAht0MCrlAAAMAAABt0g");
	var mask_1_graphics_104 = new cjs.Graphics().p("EhVsA26MAAAht0MCrZAAAMAAABt0g");
	var mask_1_graphics_105 = new cjs.Graphics().p("EhVmA26MAAAht0MCrNAAAMAAABt0g");
	var mask_1_graphics_106 = new cjs.Graphics().p("EhVgA26MAAAht0MCrBAAAMAAABt0g");
	var mask_1_graphics_107 = new cjs.Graphics().p("EhVaA26MAAAht0MCq1AAAMAAABt0g");
	var mask_1_graphics_108 = new cjs.Graphics().p("EhVUA26MAAAht0MCqpAAAMAAABt0g");
	var mask_1_graphics_109 = new cjs.Graphics().p("EhVOA26MAAAht0MCqdAAAMAAABt0g");
	var mask_1_graphics_110 = new cjs.Graphics().p("EhVIA26MAAAht0MCqRAAAMAAABt0g");
	var mask_1_graphics_111 = new cjs.Graphics().p("EhVCA26MAAAht0MCqFAAAMAAABt0g");
	var mask_1_graphics_112 = new cjs.Graphics().p("EhU8A26MAAAht0MCp5AAAMAAABt0g");
	var mask_1_graphics_113 = new cjs.Graphics().p("EhU2A26MAAAht0MCptAAAMAAABt0g");
	var mask_1_graphics_114 = new cjs.Graphics().p("EhUwA26MAAAht0MCphAAAMAAABt0g");
	var mask_1_graphics_115 = new cjs.Graphics().p("EhUqA26MAAAht0MCpVAAAMAAABt0g");
	var mask_1_graphics_116 = new cjs.Graphics().p("EhUkA26MAAAht0MCpJAAAMAAABt0g");
	var mask_1_graphics_117 = new cjs.Graphics().p("EhUfA26MAAAht0MCo/AAAMAAABt0g");
	var mask_1_graphics_118 = new cjs.Graphics().p("EhUYA26MAAAht0MCoxAAAMAAABt0g");
	var mask_1_graphics_119 = new cjs.Graphics().p("EhUTA26MAAAht0MComAAAMAAABt0g");
	var mask_1_graphics_120 = new cjs.Graphics().p("EhUNA26MAAAht0MCoaAAAMAAABt0g");
	var mask_1_graphics_121 = new cjs.Graphics().p("EhUGA26MAAAht0MCoNAAAMAAABt0g");
	var mask_1_graphics_122 = new cjs.Graphics().p("EhUBA26MAAAht0MCoCAAAMAAABt0g");
	var mask_1_graphics_123 = new cjs.Graphics().p("EhT6A26MAAAht0MCn1AAAMAAABt0g");
	var mask_1_graphics_124 = new cjs.Graphics().p("EhT1A26MAAAht0MCnrAAAMAAABt0g");
	var mask_1_graphics_125 = new cjs.Graphics().p("EhTuA26MAAAht0MCneAAAMAAABt0g");
	var mask_1_graphics_126 = new cjs.Graphics().p("EhToA26MAAAht0MCnRAAAMAAABt0g");
	var mask_1_graphics_127 = new cjs.Graphics().p("EhTjA26MAAAht0MCnHAAAMAAABt0g");
	var mask_1_graphics_128 = new cjs.Graphics().p("EhTcA26MAAAht0MCm6AAAMAAABt0g");
	var mask_1_graphics_129 = new cjs.Graphics().p("EhTXA26MAAAht0MCmvAAAMAAABt0g");
	var mask_1_graphics_130 = new cjs.Graphics().p("EhTRA26MAAAht0MCmjAAAMAAABt0g");
	var mask_1_graphics_131 = new cjs.Graphics().p("EhTLA26MAAAht0MCmWAAAMAAABt0g");
	var mask_1_graphics_132 = new cjs.Graphics().p("EhTFA26MAAAht0MCmLAAAMAAABt0g");
	var mask_1_graphics_133 = new cjs.Graphics().p("EhS/A26MAAAht0MCl/AAAMAAABt0g");
	var mask_1_graphics_134 = new cjs.Graphics().p("EhS5A26MAAAht0MClzAAAMAAABt0g");
	var mask_1_graphics_135 = new cjs.Graphics().p("EhSzA26MAAAht0MClnAAAMAAABt0g");
	var mask_1_graphics_136 = new cjs.Graphics().p("EhStA26MAAAht0MClbAAAMAAABt0g");
	var mask_1_graphics_137 = new cjs.Graphics().p("EhSnA26MAAAht0MClPAAAMAAABt0g");
	var mask_1_graphics_138 = new cjs.Graphics().p("EhShA26MAAAht0MClDAAAMAAABt0g");
	var mask_1_graphics_139 = new cjs.Graphics().p("EhSbA26MAAAht0MCk3AAAMAAABt0g");
	var mask_1_graphics_140 = new cjs.Graphics().p("EhSVA26MAAAht0MCkrAAAMAAABt0g");
	var mask_1_graphics_141 = new cjs.Graphics().p("EhSPA26MAAAht0MCkfAAAMAAABt0g");
	var mask_1_graphics_142 = new cjs.Graphics().p("EhSJA26MAAAht0MCkTAAAMAAABt0g");
	var mask_1_graphics_143 = new cjs.Graphics().p("EhSDA26MAAAht0MCkHAAAMAAABt0g");
	var mask_1_graphics_144 = new cjs.Graphics().p("EhR9A26MAAAht0MCj7AAAMAAABt0g");
	var mask_1_graphics_145 = new cjs.Graphics().p("EhR3A26MAAAht0MCjvAAAMAAABt0g");
	var mask_1_graphics_146 = new cjs.Graphics().p("EhRxA26MAAAht0MCjjAAAMAAABt0g");
	var mask_1_graphics_147 = new cjs.Graphics().p("EhRrA26MAAAht0MCjXAAAMAAABt0g");
	var mask_1_graphics_148 = new cjs.Graphics().p("EhRlA26MAAAht0MCjLAAAMAAABt0g");
	var mask_1_graphics_149 = new cjs.Graphics().p("EhRfA26MAAAht0MCi/AAAMAAABt0g");
	var mask_1_graphics_150 = new cjs.Graphics().p("EhRZA26MAAAht0MCizAAAMAAABt0g");
	var mask_1_graphics_151 = new cjs.Graphics().p("EhRTA26MAAAht0MCinAAAMAAABt0g");
	var mask_1_graphics_152 = new cjs.Graphics().p("EhRNA26MAAAht0MCibAAAMAAABt0g");
	var mask_1_graphics_153 = new cjs.Graphics().p("EhRHA26MAAAht0MCiPAAAMAAABt0g");
	var mask_1_graphics_154 = new cjs.Graphics().p("EhRBA26MAAAht0MCiDAAAMAAABt0g");
	var mask_1_graphics_155 = new cjs.Graphics().p("EhQ7A26MAAAht0MCh3AAAMAAABt0g");
	var mask_1_graphics_156 = new cjs.Graphics().p("EhQ1A26MAAAht0MChrAAAMAAABt0g");
	var mask_1_graphics_157 = new cjs.Graphics().p("EhQvA26MAAAht0MChfAAAMAAABt0g");
	var mask_1_graphics_158 = new cjs.Graphics().p("EhQpA26MAAAht0MChTAAAMAAABt0g");
	var mask_1_graphics_159 = new cjs.Graphics().p("EhQjA26MAAAht0MChHAAAMAAABt0g");
	var mask_1_graphics_160 = new cjs.Graphics().p("EhQdA26MAAAht0MCg7AAAMAAABt0g");
	var mask_1_graphics_161 = new cjs.Graphics().p("EhQXA26MAAAht0MCgvAAAMAAABt0g");
	var mask_1_graphics_162 = new cjs.Graphics().p("EhQRA26MAAAht0MCgkAAAMAAABt0g");
	var mask_1_graphics_163 = new cjs.Graphics().p("EhQLA26MAAAht0MCgXAAAMAAABt0g");
	var mask_1_graphics_164 = new cjs.Graphics().p("EhQFA26MAAAht0MCgLAAAMAAABt0g");
	var mask_1_graphics_165 = new cjs.Graphics().p("EhQAA26MAAAht0MCgAAAAMAAABt0g");
	var mask_1_graphics_166 = new cjs.Graphics().p("EhP5A26MAAAht0MCfzAAAMAAABt0g");
	var mask_1_graphics_167 = new cjs.Graphics().p("EhP0A26MAAAht0MCfoAAAMAAABt0g");
	var mask_1_graphics_168 = new cjs.Graphics().p("EhPuA26MAAAht0MCfcAAAMAAABt0g");
	var mask_1_graphics_169 = new cjs.Graphics().p("EhPnA26MAAAht0MCfPAAAMAAABt0g");
	var mask_1_graphics_170 = new cjs.Graphics().p("EhPiA26MAAAht0MCfFAAAMAAABt0g");
	var mask_1_graphics_171 = new cjs.Graphics().p("EhPbA26MAAAht0MCe3AAAMAAABt0g");
	var mask_1_graphics_172 = new cjs.Graphics().p("EhPWA26MAAAht0MCetAAAMAAABt0g");
	var mask_1_graphics_173 = new cjs.Graphics().p("EhPPA26MAAAht0MCegAAAMAAABt0g");
	var mask_1_graphics_174 = new cjs.Graphics().p("EhPJA26MAAAht0MCeUAAAMAAABt0g");
	var mask_1_graphics_175 = new cjs.Graphics().p("EhPEA26MAAAht0MCeJAAAMAAABt0g");
	var mask_1_graphics_176 = new cjs.Graphics().p("EhO9A26MAAAht0MCd7AAAMAAABt0g");
	var mask_1_graphics_177 = new cjs.Graphics().p("EhO4A26MAAAht0MCdxAAAMAAABt0g");
	var mask_1_graphics_178 = new cjs.Graphics().p("EhOyA26MAAAht0MCdlAAAMAAABt0g");
	var mask_1_graphics_179 = new cjs.Graphics().p("EhOsA26MAAAht0MCdYAAAMAAABt0g");
	var mask_1_graphics_180 = new cjs.Graphics().p("EhOmA26MAAAht0MCdNAAAMAAABt0g");
	var mask_1_graphics_181 = new cjs.Graphics().p("EhOgA26MAAAht0MCdBAAAMAAABt0g");
	var mask_1_graphics_182 = new cjs.Graphics().p("EhOaA26MAAAht0MCc1AAAMAAABt0g");
	var mask_1_graphics_183 = new cjs.Graphics().p("EhOUA26MAAAht0MCcpAAAMAAABt0g");
	var mask_1_graphics_184 = new cjs.Graphics().p("EhOOA26MAAAht0MCcdAAAMAAABt0g");
	var mask_1_graphics_185 = new cjs.Graphics().p("EhOIA26MAAAht0MCcRAAAMAAABt0g");
	var mask_1_graphics_186 = new cjs.Graphics().p("EhOCA26MAAAht0MCcFAAAMAAABt0g");
	var mask_1_graphics_187 = new cjs.Graphics().p("EhN8A26MAAAht0MCb5AAAMAAABt0g");
	var mask_1_graphics_188 = new cjs.Graphics().p("EhN2A26MAAAht0MCbtAAAMAAABt0g");
	var mask_1_graphics_189 = new cjs.Graphics().p("EhNwA26MAAAht0MCbhAAAMAAABt0g");
	var mask_1_graphics_190 = new cjs.Graphics().p("EhNqA26MAAAht0MCbVAAAMAAABt0g");
	var mask_1_graphics_191 = new cjs.Graphics().p("EhNkA26MAAAht0MCbJAAAMAAABt0g");
	var mask_1_graphics_192 = new cjs.Graphics().p("EhNeA26MAAAht0MCa9AAAMAAABt0g");
	var mask_1_graphics_193 = new cjs.Graphics().p("EhNYA26MAAAht0MCaxAAAMAAABt0g");
	var mask_1_graphics_194 = new cjs.Graphics().p("EhNSA26MAAAht0MCalAAAMAAABt0g");
	var mask_1_graphics_195 = new cjs.Graphics().p("EhNMA26MAAAht0MCaZAAAMAAABt0g");
	var mask_1_graphics_196 = new cjs.Graphics().p("EhNGA26MAAAht0MCaNAAAMAAABt0g");
	var mask_1_graphics_197 = new cjs.Graphics().p("EhNAA26MAAAht0MCaBAAAMAAABt0g");
	var mask_1_graphics_198 = new cjs.Graphics().p("EhM6A26MAAAht0MCZ1AAAMAAABt0g");
	var mask_1_graphics_199 = new cjs.Graphics().p("EhM0A26MAAAht0MCZpAAAMAAABt0g");
	var mask_1_graphics_200 = new cjs.Graphics().p("EhMuA26MAAAht0MCZdAAAMAAABt0g");
	var mask_1_graphics_201 = new cjs.Graphics().p("EhMoA26MAAAht0MCZRAAAMAAABt0g");
	var mask_1_graphics_202 = new cjs.Graphics().p("EhMiA26MAAAht0MCZFAAAMAAABt0g");
	var mask_1_graphics_203 = new cjs.Graphics().p("EhMcA26MAAAht0MCY5AAAMAAABt0g");
	var mask_1_graphics_204 = new cjs.Graphics().p("EhMWA26MAAAht0MCYtAAAMAAABt0g");
	var mask_1_graphics_205 = new cjs.Graphics().p("EhMQA26MAAAht0MCYhAAAMAAABt0g");
	var mask_1_graphics_206 = new cjs.Graphics().p("EhMKA26MAAAht0MCYVAAAMAAABt0g");
	var mask_1_graphics_207 = new cjs.Graphics().p("EhMEA26MAAAht0MCYKAAAMAAABt0g");
	var mask_1_graphics_208 = new cjs.Graphics().p("EhL+A26MAAAht0MCX+AAAMAAABt0g");
	var mask_1_graphics_209 = new cjs.Graphics().p("EhL4A26MAAAht0MCXxAAAMAAABt0g");
	var mask_1_graphics_210 = new cjs.Graphics().p("EhLyA26MAAAht0MCXlAAAMAAABt0g");
	var mask_1_graphics_211 = new cjs.Graphics().p("EhLtA26MAAAht0MCXbAAAMAAABt0g");
	var mask_1_graphics_212 = new cjs.Graphics().p("EhLmA26MAAAht0MCXNAAAMAAABt0g");
	var mask_1_graphics_213 = new cjs.Graphics().p("EhLhA26MAAAht0MCXCAAAMAAABt0g");
	var mask_1_graphics_214 = new cjs.Graphics().p("EhLbA26MAAAht0MCW2AAAMAAABt0g");
	var mask_1_graphics_215 = new cjs.Graphics().p("EhLVA26MAAAht0MCWrAAAMAAABt0g");
	var mask_1_graphics_216 = new cjs.Graphics().p("EhLPA26MAAAht0MCWfAAAMAAABt0g");
	var mask_1_graphics_217 = new cjs.Graphics().p("EhLJA26MAAAht0MCWTAAAMAAABt0g");
	var mask_1_graphics_218 = new cjs.Graphics().p("EhLDA26MAAAht0MCWHAAAMAAABt0g");
	var mask_1_graphics_219 = new cjs.Graphics().p("EhK8A26MAAAht0MCV6AAAMAAABt0g");
	var mask_1_graphics_220 = new cjs.Graphics().p("EhK3A26MAAAht0MCVvAAAMAAABt0g");
	var mask_1_graphics_221 = new cjs.Graphics().p("EhKwA26MAAAht0MCVhAAAMAAABt0g");
	var mask_1_graphics_222 = new cjs.Graphics().p("EhKrA26MAAAht0MCVXAAAMAAABt0g");
	var mask_1_graphics_223 = new cjs.Graphics().p("EhKlA26MAAAht0MCVLAAAMAAABt0g");
	var mask_1_graphics_224 = new cjs.Graphics().p("EhKeA26MAAAht0MCU9AAAMAAABt0g");
	var mask_1_graphics_225 = new cjs.Graphics().p("EhKZA26MAAAht0MCUzAAAMAAABt0g");
	var mask_1_graphics_226 = new cjs.Graphics().p("EhKTA26MAAAht0MCUnAAAMAAABt0g");
	var mask_1_graphics_227 = new cjs.Graphics().p("EhKNA26MAAAht0MCUbAAAMAAABt0g");
	var mask_1_graphics_228 = new cjs.Graphics().p("EhKHA26MAAAht0MCUPAAAMAAABt0g");
	var mask_1_graphics_229 = new cjs.Graphics().p("EhKBA26MAAAht0MCUDAAAMAAABt0g");
	var mask_1_graphics_230 = new cjs.Graphics().p("EhJ7A26MAAAht0MCT3AAAMAAABt0g");
	var mask_1_graphics_231 = new cjs.Graphics().p("EhJ1A26MAAAht0MCTrAAAMAAABt0g");
	var mask_1_graphics_232 = new cjs.Graphics().p("EhJvA26MAAAht0MCTfAAAMAAABt0g");
	var mask_1_graphics_233 = new cjs.Graphics().p("EhJpA26MAAAht0MCTTAAAMAAABt0g");
	var mask_1_graphics_234 = new cjs.Graphics().p("EhJjA26MAAAht0MCTHAAAMAAABt0g");
	var mask_1_graphics_235 = new cjs.Graphics().p("EhJdA26MAAAht0MCS7AAAMAAABt0g");
	var mask_1_graphics_236 = new cjs.Graphics().p("EhJXA26MAAAht0MCSvAAAMAAABt0g");
	var mask_1_graphics_237 = new cjs.Graphics().p("EhJRA26MAAAht0MCSjAAAMAAABt0g");
	var mask_1_graphics_238 = new cjs.Graphics().p("EhJLA26MAAAht0MCSXAAAMAAABt0g");
	var mask_1_graphics_239 = new cjs.Graphics().p("EhJFA26MAAAht0MCSLAAAMAAABt0g");
	var mask_1_graphics_240 = new cjs.Graphics().p("EhI/A26MAAAht0MCR/AAAMAAABt0g");
	var mask_1_graphics_241 = new cjs.Graphics().p("EhI5A26MAAAht0MCRzAAAMAAABt0g");
	var mask_1_graphics_242 = new cjs.Graphics().p("EhIzA26MAAAht0MCRnAAAMAAABt0g");
	var mask_1_graphics_243 = new cjs.Graphics().p("EhItA26MAAAht0MCRbAAAMAAABt0g");
	var mask_1_graphics_244 = new cjs.Graphics().p("EhInA26MAAAht0MCRPAAAMAAABt0g");
	var mask_1_graphics_245 = new cjs.Graphics().p("EhIhA26MAAAht0MCRDAAAMAAABt0g");
	var mask_1_graphics_246 = new cjs.Graphics().p("EhIbA26MAAAht0MCQ3AAAMAAABt0g");
	var mask_1_graphics_247 = new cjs.Graphics().p("EhIVA26MAAAht0MCQrAAAMAAABt0g");
	var mask_1_graphics_248 = new cjs.Graphics().p("EhIPA26MAAAht0MCQfAAAMAAABt0g");
	var mask_1_graphics_249 = new cjs.Graphics().p("EhIJA26MAAAht0MCQTAAAMAAABt0g");
	var mask_1_graphics_250 = new cjs.Graphics().p("EhIEA26MAAAht0MCQJAAAMAAABt0g");
	var mask_1_graphics_251 = new cjs.Graphics().p("EhH9A26MAAAht0MCP7AAAMAAABt0g");
	var mask_1_graphics_252 = new cjs.Graphics().p("EhH4A26MAAAht0MCPxAAAMAAABt0g");
	var mask_1_graphics_253 = new cjs.Graphics().p("EhHxA26MAAAht0MCPkAAAMAAABt0g");
	var mask_1_graphics_254 = new cjs.Graphics().p("EhHrA26MAAAht0MCPXAAAMAAABt0g");
	var mask_1_graphics_255 = new cjs.Graphics().p("EhHlA26MAAAht0MCPLAAAMAAABt0g");
	var mask_1_graphics_256 = new cjs.Graphics().p("EhHfA26MAAAht0MCO/AAAMAAABt0g");
	var mask_1_graphics_257 = new cjs.Graphics().p("EhHZA26MAAAht0MCOzAAAMAAABt0g");
	var mask_1_graphics_258 = new cjs.Graphics().p("EhHTA26MAAAht0MCOnAAAMAAABt0g");
	var mask_1_graphics_259 = new cjs.Graphics().p("EhHOA26MAAAht0MCOcAAAMAAABt0g");
	var mask_1_graphics_260 = new cjs.Graphics().p("EhHHA26MAAAht0MCOQAAAMAAABt0g");
	var mask_1_graphics_261 = new cjs.Graphics().p("EhHCA26MAAAht0MCOFAAAMAAABt0g");
	var mask_1_graphics_262 = new cjs.Graphics().p("EhG8A26MAAAht0MCN5AAAMAAABt0g");
	var mask_1_graphics_263 = new cjs.Graphics().p("EhG2A26MAAAht0MCNtAAAMAAABt0g");
	var mask_1_graphics_264 = new cjs.Graphics().p("EhGwA26MAAAht0MCNhAAAMAAABt0g");
	var mask_1_graphics_265 = new cjs.Graphics().p("EhGqA26MAAAht0MCNVAAAMAAABt0g");
	var mask_1_graphics_266 = new cjs.Graphics().p("EhGkA26MAAAht0MCNIAAAMAAABt0g");
	var mask_1_graphics_267 = new cjs.Graphics().p("EhGeA26MAAAht0MCM9AAAMAAABt0g");
	var mask_1_graphics_268 = new cjs.Graphics().p("EhGYA26MAAAht0MCMxAAAMAAABt0g");
	var mask_1_graphics_269 = new cjs.Graphics().p("EhGRA26MAAAht0MCMjAAAMAAABt0g");
	var mask_1_graphics_270 = new cjs.Graphics().p("EhGMA26MAAAht0MCMZAAAMAAABt0g");
	var mask_1_graphics_271 = new cjs.Graphics().p("EhGGA26MAAAht0MCMNAAAMAAABt0g");
	var mask_1_graphics_272 = new cjs.Graphics().p("EhGAA26MAAAht0MCMBAAAMAAABt0g");
	var mask_1_graphics_273 = new cjs.Graphics().p("EhF6A26MAAAht0MCL1AAAMAAABt0g");
	var mask_1_graphics_274 = new cjs.Graphics().p("EhF0A26MAAAht0MCLpAAAMAAABt0g");
	var mask_1_graphics_275 = new cjs.Graphics().p("EhFuA26MAAAht0MCLdAAAMAAABt0g");
	var mask_1_graphics_276 = new cjs.Graphics().p("EhFoA26MAAAht0MCLRAAAMAAABt0g");
	var mask_1_graphics_277 = new cjs.Graphics().p("EhFiA26MAAAht0MCLFAAAMAAABt0g");
	var mask_1_graphics_278 = new cjs.Graphics().p("EhFcA26MAAAht0MCK5AAAMAAABt0g");
	var mask_1_graphics_279 = new cjs.Graphics().p("EhFWA26MAAAht0MCKtAAAMAAABt0g");
	var mask_1_graphics_280 = new cjs.Graphics().p("EhFQA26MAAAht0MCKhAAAMAAABt0g");
	var mask_1_graphics_281 = new cjs.Graphics().p("EhFKA26MAAAht0MCKVAAAMAAABt0g");
	var mask_1_graphics_282 = new cjs.Graphics().p("EhFEA26MAAAht0MCKJAAAMAAABt0g");
	var mask_1_graphics_283 = new cjs.Graphics().p("EhE+A26MAAAht0MCJ9AAAMAAABt0g");
	var mask_1_graphics_284 = new cjs.Graphics().p("EhE4A26MAAAht0MCJxAAAMAAABt0g");
	var mask_1_graphics_285 = new cjs.Graphics().p("EhEyA26MAAAht0MCJlAAAMAAABt0g");
	var mask_1_graphics_286 = new cjs.Graphics().p("EhEsA26MAAAht0MCJZAAAMAAABt0g");
	var mask_1_graphics_287 = new cjs.Graphics().p("EhEmA26MAAAht0MCJNAAAMAAABt0g");
	var mask_1_graphics_288 = new cjs.Graphics().p("EhEgA26MAAAht0MCJBAAAMAAABt0g");
	var mask_1_graphics_289 = new cjs.Graphics().p("EhEaA26MAAAht0MCI1AAAMAAABt0g");
	var mask_1_graphics_290 = new cjs.Graphics().p("EhEUA26MAAAht0MCIpAAAMAAABt0g");
	var mask_1_graphics_291 = new cjs.Graphics().p("EhEOA26MAAAht0MCIdAAAMAAABt0g");
	var mask_1_graphics_292 = new cjs.Graphics().p("EhEIA26MAAAht0MCIRAAAMAAABt0g");
	var mask_1_graphics_293 = new cjs.Graphics().p("EhECA26MAAAht0MCIFAAAMAAABt0g");
	var mask_1_graphics_294 = new cjs.Graphics().p("EhD8A26MAAAht0MCH5AAAMAAABt0g");
	var mask_1_graphics_295 = new cjs.Graphics().p("EhD3A26MAAAht0MCHuAAAMAAABt0g");
	var mask_1_graphics_296 = new cjs.Graphics().p("EhDwA26MAAAht0MCHhAAAMAAABt0g");
	var mask_1_graphics_297 = new cjs.Graphics().p("EhDrA26MAAAht0MCHXAAAMAAABt0g");
	var mask_1_graphics_298 = new cjs.Graphics().p("EhDlA26MAAAht0MCHLAAAMAAABt0g");
	var mask_1_graphics_299 = new cjs.Graphics().p("EhDeA26MAAAht0MCG9AAAMAAABt0g");
	var mask_1_graphics_300 = new cjs.Graphics().p("EhDZA26MAAAht0MCGyAAAMAAABt0g");
	var mask_1_graphics_301 = new cjs.Graphics().p("EhDSA26MAAAht0MCGlAAAMAAABt0g");
	var mask_1_graphics_302 = new cjs.Graphics().p("EhDNA26MAAAht0MCGaAAAMAAABt0g");
	var mask_1_graphics_303 = new cjs.Graphics().p("EhDGA26MAAAht0MCGNAAAMAAABt0g");
	var mask_1_graphics_304 = new cjs.Graphics().p("EhDAA26MAAAht0MCGBAAAMAAABt0g");
	var mask_1_graphics_305 = new cjs.Graphics().p("EhC7A26MAAAht0MCF3AAAMAAABt0g");
	var mask_1_graphics_306 = new cjs.Graphics().p("EhC0A26MAAAht0MCFqAAAMAAABt0g");
	var mask_1_graphics_307 = new cjs.Graphics().p("EhCvA26MAAAht0MCFfAAAMAAABt0g");
	var mask_1_graphics_308 = new cjs.Graphics().p("EhCpA26MAAAht0MCFTAAAMAAABt0g");
	var mask_1_graphics_309 = new cjs.Graphics().p("EhCjA26MAAAht0MCFHAAAMAAABt0g");
	var mask_1_graphics_310 = new cjs.Graphics().p("EhCdA26MAAAht0MCE7AAAMAAABt0g");
	var mask_1_graphics_311 = new cjs.Graphics().p("EhCXA26MAAAht0MCEvAAAMAAABt0g");
	var mask_1_graphics_312 = new cjs.Graphics().p("EhCRA26MAAAht0MCEjAAAMAAABt0g");
	var mask_1_graphics_313 = new cjs.Graphics().p("EhCLA26MAAAht0MCEXAAAMAAABt0g");
	var mask_1_graphics_314 = new cjs.Graphics().p("EhCFA26MAAAht0MCELAAAMAAABt0g");
	var mask_1_graphics_315 = new cjs.Graphics().p("EhB/A26MAAAht0MCD/AAAMAAABt0g");
	var mask_1_graphics_316 = new cjs.Graphics().p("EhB5A26MAAAht0MCDzAAAMAAABt0g");
	var mask_1_graphics_317 = new cjs.Graphics().p("EhBzA26MAAAht0MCDnAAAMAAABt0g");
	var mask_1_graphics_318 = new cjs.Graphics().p("EhBtA26MAAAht0MCDbAAAMAAABt0g");
	var mask_1_graphics_319 = new cjs.Graphics().p("EhBnA26MAAAht0MCDPAAAMAAABt0g");
	var mask_1_graphics_320 = new cjs.Graphics().p("EhBhA26MAAAht0MCDDAAAMAAABt0g");
	var mask_1_graphics_321 = new cjs.Graphics().p("EhBbA26MAAAht0MCC3AAAMAAABt0g");
	var mask_1_graphics_322 = new cjs.Graphics().p("EhBVA26MAAAht0MCCrAAAMAAABt0g");
	var mask_1_graphics_323 = new cjs.Graphics().p("EhBPA26MAAAht0MCCfAAAMAAABt0g");
	var mask_1_graphics_324 = new cjs.Graphics().p("EhBJA26MAAAht0MCCTAAAMAAABt0g");
	var mask_1_graphics_325 = new cjs.Graphics().p("EhBDA26MAAAht0MCCHAAAMAAABt0g");
	var mask_1_graphics_326 = new cjs.Graphics().p("EhA9A26MAAAht0MCB7AAAMAAABt0g");
	var mask_1_graphics_327 = new cjs.Graphics().p("EhA3A26MAAAht0MCBvAAAMAAABt0g");
	var mask_1_graphics_328 = new cjs.Graphics().p("EhAxA26MAAAht0MCBjAAAMAAABt0g");
	var mask_1_graphics_329 = new cjs.Graphics().p("EhArA26MAAAht0MCBXAAAMAAABt0g");
	var mask_1_graphics_330 = new cjs.Graphics().p("EhAlA26MAAAht0MCBLAAAMAAABt0g");
	var mask_1_graphics_331 = new cjs.Graphics().p("EhAfA26MAAAht0MCA/AAAMAAABt0g");
	var mask_1_graphics_332 = new cjs.Graphics().p("EhAZA26MAAAht0MCAzAAAMAAABt0g");
	var mask_1_graphics_333 = new cjs.Graphics().p("EhATA26MAAAht0MCAnAAAMAAABt0g");
	var mask_1_graphics_334 = new cjs.Graphics().p("EhANA26MAAAht0MCAbAAAMAAABt0g");
	var mask_1_graphics_335 = new cjs.Graphics().p("EhAHA26MAAAht0MCAPAAAMAAABt0g");
	var mask_1_graphics_336 = new cjs.Graphics().p("EhABA26MAAAht0MCADAAAMAAABt0g");
	var mask_1_graphics_337 = new cjs.Graphics().p("Eg/7A26MAAAht0MB/3AAAMAAABt0g");
	var mask_1_graphics_338 = new cjs.Graphics().p("Eg/1A26MAAAht0MB/rAAAMAAABt0g");
	var mask_1_graphics_339 = new cjs.Graphics().p("Eg/vA26MAAAht0MB/fAAAMAAABt0g");
	var mask_1_graphics_340 = new cjs.Graphics().p("Eg/pA26MAAAht0MB/TAAAMAAABt0g");
	var mask_1_graphics_341 = new cjs.Graphics().p("Eg/jA26MAAAht0MB/HAAAMAAABt0g");
	var mask_1_graphics_342 = new cjs.Graphics().p("Eg/dA26MAAAht0MB+8AAAMAAABt0g");
	var mask_1_graphics_343 = new cjs.Graphics().p("Eg/YA26MAAAht0MB+xAAAMAAABt0g");
	var mask_1_graphics_344 = new cjs.Graphics().p("Eg/RA26MAAAht0MB+jAAAMAAABt0g");
	var mask_1_graphics_345 = new cjs.Graphics().p("Eg/MA26MAAAht0MB+YAAAMAAABt0g");
	var mask_1_graphics_346 = new cjs.Graphics().p("Eg/GA26MAAAht0MB+MAAAMAAABt0g");
	var mask_1_graphics_347 = new cjs.Graphics().p("Eg/AA26MAAAht0MB+AAAAMAAABt0g");
	var mask_1_graphics_348 = new cjs.Graphics().p("Eg+6A26MAAAht0MB90AAAMAAABt0g");
	var mask_1_graphics_349 = new cjs.Graphics().p("Eg+zA26MAAAht0MB9nAAAMAAABt0g");
	var mask_1_graphics_350 = new cjs.Graphics().p("Eg+uA26MAAAht0MB9dAAAMAAABt0g");
	var mask_1_graphics_351 = new cjs.Graphics().p("Eg+nA26MAAAht0MB9PAAAMAAABt0g");
	var mask_1_graphics_352 = new cjs.Graphics().p("Eg+iA26MAAAht0MB9FAAAMAAABt0g");
	var mask_1_graphics_353 = new cjs.Graphics().p("Eg+cA26MAAAht0MB85AAAMAAABt0g");
	var mask_1_graphics_354 = new cjs.Graphics().p("Eg+VA26MAAAht0MB8sAAAMAAABt0g");
	var mask_1_graphics_355 = new cjs.Graphics().p("Eg+QA26MAAAht0MB8hAAAMAAABt0g");
	var mask_1_graphics_356 = new cjs.Graphics().p("Eg+KA26MAAAht0MB8VAAAMAAABt0g");
	var mask_1_graphics_357 = new cjs.Graphics().p("Eg+EA26MAAAht0MB8JAAAMAAABt0g");
	var mask_1_graphics_358 = new cjs.Graphics().p("Eg9+A26MAAAht0MB79AAAMAAABt0g");
	var mask_1_graphics_359 = new cjs.Graphics().p("Eg94A26MAAAht0MB7xAAAMAAABt0g");
	var mask_1_graphics_360 = new cjs.Graphics().p("Eg9yA26MAAAht0MB7lAAAMAAABt0g");
	var mask_1_graphics_361 = new cjs.Graphics().p("Eg9sA26MAAAht0MB7ZAAAMAAABt0g");
	var mask_1_graphics_362 = new cjs.Graphics().p("Eg9mA26MAAAht0MB7NAAAMAAABt0g");
	var mask_1_graphics_363 = new cjs.Graphics().p("Eg9gA26MAAAht0MB7BAAAMAAABt0g");
	var mask_1_graphics_364 = new cjs.Graphics().p("Eg9aA26MAAAht0MB61AAAMAAABt0g");
	var mask_1_graphics_365 = new cjs.Graphics().p("Eg9UA26MAAAht0MB6pAAAMAAABt0g");
	var mask_1_graphics_366 = new cjs.Graphics().p("Eg9OA26MAAAht0MB6dAAAMAAABt0g");
	var mask_1_graphics_367 = new cjs.Graphics().p("Eg9IA26MAAAht0MB6RAAAMAAABt0g");
	var mask_1_graphics_368 = new cjs.Graphics().p("Eg9CA26MAAAht0MB6FAAAMAAABt0g");
	var mask_1_graphics_369 = new cjs.Graphics().p("Eg88A26MAAAht0MB55AAAMAAABt0g");
	var mask_1_graphics_370 = new cjs.Graphics().p("Eg82A26MAAAht0MB5tAAAMAAABt0g");
	var mask_1_graphics_371 = new cjs.Graphics().p("Eg8wA26MAAAht0MB5hAAAMAAABt0g");
	var mask_1_graphics_372 = new cjs.Graphics().p("Eg8qA26MAAAht0MB5VAAAMAAABt0g");
	var mask_1_graphics_373 = new cjs.Graphics().p("Eg8kA26MAAAht0MB5JAAAMAAABt0g");
	var mask_1_graphics_374 = new cjs.Graphics().p("Eg8eA26MAAAht0MB49AAAMAAABt0g");
	var mask_1_graphics_375 = new cjs.Graphics().p("Eg8YA26MAAAht0MB4xAAAMAAABt0g");
	var mask_1_graphics_376 = new cjs.Graphics().p("Eg8SA26MAAAht0MB4lAAAMAAABt0g");
	var mask_1_graphics_377 = new cjs.Graphics().p("Eg8MA26MAAAht0MB4ZAAAMAAABt0g");
	var mask_1_graphics_378 = new cjs.Graphics().p("Eg8GA26MAAAht0MB4NAAAMAAABt0g");
	var mask_1_graphics_379 = new cjs.Graphics().p("Eg8AA26MAAAht0MB4BAAAMAAABt0g");
	var mask_1_graphics_380 = new cjs.Graphics().p("Eg76A26MAAAht0MB31AAAMAAABt0g");
	var mask_1_graphics_381 = new cjs.Graphics().p("Eg70A26MAAAht0MB3pAAAMAAABt0g");
	var mask_1_graphics_382 = new cjs.Graphics().p("Eg7uA26MAAAht0MB3dAAAMAAABt0g");
	var mask_1_graphics_383 = new cjs.Graphics().p("Eg7oA26MAAAht0MB3RAAAMAAABt0g");
	var mask_1_graphics_384 = new cjs.Graphics().p("Eg7iA26MAAAht0MB3FAAAMAAABt0g");
	var mask_1_graphics_385 = new cjs.Graphics().p("Eg7cA26MAAAht0MB25AAAMAAABt0g");
	var mask_1_graphics_386 = new cjs.Graphics().p("Eg7WA26MAAAht0MB2tAAAMAAABt0g");
	var mask_1_graphics_387 = new cjs.Graphics().p("Eg7QA26MAAAht0MB2iAAAMAAABt0g");
	var mask_1_graphics_388 = new cjs.Graphics().p("Eg7LA26MAAAht0MB2XAAAMAAABt0g");
	var mask_1_graphics_389 = new cjs.Graphics().p("Eg7EA26MAAAht0MB2JAAAMAAABt0g");
	var mask_1_graphics_390 = new cjs.Graphics().p("Eg6/A26MAAAht0MB1+AAAMAAABt0g");
	var mask_1_graphics_391 = new cjs.Graphics().p("Eg65A26MAAAht0MB1zAAAMAAABt0g");
	var mask_1_graphics_392 = new cjs.Graphics().p("Eg6zA26MAAAht0MB1mAAAMAAABt0g");
	var mask_1_graphics_393 = new cjs.Graphics().p("Eg6tA26MAAAht0MB1aAAAMAAABt0g");
	var mask_1_graphics_394 = new cjs.Graphics().p("Eg6nA26MAAAht0MB1OAAAMAAABt0g");
	var mask_1_graphics_395 = new cjs.Graphics().p("Eg6hA26MAAAht0MB1DAAAMAAABt0g");
	var mask_1_graphics_396 = new cjs.Graphics().p("Eg6bA26MAAAht0MB02AAAMAAABt0g");
	var mask_1_graphics_397 = new cjs.Graphics().p("Eg6VA26MAAAht0MB0rAAAMAAABt0g");
	var mask_1_graphics_398 = new cjs.Graphics().p("Eg6PA26MAAAht0MB0fAAAMAAABt0g");
	var mask_1_graphics_399 = new cjs.Graphics().p("Eg6IA26MAAAht0MB0SAAAMAAABt0g");
	var mask_1_graphics_400 = new cjs.Graphics().p("Eg6DA26MAAAht0MB0HAAAMAAABt0g");
	var mask_1_graphics_401 = new cjs.Graphics().p("Eg59A26MAAAht0MBz7AAAMAAABt0g");
	var mask_1_graphics_402 = new cjs.Graphics().p("Eg53A26MAAAht0MBzvAAAMAAABt0g");
	var mask_1_graphics_403 = new cjs.Graphics().p("Eg5xA26MAAAht0MBzjAAAMAAABt0g");
	var mask_1_graphics_404 = new cjs.Graphics().p("Eg5rA26MAAAht0MBzXAAAMAAABt0g");
	var mask_1_graphics_405 = new cjs.Graphics().p("Eg5lA26MAAAht0MBzLAAAMAAABt0g");
	var mask_1_graphics_406 = new cjs.Graphics().p("Eg5fA26MAAAht0MBy/AAAMAAABt0g");
	var mask_1_graphics_407 = new cjs.Graphics().p("Eg5ZA26MAAAht0MByzAAAMAAABt0g");
	var mask_1_graphics_408 = new cjs.Graphics().p("Eg5TA26MAAAht0MBynAAAMAAABt0g");
	var mask_1_graphics_409 = new cjs.Graphics().p("Eg5NA26MAAAht0MBybAAAMAAABt0g");
	var mask_1_graphics_410 = new cjs.Graphics().p("Eg5HA26MAAAht0MByPAAAMAAABt0g");
	var mask_1_graphics_411 = new cjs.Graphics().p("Eg5BA26MAAAht0MByDAAAMAAABt0g");
	var mask_1_graphics_412 = new cjs.Graphics().p("Eg47A26MAAAht0MBx3AAAMAAABt0g");
	var mask_1_graphics_413 = new cjs.Graphics().p("Eg41A26MAAAht0MBxrAAAMAAABt0g");
	var mask_1_graphics_414 = new cjs.Graphics().p("Eg4vA26MAAAht0MBxfAAAMAAABt0g");
	var mask_1_graphics_415 = new cjs.Graphics().p("Eg4pA26MAAAht0MBxTAAAMAAABt0g");
	var mask_1_graphics_416 = new cjs.Graphics().p("Eg4jA26MAAAht0MBxHAAAMAAABt0g");
	var mask_1_graphics_417 = new cjs.Graphics().p("Eg4dA26MAAAht0MBw7AAAMAAABt0g");
	var mask_1_graphics_418 = new cjs.Graphics().p("Eg4XA26MAAAht0MBwvAAAMAAABt0g");
	var mask_1_graphics_419 = new cjs.Graphics().p("Eg4RA26MAAAht0MBwjAAAMAAABt0g");
	var mask_1_graphics_420 = new cjs.Graphics().p("Eg4LA26MAAAht0MBwXAAAMAAABt0g");
	var mask_1_graphics_421 = new cjs.Graphics().p("Eg4FA26MAAAht0MBwLAAAMAAABt0g");
	var mask_1_graphics_422 = new cjs.Graphics().p("Eg3/A26MAAAht0MBv/AAAMAAABt0g");
	var mask_1_graphics_423 = new cjs.Graphics().p("Eg35A26MAAAht0MBvzAAAMAAABt0g");
	var mask_1_graphics_424 = new cjs.Graphics().p("Eg3zA26MAAAht0MBvnAAAMAAABt0g");
	var mask_1_graphics_425 = new cjs.Graphics().p("Eg3tA26MAAAht0MBvbAAAMAAABt0g");
	var mask_1_graphics_426 = new cjs.Graphics().p("Eg3nA26MAAAht0MBvPAAAMAAABt0g");
	var mask_1_graphics_427 = new cjs.Graphics().p("Eg3hA26MAAAht0MBvDAAAMAAABt0g");
	var mask_1_graphics_428 = new cjs.Graphics().p("Eg3bA26MAAAht0MBu3AAAMAAABt0g");
	var mask_1_graphics_429 = new cjs.Graphics().p("Eg3VA26MAAAht0MBurAAAMAAABt0g");
	var mask_1_graphics_430 = new cjs.Graphics().p("Eg3PA26MAAAht0MBufAAAMAAABt0g");
	var mask_1_graphics_431 = new cjs.Graphics().p("Eg3JA26MAAAht0MBuTAAAMAAABt0g");
	var mask_1_graphics_432 = new cjs.Graphics().p("Eg3DA26MAAAht0MBuIAAAMAAABt0g");
	var mask_1_graphics_433 = new cjs.Graphics().p("Eg29A26MAAAht0MBt8AAAMAAABt0g");
	var mask_1_graphics_434 = new cjs.Graphics().p("Eg23A26MAAAht0MBtvAAAMAAABt0g");
	var mask_1_graphics_435 = new cjs.Graphics().p("Eg2xA26MAAAht0MBtjAAAMAAABt0g");
	var mask_1_graphics_436 = new cjs.Graphics().p("Eg2rA26MAAAht0MBtYAAAMAAABt0g");
	var mask_1_graphics_437 = new cjs.Graphics().p("Eg2lA26MAAAht0MBtLAAAMAAABt0g");
	var mask_1_graphics_438 = new cjs.Graphics().p("Eg2fA26MAAAht0MBs/AAAMAAABt0g");
	var mask_1_graphics_439 = new cjs.Graphics().p("Eg2aA26MAAAht0MBs0AAAMAAABt0g");
	var mask_1_graphics_440 = new cjs.Graphics().p("Eg2TA26MAAAht0MBsoAAAMAAABt0g");
	var mask_1_graphics_441 = new cjs.Graphics().p("Eg2OA26MAAAht0MBsdAAAMAAABt0g");
	var mask_1_graphics_442 = new cjs.Graphics().p("Eg2IA26MAAAht0MBsRAAAMAAABt0g");
	var mask_1_graphics_443 = new cjs.Graphics().p("Eg2CA26MAAAht0MBsFAAAMAAABt0g");
	var mask_1_graphics_444 = new cjs.Graphics().p("Eg18A26MAAAht0MBr5AAAMAAABt0g");
	var mask_1_graphics_445 = new cjs.Graphics().p("Eg12A26MAAAht0MBrtAAAMAAABt0g");
	var mask_1_graphics_446 = new cjs.Graphics().p("Eg1wA26MAAAht0MBrhAAAMAAABt0g");
	var mask_1_graphics_447 = new cjs.Graphics().p("Eg1qA26MAAAht0MBrVAAAMAAABt0g");
	var mask_1_graphics_448 = new cjs.Graphics().p("Eg1kA26MAAAht0MBrJAAAMAAABt0g");
	var mask_1_graphics_449 = new cjs.Graphics().p("Eg1eA26MAAAht0MBq9AAAMAAABt0g");
	var mask_1_graphics_450 = new cjs.Graphics().p("Eg1YA26MAAAht0MBqxAAAMAAABt0g");
	var mask_1_graphics_451 = new cjs.Graphics().p("Eg1SA26MAAAht0MBqlAAAMAAABt0g");
	var mask_1_graphics_452 = new cjs.Graphics().p("Eg1MA26MAAAht0MBqZAAAMAAABt0g");
	var mask_1_graphics_453 = new cjs.Graphics().p("Eg1GA26MAAAht0MBqNAAAMAAABt0g");
	var mask_1_graphics_454 = new cjs.Graphics().p("Eg1AA26MAAAht0MBqBAAAMAAABt0g");
	var mask_1_graphics_455 = new cjs.Graphics().p("Eg06A26MAAAht0MBp1AAAMAAABt0g");
	var mask_1_graphics_456 = new cjs.Graphics().p("Eg00A26MAAAht0MBppAAAMAAABt0g");
	var mask_1_graphics_457 = new cjs.Graphics().p("Eg0uA26MAAAht0MBpdAAAMAAABt0g");
	var mask_1_graphics_458 = new cjs.Graphics().p("Eg0oA26MAAAht0MBpRAAAMAAABt0g");
	var mask_1_graphics_459 = new cjs.Graphics().p("Eg0iA26MAAAht0MBpFAAAMAAABt0g");
	var mask_1_graphics_460 = new cjs.Graphics().p("Eg0cA26MAAAht0MBo5AAAMAAABt0g");
	var mask_1_graphics_461 = new cjs.Graphics().p("Eg0WA26MAAAht0MBotAAAMAAABt0g");
	var mask_1_graphics_462 = new cjs.Graphics().p("Eg0QA26MAAAht0MBohAAAMAAABt0g");
	var mask_1_graphics_463 = new cjs.Graphics().p("Eg0KA26MAAAht0MBoVAAAMAAABt0g");
	var mask_1_graphics_464 = new cjs.Graphics().p("Eg0EA26MAAAht0MBoJAAAMAAABt0g");
	var mask_1_graphics_465 = new cjs.Graphics().p("Egz+A26MAAAht0MBn9AAAMAAABt0g");
	var mask_1_graphics_466 = new cjs.Graphics().p("Egz4A26MAAAht0MBnxAAAMAAABt0g");
	var mask_1_graphics_467 = new cjs.Graphics().p("EgzyA26MAAAht0MBnlAAAMAAABt0g");
	var mask_1_graphics_468 = new cjs.Graphics().p("EgzsA26MAAAht0MBnZAAAMAAABt0g");
	var mask_1_graphics_469 = new cjs.Graphics().p("EgzmA26MAAAht0MBnNAAAMAAABt0g");
	var mask_1_graphics_470 = new cjs.Graphics().p("EgzgA26MAAAht0MBnBAAAMAAABt0g");
	var mask_1_graphics_471 = new cjs.Graphics().p("EgzaA26MAAAht0MBm1AAAMAAABt0g");
	var mask_1_graphics_472 = new cjs.Graphics().p("EgzVA26MAAAht0MBmqAAAMAAABt0g");
	var mask_1_graphics_473 = new cjs.Graphics().p("EgzOA26MAAAht0MBmdAAAMAAABt0g");
	var mask_1_graphics_474 = new cjs.Graphics().p("EgzIA26MAAAht0MBmRAAAMAAABt0g");
	var mask_1_graphics_475 = new cjs.Graphics().p("EgzDA26MAAAht0MBmHAAAMAAABt0g");
	var mask_1_graphics_476 = new cjs.Graphics().p("Egy8A26MAAAht0MBl5AAAMAAABt0g");
	var mask_1_graphics_477 = new cjs.Graphics().p("Egy3A26MAAAht0MBlvAAAMAAABt0g");
	var mask_1_graphics_478 = new cjs.Graphics().p("EgywA26MAAAht0MBliAAAMAAABt0g");
	var mask_1_graphics_479 = new cjs.Graphics().p("EgyqA26MAAAht0MBlVAAAMAAABt0g");
	var mask_1_graphics_480 = new cjs.Graphics().p("EgykA26MAAAht0MBlJAAAMAAABt0g");
	var mask_1_graphics_481 = new cjs.Graphics().p("EgyeA26MAAAht0MBk9AAAMAAABt0g");
	var mask_1_graphics_482 = new cjs.Graphics().p("EgyYA26MAAAht0MBkxAAAMAAABt0g");
	var mask_1_graphics_483 = new cjs.Graphics().p("EgySA26MAAAht0MBklAAAMAAABt0g");
	var mask_1_graphics_484 = new cjs.Graphics().p("EgyNA26MAAAht0MBkaAAAMAAABt0g");
	var mask_1_graphics_485 = new cjs.Graphics().p("EgyGA26MAAAht0MBkOAAAMAAABt0g");
	var mask_1_graphics_486 = new cjs.Graphics().p("EgyBA26MAAAht0MBkDAAAMAAABt0g");
	var mask_1_graphics_487 = new cjs.Graphics().p("Egx7A26MAAAht0MBj3AAAMAAABt0g");
	var mask_1_graphics_488 = new cjs.Graphics().p("Egx1A26MAAAht0MBjrAAAMAAABt0g");
	var mask_1_graphics_489 = new cjs.Graphics().p("EgxvA26MAAAht0MBjfAAAMAAABt0g");
	var mask_1_graphics_490 = new cjs.Graphics().p("EgxpA26MAAAht0MBjTAAAMAAABt0g");
	var mask_1_graphics_491 = new cjs.Graphics().p("EgxjA26MAAAht0MBjHAAAMAAABt0g");
	var mask_1_graphics_492 = new cjs.Graphics().p("EgxdA26MAAAht0MBi7AAAMAAABt0g");
	var mask_1_graphics_493 = new cjs.Graphics().p("EgxXA26MAAAht0MBivAAAMAAABt0g");
	var mask_1_graphics_494 = new cjs.Graphics().p("EgxRA26MAAAht0MBijAAAMAAABt0g");
	var mask_1_graphics_495 = new cjs.Graphics().p("EgxLA26MAAAht0MBiXAAAMAAABt0g");
	var mask_1_graphics_496 = new cjs.Graphics().p("EgxFA26MAAAht0MBiLAAAMAAABt0g");
	var mask_1_graphics_497 = new cjs.Graphics().p("Egw/A26MAAAht0MBh/AAAMAAABt0g");
	var mask_1_graphics_498 = new cjs.Graphics().p("Egw5A26MAAAht0MBhzAAAMAAABt0g");
	var mask_1_graphics_499 = new cjs.Graphics().p("EgwzA26MAAAht0MBhnAAAMAAABt0g");
	var mask_1_graphics_500 = new cjs.Graphics().p("EgwtA26MAAAht0MBhbAAAMAAABt0g");
	var mask_1_graphics_501 = new cjs.Graphics().p("EgwnA26MAAAht0MBhPAAAMAAABt0g");
	var mask_1_graphics_502 = new cjs.Graphics().p("EgwhA26MAAAht0MBhDAAAMAAABt0g");
	var mask_1_graphics_503 = new cjs.Graphics().p("EgwbA26MAAAht0MBg3AAAMAAABt0g");
	var mask_1_graphics_504 = new cjs.Graphics().p("EgwVA26MAAAht0MBgrAAAMAAABt0g");
	var mask_1_graphics_505 = new cjs.Graphics().p("EgwPA26MAAAht0MBgfAAAMAAABt0g");
	var mask_1_graphics_506 = new cjs.Graphics().p("EgwJA26MAAAht0MBgTAAAMAAABt0g");
	var mask_1_graphics_507 = new cjs.Graphics().p("EgwDA26MAAAht0MBgHAAAMAAABt0g");
	var mask_1_graphics_508 = new cjs.Graphics().p("Egv9A26MAAAht0MBf7AAAMAAABt0g");
	var mask_1_graphics_509 = new cjs.Graphics().p("Egv3A26MAAAht0MBfvAAAMAAABt0g");
	var mask_1_graphics_510 = new cjs.Graphics().p("EgvxA26MAAAht0MBfjAAAMAAABt0g");
	var mask_1_graphics_511 = new cjs.Graphics().p("EgvrA26MAAAht0MBfXAAAMAAABt0g");
	var mask_1_graphics_512 = new cjs.Graphics().p("EgvlA26MAAAht0MBfLAAAMAAABt0g");
	var mask_1_graphics_513 = new cjs.Graphics().p("EgvfA26MAAAht0MBe/AAAMAAABt0g");
	var mask_1_graphics_514 = new cjs.Graphics().p("EgvZA26MAAAht0MBezAAAMAAABt0g");
	var mask_1_graphics_515 = new cjs.Graphics().p("EgvTA26MAAAht0MBenAAAMAAABt0g");
	var mask_1_graphics_516 = new cjs.Graphics().p("EgvNA26MAAAht0MBebAAAMAAABt0g");
	var mask_1_graphics_517 = new cjs.Graphics().p("EgvHA26MAAAht0MBePAAAMAAABt0g");
	var mask_1_graphics_518 = new cjs.Graphics().p("EgvBA26MAAAht0MBeDAAAMAAABt0g");
	var mask_1_graphics_519 = new cjs.Graphics().p("Egu7A26MAAAht0MBd3AAAMAAABt0g");
	var mask_1_graphics_520 = new cjs.Graphics().p("Egu2A26MAAAht0MBdsAAAMAAABt0g");
	var mask_1_graphics_521 = new cjs.Graphics().p("EguvA26MAAAht0MBdfAAAMAAABt0g");
	var mask_1_graphics_522 = new cjs.Graphics().p("EgupA26MAAAht0MBdTAAAMAAABt0g");
	var mask_1_graphics_523 = new cjs.Graphics().p("EgukA26MAAAht0MBdJAAAMAAABt0g");
	var mask_1_graphics_524 = new cjs.Graphics().p("EgudA26MAAAht0MBc7AAAMAAABt0g");
	var mask_1_graphics_525 = new cjs.Graphics().p("EguYA26MAAAht0MBcwAAAMAAABt0g");
	var mask_1_graphics_526 = new cjs.Graphics().p("EguRA26MAAAht0MBcjAAAMAAABt0g");
	var mask_1_graphics_527 = new cjs.Graphics().p("EguLA26MAAAht0MBcXAAAMAAABt0g");
	var mask_1_graphics_528 = new cjs.Graphics().p("EguFA26MAAAht0MBcLAAAMAAABt0g");
	var mask_1_graphics_529 = new cjs.Graphics().p("Egt/A26MAAAht0MBb/AAAMAAABt0g");
	var mask_1_graphics_530 = new cjs.Graphics().p("Egt5A26MAAAht0MBb0AAAMAAABt0g");
	var mask_1_graphics_531 = new cjs.Graphics().p("EgtzA26MAAAht0MBboAAAMAAABt0g");
	var mask_1_graphics_532 = new cjs.Graphics().p("EgtuA26MAAAht0MBbcAAAMAAABt0g");
	var mask_1_graphics_533 = new cjs.Graphics().p("EgtnA26MAAAht0MBbQAAAMAAABt0g");
	var mask_1_graphics_534 = new cjs.Graphics().p("EgtiA26MAAAht0MBbFAAAMAAABt0g");
	var mask_1_graphics_535 = new cjs.Graphics().p("EgtcA26MAAAht0MBa5AAAMAAABt0g");
	var mask_1_graphics_536 = new cjs.Graphics().p("EgtWA26MAAAht0MBatAAAMAAABt0g");
	var mask_1_graphics_537 = new cjs.Graphics().p("EgtQA26MAAAht0MBagAAAMAAABt0g");
	var mask_1_graphics_538 = new cjs.Graphics().p("EgtKA26MAAAht0MBaVAAAMAAABt0g");
	var mask_1_graphics_539 = new cjs.Graphics().p("EgtEA26MAAAht0MBaJAAAMAAABt0g");
	var mask_1_graphics_540 = new cjs.Graphics().p("Egs+A26MAAAht0MBZ9AAAMAAABt0g");
	var mask_1_graphics_541 = new cjs.Graphics().p("Egs4A26MAAAht0MBZxAAAMAAABt0g");
	var mask_1_graphics_542 = new cjs.Graphics().p("EgsyA26MAAAht0MBZlAAAMAAABt0g");
	var mask_1_graphics_543 = new cjs.Graphics().p("EgssA26MAAAht0MBZZAAAMAAABt0g");
	var mask_1_graphics_544 = new cjs.Graphics().p("EgsmA26MAAAht0MBZNAAAMAAABt0g");
	var mask_1_graphics_545 = new cjs.Graphics().p("EgsgA26MAAAht0MBZBAAAMAAABt0g");
	var mask_1_graphics_546 = new cjs.Graphics().p("EgsaA26MAAAht0MBY1AAAMAAABt0g");
	var mask_1_graphics_547 = new cjs.Graphics().p("EgsUA26MAAAht0MBYpAAAMAAABt0g");
	var mask_1_graphics_548 = new cjs.Graphics().p("EgsOA26MAAAht0MBYdAAAMAAABt0g");
	var mask_1_graphics_549 = new cjs.Graphics().p("EgsIA26MAAAht0MBYRAAAMAAABt0g");
	var mask_1_graphics_550 = new cjs.Graphics().p("EgsCA26MAAAht0MBYFAAAMAAABt0g");
	var mask_1_graphics_551 = new cjs.Graphics().p("Egr8A26MAAAht0MBX5AAAMAAABt0g");
	var mask_1_graphics_552 = new cjs.Graphics().p("Egr2A26MAAAht0MBXtAAAMAAABt0g");
	var mask_1_graphics_553 = new cjs.Graphics().p("EgrwA26MAAAht0MBXhAAAMAAABt0g");
	var mask_1_graphics_554 = new cjs.Graphics().p("EgrqA26MAAAht0MBXVAAAMAAABt0g");
	var mask_1_graphics_555 = new cjs.Graphics().p("EgrkA26MAAAht0MBXJAAAMAAABt0g");
	var mask_1_graphics_556 = new cjs.Graphics().p("EgreA26MAAAht0MBW9AAAMAAABt0g");
	var mask_1_graphics_557 = new cjs.Graphics().p("EgrYA26MAAAht0MBWxAAAMAAABt0g");
	var mask_1_graphics_558 = new cjs.Graphics().p("EgrSA26MAAAht0MBWlAAAMAAABt0g");
	var mask_1_graphics_559 = new cjs.Graphics().p("EgrMA26MAAAht0MBWZAAAMAAABt0g");
	var mask_1_graphics_560 = new cjs.Graphics().p("EgrGA26MAAAht0MBWNAAAMAAABt0g");
	var mask_1_graphics_561 = new cjs.Graphics().p("EgrAA26MAAAht0MBWBAAAMAAABt0g");
	var mask_1_graphics_562 = new cjs.Graphics().p("Egq6A26MAAAht0MBV1AAAMAAABt0g");
	var mask_1_graphics_563 = new cjs.Graphics().p("Egq0A26MAAAht0MBVpAAAMAAABt0g");
	var mask_1_graphics_564 = new cjs.Graphics().p("EgquA26MAAAht0MBVdAAAMAAABt0g");
	var mask_1_graphics_565 = new cjs.Graphics().p("EgqoA26MAAAht0MBVRAAAMAAABt0g");
	var mask_1_graphics_566 = new cjs.Graphics().p("EgqiA26MAAAht0MBVFAAAMAAABt0g");
	var mask_1_graphics_567 = new cjs.Graphics().p("EgqcA26MAAAht0MBU5AAAMAAABt0g");
	var mask_1_graphics_568 = new cjs.Graphics().p("EgqXA26MAAAht0MBUvAAAMAAABt0g");
	var mask_1_graphics_569 = new cjs.Graphics().p("EgqRA26MAAAht0MBUjAAAMAAABt0g");
	var mask_1_graphics_570 = new cjs.Graphics().p("EgqLA26MAAAht0MBUWAAAMAAABt0g");
	var mask_1_graphics_571 = new cjs.Graphics().p("EgqFA26MAAAht0MBUKAAAMAAABt0g");
	var mask_1_graphics_572 = new cjs.Graphics().p("Egp+A26MAAAht0MBT+AAAMAAABt0g");
	var mask_1_graphics_573 = new cjs.Graphics().p("Egp5A26MAAAht0MBTyAAAMAAABt0g");
	var mask_1_graphics_574 = new cjs.Graphics().p("EgpyA26MAAAht0MBTlAAAMAAABt0g");
	var mask_1_graphics_575 = new cjs.Graphics().p("EgptA26MAAAht0MBTbAAAMAAABt0g");
	var mask_1_graphics_576 = new cjs.Graphics().p("EgpmA26MAAAht0MBTNAAAMAAABt0g");
	var mask_1_graphics_577 = new cjs.Graphics().p("EgpgA26MAAAht0MBTBAAAMAAABt0g");
	var mask_1_graphics_578 = new cjs.Graphics().p("EgpbA26MAAAht0MBS3AAAMAAABt0g");
	var mask_1_graphics_579 = new cjs.Graphics().p("EgpUA26MAAAht0MBSqAAAMAAABt0g");
	var mask_1_graphics_580 = new cjs.Graphics().p("EgpPA26MAAAht0MBSfAAAMAAABt0g");
	var mask_1_graphics_581 = new cjs.Graphics().p("EgpJA26MAAAht0MBSTAAAMAAABt0g");
	var mask_1_graphics_582 = new cjs.Graphics().p("EgpDA26MAAAht0MBSGAAAMAAABt0g");
	var mask_1_graphics_583 = new cjs.Graphics().p("Ego9A26MAAAht0MBR7AAAMAAABt0g");
	var mask_1_graphics_584 = new cjs.Graphics().p("Ego3A26MAAAht0MBRvAAAMAAABt0g");
	var mask_1_graphics_585 = new cjs.Graphics().p("EgoxA26MAAAht0MBRjAAAMAAABt0g");
	var mask_1_graphics_586 = new cjs.Graphics().p("EgorA26MAAAht0MBRXAAAMAAABt0g");
	var mask_1_graphics_587 = new cjs.Graphics().p("EgolA26MAAAht0MBRLAAAMAAABt0g");
	var mask_1_graphics_588 = new cjs.Graphics().p("EgofA26MAAAht0MBQ/AAAMAAABt0g");
	var mask_1_graphics_589 = new cjs.Graphics().p("EgoZA26MAAAht0MBQzAAAMAAABt0g");
	var mask_1_graphics_590 = new cjs.Graphics().p("EgoTA26MAAAht0MBQnAAAMAAABt0g");
	var mask_1_graphics_591 = new cjs.Graphics().p("EgoNA26MAAAht0MBQbAAAMAAABt0g");
	var mask_1_graphics_592 = new cjs.Graphics().p("EgoHA26MAAAht0MBQPAAAMAAABt0g");
	var mask_1_graphics_593 = new cjs.Graphics().p("EgoBA26MAAAht0MBQDAAAMAAABt0g");
	var mask_1_graphics_594 = new cjs.Graphics().p("Egn7A26MAAAht0MBP3AAAMAAABt0g");
	var mask_1_graphics_595 = new cjs.Graphics().p("Egn1A26MAAAht0MBPrAAAMAAABt0g");
	var mask_1_graphics_596 = new cjs.Graphics().p("EgnvA26MAAAht0MBPfAAAMAAABt0g");
	var mask_1_graphics_597 = new cjs.Graphics().p("EgnpA26MAAAht0MBPTAAAMAAABt0g");
	var mask_1_graphics_598 = new cjs.Graphics().p("EgnjA26MAAAht0MBPHAAAMAAABt0g");
	var mask_1_graphics_599 = new cjs.Graphics().p("EgndA26MAAAht0MBO7AAAMAAABt0g");
	var mask_1_graphics_600 = new cjs.Graphics().p("EgnXA26MAAAht0MBOvAAAMAAABt0g");
	var mask_1_graphics_601 = new cjs.Graphics().p("EgnRA26MAAAht0MBOjAAAMAAABt0g");
	var mask_1_graphics_602 = new cjs.Graphics().p("EgnLA26MAAAht0MBOXAAAMAAABt0g");
	var mask_1_graphics_603 = new cjs.Graphics().p("EgnFA26MAAAht0MBOLAAAMAAABt0g");
	var mask_1_graphics_604 = new cjs.Graphics().p("Egm/A26MAAAht0MBN/AAAMAAABt0g");
	var mask_1_graphics_605 = new cjs.Graphics().p("Egm5A26MAAAht0MBNzAAAMAAABt0g");
	var mask_1_graphics_606 = new cjs.Graphics().p("EgmzA26MAAAht0MBNnAAAMAAABt0g");
	var mask_1_graphics_607 = new cjs.Graphics().p("EgmtA26MAAAht0MBNbAAAMAAABt0g");
	var mask_1_graphics_608 = new cjs.Graphics().p("EgmnA26MAAAht0MBNPAAAMAAABt0g");
	var mask_1_graphics_609 = new cjs.Graphics().p("EgmhA26MAAAht0MBNDAAAMAAABt0g");
	var mask_1_graphics_610 = new cjs.Graphics().p("EgmbA26MAAAht0MBM4AAAMAAABt0g");
	var mask_1_graphics_611 = new cjs.Graphics().p("EgmVA26MAAAht0MBMrAAAMAAABt0g");
	var mask_1_graphics_612 = new cjs.Graphics().p("EgmPA26MAAAht0MBMfAAAMAAABt0g");
	var mask_1_graphics_613 = new cjs.Graphics().p("EgmJA26MAAAht0MBMUAAAMAAABt0g");
	var mask_1_graphics_614 = new cjs.Graphics().p("EgmEA26MAAAht0MBMJAAAMAAABt0g");
	var mask_1_graphics_615 = new cjs.Graphics().p("Egl9A26MAAAht0MBL7AAAMAAABt0g");
	var mask_1_graphics_616 = new cjs.Graphics().p("Egl4A26MAAAht0MBLxAAAMAAABt0g");
	var mask_1_graphics_617 = new cjs.Graphics().p("EglyA26MAAAht0MBLlAAAMAAABt0g");
	var mask_1_graphics_618 = new cjs.Graphics().p("EglsA26MAAAht0MBLYAAAMAAABt0g");
	var mask_1_graphics_619 = new cjs.Graphics().p("EglmA26MAAAht0MBLMAAAMAAABt0g");
	var mask_1_graphics_620 = new cjs.Graphics().p("EglgA26MAAAht0MBLBAAAMAAABt0g");
	var mask_1_graphics_621 = new cjs.Graphics().p("EglaA26MAAAht0MBK0AAAMAAABt0g");
	var mask_1_graphics_622 = new cjs.Graphics().p("EglTA26MAAAht0MBKnAAAMAAABt0g");
	var mask_1_graphics_623 = new cjs.Graphics().p("EglOA26MAAAht0MBKdAAAMAAABt0g");
	var mask_1_graphics_624 = new cjs.Graphics().p("EglIA26MAAAht0MBKRAAAMAAABt0g");
	var mask_1_graphics_625 = new cjs.Graphics().p("EglCA26MAAAht0MBKFAAAMAAABt0g");
	var mask_1_graphics_626 = new cjs.Graphics().p("Egk8A26MAAAht0MBJ5AAAMAAABt0g");
	var mask_1_graphics_627 = new cjs.Graphics().p("Egk2A26MAAAht0MBJtAAAMAAABt0g");
	var mask_1_graphics_628 = new cjs.Graphics().p("EgkwA26MAAAht0MBJhAAAMAAABt0g");
	var mask_1_graphics_629 = new cjs.Graphics().p("EgkqA26MAAAht0MBJVAAAMAAABt0g");
	var mask_1_graphics_630 = new cjs.Graphics().p("EgkkA26MAAAht0MBJJAAAMAAABt0g");
	var mask_1_graphics_631 = new cjs.Graphics().p("EgkeA26MAAAht0MBI9AAAMAAABt0g");
	var mask_1_graphics_632 = new cjs.Graphics().p("EgkYA26MAAAht0MBIxAAAMAAABt0g");
	var mask_1_graphics_633 = new cjs.Graphics().p("EgkSA26MAAAht0MBIlAAAMAAABt0g");
	var mask_1_graphics_634 = new cjs.Graphics().p("EgkMA26MAAAht0MBIZAAAMAAABt0g");
	var mask_1_graphics_635 = new cjs.Graphics().p("EgkGA26MAAAht0MBINAAAMAAABt0g");
	var mask_1_graphics_636 = new cjs.Graphics().p("EgkAA26MAAAht0MBIBAAAMAAABt0g");
	var mask_1_graphics_637 = new cjs.Graphics().p("Egj6A26MAAAht0MBH1AAAMAAABt0g");
	var mask_1_graphics_638 = new cjs.Graphics().p("Egj0A26MAAAht0MBHpAAAMAAABt0g");
	var mask_1_graphics_639 = new cjs.Graphics().p("EgjuA26MAAAht0MBHdAAAMAAABt0g");
	var mask_1_graphics_640 = new cjs.Graphics().p("EgjoA26MAAAht0MBHRAAAMAAABt0g");
	var mask_1_graphics_641 = new cjs.Graphics().p("EgjiA26MAAAht0MBHFAAAMAAABt0g");
	var mask_1_graphics_642 = new cjs.Graphics().p("EgjcA26MAAAht0MBG5AAAMAAABt0g");
	var mask_1_graphics_643 = new cjs.Graphics().p("EgjWA26MAAAht0MBGtAAAMAAABt0g");
	var mask_1_graphics_644 = new cjs.Graphics().p("EgjQA26MAAAht0MBGhAAAMAAABt0g");
	var mask_1_graphics_645 = new cjs.Graphics().p("EgjKA26MAAAht0MBGVAAAMAAABt0g");
	var mask_1_graphics_646 = new cjs.Graphics().p("EgjEA26MAAAht0MBGJAAAMAAABt0g");
	var mask_1_graphics_647 = new cjs.Graphics().p("Egi+A26MAAAht0MBF9AAAMAAABt0g");
	var mask_1_graphics_648 = new cjs.Graphics().p("Egi4A26MAAAht0MBFxAAAMAAABt0g");
	var mask_1_graphics_649 = new cjs.Graphics().p("EgiyA26MAAAht0MBFlAAAMAAABt0g");
	var mask_1_graphics_650 = new cjs.Graphics().p("EgisA26MAAAht0MBFZAAAMAAABt0g");
	var mask_1_graphics_651 = new cjs.Graphics().p("EgimA26MAAAht0MBFNAAAMAAABt0g");
	var mask_1_graphics_652 = new cjs.Graphics().p("EgigA26MAAAht0MBFBAAAMAAABt0g");
	var mask_1_graphics_653 = new cjs.Graphics().p("EgiaA26MAAAht0MBE1AAAMAAABt0g");
	var mask_1_graphics_654 = new cjs.Graphics().p("EgiUA26MAAAht0MBEpAAAMAAABt0g");
	var mask_1_graphics_655 = new cjs.Graphics().p("EgiPA26MAAAht0MBEfAAAMAAABt0g");
	var mask_1_graphics_656 = new cjs.Graphics().p("EgiIA26MAAAht0MBERAAAMAAABt0g");
	var mask_1_graphics_657 = new cjs.Graphics().p("EgiCA26MAAAht0MBEFAAAMAAABt0g");
	var mask_1_graphics_658 = new cjs.Graphics().p("Egh8A26MAAAht0MBD6AAAMAAABt0g");
	var mask_1_graphics_659 = new cjs.Graphics().p("Egh2A26MAAAht0MBDuAAAMAAABt0g");
	var mask_1_graphics_660 = new cjs.Graphics().p("EghwA26MAAAht0MBDhAAAMAAABt0g");
	var mask_1_graphics_661 = new cjs.Graphics().p("EghqA26MAAAht0MBDWAAAMAAABt0g");
	var mask_1_graphics_662 = new cjs.Graphics().p("EghlA26MAAAht0MBDLAAAMAAABt0g");
	var mask_1_graphics_663 = new cjs.Graphics().p("EgheA26MAAAht0MBC9AAAMAAABt0g");
	var mask_1_graphics_664 = new cjs.Graphics().p("EghZA26MAAAht0MBCyAAAMAAABt0g");
	var mask_1_graphics_665 = new cjs.Graphics().p("EghTA26MAAAht0MBCnAAAMAAABt0g");
	var mask_1_graphics_666 = new cjs.Graphics().p("EghNA26MAAAht0MBCbAAAMAAABt0g");
	var mask_1_graphics_667 = new cjs.Graphics().p("EghHA26MAAAht0MBCOAAAMAAABt0g");
	var mask_1_graphics_668 = new cjs.Graphics().p("EghBA26MAAAht0MBCDAAAMAAABt0g");
	var mask_1_graphics_669 = new cjs.Graphics().p("Egg7A26MAAAht0MBB3AAAMAAABt0g");
	var mask_1_graphics_670 = new cjs.Graphics().p("Egg1A26MAAAht0MBBrAAAMAAABt0g");
	var mask_1_graphics_671 = new cjs.Graphics().p("EggvA26MAAAht0MBBfAAAMAAABt0g");
	var mask_1_graphics_672 = new cjs.Graphics().p("EggpA26MAAAht0MBBTAAAMAAABt0g");
	var mask_1_graphics_673 = new cjs.Graphics().p("EggjA26MAAAht0MBBHAAAMAAABt0g");
	var mask_1_graphics_674 = new cjs.Graphics().p("EggdA26MAAAht0MBA7AAAMAAABt0g");
	var mask_1_graphics_675 = new cjs.Graphics().p("EggXA26MAAAht0MBAvAAAMAAABt0g");
	var mask_1_graphics_676 = new cjs.Graphics().p("EggRA26MAAAht0MBAjAAAMAAABt0g");
	var mask_1_graphics_677 = new cjs.Graphics().p("EggLA26MAAAht0MBAXAAAMAAABt0g");
	var mask_1_graphics_678 = new cjs.Graphics().p("EggFA26MAAAht0MBALAAAMAAABt0g");
	var mask_1_graphics_679 = new cjs.Graphics().p("Egf/A26MAAAht0MA//AAAMAAABt0g");
	var mask_1_graphics_680 = new cjs.Graphics().p("Egf5A26MAAAht0MA/zAAAMAAABt0g");
	var mask_1_graphics_681 = new cjs.Graphics().p("EgfzA26MAAAht0MA/nAAAMAAABt0g");
	var mask_1_graphics_682 = new cjs.Graphics().p("EgftA26MAAAht0MA/bAAAMAAABt0g");
	var mask_1_graphics_683 = new cjs.Graphics().p("EgfnA26MAAAht0MA/PAAAMAAABt0g");
	var mask_1_graphics_684 = new cjs.Graphics().p("EgfhA26MAAAht0MA/DAAAMAAABt0g");
	var mask_1_graphics_685 = new cjs.Graphics().p("EgfbA26MAAAht0MA+3AAAMAAABt0g");
	var mask_1_graphics_686 = new cjs.Graphics().p("EgfVA26MAAAht0MA+rAAAMAAABt0g");
	var mask_1_graphics_687 = new cjs.Graphics().p("EgfPA26MAAAht0MA+fAAAMAAABt0g");
	var mask_1_graphics_688 = new cjs.Graphics().p("EgfJA26MAAAht0MA+TAAAMAAABt0g");
	var mask_1_graphics_689 = new cjs.Graphics().p("EgfDA26MAAAht0MA+HAAAMAAABt0g");
	var mask_1_graphics_690 = new cjs.Graphics().p("Ege9A26MAAAht0MA97AAAMAAABt0g");
	var mask_1_graphics_691 = new cjs.Graphics().p("Ege3A26MAAAht0MA9vAAAMAAABt0g");
	var mask_1_graphics_692 = new cjs.Graphics().p("EgexA26MAAAht0MA9jAAAMAAABt0g");
	var mask_1_graphics_693 = new cjs.Graphics().p("EgerA26MAAAht0MA9XAAAMAAABt0g");
	var mask_1_graphics_694 = new cjs.Graphics().p("EgelA26MAAAht0MA9LAAAMAAABt0g");
	var mask_1_graphics_695 = new cjs.Graphics().p("EgefA26MAAAht0MA8/AAAMAAABt0g");
	var mask_1_graphics_696 = new cjs.Graphics().p("EgeZA26MAAAht0MA8zAAAMAAABt0g");
	var mask_1_graphics_697 = new cjs.Graphics().p("EgeTA26MAAAht0MA8nAAAMAAABt0g");
	var mask_1_graphics_698 = new cjs.Graphics().p("EgeNA26MAAAht0MA8bAAAMAAABt0g");
	var mask_1_graphics_699 = new cjs.Graphics().p("EgeHA26MAAAht0MA8PAAAMAAABt0g");
	var mask_1_graphics_700 = new cjs.Graphics().p("EgeCA26MAAAht0MA8FAAAMAAABt0g");
	var mask_1_graphics_701 = new cjs.Graphics().p("Egd7A26MAAAht0MA73AAAMAAABt0g");
	var mask_1_graphics_702 = new cjs.Graphics().p("Egd1A26MAAAht0MA7rAAAMAAABt0g");
	var mask_1_graphics_703 = new cjs.Graphics().p("EgdwA26MAAAht0MA7hAAAMAAABt0g");
	var mask_1_graphics_704 = new cjs.Graphics().p("EgdpA26MAAAht0MA7TAAAMAAABt0g");
	var mask_1_graphics_705 = new cjs.Graphics().p("EgdkA26MAAAht0MA7IAAAMAAABt0g");
	var mask_1_graphics_706 = new cjs.Graphics().p("EgddA26MAAAht0MA67AAAMAAABt0g");
	var mask_1_graphics_707 = new cjs.Graphics().p("EgdXA26MAAAht0MA6wAAAMAAABt0g");
	var mask_1_graphics_708 = new cjs.Graphics().p("EgdRA26MAAAht0MA6jAAAMAAABt0g");
	var mask_1_graphics_709 = new cjs.Graphics().p("EgdLA26MAAAht0MA6XAAAMAAABt0g");
	var mask_1_graphics_710 = new cjs.Graphics().p("EgdGA26MAAAht0MA6NAAAMAAABt0g");
	var mask_1_graphics_711 = new cjs.Graphics().p("Egc/A26MAAAht0MA6AAAAMAAABt0g");
	var mask_1_graphics_712 = new cjs.Graphics().p("Egc6A26MAAAht0MA50AAAMAAABt0g");
	var mask_1_graphics_713 = new cjs.Graphics().p("Egc0A26MAAAht0MA5pAAAMAAABt0g");
	var mask_1_graphics_714 = new cjs.Graphics().p("EgcuA26MAAAht0MA5dAAAMAAABt0g");
	var mask_1_graphics_715 = new cjs.Graphics().p("EgcoA26MAAAht0MA5RAAAMAAABt0g");
	var mask_1_graphics_716 = new cjs.Graphics().p("EgciA26MAAAht0MA5FAAAMAAABt0g");
	var mask_1_graphics_717 = new cjs.Graphics().p("EgccA26MAAAht0MA45AAAMAAABt0g");
	var mask_1_graphics_718 = new cjs.Graphics().p("EgcWA26MAAAht0MA4tAAAMAAABt0g");
	var mask_1_graphics_719 = new cjs.Graphics().p("EgcQA26MAAAht0MA4hAAAMAAABt0g");
	var mask_1_graphics_720 = new cjs.Graphics().p("EgcKA26MAAAht0MA4VAAAMAAABt0g");
	var mask_1_graphics_721 = new cjs.Graphics().p("EgcEA26MAAAht0MA4JAAAMAAABt0g");
	var mask_1_graphics_722 = new cjs.Graphics().p("Egb+A26MAAAht0MA39AAAMAAABt0g");
	var mask_1_graphics_723 = new cjs.Graphics().p("Egb4A26MAAAht0MA3xAAAMAAABt0g");
	var mask_1_graphics_724 = new cjs.Graphics().p("EgbyA26MAAAht0MA3lAAAMAAABt0g");
	var mask_1_graphics_725 = new cjs.Graphics().p("EgbsA26MAAAht0MA3ZAAAMAAABt0g");
	var mask_1_graphics_726 = new cjs.Graphics().p("EgbmA26MAAAht0MA3NAAAMAAABt0g");
	var mask_1_graphics_727 = new cjs.Graphics().p("EgbgA26MAAAht0MA3BAAAMAAABt0g");
	var mask_1_graphics_728 = new cjs.Graphics().p("EgbaA26MAAAht0MA21AAAMAAABt0g");
	var mask_1_graphics_729 = new cjs.Graphics().p("EgbUA26MAAAht0MA2pAAAMAAABt0g");
	var mask_1_graphics_730 = new cjs.Graphics().p("EgbOA26MAAAht0MA2dAAAMAAABt0g");
	var mask_1_graphics_731 = new cjs.Graphics().p("EgbIA26MAAAht0MA2RAAAMAAABt0g");
	var mask_1_graphics_732 = new cjs.Graphics().p("EgbCA26MAAAht0MA2FAAAMAAABt0g");
	var mask_1_graphics_733 = new cjs.Graphics().p("Ega8A26MAAAht0MA15AAAMAAABt0g");
	var mask_1_graphics_734 = new cjs.Graphics().p("Ega2A26MAAAht0MA1tAAAMAAABt0g");
	var mask_1_graphics_735 = new cjs.Graphics().p("EgawA26MAAAht0MA1hAAAMAAABt0g");
	var mask_1_graphics_736 = new cjs.Graphics().p("EgaqA26MAAAht0MA1VAAAMAAABt0g");
	var mask_1_graphics_737 = new cjs.Graphics().p("EgakA26MAAAht0MA1JAAAMAAABt0g");
	var mask_1_graphics_738 = new cjs.Graphics().p("EgaeA26MAAAht0MA09AAAMAAABt0g");
	var mask_1_graphics_739 = new cjs.Graphics().p("EgaYA26MAAAht0MA0xAAAMAAABt0g");
	var mask_1_graphics_740 = new cjs.Graphics().p("EgaSA26MAAAht0MA0lAAAMAAABt0g");
	var mask_1_graphics_741 = new cjs.Graphics().p("EgaMA26MAAAht0MA0ZAAAMAAABt0g");
	var mask_1_graphics_742 = new cjs.Graphics().p("EgaGA26MAAAht0MA0NAAAMAAABt0g");
	var mask_1_graphics_743 = new cjs.Graphics().p("EgaAA26MAAAht0MA0BAAAMAAABt0g");
	var mask_1_graphics_744 = new cjs.Graphics().p("EgZ6A26MAAAht0MAz1AAAMAAABt0g");
	var mask_1_graphics_745 = new cjs.Graphics().p("EgZ1A26MAAAht0MAzqAAAMAAABt0g");
	var mask_1_graphics_746 = new cjs.Graphics().p("EgZuA26MAAAht0MAzdAAAMAAABt0g");
	var mask_1_graphics_747 = new cjs.Graphics().p("EgZoA26MAAAht0MAzRAAAMAAABt0g");
	var mask_1_graphics_748 = new cjs.Graphics().p("EgZjA26MAAAht0MAzHAAAMAAABt0g");
	var mask_1_graphics_749 = new cjs.Graphics().p("EgZcA26MAAAht0MAy5AAAMAAABt0g");
	var mask_1_graphics_750 = new cjs.Graphics().p("EgZXA26MAAAht0MAyuAAAMAAABt0g");
	var mask_1_graphics_751 = new cjs.Graphics().p("EgZRA26MAAAht0MAyiAAAMAAABt0g");
	var mask_1_graphics_752 = new cjs.Graphics().p("EgZKA26MAAAht0MAyWAAAMAAABt0g");
	var mask_1_graphics_753 = new cjs.Graphics().p("EgZFA26MAAAht0MAyKAAAMAAABt0g");
	var mask_1_graphics_754 = new cjs.Graphics().p("EgY+A26MAAAht0MAx9AAAMAAABt0g");
	var mask_1_graphics_755 = new cjs.Graphics().p("EgY5A26MAAAht0MAxzAAAMAAABt0g");
	var mask_1_graphics_756 = new cjs.Graphics().p("EgYyA26MAAAht0MAxmAAAMAAABt0g");
	var mask_1_graphics_757 = new cjs.Graphics().p("EgYsA26MAAAht0MAxZAAAMAAABt0g");
	var mask_1_graphics_758 = new cjs.Graphics().p("EgYnA26MAAAht0MAxPAAAMAAABt0g");
	var mask_1_graphics_759 = new cjs.Graphics().p("EgYgA26MAAAht0MAxCAAAMAAABt0g");
	var mask_1_graphics_760 = new cjs.Graphics().p("EgYbA26MAAAht0MAw3AAAMAAABt0g");
	var mask_1_graphics_761 = new cjs.Graphics().p("EgYVA26MAAAht0MAwrAAAMAAABt0g");
	var mask_1_graphics_762 = new cjs.Graphics().p("EgYPA26MAAAht0MAwfAAAMAAABt0g");
	var mask_1_graphics_763 = new cjs.Graphics().p("EgYJA26MAAAht0MAwTAAAMAAABt0g");
	var mask_1_graphics_764 = new cjs.Graphics().p("EgYDA26MAAAht0MAwHAAAMAAABt0g");
	var mask_1_graphics_765 = new cjs.Graphics().p("EgX9A26MAAAht0MAv7AAAMAAABt0g");
	var mask_1_graphics_766 = new cjs.Graphics().p("EgX3A26MAAAht0MAvvAAAMAAABt0g");
	var mask_1_graphics_767 = new cjs.Graphics().p("EgXxA26MAAAht0MAvjAAAMAAABt0g");
	var mask_1_graphics_768 = new cjs.Graphics().p("EgXrA26MAAAht0MAvXAAAMAAABt0g");
	var mask_1_graphics_769 = new cjs.Graphics().p("EgXlA26MAAAht0MAvLAAAMAAABt0g");
	var mask_1_graphics_770 = new cjs.Graphics().p("EgXfA26MAAAht0MAu/AAAMAAABt0g");
	var mask_1_graphics_771 = new cjs.Graphics().p("EgXZA26MAAAht0MAuzAAAMAAABt0g");
	var mask_1_graphics_772 = new cjs.Graphics().p("EgXTA26MAAAht0MAunAAAMAAABt0g");
	var mask_1_graphics_773 = new cjs.Graphics().p("EgXNA26MAAAht0MAubAAAMAAABt0g");
	var mask_1_graphics_774 = new cjs.Graphics().p("EgXHA26MAAAht0MAuPAAAMAAABt0g");
	var mask_1_graphics_775 = new cjs.Graphics().p("EgXBA26MAAAht0MAuDAAAMAAABt0g");
	var mask_1_graphics_776 = new cjs.Graphics().p("EgW7A26MAAAht0MAt3AAAMAAABt0g");
	var mask_1_graphics_777 = new cjs.Graphics().p("EgW1A26MAAAht0MAtrAAAMAAABt0g");
	var mask_1_graphics_778 = new cjs.Graphics().p("EgWvA26MAAAht0MAtfAAAMAAABt0g");
	var mask_1_graphics_779 = new cjs.Graphics().p("EgWpA26MAAAht0MAtTAAAMAAABt0g");
	var mask_1_graphics_780 = new cjs.Graphics().p("EgWjA26MAAAht0MAtHAAAMAAABt0g");
	var mask_1_graphics_781 = new cjs.Graphics().p("EgWdA26MAAAht0MAs7AAAMAAABt0g");
	var mask_1_graphics_782 = new cjs.Graphics().p("EgWXA26MAAAht0MAsvAAAMAAABt0g");
	var mask_1_graphics_783 = new cjs.Graphics().p("EgWRA26MAAAht0MAsjAAAMAAABt0g");
	var mask_1_graphics_784 = new cjs.Graphics().p("EgWLA26MAAAht0MAsXAAAMAAABt0g");
	var mask_1_graphics_785 = new cjs.Graphics().p("EgWFA26MAAAht0MAsLAAAMAAABt0g");
	var mask_1_graphics_786 = new cjs.Graphics().p("EgV/A26MAAAht0MAr/AAAMAAABt0g");
	var mask_1_graphics_787 = new cjs.Graphics().p("EgV5A26MAAAht0MArzAAAMAAABt0g");
	var mask_1_graphics_788 = new cjs.Graphics().p("EgVzA26MAAAht0MArnAAAMAAABt0g");
	var mask_1_graphics_789 = new cjs.Graphics().p("EgVtA26MAAAht0MArbAAAMAAABt0g");
	var mask_1_graphics_790 = new cjs.Graphics().p("EgVnA26MAAAht0MArPAAAMAAABt0g");
	var mask_1_graphics_791 = new cjs.Graphics().p("EgVhA26MAAAht0MArDAAAMAAABt0g");
	var mask_1_graphics_792 = new cjs.Graphics().p("EgVbA26MAAAht0MAq3AAAMAAABt0g");
	var mask_1_graphics_793 = new cjs.Graphics().p("EgVVA26MAAAht0MAqsAAAMAAABt0g");
	var mask_1_graphics_794 = new cjs.Graphics().p("EgVQA26MAAAht0MAqhAAAMAAABt0g");
	var mask_1_graphics_795 = new cjs.Graphics().p("EgVJA26MAAAht0MAqTAAAMAAABt0g");
	var mask_1_graphics_796 = new cjs.Graphics().p("EgVEA26MAAAht0MAqIAAAMAAABt0g");
	var mask_1_graphics_797 = new cjs.Graphics().p("EgU+A26MAAAht0MAp9AAAMAAABt0g");
	var mask_1_graphics_798 = new cjs.Graphics().p("EgU4A26MAAAht0MApwAAAMAAABt0g");
	var mask_1_graphics_799 = new cjs.Graphics().p("EgUyA26MAAAht0MApkAAAMAAABt0g");
	var mask_1_graphics_800 = new cjs.Graphics().p("EgUsA26MAAAht0MApZAAAMAAABt0g");
	var mask_1_graphics_801 = new cjs.Graphics().p("EgUmA26MAAAht0MApMAAAMAAABt0g");
	var mask_1_graphics_802 = new cjs.Graphics().p("EgUfA26MAAAht0MAo/AAAMAAABt0g");
	var mask_1_graphics_803 = new cjs.Graphics().p("EgUaA26MAAAht0MAo1AAAMAAABt0g");
	var mask_1_graphics_804 = new cjs.Graphics().p("EgUTA26MAAAht0MAooAAAMAAABt0g");
	var mask_1_graphics_805 = new cjs.Graphics().p("EgUOA26MAAAht0MAodAAAMAAABt0g");
	var mask_1_graphics_806 = new cjs.Graphics().p("EgUIA26MAAAht0MAoRAAAMAAABt0g");
	var mask_1_graphics_807 = new cjs.Graphics().p("EgUCA26MAAAht0MAoFAAAMAAABt0g");
	var mask_1_graphics_808 = new cjs.Graphics().p("EgT8A26MAAAht0MAn5AAAMAAABt0g");
	var mask_1_graphics_809 = new cjs.Graphics().p("EgT2A26MAAAht0MAntAAAMAAABt0g");
	var mask_1_graphics_810 = new cjs.Graphics().p("EgTwA26MAAAht0MAnhAAAMAAABt0g");
	var mask_1_graphics_811 = new cjs.Graphics().p("EgTqA26MAAAht0MAnVAAAMAAABt0g");
	var mask_1_graphics_812 = new cjs.Graphics().p("EgTkA26MAAAht0MAnJAAAMAAABt0g");
	var mask_1_graphics_813 = new cjs.Graphics().p("EgTeA26MAAAht0MAm9AAAMAAABt0g");
	var mask_1_graphics_814 = new cjs.Graphics().p("EgTYA26MAAAht0MAmxAAAMAAABt0g");
	var mask_1_graphics_815 = new cjs.Graphics().p("EgTSA26MAAAht0MAmlAAAMAAABt0g");
	var mask_1_graphics_816 = new cjs.Graphics().p("EgTMA26MAAAht0MAmZAAAMAAABt0g");
	var mask_1_graphics_817 = new cjs.Graphics().p("EgTGA26MAAAht0MAmNAAAMAAABt0g");
	var mask_1_graphics_818 = new cjs.Graphics().p("EgTAA26MAAAht0MAmBAAAMAAABt0g");
	var mask_1_graphics_819 = new cjs.Graphics().p("EgS6A26MAAAht0MAl1AAAMAAABt0g");
	var mask_1_graphics_820 = new cjs.Graphics().p("EgS0A26MAAAht0MAlpAAAMAAABt0g");
	var mask_1_graphics_821 = new cjs.Graphics().p("EgSuA26MAAAht0MAldAAAMAAABt0g");
	var mask_1_graphics_822 = new cjs.Graphics().p("EgSoA26MAAAht0MAlRAAAMAAABt0g");
	var mask_1_graphics_823 = new cjs.Graphics().p("EgSiA26MAAAht0MAlFAAAMAAABt0g");
	var mask_1_graphics_824 = new cjs.Graphics().p("EgScA26MAAAht0MAk5AAAMAAABt0g");
	var mask_1_graphics_825 = new cjs.Graphics().p("EgSWA26MAAAht0MAktAAAMAAABt0g");
	var mask_1_graphics_826 = new cjs.Graphics().p("EgSQA26MAAAht0MAkhAAAMAAABt0g");
	var mask_1_graphics_827 = new cjs.Graphics().p("EgSKA26MAAAht0MAkVAAAMAAABt0g");
	var mask_1_graphics_828 = new cjs.Graphics().p("EgSEA26MAAAht0MAkJAAAMAAABt0g");
	var mask_1_graphics_829 = new cjs.Graphics().p("EgR+A26MAAAht0MAj9AAAMAAABt0g");
	var mask_1_graphics_830 = new cjs.Graphics().p("EgR5A26MAAAht0MAjzAAAMAAABt0g");
	var mask_1_graphics_831 = new cjs.Graphics().p("EgRyA26MAAAht0MAjlAAAMAAABt0g");
	var mask_1_graphics_832 = new cjs.Graphics().p("EgRsA26MAAAht0MAjZAAAMAAABt0g");
	var mask_1_graphics_833 = new cjs.Graphics().p("EgRmA26MAAAht0MAjNAAAMAAABt0g");
	var mask_1_graphics_834 = new cjs.Graphics().p("EgRgA26MAAAht0MAjBAAAMAAABt0g");
	var mask_1_graphics_835 = new cjs.Graphics().p("EgRaA26MAAAht0MAi2AAAMAAABt0g");
	var mask_1_graphics_836 = new cjs.Graphics().p("EgRUA26MAAAht0MAipAAAMAAABt0g");
	var mask_1_graphics_837 = new cjs.Graphics().p("EgROA26MAAAht0MAidAAAMAAABt0g");
	var mask_1_graphics_838 = new cjs.Graphics().p("EgRIA26MAAAht0MAiSAAAMAAABt0g");
	var mask_1_graphics_839 = new cjs.Graphics().p("EgRDA26MAAAht0MAiHAAAMAAABt0g");
	var mask_1_graphics_840 = new cjs.Graphics().p("EgQ8A26MAAAht0MAh5AAAMAAABt0g");
	var mask_1_graphics_841 = new cjs.Graphics().p("EgQ3A26MAAAht0MAhvAAAMAAABt0g");
	var mask_1_graphics_842 = new cjs.Graphics().p("EgQxA26MAAAht0MAhjAAAMAAABt0g");
	var mask_1_graphics_843 = new cjs.Graphics().p("EgQqA26MAAAht0MAhVAAAMAAABt0g");
	var mask_1_graphics_844 = new cjs.Graphics().p("EgQlA26MAAAht0MAhKAAAMAAABt0g");
	var mask_1_graphics_845 = new cjs.Graphics().p("EgQfA26MAAAht0MAg/AAAMAAABt0g");
	var mask_1_graphics_846 = new cjs.Graphics().p("EgQZA26MAAAht0MAgyAAAMAAABt0g");
	var mask_1_graphics_847 = new cjs.Graphics().p("EgQTA26MAAAht0MAgmAAAMAAABt0g");
	var mask_1_graphics_848 = new cjs.Graphics().p("EgQNA26MAAAht0MAgbAAAMAAABt0g");
	var mask_1_graphics_849 = new cjs.Graphics().p("EgQHA26MAAAht0MAgPAAAMAAABt0g");
	var mask_1_graphics_850 = new cjs.Graphics().p("EgQAA26MAAAht0MAgCAAAMAAABt0g");
	var mask_1_graphics_851 = new cjs.Graphics().p("EgP7A26MAAAht0If3AAMAAABt0g");
	var mask_1_graphics_852 = new cjs.Graphics().p("EgP0A26MAAAht0IfpAAMAAABt0g");
	var mask_1_graphics_853 = new cjs.Graphics().p("EgPvA26MAAAht0IffAAMAAABt0g");
	var mask_1_graphics_854 = new cjs.Graphics().p("EgPpA26MAAAht0IfTAAMAAABt0g");
	var mask_1_graphics_855 = new cjs.Graphics().p("EgPjA26MAAAht0IfHAAMAAABt0g");
	var mask_1_graphics_856 = new cjs.Graphics().p("EgPdA26MAAAht0Ie7AAMAAABt0g");
	var mask_1_graphics_857 = new cjs.Graphics().p("EgPXA26MAAAht0IevAAMAAABt0g");
	var mask_1_graphics_858 = new cjs.Graphics().p("EgPRA26MAAAht0IejAAMAAABt0g");
	var mask_1_graphics_859 = new cjs.Graphics().p("EgPLA26MAAAht0IeXAAMAAABt0g");
	var mask_1_graphics_860 = new cjs.Graphics().p("EgPFA26MAAAht0IeLAAMAAABt0g");
	var mask_1_graphics_861 = new cjs.Graphics().p("EgO/A26MAAAht0Id/AAMAAABt0g");
	var mask_1_graphics_862 = new cjs.Graphics().p("EgO5A26MAAAht0IdzAAMAAABt0g");
	var mask_1_graphics_863 = new cjs.Graphics().p("EgOzA26MAAAht0IdnAAMAAABt0g");
	var mask_1_graphics_864 = new cjs.Graphics().p("EgOtA26MAAAht0IdbAAMAAABt0g");
	var mask_1_graphics_865 = new cjs.Graphics().p("EgOnA26MAAAht0IdPAAMAAABt0g");
	var mask_1_graphics_866 = new cjs.Graphics().p("EgOhA26MAAAht0IdDAAMAAABt0g");
	var mask_1_graphics_867 = new cjs.Graphics().p("EgObA26MAAAht0Ic3AAMAAABt0g");
	var mask_1_graphics_868 = new cjs.Graphics().p("EgOVA26MAAAht0IcrAAMAAABt0g");
	var mask_1_graphics_869 = new cjs.Graphics().p("EgOPA26MAAAht0IcfAAMAAABt0g");
	var mask_1_graphics_870 = new cjs.Graphics().p("EgOJA26MAAAht0IcTAAMAAABt0g");
	var mask_1_graphics_871 = new cjs.Graphics().p("EgODA26MAAAht0IcHAAMAAABt0g");
	var mask_1_graphics_872 = new cjs.Graphics().p("EgN9A26MAAAht0Ib7AAMAAABt0g");
	var mask_1_graphics_873 = new cjs.Graphics().p("EgN3A26MAAAht0IbvAAMAAABt0g");
	var mask_1_graphics_874 = new cjs.Graphics().p("EgNxA26MAAAht0IbjAAMAAABt0g");
	var mask_1_graphics_875 = new cjs.Graphics().p("EgNrA26MAAAht0IbXAAMAAABt0g");
	var mask_1_graphics_876 = new cjs.Graphics().p("EgNlA26MAAAht0IbLAAMAAABt0g");
	var mask_1_graphics_877 = new cjs.Graphics().p("EgNfA26MAAAht0Ia/AAMAAABt0g");
	var mask_1_graphics_878 = new cjs.Graphics().p("EgNaA26MAAAht0Ia0AAMAAABt0g");
	var mask_1_graphics_879 = new cjs.Graphics().p("EgNTA26MAAAht0IanAAMAAABt0g");
	var mask_1_graphics_880 = new cjs.Graphics().p("EgNNA26MAAAht0IabAAMAAABt0g");
	var mask_1_graphics_881 = new cjs.Graphics().p("EgNIA26MAAAht0IaQAAMAAABt0g");
	var mask_1_graphics_882 = new cjs.Graphics().p("EgNBA26MAAAht0IaDAAMAAABt0g");
	var mask_1_graphics_883 = new cjs.Graphics().p("EgM8A26MAAAht0IZ5AAMAAABt0g");
	var mask_1_graphics_884 = new cjs.Graphics().p("EgM1A26MAAAht0IZsAAMAAABt0g");
	var mask_1_graphics_885 = new cjs.Graphics().p("EgMwA26MAAAht0IZgAAMAAABt0g");
	var mask_1_graphics_886 = new cjs.Graphics().p("EgMpA26MAAAht0IZUAAMAAABt0g");
	var mask_1_graphics_887 = new cjs.Graphics().p("EgMkA26MAAAht0IZJAAMAAABt0g");
	var mask_1_graphics_888 = new cjs.Graphics().p("EgMeA26MAAAht0IY9AAMAAABt0g");
	var mask_1_graphics_889 = new cjs.Graphics().p("EgMYA26MAAAht0IYwAAMAAABt0g");
	var mask_1_graphics_890 = new cjs.Graphics().p("EgMSA26MAAAht0IYkAAMAAABt0g");
	var mask_1_graphics_891 = new cjs.Graphics().p("EgMMA26MAAAht0IYZAAMAAABt0g");
	var mask_1_graphics_892 = new cjs.Graphics().p("EgMGA26MAAAht0IYMAAMAAABt0g");
	var mask_1_graphics_893 = new cjs.Graphics().p("EgMAA26MAAAht0IYBAAMAAABt0g");
	var mask_1_graphics_894 = new cjs.Graphics().p("EgL6A26MAAAht0IX1AAMAAABt0g");
	var mask_1_graphics_895 = new cjs.Graphics().p("EgL0A26MAAAht0IXpAAMAAABt0g");
	var mask_1_graphics_896 = new cjs.Graphics().p("EgLuA26MAAAht0IXdAAMAAABt0g");
	var mask_1_graphics_897 = new cjs.Graphics().p("EgLoA26MAAAht0IXRAAMAAABt0g");
	var mask_1_graphics_898 = new cjs.Graphics().p("EgLiA26MAAAht0IXFAAMAAABt0g");
	var mask_1_graphics_899 = new cjs.Graphics().p("EgLcA26MAAAht0IW5AAMAAABt0g");
	var mask_1_graphics_900 = new cjs.Graphics().p("EgLWA26MAAAht0IWtAAMAAABt0g");
	var mask_1_graphics_901 = new cjs.Graphics().p("EgLQA26MAAAht0IWhAAMAAABt0g");
	var mask_1_graphics_902 = new cjs.Graphics().p("EgLKA26MAAAht0IWVAAMAAABt0g");
	var mask_1_graphics_903 = new cjs.Graphics().p("EgLEA26MAAAht0IWJAAMAAABt0g");
	var mask_1_graphics_904 = new cjs.Graphics().p("EgK+A26MAAAht0IV9AAMAAABt0g");
	var mask_1_graphics_905 = new cjs.Graphics().p("EgK4A26MAAAht0IVxAAMAAABt0g");
	var mask_1_graphics_906 = new cjs.Graphics().p("EgKyA26MAAAht0IVlAAMAAABt0g");
	var mask_1_graphics_907 = new cjs.Graphics().p("EgKsA26MAAAht0IVZAAMAAABt0g");
	var mask_1_graphics_908 = new cjs.Graphics().p("EgKmA26MAAAht0IVNAAMAAABt0g");
	var mask_1_graphics_909 = new cjs.Graphics().p("EgKgA26MAAAht0IVBAAMAAABt0g");
	var mask_1_graphics_910 = new cjs.Graphics().p("EgKaA26MAAAht0IU1AAMAAABt0g");
	var mask_1_graphics_911 = new cjs.Graphics().p("EgKUA26MAAAht0IUpAAMAAABt0g");
	var mask_1_graphics_912 = new cjs.Graphics().p("EgKOA26MAAAht0IUdAAMAAABt0g");
	var mask_1_graphics_913 = new cjs.Graphics().p("EgKIA26MAAAht0IURAAMAAABt0g");
	var mask_1_graphics_914 = new cjs.Graphics().p("EgKCA26MAAAht0IUFAAMAAABt0g");
	var mask_1_graphics_915 = new cjs.Graphics().p("EgJ8A26MAAAht0IT5AAMAAABt0g");
	var mask_1_graphics_916 = new cjs.Graphics().p("EgJ2A26MAAAht0ITtAAMAAABt0g");
	var mask_1_graphics_917 = new cjs.Graphics().p("EgJwA26MAAAht0IThAAMAAABt0g");
	var mask_1_graphics_918 = new cjs.Graphics().p("EgJqA26MAAAht0ITVAAMAAABt0g");
	var mask_1_graphics_919 = new cjs.Graphics().p("EgJkA26MAAAht0ITJAAMAAABt0g");
	var mask_1_graphics_920 = new cjs.Graphics().p("EgJeA26MAAAht0IS9AAMAAABt0g");
	var mask_1_graphics_921 = new cjs.Graphics().p("EgJYA26MAAAht0ISxAAMAAABt0g");
	var mask_1_graphics_922 = new cjs.Graphics().p("EgJSA26MAAAht0ISlAAMAAABt0g");
	var mask_1_graphics_923 = new cjs.Graphics().p("EgJNA26MAAAht0ISaAAMAAABt0g");
	var mask_1_graphics_924 = new cjs.Graphics().p("EgJGA26MAAAht0ISNAAMAAABt0g");
	var mask_1_graphics_925 = new cjs.Graphics().p("EgJAA26MAAAht0ISBAAMAAABt0g");
	var mask_1_graphics_926 = new cjs.Graphics().p("EgI7A26MAAAht0IR2AAMAAABt0g");
	var mask_1_graphics_927 = new cjs.Graphics().p("EgI0A26MAAAht0IRpAAMAAABt0g");
	var mask_1_graphics_928 = new cjs.Graphics().p("EgIvA26MAAAht0IRfAAMAAABt0g");
	var mask_1_graphics_929 = new cjs.Graphics().p("EgIoA26MAAAht0IRSAAMAAABt0g");
	var mask_1_graphics_930 = new cjs.Graphics().p("EgIiA26MAAAht0IRFAAMAAABt0g");
	var mask_1_graphics_931 = new cjs.Graphics().p("EgIcA26MAAAht0IQ5AAMAAABt0g");
	var mask_1_graphics_932 = new cjs.Graphics().p("EgIWA26MAAAht0IQuAAMAAABt0g");
	var mask_1_graphics_933 = new cjs.Graphics().p("EgIRA26MAAAht0IQjAAMAAABt0g");
	var mask_1_graphics_934 = new cjs.Graphics().p("EgIKA26MAAAht0IQVAAMAAABt0g");
	var mask_1_graphics_935 = new cjs.Graphics().p("EgIFA26MAAAht0IQKAAMAAABt0g");
	var mask_1_graphics_936 = new cjs.Graphics().p("EgH/A26MAAAht0IP/AAMAAABt0g");
	var mask_1_graphics_937 = new cjs.Graphics().p("EgH5A26MAAAht0IPyAAMAAABt0g");
	var mask_1_graphics_938 = new cjs.Graphics().p("EgHzA26MAAAht0IPnAAMAAABt0g");
	var mask_1_graphics_939 = new cjs.Graphics().p("EgHtA26MAAAht0IPbAAMAAABt0g");
	var mask_1_graphics_940 = new cjs.Graphics().p("EgHnA26MAAAht0IPPAAMAAABt0g");
	var mask_1_graphics_941 = new cjs.Graphics().p("EgHhA26MAAAht0IPDAAMAAABt0g");
	var mask_1_graphics_942 = new cjs.Graphics().p("EgHbA26MAAAht0IO3AAMAAABt0g");
	var mask_1_graphics_943 = new cjs.Graphics().p("EgHVA26MAAAht0IOrAAMAAABt0g");
	var mask_1_graphics_944 = new cjs.Graphics().p("EgHPA26MAAAht0IOfAAMAAABt0g");
	var mask_1_graphics_945 = new cjs.Graphics().p("EgHJA26MAAAht0IOTAAMAAABt0g");
	var mask_1_graphics_946 = new cjs.Graphics().p("EgHDA26MAAAht0IOHAAMAAABt0g");
	var mask_1_graphics_947 = new cjs.Graphics().p("EgG9A26MAAAht0IN7AAMAAABt0g");
	var mask_1_graphics_948 = new cjs.Graphics().p("EgG3A26MAAAht0INvAAMAAABt0g");
	var mask_1_graphics_949 = new cjs.Graphics().p("EgGxA26MAAAht0INjAAMAAABt0g");
	var mask_1_graphics_950 = new cjs.Graphics().p("EgGrA26MAAAht0INXAAMAAABt0g");
	var mask_1_graphics_951 = new cjs.Graphics().p("EgGlA26MAAAht0INLAAMAAABt0g");
	var mask_1_graphics_952 = new cjs.Graphics().p("EgGfA26MAAAht0IM/AAMAAABt0g");
	var mask_1_graphics_953 = new cjs.Graphics().p("EgGZA26MAAAht0IMzAAMAAABt0g");
	var mask_1_graphics_954 = new cjs.Graphics().p("EgGTA26MAAAht0IMnAAMAAABt0g");
	var mask_1_graphics_955 = new cjs.Graphics().p("EgGNA26MAAAht0IMbAAMAAABt0g");
	var mask_1_graphics_956 = new cjs.Graphics().p("EgGHA26MAAAht0IMPAAMAAABt0g");
	var mask_1_graphics_957 = new cjs.Graphics().p("EgGBA26MAAAht0IMDAAMAAABt0g");
	var mask_1_graphics_958 = new cjs.Graphics().p("EgF7A26MAAAht0IL3AAMAAABt0g");
	var mask_1_graphics_959 = new cjs.Graphics().p("EgF1A26MAAAht0ILrAAMAAABt0g");
	var mask_1_graphics_960 = new cjs.Graphics().p("EgFvA26MAAAht0ILfAAMAAABt0g");
	var mask_1_graphics_961 = new cjs.Graphics().p("EgFpA26MAAAht0ILTAAMAAABt0g");
	var mask_1_graphics_962 = new cjs.Graphics().p("EgFjA26MAAAht0ILHAAMAAABt0g");
	var mask_1_graphics_963 = new cjs.Graphics().p("EgFdA26MAAAht0IK7AAMAAABt0g");
	var mask_1_graphics_964 = new cjs.Graphics().p("EgFXA26MAAAht0IKvAAMAAABt0g");
	var mask_1_graphics_965 = new cjs.Graphics().p("EgFRA26MAAAht0IKjAAMAAABt0g");
	var mask_1_graphics_966 = new cjs.Graphics().p("EgFLA26MAAAht0IKXAAMAAABt0g");
	var mask_1_graphics_967 = new cjs.Graphics().p("EgFFA26MAAAht0IKLAAMAAABt0g");
	var mask_1_graphics_968 = new cjs.Graphics().p("EgE/A26MAAAht0IJ/AAMAAABt0g");
	var mask_1_graphics_969 = new cjs.Graphics().p("EgE5A26MAAAht0IJzAAMAAABt0g");
	var mask_1_graphics_970 = new cjs.Graphics().p("EgEzA26MAAAht0IJnAAMAAABt0g");
	var mask_1_graphics_971 = new cjs.Graphics().p("EgEuA26MAAAht0IJcAAMAAABt0g");
	var mask_1_graphics_972 = new cjs.Graphics().p("EgEnA26MAAAht0IJPAAMAAABt0g");
	var mask_1_graphics_973 = new cjs.Graphics().p("EgEiA26MAAAht0IJFAAMAAABt0g");
	var mask_1_graphics_974 = new cjs.Graphics().p("EgEcA26MAAAht0II5AAMAAABt0g");
	var mask_1_graphics_975 = new cjs.Graphics().p("EgEVA26MAAAht0IIrAAMAAABt0g");
	var mask_1_graphics_976 = new cjs.Graphics().p("EgEQA26MAAAht0IIgAAMAAABt0g");
	var mask_1_graphics_977 = new cjs.Graphics().p("EgEKA26MAAAht0IIVAAMAAABt0g");
	var mask_1_graphics_978 = new cjs.Graphics().p("EgEEA26MAAAht0IIJAAMAAABt0g");
	var mask_1_graphics_979 = new cjs.Graphics().p("EgD+A26MAAAht0IH8AAMAAABt0g");
	var mask_1_graphics_980 = new cjs.Graphics().p("EgD3A26MAAAht0IHvAAMAAABt0g");
	var mask_1_graphics_981 = new cjs.Graphics().p("EgDyA26MAAAht0IHlAAMAAABt0g");
	var mask_1_graphics_982 = new cjs.Graphics().p("EgDrA26MAAAht0IHXAAMAAABt0g");
	var mask_1_graphics_983 = new cjs.Graphics().p("EgDmA26MAAAht0IHNAAMAAABt0g");
	var mask_1_graphics_984 = new cjs.Graphics().p("EgDgA26MAAAht0IHBAAMAAABt0g");
	var mask_1_graphics_985 = new cjs.Graphics().p("EgDZA26MAAAht0IG0AAMAAABt0g");
	var mask_1_graphics_986 = new cjs.Graphics().p("EgDUA26MAAAht0IGpAAMAAABt0g");
	var mask_1_graphics_987 = new cjs.Graphics().p("EgDOA26MAAAht0IGdAAMAAABt0g");
	var mask_1_graphics_988 = new cjs.Graphics().p("EgDIA26MAAAht0IGRAAMAAABt0g");
	var mask_1_graphics_989 = new cjs.Graphics().p("EgDCA26MAAAht0IGFAAMAAABt0g");
	var mask_1_graphics_990 = new cjs.Graphics().p("EgC8A26MAAAht0IF5AAMAAABt0g");
	var mask_1_graphics_991 = new cjs.Graphics().p("EgC2A26MAAAht0IFtAAMAAABt0g");
	var mask_1_graphics_992 = new cjs.Graphics().p("EgCwA26MAAAht0IFhAAMAAABt0g");
	var mask_1_graphics_993 = new cjs.Graphics().p("EgCqA26MAAAht0IFVAAMAAABt0g");
	var mask_1_graphics_994 = new cjs.Graphics().p("EgCkA26MAAAht0IFJAAMAAABt0g");
	var mask_1_graphics_995 = new cjs.Graphics().p("EgCeA26MAAAht0IE9AAMAAABt0g");
	var mask_1_graphics_996 = new cjs.Graphics().p("EgCYA26MAAAht0IExAAMAAABt0g");
	var mask_1_graphics_997 = new cjs.Graphics().p("EgCSA26MAAAht0IElAAMAAABt0g");
	var mask_1_graphics_998 = new cjs.Graphics().p("EgCMA26MAAAht0IEZAAMAAABt0g");
	var mask_1_graphics_999 = new cjs.Graphics().p("EgCGA26MAAAht0IENAAMAAABt0g");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:mask_1_graphics_0,x:649,y:351.5}).wait(1).to({graphics:mask_1_graphics_1,x:687.8,y:351.5}).wait(1).to({graphics:mask_1_graphics_2,x:688.4,y:351.5}).wait(1).to({graphics:mask_1_graphics_3,x:688.9,y:351.5}).wait(1).to({graphics:mask_1_graphics_4,x:689.4,y:351.5}).wait(1).to({graphics:mask_1_graphics_5,x:689.9,y:351.5}).wait(1).to({graphics:mask_1_graphics_6,x:690.4,y:351.5}).wait(1).to({graphics:mask_1_graphics_7,x:691,y:351.5}).wait(1).to({graphics:mask_1_graphics_8,x:691.5,y:351.5}).wait(1).to({graphics:mask_1_graphics_9,x:692,y:351.5}).wait(1).to({graphics:mask_1_graphics_10,x:692.5,y:351.5}).wait(1).to({graphics:mask_1_graphics_11,x:693,y:351.5}).wait(1).to({graphics:mask_1_graphics_12,x:693.6,y:351.5}).wait(1).to({graphics:mask_1_graphics_13,x:694.1,y:351.5}).wait(1).to({graphics:mask_1_graphics_14,x:694.6,y:351.5}).wait(1).to({graphics:mask_1_graphics_15,x:695.1,y:351.5}).wait(1).to({graphics:mask_1_graphics_16,x:695.6,y:351.5}).wait(1).to({graphics:mask_1_graphics_17,x:696.1,y:351.5}).wait(1).to({graphics:mask_1_graphics_18,x:696.7,y:351.5}).wait(1).to({graphics:mask_1_graphics_19,x:697.2,y:351.5}).wait(1).to({graphics:mask_1_graphics_20,x:697.7,y:351.5}).wait(1).to({graphics:mask_1_graphics_21,x:698.2,y:351.5}).wait(1).to({graphics:mask_1_graphics_22,x:698.7,y:351.5}).wait(1).to({graphics:mask_1_graphics_23,x:699.2,y:351.5}).wait(1).to({graphics:mask_1_graphics_24,x:699.8,y:351.5}).wait(1).to({graphics:mask_1_graphics_25,x:700.3,y:351.5}).wait(1).to({graphics:mask_1_graphics_26,x:700.8,y:351.5}).wait(1).to({graphics:mask_1_graphics_27,x:701.3,y:351.5}).wait(1).to({graphics:mask_1_graphics_28,x:701.8,y:351.5}).wait(1).to({graphics:mask_1_graphics_29,x:702.4,y:351.5}).wait(1).to({graphics:mask_1_graphics_30,x:702.9,y:351.5}).wait(1).to({graphics:mask_1_graphics_31,x:703.4,y:351.5}).wait(1).to({graphics:mask_1_graphics_32,x:703.9,y:351.5}).wait(1).to({graphics:mask_1_graphics_33,x:704.4,y:351.5}).wait(1).to({graphics:mask_1_graphics_34,x:704.9,y:351.5}).wait(1).to({graphics:mask_1_graphics_35,x:705.5,y:351.5}).wait(1).to({graphics:mask_1_graphics_36,x:706,y:351.5}).wait(1).to({graphics:mask_1_graphics_37,x:706.5,y:351.5}).wait(1).to({graphics:mask_1_graphics_38,x:707,y:351.5}).wait(1).to({graphics:mask_1_graphics_39,x:707.5,y:351.5}).wait(1).to({graphics:mask_1_graphics_40,x:708,y:351.5}).wait(1).to({graphics:mask_1_graphics_41,x:708.6,y:351.5}).wait(1).to({graphics:mask_1_graphics_42,x:709.1,y:351.5}).wait(1).to({graphics:mask_1_graphics_43,x:709.6,y:351.5}).wait(1).to({graphics:mask_1_graphics_44,x:710.1,y:351.5}).wait(1).to({graphics:mask_1_graphics_45,x:710.6,y:351.5}).wait(1).to({graphics:mask_1_graphics_46,x:711.1,y:351.5}).wait(1).to({graphics:mask_1_graphics_47,x:711.7,y:351.5}).wait(1).to({graphics:mask_1_graphics_48,x:712.2,y:351.5}).wait(1).to({graphics:mask_1_graphics_49,x:712.7,y:351.5}).wait(1).to({graphics:mask_1_graphics_50,x:713.2,y:351.5}).wait(1).to({graphics:mask_1_graphics_51,x:713.7,y:351.5}).wait(1).to({graphics:mask_1_graphics_52,x:714.3,y:351.5}).wait(1).to({graphics:mask_1_graphics_53,x:714.8,y:351.5}).wait(1).to({graphics:mask_1_graphics_54,x:715.3,y:351.5}).wait(1).to({graphics:mask_1_graphics_55,x:715.8,y:351.5}).wait(1).to({graphics:mask_1_graphics_56,x:716.3,y:351.5}).wait(1).to({graphics:mask_1_graphics_57,x:716.9,y:351.5}).wait(1).to({graphics:mask_1_graphics_58,x:717.4,y:351.5}).wait(1).to({graphics:mask_1_graphics_59,x:717.9,y:351.5}).wait(1).to({graphics:mask_1_graphics_60,x:718.4,y:351.5}).wait(1).to({graphics:mask_1_graphics_61,x:718.9,y:351.5}).wait(1).to({graphics:mask_1_graphics_62,x:719.4,y:351.5}).wait(1).to({graphics:mask_1_graphics_63,x:720,y:351.5}).wait(1).to({graphics:mask_1_graphics_64,x:720.5,y:351.5}).wait(1).to({graphics:mask_1_graphics_65,x:721,y:351.5}).wait(1).to({graphics:mask_1_graphics_66,x:721.5,y:351.5}).wait(1).to({graphics:mask_1_graphics_67,x:722,y:351.5}).wait(1).to({graphics:mask_1_graphics_68,x:722.5,y:351.5}).wait(1).to({graphics:mask_1_graphics_69,x:723.1,y:351.5}).wait(1).to({graphics:mask_1_graphics_70,x:723.6,y:351.5}).wait(1).to({graphics:mask_1_graphics_71,x:724.1,y:351.5}).wait(1).to({graphics:mask_1_graphics_72,x:724.6,y:351.5}).wait(1).to({graphics:mask_1_graphics_73,x:725.1,y:351.5}).wait(1).to({graphics:mask_1_graphics_74,x:725.7,y:351.5}).wait(1).to({graphics:mask_1_graphics_75,x:726.2,y:351.5}).wait(1).to({graphics:mask_1_graphics_76,x:726.7,y:351.5}).wait(1).to({graphics:mask_1_graphics_77,x:727.2,y:351.5}).wait(1).to({graphics:mask_1_graphics_78,x:727.7,y:351.5}).wait(1).to({graphics:mask_1_graphics_79,x:728.3,y:351.5}).wait(1).to({graphics:mask_1_graphics_80,x:728.8,y:351.5}).wait(1).to({graphics:mask_1_graphics_81,x:729.3,y:351.5}).wait(1).to({graphics:mask_1_graphics_82,x:729.8,y:351.5}).wait(1).to({graphics:mask_1_graphics_83,x:730.3,y:351.5}).wait(1).to({graphics:mask_1_graphics_84,x:730.8,y:351.5}).wait(1).to({graphics:mask_1_graphics_85,x:731.3,y:351.5}).wait(1).to({graphics:mask_1_graphics_86,x:731.9,y:351.5}).wait(1).to({graphics:mask_1_graphics_87,x:732.4,y:351.5}).wait(1).to({graphics:mask_1_graphics_88,x:732.9,y:351.5}).wait(1).to({graphics:mask_1_graphics_89,x:733.4,y:351.5}).wait(1).to({graphics:mask_1_graphics_90,x:733.9,y:351.5}).wait(1).to({graphics:mask_1_graphics_91,x:734.4,y:351.5}).wait(1).to({graphics:mask_1_graphics_92,x:735,y:351.5}).wait(1).to({graphics:mask_1_graphics_93,x:735.5,y:351.5}).wait(1).to({graphics:mask_1_graphics_94,x:736,y:351.5}).wait(1).to({graphics:mask_1_graphics_95,x:736.5,y:351.5}).wait(1).to({graphics:mask_1_graphics_96,x:737,y:351.5}).wait(1).to({graphics:mask_1_graphics_97,x:737.6,y:351.5}).wait(1).to({graphics:mask_1_graphics_98,x:738.1,y:351.5}).wait(1).to({graphics:mask_1_graphics_99,x:738.6,y:351.5}).wait(1).to({graphics:mask_1_graphics_100,x:739.1,y:351.5}).wait(1).to({graphics:mask_1_graphics_101,x:739.6,y:351.5}).wait(1).to({graphics:mask_1_graphics_102,x:740.2,y:351.5}).wait(1).to({graphics:mask_1_graphics_103,x:740.7,y:351.5}).wait(1).to({graphics:mask_1_graphics_104,x:741.2,y:351.5}).wait(1).to({graphics:mask_1_graphics_105,x:741.7,y:351.5}).wait(1).to({graphics:mask_1_graphics_106,x:742.2,y:351.5}).wait(1).to({graphics:mask_1_graphics_107,x:742.7,y:351.5}).wait(1).to({graphics:mask_1_graphics_108,x:743.3,y:351.5}).wait(1).to({graphics:mask_1_graphics_109,x:743.8,y:351.5}).wait(1).to({graphics:mask_1_graphics_110,x:744.3,y:351.5}).wait(1).to({graphics:mask_1_graphics_111,x:744.8,y:351.5}).wait(1).to({graphics:mask_1_graphics_112,x:745.3,y:351.5}).wait(1).to({graphics:mask_1_graphics_113,x:745.8,y:351.5}).wait(1).to({graphics:mask_1_graphics_114,x:746.4,y:351.5}).wait(1).to({graphics:mask_1_graphics_115,x:746.9,y:351.5}).wait(1).to({graphics:mask_1_graphics_116,x:747.4,y:351.5}).wait(1).to({graphics:mask_1_graphics_117,x:747.9,y:351.5}).wait(1).to({graphics:mask_1_graphics_118,x:748.4,y:351.5}).wait(1).to({graphics:mask_1_graphics_119,x:749,y:351.5}).wait(1).to({graphics:mask_1_graphics_120,x:749.5,y:351.5}).wait(1).to({graphics:mask_1_graphics_121,x:750,y:351.5}).wait(1).to({graphics:mask_1_graphics_122,x:750.5,y:351.5}).wait(1).to({graphics:mask_1_graphics_123,x:751,y:351.5}).wait(1).to({graphics:mask_1_graphics_124,x:751.6,y:351.5}).wait(1).to({graphics:mask_1_graphics_125,x:752.1,y:351.5}).wait(1).to({graphics:mask_1_graphics_126,x:752.6,y:351.5}).wait(1).to({graphics:mask_1_graphics_127,x:753.1,y:351.5}).wait(1).to({graphics:mask_1_graphics_128,x:753.6,y:351.5}).wait(1).to({graphics:mask_1_graphics_129,x:754.1,y:351.5}).wait(1).to({graphics:mask_1_graphics_130,x:754.6,y:351.5}).wait(1).to({graphics:mask_1_graphics_131,x:755.2,y:351.5}).wait(1).to({graphics:mask_1_graphics_132,x:755.7,y:351.5}).wait(1).to({graphics:mask_1_graphics_133,x:756.2,y:351.5}).wait(1).to({graphics:mask_1_graphics_134,x:756.7,y:351.5}).wait(1).to({graphics:mask_1_graphics_135,x:757.2,y:351.5}).wait(1).to({graphics:mask_1_graphics_136,x:757.7,y:351.5}).wait(1).to({graphics:mask_1_graphics_137,x:758.3,y:351.5}).wait(1).to({graphics:mask_1_graphics_138,x:758.8,y:351.5}).wait(1).to({graphics:mask_1_graphics_139,x:759.3,y:351.5}).wait(1).to({graphics:mask_1_graphics_140,x:759.8,y:351.5}).wait(1).to({graphics:mask_1_graphics_141,x:760.3,y:351.5}).wait(1).to({graphics:mask_1_graphics_142,x:760.9,y:351.5}).wait(1).to({graphics:mask_1_graphics_143,x:761.4,y:351.5}).wait(1).to({graphics:mask_1_graphics_144,x:761.9,y:351.5}).wait(1).to({graphics:mask_1_graphics_145,x:762.4,y:351.5}).wait(1).to({graphics:mask_1_graphics_146,x:762.9,y:351.5}).wait(1).to({graphics:mask_1_graphics_147,x:763.4,y:351.5}).wait(1).to({graphics:mask_1_graphics_148,x:764,y:351.5}).wait(1).to({graphics:mask_1_graphics_149,x:764.5,y:351.5}).wait(1).to({graphics:mask_1_graphics_150,x:765,y:351.5}).wait(1).to({graphics:mask_1_graphics_151,x:765.5,y:351.5}).wait(1).to({graphics:mask_1_graphics_152,x:766,y:351.5}).wait(1).to({graphics:mask_1_graphics_153,x:766.5,y:351.5}).wait(1).to({graphics:mask_1_graphics_154,x:767.1,y:351.5}).wait(1).to({graphics:mask_1_graphics_155,x:767.6,y:351.5}).wait(1).to({graphics:mask_1_graphics_156,x:768.1,y:351.5}).wait(1).to({graphics:mask_1_graphics_157,x:768.6,y:351.5}).wait(1).to({graphics:mask_1_graphics_158,x:769.1,y:351.5}).wait(1).to({graphics:mask_1_graphics_159,x:769.6,y:351.5}).wait(1).to({graphics:mask_1_graphics_160,x:770.2,y:351.5}).wait(1).to({graphics:mask_1_graphics_161,x:770.7,y:351.5}).wait(1).to({graphics:mask_1_graphics_162,x:771.2,y:351.5}).wait(1).to({graphics:mask_1_graphics_163,x:771.7,y:351.5}).wait(1).to({graphics:mask_1_graphics_164,x:772.2,y:351.5}).wait(1).to({graphics:mask_1_graphics_165,x:772.8,y:351.5}).wait(1).to({graphics:mask_1_graphics_166,x:773.3,y:351.5}).wait(1).to({graphics:mask_1_graphics_167,x:773.8,y:351.5}).wait(1).to({graphics:mask_1_graphics_168,x:774.3,y:351.5}).wait(1).to({graphics:mask_1_graphics_169,x:774.8,y:351.5}).wait(1).to({graphics:mask_1_graphics_170,x:775.4,y:351.5}).wait(1).to({graphics:mask_1_graphics_171,x:775.9,y:351.5}).wait(1).to({graphics:mask_1_graphics_172,x:776.4,y:351.5}).wait(1).to({graphics:mask_1_graphics_173,x:776.9,y:351.5}).wait(1).to({graphics:mask_1_graphics_174,x:777.4,y:351.5}).wait(1).to({graphics:mask_1_graphics_175,x:777.9,y:351.5}).wait(1).to({graphics:mask_1_graphics_176,x:778.5,y:351.5}).wait(1).to({graphics:mask_1_graphics_177,x:779,y:351.5}).wait(1).to({graphics:mask_1_graphics_178,x:779.5,y:351.5}).wait(1).to({graphics:mask_1_graphics_179,x:780,y:351.5}).wait(1).to({graphics:mask_1_graphics_180,x:780.5,y:351.5}).wait(1).to({graphics:mask_1_graphics_181,x:781,y:351.5}).wait(1).to({graphics:mask_1_graphics_182,x:781.6,y:351.5}).wait(1).to({graphics:mask_1_graphics_183,x:782.1,y:351.5}).wait(1).to({graphics:mask_1_graphics_184,x:782.6,y:351.5}).wait(1).to({graphics:mask_1_graphics_185,x:783.1,y:351.5}).wait(1).to({graphics:mask_1_graphics_186,x:783.6,y:351.5}).wait(1).to({graphics:mask_1_graphics_187,x:784.2,y:351.5}).wait(1).to({graphics:mask_1_graphics_188,x:784.7,y:351.5}).wait(1).to({graphics:mask_1_graphics_189,x:785.2,y:351.5}).wait(1).to({graphics:mask_1_graphics_190,x:785.7,y:351.5}).wait(1).to({graphics:mask_1_graphics_191,x:786.2,y:351.5}).wait(1).to({graphics:mask_1_graphics_192,x:786.8,y:351.5}).wait(1).to({graphics:mask_1_graphics_193,x:787.3,y:351.5}).wait(1).to({graphics:mask_1_graphics_194,x:787.8,y:351.5}).wait(1).to({graphics:mask_1_graphics_195,x:788.3,y:351.5}).wait(1).to({graphics:mask_1_graphics_196,x:788.8,y:351.5}).wait(1).to({graphics:mask_1_graphics_197,x:789.3,y:351.5}).wait(1).to({graphics:mask_1_graphics_198,x:789.8,y:351.5}).wait(1).to({graphics:mask_1_graphics_199,x:790.4,y:351.5}).wait(1).to({graphics:mask_1_graphics_200,x:790.9,y:351.5}).wait(1).to({graphics:mask_1_graphics_201,x:791.4,y:351.5}).wait(1).to({graphics:mask_1_graphics_202,x:791.9,y:351.5}).wait(1).to({graphics:mask_1_graphics_203,x:792.4,y:351.5}).wait(1).to({graphics:mask_1_graphics_204,x:792.9,y:351.5}).wait(1).to({graphics:mask_1_graphics_205,x:793.5,y:351.5}).wait(1).to({graphics:mask_1_graphics_206,x:794,y:351.5}).wait(1).to({graphics:mask_1_graphics_207,x:794.5,y:351.5}).wait(1).to({graphics:mask_1_graphics_208,x:795,y:351.5}).wait(1).to({graphics:mask_1_graphics_209,x:795.5,y:351.5}).wait(1).to({graphics:mask_1_graphics_210,x:796.1,y:351.5}).wait(1).to({graphics:mask_1_graphics_211,x:796.6,y:351.5}).wait(1).to({graphics:mask_1_graphics_212,x:797.1,y:351.5}).wait(1).to({graphics:mask_1_graphics_213,x:797.6,y:351.5}).wait(1).to({graphics:mask_1_graphics_214,x:798.1,y:351.5}).wait(1).to({graphics:mask_1_graphics_215,x:798.7,y:351.5}).wait(1).to({graphics:mask_1_graphics_216,x:799.2,y:351.5}).wait(1).to({graphics:mask_1_graphics_217,x:799.7,y:351.5}).wait(1).to({graphics:mask_1_graphics_218,x:800.2,y:351.5}).wait(1).to({graphics:mask_1_graphics_219,x:800.7,y:351.5}).wait(1).to({graphics:mask_1_graphics_220,x:801.2,y:351.5}).wait(1).to({graphics:mask_1_graphics_221,x:801.8,y:351.5}).wait(1).to({graphics:mask_1_graphics_222,x:802.3,y:351.5}).wait(1).to({graphics:mask_1_graphics_223,x:802.8,y:351.5}).wait(1).to({graphics:mask_1_graphics_224,x:803.3,y:351.5}).wait(1).to({graphics:mask_1_graphics_225,x:803.8,y:351.5}).wait(1).to({graphics:mask_1_graphics_226,x:804.3,y:351.5}).wait(1).to({graphics:mask_1_graphics_227,x:804.9,y:351.5}).wait(1).to({graphics:mask_1_graphics_228,x:805.4,y:351.5}).wait(1).to({graphics:mask_1_graphics_229,x:805.9,y:351.5}).wait(1).to({graphics:mask_1_graphics_230,x:806.4,y:351.5}).wait(1).to({graphics:mask_1_graphics_231,x:806.9,y:351.5}).wait(1).to({graphics:mask_1_graphics_232,x:807.5,y:351.5}).wait(1).to({graphics:mask_1_graphics_233,x:808,y:351.5}).wait(1).to({graphics:mask_1_graphics_234,x:808.5,y:351.5}).wait(1).to({graphics:mask_1_graphics_235,x:809,y:351.5}).wait(1).to({graphics:mask_1_graphics_236,x:809.5,y:351.5}).wait(1).to({graphics:mask_1_graphics_237,x:810.1,y:351.5}).wait(1).to({graphics:mask_1_graphics_238,x:810.6,y:351.5}).wait(1).to({graphics:mask_1_graphics_239,x:811.1,y:351.5}).wait(1).to({graphics:mask_1_graphics_240,x:811.6,y:351.5}).wait(1).to({graphics:mask_1_graphics_241,x:812.1,y:351.5}).wait(1).to({graphics:mask_1_graphics_242,x:812.6,y:351.5}).wait(1).to({graphics:mask_1_graphics_243,x:813.1,y:351.5}).wait(1).to({graphics:mask_1_graphics_244,x:813.7,y:351.5}).wait(1).to({graphics:mask_1_graphics_245,x:814.2,y:351.5}).wait(1).to({graphics:mask_1_graphics_246,x:814.7,y:351.5}).wait(1).to({graphics:mask_1_graphics_247,x:815.2,y:351.5}).wait(1).to({graphics:mask_1_graphics_248,x:815.7,y:351.5}).wait(1).to({graphics:mask_1_graphics_249,x:816.2,y:351.5}).wait(1).to({graphics:mask_1_graphics_250,x:816.8,y:351.5}).wait(1).to({graphics:mask_1_graphics_251,x:817.3,y:351.5}).wait(1).to({graphics:mask_1_graphics_252,x:817.8,y:351.5}).wait(1).to({graphics:mask_1_graphics_253,x:818.3,y:351.5}).wait(1).to({graphics:mask_1_graphics_254,x:818.8,y:351.5}).wait(1).to({graphics:mask_1_graphics_255,x:819.4,y:351.5}).wait(1).to({graphics:mask_1_graphics_256,x:819.9,y:351.5}).wait(1).to({graphics:mask_1_graphics_257,x:820.4,y:351.5}).wait(1).to({graphics:mask_1_graphics_258,x:820.9,y:351.5}).wait(1).to({graphics:mask_1_graphics_259,x:821.4,y:351.5}).wait(1).to({graphics:mask_1_graphics_260,x:822,y:351.5}).wait(1).to({graphics:mask_1_graphics_261,x:822.5,y:351.5}).wait(1).to({graphics:mask_1_graphics_262,x:823,y:351.5}).wait(1).to({graphics:mask_1_graphics_263,x:823.5,y:351.5}).wait(1).to({graphics:mask_1_graphics_264,x:824,y:351.5}).wait(1).to({graphics:mask_1_graphics_265,x:824.5,y:351.5}).wait(1).to({graphics:mask_1_graphics_266,x:825.1,y:351.5}).wait(1).to({graphics:mask_1_graphics_267,x:825.6,y:351.5}).wait(1).to({graphics:mask_1_graphics_268,x:826.1,y:351.5}).wait(1).to({graphics:mask_1_graphics_269,x:826.6,y:351.5}).wait(1).to({graphics:mask_1_graphics_270,x:827.1,y:351.5}).wait(1).to({graphics:mask_1_graphics_271,x:827.6,y:351.5}).wait(1).to({graphics:mask_1_graphics_272,x:828.2,y:351.5}).wait(1).to({graphics:mask_1_graphics_273,x:828.7,y:351.5}).wait(1).to({graphics:mask_1_graphics_274,x:829.2,y:351.5}).wait(1).to({graphics:mask_1_graphics_275,x:829.7,y:351.5}).wait(1).to({graphics:mask_1_graphics_276,x:830.2,y:351.5}).wait(1).to({graphics:mask_1_graphics_277,x:830.8,y:351.5}).wait(1).to({graphics:mask_1_graphics_278,x:831.3,y:351.5}).wait(1).to({graphics:mask_1_graphics_279,x:831.8,y:351.5}).wait(1).to({graphics:mask_1_graphics_280,x:832.3,y:351.5}).wait(1).to({graphics:mask_1_graphics_281,x:832.8,y:351.5}).wait(1).to({graphics:mask_1_graphics_282,x:833.4,y:351.5}).wait(1).to({graphics:mask_1_graphics_283,x:833.9,y:351.5}).wait(1).to({graphics:mask_1_graphics_284,x:834.4,y:351.5}).wait(1).to({graphics:mask_1_graphics_285,x:834.9,y:351.5}).wait(1).to({graphics:mask_1_graphics_286,x:835.4,y:351.5}).wait(1).to({graphics:mask_1_graphics_287,x:835.9,y:351.5}).wait(1).to({graphics:mask_1_graphics_288,x:836.4,y:351.5}).wait(1).to({graphics:mask_1_graphics_289,x:837,y:351.5}).wait(1).to({graphics:mask_1_graphics_290,x:837.5,y:351.5}).wait(1).to({graphics:mask_1_graphics_291,x:838,y:351.5}).wait(1).to({graphics:mask_1_graphics_292,x:838.5,y:351.5}).wait(1).to({graphics:mask_1_graphics_293,x:839,y:351.5}).wait(1).to({graphics:mask_1_graphics_294,x:839.5,y:351.5}).wait(1).to({graphics:mask_1_graphics_295,x:840.1,y:351.5}).wait(1).to({graphics:mask_1_graphics_296,x:840.6,y:351.5}).wait(1).to({graphics:mask_1_graphics_297,x:841.1,y:351.5}).wait(1).to({graphics:mask_1_graphics_298,x:841.6,y:351.5}).wait(1).to({graphics:mask_1_graphics_299,x:842.1,y:351.5}).wait(1).to({graphics:mask_1_graphics_300,x:842.7,y:351.5}).wait(1).to({graphics:mask_1_graphics_301,x:843.2,y:351.5}).wait(1).to({graphics:mask_1_graphics_302,x:843.7,y:351.5}).wait(1).to({graphics:mask_1_graphics_303,x:844.2,y:351.5}).wait(1).to({graphics:mask_1_graphics_304,x:844.7,y:351.5}).wait(1).to({graphics:mask_1_graphics_305,x:845.2,y:351.5}).wait(1).to({graphics:mask_1_graphics_306,x:845.8,y:351.5}).wait(1).to({graphics:mask_1_graphics_307,x:846.3,y:351.5}).wait(1).to({graphics:mask_1_graphics_308,x:846.8,y:351.5}).wait(1).to({graphics:mask_1_graphics_309,x:847.3,y:351.5}).wait(1).to({graphics:mask_1_graphics_310,x:847.8,y:351.5}).wait(1).to({graphics:mask_1_graphics_311,x:848.3,y:351.5}).wait(1).to({graphics:mask_1_graphics_312,x:848.9,y:351.5}).wait(1).to({graphics:mask_1_graphics_313,x:849.4,y:351.5}).wait(1).to({graphics:mask_1_graphics_314,x:849.9,y:351.5}).wait(1).to({graphics:mask_1_graphics_315,x:850.4,y:351.5}).wait(1).to({graphics:mask_1_graphics_316,x:850.9,y:351.5}).wait(1).to({graphics:mask_1_graphics_317,x:851.5,y:351.5}).wait(1).to({graphics:mask_1_graphics_318,x:852,y:351.5}).wait(1).to({graphics:mask_1_graphics_319,x:852.5,y:351.5}).wait(1).to({graphics:mask_1_graphics_320,x:853,y:351.5}).wait(1).to({graphics:mask_1_graphics_321,x:853.5,y:351.5}).wait(1).to({graphics:mask_1_graphics_322,x:854.1,y:351.5}).wait(1).to({graphics:mask_1_graphics_323,x:854.6,y:351.5}).wait(1).to({graphics:mask_1_graphics_324,x:855.1,y:351.5}).wait(1).to({graphics:mask_1_graphics_325,x:855.6,y:351.5}).wait(1).to({graphics:mask_1_graphics_326,x:856.1,y:351.5}).wait(1).to({graphics:mask_1_graphics_327,x:856.7,y:351.5}).wait(1).to({graphics:mask_1_graphics_328,x:857.2,y:351.5}).wait(1).to({graphics:mask_1_graphics_329,x:857.7,y:351.5}).wait(1).to({graphics:mask_1_graphics_330,x:858.2,y:351.5}).wait(1).to({graphics:mask_1_graphics_331,x:858.7,y:351.5}).wait(1).to({graphics:mask_1_graphics_332,x:859.2,y:351.5}).wait(1).to({graphics:mask_1_graphics_333,x:859.7,y:351.5}).wait(1).to({graphics:mask_1_graphics_334,x:860.3,y:351.5}).wait(1).to({graphics:mask_1_graphics_335,x:860.8,y:351.5}).wait(1).to({graphics:mask_1_graphics_336,x:861.3,y:351.5}).wait(1).to({graphics:mask_1_graphics_337,x:861.8,y:351.5}).wait(1).to({graphics:mask_1_graphics_338,x:862.3,y:351.5}).wait(1).to({graphics:mask_1_graphics_339,x:862.8,y:351.5}).wait(1).to({graphics:mask_1_graphics_340,x:863.4,y:351.5}).wait(1).to({graphics:mask_1_graphics_341,x:863.9,y:351.5}).wait(1).to({graphics:mask_1_graphics_342,x:864.4,y:351.5}).wait(1).to({graphics:mask_1_graphics_343,x:864.9,y:351.5}).wait(1).to({graphics:mask_1_graphics_344,x:865.4,y:351.5}).wait(1).to({graphics:mask_1_graphics_345,x:866,y:351.5}).wait(1).to({graphics:mask_1_graphics_346,x:866.5,y:351.5}).wait(1).to({graphics:mask_1_graphics_347,x:867,y:351.5}).wait(1).to({graphics:mask_1_graphics_348,x:867.5,y:351.5}).wait(1).to({graphics:mask_1_graphics_349,x:868,y:351.5}).wait(1).to({graphics:mask_1_graphics_350,x:868.6,y:351.5}).wait(1).to({graphics:mask_1_graphics_351,x:869.1,y:351.5}).wait(1).to({graphics:mask_1_graphics_352,x:869.6,y:351.5}).wait(1).to({graphics:mask_1_graphics_353,x:870.1,y:351.5}).wait(1).to({graphics:mask_1_graphics_354,x:870.6,y:351.5}).wait(1).to({graphics:mask_1_graphics_355,x:871.1,y:351.5}).wait(1).to({graphics:mask_1_graphics_356,x:871.6,y:351.5}).wait(1).to({graphics:mask_1_graphics_357,x:872.2,y:351.5}).wait(1).to({graphics:mask_1_graphics_358,x:872.7,y:351.5}).wait(1).to({graphics:mask_1_graphics_359,x:873.2,y:351.5}).wait(1).to({graphics:mask_1_graphics_360,x:873.7,y:351.5}).wait(1).to({graphics:mask_1_graphics_361,x:874.2,y:351.5}).wait(1).to({graphics:mask_1_graphics_362,x:874.8,y:351.5}).wait(1).to({graphics:mask_1_graphics_363,x:875.3,y:351.5}).wait(1).to({graphics:mask_1_graphics_364,x:875.8,y:351.5}).wait(1).to({graphics:mask_1_graphics_365,x:876.3,y:351.5}).wait(1).to({graphics:mask_1_graphics_366,x:876.8,y:351.5}).wait(1).to({graphics:mask_1_graphics_367,x:877.4,y:351.5}).wait(1).to({graphics:mask_1_graphics_368,x:877.9,y:351.5}).wait(1).to({graphics:mask_1_graphics_369,x:878.4,y:351.5}).wait(1).to({graphics:mask_1_graphics_370,x:878.9,y:351.5}).wait(1).to({graphics:mask_1_graphics_371,x:879.4,y:351.5}).wait(1).to({graphics:mask_1_graphics_372,x:880,y:351.5}).wait(1).to({graphics:mask_1_graphics_373,x:880.5,y:351.5}).wait(1).to({graphics:mask_1_graphics_374,x:881,y:351.5}).wait(1).to({graphics:mask_1_graphics_375,x:881.5,y:351.5}).wait(1).to({graphics:mask_1_graphics_376,x:882,y:351.5}).wait(1).to({graphics:mask_1_graphics_377,x:882.5,y:351.5}).wait(1).to({graphics:mask_1_graphics_378,x:883,y:351.5}).wait(1).to({graphics:mask_1_graphics_379,x:883.6,y:351.5}).wait(1).to({graphics:mask_1_graphics_380,x:884.1,y:351.5}).wait(1).to({graphics:mask_1_graphics_381,x:884.6,y:351.5}).wait(1).to({graphics:mask_1_graphics_382,x:885.1,y:351.5}).wait(1).to({graphics:mask_1_graphics_383,x:885.6,y:351.5}).wait(1).to({graphics:mask_1_graphics_384,x:886.1,y:351.5}).wait(1).to({graphics:mask_1_graphics_385,x:886.7,y:351.5}).wait(1).to({graphics:mask_1_graphics_386,x:887.2,y:351.5}).wait(1).to({graphics:mask_1_graphics_387,x:887.7,y:351.5}).wait(1).to({graphics:mask_1_graphics_388,x:888.2,y:351.5}).wait(1).to({graphics:mask_1_graphics_389,x:888.7,y:351.5}).wait(1).to({graphics:mask_1_graphics_390,x:889.3,y:351.5}).wait(1).to({graphics:mask_1_graphics_391,x:889.8,y:351.5}).wait(1).to({graphics:mask_1_graphics_392,x:890.3,y:351.5}).wait(1).to({graphics:mask_1_graphics_393,x:890.8,y:351.5}).wait(1).to({graphics:mask_1_graphics_394,x:891.3,y:351.5}).wait(1).to({graphics:mask_1_graphics_395,x:891.9,y:351.5}).wait(1).to({graphics:mask_1_graphics_396,x:892.4,y:351.5}).wait(1).to({graphics:mask_1_graphics_397,x:892.9,y:351.5}).wait(1).to({graphics:mask_1_graphics_398,x:893.4,y:351.5}).wait(1).to({graphics:mask_1_graphics_399,x:893.9,y:351.5}).wait(1).to({graphics:mask_1_graphics_400,x:894.4,y:351.5}).wait(1).to({graphics:mask_1_graphics_401,x:894.9,y:351.5}).wait(1).to({graphics:mask_1_graphics_402,x:895.5,y:351.5}).wait(1).to({graphics:mask_1_graphics_403,x:896,y:351.5}).wait(1).to({graphics:mask_1_graphics_404,x:896.5,y:351.5}).wait(1).to({graphics:mask_1_graphics_405,x:897,y:351.5}).wait(1).to({graphics:mask_1_graphics_406,x:897.5,y:351.5}).wait(1).to({graphics:mask_1_graphics_407,x:898.1,y:351.5}).wait(1).to({graphics:mask_1_graphics_408,x:898.6,y:351.5}).wait(1).to({graphics:mask_1_graphics_409,x:899.1,y:351.5}).wait(1).to({graphics:mask_1_graphics_410,x:899.6,y:351.5}).wait(1).to({graphics:mask_1_graphics_411,x:900.1,y:351.5}).wait(1).to({graphics:mask_1_graphics_412,x:900.7,y:351.5}).wait(1).to({graphics:mask_1_graphics_413,x:901.2,y:351.5}).wait(1).to({graphics:mask_1_graphics_414,x:901.7,y:351.5}).wait(1).to({graphics:mask_1_graphics_415,x:902.2,y:351.5}).wait(1).to({graphics:mask_1_graphics_416,x:902.7,y:351.5}).wait(1).to({graphics:mask_1_graphics_417,x:903.2,y:351.5}).wait(1).to({graphics:mask_1_graphics_418,x:903.8,y:351.5}).wait(1).to({graphics:mask_1_graphics_419,x:904.3,y:351.5}).wait(1).to({graphics:mask_1_graphics_420,x:904.8,y:351.5}).wait(1).to({graphics:mask_1_graphics_421,x:905.3,y:351.5}).wait(1).to({graphics:mask_1_graphics_422,x:905.8,y:351.5}).wait(1).to({graphics:mask_1_graphics_423,x:906.3,y:351.5}).wait(1).to({graphics:mask_1_graphics_424,x:906.9,y:351.5}).wait(1).to({graphics:mask_1_graphics_425,x:907.4,y:351.5}).wait(1).to({graphics:mask_1_graphics_426,x:907.9,y:351.5}).wait(1).to({graphics:mask_1_graphics_427,x:908.4,y:351.5}).wait(1).to({graphics:mask_1_graphics_428,x:908.9,y:351.5}).wait(1).to({graphics:mask_1_graphics_429,x:909.4,y:351.5}).wait(1).to({graphics:mask_1_graphics_430,x:910,y:351.5}).wait(1).to({graphics:mask_1_graphics_431,x:910.5,y:351.5}).wait(1).to({graphics:mask_1_graphics_432,x:911,y:351.5}).wait(1).to({graphics:mask_1_graphics_433,x:911.5,y:351.5}).wait(1).to({graphics:mask_1_graphics_434,x:912,y:351.5}).wait(1).to({graphics:mask_1_graphics_435,x:912.6,y:351.5}).wait(1).to({graphics:mask_1_graphics_436,x:913.1,y:351.5}).wait(1).to({graphics:mask_1_graphics_437,x:913.6,y:351.5}).wait(1).to({graphics:mask_1_graphics_438,x:914.1,y:351.5}).wait(1).to({graphics:mask_1_graphics_439,x:914.6,y:351.5}).wait(1).to({graphics:mask_1_graphics_440,x:915.2,y:351.5}).wait(1).to({graphics:mask_1_graphics_441,x:915.7,y:351.5}).wait(1).to({graphics:mask_1_graphics_442,x:916.2,y:351.5}).wait(1).to({graphics:mask_1_graphics_443,x:916.7,y:351.5}).wait(1).to({graphics:mask_1_graphics_444,x:917.2,y:351.5}).wait(1).to({graphics:mask_1_graphics_445,x:917.7,y:351.5}).wait(1).to({graphics:mask_1_graphics_446,x:918.2,y:351.5}).wait(1).to({graphics:mask_1_graphics_447,x:918.8,y:351.5}).wait(1).to({graphics:mask_1_graphics_448,x:919.3,y:351.5}).wait(1).to({graphics:mask_1_graphics_449,x:919.8,y:351.5}).wait(1).to({graphics:mask_1_graphics_450,x:920.3,y:351.5}).wait(1).to({graphics:mask_1_graphics_451,x:920.8,y:351.5}).wait(1).to({graphics:mask_1_graphics_452,x:921.4,y:351.5}).wait(1).to({graphics:mask_1_graphics_453,x:921.9,y:351.5}).wait(1).to({graphics:mask_1_graphics_454,x:922.4,y:351.5}).wait(1).to({graphics:mask_1_graphics_455,x:922.9,y:351.5}).wait(1).to({graphics:mask_1_graphics_456,x:923.4,y:351.5}).wait(1).to({graphics:mask_1_graphics_457,x:924,y:351.5}).wait(1).to({graphics:mask_1_graphics_458,x:924.5,y:351.5}).wait(1).to({graphics:mask_1_graphics_459,x:925,y:351.5}).wait(1).to({graphics:mask_1_graphics_460,x:925.5,y:351.5}).wait(1).to({graphics:mask_1_graphics_461,x:926,y:351.5}).wait(1).to({graphics:mask_1_graphics_462,x:926.5,y:351.5}).wait(1).to({graphics:mask_1_graphics_463,x:927.1,y:351.5}).wait(1).to({graphics:mask_1_graphics_464,x:927.6,y:351.5}).wait(1).to({graphics:mask_1_graphics_465,x:928.1,y:351.5}).wait(1).to({graphics:mask_1_graphics_466,x:928.6,y:351.5}).wait(1).to({graphics:mask_1_graphics_467,x:929.1,y:351.5}).wait(1).to({graphics:mask_1_graphics_468,x:929.6,y:351.5}).wait(1).to({graphics:mask_1_graphics_469,x:930.1,y:351.5}).wait(1).to({graphics:mask_1_graphics_470,x:930.7,y:351.5}).wait(1).to({graphics:mask_1_graphics_471,x:931.2,y:351.5}).wait(1).to({graphics:mask_1_graphics_472,x:931.7,y:351.5}).wait(1).to({graphics:mask_1_graphics_473,x:932.2,y:351.5}).wait(1).to({graphics:mask_1_graphics_474,x:932.7,y:351.5}).wait(1).to({graphics:mask_1_graphics_475,x:933.3,y:351.5}).wait(1).to({graphics:mask_1_graphics_476,x:933.8,y:351.5}).wait(1).to({graphics:mask_1_graphics_477,x:934.3,y:351.5}).wait(1).to({graphics:mask_1_graphics_478,x:934.8,y:351.5}).wait(1).to({graphics:mask_1_graphics_479,x:935.3,y:351.5}).wait(1).to({graphics:mask_1_graphics_480,x:935.9,y:351.5}).wait(1).to({graphics:mask_1_graphics_481,x:936.4,y:351.5}).wait(1).to({graphics:mask_1_graphics_482,x:936.9,y:351.5}).wait(1).to({graphics:mask_1_graphics_483,x:937.4,y:351.5}).wait(1).to({graphics:mask_1_graphics_484,x:937.9,y:351.5}).wait(1).to({graphics:mask_1_graphics_485,x:938.5,y:351.5}).wait(1).to({graphics:mask_1_graphics_486,x:939,y:351.5}).wait(1).to({graphics:mask_1_graphics_487,x:939.5,y:351.5}).wait(1).to({graphics:mask_1_graphics_488,x:940,y:351.5}).wait(1).to({graphics:mask_1_graphics_489,x:940.5,y:351.5}).wait(1).to({graphics:mask_1_graphics_490,x:941,y:351.5}).wait(1).to({graphics:mask_1_graphics_491,x:941.5,y:351.5}).wait(1).to({graphics:mask_1_graphics_492,x:942.1,y:351.5}).wait(1).to({graphics:mask_1_graphics_493,x:942.6,y:351.5}).wait(1).to({graphics:mask_1_graphics_494,x:943.1,y:351.5}).wait(1).to({graphics:mask_1_graphics_495,x:943.6,y:351.5}).wait(1).to({graphics:mask_1_graphics_496,x:944.1,y:351.5}).wait(1).to({graphics:mask_1_graphics_497,x:944.7,y:351.5}).wait(1).to({graphics:mask_1_graphics_498,x:945.2,y:351.5}).wait(1).to({graphics:mask_1_graphics_499,x:945.7,y:351.5}).wait(1).to({graphics:mask_1_graphics_500,x:946.2,y:351.5}).wait(1).to({graphics:mask_1_graphics_501,x:946.7,y:351.5}).wait(1).to({graphics:mask_1_graphics_502,x:947.2,y:351.5}).wait(1).to({graphics:mask_1_graphics_503,x:947.8,y:351.5}).wait(1).to({graphics:mask_1_graphics_504,x:948.3,y:351.5}).wait(1).to({graphics:mask_1_graphics_505,x:948.8,y:351.5}).wait(1).to({graphics:mask_1_graphics_506,x:949.3,y:351.5}).wait(1).to({graphics:mask_1_graphics_507,x:949.8,y:351.5}).wait(1).to({graphics:mask_1_graphics_508,x:950.4,y:351.5}).wait(1).to({graphics:mask_1_graphics_509,x:950.9,y:351.5}).wait(1).to({graphics:mask_1_graphics_510,x:951.4,y:351.5}).wait(1).to({graphics:mask_1_graphics_511,x:951.9,y:351.5}).wait(1).to({graphics:mask_1_graphics_512,x:952.4,y:351.5}).wait(1).to({graphics:mask_1_graphics_513,x:952.9,y:351.5}).wait(1).to({graphics:mask_1_graphics_514,x:953.4,y:351.5}).wait(1).to({graphics:mask_1_graphics_515,x:954,y:351.5}).wait(1).to({graphics:mask_1_graphics_516,x:954.5,y:351.5}).wait(1).to({graphics:mask_1_graphics_517,x:955,y:351.5}).wait(1).to({graphics:mask_1_graphics_518,x:955.5,y:351.5}).wait(1).to({graphics:mask_1_graphics_519,x:956,y:351.5}).wait(1).to({graphics:mask_1_graphics_520,x:956.6,y:351.5}).wait(1).to({graphics:mask_1_graphics_521,x:957.1,y:351.5}).wait(1).to({graphics:mask_1_graphics_522,x:957.6,y:351.5}).wait(1).to({graphics:mask_1_graphics_523,x:958.1,y:351.5}).wait(1).to({graphics:mask_1_graphics_524,x:958.6,y:351.5}).wait(1).to({graphics:mask_1_graphics_525,x:959.2,y:351.5}).wait(1).to({graphics:mask_1_graphics_526,x:959.7,y:351.5}).wait(1).to({graphics:mask_1_graphics_527,x:960.2,y:351.5}).wait(1).to({graphics:mask_1_graphics_528,x:960.7,y:351.5}).wait(1).to({graphics:mask_1_graphics_529,x:961.2,y:351.5}).wait(1).to({graphics:mask_1_graphics_530,x:961.8,y:351.5}).wait(1).to({graphics:mask_1_graphics_531,x:962.3,y:351.5}).wait(1).to({graphics:mask_1_graphics_532,x:962.8,y:351.5}).wait(1).to({graphics:mask_1_graphics_533,x:963.3,y:351.5}).wait(1).to({graphics:mask_1_graphics_534,x:963.8,y:351.5}).wait(1).to({graphics:mask_1_graphics_535,x:964.3,y:351.5}).wait(1).to({graphics:mask_1_graphics_536,x:964.8,y:351.5}).wait(1).to({graphics:mask_1_graphics_537,x:965.4,y:351.5}).wait(1).to({graphics:mask_1_graphics_538,x:965.9,y:351.5}).wait(1).to({graphics:mask_1_graphics_539,x:966.4,y:351.5}).wait(1).to({graphics:mask_1_graphics_540,x:966.9,y:351.5}).wait(1).to({graphics:mask_1_graphics_541,x:967.4,y:351.5}).wait(1).to({graphics:mask_1_graphics_542,x:967.9,y:351.5}).wait(1).to({graphics:mask_1_graphics_543,x:968.5,y:351.5}).wait(1).to({graphics:mask_1_graphics_544,x:969,y:351.5}).wait(1).to({graphics:mask_1_graphics_545,x:969.5,y:351.5}).wait(1).to({graphics:mask_1_graphics_546,x:970,y:351.5}).wait(1).to({graphics:mask_1_graphics_547,x:970.5,y:351.5}).wait(1).to({graphics:mask_1_graphics_548,x:971.1,y:351.5}).wait(1).to({graphics:mask_1_graphics_549,x:971.6,y:351.5}).wait(1).to({graphics:mask_1_graphics_550,x:972.1,y:351.5}).wait(1).to({graphics:mask_1_graphics_551,x:972.6,y:351.5}).wait(1).to({graphics:mask_1_graphics_552,x:973.1,y:351.5}).wait(1).to({graphics:mask_1_graphics_553,x:973.7,y:351.5}).wait(1).to({graphics:mask_1_graphics_554,x:974.2,y:351.5}).wait(1).to({graphics:mask_1_graphics_555,x:974.7,y:351.5}).wait(1).to({graphics:mask_1_graphics_556,x:975.2,y:351.5}).wait(1).to({graphics:mask_1_graphics_557,x:975.7,y:351.5}).wait(1).to({graphics:mask_1_graphics_558,x:976.2,y:351.5}).wait(1).to({graphics:mask_1_graphics_559,x:976.7,y:351.5}).wait(1).to({graphics:mask_1_graphics_560,x:977.3,y:351.5}).wait(1).to({graphics:mask_1_graphics_561,x:977.8,y:351.5}).wait(1).to({graphics:mask_1_graphics_562,x:978.3,y:351.5}).wait(1).to({graphics:mask_1_graphics_563,x:978.8,y:351.5}).wait(1).to({graphics:mask_1_graphics_564,x:979.3,y:351.5}).wait(1).to({graphics:mask_1_graphics_565,x:979.9,y:351.5}).wait(1).to({graphics:mask_1_graphics_566,x:980.4,y:351.5}).wait(1).to({graphics:mask_1_graphics_567,x:980.9,y:351.5}).wait(1).to({graphics:mask_1_graphics_568,x:981.4,y:351.5}).wait(1).to({graphics:mask_1_graphics_569,x:981.9,y:351.5}).wait(1).to({graphics:mask_1_graphics_570,x:982.5,y:351.5}).wait(1).to({graphics:mask_1_graphics_571,x:983,y:351.5}).wait(1).to({graphics:mask_1_graphics_572,x:983.5,y:351.5}).wait(1).to({graphics:mask_1_graphics_573,x:984,y:351.5}).wait(1).to({graphics:mask_1_graphics_574,x:984.5,y:351.5}).wait(1).to({graphics:mask_1_graphics_575,x:985,y:351.5}).wait(1).to({graphics:mask_1_graphics_576,x:985.6,y:351.5}).wait(1).to({graphics:mask_1_graphics_577,x:986.1,y:351.5}).wait(1).to({graphics:mask_1_graphics_578,x:986.6,y:351.5}).wait(1).to({graphics:mask_1_graphics_579,x:987.1,y:351.5}).wait(1).to({graphics:mask_1_graphics_580,x:987.6,y:351.5}).wait(1).to({graphics:mask_1_graphics_581,x:988.1,y:351.5}).wait(1).to({graphics:mask_1_graphics_582,x:988.7,y:351.5}).wait(1).to({graphics:mask_1_graphics_583,x:989.2,y:351.5}).wait(1).to({graphics:mask_1_graphics_584,x:989.7,y:351.5}).wait(1).to({graphics:mask_1_graphics_585,x:990.2,y:351.5}).wait(1).to({graphics:mask_1_graphics_586,x:990.7,y:351.5}).wait(1).to({graphics:mask_1_graphics_587,x:991.2,y:351.5}).wait(1).to({graphics:mask_1_graphics_588,x:991.8,y:351.5}).wait(1).to({graphics:mask_1_graphics_589,x:992.3,y:351.5}).wait(1).to({graphics:mask_1_graphics_590,x:992.8,y:351.5}).wait(1).to({graphics:mask_1_graphics_591,x:993.3,y:351.5}).wait(1).to({graphics:mask_1_graphics_592,x:993.8,y:351.5}).wait(1).to({graphics:mask_1_graphics_593,x:994.4,y:351.5}).wait(1).to({graphics:mask_1_graphics_594,x:994.9,y:351.5}).wait(1).to({graphics:mask_1_graphics_595,x:995.4,y:351.5}).wait(1).to({graphics:mask_1_graphics_596,x:995.9,y:351.5}).wait(1).to({graphics:mask_1_graphics_597,x:996.4,y:351.5}).wait(1).to({graphics:mask_1_graphics_598,x:997,y:351.5}).wait(1).to({graphics:mask_1_graphics_599,x:997.5,y:351.5}).wait(1).to({graphics:mask_1_graphics_600,x:998,y:351.5}).wait(1).to({graphics:mask_1_graphics_601,x:998.5,y:351.5}).wait(1).to({graphics:mask_1_graphics_602,x:999,y:351.5}).wait(1).to({graphics:mask_1_graphics_603,x:999.5,y:351.5}).wait(1).to({graphics:mask_1_graphics_604,x:1000,y:351.5}).wait(1).to({graphics:mask_1_graphics_605,x:1000.6,y:351.5}).wait(1).to({graphics:mask_1_graphics_606,x:1001.1,y:351.5}).wait(1).to({graphics:mask_1_graphics_607,x:1001.6,y:351.5}).wait(1).to({graphics:mask_1_graphics_608,x:1002.1,y:351.5}).wait(1).to({graphics:mask_1_graphics_609,x:1002.6,y:351.5}).wait(1).to({graphics:mask_1_graphics_610,x:1003.2,y:351.5}).wait(1).to({graphics:mask_1_graphics_611,x:1003.7,y:351.5}).wait(1).to({graphics:mask_1_graphics_612,x:1004.2,y:351.5}).wait(1).to({graphics:mask_1_graphics_613,x:1004.7,y:351.5}).wait(1).to({graphics:mask_1_graphics_614,x:1005.2,y:351.5}).wait(1).to({graphics:mask_1_graphics_615,x:1005.8,y:351.5}).wait(1).to({graphics:mask_1_graphics_616,x:1006.3,y:351.5}).wait(1).to({graphics:mask_1_graphics_617,x:1006.8,y:351.5}).wait(1).to({graphics:mask_1_graphics_618,x:1007.3,y:351.5}).wait(1).to({graphics:mask_1_graphics_619,x:1007.8,y:351.5}).wait(1).to({graphics:mask_1_graphics_620,x:1008.3,y:351.5}).wait(1).to({graphics:mask_1_graphics_621,x:1008.9,y:351.5}).wait(1).to({graphics:mask_1_graphics_622,x:1009.4,y:351.5}).wait(1).to({graphics:mask_1_graphics_623,x:1009.9,y:351.5}).wait(1).to({graphics:mask_1_graphics_624,x:1010.4,y:351.5}).wait(1).to({graphics:mask_1_graphics_625,x:1010.9,y:351.5}).wait(1).to({graphics:mask_1_graphics_626,x:1011.4,y:351.5}).wait(1).to({graphics:mask_1_graphics_627,x:1011.9,y:351.5}).wait(1).to({graphics:mask_1_graphics_628,x:1012.5,y:351.5}).wait(1).to({graphics:mask_1_graphics_629,x:1013,y:351.5}).wait(1).to({graphics:mask_1_graphics_630,x:1013.5,y:351.5}).wait(1).to({graphics:mask_1_graphics_631,x:1014,y:351.5}).wait(1).to({graphics:mask_1_graphics_632,x:1014.5,y:351.5}).wait(1).to({graphics:mask_1_graphics_633,x:1015.1,y:351.5}).wait(1).to({graphics:mask_1_graphics_634,x:1015.6,y:351.5}).wait(1).to({graphics:mask_1_graphics_635,x:1016.1,y:351.5}).wait(1).to({graphics:mask_1_graphics_636,x:1016.6,y:351.5}).wait(1).to({graphics:mask_1_graphics_637,x:1017.1,y:351.5}).wait(1).to({graphics:mask_1_graphics_638,x:1017.7,y:351.5}).wait(1).to({graphics:mask_1_graphics_639,x:1018.2,y:351.5}).wait(1).to({graphics:mask_1_graphics_640,x:1018.7,y:351.5}).wait(1).to({graphics:mask_1_graphics_641,x:1019.2,y:351.5}).wait(1).to({graphics:mask_1_graphics_642,x:1019.7,y:351.5}).wait(1).to({graphics:mask_1_graphics_643,x:1020.3,y:351.5}).wait(1).to({graphics:mask_1_graphics_644,x:1020.8,y:351.5}).wait(1).to({graphics:mask_1_graphics_645,x:1021.3,y:351.5}).wait(1).to({graphics:mask_1_graphics_646,x:1021.8,y:351.5}).wait(1).to({graphics:mask_1_graphics_647,x:1022.3,y:351.5}).wait(1).to({graphics:mask_1_graphics_648,x:1022.8,y:351.5}).wait(1).to({graphics:mask_1_graphics_649,x:1023.3,y:351.5}).wait(1).to({graphics:mask_1_graphics_650,x:1023.9,y:351.5}).wait(1).to({graphics:mask_1_graphics_651,x:1024.4,y:351.5}).wait(1).to({graphics:mask_1_graphics_652,x:1024.9,y:351.5}).wait(1).to({graphics:mask_1_graphics_653,x:1025.4,y:351.5}).wait(1).to({graphics:mask_1_graphics_654,x:1025.9,y:351.5}).wait(1).to({graphics:mask_1_graphics_655,x:1026.5,y:351.5}).wait(1).to({graphics:mask_1_graphics_656,x:1027,y:351.5}).wait(1).to({graphics:mask_1_graphics_657,x:1027.5,y:351.5}).wait(1).to({graphics:mask_1_graphics_658,x:1028,y:351.5}).wait(1).to({graphics:mask_1_graphics_659,x:1028.5,y:351.5}).wait(1).to({graphics:mask_1_graphics_660,x:1029.1,y:351.5}).wait(1).to({graphics:mask_1_graphics_661,x:1029.6,y:351.5}).wait(1).to({graphics:mask_1_graphics_662,x:1030.1,y:351.5}).wait(1).to({graphics:mask_1_graphics_663,x:1030.6,y:351.5}).wait(1).to({graphics:mask_1_graphics_664,x:1031.1,y:351.5}).wait(1).to({graphics:mask_1_graphics_665,x:1031.6,y:351.5}).wait(1).to({graphics:mask_1_graphics_666,x:1032.2,y:351.5}).wait(1).to({graphics:mask_1_graphics_667,x:1032.7,y:351.5}).wait(1).to({graphics:mask_1_graphics_668,x:1033.2,y:351.5}).wait(1).to({graphics:mask_1_graphics_669,x:1033.7,y:351.5}).wait(1).to({graphics:mask_1_graphics_670,x:1034.2,y:351.5}).wait(1).to({graphics:mask_1_graphics_671,x:1034.7,y:351.5}).wait(1).to({graphics:mask_1_graphics_672,x:1035.2,y:351.5}).wait(1).to({graphics:mask_1_graphics_673,x:1035.8,y:351.5}).wait(1).to({graphics:mask_1_graphics_674,x:1036.3,y:351.5}).wait(1).to({graphics:mask_1_graphics_675,x:1036.8,y:351.5}).wait(1).to({graphics:mask_1_graphics_676,x:1037.3,y:351.5}).wait(1).to({graphics:mask_1_graphics_677,x:1037.8,y:351.5}).wait(1).to({graphics:mask_1_graphics_678,x:1038.4,y:351.5}).wait(1).to({graphics:mask_1_graphics_679,x:1038.9,y:351.5}).wait(1).to({graphics:mask_1_graphics_680,x:1039.4,y:351.5}).wait(1).to({graphics:mask_1_graphics_681,x:1039.9,y:351.5}).wait(1).to({graphics:mask_1_graphics_682,x:1040.4,y:351.5}).wait(1).to({graphics:mask_1_graphics_683,x:1041,y:351.5}).wait(1).to({graphics:mask_1_graphics_684,x:1041.5,y:351.5}).wait(1).to({graphics:mask_1_graphics_685,x:1042,y:351.5}).wait(1).to({graphics:mask_1_graphics_686,x:1042.5,y:351.5}).wait(1).to({graphics:mask_1_graphics_687,x:1043,y:351.5}).wait(1).to({graphics:mask_1_graphics_688,x:1043.6,y:351.5}).wait(1).to({graphics:mask_1_graphics_689,x:1044.1,y:351.5}).wait(1).to({graphics:mask_1_graphics_690,x:1044.6,y:351.5}).wait(1).to({graphics:mask_1_graphics_691,x:1045.1,y:351.5}).wait(1).to({graphics:mask_1_graphics_692,x:1045.6,y:351.5}).wait(1).to({graphics:mask_1_graphics_693,x:1046.1,y:351.5}).wait(1).to({graphics:mask_1_graphics_694,x:1046.7,y:351.5}).wait(1).to({graphics:mask_1_graphics_695,x:1047.2,y:351.5}).wait(1).to({graphics:mask_1_graphics_696,x:1047.7,y:351.5}).wait(1).to({graphics:mask_1_graphics_697,x:1048.2,y:351.5}).wait(1).to({graphics:mask_1_graphics_698,x:1048.7,y:351.5}).wait(1).to({graphics:mask_1_graphics_699,x:1049.2,y:351.5}).wait(1).to({graphics:mask_1_graphics_700,x:1049.8,y:351.5}).wait(1).to({graphics:mask_1_graphics_701,x:1050.3,y:351.5}).wait(1).to({graphics:mask_1_graphics_702,x:1050.8,y:351.5}).wait(1).to({graphics:mask_1_graphics_703,x:1051.3,y:351.5}).wait(1).to({graphics:mask_1_graphics_704,x:1051.8,y:351.5}).wait(1).to({graphics:mask_1_graphics_705,x:1052.4,y:351.5}).wait(1).to({graphics:mask_1_graphics_706,x:1052.9,y:351.5}).wait(1).to({graphics:mask_1_graphics_707,x:1053.4,y:351.5}).wait(1).to({graphics:mask_1_graphics_708,x:1053.9,y:351.5}).wait(1).to({graphics:mask_1_graphics_709,x:1054.4,y:351.5}).wait(1).to({graphics:mask_1_graphics_710,x:1054.9,y:351.5}).wait(1).to({graphics:mask_1_graphics_711,x:1055.5,y:351.5}).wait(1).to({graphics:mask_1_graphics_712,x:1056,y:351.5}).wait(1).to({graphics:mask_1_graphics_713,x:1056.5,y:351.5}).wait(1).to({graphics:mask_1_graphics_714,x:1057,y:351.5}).wait(1).to({graphics:mask_1_graphics_715,x:1057.5,y:351.5}).wait(1).to({graphics:mask_1_graphics_716,x:1058,y:351.5}).wait(1).to({graphics:mask_1_graphics_717,x:1058.5,y:351.5}).wait(1).to({graphics:mask_1_graphics_718,x:1059.1,y:351.5}).wait(1).to({graphics:mask_1_graphics_719,x:1059.6,y:351.5}).wait(1).to({graphics:mask_1_graphics_720,x:1060.1,y:351.5}).wait(1).to({graphics:mask_1_graphics_721,x:1060.6,y:351.5}).wait(1).to({graphics:mask_1_graphics_722,x:1061.1,y:351.5}).wait(1).to({graphics:mask_1_graphics_723,x:1061.7,y:351.5}).wait(1).to({graphics:mask_1_graphics_724,x:1062.2,y:351.5}).wait(1).to({graphics:mask_1_graphics_725,x:1062.7,y:351.5}).wait(1).to({graphics:mask_1_graphics_726,x:1063.2,y:351.5}).wait(1).to({graphics:mask_1_graphics_727,x:1063.7,y:351.5}).wait(1).to({graphics:mask_1_graphics_728,x:1064.3,y:351.5}).wait(1).to({graphics:mask_1_graphics_729,x:1064.8,y:351.5}).wait(1).to({graphics:mask_1_graphics_730,x:1065.3,y:351.5}).wait(1).to({graphics:mask_1_graphics_731,x:1065.8,y:351.5}).wait(1).to({graphics:mask_1_graphics_732,x:1066.3,y:351.5}).wait(1).to({graphics:mask_1_graphics_733,x:1066.8,y:351.5}).wait(1).to({graphics:mask_1_graphics_734,x:1067.4,y:351.5}).wait(1).to({graphics:mask_1_graphics_735,x:1067.9,y:351.5}).wait(1).to({graphics:mask_1_graphics_736,x:1068.4,y:351.5}).wait(1).to({graphics:mask_1_graphics_737,x:1068.9,y:351.5}).wait(1).to({graphics:mask_1_graphics_738,x:1069.4,y:351.5}).wait(1).to({graphics:mask_1_graphics_739,x:1069.9,y:351.5}).wait(1).to({graphics:mask_1_graphics_740,x:1070.5,y:351.5}).wait(1).to({graphics:mask_1_graphics_741,x:1071,y:351.5}).wait(1).to({graphics:mask_1_graphics_742,x:1071.5,y:351.5}).wait(1).to({graphics:mask_1_graphics_743,x:1072,y:351.5}).wait(1).to({graphics:mask_1_graphics_744,x:1072.5,y:351.5}).wait(1).to({graphics:mask_1_graphics_745,x:1073.1,y:351.5}).wait(1).to({graphics:mask_1_graphics_746,x:1073.6,y:351.5}).wait(1).to({graphics:mask_1_graphics_747,x:1074.1,y:351.5}).wait(1).to({graphics:mask_1_graphics_748,x:1074.6,y:351.5}).wait(1).to({graphics:mask_1_graphics_749,x:1075.1,y:351.5}).wait(1).to({graphics:mask_1_graphics_750,x:1075.7,y:351.5}).wait(1).to({graphics:mask_1_graphics_751,x:1076.2,y:351.5}).wait(1).to({graphics:mask_1_graphics_752,x:1076.7,y:351.5}).wait(1).to({graphics:mask_1_graphics_753,x:1077.2,y:351.5}).wait(1).to({graphics:mask_1_graphics_754,x:1077.7,y:351.5}).wait(1).to({graphics:mask_1_graphics_755,x:1078.2,y:351.5}).wait(1).to({graphics:mask_1_graphics_756,x:1078.8,y:351.5}).wait(1).to({graphics:mask_1_graphics_757,x:1079.3,y:351.5}).wait(1).to({graphics:mask_1_graphics_758,x:1079.8,y:351.5}).wait(1).to({graphics:mask_1_graphics_759,x:1080.3,y:351.5}).wait(1).to({graphics:mask_1_graphics_760,x:1080.8,y:351.5}).wait(1).to({graphics:mask_1_graphics_761,x:1081.3,y:351.5}).wait(1).to({graphics:mask_1_graphics_762,x:1081.8,y:351.5}).wait(1).to({graphics:mask_1_graphics_763,x:1082.4,y:351.5}).wait(1).to({graphics:mask_1_graphics_764,x:1082.9,y:351.5}).wait(1).to({graphics:mask_1_graphics_765,x:1083.4,y:351.5}).wait(1).to({graphics:mask_1_graphics_766,x:1083.9,y:351.5}).wait(1).to({graphics:mask_1_graphics_767,x:1084.4,y:351.5}).wait(1).to({graphics:mask_1_graphics_768,x:1085,y:351.5}).wait(1).to({graphics:mask_1_graphics_769,x:1085.5,y:351.5}).wait(1).to({graphics:mask_1_graphics_770,x:1086,y:351.5}).wait(1).to({graphics:mask_1_graphics_771,x:1086.5,y:351.5}).wait(1).to({graphics:mask_1_graphics_772,x:1087,y:351.5}).wait(1).to({graphics:mask_1_graphics_773,x:1087.6,y:351.5}).wait(1).to({graphics:mask_1_graphics_774,x:1088.1,y:351.5}).wait(1).to({graphics:mask_1_graphics_775,x:1088.6,y:351.5}).wait(1).to({graphics:mask_1_graphics_776,x:1089.1,y:351.5}).wait(1).to({graphics:mask_1_graphics_777,x:1089.6,y:351.5}).wait(1).to({graphics:mask_1_graphics_778,x:1090.1,y:351.5}).wait(1).to({graphics:mask_1_graphics_779,x:1090.7,y:351.5}).wait(1).to({graphics:mask_1_graphics_780,x:1091.2,y:351.5}).wait(1).to({graphics:mask_1_graphics_781,x:1091.7,y:351.5}).wait(1).to({graphics:mask_1_graphics_782,x:1092.2,y:351.5}).wait(1).to({graphics:mask_1_graphics_783,x:1092.7,y:351.5}).wait(1).to({graphics:mask_1_graphics_784,x:1093.2,y:351.5}).wait(1).to({graphics:mask_1_graphics_785,x:1093.8,y:351.5}).wait(1).to({graphics:mask_1_graphics_786,x:1094.3,y:351.5}).wait(1).to({graphics:mask_1_graphics_787,x:1094.8,y:351.5}).wait(1).to({graphics:mask_1_graphics_788,x:1095.3,y:351.5}).wait(1).to({graphics:mask_1_graphics_789,x:1095.8,y:351.5}).wait(1).to({graphics:mask_1_graphics_790,x:1096.4,y:351.5}).wait(1).to({graphics:mask_1_graphics_791,x:1096.9,y:351.5}).wait(1).to({graphics:mask_1_graphics_792,x:1097.4,y:351.5}).wait(1).to({graphics:mask_1_graphics_793,x:1097.9,y:351.5}).wait(1).to({graphics:mask_1_graphics_794,x:1098.4,y:351.5}).wait(1).to({graphics:mask_1_graphics_795,x:1099,y:351.5}).wait(1).to({graphics:mask_1_graphics_796,x:1099.5,y:351.5}).wait(1).to({graphics:mask_1_graphics_797,x:1100,y:351.5}).wait(1).to({graphics:mask_1_graphics_798,x:1100.5,y:351.5}).wait(1).to({graphics:mask_1_graphics_799,x:1101,y:351.5}).wait(1).to({graphics:mask_1_graphics_800,x:1101.5,y:351.5}).wait(1).to({graphics:mask_1_graphics_801,x:1102.1,y:351.5}).wait(1).to({graphics:mask_1_graphics_802,x:1102.6,y:351.5}).wait(1).to({graphics:mask_1_graphics_803,x:1103.1,y:351.5}).wait(1).to({graphics:mask_1_graphics_804,x:1103.6,y:351.5}).wait(1).to({graphics:mask_1_graphics_805,x:1104.1,y:351.5}).wait(1).to({graphics:mask_1_graphics_806,x:1104.6,y:351.5}).wait(1).to({graphics:mask_1_graphics_807,x:1105.1,y:351.5}).wait(1).to({graphics:mask_1_graphics_808,x:1105.7,y:351.5}).wait(1).to({graphics:mask_1_graphics_809,x:1106.2,y:351.5}).wait(1).to({graphics:mask_1_graphics_810,x:1106.7,y:351.5}).wait(1).to({graphics:mask_1_graphics_811,x:1107.2,y:351.5}).wait(1).to({graphics:mask_1_graphics_812,x:1107.7,y:351.5}).wait(1).to({graphics:mask_1_graphics_813,x:1108.3,y:351.5}).wait(1).to({graphics:mask_1_graphics_814,x:1108.8,y:351.5}).wait(1).to({graphics:mask_1_graphics_815,x:1109.3,y:351.5}).wait(1).to({graphics:mask_1_graphics_816,x:1109.8,y:351.5}).wait(1).to({graphics:mask_1_graphics_817,x:1110.3,y:351.5}).wait(1).to({graphics:mask_1_graphics_818,x:1110.9,y:351.5}).wait(1).to({graphics:mask_1_graphics_819,x:1111.4,y:351.5}).wait(1).to({graphics:mask_1_graphics_820,x:1111.9,y:351.5}).wait(1).to({graphics:mask_1_graphics_821,x:1112.4,y:351.5}).wait(1).to({graphics:mask_1_graphics_822,x:1112.9,y:351.5}).wait(1).to({graphics:mask_1_graphics_823,x:1113.4,y:351.5}).wait(1).to({graphics:mask_1_graphics_824,x:1114,y:351.5}).wait(1).to({graphics:mask_1_graphics_825,x:1114.5,y:351.5}).wait(1).to({graphics:mask_1_graphics_826,x:1115,y:351.5}).wait(1).to({graphics:mask_1_graphics_827,x:1115.5,y:351.5}).wait(1).to({graphics:mask_1_graphics_828,x:1116,y:351.5}).wait(1).to({graphics:mask_1_graphics_829,x:1116.5,y:351.5}).wait(1).to({graphics:mask_1_graphics_830,x:1117.1,y:351.5}).wait(1).to({graphics:mask_1_graphics_831,x:1117.6,y:351.5}).wait(1).to({graphics:mask_1_graphics_832,x:1118.1,y:351.5}).wait(1).to({graphics:mask_1_graphics_833,x:1118.6,y:351.5}).wait(1).to({graphics:mask_1_graphics_834,x:1119.1,y:351.5}).wait(1).to({graphics:mask_1_graphics_835,x:1119.7,y:351.5}).wait(1).to({graphics:mask_1_graphics_836,x:1120.2,y:351.5}).wait(1).to({graphics:mask_1_graphics_837,x:1120.7,y:351.5}).wait(1).to({graphics:mask_1_graphics_838,x:1121.2,y:351.5}).wait(1).to({graphics:mask_1_graphics_839,x:1121.7,y:351.5}).wait(1).to({graphics:mask_1_graphics_840,x:1122.3,y:351.5}).wait(1).to({graphics:mask_1_graphics_841,x:1122.8,y:351.5}).wait(1).to({graphics:mask_1_graphics_842,x:1123.3,y:351.5}).wait(1).to({graphics:mask_1_graphics_843,x:1123.8,y:351.5}).wait(1).to({graphics:mask_1_graphics_844,x:1124.3,y:351.5}).wait(1).to({graphics:mask_1_graphics_845,x:1124.8,y:351.5}).wait(1).to({graphics:mask_1_graphics_846,x:1125.4,y:351.5}).wait(1).to({graphics:mask_1_graphics_847,x:1125.9,y:351.5}).wait(1).to({graphics:mask_1_graphics_848,x:1126.4,y:351.5}).wait(1).to({graphics:mask_1_graphics_849,x:1126.9,y:351.5}).wait(1).to({graphics:mask_1_graphics_850,x:1127.4,y:351.5}).wait(1).to({graphics:mask_1_graphics_851,x:1127.9,y:351.5}).wait(1).to({graphics:mask_1_graphics_852,x:1128.5,y:351.5}).wait(1).to({graphics:mask_1_graphics_853,x:1129,y:351.5}).wait(1).to({graphics:mask_1_graphics_854,x:1129.5,y:351.5}).wait(1).to({graphics:mask_1_graphics_855,x:1130,y:351.5}).wait(1).to({graphics:mask_1_graphics_856,x:1130.5,y:351.5}).wait(1).to({graphics:mask_1_graphics_857,x:1131,y:351.5}).wait(1).to({graphics:mask_1_graphics_858,x:1131.6,y:351.5}).wait(1).to({graphics:mask_1_graphics_859,x:1132.1,y:351.5}).wait(1).to({graphics:mask_1_graphics_860,x:1132.6,y:351.5}).wait(1).to({graphics:mask_1_graphics_861,x:1133.1,y:351.5}).wait(1).to({graphics:mask_1_graphics_862,x:1133.6,y:351.5}).wait(1).to({graphics:mask_1_graphics_863,x:1134.2,y:351.5}).wait(1).to({graphics:mask_1_graphics_864,x:1134.7,y:351.5}).wait(1).to({graphics:mask_1_graphics_865,x:1135.2,y:351.5}).wait(1).to({graphics:mask_1_graphics_866,x:1135.7,y:351.5}).wait(1).to({graphics:mask_1_graphics_867,x:1136.2,y:351.5}).wait(1).to({graphics:mask_1_graphics_868,x:1136.7,y:351.5}).wait(1).to({graphics:mask_1_graphics_869,x:1137.3,y:351.5}).wait(1).to({graphics:mask_1_graphics_870,x:1137.8,y:351.5}).wait(1).to({graphics:mask_1_graphics_871,x:1138.3,y:351.5}).wait(1).to({graphics:mask_1_graphics_872,x:1138.8,y:351.5}).wait(1).to({graphics:mask_1_graphics_873,x:1139.3,y:351.5}).wait(1).to({graphics:mask_1_graphics_874,x:1139.8,y:351.5}).wait(1).to({graphics:mask_1_graphics_875,x:1140.3,y:351.5}).wait(1).to({graphics:mask_1_graphics_876,x:1140.9,y:351.5}).wait(1).to({graphics:mask_1_graphics_877,x:1141.4,y:351.5}).wait(1).to({graphics:mask_1_graphics_878,x:1141.9,y:351.5}).wait(1).to({graphics:mask_1_graphics_879,x:1142.4,y:351.5}).wait(1).to({graphics:mask_1_graphics_880,x:1142.9,y:351.5}).wait(1).to({graphics:mask_1_graphics_881,x:1143.5,y:351.5}).wait(1).to({graphics:mask_1_graphics_882,x:1144,y:351.5}).wait(1).to({graphics:mask_1_graphics_883,x:1144.5,y:351.5}).wait(1).to({graphics:mask_1_graphics_884,x:1145,y:351.5}).wait(1).to({graphics:mask_1_graphics_885,x:1145.5,y:351.5}).wait(1).to({graphics:mask_1_graphics_886,x:1146.1,y:351.5}).wait(1).to({graphics:mask_1_graphics_887,x:1146.6,y:351.5}).wait(1).to({graphics:mask_1_graphics_888,x:1147.1,y:351.5}).wait(1).to({graphics:mask_1_graphics_889,x:1147.6,y:351.5}).wait(1).to({graphics:mask_1_graphics_890,x:1148.1,y:351.5}).wait(1).to({graphics:mask_1_graphics_891,x:1148.6,y:351.5}).wait(1).to({graphics:mask_1_graphics_892,x:1149.2,y:351.5}).wait(1).to({graphics:mask_1_graphics_893,x:1149.7,y:351.5}).wait(1).to({graphics:mask_1_graphics_894,x:1150.2,y:351.5}).wait(1).to({graphics:mask_1_graphics_895,x:1150.7,y:351.5}).wait(1).to({graphics:mask_1_graphics_896,x:1151.2,y:351.5}).wait(1).to({graphics:mask_1_graphics_897,x:1151.7,y:351.5}).wait(1).to({graphics:mask_1_graphics_898,x:1152.3,y:351.5}).wait(1).to({graphics:mask_1_graphics_899,x:1152.8,y:351.5}).wait(1).to({graphics:mask_1_graphics_900,x:1153.3,y:351.5}).wait(1).to({graphics:mask_1_graphics_901,x:1153.8,y:351.5}).wait(1).to({graphics:mask_1_graphics_902,x:1154.3,y:351.5}).wait(1).to({graphics:mask_1_graphics_903,x:1154.9,y:351.5}).wait(1).to({graphics:mask_1_graphics_904,x:1155.4,y:351.5}).wait(1).to({graphics:mask_1_graphics_905,x:1155.9,y:351.5}).wait(1).to({graphics:mask_1_graphics_906,x:1156.4,y:351.5}).wait(1).to({graphics:mask_1_graphics_907,x:1156.9,y:351.5}).wait(1).to({graphics:mask_1_graphics_908,x:1157.5,y:351.5}).wait(1).to({graphics:mask_1_graphics_909,x:1158,y:351.5}).wait(1).to({graphics:mask_1_graphics_910,x:1158.5,y:351.5}).wait(1).to({graphics:mask_1_graphics_911,x:1159,y:351.5}).wait(1).to({graphics:mask_1_graphics_912,x:1159.5,y:351.5}).wait(1).to({graphics:mask_1_graphics_913,x:1160,y:351.5}).wait(1).to({graphics:mask_1_graphics_914,x:1160.6,y:351.5}).wait(1).to({graphics:mask_1_graphics_915,x:1161.1,y:351.5}).wait(1).to({graphics:mask_1_graphics_916,x:1161.6,y:351.5}).wait(1).to({graphics:mask_1_graphics_917,x:1162.1,y:351.5}).wait(1).to({graphics:mask_1_graphics_918,x:1162.6,y:351.5}).wait(1).to({graphics:mask_1_graphics_919,x:1163.1,y:351.5}).wait(1).to({graphics:mask_1_graphics_920,x:1163.6,y:351.5}).wait(1).to({graphics:mask_1_graphics_921,x:1164.2,y:351.5}).wait(1).to({graphics:mask_1_graphics_922,x:1164.7,y:351.5}).wait(1).to({graphics:mask_1_graphics_923,x:1165.2,y:351.5}).wait(1).to({graphics:mask_1_graphics_924,x:1165.7,y:351.5}).wait(1).to({graphics:mask_1_graphics_925,x:1166.2,y:351.5}).wait(1).to({graphics:mask_1_graphics_926,x:1166.8,y:351.5}).wait(1).to({graphics:mask_1_graphics_927,x:1167.3,y:351.5}).wait(1).to({graphics:mask_1_graphics_928,x:1167.8,y:351.5}).wait(1).to({graphics:mask_1_graphics_929,x:1168.3,y:351.5}).wait(1).to({graphics:mask_1_graphics_930,x:1168.8,y:351.5}).wait(1).to({graphics:mask_1_graphics_931,x:1169.4,y:351.5}).wait(1).to({graphics:mask_1_graphics_932,x:1169.9,y:351.5}).wait(1).to({graphics:mask_1_graphics_933,x:1170.4,y:351.5}).wait(1).to({graphics:mask_1_graphics_934,x:1170.9,y:351.5}).wait(1).to({graphics:mask_1_graphics_935,x:1171.4,y:351.5}).wait(1).to({graphics:mask_1_graphics_936,x:1171.9,y:351.5}).wait(1).to({graphics:mask_1_graphics_937,x:1172.5,y:351.5}).wait(1).to({graphics:mask_1_graphics_938,x:1173,y:351.5}).wait(1).to({graphics:mask_1_graphics_939,x:1173.5,y:351.5}).wait(1).to({graphics:mask_1_graphics_940,x:1174,y:351.5}).wait(1).to({graphics:mask_1_graphics_941,x:1174.5,y:351.5}).wait(1).to({graphics:mask_1_graphics_942,x:1175,y:351.5}).wait(1).to({graphics:mask_1_graphics_943,x:1175.6,y:351.5}).wait(1).to({graphics:mask_1_graphics_944,x:1176.1,y:351.5}).wait(1).to({graphics:mask_1_graphics_945,x:1176.6,y:351.5}).wait(1).to({graphics:mask_1_graphics_946,x:1177.1,y:351.5}).wait(1).to({graphics:mask_1_graphics_947,x:1177.6,y:351.5}).wait(1).to({graphics:mask_1_graphics_948,x:1178.2,y:351.5}).wait(1).to({graphics:mask_1_graphics_949,x:1178.7,y:351.5}).wait(1).to({graphics:mask_1_graphics_950,x:1179.2,y:351.5}).wait(1).to({graphics:mask_1_graphics_951,x:1179.7,y:351.5}).wait(1).to({graphics:mask_1_graphics_952,x:1180.2,y:351.5}).wait(1).to({graphics:mask_1_graphics_953,x:1180.8,y:351.5}).wait(1).to({graphics:mask_1_graphics_954,x:1181.3,y:351.5}).wait(1).to({graphics:mask_1_graphics_955,x:1181.8,y:351.5}).wait(1).to({graphics:mask_1_graphics_956,x:1182.3,y:351.5}).wait(1).to({graphics:mask_1_graphics_957,x:1182.8,y:351.5}).wait(1).to({graphics:mask_1_graphics_958,x:1183.3,y:351.5}).wait(1).to({graphics:mask_1_graphics_959,x:1183.9,y:351.5}).wait(1).to({graphics:mask_1_graphics_960,x:1184.4,y:351.5}).wait(1).to({graphics:mask_1_graphics_961,x:1184.9,y:351.5}).wait(1).to({graphics:mask_1_graphics_962,x:1185.4,y:351.5}).wait(1).to({graphics:mask_1_graphics_963,x:1185.9,y:351.5}).wait(1).to({graphics:mask_1_graphics_964,x:1186.4,y:351.5}).wait(1).to({graphics:mask_1_graphics_965,x:1187,y:351.5}).wait(1).to({graphics:mask_1_graphics_966,x:1187.5,y:351.5}).wait(1).to({graphics:mask_1_graphics_967,x:1188,y:351.5}).wait(1).to({graphics:mask_1_graphics_968,x:1188.5,y:351.5}).wait(1).to({graphics:mask_1_graphics_969,x:1189,y:351.5}).wait(1).to({graphics:mask_1_graphics_970,x:1189.5,y:351.5}).wait(1).to({graphics:mask_1_graphics_971,x:1190.1,y:351.5}).wait(1).to({graphics:mask_1_graphics_972,x:1190.6,y:351.5}).wait(1).to({graphics:mask_1_graphics_973,x:1191.1,y:351.5}).wait(1).to({graphics:mask_1_graphics_974,x:1191.6,y:351.5}).wait(1).to({graphics:mask_1_graphics_975,x:1192.1,y:351.5}).wait(1).to({graphics:mask_1_graphics_976,x:1192.7,y:351.5}).wait(1).to({graphics:mask_1_graphics_977,x:1193.2,y:351.5}).wait(1).to({graphics:mask_1_graphics_978,x:1193.7,y:351.5}).wait(1).to({graphics:mask_1_graphics_979,x:1194.2,y:351.5}).wait(1).to({graphics:mask_1_graphics_980,x:1194.7,y:351.5}).wait(1).to({graphics:mask_1_graphics_981,x:1195.2,y:351.5}).wait(1).to({graphics:mask_1_graphics_982,x:1195.8,y:351.5}).wait(1).to({graphics:mask_1_graphics_983,x:1196.3,y:351.5}).wait(1).to({graphics:mask_1_graphics_984,x:1196.8,y:351.5}).wait(1).to({graphics:mask_1_graphics_985,x:1197.3,y:351.5}).wait(1).to({graphics:mask_1_graphics_986,x:1197.8,y:351.5}).wait(1).to({graphics:mask_1_graphics_987,x:1198.3,y:351.5}).wait(1).to({graphics:mask_1_graphics_988,x:1198.9,y:351.5}).wait(1).to({graphics:mask_1_graphics_989,x:1199.4,y:351.5}).wait(1).to({graphics:mask_1_graphics_990,x:1199.9,y:351.5}).wait(1).to({graphics:mask_1_graphics_991,x:1200.4,y:351.5}).wait(1).to({graphics:mask_1_graphics_992,x:1200.9,y:351.5}).wait(1).to({graphics:mask_1_graphics_993,x:1201.5,y:351.5}).wait(1).to({graphics:mask_1_graphics_994,x:1202,y:351.5}).wait(1).to({graphics:mask_1_graphics_995,x:1202.5,y:351.5}).wait(1).to({graphics:mask_1_graphics_996,x:1203,y:351.5}).wait(1).to({graphics:mask_1_graphics_997,x:1203.5,y:351.5}).wait(1).to({graphics:mask_1_graphics_998,x:1204.1,y:351.5}).wait(1).to({graphics:mask_1_graphics_999,x:1204.6,y:351.5}).wait(1));

	// container_text
	this.instance_6 = new lib.container_text("single",3);
	this.instance_6.setTransform(997,802.8,1,1,0,0,0,548,182.8);

	this.instance_6.mask = mask_1;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(1000));

	// Ebene 2
	this.instance_7 = new lib.pic_shadow_occlusionRound();
	this.instance_7.setTransform(648.9,713.9,2.757,1);
	this.instance_7.alpha = 0.5;

	this.instance_8 = new lib.pic_shadow_occlusionRound();
	this.instance_8.setTransform(472.9,708.9,2.757,1);
	this.instance_8.alpha = 0.5;

	this.instance_9 = new lib.pic_shadow_occlusionRound();
	this.instance_9.setTransform(641.7,659.9,2.757,1);
	this.instance_9.alpha = 0.5;

	this.instance_10 = new lib.pic_shadow_occlusionRound();
	this.instance_10.setTransform(562.7,659.9,2.757,1);
	this.instance_10.alpha = 0.5;

	this.instance_7.mask = this.instance_8.mask = this.instance_9.mask = this.instance_10.mask = mask_1;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7}]}).wait(1000));

	// container_pics
	this.clickPopup_4 = new lib.button_general();
	this.clickPopup_4.setTransform(441,418.4);

	this.clickPopup_1 = new lib.button_general();
	this.clickPopup_1.setTransform(752,281.4);

	this.clickPopup_3 = new lib.button_general();
	this.clickPopup_3.setTransform(792,561.7);

	this.clickPopup_2 = new lib.button_general();
	this.clickPopup_2.setTransform(742.9,461.4);

	this.instance_11 = new lib.container_pics("single",1);

	this.clickPopup_4.mask = this.clickPopup_1.mask = this.clickPopup_3.mask = this.clickPopup_2.mask = this.instance_11.mask = mask_1;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_11},{t:this.clickPopup_2},{t:this.clickPopup_3},{t:this.clickPopup_1},{t:this.clickPopup_4}]}).wait(1000));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,-62.3,1642.3,765.4);


(lib.slider_grip01 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAmBnIhnhnIBnhmIAcAAIhmBmIBmBng");
	this.shape.setTransform(16.5,325.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AhBBnIBmhnIhmhmIAcAAIBnBmIhnBng");
	this.shape_1.setTransform(36.5,325.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#D5001C").s().p("AAADWQhXABg/hAIAAAAQg/g+AAhZQgBhXBAhAQA/g+BXgBIAHABIACAAQBTADA7A7QA/BAAABXQAABZg/A+Qg7A8hUADIgIAAg");
	this.shape_2.setTransform(26.5,325.5);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("rgba(255,255,255,0.698)").s().p("AAKEJIgKAAQhsAAhNhOIAAAAQhPhOAAhtQAAhsBPhOQBMhNBtAAIAMABIgBgBQBmADBKBKQBOBOAABsQAABthOBOIgBAAQhJBJhmAFgAiWiXQhABAABBXQAABZA/A+IAAAAQA/BABXgBIAIAAQBUgDA7g8QA/g+AAhZQAAhXg/hAQg7g7hTgDIgCAAIgHgBQhXABg/A+g");
	this.shape_3.setTransform(26.5,325.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Ebene 3
	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().ls(["rgba(115,114,120,0)","#737278","#737278","rgba(115,114,120,0)"],[0.09,0.396,0.718,1],0,-266.9,0,229.9).ss(2,0,0,3).p("EAAAgkjMAAABJH");
	this.shape_4.setTransform(26.5,406);

	this.timeline.addTween(cjs.Tween.get(this.shape_4).wait(1));

	// Ebene 1
	this.instance = new lib.ani_highlight_sliderHandle();
	this.instance.setTransform(26.5,325.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,171,53,470);


(lib.slider_filters = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.dispatchEvent(new createjs.Event("RESET"),true);
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// nextBtn
	this.nextBtn = new lib.PreviousBtn_dark();
	this.nextBtn.setTransform(520.5,183.5,0.6,0.6,0,0,180,27.5,62.6);
	new cjs.ButtonHelper(this.nextBtn, 0, 1, 2, false, new lib.PreviousBtn_dark(), 3);

	this.timeline.addTween(cjs.Tween.get(this.nextBtn).wait(1));

	// prevBtn
	this.prevBtn = new lib.PreviousBtn_dark();
	this.prevBtn.setTransform(27.6,183.5,0.6,0.6,0,0,0,27.6,62.6);
	new cjs.ButtonHelper(this.prevBtn, 0, 1, 2, false, new lib.PreviousBtn_dark(), 3);

	this.timeline.addTween(cjs.Tween.get(this.prevBtn).wait(1));

	// Ebene 1
	this.slideShowContent = new lib.ani_slider_filters();
	this.slideShowContent.setTransform(275,225,1,1,0,0,0,275,225);

	this.timeline.addTween(cjs.Tween.get(this.slideShowContent).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,550,450);


(lib.popup04 = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// Ebene 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgOA3QgGgDgDgFQgEgFgCgIQgBgIAAgLQAAgTAHgKQAIgKAPAAQANAAAFAKIAAgqIANAAIAABwIgMAAIAAgMQgGANgOAAQgIAAgFgCgAgHgLQgEABgCAEQgCADgBAEIgBAOIABAPQABAGACAEQACADAEACQADABAEAAQAFAAADgBQAEgCACgDQACgEABgGIABgPIgBgOQgBgEgCgDQgCgEgEgBIgIgBIgHABg");
	this.shape.setTransform(1405.8,153.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgVAjQgGgFAAgKQAAgHACgEQADgEAEgDQAEgCAFgBIAMgEIAMgCIAAgFQAAgIgDgFQgDgEgJAAQgGAAgEADQgDAEAAAJIgMAAQABgNAGgHQAGgHAOAAQAHAAAFACQAFACADADQADAEABAFQACAFAAAGIAAA1IgNAAIAAgKQgCAEgFAEQgFADgGAAQgMAAgGgGgAAEADIgIACIgGAEQgCABgBADIgBAFQAAANAOAAQAGAAAEgFQAFgFAAgIIAAgLg");
	this.shape_1.setTransform(1398.1,155);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgRAoIAAg3QAAgLAGgHQAGgGAKAAIANAAIAAALIgMAAQgKAAAAAMIAAA4g");
	this.shape_2.setTransform(1392.6,155);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AAQA4IgVglIgLAMIAAAZIgMAAIAAhvIAMAAIAABHIAfgmIAOAAIgcAgIAcAug");
	this.shape_3.setTransform(1386.6,153.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AAQAoIAAgwQAAgLgEgEQgEgEgIgBQgGABgFAEQgEADAAAMIAAAwIgNAAIAAhOIANAAIAAAKQAEgLAOgBQANABAGAHQAHAHAAANIAAA0g");
	this.shape_4.setTransform(1378.5,155);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AgMAnQgFgDgFgFQgDgFgCgIQgCgIAAgKQAAgVAHgJQAIgKAPAAQAIAAAFACQAGADADAFQAEAFACAHQABAIAAAJIAAACIguAAIABAPQABAGACADQACADAFABIAGABQAIAAAEgDQAEgDABgIIAMAAQgCAMgGAGQgHAHgOAAQgHAAgGgCgAgFgcQgDABgDADIgDAGIgCALIAiAAQAAgHgCgEQgBgEgCgCQgCgDgDgBIgIAAIgFAAg");
	this.shape_5.setTransform(1370.8,155);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgFA4IAAhvIALAAIAABvg");
	this.shape_6.setTransform(1365.3,153.4);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AALAxQgWAAAAgZIAAgqIgLAAIAAgLIALAAIAAgUIALAAIAAAUIAXAAIAAALIgXAAIAAAqQAAAIACAEQADADAIAAIAKAAIAAAKg");
	this.shape_7.setTransform(1360.9,154.1);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AgRAoIAAg3QAAgLAGgHQAHgGAJAAIANAAIAAALIgMAAQgKAAAAAMIAAA4g");
	this.shape_8.setTransform(1356.1,155);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AgNAnQgGgDgEgFQgEgFgBgIQgCgIAAgKQAAgJACgIQABgIAEgFQAEgFAGgDQAGgCAHAAQAIAAAGACQAGADAEAFQAEAFACAIQABAIAAAJQAAAVgHAKQgIAKgQAAQgHAAgGgCgAgHgbQgEABgCAEQgCADgBAGIgBANIABAOQABAGACAEQACADAEACQADABAEAAQAFAAADgBQAEgCACgDQACgEABgGIABgOIgBgNQgBgGgCgDQgCgEgEgBIgIgBIgHABg");
	this.shape_9.setTransform(1349.4,155);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AgeA5IAAhwIAMAAIAAALQAGgMANAAQAIAAAGACQAFADAEAFQAEAFABAIQACAIAAAKQAAAUgHAKQgIAKgQAAQgMAAgGgKIAAAqgAgHgrQgDABgDAEQgCADgBAGQgCAGAAAIIACAPIADAIQACADAEACQADABAEAAQAFAAAEgBQADgCACgDQACgEACgEIABgPIgBgOQgCgGgCgDQgCgEgDgBIgJgBIgHABg");
	this.shape_10.setTransform(1341.6,156.6);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AgaAxQgIgIgBgTIAMAAQABAOAGAGQAFAGALAAQALAAAGgFQAGgEAAgMIgBgIQgCgDgDgDQgCgCgEgCIgJgCIgHgDIgLgEQgGAAgDgEQgEgDgCgGQgDgGAAgHQAAgPAJgIQAJgJAQAAQAKAAAGADQAHADAEAEQAEAFACAIQACAGAAAKIgMAAIgCgNQgCgEgDgEQgCgDgFgBIgJgBQgJAAgGAEQgFAFAAAKQAAAFABAEIAEAFQADACAEACIAIACIAHADIAMADQAGACAEAEQADAEACAFQACAGAAAGQAAAPgJAIQgJAJgSgBQgRAAgJgJg");
	this.shape_11.setTransform(1333,153.4);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AgFA4IAAhjIggAAIAAgMIBMAAIAAAMIghAAIAABjg");
	this.shape_12.setTransform(1321.1,153.4);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("AgRA3QgIgDgFgHQgFgHgCgLQgCgLAAgQQAAgPACgLQACgLAFgHQAFgHAIgDQAIgEAKAAQAKAAAHADQAHADAEAEQAFAFACAHIADARIgNAAQgBgOgGgGQgFgGgNAAQgGAAgGACQgFACgDAGQgEAFgBAIQgBAJAAANQAAANABAKQABAJAEAGQADAFAFACQAGADAGAAQAHAAAFgCQAFgCADgEQADgEACgHIABgQIAAgEIgaAAIAAgJIAnAAIAAANQAAAXgKALQgJALgUAAQgKAAgIgDg");
	this.shape_13.setTransform(1312.1,153.4);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AgnAFIAAgJIBPAAIAAAJg");
	this.shape_14.setTransform(1302.6,159.8);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("AALA4IAAgaIgyAAIAAgKIAshLIATAAIAABKIAQAAIAAALIgQAAIAAAagAgZATIAkAAIAAg+g");
	this.shape_15.setTransform(1293.5,153.4);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("AgQA3QgHgCgFgIQgEgGgCgMQgCgLAAgQQAAgPACgLQABgLAFgHQAEgHAHgDQAIgEAJAAQAKAAAIAEQAHADAEAHQAFAHABALQACALAAAPQAAAQgCALQgCALgEAHQgFAIgHACQgHADgKAAQgJAAgHgDgAgKgrQgFACgDAGQgCAFgBAIQgCAJAAANIABAWQABAKADAFQADAGAEACQAFADAGAAQAHAAAFgDQAEgCADgGQADgFABgKIABgWIgBgWQgCgIgCgFQgDgGgFgCQgEgCgHAAQgGAAgEACg");
	this.shape_16.setTransform(1284.6,153.4);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AgeA5IAAhwIAMAAIAAALQAGgMAMAAQAJAAAGACQAFADAFAFQADAFABAIQACAIAAAKQAAAUgHAKQgHAKgRAAQgMAAgFgKIAAAqgAgHgrQgEABgCAEQgCADgBAGQgCAGABAIIABAPIADAIQACADAEACQAEABADAAQAFAAADgBQAEgCADgDQACgEABgEIAAgPIAAgOQgBgGgCgDQgDgEgEgBIgIgBIgHABg");
	this.shape_17.setTransform(1276.2,156.6);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#000000").s().p("AgVAhQgHgHAAgNIAAg0IANAAIAAAwQAAALAEAFQADAFAIAAQAIAAAEgFQAEgFAAgLIAAgwIANAAIAABOIgNAAIAAgKQgCAGgFADQgFADgGAAQgNgBgGgHg");
	this.shape_18.setTransform(1267.9,155.1);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#000000").s().p("AgeA5IAAhwIAMAAIAAALQAGgMAMAAQAJAAAGACQAGADAEAFQADAFABAIQACAIAAAKQAAAUgHAKQgHAKgRAAQgMAAgGgKIAAAqgAgHgrQgEABgCAEQgCADgBAGQgBAGgBAIIABAPIAEAIQACADAEACQAEABADAAQAFAAADgBQAEgCADgDQABgEABgEIABgPIgBgOQgBgGgBgDQgDgEgEgBIgIgBIgHABg");
	this.shape_19.setTransform(1260.1,156.6);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#000000").s().p("AgNAnQgGgDgEgFQgEgFgBgIQgCgIAAgKQAAgJACgIQABgIAEgFQAEgFAGgDQAGgCAHAAQAIAAAGACQAGADAEAFQAEAFACAIQABAIAAAJQAAAVgHAKQgIAKgQAAQgHAAgGgCgAgHgbQgEABgCAEQgCADgBAGIgBANIABAOQABAGACAEQACADAEACQADABAEAAQAFAAADgBQAEgCACgDQACgEABgGIABgOIgBgNQgBgGgCgDQgCgEgEgBIgIgBIgHABg");
	this.shape_20.setTransform(1252,155);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#000000").s().p("AgeA5IAAhwIAMAAIAAALQAGgMANAAQAIAAAGACQAFADAEAFQAEAFACAIQABAIAAAKQAAAUgHAKQgIAKgQAAQgLAAgHgKIAAAqgAgHgrQgEABgCAEQgCADgBAGQgCAGAAAIIABAPIAEAIQACADAEACQADABAEAAQAFAAADgBQAEgCACgDQACgEABgEIABgPIgBgOQgBgGgCgDQgCgEgEgBIgIgBIgHABg");
	this.shape_21.setTransform(1244.2,156.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(10));

	// Ebene 2
	this.instance = new lib.container_text("single",29);
	this.instance.setTransform(645,278.8,1,1,0,0,0,585,188.8);

	this.instance_1 = new lib.container_text("single",30);
	this.instance_1.setTransform(640,146);

	this.instance_2 = new lib.container_pics("single",7);
	this.instance_2.setTransform(60,146);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_2},{t:this.instance_1},{t:this.instance}]},4).wait(6));

	// Ebene 5
	this.closeBtn = new lib.btn_close02();
	this.closeBtn.setTransform(1162,58.2,1,1,0,0,0,12,11.8);
	this.closeBtn._off = true;

	this.timeline.addTween(cjs.Tween.get(this.closeBtn).wait(4).to({_off:false},0).wait(6));

	// Ebene 1
	this.instance_3 = new lib.pic_plane_white();
	this.instance_3.setTransform(609,336,0.993,1.132,0,0,0,579,265);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(4).to({_off:false},0).wait(6));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(1238,140.7,232,27.4);


(lib.popup03 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgLA4QgGgCgDgDQgDgEgCgFQgCgFAAgGIAMAAQABAJADAEQAEADAHAAQAKAAAEgEQAEgDAAgKIAAgRQgGAMgNAAQgIAAgFgDQgGgCgDgFQgEgFgCgIQgBgGAAgLQAAgWAHgKQAIgKAPAAQAGAAAFADQAFADADAGIAAgKIAMAAIAABVQAAAOgHAHQgIAHgPAAQgHAAgFgCgAgHgsQgEACgCADQgCAEgBAGIgBAOIABAPQABAEACADQACAEAEABQADACAEAAIAIgBQADgCADgDQACgEABgEIABgPIgBgOQgBgGgCgEQgCgDgEgCIgIgBIgHABg");
	this.shape.setTransform(1388.4,126);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AAQApIAAgxQAAgLgEgFQgEgDgIAAQgHAAgDADQgFAFAAALIAAAxIgMAAIAAhPIALAAIAAALQAGgMANAAQANgBAHAIQAFAHAAAOIAAA0g");
	this.shape_1.setTransform(1380.6,124.3);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgVAhQgHgIAAgNIAAg0IANAAIAAAxQAAALAEAFQADAEAIAAQAIAAAEgEQAEgEAAgMIAAgxIANAAIAABPIgNAAIAAgKQgCAGgFACQgFADgGAAQgNABgGgIg");
	this.shape_2.setTransform(1372.6,124.5);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgLA4QgGgCgDgDQgDgEgCgFQgCgFAAgGIAMAAQABAJADAEQAEADAHAAQAKAAAEgEQAEgDAAgKIAAgRQgGAMgNAAQgIAAgFgDQgGgCgDgFQgEgFgCgIQgBgGAAgLQAAgWAHgKQAIgKAPAAQAGAAAFADQAFADADAGIAAgKIAMAAIAABVQAAAOgHAHQgIAHgPAAQgHAAgFgCgAgHgsQgEACgCADQgCAEgBAGIgBAOIABAPQABAEACADQACAEAEABQADACAEAAIAIgBQADgCADgDQACgEABgEIABgPIgBgOQgBgGgCgEQgCgDgEgCIgIgBIgHABg");
	this.shape_3.setTransform(1364.4,126);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgFA5IAAhPIALAAIAABPgAgFgoIAAgQIALAAIAAAQg");
	this.shape_4.setTransform(1358.8,122.7);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AAQApIAAgxQAAgLgEgFQgDgDgJAAQgHAAgEADQgEAFAAALIAAAxIgNAAIAAhPIANAAIAAALQAEgMAOAAQANgBAHAIQAFAHABAOIAAA0g");
	this.shape_5.setTransform(1353.1,124.3);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgFA5IAAhPIALAAIAABPgAgFgoIAAgQIALAAIAAAQg");
	this.shape_6.setTransform(1347.4,122.7);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AgMAnQgFgDgFgFQgEgFgBgIQgCgIAAgKQAAgVAHgJQAIgKAPAAQAIAAAGACQAFADAEAFQADAFABAHQACAIAAAJIAAACIguAAIABAPQABAGACADQADADADABIAHABQAIAAAEgDQAEgDABgIIALAAQgBAMgGAGQgHAHgOAAQgGAAgHgCgAgFgcQgDABgCADIgEAGIgCALIAhAAQAAgHgBgEQgBgEgCgCQgCgDgDgBIgIAAIgFAAg");
	this.shape_7.setTransform(1341.9,124.4);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AgRAoIAAg3QAAgLAHgHQAFgGALAAIAMAAIAAALIgMAAQgKAAAAAMIAAA4g");
	this.shape_8.setTransform(1336.1,124.4);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AALAyQgWAAAAgZIAAgrIgLAAIAAgLIALAAIAAgTIALAAIAAATIAXAAIAAALIgXAAIAAAqQAAAJACACQADAEAIAAIAKAAIAAALg");
	this.shape_9.setTransform(1330.5,123.4);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AgLA5IAAhEIgKAAIAAgLIAKAAIAAgIQAAgMAGgHQAFgGAMgBIAKAAIAAAMIgJAAQgHAAgDAEQgDACAAAIIAAAIIAUAAIAAALIgUAAIAABEg");
	this.shape_10.setTransform(1325.5,122.7);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AgVAhQgHgIAAgNIAAg0IANAAIAAAxQAAALAEAFQADAEAIAAQAIAAAEgEQAEgEAAgMIAAgxIANAAIAABPIgNAAIAAgKQgCAGgFACQgFADgGAAQgNABgGgIg");
	this.shape_11.setTransform(1318.8,124.5);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AgdA5IAAhxIANAAIAABmIAuAAIAAALg");
	this.shape_12.setTransform(1311.6,122.7);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("AgnAFIAAgJIBPAAIAAAJg");
	this.shape_13.setTransform(1302.6,129.2);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AgaAyQgIgJgCgTIANAAQABAOAGAGQAFAGALAAQAMAAAFgFQAHgGAAgLQgBgLgFgFQgGgFgMAAIgJAAIAAgKIAJAAQALAAAEgFQAGgFAAgKQAAgLgGgEQgGgFgJAAQgKAAgGAGQgFAFgCAOIgNAAQABgIACgHQACgHAEgFQAFgFAGgDQAHgCAJAAQARAAAIAIQAJAJAAAPQAAAHgDAIQgFAGgHADQAIABAFAHQAFAGgBANQAAAPgJAJQgJAJgSAAQgRAAgJgJg");
	this.shape_14.setTransform(1293.5,122.7);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("AgQA4QgHgEgFgHQgEgGgCgMQgCgMAAgPQAAgPACgLQABgLAFgHQAEgHAHgDQAIgEAJABQAKgBAIAEQAHADAEAHQAFAHABALQACALAAAPQAAAPgCAMQgCAMgEAGQgFAHgHAEQgHADgKAAQgJAAgHgDgAgKgrQgFACgDAFQgCAGgBAJQgCAIAAANIABAXQABAJADAGQADAFAEACQAFADAGAAQAHAAAFgDQAEgCADgFQADgGABgJIABgXIgBgVQgCgJgCgGQgDgFgFgCQgEgCgHAAQgGAAgEACg");
	this.shape_15.setTransform(1284.6,122.7);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("AgeA5IAAhwIAMAAIAAALQAGgMAMAAQAJAAAGACQAFADAFAFQADAFABAIQACAIAAAKQAAAUgHAKQgHAKgRAAQgMAAgFgKIAAAqgAgHgrQgEABgCAEQgCADgBAGQgCAGABAIIABAPIADAIQACADAEACQAEABADAAQAFAAADgBQAEgCADgDQACgEABgEIAAgPIAAgOQgBgGgCgDQgDgEgEgBIgIgBIgHABg");
	this.shape_16.setTransform(1276.2,126);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AgVAhQgHgIAAgNIAAg0IANAAIAAAxQAAALAEAFQADAEAIAAQAIAAAEgEQAEgEAAgMIAAgxIANAAIAABPIgNAAIAAgKQgCAGgFACQgFADgGAAQgNABgGgIg");
	this.shape_17.setTransform(1267.9,124.5);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#000000").s().p("AgeA5IAAhwIAMAAIAAALQAGgMAMAAQAJAAAGACQAGADAEAFQADAFABAIQACAIAAAKQAAAUgHAKQgHAKgRAAQgMAAgGgKIAAAqgAgHgrQgEABgCAEQgCADgBAGQgBAGgBAIIABAPIAEAIQACADAEACQAEABADAAQAFAAADgBQAEgCADgDQABgEABgEIABgPIgBgOQgBgGgBgDQgDgEgEgBIgIgBIgHABg");
	this.shape_18.setTransform(1260.1,126);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#000000").s().p("AgNAnQgGgDgEgFQgEgFgBgIQgCgIAAgKQAAgJACgIQABgIAEgFQAEgFAGgDQAGgCAHAAQAIAAAGACQAGADAEAFQAEAFACAIQABAIAAAJQAAAVgHAKQgIAKgQAAQgHAAgGgCgAgHgbQgEABgCAEQgCADgBAGIgBANIABAOQABAGACAEQACADAEACQADABAEAAQAFAAADgBQAEgCACgDQACgEABgGIABgOIgBgNQgBgGgCgDQgCgEgEgBIgIgBIgHABg");
	this.shape_19.setTransform(1252,124.4);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#000000").s().p("AgeA5IAAhwIAMAAIAAALQAGgMANAAQAIAAAGACQAFADAEAFQAEAFACAIQABAIAAAKQAAAUgHAKQgIAKgQAAQgLAAgHgKIAAAqgAgHgrQgEABgCAEQgCADgBAGQgCAGAAAIIABAPIAEAIQACADAEACQADABAEAAQAFAAADgBQAEgCACgDQACgEABgEIABgPIgBgOQgBgGgCgDQgCgEgEgBIgIgBIgHABg");
	this.shape_20.setTransform(1244.2,126);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(10));

	// Ebene 5
	this.closeBtn = new lib.btn_close02();
	this.closeBtn.setTransform(1162,58.2,1,1,0,0,0,12,11.8);
	this.closeBtn._off = true;

	this.timeline.addTween(cjs.Tween.get(this.closeBtn).wait(4).to({_off:false},0).wait(6));

	// container_text
	this.instance = new lib.container_text("single",19);
	this.instance.setTransform(645,278.8,1,1,0,0,0,585,188.8);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(4).to({_off:false},0).wait(6));

	// container_pics
	this.slideShowWidget = new lib.slider_filters();
	this.slideShowWidget.setTransform(335,371,1,1,0,0,0,275,225);

	this.scrollerWidget = new lib.croller_text21();
	this.scrollerWidget.setTransform(890,370.8,1,1,0,0,0,250,224.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.scrollerWidget},{t:this.slideShowWidget}]},4).wait(6));

	// scrollerWidget_1
	this.instance_1 = new lib.pic_plane_white();
	this.instance_1.setTransform(609,336,0.993,1.132,0,0,0,579,265);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(4).to({_off:false},0).wait(6));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(1238,110,322,27.4);


(lib.popup02 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgLA4QgGgCgDgDQgDgEgCgFQgCgFAAgGIAMAAQABAJADAEQAEADAHAAQAKAAAEgEQAEgDAAgKIAAgRQgGAMgNAAQgIAAgFgDQgGgCgDgFQgEgFgCgIQgBgGAAgLQAAgWAHgKQAIgKAPAAQAGAAAFADQAFADADAGIAAgKIAMAAIAABVQAAAOgHAHQgIAHgPAAQgHAAgFgCgAgHgsQgEACgCADQgCAEgBAGIgBAOIABAPQABAEACADQACAEAEABQADACAEAAIAIgBQADgCADgDQACgEABgEIABgPIgBgOQgBgGgCgEQgCgDgEgCIgIgBIgHABg");
	this.shape.setTransform(1378.9,96);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AAQAoIAAgwQAAgLgEgFQgEgDgIAAQgGAAgFADQgEAEAAAMIAAAwIgMAAIAAhOIALAAIAAALQAFgMAOgBQANAAAGAIQAHAHgBANIAAA0g");
	this.shape_1.setTransform(1371.1,94.3);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgVAhQgHgIAAgMIAAg0IANAAIAAAwQAAALAEAFQADAEAIABQAIgBAEgEQAEgFAAgLIAAgwIANAAIAABOIgNAAIAAgKQgCAFgFAEQgFACgGAAQgNAAgGgHg");
	this.shape_2.setTransform(1363,94.5);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgRAoIAAg3QAAgLAGgHQAHgGAJAAIANAAIAAALIgMAAQgKAAAAAMIAAA4g");
	this.shape_3.setTransform(1357,94.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AAQA4IAAgyQAAgJgEgFQgEgDgIAAQgHAAgDADQgFAEAAAKIAAAyIgNAAIAAhvIANAAIAAAqQADgFAFgDQAFgCAFgBQANAAAHAIQAFAHAAALIAAA2g");
	this.shape_4.setTransform(1350.2,92.7);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AgVAwQgHgIAAgMIAAg0IANAAIAAAwQAAALAEAFQADAEAIABQAIgBAEgEQAEgFAAgLIAAgwIANAAIAABOIgNAAIAAgKQgCAFgFAEQgFACgGAAQgNAAgGgHgAAHgoIAAgOIANAAIAAAOgAgRgoIAAgOIAMAAIAAAOg");
	this.shape_5.setTransform(1342.2,93);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgLA4IAAhDIgKAAIAAgLIAKAAIAAgIQAAgNAGgGQAFgHAMABIAKAAIAAALIgJAAQgHAAgDADQgDAEAAAGIAAAJIAUAAIAAALIgUAAIAABDg");
	this.shape_6.setTransform(1335.9,92.7);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AALAxQgWAAAAgYIAAgrIgLAAIAAgLIALAAIAAgUIALAAIAAAUIAXAAIAAALIgXAAIAAAqQAAAJACADQADADAIAAIAKAAIAAAKg");
	this.shape_7.setTransform(1330.6,93.4);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AgLA4IAAhDIgKAAIAAgLIAKAAIAAgIQAAgNAGgGQAFgHAMABIAKAAIAAALIgJAAQgHAAgDADQgDAEAAAGIAAAJIAUAAIAAALIgUAAIAABDg");
	this.shape_8.setTransform(1325.5,92.7);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AgVAhQgHgIAAgMIAAg0IANAAIAAAwQAAALAEAFQADAEAIABQAIgBAEgEQAEgFAAgLIAAgwIANAAIAABOIgNAAIAAgKQgCAFgFAEQgFACgGAAQgNAAgGgHg");
	this.shape_9.setTransform(1318.9,94.5);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AgdA4IAAhvIANAAIAABlIAuAAIAAAKg");
	this.shape_10.setTransform(1311.7,92.7);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AgnAFIAAgJIBPAAIAAAJg");
	this.shape_11.setTransform(1302.7,99.2);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AgfA5IAAgKQAAgGABgGQACgFADgEIAHgIIAJgHIALgIIAHgDQADgCADgEQADgDACgFQACgEgBgGQAAgKgFgGQgGgEgKAAIgIABQgEACgDACQgDAEgCAEIgCANIgMAAQAAgKACgGQACgIAFgEQAEgFAGgDQAHgDAIAAQARAAAKAJQAIAJAAAPQAAAIgDAGQgCAFgCAEIgIAFIgJAGIgLAJIgIAHIgGAFIgDAGIgBAIIAAACIA0AAIAAAKg");
	this.shape_12.setTransform(1293.6,92.6);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("AgQA3QgHgCgFgIQgEgGgCgMQgCgMAAgPQAAgPACgLQABgLAFgHQAEgHAHgDQAIgEAJAAQAKAAAIAEQAHADAEAHQAFAHABALQACALAAAPQAAAPgCAMQgCALgEAHQgFAIgHACQgHADgKABQgJgBgHgDgAgKgrQgFACgDAGQgCAFgBAIQgCAJAAANIABAXQABAJADAFQADAGAEACQAFADAGAAQAHAAAFgDQAEgCADgGQADgFABgJIABgXIgBgWQgCgIgCgFQgDgGgFgCQgEgCgHAAQgGAAgEACg");
	this.shape_13.setTransform(1284.6,92.7);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AgeA5IAAhwIAMAAIAAALQAGgMANAAQAIAAAGACQAFADAEAFQAEAFACAIQABAIAAAKQAAAUgHAKQgIAKgQAAQgLAAgHgKIAAAqgAgHgrQgDABgDAEQgCADgBAGQgCAGAAAIIABAPIAEAIQACADAEACQADABAEAAQAFAAAEgBQADgCACgDQACgEACgEIABgPIgBgOQgCgGgCgDQgCgEgDgBIgJgBIgHABg");
	this.shape_14.setTransform(1276.3,96);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("AgVAhQgHgIAAgMIAAg0IANAAIAAAwQAAALAEAFQADAEAIABQAIgBAEgEQAEgFAAgLIAAgwIANAAIAABOIgNAAIAAgKQgCAFgFAEQgFACgGAAQgNAAgGgHg");
	this.shape_15.setTransform(1268,94.5);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("AgeA5IAAhwIAMAAIAAALQAGgMANAAQAIAAAGACQAFADAEAFQAEAFACAIQABAIAAAKQAAAUgHAKQgIAKgQAAQgMAAgFgKIAAAqgAgHgrQgDABgDAEQgCADgBAGQgBAGAAAIIABAPIADAIQACADAEACQADABAEAAQAFAAAEgBQADgCACgDQACgEACgEIABgPIgBgOQgCgGgCgDQgCgEgDgBIgJgBIgHABg");
	this.shape_16.setTransform(1260.2,96);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AgNAnQgGgDgEgFQgEgFgBgIQgCgIAAgKQAAgJACgIQABgIAEgFQAEgFAGgDQAGgCAHAAQAIAAAGACQAGADAEAFQAEAFACAIQABAIAAAJQAAAVgHAKQgIAKgQAAQgHAAgGgCgAgHgbQgEABgCAEQgCADgBAGIgBANIABAOQABAGACAEQACADAEACQADABAEAAQAFAAADgBQAEgCACgDQACgEABgGIABgOIgBgNQgBgGgCgDQgCgEgEgBIgIgBIgHABg");
	this.shape_17.setTransform(1252,94.4);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#000000").s().p("AgeA5IAAhwIAMAAIAAALQAGgMAMAAQAJAAAGACQAFADAFAFQADAFABAIQACAIAAAKQAAAUgHAKQgHAKgRAAQgMAAgFgKIAAAqgAgHgrQgEABgCAEQgCADgBAGQgCAGABAIIAAAPIAEAIQACADAEACQAEABADAAQAFAAAEgBQADgCADgDQACgEAAgEIABgPIgBgOQAAgGgCgDQgDgEgDgBIgJgBIgHABg");
	this.shape_18.setTransform(1244.3,96);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(10));

	// Ebene 2
	this.closeBtn = new lib.btn_close02();
	this.closeBtn.setTransform(1162,58.2,1,1,0,0,0,12,11.8);
	this.closeBtn._off = true;

	this.timeline.addTween(cjs.Tween.get(this.closeBtn).wait(4).to({_off:false},0).wait(6));

	// scrollerWidget_1
	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#000000").s().p("AgPA3QgHgCgFgEQgFgFgDgHQgCgHAAgLIAAgLIADgIIADgIIAGgKIAYgmIAWAAIgYAoIAFgBQAJAAAHACQAGACAFAFQAFAEACAGQACAHAAAKQAAALgCAHQgDAHgEAFQgFAEgIACQgHACgJABQgIgBgHgCgAgMAFQgEAEAAAKIABAKIADAGQACADADABIAHABIAIgBQADgBACgDIADgGIABgKQAAgKgEgEQgEgFgJAAQgIAAgEAFg");
	this.shape_19.setTransform(271.1,468.1);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#000000").s().p("AgPA3QgIgCgEgEQgFgEgCgGQgDgHAAgHIAWAAQAAAIADAEQAFADAHAAIAHgBQADgBACgDQACgCABgDIABgKQAAgMgEgEQgDgEgJAAQgHAAgEADQgDADgBAFIgUAAIAAgHIAEg9IA/AAIAAAUIguAAIgBAcQADgEAFgCQAFgCAEAAQASAAAJAJQAJAIAAATQAAAUgKAJQgJAKgTAAQgJgBgGgCg");
	this.shape_20.setTransform(407.1,590.4);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#000000").s().p("AAHA4IAAgWIguAAIAAgRIAmhIIAcAAIAABHIANAAIAAASIgNAAIAAAWgAgSAQIAZAAIAAg0g");
	this.shape_21.setTransform(502,468);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#000000").s().p("AgjA5IAAgMQAAgMAGgIQAFgJAMgHIAMgIIAGgDIAFgEIAEgHIAAgJQAAgIgDgDQgFgDgHAAIgGABQgDAAgCACQgCACAAAEIgCAJIgWAAQABgKACgGQACgIAEgFQAEgEAIgDQAHgDAJAAQAKAAAHADQAIADAEAEQAEAFACAGQACAHABAHQgBAIgCAFQgBAGgDADQgDADgEADIgJAGIgMAIQgHAFgFAFQgEAEAAAGIAxAAIAAARg");
	this.shape_22.setTransform(493.5,262.6);

	this.instance = new lib.container_text("single",15);
	this.instance.setTransform(660,507.8);

	this.instance_1 = new lib.container_text("single",14);
	this.instance_1.setTransform(660,470.3);

	this.instance_2 = new lib.container_text("single",13);
	this.instance_2.setTransform(660,432.9);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#000000").s().p("AgPA3QgHgCgFgEQgFgEgDgIQgCgHAAgLIAAgLIADgIIADgIIAGgJIAYgoIAWAAIgYApIAFAAQAJAAAHABQAGACAFAFQAFAFACAFQACAHAAAKQAAALgCAHQgDAIgEAEQgFAEgIACQgHACgJAAQgIAAgHgCgAgMAEQgEAFAAAKIABAKIADAHQACACADABIAHABIAIgBQADgBACgCIADgHIABgKQAAgKgEgFQgEgEgJAAQgIAAgEAEg");
	this.shape_23.setTransform(640,520.6);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#000000").s().p("AgQA3QgGgCgFgFQgFgDgCgHQgDgFAAgIIAVAAQABAJAEADQADADAIAAIAHgBQADgBADgCQABgDABgEIABgJQAAgLgDgFQgFgEgIAAQgHAAgDACQgEADgBAGIgUAAIAAgHIAFg9IA/AAIAAAVIgvAAIgCAbQAEgEAFgCQAFgCAEABQASAAAJAIQAJAIAAATQAAAUgKAJQgIAJgUAAQgIABgIgDg");
	this.shape_24.setTransform(640,483.1);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#000000").s().p("AAGA5IAAgXIgtAAIAAgRIAmhJIAcAAIAABIIANAAIAAASIgNAAIAAAXgAgTAQIAZAAIAAg1g");
	this.shape_25.setTransform(640,445.6);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#000000").s().p("AgQA5QgHgCgFgFQgFgFgCgGQgCgIgBgJIAWAAIABAJIADAGQACACAEABIAGABQAJAAAEgDQAEgEAAgIQAAgJgEgEQgEgDgJAAIgJAAIAAgSIAJAAQAIAAAEgDQADgEAAgHQAAgJgEgDQgEgDgHgBIgGABQgDABgCACQgCACgBADIgCAJIgVAAQABgJACgHQACgHAEgEQAEgFAIgDQAHgDAJABQAKgBAHADQAHADAFAEQAEAEACAGQACAHAAAHQAAAJgDAFQgEAHgHADQAIABAEAGQAEAHAAALQAAAIgCAGQgDAHgEADQgFAFgHACQgIACgKAAQgJAAgHgBg");
	this.shape_26.setTransform(529,391.9);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#000000").s().p("AADA4IAAhZIgbAKIAAgUIAggMIARAAIAABvg");
	this.shape_27.setTransform(209.7,262.7);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#000000").s().p("AgQA5QgHgCgFgFQgFgFgCgGQgCgIgBgJIAWAAIABAJIADAGQACACAEABIAGABQAJAAAEgDQAEgEAAgIQAAgJgEgEQgEgDgJAAIgJAAIAAgSIAJAAQAIAAAEgDQADgEAAgHQAAgJgEgDQgEgDgHgBIgGABQgDABgCACQgCACgBADIgCAJIgVAAQABgJACgHQACgHAEgFQAEgEAIgDQAHgDAJABQAKgBAHADQAHADAFAEQAEAEACAGQACAHAAAHQAAAJgDAFQgEAHgHADQAIABAEAGQAEAHAAALQAAAIgCAGQgDAHgEAEQgFAEgHACQgIACgKAAQgJAAgHgBg");
	this.shape_28.setTransform(639.9,408.1);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#000000").s().p("AgiA6IAAgNQgBgMAGgJQAFgIAMgHIAMgJIAFgBIAGgGIADgGIABgIQAAgJgDgDQgEgDgIgBIgGABQgDABgCACQgCACAAADIgCAJIgWAAQABgIACgIQACgGAEgFQAFgFAHgDQAHgDAJABQAKgBAIADQAGADAFAEQAEAFADAGQACAGAAAJQAAAHgCAFQgCAGgDADQgDADgEADIgJAGIgMAJQgHAFgFAEQgEAEAAAGIAxAAIAAASg");
	this.shape_29.setTransform(640,370.6);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#000000").s().p("AADA5IAAhaIgbALIAAgVIAggMIARAAIAABwg");
	this.shape_30.setTransform(639.1,333.2);

	this.instance_3 = new lib.container_text("single",12);
	this.instance_3.setTransform(660,395.4);

	this.instance_4 = new lib.container_text("single",11);
	this.instance_4.setTransform(660,358);

	this.instance_5 = new lib.container_text("single",10);
	this.instance_5.setTransform(660,320.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.instance_2},{t:this.instance_1},{t:this.instance},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19}]},4).wait(6));

	// container_text
	this.instance_6 = new lib.container_text("single",6);
	this.instance_6.setTransform(645,278.8,1,1,0,0,0,585,188.8);
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(4).to({_off:false},0).wait(6));

	// Ebene 6
	this.instance_7 = new lib.pic_circle("single",3);
	this.instance_7.setTransform(271.1,558.3,0.1,0.1,0,0,0,0.5,0);

	this.instance_8 = new lib.pic_circle("single",3);
	this.instance_8.setTransform(493.6,320.9,0.1,0.1,0,0,0,0.5,0);

	this.instance_9 = new lib.pic_circle("single",3);
	this.instance_9.setTransform(502.1,558.3,0.1,0.1,0,0,0,0.5,0);

	this.instance_10 = new lib.pic_circle("single",3);
	this.instance_10.setTransform(374.1,392.9,0.1,0.1,0,0,0,0.5,0);

	this.instance_11 = new lib.pic_circle("single",3);
	this.instance_11.setTransform(210.6,360.9,0.1,0.1,0,0,0,0.5,0);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f().s("#D5001C").ss(1,1,1).p("AUNvIIgBmzABhj4IWgAAA3/o4IgBtDAuiV7IAArzAViV7IAArz");
	this.shape_31.setTransform(364.3,417.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_31},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7}]},4).wait(6));

	// container_text
	this.instance_12 = new lib.container_text("single",7);
	this.instance_12.setTransform(60,146);
	this.instance_12._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(4).to({_off:false},0).wait(6));

	// container_pics
	this.instance_13 = new lib.container_pics("single",3);
	this.instance_13.setTransform(246,351.5,1,1,0,0,0,136,101.5);
	this.instance_13._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_13).wait(4).to({_off:false},0).wait(6));

	// scrollerWidget_1
	this.instance_14 = new lib.pic_plane_white();
	this.instance_14.setTransform(609,336,0.993,1.132,0,0,0,579,265);
	this.instance_14._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_14).wait(4).to({_off:false},0).wait(6));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(1238,80,232,27.5);


(lib.popup01 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgcA4IAAgKIAGAAQAFgBAEgCQADgDADgHIADgJIgchPIAOAAIATA9IAUg9IALAAIgfBZIgBAKIgFAHQgCACgFACQgDACgHgBg");
	this.shape.setTransform(1387.6,66.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgVAjQgGgFAAgKQAAgHACgEQADgEAEgDQAEgCAFgBIAMgEIAMgCIAAgFQAAgIgDgFQgDgEgJAAQgGAAgEADQgDAEAAAJIgMAAQABgNAGgHQAGgHAOAAQAHAAAFACQAFACADADQADAEABAFQACAFAAAGIAAA1IgNAAIAAgKQgCAEgFAEQgFADgGAAQgMAAgGgGgAAEADIgIACIgGAEQAAAAgBABQAAAAgBABQAAAAAAABQgBAAAAABIgBAFQAAANAOAAQAGAAAEgFQAFgFAAgIIAAgLg");
	this.shape_1.setTransform(1380.2,64.4);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgFA5IAAhxIALAAIAABxg");
	this.shape_2.setTransform(1375.1,62.7);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgeA5IAAhwIAMAAIAAALQAGgMAMAAQAJAAAGACQAGADAEAFQADAFABAIQACAIAAAKQAAAUgHAKQgHAKgRAAQgMAAgGgKIAAAqgAgHgrQgEABgCAEQgCADgBAGQgCAGAAAIIABAPIAEAIQACADAEACQAEABADAAQAFAAADgBQAEgCADgDQABgEABgEIABgPIgBgOQgBgGgBgDQgDgEgEgBIgIgBIgHABg");
	this.shape_3.setTransform(1369.5,66);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgMAnQgFgCgDgDQgDgDgBgEIgCgKIALAAQABAIAEADQAEADAGAAQAIAAAEgDQADgDAAgGIgBgFQAAgBAAAAQAAgBgBAAQAAgBAAAAQgBAAAAgBIgEgCIgIgCIgGgCQgJgCgFgEQgGgFAAgKQAAgMAHgGQAIgFALAAQAMAAAHAFQAHAGAAAOIgLAAQgBgIgDgDQgEgDgHAAQgHAAgDADQgDADAAAGQAAAFADADQACACAIACIAGACQAMADAFAEQAEAFAAAKQAAAFgBAEQgCAEgDADQgDADgGABQgFACgHAAQgGAAgGgCg");
	this.shape_4.setTransform(1361.8,64.4);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AgFA5IAAhPIALAAIAABPgAgFgpIAAgPIALAAIAAAPg");
	this.shape_5.setTransform(1356.6,62.7);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgOA3QgGgDgDgFQgEgFgCgIQgBgIAAgLQAAgTAHgKQAIgKAPAAQANAAAFAKIAAgqIANAAIAABwIgMAAIAAgMQgGANgOAAQgIAAgFgCgAgHgLQgEABgCAEQgCADgBAEIgBAOIABAPQABAGACAEQACADAEACQADABAEAAQAFAAADgBQAEgCACgDQACgEABgGIABgPIgBgOQgBgEgCgDQgCgEgEgBIgIgBIgHABg");
	this.shape_6.setTransform(1350.6,62.8);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AAQA5IAAgzQAAgJgEgEQgDgFgJAAQgGAAgEAFQgFAEAAAIIAAA0IgMAAIAAhxIAMAAIAAArQADgFAFgDQAFgDAFABQANAAAGAHQAHAIgBAKIAAA3g");
	this.shape_7.setTransform(1342.8,62.7);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AgMAnQgGgDgDgFQgEgFgCgHQgCgIAAgLQAAgVAIgJQAHgKAPAAQAHAAAFACQAGACADAEQAEAEABAGQACAFABAIIgMAAIgCgJQgBgEgCgCQgCgDgDgBIgIAAIgGABQgEABgCAEQgCADgBAGIgBANIABAOQABAHACADQADAEADABIAGABQAJAAAEgEQAEgFABgMIAMAAQgBARgHAIQgIAHgNAAQgHAAgGgCg");
	this.shape_8.setTransform(1335.1,64.4);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AgVAhQgHgHAAgNIAAg0IANAAIAAAwQAAALAEAFQADAFAIgBQAIABAEgFQAEgEAAgMIAAgwIANAAIAABOIgNAAIAAgKQgCAFgFADQgFAEgGAAQgNAAgGgIg");
	this.shape_9.setTransform(1327.4,64.5);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AgNAnQgGgDgEgFQgEgFgBgIQgCgIAAgKQAAgJACgIQABgIAEgFQAEgFAGgDQAGgCAHAAQAIAAAGACQAGADAEAFQAEAFACAIQABAIAAAJQAAAVgHAKQgIAKgQAAQgHAAgGgCgAgHgbQgEABgCAEQgCADgBAGIgBANIABAOQABAGACAEQACADAEACQADABAEAAQAFAAADgBQAEgCACgDQACgEABgGIABgOIgBgNQgBgGgCgDQgCgEgEgBIgIgBIgHABg");
	this.shape_10.setTransform(1319.6,64.4);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AgFA5IAAhkIggAAIAAgNIBMAAIAAANIghAAIAABkg");
	this.shape_11.setTransform(1311.5,62.7);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AgnAFIAAgJIBPAAIAAAJg");
	this.shape_12.setTransform(1302.7,69.2);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("AAJA5IAAhiIgeALIAAgMIAggOIALAAIAABxg");
	this.shape_13.setTransform(1293.1,62.7);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AgQA4QgHgEgFgGQgEgHgCgMQgCgMAAgPQAAgPACgLQABgLAFgHQAEgHAHgDQAIgDAJgBQAKABAIADQAHADAEAHQAFAHABALQACALAAAPQAAAPgCAMQgCALgEAIQgFAGgHAEQgHACgKAAQgJAAgHgCgAgKgrQgFACgDAGQgCAEgBAJQgCAJAAANIABAWQABAKADAGQADAFAEADQAFACAGAAQAHAAAFgCQAEgDADgFQADgGABgKIABgWIgBgWQgCgJgCgEQgDgGgFgCQgEgCgHAAQgGAAgEACg");
	this.shape_14.setTransform(1284.6,62.7);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("AgeA5IAAhwIAMAAIAAALQAGgMANAAQAIAAAGACQAFADAEAFQAEAFACAIQABAIAAAKQAAAUgHAKQgIAKgQAAQgLAAgHgKIAAAqgAgHgrQgDABgDAEQgCADgBAGQgCAGAAAIIABAPIAEAIQACADAEACQADABAEAAQAFAAAEgBQADgCACgDQACgEACgEIABgPIgBgOQgCgGgCgDQgCgEgDgBIgJgBIgHABg");
	this.shape_15.setTransform(1276.3,66);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("AgVAhQgHgHAAgNIAAg0IANAAIAAAwQAAALAEAFQADAFAIgBQAIABAEgFQAEgEAAgMIAAgwIANAAIAABOIgNAAIAAgKQgCAFgFADQgFAEgGAAQgNAAgGgIg");
	this.shape_16.setTransform(1268,64.5);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AgeA5IAAhwIAMAAIAAALQAGgMANAAQAIAAAGACQAFADAEAFQAEAFACAIQABAIAAAKQAAAUgHAKQgIAKgQAAQgMAAgFgKIAAAqgAgHgrQgDABgDAEQgCADgBAGQgBAGAAAIIABAPIADAIQACADAEACQADABAEAAQAFAAAEgBQADgCACgDQACgEACgEIABgPIgBgOQgCgGgCgDQgCgEgDgBIgJgBIgHABg");
	this.shape_17.setTransform(1260.2,66);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#000000").s().p("AgNAnQgGgDgEgFQgEgFgBgIQgCgIAAgKQAAgJACgIQABgIAEgFQAEgFAGgDQAGgCAHAAQAIAAAGACQAGADAEAFQAEAFACAIQABAIAAAJQAAAVgHAKQgIAKgQAAQgHAAgGgCgAgHgbQgEABgCAEQgCADgBAGIgBANIABAOQABAGACAEQACADAEACQADABAEAAQAFAAADgBQAEgCACgDQACgEABgGIABgOIgBgNQgBgGgCgDQgCgEgEgBIgIgBIgHABg");
	this.shape_18.setTransform(1252,64.4);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#000000").s().p("AgeA5IAAhwIAMAAIAAALQAGgMAMAAQAJAAAGACQAFADAFAFQADAFABAIQACAIAAAKQAAAUgHAKQgHAKgRAAQgMAAgFgKIAAAqgAgHgrQgEABgCAEQgCADgBAGQgCAGABAIIAAAPIAEAIQACADAEACQAEABADAAQAFAAAEgBQADgCADgDQACgEAAgEIABgPIgBgOQAAgGgCgDQgDgEgDgBIgJgBIgHABg");
	this.shape_19.setTransform(1244.3,66);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(10));

	// Ebene 2
	this.instance = new lib.container_text("single",4);
	this.instance.setTransform(645,278.8,1,1,0,0,0,585,188.8);

	this.instance_1 = new lib.container_text("single",5);
	this.instance_1.setTransform(640,146);

	this.instance_2 = new lib.container_pics("single",2);
	this.instance_2.setTransform(60,146);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_2},{t:this.instance_1},{t:this.instance}]},4).wait(6));

	// Ebene 5
	this.closeBtn = new lib.btn_close02();
	this.closeBtn.setTransform(1162,58.2,1,1,0,0,0,12,11.8);
	this.closeBtn._off = true;

	this.timeline.addTween(cjs.Tween.get(this.closeBtn).wait(4).to({_off:false},0).wait(6));

	// Ebene 1
	this.instance_3 = new lib.pic_plane_white();
	this.instance_3.setTransform(609,336,0.993,1.132,0,0,0,579,265);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(4).to({_off:false},0).wait(6));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(1238,50,232,27.5);


(lib.ani_inLine = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 20
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#002F6C").s().p("AgMAnQgFgCgDgDQgDgDgBgEIgCgKIALAAQABAIAEADQAEADAGAAQAIAAAEgDQADgDAAgGIgBgFQAAgBAAAAQAAgBgBAAQAAgBAAAAQgBAAAAgBIgEgCIgIgCIgGgCQgJgCgFgEQgGgFAAgKQAAgMAHgGQAIgFALAAQAMAAAHAFQAHAGAAAOIgLAAQgBgIgDgDQgEgDgHAAQgHAAgDADQgDADAAAGQAAAFADADQACACAIACIAGACQAMADAFAEQAEAFAAAKQAAAFgBAEQgCAEgDADQgDADgGABQgFACgHAAQgGAAgGgCg");
	this.shape.setTransform(1381.3,43);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#002F6C").s().p("AgeA5IAAhwIAMAAIAAALQAGgMANAAQAIAAAGACQAFADAEAFQAEAFACAIQABAIAAAKQAAAUgHAKQgIAKgQAAQgLAAgHgKIAAAqgAgHgrQgDABgDAEQgCADgBAGQgCAGAAAIIACAPIADAIQACADAEACQADABAEAAQAFAAAEgBQADgCACgDQACgEACgEIABgPIgBgOQgCgGgCgDQgCgEgDgBIgJgBIgHABg");
	this.shape_1.setTransform(1374,44.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#002F6C").s().p("AgMAnQgGgDgEgFQgEgFgBgIQgCgIAAgKQAAgVAHgJQAJgKAOAAQAIAAAFACQAGADADAFQAEAFACAHQABAIAAAJIAAACIguAAIABAPQABAGACADQACADAEABIAHABQAIAAAEgDQAEgDABgIIALAAQgBAMgGAGQgGAHgPAAQgGAAgHgCgAgFgcQgDABgDADIgDAGIgCALIAiAAQgBgHgBgEQgBgEgCgCQgCgDgDgBIgIAAIgFAAg");
	this.shape_2.setTransform(1366,43);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#002F6C").s().p("AALAyQgWAAAAgaIAAgqIgLAAIAAgLIALAAIAAgTIALAAIAAATIAXAAIAAALIgXAAIAAAqQAAAJACACQADAEAIAAIAKAAIAAALg");
	this.shape_3.setTransform(1359.6,42.1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#002F6C").s().p("AgaAxQgIgJgBgSIAMAAQABAOAGAGQAFAGALAAQALAAAGgFQAGgFAAgKIgBgIQgCgEgDgDQgCgCgEgBIgJgEIgHgCIgLgDQgGgBgDgEQgEgDgCgGQgDgFAAgJQAAgOAJgIQAJgIAQAAQAKgBAGADQAHADAEAFQAEAEACAHQACAHAAAJIgMAAIgCgLQgCgGgDgCQgCgDgFgCIgJgBQgJAAgGAFQgFAEAAAJQAAAGABADIAEAGQADADAEABIAIADIAHACIAMADQAGACAEAEQADADACAGQACAFAAAIQAAAOgJAIQgJAIgSAAQgRABgJgKg");
	this.shape_4.setTransform(1352.5,41.4);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#002F6C").s().p("AAQApIAAgxQAAgLgEgFQgEgDgIgBQgHABgDADQgFAFAAALIAAAxIgNAAIAAhPIAMAAIAAAKQAGgLANAAQANgBAHAIQAFAIABANIAAA0g");
	this.shape_5.setTransform(1340.9,43);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#002F6C").s().p("AgFA5IAAhxIALAAIAABxg");
	this.shape_6.setTransform(1334.9,41.4);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#002F6C").s().p("AgLA4QgGgCgDgDQgDgEgCgFQgCgFAAgGIAMAAQABAJADAEQAEADAHAAQAKAAAEgEQAEgDAAgKIAAgRQgGAMgNAAQgIAAgFgDQgGgCgDgFQgEgFgCgIQgBgGAAgLQAAgWAHgKQAIgKAPAAQAGAAAFADQAFADADAGIAAgKIAMAAIAABVQAAAOgHAHQgIAHgPAAQgHAAgFgCgAgHgsQgEACgCADQgCAEgBAGIgBAOIABAPQABAEACADQACAEAEABQADACAEAAIAIgBQADgCADgDQACgEABgEIABgPIgBgOQgBgGgCgEQgCgDgEgCIgIgBIgHABg");
	this.shape_7.setTransform(1325.3,44.7);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#002F6C").s().p("AAQApIAAgxQAAgLgEgFQgEgDgIgBQgHABgDADQgFAFAAALIAAAxIgNAAIAAhPIAMAAIAAAKQAGgLANAAQANgBAHAIQAFAIAAANIAAA0g");
	this.shape_8.setTransform(1317.5,43);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#002F6C").s().p("AgFA5IAAhPIALAAIAABPgAgFgoIAAgQIALAAIAAAQg");
	this.shape_9.setTransform(1311.7,41.4);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#002F6C").s().p("AgOA3QgGgDgDgFQgEgFgCgIQgBgIAAgLQAAgTAHgKQAIgKAPAAQANAAAFAKIAAgqIANAAIAABwIgMAAIAAgMQgGANgOAAQgIAAgFgCgAgHgLQgEABgCAEQgCADgBAEIgBAOIABAPQABAGACAEQACADAEACQADABAEAAQAFAAADgBQAEgCACgDQACgEABgGIABgPIgBgOQgBgEgCgDQgCgEgEgBIgIgBIgHABg");
	this.shape_10.setTransform(1305.7,41.4);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#002F6C").s().p("AgVAjQgGgFAAgKQAAgHACgEQADgEAEgDQAEgCAFgBIAMgEIAMgCIAAgFQAAgIgDgFQgDgEgJAAQgGAAgEADQgDAEAAAJIgMAAQABgNAGgHQAGgHAOAAQAHAAAFACQAFACADADQADAEABAFQACAFAAAGIAAA1IgNAAIAAgKQgCAEgFAEQgFADgGAAQgMAAgGgGgAAEADIgIACIgGAEQgCABgBADIgBAFQAAANAOAAQAGAAAEgFQAFgFAAgIIAAgLg");
	this.shape_11.setTransform(1298,43);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#002F6C").s().p("AgLA5IAAhEIgKAAIAAgLIAKAAIAAgIQAAgMAGgHQAFgGAMgBIAKAAIAAAMIgJAAQgHAAgDAEQgDACAAAIIAAAIIAUAAIAAALIgUAAIAABEg");
	this.shape_12.setTransform(1292.2,41.4);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#002F6C").s().p("AgnAFIAAgJIBPAAIAAAJg");
	this.shape_13.setTransform(1285,47.8);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#002F6C").s().p("AgFA5IAAhPIALAAIAABPgAgFgoIAAgQIALAAIAAAQg");
	this.shape_14.setTransform(1278.6,41.4);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#002F6C").s().p("AAQApIAAgxQAAgLgEgFQgEgDgIgBQgGABgEADQgFAFAAALIAAAxIgMAAIAAhPIAMAAIAAAKQAEgLAOAAQANgBAGAIQAHAIgBANIAAA0g");
	this.shape_15.setTransform(1273,43);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#002F6C").s().p("AAdA5IgJgcIgpAAIgIAcIgMAAIAjhxIANAAIAjBxgAgRASIAiAAIgRg6g");
	this.shape_16.setTransform(1264.5,41.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).to({state:[]},9).wait(141));

	// Ebene 1
	this.instance = new lib.ani_fadeIn();
	this.instance.setTransform(609,351.5,1,1,0,0,0,609,351.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({_off:true},9).wait(141));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,1425,703);


(lib.ani_comparison_front = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// constraint
	this.constraint = new lib.SliderConstraint01();
	this.constraint.setTransform(50,0);

	this.timeline.addTween(cjs.Tween.get(this.constraint).wait(1));

	// slider1
	this.slider1 = new lib.slider_grip01();
	this.slider1.setTransform(50,0);

	this.timeline.addTween(cjs.Tween.get(this.slider1).wait(1));

	// frameSlave1
	this.frameSlave_1 = new lib.ani_comparison_Front_();
	this.frameSlave_1.setTransform(257.9,189,1,1,0,0,0,257.9,189);

	this.timeline.addTween(cjs.Tween.get(this.frameSlave_1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-29.9,0,1328,825.4);


(lib.popupCluster01 = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// Ebene 2
	this.popup_4_continueOnClose = new lib.popup04();
	this.popup_4_continueOnClose.setTransform(1354,124.4,1,1,0,0,0,1354,124.4);

	this.timeline.addTween(cjs.Tween.get(this.popup_4_continueOnClose).wait(1));

	// Ebene 1
	this.popup_3_continueOnClose = new lib.popup03();
	this.popup_3_continueOnClose.setTransform(1354,124.4,1,1,0,0,0,1354,124.4);

	this.timeline.addTween(cjs.Tween.get(this.popup_3_continueOnClose).wait(1));

	// popup_3
	this.popup_3 = new lib.popup03();
	this.popup_3.setTransform(1354,124.4,1,1,0,0,0,1354,124.4);

	this.timeline.addTween(cjs.Tween.get(this.popup_3).wait(1));

	// popup_2
	this.popup_2_continueOnClose = new lib.popup02();
	this.popup_2_continueOnClose.setTransform(1354,124.4,1,1,0,0,0,1354,124.4);

	this.timeline.addTween(cjs.Tween.get(this.popup_2_continueOnClose).wait(1));

	// popup_1
	this.popup_1_continueOnClose = new lib.popup01();
	this.popup_1_continueOnClose.setTransform(1354,124.4,1,1,0,0,0,1354,124.4);

	this.timeline.addTween(cjs.Tween.get(this.popup_1_continueOnClose).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(1238,50,322,118.1);


(lib.timelineJumpWidget = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{step1:0});

	// fadeIn
	this.instance = new lib.ani_inLine("synched",0);
	this.instance.setTransform(609,351.5,1,1,0,0,0,609,351.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(9));

	// Ebene 2
	this.instance_1 = new lib.container_text("single",139);
	this.instance_1.setTransform(1430,824.8,1,1,0,0,0,540,224.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(9));

	// popup_09
	this.instance_2 = new lib.ani_text_sideBar01();
	this.instance_2.setTransform(-104.5,351.5,1,1,0,0,0,-104.5,351.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(9));

	// popup_09
	this.instance_3 = new lib.popupCluster01();
	this.instance_3.setTransform(161,43.7,1,1,0,0,0,161,43.7);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(9));

	// popup_09
	this.slideWidget1 = new lib.ani_comparison_front();
	this.slideWidget1.setTransform(325.9,262.3,1,1,0,0,0,325.9,262.3);

	this.timeline.addTween(cjs.Tween.get(this.slideWidget1).wait(9));

	// popup_10
	this.instance_4 = new lib.container_pics("single",0);
	this.instance_4.setTransform(549.3,321.5,1,1,0,0,0,549.3,321.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(9));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-505.9,-1,2065.9,826.4);


// stage content:
(lib.c3p1 = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{"I":6});

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_2 = new cjs.Graphics().p("EhfJA26MAAAht0MC+SAAAMAAABt0g");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(2).to({graphics:mask_graphics_2,x:609,y:351.5}).wait(8));

	// timelineJumpWidget
	this.timelineJumpWidget = new lib.timelineJumpWidget();
	this.timelineJumpWidget._off = true;

	this.timelineJumpWidget.mask = mask;

	this.timeline.addTween(cjs.Tween.get(this.timelineJumpWidget).wait(2).to({_off:false},0).wait(8));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;

})(lib = lib||{}, images = images||{}, createjs = createjs||{}, ss = ss||{});
var lib, images, createjs, ss;