(function (lib, img, cjs, ss) {

var p; // shortcut to reference prototypes
lib.webFontTxtFilters = {}; 

// library properties:
lib.properties = {
	width: 1218,
	height: 703,
	fps: 25,
	color: "#FFFFFF",
	opacity: 1.00,
	webfonts: {},
	manifest: [
		{src:"assets/content/images/c5p1_pic01.jpg", id:"c5p1_pic01"},
		{src:"assets/content/images/c5p1_pic02.jpg", id:"c5p1_pic02"},
		{src:"assets/content/images/c5p1_pic03.jpg", id:"c5p1_pic03"}
	]
};



lib.ssMetadata = [];


lib.webfontAvailable = function(family) { 
	lib.properties.webfonts[family] = true;
	var txtFilters = lib.webFontTxtFilters && lib.webFontTxtFilters[family] || [];
	for(var f = 0; f < txtFilters.length; ++f) {
		txtFilters[f].updateCache();
	}
};
// symbols:



(lib.c5p1_pic01 = function() {
	this.initialize(img.c5p1_pic01);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1218,703);


(lib.c5p1_pic02 = function() {
	this.initialize(img.c5p1_pic02);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1218,703);


(lib.c5p1_pic03 = function() {
	this.initialize(img.c5p1_pic03);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1218,703);


(lib.scroller_handle = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D5001C").s().p("AgsCVIAAkqIBZAAIAAEqg");
	this.shape.setTransform(4.5,15);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,9,30);


(lib.scroller_back_500 = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CCCCCC").s().p("EgAYAnEMAAAhOHIAxAAMAAABOHg");
	this.shape.setTransform(2.5,250);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,5,500);


(lib.pic_shadow_occlusionRound = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#000000","rgba(0,0,0,0)"],[0,1],0,0,0,0,0,102.5).s().p("AsTMUQlGlHgBnNQABnMFGlHQFHlGHMgBQHNABFHFGQFGFHABHMQgBHNlGFHQlHFGnNABQnMgBlHlGg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-111.5,-111.5,223,223);


(lib.pic_plane_white = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EhadApaMAAAhSzMC07AAAMAAABSzg");
	this.shape.setTransform(579,265);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,1158,530);


(lib.container_text = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// Ebene 4
	this.text_140 = new cjs.Text("Klicken Sie oben rechts auf \"Themenübersicht\", um ein anderes Thema zu auszuwählen.", "16px 'Porsche Next TT'", "#FFFFFF");
	this.text_140.name = "text_140";
	this.text_140.lineHeight = 23;
	this.text_140.lineWidth = 306;
	this.text_140.setTransform(2,2);
	this.text_140._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_140).wait(139).to({_off:false},0).to({_off:true},1).wait(1));

	// Ebene 3
	this.text_03 = new cjs.Text("Neues PCM 5.1, bedienbar über 10,9-Zoll-Touchdisplay", "16px 'Porsche Next TT'", "#FFFFFF");
	this.text_03.name = "text_03";
	this.text_03.textAlign = "center";
	this.text_03.lineHeight = 23;
	this.text_03.lineWidth = 796;
	this.text_03.setTransform(400,2);
	this.text_03._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_03).wait(2).to({_off:false},0).to({_off:true},1).wait(138));

	// Ebene 2
	this.text_02 = new cjs.Text("Im Macan (MJ 19) kommt das neue PCM 5.1 (Porsche Communication Management) zum Einsatz, welches auf dem MIB2+ (Modularer Infotainment Baukasten 2+) Rechner basiert und zahlreiche Navigations- und Infotainment-Funktionen sowie Porsche Connect Dienste bereitstellt. \n\nDer neue Zentralrechner enthält nur noch einen SD- und SIM-Karten-Slot sowie zwei USB-Anschlüsse. Ein CD- oder DVD-Laufwerk ist nicht mehr vorhanden.\n\nLandesspezifisch ist nun Connect Plus serienmäßig mit permanentem Online-Zugang in den Macan (MJ 19) integriert und bietet u. a.: \n\n• Echtzeit-Verkehrsinformationen \n• Online Routing \n• Voice Pilot (Sprachsteuerung) \n\nZu beachten ist, dass die angebotenen Dienste länderspezifisch abweichen. Z.B. ist der permanente Online-Zugang nur in Ländern verfügbar, in denen die integrierte SIM Karte verbaut ist.\n\nWireless Apple CarPlay® ist nicht im Serienumfang enthalten und muss optional erworben werden. Des Weiteren ist Wireless Apple Car Play derzeit nur in der North America Region verfügbar. \n\n<b>Bitte beachten Sie:</b>\nIm Rahmen von <b>Porsche Connect</b> kommt das PCM 5.1 zum Einsatz. Das heißt, dass für die Navigation und das Infotainment die Porsche Connect App verwendet werden <b>kann.</b>  Im Rahmen von <b>Porsche Car Connect</b> kommt jedoch das bereits im Vorgänger eingesetzte Vodafone Steuergerät zum Einsatz. Das bedeutet, dass für Remote-, Safety- und Security-Dienste die Porsche Car Connect App verwendet werden <b>muss.</b> ", "16px 'Porsche Next TT'");
	this.text_02.name = "text_02";
	this.text_02.lineHeight = 23;
	this.text_02.lineWidth = 336;
	this.text_02.setTransform(2,2);
	this.text_02._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_02).wait(1).to({_off:false},0).to({_off:true},1).wait(139));

	// Ebene 1
	this.text_01 = new cjs.Text("Konnektivität", "32px 'Porsche Next TT Thin'");
	this.text_01.name = "text_01";
	this.text_01.lineHeight = 47;
	this.text_01.lineWidth = 356;
	this.text_01.setTransform(2,2);

	this.timeline.addTween(cjs.Tween.get(this.text_01).to({_off:true},1).wait(140));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,360,50.9);


(lib.container_pics = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// Ebene 4
	this.instance = new lib.c5p1_pic01();

	this.instance_1 = new lib.c5p1_pic02();

	this.instance_2 = new lib.c5p1_pic03();

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,1218,703);


(lib.btn_arrow_openSideBar = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{out:0,over:4,down:9});

	// Ebene 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ag/B9IBkh9Ihkh8IAbAAIBlB8IhlB9g");
	this.shape.setTransform(25,35);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(10));

	// Ebene 3
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#D5001C").s().p("Aj5FeIAAq7IHzAAIAAK7g");
	this.shape_1.setTransform(25,35);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(10));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,50,70);


(lib.scrollerContent_text_sideBar = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.instance = new lib.container_text("single",1);
	this.instance.setTransform(51.3,14.2,1,1,0,0,0,51.3,14.2);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,340,988.9);


(lib.scroller_500 = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.slider = new lib.scroller_handle();

	this.bg = new lib.scroller_back_500();
	this.bg.setTransform(2,0);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.bg},{t:this.slider}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,9,500);


(lib.pic_text_sideBar01 = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// Ebene 6
	this.scrollerItem = new lib.scroller_500();
	this.scrollerItem.setTransform(350,60);

	this.timeline.addTween(cjs.Tween.get(this.scrollerItem).wait(1));

	// container_text
	this.instance = new lib.container_text("single",0);
	this.instance.setTransform(51.3,14.2,1,1,0,0,0,51.3,14.2);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// container_text
	this.scrollerContent = new lib.scrollerContent_text_sideBar();
	this.scrollerContent.setTransform(0,60);

	this.timeline.addTween(cjs.Tween.get(this.scrollerContent).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,360,1048.9);


(lib.pic_text_sideBar_back = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.instance = new lib.pic_plane_white();
	this.instance.setTransform(209,325,1,1,0,0,0,209,325);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,1158,530);


(lib.ani_text_sideBar01_ = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{end:12});

	// timeline functions:
	this.frame_1 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(1).call(this.frame_1).wait(12));

	// pic_arrow_textbox
	this.button_play_parent = new lib.btn_arrow_openSideBar();
	this.button_play_parent.setTransform(20,320,1,1,0,0,0,20,20);

	this.timeline.addTween(cjs.Tween.get(this.button_play_parent).wait(2).to({visible:false},0).wait(11));

	// pic_arrow_textbox
	this.button_back_parent = new lib.btn_arrow_openSideBar();
	this.button_back_parent.setTransform(-485.9,276.9,1,1,0,0,0,20,20);
	this.button_back_parent.visible = false;

	this.timeline.addTween(cjs.Tween.get(this.button_back_parent).wait(12).to({regX:25,regY:35,skewY:180,x:443,y:335,visible:true},0).wait(1));

	// Ebene 5
	this.scrollerWidget = new lib.pic_text_sideBar01();
	this.scrollerWidget.setTransform(-218,330,1,1,0,0,0,160,280);

	this.timeline.addTween(cjs.Tween.get(this.scrollerWidget).wait(2).to({x:200},10).wait(1));

	// pic_plane_white
	this.instance = new lib.pic_text_sideBar_back();
	this.instance.setTransform(-337.7,431.1,0.361,1.326,0,0,0,222.3,325);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(2).to({regX:222.5,x:80.3},10).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-505.9,0,556,1098.9);


(lib.ani_text_sideBar01 = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{I:12});

	// Ebene 1
	this.instance = new lib.ani_text_sideBar01_("synched",2,false);
	this.instance.setTransform(209,325,1,1,0,0,0,209,325);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(12).to({mode:"independent"},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-505.9,0,556,1098.9);


(lib.ani_pic01 = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// Ebene 2
	this.instance = new lib.container_pics("single",1);
	this.instance.setTransform(549.3,321.5,1,1,0,0,0,549.3,321.5);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(49).to({_off:false},0).to({alpha:1},10).wait(49).to({startPosition:1},0).to({alpha:0},10).to({_off:true},1).wait(48).to({_off:false},0).to({alpha:1},10).wait(1));

	// Ebene 1
	this.instance_1 = new lib.container_pics("single",0);
	this.instance_1.setTransform(549.3,321.5,1,1,0,0,0,549.3,321.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({_off:true},60).wait(48).to({_off:false,startPosition:2},0).wait(70));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,1218,703);


(lib.ani_fadeIn = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.loop = true;
	}
	this.frame_9 = function() {
		this.loop = true;
	}
	this.frame_10 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(9).call(this.frame_9).wait(1).call(this.frame_10).wait(1));

	// Ebene 1
	this.instance = new lib.pic_plane_white();
	this.instance.setTransform(609,351.5,1.052,1.326,0,0,0,579,265);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({alpha:0},9).to({_off:true},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,1218,703);


(lib.ani_inLine = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 20
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#002F6C").s().p("AgMAnQgFgCgDgDQgDgDgBgEIgCgKIALAAQABAIAEADQAEADAGAAQAIAAAEgDQADgDAAgGIgBgFQAAgBAAAAQAAgBgBAAQAAgBAAAAQgBAAAAgBIgEgCIgIgCIgGgCQgJgCgFgEQgGgFAAgKQAAgMAHgGQAIgFALAAQAMAAAHAFQAHAGAAAOIgLAAQgBgIgDgDQgEgDgHAAQgHAAgDADQgDADAAAGQAAAFADADQACACAIACIAGACQAMADAFAEQAEAFAAAKQAAAFgBAEQgCAEgDADQgDADgGABQgFACgHAAQgGAAgGgCg");
	this.shape.setTransform(1381.3,43);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#002F6C").s().p("AgeA5IAAhwIAMAAIAAALQAGgMANAAQAIAAAGACQAFADAEAFQAEAFACAIQABAIAAAKQAAAUgHAKQgIAKgQAAQgLAAgHgKIAAAqgAgHgrQgDABgDAEQgCADgBAGQgCAGAAAIIACAPIADAIQACADAEACQADABAEAAQAFAAAEgBQADgCACgDQACgEACgEIABgPIgBgOQgCgGgCgDQgCgEgDgBIgJgBIgHABg");
	this.shape_1.setTransform(1374,44.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#002F6C").s().p("AgMAnQgGgDgEgFQgEgFgBgIQgCgIAAgKQAAgVAHgJQAJgKAOAAQAIAAAFACQAGADADAFQAEAFACAHQABAIAAAJIAAACIguAAIABAPQABAGACADQACADAEABIAHABQAIAAAEgDQAEgDABgIIALAAQgBAMgGAGQgGAHgPAAQgGAAgHgCgAgFgcQgDABgDADIgDAGIgCALIAiAAQgBgHgBgEQgBgEgCgCQgCgDgDgBIgIAAIgFAAg");
	this.shape_2.setTransform(1366,43);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#002F6C").s().p("AALAyQgWAAAAgaIAAgqIgLAAIAAgLIALAAIAAgTIALAAIAAATIAXAAIAAALIgXAAIAAAqQAAAJACACQADAEAIAAIAKAAIAAALg");
	this.shape_3.setTransform(1359.6,42.1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#002F6C").s().p("AgaAxQgIgJgBgSIAMAAQABAOAGAGQAFAGALAAQALAAAGgFQAGgFAAgKIgBgIQgCgEgDgDQgCgCgEgBIgJgEIgHgCIgLgDQgGgBgDgEQgEgDgCgGQgDgFAAgJQAAgOAJgIQAJgIAQAAQAKgBAGADQAHADAEAFQAEAEACAHQACAHAAAJIgMAAIgCgLQgCgGgDgCQgCgDgFgCIgJgBQgJAAgGAFQgFAEAAAJQAAAGABADIAEAGQADADAEABIAIADIAHACIAMADQAGACAEAEQADADACAGQACAFAAAIQAAAOgJAIQgJAIgSAAQgRABgJgKg");
	this.shape_4.setTransform(1352.5,41.4);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#002F6C").s().p("AAQApIAAgxQAAgLgEgFQgEgDgIgBQgHABgDADQgFAFAAALIAAAxIgNAAIAAhPIAMAAIAAAKQAGgLANAAQANgBAHAIQAFAIABANIAAA0g");
	this.shape_5.setTransform(1340.9,43);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#002F6C").s().p("AgFA5IAAhxIALAAIAABxg");
	this.shape_6.setTransform(1334.9,41.4);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#002F6C").s().p("AgLA4QgGgCgDgDQgDgEgCgFQgCgFAAgGIAMAAQABAJADAEQAEADAHAAQAKAAAEgEQAEgDAAgKIAAgRQgGAMgNAAQgIAAgFgDQgGgCgDgFQgEgFgCgIQgBgGAAgLQAAgWAHgKQAIgKAPAAQAGAAAFADQAFADADAGIAAgKIAMAAIAABVQAAAOgHAHQgIAHgPAAQgHAAgFgCgAgHgsQgEACgCADQgCAEgBAGIgBAOIABAPQABAEACADQACAEAEABQADACAEAAIAIgBQADgCADgDQACgEABgEIABgPIgBgOQgBgGgCgEQgCgDgEgCIgIgBIgHABg");
	this.shape_7.setTransform(1325.3,44.7);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#002F6C").s().p("AAQApIAAgxQAAgLgEgFQgEgDgIgBQgHABgDADQgFAFAAALIAAAxIgNAAIAAhPIAMAAIAAAKQAGgLANAAQANgBAHAIQAFAIAAANIAAA0g");
	this.shape_8.setTransform(1317.5,43);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#002F6C").s().p("AgFA5IAAhPIALAAIAABPgAgFgoIAAgQIALAAIAAAQg");
	this.shape_9.setTransform(1311.7,41.4);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#002F6C").s().p("AgOA3QgGgDgDgFQgEgFgCgIQgBgIAAgLQAAgTAHgKQAIgKAPAAQANAAAFAKIAAgqIANAAIAABwIgMAAIAAgMQgGANgOAAQgIAAgFgCgAgHgLQgEABgCAEQgCADgBAEIgBAOIABAPQABAGACAEQACADAEACQADABAEAAQAFAAADgBQAEgCACgDQACgEABgGIABgPIgBgOQgBgEgCgDQgCgEgEgBIgIgBIgHABg");
	this.shape_10.setTransform(1305.7,41.4);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#002F6C").s().p("AgVAjQgGgFAAgKQAAgHACgEQADgEAEgDQAEgCAFgBIAMgEIAMgCIAAgFQAAgIgDgFQgDgEgJAAQgGAAgEADQgDAEAAAJIgMAAQABgNAGgHQAGgHAOAAQAHAAAFACQAFACADADQADAEABAFQACAFAAAGIAAA1IgNAAIAAgKQgCAEgFAEQgFADgGAAQgMAAgGgGgAAEADIgIACIgGAEQgCABgBADIgBAFQAAANAOAAQAGAAAEgFQAFgFAAgIIAAgLg");
	this.shape_11.setTransform(1298,43);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#002F6C").s().p("AgLA5IAAhEIgKAAIAAgLIAKAAIAAgIQAAgMAGgHQAFgGAMgBIAKAAIAAAMIgJAAQgHAAgDAEQgDACAAAIIAAAIIAUAAIAAALIgUAAIAABEg");
	this.shape_12.setTransform(1292.2,41.4);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#002F6C").s().p("AgnAFIAAgJIBPAAIAAAJg");
	this.shape_13.setTransform(1285,47.8);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#002F6C").s().p("AgFA5IAAhPIALAAIAABPgAgFgoIAAgQIALAAIAAAQg");
	this.shape_14.setTransform(1278.6,41.4);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#002F6C").s().p("AAQApIAAgxQAAgLgEgFQgEgDgIgBQgGABgEADQgFAFAAALIAAAxIgMAAIAAhPIAMAAIAAAKQAEgLAOAAQANgBAGAIQAHAIgBANIAAA0g");
	this.shape_15.setTransform(1273,43);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#002F6C").s().p("AAdA5IgJgcIgpAAIgIAcIgMAAIAjhxIANAAIAjBxgAgRASIAiAAIgRg6g");
	this.shape_16.setTransform(1264.5,41.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).to({state:[]},10).wait(140));

	// Ebene 1
	this.instance = new lib.ani_fadeIn();
	this.instance.setTransform(609,351.5,1,1,0,0,0,609,351.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({_off:true},10).wait(140));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,1425,703);


(lib.timelineJumpWidget = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{step1:0});

	// fadeIn
	this.instance = new lib.ani_inLine("synched",0);
	this.instance.setTransform(609,351.5,1,1,0,0,0,609,351.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(10));

	// popup_09
	this.instance_1 = new lib.ani_text_sideBar01();
	this.instance_1.setTransform(-104.5,351.5,1,1,0,0,0,-104.5,351.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(10));

	// popup_09
	this.instance_2 = new lib.container_text("single",139);
	this.instance_2.setTransform(1430,824.8,1,1,0,0,0,540,224.8);

	this.instance_3 = new lib.container_text("single",2);
	this.instance_3.setTransform(763.6,1102.6,1,1,0,0,0,550,494.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_3},{t:this.instance_2}]}).wait(10));

	// popup_09
	this.instance_4 = new lib.pic_shadow_occlusionRound();
	this.instance_4.setTransform(1255,620.6,3.495,1);
	this.instance_4.alpha = 0.5;

	this.instance_5 = new lib.pic_shadow_occlusionRound();
	this.instance_5.setTransform(1017,620.6,3.495,1);
	this.instance_5.alpha = 0.5;

	this.instance_6 = new lib.pic_shadow_occlusionRound();
	this.instance_6.setTransform(691,620.6,3.495,1);
	this.instance_6.alpha = 0.5;

	this.instance_7 = new lib.pic_shadow_occlusionRound();
	this.instance_7.setTransform(839.3,620.6,3.495,1);
	this.instance_7.alpha = 0.5;

	this.instance_8 = new lib.pic_shadow_occlusionRound();
	this.instance_8.setTransform(707.6,620.6,3.495,1);
	this.instance_8.alpha = 0.5;

	this.instance_9 = new lib.pic_shadow_occlusionRound();
	this.instance_9.setTransform(514.1,620.6,3.495,1);
	this.instance_9.alpha = 0.5;

	this.instance_10 = new lib.pic_shadow_occlusionRound();
	this.instance_10.setTransform(375,637.6,3.495,1);
	this.instance_10.alpha = 0.5;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4}]}).wait(10));

	// popup_10
	this.instance_11 = new lib.ani_pic01();
	this.instance_11.setTransform(609,351.5,1,1,0,0,0,609,351.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(10));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-505.9,-1,2150.6,1099.9);


// stage content:
(lib.c5p1 = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{"I":6});

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_2 = new cjs.Graphics().p("EhfJA26MAAAht0MC+SAAAMAAABt0g");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(2).to({graphics:mask_graphics_2,x:609,y:351.5}).wait(8));

	// timelineJumpWidget
	this.timelineJumpWidget = new lib.timelineJumpWidget();
	this.timelineJumpWidget._off = true;

	this.timelineJumpWidget.mask = mask;

	this.timeline.addTween(cjs.Tween.get(this.timelineJumpWidget).wait(2).to({_off:false},0).wait(8));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;

})(lib = lib||{}, images = images||{}, createjs = createjs||{}, ss = ss||{});
var lib, images, createjs, ss;