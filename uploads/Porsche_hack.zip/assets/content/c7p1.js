(function (lib, img, cjs, ss) {

var p; // shortcut to reference prototypes
lib.webFontTxtFilters = {}; 

// library properties:
lib.properties = {
	width: 1218,
	height: 703,
	fps: 25,
	color: "#FFFFFF",
	opacity: 1.00,
	webfonts: {},
	manifest: [
		{src:"assets/content/images/c7p1_pic01.jpg", id:"c7p1_pic01"},
		{src:"assets/content/images/c7p1_pic02.jpg", id:"c7p1_pic02"},
		{src:"assets/content/images/c7p1_pic03.jpg", id:"c7p1_pic03"},
		{src:"assets/content/images/c7p1_pic04.jpg", id:"c7p1_pic04"},
		{src:"assets/content/images/c7p1_pic05.jpg", id:"c7p1_pic05"}
	]
};



lib.ssMetadata = [];


lib.webfontAvailable = function(family) { 
	lib.properties.webfonts[family] = true;
	var txtFilters = lib.webFontTxtFilters && lib.webFontTxtFilters[family] || [];
	for(var f = 0; f < txtFilters.length; ++f) {
		txtFilters[f].updateCache();
	}
};
// symbols:



(lib.c7p1_pic01 = function() {
	this.initialize(img.c7p1_pic01);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1218,703);


(lib.c7p1_pic02 = function() {
	this.initialize(img.c7p1_pic02);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,620,450);


(lib.c7p1_pic03 = function() {
	this.initialize(img.c7p1_pic03);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,620,450);


(lib.c7p1_pic04 = function() {
	this.initialize(img.c7p1_pic04);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,620,450);


(lib.c7p1_pic05 = function() {
	this.initialize(img.c7p1_pic05);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,620,450);


(lib.scroller_handle = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CC0000").s().p("AgsCVIAAkqIBZAAIAAEqg");
	this.shape.setTransform(4.5,15);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,9,30);


(lib.scroller_back_200 = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CCCCCC").s().p("AgYPnIAA/OIAxAAIAAfOg");
	this.shape.setTransform(2.5,100);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,5,200);


(lib.scroller_back_180 = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CCCCCC").s().p("AgYOEIAA8HIAxAAIAAcHg");
	this.shape.setTransform(2.5,90);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,5,180);


(lib.pic_plane_white = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EhadApaMAAAhSzMC07AAAMAAABSzg");
	this.shape.setTransform(579,265);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,1158,530);


(lib.container_text = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// Ebene 96
	this.text_383 = new cjs.Text("Neu sind die Assistenzsysteme Anhalte­wegverkürzung (AWV), Fußgängerwarnung, Spurhalteassistent und Stauassistent.", "16px 'Porsche Next TT'");
	this.text_383.name = "text_383";
	this.text_383.lineHeight = 23;
	this.text_383.lineWidth = 406;
	this.text_383.setTransform(2,2);
	this.text_383._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_383).wait(382).to({_off:false},0).to({_off:true},1).wait(1));

	// Ebene 97
	this.text_382 = new cjs.Text("Leider nicht richtig.\n\nKlicken Sie auf \"Lösung\".", "16px 'Porsche Next TT'");
	this.text_382.name = "text_382";
	this.text_382.lineHeight = 23;
	this.text_382.lineWidth = 436;
	this.text_382.setTransform(2,2);
	this.text_382._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_382).wait(381).to({_off:false},0).to({_off:true},1).wait(2));

	// Ebene 98
	this.text_381 = new cjs.Text("Noch nicht richtig.\nBitte versuchen Sie es erneut.", "16px 'Porsche Next TT'");
	this.text_381.name = "text_381";
	this.text_381.lineHeight = 23;
	this.text_381.lineWidth = 436;
	this.text_381.setTransform(2,2);
	this.text_381._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_381).wait(380).to({_off:false},0).to({_off:true},1).wait(3));

	// Ebene 99
	this.text_380 = new cjs.Text("Richtig.\n\nNeu sind die Assistenzsysteme Anhalte­wegverkürzung (AWV), Fußgängerwarnung, Spurhalteassistent und Stauassistent.", "16px 'Porsche Next TT'");
	this.text_380.name = "text_380";
	this.text_380.lineHeight = 23;
	this.text_380.lineWidth = 406;
	this.text_380.setTransform(2,2);
	this.text_380._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_380).wait(379).to({_off:false},0).to({_off:true},1).wait(4));

	// Ebene 101
	this.text_378 = new cjs.Text("Stauassistent", "16px 'Porsche Next TT'");
	this.text_378.name = "text_378";
	this.text_378.lineHeight = 23;
	this.text_378.lineWidth = 436;
	this.text_378.setTransform(2,2);
	this.text_378._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_378).wait(377).to({_off:false},0).to({_off:true},1).wait(6));

	// Ebene 102
	this.text_377 = new cjs.Text("Spurwechselassistent", "16px 'Porsche Next TT'");
	this.text_377.name = "text_377";
	this.text_377.lineHeight = 23;
	this.text_377.lineWidth = 436;
	this.text_377.setTransform(2,2);
	this.text_377._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_377).wait(376).to({_off:false},0).to({_off:true},1).wait(7));

	// Ebene 103
	this.text_376 = new cjs.Text("Spurhalteassistent", "16px 'Porsche Next TT'");
	this.text_376.name = "text_376";
	this.text_376.lineHeight = 23;
	this.text_376.lineWidth = 436;
	this.text_376.setTransform(2,2);
	this.text_376._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_376).wait(375).to({_off:false},0).to({_off:true},1).wait(8));

	// Ebene 104
	this.text_375 = new cjs.Text("Fußgängerwarnung", "16px 'Porsche Next TT'");
	this.text_375.name = "text_375";
	this.text_375.lineHeight = 23;
	this.text_375.lineWidth = 436;
	this.text_375.setTransform(2,2);
	this.text_375._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_375).wait(374).to({_off:false},0).to({_off:true},1).wait(9));

	// Ebene 106
	this.text_374 = new cjs.Text("Anhaltewegverkürzung (AWV)", "16px 'Porsche Next TT'");
	this.text_374.name = "text_374";
	this.text_374.lineHeight = 23;
	this.text_374.lineWidth = 436;
	this.text_374.setTransform(2,2);
	this.text_374._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_374).wait(373).to({_off:false},0).to({_off:true},1).wait(10));

	// Ebene 107
	this.text_373 = new cjs.Text("Abstandregeltempostat (ACC)", "16px 'Porsche Next TT'");
	this.text_373.name = "text_373";
	this.text_373.lineHeight = 23;
	this.text_373.lineWidth = 436;
	this.text_373.setTransform(2,2);
	this.text_373._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_373).wait(372).to({_off:false},0).to({_off:true},1).wait(11));

	// Ebene 108
	this.text_372 = new cjs.Text("Welche Assistenzsysteme sind neu beim Macan (MJ 19)?", "bold 16px 'Porsche Next TT'");
	this.text_372.name = "text_372";
	this.text_372.lineHeight = 23;
	this.text_372.lineWidth = 996;
	this.text_372.setTransform(2,2);
	this.text_372._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_372).wait(371).to({_off:false},0).to({_off:true},1).wait(12));

	// Ebene 109
	this.text_371 = new cjs.Text("Bitte klicken Sie die richtigen Antworten an und bestätigen Sie ihre Auswahl durch Klick auf „Auswerten“.\n", "16px 'Porsche Next TT'");
	this.text_371.name = "text_371";
	this.text_371.lineHeight = 23;
	this.text_371.lineWidth = 436;
	this.text_371.setTransform(2,2);
	this.text_371._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_371).wait(370).to({_off:false},0).to({_off:true},1).wait(13));

	// Ebene 67
	this.text_363 = new cjs.Text("Der Abgasreinigungsanlage mit Ottopartikel­filter wird nur in bestimmten Märkten ein­geführt. Die Warnmeldung erscheint ab 70 % Beladung, ein Austausch des Ottopartikelfilters ist ab 100 % Beladung notwendig.", "16px 'Porsche Next TT'");
	this.text_363.name = "text_363";
	this.text_363.lineHeight = 23;
	this.text_363.lineWidth = 406;
	this.text_363.setTransform(2,2);
	this.text_363._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_363).wait(362).to({_off:false},0).to({_off:true},1).wait(21));

	// Ebene 68
	this.text_362 = new cjs.Text("Leider nicht richtig.\n\nKlicken Sie auf \"Lösung\".", "16px 'Porsche Next TT'");
	this.text_362.name = "text_362";
	this.text_362.lineHeight = 23;
	this.text_362.lineWidth = 436;
	this.text_362.setTransform(2,2);
	this.text_362._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_362).wait(361).to({_off:false},0).to({_off:true},1).wait(22));

	// Ebene 76
	this.text_361 = new cjs.Text("Noch nicht richtig.\nBitte versuchen Sie es erneut.", "16px 'Porsche Next TT'");
	this.text_361.name = "text_361";
	this.text_361.lineHeight = 23;
	this.text_361.lineWidth = 436;
	this.text_361.setTransform(2,2);
	this.text_361._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_361).wait(360).to({_off:false},0).to({_off:true},1).wait(23));

	// Ebene 85
	this.text_360 = new cjs.Text("Richtig.\n\nDer Abgasreinigungsanlage mit Ottopartikel­filter wird nur in bestimmten Märkten ein­geführt. Die Warnmeldung erscheint ab 70 % Beladung, ein Austausch des Ottopartikelfilters ist ab 100 % Beladung notwendig.", "16px 'Porsche Next TT'");
	this.text_360.name = "text_360";
	this.text_360.lineHeight = 23;
	this.text_360.lineWidth = 406;
	this.text_360.setTransform(2,2);
	this.text_360._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_360).wait(359).to({_off:false},0).to({_off:true},1).wait(24));

	// Ebene 87
	this.text_358 = new cjs.Text("Ab 90 % Beladung muss der Ottopartikelfilter ausgetauscht werden.", "16px 'Porsche Next TT'");
	this.text_358.name = "text_358";
	this.text_358.lineHeight = 23;
	this.text_358.lineWidth = 436;
	this.text_358.setTransform(2,2);
	this.text_358._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_358).wait(357).to({_off:false},0).to({_off:true},1).wait(26));

	// Ebene 88
	this.text_357 = new cjs.Text("Ab 85 % Beladung ist eine Regeneration in der Werkstatt notwendig.", "16px 'Porsche Next TT'");
	this.text_357.name = "text_357";
	this.text_357.lineHeight = 23;
	this.text_357.lineWidth = 436;
	this.text_357.setTransform(2,2);
	this.text_357._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_357).wait(356).to({_off:false},0).to({_off:true},1).wait(27));

	// Ebene 89
	this.text_356 = new cjs.Text("Ab 60% Beladung erscheint eine Warnmeldung. ", "16px 'Porsche Next TT'");
	this.text_356.name = "text_356";
	this.text_356.lineHeight = 23;
	this.text_356.lineWidth = 436;
	this.text_356.setTransform(2,2);
	this.text_356._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_356).wait(355).to({_off:false},0).to({_off:true},1).wait(28));

	// Ebene 90
	this.text_355 = new cjs.Text("Voraussetzungen für die Regeneration sind mind. 600 °C Abgastemperatur und genügend Sauerstoff im Abgas. ", "16px 'Porsche Next TT'");
	this.text_355.name = "text_355";
	this.text_355.lineHeight = 23;
	this.text_355.lineWidth = 436;
	this.text_355.setTransform(2,2);
	this.text_355._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_355).wait(354).to({_off:false},0).to({_off:true},1).wait(29));

	// Ebene 91
	this.text_354 = new cjs.Text("Es darf nur freigegebenes, aschearmes Motoröl nach Porsche Spezifikation verwendet werden.", "16px 'Porsche Next TT'");
	this.text_354.name = "text_354";
	this.text_354.lineHeight = 23;
	this.text_354.lineWidth = 436;
	this.text_354.setTransform(2,2);
	this.text_354._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_354).wait(353).to({_off:false},0).to({_off:true},1).wait(30));

	// Ebene 92
	this.text_353 = new cjs.Text("Der Abgasreinigungsanlage mit Ottopartikelfilter im Macan wird weltweit eingeführt.", "16px 'Porsche Next TT'");
	this.text_353.name = "text_353";
	this.text_353.lineHeight = 23;
	this.text_353.lineWidth = 436;
	this.text_353.setTransform(2,2);
	this.text_353._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_353).wait(352).to({_off:false},0).to({_off:true},1).wait(31));

	// Ebene 93
	this.text_352 = new cjs.Text("Welche Aussagen zum Ottopartikelfilter sind richtig?", "bold 16px 'Porsche Next TT'");
	this.text_352.name = "text_352";
	this.text_352.lineHeight = 23;
	this.text_352.lineWidth = 996;
	this.text_352.setTransform(2,2);
	this.text_352._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_352).wait(351).to({_off:false},0).to({_off:true},1).wait(32));

	// Ebene 94
	this.text_351 = new cjs.Text("Bitte klicken Sie die richtigen Antworten an und bestätigen Sie ihre Auswahl durch Klick auf „Auswerten“.\n", "16px 'Porsche Next TT'");
	this.text_351.name = "text_351";
	this.text_351.lineHeight = 23;
	this.text_351.lineWidth = 436;
	this.text_351.setTransform(2,2);
	this.text_351._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_351).wait(350).to({_off:false},0).to({_off:true},1).wait(33));

	// Ebene 18
	this.text_343 = new cjs.Text("Der Ionisator der 2. Generation und das Multifunktions-GT-Sportlenkrad sind optional erhältlich. Serienmäßig ist ein  Multifunktions-Lenkrad verbaut.", "16px 'Porsche Next TT'");
	this.text_343.name = "text_343";
	this.text_343.lineHeight = 23;
	this.text_343.lineWidth = 406;
	this.text_343.setTransform(2,2);
	this.text_343._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_343).wait(342).to({_off:false},0).to({_off:true},1).wait(41));

	// Ebene 19
	this.text_342 = new cjs.Text("Leider nicht richtig.\n\nKlicken Sie auf \"Lösung\".", "16px 'Porsche Next TT'");
	this.text_342.name = "text_342";
	this.text_342.lineHeight = 23;
	this.text_342.lineWidth = 436;
	this.text_342.setTransform(2,2);
	this.text_342._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_342).wait(341).to({_off:false},0).to({_off:true},1).wait(42));

	// Ebene 20
	this.text_341 = new cjs.Text("Noch nicht richtig.\nBitte versuchen Sie es erneut.", "16px 'Porsche Next TT'");
	this.text_341.name = "text_341";
	this.text_341.lineHeight = 23;
	this.text_341.lineWidth = 436;
	this.text_341.setTransform(2,2);
	this.text_341._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_341).wait(340).to({_off:false},0).to({_off:true},1).wait(43));

	// Ebene 36
	this.text_340 = new cjs.Text("Richtig.\n\nDer Ionisator der 2. Generation und das Multifunktions-GT-Sportlenkrad sind optional erhältlich. Serienmäßig ist ein  Multifunktions-Lenkrad verbaut.", "16px 'Porsche Next TT'");
	this.text_340.name = "text_340";
	this.text_340.lineHeight = 23;
	this.text_340.lineWidth = 406;
	this.text_340.setTransform(2,2);
	this.text_340._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_340).wait(339).to({_off:false},0).to({_off:true},1).wait(44));

	// Ebene 39
	this.text_337 = new cjs.Text("Serienmäßig ist das Multifunktions-GT-Sportlenkrad verbaut.", "16px 'Porsche Next TT'");
	this.text_337.name = "text_337";
	this.text_337.lineHeight = 23;
	this.text_337.lineWidth = 436;
	this.text_337.setTransform(2,2);
	this.text_337._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_337).wait(336).to({_off:false},0).to({_off:true},1).wait(47));

	// Ebene 40
	this.text_336 = new cjs.Text("Optional ist das Sport Chrono-Paket inkl. Mode-Schalter erhältlich.", "16px 'Porsche Next TT'");
	this.text_336.name = "text_336";
	this.text_336.lineHeight = 23;
	this.text_336.lineWidth = 436;
	this.text_336.setTransform(2,2);
	this.text_336._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_336).wait(335).to({_off:false},0).to({_off:true},1).wait(48));

	// Ebene 41
	this.text_335 = new cjs.Text("Neu sind die Frontscheibenheizung und die Luftführung „Personen Mitte“.", "16px 'Porsche Next TT'");
	this.text_335.name = "text_335";
	this.text_335.lineHeight = 23;
	this.text_335.lineWidth = 436;
	this.text_335.setTransform(2,2);
	this.text_335._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_335).wait(334).to({_off:false},0).to({_off:true},1).wait(49));

	// Ebene 42
	this.text_334 = new cjs.Text("Erstmalig wird serienmäßig für die Luftreinigung im Innenraum ein Ionisator der 2. Generation verbaut.", "16px 'Porsche Next TT'");
	this.text_334.name = "text_334";
	this.text_334.lineHeight = 23;
	this.text_334.lineWidth = 436;
	this.text_334.setTransform(2,2);
	this.text_334._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_334).wait(333).to({_off:false},0).to({_off:true},1).wait(50));

	// Ebene 43
	this.text_333 = new cjs.Text("Der serienmäßig eingebaute Anti-Allergen-Filter besteht aus einer Mikrofaser-, einer Aktivkohle- und einer biofunktionalen Trägerschicht.", "16px 'Porsche Next TT'");
	this.text_333.name = "text_333";
	this.text_333.lineHeight = 23;
	this.text_333.lineWidth = 436;
	this.text_333.setTransform(2,2);
	this.text_333._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_333).wait(332).to({_off:false},0).to({_off:true},1).wait(51));

	// Ebene 64
	this.text_332 = new cjs.Text("Welche Aussagen zum Interieur des Macan (MJ 19) sind richtig?", "bold 16px 'Porsche Next TT'");
	this.text_332.name = "text_332";
	this.text_332.lineHeight = 23;
	this.text_332.lineWidth = 996;
	this.text_332.setTransform(2,2);
	this.text_332._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_332).wait(331).to({_off:false},0).to({_off:true},1).wait(52));

	// Ebene 65
	this.text_331 = new cjs.Text("Bitte klicken Sie die richtigen Antworten an und bestätigen Sie ihre Auswahl durch Klick auf „Auswerten“.\n", "16px 'Porsche Next TT'");
	this.text_331.name = "text_331";
	this.text_331.lineHeight = 23;
	this.text_331.lineWidth = 436;
	this.text_331.setTransform(2,2);
	this.text_331._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_331).wait(330).to({_off:false},0).to({_off:true},1).wait(53));

	// Ebene 149
	this.text_323 = new cjs.Text("Das neue Exterieur des Macan (MJ 19) zeichnet sich aus durch das neue 3D-Leuchtband mit 4-Punkt Bremslichtern und den serienmäßigen LED-Hauptscheinwerfern, welche optional auch mit PDLS+ erhältlich sind. \nBeim Macan Turbo ist der Dachkantenspoiler zweiteilig aufgebaut. Die Nebelscheinwerfer und Scheinwerferreinigungsanlage entfallen.", "16px 'Porsche Next TT'");
	this.text_323.name = "text_323";
	this.text_323.lineHeight = 23;
	this.text_323.lineWidth = 406;
	this.text_323.setTransform(2,2);
	this.text_323._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_323).wait(322).to({_off:false},0).to({_off:true},1).wait(61));

	// Ebene 148
	this.text_322 = new cjs.Text("Leider nicht richtig.\n\nKlicken Sie auf \"Lösung\".", "16px 'Porsche Next TT'");
	this.text_322.name = "text_322";
	this.text_322.lineHeight = 23;
	this.text_322.lineWidth = 436;
	this.text_322.setTransform(2,2);
	this.text_322._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_322).wait(321).to({_off:false},0).to({_off:true},1).wait(62));

	// Ebene 147
	this.text_321 = new cjs.Text("Noch nicht richtig.\nBitte versuchen Sie es erneut.", "16px 'Porsche Next TT'");
	this.text_321.name = "text_321";
	this.text_321.lineHeight = 23;
	this.text_321.lineWidth = 436;
	this.text_321.setTransform(2,2);
	this.text_321._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_321).wait(320).to({_off:false},0).to({_off:true},1).wait(63));

	// Ebene 138
	this.text_320 = new cjs.Text("Richtig.\n\nDas neue Exterieur des Macan (MJ 19) zeichnet sich aus durch das neue 3D-Leuchtband mit 4-Punkt Bremslichtern und den serienmäßigen LED-Hauptscheinwerfern, welche optional auch mit PDLS+ erhältlich sind. \nBeim Macan Turbo ist der Dachkantenspoiler zweiteilig aufgebaut. Die Nebelscheinwerfer und Scheinwerferreinigungsanlage entfallen.", "16px 'Porsche Next TT'");
	this.text_320.name = "text_320";
	this.text_320.lineHeight = 23;
	this.text_320.lineWidth = 406;
	this.text_320.setTransform(2,2);
	this.text_320._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_320).wait(319).to({_off:false},0).to({_off:true},1).wait(64));

	// Ebene 4
	this.text_318 = new cjs.Text("Zweiteiliger Dachkantenspoiler serienmäßig", "16px 'Porsche Next TT'");
	this.text_318.name = "text_318";
	this.text_318.lineHeight = 23;
	this.text_318.lineWidth = 436;
	this.text_318.setTransform(2,2);
	this.text_318._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_318).wait(317).to({_off:false},0).to({_off:true},1).wait(66));

	// Ebene 3
	this.text_317 = new cjs.Text("Scheinwerferreinigungsanlage optional", "16px 'Porsche Next TT'");
	this.text_317.name = "text_317";
	this.text_317.lineHeight = 23;
	this.text_317.lineWidth = 436;
	this.text_317.setTransform(2,2);
	this.text_317._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_317).wait(316).to({_off:false},0).to({_off:true},1).wait(67));

	// Ebene 137
	this.text_316 = new cjs.Text("PDLS+ optional", "16px 'Porsche Next TT'");
	this.text_316.name = "text_316";
	this.text_316.lineHeight = 23;
	this.text_316.lineWidth = 436;
	this.text_316.setTransform(2,2);
	this.text_316._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_316).wait(315).to({_off:false},0).to({_off:true},1).wait(68));

	// Ebene 136
	this.text_315 = new cjs.Text("Nebelscheinwerfer serienmäßig", "16px 'Porsche Next TT'");
	this.text_315.name = "text_315";
	this.text_315.lineHeight = 23;
	this.text_315.lineWidth = 436;
	this.text_315.setTransform(2,2);
	this.text_315._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_315).wait(314).to({_off:false},0).to({_off:true},1).wait(69));

	// Ebene 135
	this.text_314 = new cjs.Text("LED-Hauptscheinwerfer serienmäßig", "16px 'Porsche Next TT'");
	this.text_314.name = "text_314";
	this.text_314.lineHeight = 23;
	this.text_314.lineWidth = 436;
	this.text_314.setTransform(2,2);
	this.text_314._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_314).wait(313).to({_off:false},0).to({_off:true},1).wait(70));

	// Ebene 134
	this.text_313 = new cjs.Text("3D-Leuchtband mit 4-Punkt Bremslichtern", "16px 'Porsche Next TT'");
	this.text_313.name = "text_313";
	this.text_313.lineHeight = 23;
	this.text_313.lineWidth = 436;
	this.text_313.setTransform(2,2);
	this.text_313._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_313).wait(312).to({_off:false},0).to({_off:true},1).wait(71));

	// Ebene 133
	this.text_312 = new cjs.Text("Welche Änderungen am Exterieur des Macan (MJ 19) gegenüber dem Vorgängermodell kennen Sie?", "bold 16px 'Porsche Next TT'");
	this.text_312.name = "text_312";
	this.text_312.lineHeight = 23;
	this.text_312.lineWidth = 996;
	this.text_312.setTransform(2,2);
	this.text_312._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_312).wait(311).to({_off:false},0).to({_off:true},1).wait(72));

	// Ebene 124
	this.text_311 = new cjs.Text("Bitte klicken Sie die richtigen Antworten an und bestätigen Sie ihre Auswahl durch Klick auf „Auswerten“.\n", "16px 'Porsche Next TT'");
	this.text_311.name = "text_311";
	this.text_311.lineHeight = 23;
	this.text_311.lineWidth = 436;
	this.text_311.setTransform(2,2);
	this.text_311._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_311).wait(310).to({_off:false},0).to({_off:true},1).wait(73));

	// Ebene 122
	this.text_301 = new cjs.Text("Lösung", "24px 'Porsche Next TT Thin'", "#FFFFFF");
	this.text_301.name = "text_301";
	this.text_301.textAlign = "center";
	this.text_301.lineHeight = 37;
	this.text_301.lineWidth = 156;
	this.text_301.setTransform(80,2);
	this.text_301._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_301).wait(300).to({_off:false},0).to({_off:true},1).wait(83));

	// Ebene 125
	this.text_300 = new cjs.Text("Auswerten", "24px 'Porsche Next TT Thin'", "#FFFFFF");
	this.text_300.name = "text_300";
	this.text_300.textAlign = "center";
	this.text_300.lineHeight = 37;
	this.text_300.lineWidth = 156;
	this.text_300.setTransform(80,2);
	this.text_300._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_300).wait(299).to({_off:false},0).to({_off:true},1).wait(84));

	// Ebene 2
	this.text_50 = new cjs.Text("Start Quiz", "16px 'Porsche Next TT'", "#FFFFFF");
	this.text_50.name = "text_50";
	this.text_50.lineHeight = 23;
	this.text_50.lineWidth = 236;
	this.text_50.setTransform(2,2);
	this.text_50._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_50).wait(49).to({_off:false},0).to({_off:true},1).wait(334));

	// Ebene 8
	this.text_11 = new cjs.Text("Testen Sie Ihr Wissen mit den folgenden Fragen rund um die Neuerungen am Porsche Macan (MJ 19) Facelift.", "16px 'Porsche Next TT'", "#FFFFFF");
	this.text_11.name = "text_11";
	this.text_11.lineHeight = 23;
	this.text_11.lineWidth = 356;
	this.text_11.setTransform(2,2);
	this.text_11._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_11).wait(10).to({_off:false},0).to({_off:true},1).wait(373));

	// Ebene 5
	this.text_10 = new cjs.Text("Quiz", "32px 'Porsche Next TT Thin'", "#FFFFFF");
	this.text_10.name = "text_10";
	this.text_10.lineHeight = 47;
	this.text_10.lineWidth = 336;
	this.text_10.setTransform(2,2);
	this.text_10._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_10).wait(9).to({_off:false},0).to({_off:true},1).wait(374));

	// Ebene 7
	this.text_02 = new cjs.Text("Sie haben das Ende des Online Trainings erreicht.\n\nSie kennen nun die Highlights des Porsche Macan (MJ 19) Facelift:\n\n• durchgängiges 3D-Leuchtenband am Heck \n• LED-Hauptscheinwerfer serienmäßig\n• 3,0-Liter V6-Monoturbo-Ottomotor  (Macan S)\n• Ottopartikelfilter \n• neues PCM 5.1 mit hochauflösendem 10,9-Zoll-Touchdisplay \n\nneue Assistenzsysteme: \n• Fußgängerwarnung \n• Anhaltewegverkürzung (AWV) \n• Stauassistent,\n• Spurhalteassistent", "16px 'Porsche Next TT'");
	this.text_02.name = "text_02";
	this.text_02.lineHeight = 23;
	this.text_02.lineWidth = 336;
	this.text_02.setTransform(2,2);
	this.text_02._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_02).wait(1).to({_off:false},0).to({_off:true},1).wait(382));

	// Ebene 6
	this.text_01 = new cjs.Text("Glückwunsch!", "32px 'Porsche Next TT Thin'");
	this.text_01.name = "text_01";
	this.text_01.lineHeight = 47;
	this.text_01.lineWidth = 356;
	this.text_01.setTransform(2,2);

	this.timeline.addTween(cjs.Tween.get(this.text_01).to({_off:true},1).wait(383));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,360,50.9);


(lib.container_pics = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// Ebene 4
	this.instance = new lib.c7p1_pic01();

	this.instance_1 = new lib.c7p1_pic02();

	this.instance_2 = new lib.c7p1_pic03();

	this.instance_3 = new lib.c7p1_pic04();

	this.instance_4 = new lib.c7p1_pic05();

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,1218,703);


(lib.btn_blind_rectangle = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("Aj5D6IAAnzIHzAAIAAHzg");
	this.shape.setTransform(25,25);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(3).to({_off:false},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.wrong = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// mark
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#990000").ss(3,2,0,3).p("AgugvIAuAvIAvAvAgvAvIAvgvIAvgv");
	this.shape.setTransform(10.3,8);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(3.4,1.1,13.8,13.8);


(lib.selection = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// checked
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("Ag7A7IAAh2IB2AAIAAB2g");
	this.shape.setTransform(10.5,10.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(4.5,4.5,12,12);


(lib.correct = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#20C813").ss(3,2,0,3).p("AhBggIBBBBIBChB");
	this.shape.setTransform(6.7,10);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-2.1,4.6,17.6,10.9);


(lib.text363 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.instance = new lib.container_text("single",362);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,410,97.8);


(lib.text360 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.instance = new lib.container_text("single",359);
	this.instance.setTransform(550,236.5,1,1,0,0,0,550,236.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,410,144.7);


(lib.text343 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.instance = new lib.container_text("single",342);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,410,74.4);


(lib.text340 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.instance = new lib.container_text("single",339);
	this.instance.setTransform(550,236.5,1,1,0,0,0,550,236.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,410,121.3);


(lib.text323 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.instance = new lib.container_text("single",322);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,410,168.2);


(lib.text320 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.instance = new lib.container_text("single",319);
	this.instance.setTransform(550,236.5,1,1,0,0,0,550,236.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,410,215.1);


(lib.solutionBtn = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// Ebene 2
	this.instance = new lib.btn_blind_rectangle();
	this.instance.setTransform(0,0,3.2,0.8);
	new cjs.ButtonHelper(this.instance, 0, 1, 2, false, new lib.btn_blind_rectangle(), 3);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// text
	this.instance_1 = new lib.container_text("single",300);
	this.instance_1.setTransform(0,2);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	// background
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D5001C").s().dr(-80,-20,160,40);
	this.shape.setTransform(80,20);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,160,42);


(lib.scroller_200 = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.slider = new lib.scroller_handle();

	this.bg = new lib.scroller_back_200();
	this.bg.setTransform(2,0);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.bg},{t:this.slider}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,9,200);


(lib.scroller_180 = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.slider = new lib.scroller_handle();

	this.bg = new lib.scroller_back_180();
	this.bg.setTransform(2,0);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.bg},{t:this.slider}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,9,180);


(lib.choice = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// selection
	this.selection = new lib.selection();
	this.selection.visible = false;

	this.timeline.addTween(cjs.Tween.get(this.selection).wait(1));

	// wrong
	this.wrong = new lib.wrong();
	this.wrong.setTransform(-14.5,10.1,1,1,0,0,0,6.9,6.9);
	this.wrong.visible = false;

	this.timeline.addTween(cjs.Tween.get(this.wrong).wait(1));

	// correct
	this.correct = new lib.correct();
	this.correct.setTransform(-11,10.1,1,1,0,0,0,6.9,6.9);
	this.correct.visible = false;

	this.timeline.addTween(cjs.Tween.get(this.correct).wait(1));

	// rahmen
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,2,0,3).p("ABkBkIjHAAIAAjHIDHAAg");
	this.shape.setTransform(10.5,10.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AhiBkIAAjGIDGAAIAADGg");
	this.shape_1.setTransform(10.5,10.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-19.9,-0.5,41.4,22);


(lib.checkBtn = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// Ebene 2
	this.instance = new lib.btn_blind_rectangle();
	this.instance.setTransform(0,0,3.2,0.8);
	new cjs.ButtonHelper(this.instance, 0, 1, 2, false, new lib.btn_blind_rectangle(), 3);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// text
	this.instance_1 = new lib.container_text("single",299);
	this.instance_1.setTransform(0,2);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	// background
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D5001C").s().dr(-80,-20,160,40);
	this.shape.setTransform(80,20);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,160,42);


(lib.ani_fadeIn = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.loop = true;
	}
	this.frame_9 = function() {
		this.loop = true;
	}
	this.frame_10 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(9).call(this.frame_9).wait(1).call(this.frame_10).wait(1));

	// Ebene 1
	this.instance = new lib.pic_plane_white();
	this.instance.setTransform(609,351.5,1.052,1.326,0,0,0,579,265);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({alpha:0},9).to({_off:true},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,1218,703);


(lib.scroller_text363 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 2
	this.scrollerItem = new lib.scroller_180();
	this.scrollerItem.setTransform(430,0);

	this.timeline.addTween(cjs.Tween.get(this.scrollerItem).wait(1));

	// Ebene 1
	this.scrollerContent = new lib.text363();

	this.timeline.addTween(cjs.Tween.get(this.scrollerContent).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,439,180);


(lib.scroller_text360 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.scrollerItem = new lib.scroller_180();
	this.scrollerItem.setTransform(430,0);

	this.scrollerContent = new lib.text360();

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.scrollerContent},{t:this.scrollerItem}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,439,180);


(lib.scroller_text343 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 2
	this.scrollerItem = new lib.scroller_180();
	this.scrollerItem.setTransform(430,0);

	this.timeline.addTween(cjs.Tween.get(this.scrollerItem).wait(1));

	// Ebene 1
	this.scrollerContent = new lib.text343();

	this.timeline.addTween(cjs.Tween.get(this.scrollerContent).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,439,180);


(lib.scroller_text340 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.scrollerItem = new lib.scroller_180();
	this.scrollerItem.setTransform(430,0);

	this.scrollerContent = new lib.text340();

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.scrollerContent},{t:this.scrollerItem}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,439,180);


(lib.scroller_text320 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.scrollerItem = new lib.scroller_200();
	this.scrollerItem.setTransform(430,0);

	this.scrollerContent = new lib.text320();

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.scrollerContent},{t:this.scrollerItem}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,439,215.1);


(lib.scroller_text232 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 2
	this.scrollerItem = new lib.scroller_200();
	this.scrollerItem.setTransform(430,0);

	this.timeline.addTween(cjs.Tween.get(this.scrollerItem).wait(1));

	// Ebene 1
	this.scrollerContent = new lib.text323();

	this.timeline.addTween(cjs.Tween.get(this.scrollerContent).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,439,200);


(lib.exercise04 = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{correct:14,wrong:34,wrong1:49,solution:79});

	// timeline functions:
	this.frame_0 = function() {
		this.dispatchEvent(new createjs.Event("RESET"), true);
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(102));

	// checkBtn
	this.checkBtn = new lib.checkBtn();
	this.checkBtn.setTransform(800,435,1,1,0,0,0,75,15);

	this.timeline.addTween(cjs.Tween.get(this.checkBtn).wait(102));

	// solutionBtn
	this.solutionBtn = new lib.solutionBtn();
	this.solutionBtn.setTransform(800,435,1,1,0,0,0,75,15);
	this.solutionBtn.visible = false;

	this.timeline.addTween(cjs.Tween.get(this.solutionBtn).wait(102));

	// container_text
	this.instance = new lib.container_text("single",350);
	this.instance.setTransform(1275,706.5,1,1,0,0,0,550,236.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(14).to({startPosition:379},0).wait(20).to({startPosition:380},0).wait(15).to({startPosition:381},0).wait(30).to({regX:0,regY:0,x:725,y:470,startPosition:382},0).wait(23));

	// drop_1
	this.choice_4_correct = new lib.choice();
	this.choice_4_correct.setTransform(715,244,1,1,0,0,0,20.5,0.5);

	this.choice_3_correct = new lib.choice();
	this.choice_3_correct.setTransform(715,204,1,1,0,0,0,20.5,0.5);

	this.choice_2_correct = new lib.choice();
	this.choice_2_correct.setTransform(715,164,1,1,0,0,0,20.5,0.5);

	this.choice_1 = new lib.choice();
	this.choice_1.setTransform(715,124,1,1,0,0,0,20.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.choice_1},{t:this.choice_2_correct},{t:this.choice_3_correct},{t:this.choice_4_correct}]}).wait(102));

	// container_text
	this.choice_6_correct = new lib.choice();
	this.choice_6_correct.setTransform(715,324,1,1,0,0,0,20.5,0.5);

	this.instance_1 = new lib.container_text("single",377);
	this.instance_1.setTransform(1275,556.5,1,1,0,0,0,550,236.5);

	this.choice_5 = new lib.choice();
	this.choice_5.setTransform(715,284,1,1,0,0,0,20.5,0.5);

	this.instance_2 = new lib.container_text("single",376);
	this.instance_2.setTransform(1275,516.5,1,1,0,0,0,550,236.5);

	this.instance_3 = new lib.container_text("single",371);
	this.instance_3.setTransform(599.6,286.5,1,1,0,0,0,550,236.5);

	this.instance_4 = new lib.container_text("single",375);
	this.instance_4.setTransform(1275,476.5,1,1,0,0,0,550,236.5);

	this.instance_5 = new lib.container_text("single",374);
	this.instance_5.setTransform(1275,436.5,1,1,0,0,0,550,236.5);

	this.instance_6 = new lib.container_text("single",373);
	this.instance_6.setTransform(1275,396.5,1,1,0,0,0,550,236.5);

	this.instance_7 = new lib.container_text("single",372);
	this.instance_7.setTransform(1275,356.5,1,1,0,0,0,550,236.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.choice_5},{t:this.instance_1},{t:this.choice_6_correct}]}).wait(102));

	// container_pics
	this.instance_8 = new lib.container_pics("single",4);
	this.instance_8.setTransform(50,120);

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(102));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(49.6,50,1115.4,541.3);


(lib.exercise03 = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{"correct":14,"wrong":34,"wrong1":49,"solution":79});

	// timeline functions:
	this.frame_0 = function() {
		this.dispatchEvent(new createjs.Event("RESET"), true);
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(102));

	// checkBtn
	this.checkBtn = new lib.checkBtn();
	this.checkBtn.setTransform(800,435,1,1,0,0,0,75,15);

	this.timeline.addTween(cjs.Tween.get(this.checkBtn).wait(102));

	// solutionBtn
	this.solutionBtn = new lib.solutionBtn();
	this.solutionBtn.setTransform(800,435,1,1,0,0,0,75,15);
	this.solutionBtn.visible = false;

	this.timeline.addTween(cjs.Tween.get(this.solutionBtn).wait(102));

	// container_text
	this.instance = new lib.container_text("single",350);
	this.instance.setTransform(1275,706.5,1,1,0,0,0,550,236.5);

	this.scrollerWidget = new lib.scroller_text360();
	this.scrollerWidget.setTransform(725,470);

	this.scrollerWidget_1 = new lib.scroller_text363();
	this.scrollerWidget_1.setTransform(1002.5,588.3,1,1,0,0,0,277.5,118.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance,p:{startPosition:350}}]}).to({state:[{t:this.scrollerWidget}]},14).to({state:[{t:this.instance,p:{startPosition:360}}]},20).to({state:[{t:this.instance,p:{startPosition:361}}]},15).to({state:[{t:this.scrollerWidget_1}]},30).wait(23));

	// drop_1
	this.choice_4 = new lib.choice();
	this.choice_4.setTransform(715,306,1,1,0,0,0,20.5,0.5);

	this.choice_3_correct = new lib.choice();
	this.choice_3_correct.setTransform(715,246,1,1,0,0,0,20.5,0.5);

	this.choice_2_correct = new lib.choice();
	this.choice_2_correct.setTransform(715,186,1,1,0,0,0,20.5,0.5);

	this.choice_1 = new lib.choice();
	this.choice_1.setTransform(715,124,1,1,0,0,0,20.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.choice_1},{t:this.choice_2_correct},{t:this.choice_3_correct},{t:this.choice_4}]}).wait(102));

	// container_text
	this.choice_6 = new lib.choice();
	this.choice_6.setTransform(715,386,1,1,0,0,0,20.5,0.5);

	this.instance_1 = new lib.container_text("single",357);
	this.instance_1.setTransform(1275,618.5,1,1,0,0,0,550,236.5);

	this.choice_5_correct = new lib.choice();
	this.choice_5_correct.setTransform(715,346,1,1,0,0,0,20.5,0.5);

	this.instance_2 = new lib.container_text("single",356);
	this.instance_2.setTransform(1275,578.5,1,1,0,0,0,550,236.5);

	this.instance_3 = new lib.container_text("single",351);
	this.instance_3.setTransform(599.6,286.5,1,1,0,0,0,550,236.5);

	this.instance_4 = new lib.container_text("single",355);
	this.instance_4.setTransform(1275,538.5,1,1,0,0,0,550,236.5);

	this.instance_5 = new lib.container_text("single",354);
	this.instance_5.setTransform(1275,478.5,1,1,0,0,0,550,236.5);

	this.instance_6 = new lib.container_text("single",353);
	this.instance_6.setTransform(1275,418.5,1,1,0,0,0,550,236.5);

	this.instance_7 = new lib.container_text("single",352);
	this.instance_7.setTransform(1275,356.5,1,1,0,0,0,550,236.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.choice_5_correct},{t:this.instance_1},{t:this.choice_6}]}).wait(102));

	// container_pics
	this.instance_8 = new lib.container_pics("single",3);
	this.instance_8.setTransform(50,120);

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(102));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(49.6,50,1115.4,541.3);


(lib.exercise02 = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{"correct":14,"wrong":34,"wrong1":49,"solution":79});

	// timeline functions:
	this.frame_0 = function() {
		this.dispatchEvent(new createjs.Event("RESET"), true);
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(102));

	// checkBtn
	this.checkBtn = new lib.checkBtn();
	this.checkBtn.setTransform(800,425,1,1,0,0,0,75,15);

	this.timeline.addTween(cjs.Tween.get(this.checkBtn).wait(102));

	// solutionBtn
	this.solutionBtn = new lib.solutionBtn();
	this.solutionBtn.setTransform(800,425,1,1,0,0,0,75,15);
	this.solutionBtn.visible = false;

	this.timeline.addTween(cjs.Tween.get(this.solutionBtn).wait(102));

	// container_text
	this.instance = new lib.container_text("single",330);
	this.instance.setTransform(1275,696.5,1,1,0,0,0,550,236.5);

	this.scrollerWidget = new lib.scroller_text340();
	this.scrollerWidget.setTransform(725,460);

	this.scrollerWidget_1 = new lib.scroller_text343();
	this.scrollerWidget_1.setTransform(1002.5,578.3,1,1,0,0,0,277.5,118.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance,p:{startPosition:330}}]}).to({state:[{t:this.scrollerWidget}]},14).to({state:[{t:this.instance,p:{startPosition:340}}]},20).to({state:[{t:this.instance,p:{startPosition:341}}]},15).to({state:[{t:this.scrollerWidget_1}]},30).wait(23));

	// drop_1
	this.choice_4_correct = new lib.choice();
	this.choice_4_correct.setTransform(715,326,1,1,0,0,0,20.5,0.5);

	this.choice_3_correct = new lib.choice();
	this.choice_3_correct.setTransform(715,266,1,1,0,0,0,20.5,0.5);

	this.choice_2 = new lib.choice();
	this.choice_2.setTransform(715,206,1,1,0,0,0,20.5,0.5);

	this.choice_1_correct = new lib.choice();
	this.choice_1_correct.setTransform(715,124,1,1,0,0,0,20.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.choice_1_correct},{t:this.choice_2},{t:this.choice_3_correct},{t:this.choice_4_correct}]}).wait(102));

	// container_text
	this.choice_5 = new lib.choice();
	this.choice_5.setTransform(715,366,1,1,0,0,0,20.5,0.5);

	this.instance_1 = new lib.container_text("single",336);
	this.instance_1.setTransform(1275,598.5,1,1,0,0,0,550,236.5);

	this.instance_2 = new lib.container_text("single",331);
	this.instance_2.setTransform(599.6,286.5,1,1,0,0,0,550,236.5);

	this.instance_3 = new lib.container_text("single",335);
	this.instance_3.setTransform(1275,558.5,1,1,0,0,0,550,236.5);

	this.instance_4 = new lib.container_text("single",334);
	this.instance_4.setTransform(1275,498.5,1,1,0,0,0,550,236.5);

	this.instance_5 = new lib.container_text("single",333);
	this.instance_5.setTransform(1275,438.5,1,1,0,0,0,550,236.5);

	this.instance_6 = new lib.container_text("single",332);
	this.instance_6.setTransform(1275,356.5,1,1,0,0,0,550,236.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.choice_5}]}).wait(102));

	// container_pics
	this.instance_7 = new lib.container_pics("single",2);
	this.instance_7.setTransform(50,120);

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(102));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(49.6,50,1115.4,531.3);


(lib.exercise01 = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{"correct":14,"wrong":34,"wrong1":49,"solution":79});

	// timeline functions:
	this.frame_0 = function() {
		this.dispatchEvent(new createjs.Event("RESET"), true);
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(102));

	// checkBtn
	this.checkBtn = new lib.checkBtn();
	this.checkBtn.setTransform(800,395,1,1,0,0,0,75,15);

	this.timeline.addTween(cjs.Tween.get(this.checkBtn).wait(102));

	// solutionBtn
	this.solutionBtn = new lib.solutionBtn();
	this.solutionBtn.setTransform(800,395,1,1,0,0,0,75,15);
	this.solutionBtn.visible = false;

	this.timeline.addTween(cjs.Tween.get(this.solutionBtn).wait(102));

	// container_text
	this.instance = new lib.container_text("single",310);
	this.instance.setTransform(1275,666.5,1,1,0,0,0,550,236.5);

	this.scrollerWidget = new lib.scroller_text320();
	this.scrollerWidget.setTransform(725,430);

	this.scrollerWidget_1 = new lib.scroller_text232();
	this.scrollerWidget_1.setTransform(1002.5,548.3,1,1,0,0,0,277.5,118.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance,p:{startPosition:310}}]}).to({state:[{t:this.scrollerWidget}]},14).to({state:[{t:this.instance,p:{startPosition:320}}]},20).to({state:[{t:this.instance,p:{startPosition:321}}]},15).to({state:[{t:this.scrollerWidget_1}]},30).wait(23));

	// drop_1
	this.choice_4_correct = new lib.choice();
	this.choice_4_correct.setTransform(715,244,1,1,0,0,0,20.5,0.5);

	this.choice_3 = new lib.choice();
	this.choice_3.setTransform(715,204,1,1,0,0,0,20.5,0.5);

	this.choice_2_correct = new lib.choice();
	this.choice_2_correct.setTransform(715,164,1,1,0,0,0,20.5,0.5);

	this.choice_1_correct = new lib.choice();
	this.choice_1_correct.setTransform(715,124,1,1,0,0,0,20.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.choice_1_correct},{t:this.choice_2_correct},{t:this.choice_3},{t:this.choice_4_correct}]}).wait(102));

	// container_text
	this.choice_6 = new lib.choice();
	this.choice_6.setTransform(715,324,1,1,0,0,0,20.5,0.5);

	this.instance_1 = new lib.container_text("single",317);
	this.instance_1.setTransform(1275,556.5,1,1,0,0,0,550,236.5);

	this.choice_5 = new lib.choice();
	this.choice_5.setTransform(715,284,1,1,0,0,0,20.5,0.5);

	this.instance_2 = new lib.container_text("single",316);
	this.instance_2.setTransform(1275,516.5,1,1,0,0,0,550,236.5);

	this.instance_3 = new lib.container_text("single",311);
	this.instance_3.setTransform(599.6,286.5,1,1,0,0,0,550,236.5);

	this.instance_4 = new lib.container_text("single",315);
	this.instance_4.setTransform(1275,476.5,1,1,0,0,0,550,236.5);

	this.instance_5 = new lib.container_text("single",314);
	this.instance_5.setTransform(1275,436.5,1,1,0,0,0,550,236.5);

	this.instance_6 = new lib.container_text("single",313);
	this.instance_6.setTransform(1275,396.5,1,1,0,0,0,550,236.5);

	this.instance_7 = new lib.container_text("single",312);
	this.instance_7.setTransform(1275,356.5,1,1,0,0,0,550,236.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.choice_5},{t:this.instance_1},{t:this.choice_6}]}).wait(102));

	// container_pics
	this.instance_8 = new lib.container_pics("single",1);
	this.instance_8.setTransform(50,120);

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(102));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(49.6,50,1115.4,520);


(lib.ani_inLine = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 20
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D5001C").s().p("AgMAnQgFgCgDgDQgDgDgBgEIgCgKIALAAQABAIAEADQAEADAGAAQAIAAAEgDQADgDAAgGIgBgFQAAgBAAAAQAAgBgBAAQAAgBAAAAQgBAAAAgBIgEgCIgIgCIgGgCQgJgCgFgEQgGgFAAgKQAAgMAHgGQAIgFALAAQAMAAAHAFQAHAGAAAOIgLAAQgBgIgDgDQgEgDgHAAQgHAAgDADQgDADAAAGQAAAFADADQACACAIACIAGACQAMADAFAEQAEAFAAAKQAAAFgBAEQgCAEgDADQgDADgGABQgFACgHAAQgGAAgGgCg");
	this.shape.setTransform(1381.3,43);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#D5001C").s().p("AgeA5IAAhwIAMAAIAAALQAGgMANAAQAIAAAGACQAFADAEAFQAEAFACAIQABAIAAAKQAAAUgHAKQgIAKgQAAQgLAAgHgKIAAAqgAgHgrQgDABgDAEQgCADgBAGQgCAGAAAIIACAPIADAIQACADAEACQADABAEAAQAFAAAEgBQADgCACgDQACgEACgEIABgPIgBgOQgCgGgCgDQgCgEgDgBIgJgBIgHABg");
	this.shape_1.setTransform(1374,44.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#D5001C").s().p("AgMAnQgGgDgEgFQgEgFgBgIQgCgIAAgKQAAgVAHgJQAJgKAOAAQAIAAAFACQAGADADAFQAEAFACAHQABAIAAAJIAAACIguAAIABAPQABAGACADQACADAEABIAHABQAIAAAEgDQAEgDABgIIALAAQgBAMgGAGQgGAHgPAAQgGAAgHgCgAgFgcQgDABgDADIgDAGIgCALIAiAAQgBgHgBgEQgBgEgCgCQgCgDgDgBIgIAAIgFAAg");
	this.shape_2.setTransform(1366,43);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#D5001C").s().p("AALAyQgWAAAAgaIAAgqIgLAAIAAgLIALAAIAAgTIALAAIAAATIAXAAIAAALIgXAAIAAAqQAAAJACACQADAEAIAAIAKAAIAAALg");
	this.shape_3.setTransform(1359.6,42.1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#D5001C").s().p("AgaAxQgIgJgBgSIAMAAQABAOAGAGQAFAGALAAQALAAAGgFQAGgFAAgKIgBgIQgCgEgDgDQgCgCgEgBIgJgEIgHgCIgLgDQgGgBgDgEQgEgDgCgGQgDgFAAgJQAAgOAJgIQAJgIAQAAQAKgBAGADQAHADAEAFQAEAEACAHQACAHAAAJIgMAAIgCgLQgCgGgDgCQgCgDgFgCIgJgBQgJAAgGAFQgFAEAAAJQAAAGABADIAEAGQADADAEABIAIADIAHACIAMADQAGACAEAEQADADACAGQACAFAAAIQAAAOgJAIQgJAIgSAAQgRABgJgKg");
	this.shape_4.setTransform(1352.5,41.4);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#D5001C").s().p("AAQApIAAgxQAAgLgEgFQgEgDgIgBQgHABgDADQgFAFAAALIAAAxIgNAAIAAhPIAMAAIAAAKQAGgLANAAQANgBAHAIQAFAIABANIAAA0g");
	this.shape_5.setTransform(1340.9,43);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#D5001C").s().p("AgFA5IAAhxIALAAIAABxg");
	this.shape_6.setTransform(1334.9,41.4);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#D5001C").s().p("AgLA4QgGgCgDgDQgDgEgCgFQgCgFAAgGIAMAAQABAJADAEQAEADAHAAQAKAAAEgEQAEgDAAgKIAAgRQgGAMgNAAQgIAAgFgDQgGgCgDgFQgEgFgCgIQgBgGAAgLQAAgWAHgKQAIgKAPAAQAGAAAFADQAFADADAGIAAgKIAMAAIAABVQAAAOgHAHQgIAHgPAAQgHAAgFgCgAgHgsQgEACgCADQgCAEgBAGIgBAOIABAPQABAEACADQACAEAEABQADACAEAAIAIgBQADgCADgDQACgEABgEIABgPIgBgOQgBgGgCgEQgCgDgEgCIgIgBIgHABg");
	this.shape_7.setTransform(1325.3,44.7);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#D5001C").s().p("AAQApIAAgxQAAgLgEgFQgEgDgIgBQgHABgDADQgFAFAAALIAAAxIgNAAIAAhPIAMAAIAAAKQAGgLANAAQANgBAHAIQAFAIAAANIAAA0g");
	this.shape_8.setTransform(1317.5,43);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#D5001C").s().p("AgFA5IAAhPIALAAIAABPgAgFgoIAAgQIALAAIAAAQg");
	this.shape_9.setTransform(1311.7,41.4);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#D5001C").s().p("AgOA3QgGgDgDgFQgEgFgCgIQgBgIAAgLQAAgTAHgKQAIgKAPAAQANAAAFAKIAAgqIANAAIAABwIgMAAIAAgMQgGANgOAAQgIAAgFgCgAgHgLQgEABgCAEQgCADgBAEIgBAOIABAPQABAGACAEQACADAEACQADABAEAAQAFAAADgBQAEgCACgDQACgEABgGIABgPIgBgOQgBgEgCgDQgCgEgEgBIgIgBIgHABg");
	this.shape_10.setTransform(1305.7,41.4);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#D5001C").s().p("AgVAjQgGgFAAgKQAAgHACgEQADgEAEgDQAEgCAFgBIAMgEIAMgCIAAgFQAAgIgDgFQgDgEgJAAQgGAAgEADQgDAEAAAJIgMAAQABgNAGgHQAGgHAOAAQAHAAAFACQAFACADADQADAEABAFQACAFAAAGIAAA1IgNAAIAAgKQgCAEgFAEQgFADgGAAQgMAAgGgGgAAEADIgIACIgGAEQgCABgBADIgBAFQAAANAOAAQAGAAAEgFQAFgFAAgIIAAgLg");
	this.shape_11.setTransform(1298,43);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#D5001C").s().p("AgLA5IAAhEIgKAAIAAgLIAKAAIAAgIQAAgMAGgHQAFgGAMgBIAKAAIAAAMIgJAAQgHAAgDAEQgDACAAAIIAAAIIAUAAIAAALIgUAAIAABEg");
	this.shape_12.setTransform(1292.2,41.4);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#D5001C").s().p("AgnAFIAAgJIBPAAIAAAJg");
	this.shape_13.setTransform(1285,47.8);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#D5001C").s().p("AgFA5IAAhPIALAAIAABPgAgFgoIAAgQIALAAIAAAQg");
	this.shape_14.setTransform(1278.6,41.4);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#D5001C").s().p("AAQApIAAgxQAAgLgEgFQgEgDgIgBQgGABgEADQgFAFAAALIAAAxIgMAAIAAhPIAMAAIAAAKQAEgLAOAAQANgBAGAIQAHAIgBANIAAA0g");
	this.shape_15.setTransform(1273,43);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#D5001C").s().p("AAdA5IgJgcIgpAAIgIAcIgMAAIAjhxIANAAIAjBxgAgRASIAiAAIgRg6g");
	this.shape_16.setTransform(1264.5,41.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).to({state:[]},50).wait(100));

	// Ebene 6
	this.instance = new lib.ani_fadeIn();
	this.instance.setTransform(609,351.5,1,1,0,0,0,609,351.5);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(40).to({_off:false},0).to({_off:true},10).wait(100));

	// Ebene 5
	this.instance_1 = new lib.ani_fadeIn();
	this.instance_1.setTransform(609,351.5,1,1,0,0,0,609,351.5);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(30).to({_off:false},0).to({_off:true},10).wait(110));

	// Ebene 4
	this.instance_2 = new lib.ani_fadeIn();
	this.instance_2.setTransform(609,351.5,1,1,0,0,0,609,351.5);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(20).to({_off:false},0).to({_off:true},10).wait(120));

	// Ebene 3
	this.instance_3 = new lib.ani_fadeIn();
	this.instance_3.setTransform(609,351.5,1,1,0,0,0,609,351.5);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(10).to({_off:false},0).to({_off:true},10).wait(130));

	// Ebene 1
	this.instance_4 = new lib.ani_fadeIn();
	this.instance_4.setTransform(609,351.5,1,1,0,0,0,609,351.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).to({_off:true},10).wait(140));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,1425,703);


(lib.timelineJumpWidget = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{step1:0,step2:10,step3:20,step4:30,step5:40});

	// fadeIn
	this.instance = new lib.ani_inLine("synched",0);
	this.instance.setTransform(609,351.5,1,1,0,0,0,609,351.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(50));

	// popup_09
	this.instance_1 = new lib.container_text("single",10);
	this.instance_1.setTransform(625,415.1,1,1,0,0,0,575,295.1);

	this.instance_2 = new lib.container_text("single",9);
	this.instance_2.setTransform(625,345.1,1,1,0,0,0,575,295.1);

	this.instance_3 = new lib.container_pics("single",0);
	this.instance_3.setTransform(516.3,351.5,1,1,0,0,0,516.3,351.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_3},{t:this.instance_2},{t:this.instance_1}]}).to({state:[]},9).wait(41));

	// popup_10
	this.MCExercise = new lib.exercise01();
	this.MCExercise.setTransform(780,420.2,1,1,0,0,0,780,420.2);

	this.MCExercise_1 = new lib.exercise02();
	this.MCExercise_1.setTransform(780,420.2,1,1,0,0,0,780,420.2);

	this.MCExercise_2 = new lib.exercise03();
	this.MCExercise_2.setTransform(780,420.2,1,1,0,0,0,780,420.2);

	this.MCExercise_3 = new lib.exercise04();
	this.MCExercise_3.setTransform(780,420.2,1,1,0,0,0,780,420.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.MCExercise}]},10).to({state:[]},9).to({state:[{t:this.MCExercise_1}]},1).to({state:[]},9).to({state:[{t:this.MCExercise_2}]},1).to({state:[]},9).to({state:[{t:this.MCExercise_3}]},1).wait(10));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-1,1426,705);


// stage content:
(lib.c7p1 = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{I:6});

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_2 = new cjs.Graphics().p("EhfJA26MAAAht0MC+SAAAMAAABt0g");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(2).to({graphics:mask_graphics_2,x:609,y:351.5}).wait(8));

	// timelineJumpWidget
	this.timelineJumpWidget = new lib.timelineJumpWidget();
	this.timelineJumpWidget._off = true;

	this.timelineJumpWidget.mask = mask;

	this.timeline.addTween(cjs.Tween.get(this.timelineJumpWidget).wait(2).to({_off:false},0).wait(8));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;

})(lib = lib||{}, images = images||{}, createjs = createjs||{}, ss = ss||{});
var lib, images, createjs, ss;