(function (lib, img, cjs, ss) {

var p; // shortcut to reference prototypes
lib.webFontTxtFilters = {}; 

// library properties:
lib.properties = {
	width: 1218,
	height: 703,
	fps: 25,
	color: "#FFFFFF",
	opacity: 1.00,
	webfonts: {},
	manifest: [
		{src:"assets/content/images/c4p1_pic01.jpg", id:"c4p1_pic01"},
		{src:"assets/content/images/c4p1_pic02.jpg", id:"c4p1_pic02"},
		{src:"assets/content/images/c4p1_pic03.jpg", id:"c4p1_pic03"},
		{src:"assets/content/images/c4p1_pic07.jpg", id:"c4p1_pic07"},
		{src:"assets/content/images/c4p1_pic16.png", id:"c4p1_pic16"},
		{src:"assets/content/images/c4p1_pic18.png", id:"c4p1_pic18"},
		{src:"assets/content/images/visual_ppe.png", id:"visual_ppe"}
	]
};



lib.ssMetadata = [];


lib.webfontAvailable = function(family) { 
	lib.properties.webfonts[family] = true;
	var txtFilters = lib.webFontTxtFilters && lib.webFontTxtFilters[family] || [];
	for(var f = 0; f < txtFilters.length; ++f) {
		txtFilters[f].updateCache();
	}
};
// symbols:



(lib.c4p1_pic01 = function() {
	this.initialize(img.c4p1_pic01);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1218,703);


(lib.c4p1_pic02 = function() {
	this.initialize(img.c4p1_pic02);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1218,703);


(lib.c4p1_pic03 = function() {
	this.initialize(img.c4p1_pic03);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1218,703);


(lib.c4p1_pic07 = function() {
	this.initialize(img.c4p1_pic07);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1150,600);


(lib.c4p1_pic16 = function() {
	this.initialize(img.c4p1_pic16);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,279,238);


(lib.c4p1_pic18 = function() {
	this.initialize(img.c4p1_pic18);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,158,70);


(lib.visual_ppe = function() {
	this.initialize(img.visual_ppe);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,112,112);


(lib.scroller_handle = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D5001C").s().p("AgsCVIAAkqIBZAAIAAEqg");
	this.shape.setTransform(4.5,15);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,9,30);


(lib.scroller_back_500 = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CCCCCC").s().p("EgAYAnEMAAAhOHIAxAAMAAABOHg");
	this.shape.setTransform(2.5,250);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,5,500);


(lib.PreviousBtn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// text
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D5001C").s().p("ABOEsIj8knIEDkwIBaAAIkCEwID7Eng");
	this.shape.setTransform(27.6,62.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AnzJxIAAzhIPmAAIAAThg");
	this.shape_1.setTransform(50,62.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},3).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(10,32.5,35.1,60);


(lib.pics_arrowHead = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D5001C").s().p("AiFhwIELBwIkLBxg");
	this.shape.setTransform(13.5,0);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,-11.3,27,22.6);


(lib.pic_shadow_occlusionRound = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#000000","rgba(0,0,0,0)"],[0,1],0,0,0,0,0,102.5).s().p("AsTMUQlGlHgBnNQABnMFGlHQFHlGHMgBQHNABFHFGQFGFHABHMQgBHNlGFHQlHFGnNABQnMgBlHlGg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-111.5,-111.5,223,223);


(lib.pic_plane_white = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EhadApaMAAAhSzMC07AAAMAAABSzg");
	this.shape.setTransform(579,265);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,1158,530);


(lib.pic_particle = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgUAVQgJgJABgMQgBgLAJgJQAJgJALABQAMgBAJAJQAJAJgBALQABAMgJAJQgJAJgMgBQgLABgJgJg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-3,-3,6,6);


(lib.container_text = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// Ebene 16
	this.text_140 = new cjs.Text("Klicken Sie oben rechts auf \"Themenübersicht\", um ein anderes Thema zu auszuwählen.", "16px 'Porsche Next TT'");
	this.text_140.name = "text_140";
	this.text_140.lineHeight = 23;
	this.text_140.lineWidth = 306;
	this.text_140.setTransform(2,2);
	this.text_140._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_140).wait(139).to({_off:false},0).to({_off:true},1).wait(1));

	// Ebene 58
	this.text_95 = new cjs.Text("<b>Beladung ab ca. 100%</b>\nIgnoriert der Fahrer die Warnung und setzt sich der Partikelfilter weiter zu, erscheint Kombiinstrument die Meldung <b>„Partikelfilter. Fahrzeug verkehrssicher abstellen“. </b>\n\nEine Regeneration in der Fachwerkstatt ist nicht mehr möglich. \n<b>Der Partikelfilter muss getauscht werden. </b>", "16px 'Porsche Next TT'");
	this.text_95.name = "text_95";
	this.text_95.lineHeight = 23;
	this.text_95.lineWidth = 426;
	this.text_95.setTransform(2,2);
	this.text_95._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_95).wait(94).to({_off:false},0).to({_off:true},1).wait(46));

	// Ebene 57
	this.text_94 = new cjs.Text("<b>Beladung ab ca. 85 %</b>\nKommt der Fahrer der Aufforderung durch das Kombiinstrument nicht nach und setzt sich der Partikelfilter weiter zu, erscheint im Kombiinstrument die Meldung <b>„Partikelfilter, Weiterfahrt möglich, Werkstatt aufsuchen“. </b>\n\nDurch eine <b>Zwangsregeneration</b> mit dem Porsche Tester kann der Partikelfilter in der Fachwerkstatt wieder regeneriert werden. ", "16px 'Porsche Next TT'");
	this.text_94.name = "text_94";
	this.text_94.lineHeight = 23;
	this.text_94.lineWidth = 426;
	this.text_94.setTransform(2,2);
	this.text_94._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_94).wait(93).to({_off:false},0).to({_off:true},1).wait(47));

	// Ebene 56
	this.text_93 = new cjs.Text("<b>Beladung ab ca. 70 %</b>\nDer Fahrer wird durch die Meldung <b>„Partikelfilter prüfen, siehe Betriebsanleitung“</b> im Kombiinstrument aufgefordert, einen entsprechenden Fahrzyklus (laut Betriebsanleitung) durchzuführen. \n\nDieser Fahrzyklus dient dem schnellen Erreichen der genannten Bedingungen für eine <b>(aktive Regeneration).</b>", "16px 'Porsche Next TT'");
	this.text_93.name = "text_93";
	this.text_93.lineHeight = 23;
	this.text_93.lineWidth = 426;
	this.text_93.setTransform(2,2);
	this.text_93._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_93).wait(92).to({_off:false},0).to({_off:true},1).wait(48));

	// Ebene 55
	this.text_92 = new cjs.Text("• Start-Stopp-Verbot \n• Leistungsreduzierung", "16px 'Porsche Next TT'");
	this.text_92.name = "text_92";
	this.text_92.lineHeight = 23;
	this.text_92.lineWidth = 206;
	this.text_92.setTransform(2,2);
	this.text_92._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_92).wait(91).to({_off:false},0).to({_off:true},1).wait(49));

	// Ebene 54
	this.text_91 = new cjs.Text("Ab ca. 60 %", "16px 'Porsche Next TT'");
	this.text_91.name = "text_91";
	this.text_91.lineHeight = 23;
	this.text_91.lineWidth = 206;
	this.text_91.setTransform(2,2);
	this.text_91._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_91).wait(90).to({_off:false},0).to({_off:true},1).wait(50));

	// Ebene 53
	this.text_90 = new cjs.Text("• Segelverbot \n• Anpassen der Schaltdrehzahl\n• Anheben der Leerlaufdrehzahl \n• Start-Stopp-Verbot ", "16px 'Porsche Next TT'");
	this.text_90.name = "text_90";
	this.text_90.lineHeight = 23;
	this.text_90.lineWidth = 206;
	this.text_90.setTransform(2,2);
	this.text_90._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_90).wait(89).to({_off:false},0).to({_off:true},1).wait(51));

	// Ebene 52
	this.text_89 = new cjs.Text("Ab ca. 25 %", "16px 'Porsche Next TT'");
	this.text_89.name = "text_89";
	this.text_89.lineHeight = 23;
	this.text_89.lineWidth = 206;
	this.text_89.setTransform(2,2);
	this.text_89._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_89).wait(88).to({_off:false},0).to({_off:true},1).wait(52));

	// Ebene 51
	this.text_88 = new cjs.Text("• Segelverbot \n• Anpassen der Schaltdrehzahl", "16px 'Porsche Next TT'");
	this.text_88.name = "text_88";
	this.text_88.lineHeight = 23;
	this.text_88.lineWidth = 206;
	this.text_88.setTransform(2,2);
	this.text_88._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_88).wait(87).to({_off:false},0).to({_off:true},1).wait(53));

	// Ebene 50
	this.text_87 = new cjs.Text("Ab ca. 15 %", "16px 'Porsche Next TT'");
	this.text_87.name = "text_87";
	this.text_87.lineHeight = 23;
	this.text_87.lineWidth = 206;
	this.text_87.setTransform(2,2);
	this.text_87._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_87).wait(86).to({_off:false},0).to({_off:true},1).wait(54));

	// Ebene 49
	this.text_86 = new cjs.Text("Maßnahmen", "bold 16px 'Porsche Next TT'");
	this.text_86.name = "text_86";
	this.text_86.lineHeight = 23;
	this.text_86.lineWidth = 206;
	this.text_86.setTransform(2,2);
	this.text_86._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_86).wait(85).to({_off:false},0).to({_off:true},1).wait(55));

	// Ebene 48
	this.text_85 = new cjs.Text("Partikelfilterbeladung", "bold 16px 'Porsche Next TT'");
	this.text_85.name = "text_85";
	this.text_85.lineHeight = 23;
	this.text_85.lineWidth = 206;
	this.text_85.setTransform(2,2);
	this.text_85._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_85).wait(84).to({_off:false},0).to({_off:true},1).wait(56));

	// Ebene 47
	this.text_84 = new cjs.Text("<b>Beladung 15 – 70 %</b>\nBei Bedarf kann das DME Steuergerät folgende, zusätzliche Maßnahmen einleiten, um das Erreichen der Regenerationsvoraussetzungen zu unterstützen: ", "16px 'Porsche Next TT'");
	this.text_84.name = "text_84";
	this.text_84.lineHeight = 23;
	this.text_84.lineWidth = 426;
	this.text_84.setTransform(2,2);
	this.text_84._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_84).wait(83).to({_off:false},0).to({_off:true},1).wait(57));

	// Ebene 46
	this.text_83 = new cjs.Text("<b>Beladung bis ca. 15 %</b>\nDer Partikelfilter kann allein durch das Fahrprofil des Kunden regeneriert werden <b>(passive Regeneration).</b> Es sind keine Maßnahmen erforderlich.\nVoraussetzungen für die Regeneration:\nMindestens ca. 600 °C Abgastemperatur im Ottopartikelfilter\nGenügend Sauerstoff im Abgas", "16px 'Porsche Next TT'");
	this.text_83.name = "text_83";
	this.text_83.lineHeight = 23;
	this.text_83.lineWidth = 426;
	this.text_83.setTransform(2,2);
	this.text_83._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_83).wait(82).to({_off:false},0).to({_off:true},1).wait(58));

	// Ebene 45
	this.text_82 = new cjs.Text("Das DME Steuergerät errechnet die Beladung des Partikelfilters anhand des Differenzdrucks und der Temperatur der Abgase sowie weiterer Parameter (z. B. Rahmenbedingungen beim Kaltstart, Kühlmitteltemperatur, Lambda-Wert).", "16px 'Porsche Next TT'");
	this.text_82.name = "text_82";
	this.text_82.lineHeight = 23;
	this.text_82.lineWidth = 426;
	this.text_82.setTransform(2,2);
	this.text_82._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_82).wait(81).to({_off:false},0).to({_off:true},1).wait(59));

	// Ebene 44
	this.text_81 = new cjs.Text("Abgasgegendruck", "16px 'Porsche Next TT'");
	this.text_81.name = "text_81";
	this.text_81.lineHeight = 23;
	this.text_81.lineWidth = 396;
	this.text_81.setTransform(2,2);
	this.text_81._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_81).wait(80).to({_off:false},0).to({_off:true},1).wait(60));

	// Ebene 43
	this.text_80 = new cjs.Text("Ottopartikelfilter – Regenerationsstufen ", "32px 'Porsche Next TT Thin'");
	this.text_80.name = "text_80";
	this.text_80.lineHeight = 47;
	this.text_80.lineWidth = 996;
	this.text_80.setTransform(2,2);
	this.text_80._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_80).wait(79).to({_off:false},0).to({_off:true},1).wait(61));

	// Ebene 41
	this.text_74 = new cjs.Text("In diesen Ländern müssen Fahrzeuge künftig mit einem Ottopartikelfilter ausgestattet sein. ", "16px 'Porsche Next TT'");
	this.text_74.name = "text_74";
	this.text_74.lineHeight = 23;
	this.text_74.lineWidth = 1096;
	this.text_74.setTransform(2,2);
	this.text_74._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_74).wait(73).to({_off:false},0).to({_off:true},1).wait(67));

	// Ebene 40
	this.text_73 = new cjs.Text("Österreich\nPolen\nPortugal\nRéunion\nRumänien\nSchweden\nSchweiz\nSerbienSlowakei\nSlowenien\nSpanien\nTschechien\nTürkei\nUngarn\nZypern", "16px 'Porsche Next TT'");
	this.text_73.name = "text_73";
	this.text_73.lineHeight = 23;
	this.text_73.lineWidth = 191;
	this.text_73.setTransform(2,2);
	this.text_73._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_73).wait(72).to({_off:false},0).to({_off:true},1).wait(68));

	// Ebene 39
	this.text_72 = new cjs.Text("Israel\nItalien\nKroatien\nLettland\nLiechtenstein\nLitauen\nLuxemburg\nMalta\nMartinique (frz. Antillen)\nMazedonien\nMonaco\nMontenegro\nNeukaledonien\nNiederlande\nNorwegen", "16px 'Porsche Next TT'");
	this.text_72.name = "text_72";
	this.text_72.lineHeight = 23;
	this.text_72.lineWidth = 191;
	this.text_72.setTransform(2,2);
	this.text_72._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_72).wait(71).to({_off:false},0).to({_off:true},1).wait(69));

	// Ebene 38
	this.text_71 = new cjs.Text("Andorra\nBelgien\nBosnien-Herzegowina\nBulgarien\nDänemark\nDeutschland\nEstland\nFinnland\nFrankreich\nFranzösisch-Polynesien\nGriechenland\nGroßbritannien\nGuadeloupe\nIrland\nIsland", "16px 'Porsche Next TT'");
	this.text_71.name = "text_71";
	this.text_71.lineHeight = 23;
	this.text_71.lineWidth = 191;
	this.text_71.setTransform(2,2);
	this.text_71._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_71).wait(70).to({_off:false},0).to({_off:true},1).wait(70));

	// Ebene 37
	this.text_70 = new cjs.Text("Länderliste", "32px 'Porsche Next TT Thin'");
	this.text_70.name = "text_70";
	this.text_70.lineHeight = 47;
	this.text_70.lineWidth = 996;
	this.text_70.setTransform(2,2);
	this.text_70._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_70).wait(69).to({_off:false},0).to({_off:true},1).wait(71));

	// Ebene 36
	this.text_61 = new cjs.Text("Im Vergleich zum bisherigen NEFZ beinhaltet der WLTP-Fahrzyklus dynamischere und längere Zyklusphase mit höheren Geschwindigkeiten. Durch im WLTP nunmehr vier statt bisher zwei und deutlich dynamischeren Zyklusphasen werden alltägliche Fahrsituationen besser simuliert und damit realitätsnähere Verbrauchswerte ermittelt.\n\nGrundlagen zum neuen WLTP-Prüfverfahren erhalten Sie im Online-Training „WLTP – Hintergrundinformationen zum neuen Testverfahren“ und über PPE.", "16px 'Porsche Next TT'");
	this.text_61.name = "text_61";
	this.text_61.lineHeight = 23;
	this.text_61.lineWidth = 908;
	this.text_61.setTransform(2,2);
	this.text_61._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_61).wait(60).to({_off:false},0).to({_off:true},1).wait(80));

	// Ebene 35
	this.text_60 = new cjs.Text("WLTP Fahrzyklus", "32px 'Porsche Next TT Thin'");
	this.text_60.name = "text_60";
	this.text_60.lineHeight = 47;
	this.text_60.lineWidth = 996;
	this.text_60.setTransform(2,2);
	this.text_60._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_60).wait(59).to({_off:false},0).to({_off:true},1).wait(81));

	// Ebene 24
	this.text_55 = new cjs.Text("Zyklusdauer (Sekunden)", "16px 'Porsche Next TT'");
	this.text_55.name = "text_55";
	this.text_55.textAlign = "center";
	this.text_55.lineHeight = 23;
	this.text_55.lineWidth = 421;
	this.text_55.setTransform(212.5,2);
	this.text_55._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_55).wait(54).to({_off:false},0).to({_off:true},1).wait(86));

	// Ebene 22
	this.text_54 = new cjs.Text("Geschwindigkeit \n(km/h)", "16px 'Porsche Next TT'");
	this.text_54.name = "text_54";
	this.text_54.textAlign = "center";
	this.text_54.lineHeight = 23;
	this.text_54.lineWidth = 296;
	this.text_54.setTransform(150,2);
	this.text_54._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_54).wait(53).to({_off:false},0).to({_off:true},1).wait(87));

	// Ebene 21
	this.text_53 = new cjs.Text("WLTP", "16px 'Porsche Next TT'");
	this.text_53.name = "text_53";
	this.text_53.lineHeight = 23;
	this.text_53.lineWidth = 140;
	this.text_53.setTransform(2,2);
	this.text_53._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_53).wait(52).to({_off:false},0).to({_off:true},1).wait(88));

	// Ebene 8
	this.text_52 = new cjs.Text("NEFZ", "16px 'Porsche Next TT'");
	this.text_52.name = "text_52";
	this.text_52.lineHeight = 23;
	this.text_52.lineWidth = 140;
	this.text_52.setTransform(2,2);
	this.text_52._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_52).wait(51).to({_off:false},0).to({_off:true},1).wait(89));

	// Ebene 9
	this.text_51 = new cjs.Text("Extra-High", "16px 'Porsche Next TT'", "#FFFFFF");
	this.text_51.name = "text_51";
	this.text_51.textAlign = "center";
	this.text_51.lineHeight = 23;
	this.text_51.lineWidth = 140;
	this.text_51.setTransform(72,2);
	this.text_51._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_51).wait(50).to({_off:false},0).to({_off:true},1).wait(90));

	// Ebene 10
	this.text_50 = new cjs.Text("High", "16px 'Porsche Next TT'", "#FFFFFF");
	this.text_50.name = "text_50";
	this.text_50.textAlign = "center";
	this.text_50.lineHeight = 23;
	this.text_50.lineWidth = 140;
	this.text_50.setTransform(72,2);
	this.text_50._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_50).wait(49).to({_off:false},0).to({_off:true},1).wait(91));

	// Ebene 11
	this.text_49 = new cjs.Text("Medium", "16px 'Porsche Next TT'");
	this.text_49.name = "text_49";
	this.text_49.textAlign = "center";
	this.text_49.lineHeight = 23;
	this.text_49.lineWidth = 140;
	this.text_49.setTransform(72,2);
	this.text_49._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_49).wait(48).to({_off:false},0).to({_off:true},1).wait(92));

	// Ebene 14
	this.text_48 = new cjs.Text("Low", "16px 'Porsche Next TT'");
	this.text_48.name = "text_48";
	this.text_48.textAlign = "center";
	this.text_48.lineHeight = 23;
	this.text_48.lineWidth = 140;
	this.text_48.setTransform(72,2);
	this.text_48._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_48).wait(47).to({_off:false},0).to({_off:true},1).wait(93));

	// Ebene 15
	this.text_47 = new cjs.Text("Überland", "16px 'Porsche Next TT'", "#FFFFFF");
	this.text_47.name = "text_47";
	this.text_47.textAlign = "center";
	this.text_47.lineHeight = 23;
	this.text_47.lineWidth = 139;
	this.text_47.setTransform(71.5,2);
	this.text_47._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_47).wait(46).to({_off:false},0).to({_off:true},1).wait(94));

	// Ebene 179
	this.text_46 = new cjs.Text("Stadt", "16px 'Porsche Next TT'");
	this.text_46.name = "text_46";
	this.text_46.textAlign = "center";
	this.text_46.lineHeight = 23;
	this.text_46.lineWidth = 276;
	this.text_46.setTransform(140,2);
	this.text_46._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_46).wait(45).to({_off:false},0).to({_off:true},1).wait(95));

	// Ebene 178
	this.text_45 = new cjs.Text("Ottopartikelfilter – Regenerationsstufen", "16px 'Porsche Next TT'");
	this.text_45.name = "text_45";
	this.text_45.lineHeight = 23;
	this.text_45.lineWidth = 296;
	this.text_45.setTransform(2,2);
	this.text_45._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_45).wait(44).to({_off:false},0).to({_off:true},1).wait(96));

	// Ebene 74
	this.text_44 = new cjs.Text("Länderliste", "16px 'Porsche Next TT'");
	this.text_44.name = "text_44";
	this.text_44.lineHeight = 23;
	this.text_44.lineWidth = 296;
	this.text_44.setTransform(2,2);
	this.text_44._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_44).wait(43).to({_off:false},0).to({_off:true},1).wait(97));

	// Ebene 73
	this.text_43 = new cjs.Text("WLTP Fahrzyklus", "16px 'Porsche Next TT'");
	this.text_43.name = "text_43";
	this.text_43.lineHeight = 23;
	this.text_43.lineWidth = 296;
	this.text_43.setTransform(2,2);
	this.text_43._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_43).wait(42).to({_off:false},0).to({_off:true},1).wait(98));

	// Ebene 72
	this.text_42 = new cjs.Text("<b>Bitte beachten Sie:</b>\nBei Fahrzeugen mit Ottopartikelfilter darf nur freigegebenes, aschearmes Motoröl nach Porsche Spezifikation verwendet werden.", "16px 'Porsche Next TT'");
	this.text_42.name = "text_42";
	this.text_42.lineHeight = 23;
	this.text_42.lineWidth = 336;
	this.text_42.setTransform(2,2);
	this.text_42._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_42).wait(41).to({_off:false},0).to({_off:true},1).wait(99));

	// Ebene 71
	this.text_41 = new cjs.Text("Der neue Macan (MJ 19) ist der erste Porsche, der nach dem WLTP-Prüfverfahren typisiert wird. \nMit dem Macan (MJ 19) führt Porsche erstmals serienmäßig eine Abgasreinigungsanlage mit Ottopartikelfilter in verschiedenen Märkten ein. So können die RDE (Real Driving Emissions)-Anforderungen der Abgasstufe Euro 6d-TEMP für die EU28-Länder erfüllt werden.\nDer Ottopartikelfilter funktioniert ähnlich wie ein Dieselpartikelfilter. An der Oberfläche lagern sich die Rußpartikel ab und werden zur Regeneration des Ottopartikelfilters bei ca. 600 °C verbrannt.\n\n<b>Voraussetzungen für die Regeneration:</b>\n• Mindestens ca. 600 °C Abgastemperatur im Ottopartikelfilter\n• Genügend Sauerstoff im Abgas\n• Beladungszustand < 85 %\n\nDas Abgassystem mit Ottopartikelfilter ist auf die Lebensdauer des Fahrzeugs ausgelegt. Bei „normalem“ Fahrverhalten muss der Fahrer während der Fahrt also nicht auf das Partikelfiltersystem achten oder aktiv eingreifen. ", "16px 'Porsche Next TT'");
	this.text_41.name = "text_41";
	this.text_41.lineHeight = 23;
	this.text_41.lineWidth = 336;
	this.text_41.setTransform(2,2);
	this.text_41._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_41).wait(40).to({_off:false},0).to({_off:true},1).wait(100));

	// Ebene 70
	this.text_40 = new cjs.Text("Performance", "32px 'Porsche Next TT Thin'");
	this.text_40.name = "text_40";
	this.text_40.lineHeight = 47;
	this.text_40.lineWidth = 356;
	this.text_40.setTransform(2,2);
	this.text_40._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_40).wait(39).to({_off:false},0).to({_off:true},1).wait(101));

	// Ebene 25
	this.text_31 = new cjs.Text("Im Porsche Macan S (MJ 19) kommt der bereits vom Panamera und Cayenne bekannte 3,0-Liter V6-Monoturbo-Ottomotor zum Einsatz. \nDas Aggregat überzeugt durch hervorragende Performance bei geringem Kraftstoffverbrauch. \n\n<b>Merkmale</b>\n• Doppelte obenliegende Nockenwellen mit 4 Ventilen pro Zylinder \n• Zylinderköpfe mit integriertem Abgaskrümmer, der die Abgase in den Auspuff weiterleitet\n• Twin-Scroll-Turbolader (parallele Verwendung von zwei Ladern)  im Innen-V (Heiße-Seite-Innen) \n• Steuertrieb mit Ausgleichswelle \n• Brennverfahren (Miller Brennverfahren) mit zentraler Injektorlage \n• Benzindirekteinspritzung\n\nGrundlegendes zur Motortechnik erfahren Sie in PPE.", "16px 'Porsche Next TT'");
	this.text_31.name = "text_31";
	this.text_31.lineHeight = 23;
	this.text_31.lineWidth = 336;
	this.text_31.setTransform(2,2);
	this.text_31._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_31).wait(30).to({_off:false},0).to({_off:true},1).wait(110));

	// Ebene 82
	this.text_30 = new cjs.Text("Performance", "32px 'Porsche Next TT Thin'");
	this.text_30.name = "text_30";
	this.text_30.lineHeight = 47;
	this.text_30.lineWidth = 356;
	this.text_30.setTransform(2,2);
	this.text_30._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_30).wait(29).to({_off:false},0).to({_off:true},1).wait(111));

	// Ebene 65
	this.text_23 = new cjs.Text("480 Nm", "16px 'Porsche Next TT'");
	this.text_23.name = "text_23";
	this.text_23.lineHeight = 23;
	this.text_23.lineWidth = 296;
	this.text_23.setTransform(2,2);
	this.text_23._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_23).wait(22).to({_off:false},0).to({_off:true},1).wait(118));

	// Ebene 64
	this.text_22 = new cjs.Text("260 kW / 354 PS", "16px 'Porsche Next TT'");
	this.text_22.name = "text_22";
	this.text_22.lineHeight = 23;
	this.text_22.lineWidth = 296;
	this.text_22.setTransform(2,2);
	this.text_22._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_22).wait(21).to({_off:false},0).to({_off:true},1).wait(119));

	// Ebene 20
	this.text_21 = new cjs.Text("2995 cm³", "16px 'Porsche Next TT'");
	this.text_21.name = "text_21";
	this.text_21.lineHeight = 23;
	this.text_21.lineWidth = 296;
	this.text_21.setTransform(2,2);
	this.text_21._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_21).wait(20).to({_off:false},0).to({_off:true},1).wait(120));

	// Ebene 19
	this.text_20 = new cjs.Text("6-Zylinder V-Motor 90° ", "16px 'Porsche Next TT'");
	this.text_20.name = "text_20";
	this.text_20.lineHeight = 23;
	this.text_20.lineWidth = 296;
	this.text_20.setTransform(2,2);
	this.text_20._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_20).wait(19).to({_off:false},0).to({_off:true},1).wait(121));

	// Ebene 28
	this.text_12 = new cjs.Text("370 Nm", "16px 'Porsche Next TT'");
	this.text_12.name = "text_12";
	this.text_12.lineHeight = 23;
	this.text_12.lineWidth = 296;
	this.text_12.setTransform(2,2);
	this.text_12._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_12).wait(11).to({_off:false},0).to({_off:true},1).wait(129));

	// Ebene 27
	this.text_11 = new cjs.Text("180 kW / 245 PS\n(185 kW) / (252 PS) ", "16px 'Porsche Next TT'");
	this.text_11.name = "text_11";
	this.text_11.lineHeight = 23;
	this.text_11.lineWidth = 296;
	this.text_11.setTransform(2,2);
	this.text_11._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_11).wait(10).to({_off:false},0).to({_off:true},1).wait(130));

	// Ebene 23
	this.text_10 = new cjs.Text("1984 cm³", "16px 'Porsche Next TT'");
	this.text_10.name = "text_10";
	this.text_10.lineHeight = 23;
	this.text_10.lineWidth = 296;
	this.text_10.setTransform(2,2);
	this.text_10._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_10).wait(9).to({_off:false},0).to({_off:true},1).wait(131));

	// Ebene 13
	this.text_09 = new cjs.Text("4-Zylinder Reihe ", "16px 'Porsche Next TT'");
	this.text_09.name = "text_09";
	this.text_09.lineHeight = 23;
	this.text_09.lineWidth = 296;
	this.text_09.setTransform(2,2);
	this.text_09._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_09).wait(8).to({_off:false},0).to({_off:true},1).wait(132));

	// Ebene 12
	this.text_08 = new cjs.Text("Maximales Motordrehmoment", "16px 'Porsche Next TT'");
	this.text_08.name = "text_08";
	this.text_08.lineHeight = 23;
	this.text_08.lineWidth = 296;
	this.text_08.setTransform(2,2);
	this.text_08._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_08).wait(7).to({_off:false},0).to({_off:true},1).wait(133));

	// Ebene 7
	this.text_07 = new cjs.Text("Maximale Leistung\n(länderabhängig) ", "16px 'Porsche Next TT'");
	this.text_07.name = "text_07";
	this.text_07.lineHeight = 23;
	this.text_07.lineWidth = 296;
	this.text_07.setTransform(2,2);
	this.text_07._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_07).wait(6).to({_off:false},0).to({_off:true},1).wait(134));

	// Ebene 6
	this.text_06 = new cjs.Text("Maximale Leistung", "16px 'Porsche Next TT'");
	this.text_06.name = "text_06";
	this.text_06.lineHeight = 23;
	this.text_06.lineWidth = 296;
	this.text_06.setTransform(2,2);
	this.text_06._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_06).wait(5).to({_off:false},0).to({_off:true},1).wait(135));

	// Ebene 5
	this.text_05 = new cjs.Text("Hubraum", "16px 'Porsche Next TT'");
	this.text_05.name = "text_05";
	this.text_05.lineHeight = 23;
	this.text_05.lineWidth = 296;
	this.text_05.setTransform(2,2);
	this.text_05._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_05).wait(4).to({_off:false},0).to({_off:true},1).wait(136));

	// Ebene 4
	this.text_04 = new cjs.Text("Bauart", "16px 'Porsche Next TT'");
	this.text_04.name = "text_04";
	this.text_04.lineHeight = 23;
	this.text_04.lineWidth = 296;
	this.text_04.setTransform(2,2);
	this.text_04._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_04).wait(3).to({_off:false},0).to({_off:true},1).wait(137));

	// Ebene 3
	this.text_03 = new cjs.Text("<b>Leistungsdaten</b>", "16px 'Porsche Next TT'");
	this.text_03.name = "text_03";
	this.text_03.lineHeight = 23;
	this.text_03.lineWidth = 296;
	this.text_03.setTransform(2,2);
	this.text_03._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_03).wait(2).to({_off:false},0).to({_off:true},1).wait(138));

	// Ebene 2
	this.text_02 = new cjs.Text("Im Porsche Macan (MJ 19) wird als Basismotorisierung der 2,0-Liter Reihenvierzylinder-Motor eingesetzt.\nDas Aggregat wird mit einem Abgasturbolader aufgeladen und überzeugt durch eine sportliche Charakteristik bei günstigen Verbrauchswerten. \n\n<b>Merkmale</b>\n• Doppelte obenliegende Nockenwellen mit 4 Ventilen pro Zylinder \n• Zylinderkopf mit integriertem Abgaskrümmer, der die Abgase in den Auspuff weiterleitet \n• Steuertrieb mit zwei Ausgleichswellen \n• Benzin-Direkteinpritzung mit Drücken von ca. 60–200 bar\n\nGrundlegendes zur Motortechnik erfahren Sie in PPE.", "16px 'Porsche Next TT'");
	this.text_02.name = "text_02";
	this.text_02.lineHeight = 23;
	this.text_02.lineWidth = 336;
	this.text_02.setTransform(2,2);
	this.text_02._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_02).wait(1).to({_off:false},0).to({_off:true},1).wait(139));

	// Ebene 1
	this.text_01 = new cjs.Text("Performance", "32px 'Porsche Next TT Thin'");
	this.text_01.name = "text_01";
	this.text_01.lineHeight = 47;
	this.text_01.lineWidth = 356;
	this.text_01.setTransform(2,2);

	this.timeline.addTween(cjs.Tween.get(this.text_01).to({_off:true},1).wait(140));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,360,50.9);


(lib.container_pics = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// Ebene 4
	this.instance = new lib.c4p1_pic01();

	this.instance_1 = new lib.c4p1_pic02();

	this.instance_2 = new lib.c4p1_pic03();

	this.instance_3 = new lib.c4p1_pic07();

	this.instance_4 = new lib.c4p1_pic16();

	this.instance_5 = new lib.c4p1_pic18();

	this.instance_6 = new lib.visual_ppe();

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[]},1).to({state:[{t:this.instance_3}]},3).to({state:[]},1).to({state:[{t:this.instance_4}]},8).to({state:[]},1).to({state:[{t:this.instance_5}]},1).to({state:[]},1).to({state:[{t:this.instance_6}]},18).to({state:[]},1).wait(149));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,1218,703);


(lib.btn_blind_rectangle = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("Aj5D6IAAnzIHzAAIAAHzg");
	this.shape.setTransform(25,25);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(3).to({_off:false},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.btn_blind = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#002F6C").s().p("Aj5D6IAAnzIHzAAIAAHzg");
	this.shape.setTransform(25,25);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(3).to({_off:false},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.btn_arrow_openSideBar = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{out:0,over:4,down:9});

	// Ebene 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ag/B9IBkh9Ihkh8IAbAAIBlB8IhlB9g");
	this.shape.setTransform(25,35);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(10));

	// Ebene 3
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#D5001C").s().p("Aj5FeIAAq7IHzAAIAAK7g");
	this.shape_1.setTransform(25,35);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(10));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,50,70);


(lib.ani_coating = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("rgba(255,246,0,0)").ss(2,0,0,3).p("A1+tpMApOAAAIAAjcMgpOAAAA1+jVMApOAAAIAAjcMgpOAAAA1+G9MApOAAAIAAjcMgpOAAAAV/r7MgpOAAAIAADcMApOAAAAV/hnMgpOAAAIAADaMApOAAAAV/IrMgpOAAAIAADRMApOAAAA1+N1MApOAAAIAADRMgpOAAA");
	this.shape.setTransform(140.8,109.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("rgba(255,246,0,0.051)").ss(2,0,0,3).p("A1+xFMApOAAAIAADcMgpOAAAA1+mxMApOAAAIAADcMgpOAAAA1+DhMApOAAAIAADcMgpOAAAAV/ofMgpOAAAIAAjcMApOAAAAV/BzMgpOAAAIAAjaMApOAAAAV/L8MgpOAAAIAAjRMApOAAAA1+RGMApOAAAIAAjRMgpOAAA");
	this.shape_1.setTransform(140.8,109.4);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("rgba(255,246,0,0.106)").ss(2,0,0,3).p("A1+xFMApOAAAIAADcMgpOAAAA1+mxMApOAAAIAADcMgpOAAAA1+DhMApOAAAIAADcMgpOAAAAV/ofMgpOAAAIAAjcMApOAAAAV/BzMgpOAAAIAAjaMApOAAAAV/L8MgpOAAAIAAjRMApOAAAA1+RGMApOAAAIAAjRMgpOAAA");
	this.shape_2.setTransform(140.8,109.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("rgba(255,246,0,0.157)").ss(2,0,0,3).p("A1+xFMApOAAAIAADcMgpOAAAA1+mxMApOAAAIAADcMgpOAAAA1+DhMApOAAAIAADcMgpOAAAAV/ofMgpOAAAIAAjcMApOAAAAV/BzMgpOAAAIAAjaMApOAAAAV/L8MgpOAAAIAAjRMApOAAAA1+RGMApOAAAIAAjRMgpOAAA");
	this.shape_3.setTransform(140.8,109.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("rgba(255,246,0,0.212)").ss(2,0,0,3).p("A1+xFMApOAAAIAADcMgpOAAAA1+mxMApOAAAIAADcMgpOAAAA1+DhMApOAAAIAADcMgpOAAAAV/ofMgpOAAAIAAjcMApOAAAAV/BzMgpOAAAIAAjaMApOAAAAV/L8MgpOAAAIAAjRMApOAAAA1+RGMApOAAAIAAjRMgpOAAA");
	this.shape_4.setTransform(140.8,109.4);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("rgba(255,246,0,0.263)").ss(2,0,0,3).p("A1+xFMApOAAAIAADcMgpOAAAA1+mxMApOAAAIAADcMgpOAAAA1+DhMApOAAAIAADcMgpOAAAAV/ofMgpOAAAIAAjcMApOAAAAV/BzMgpOAAAIAAjaMApOAAAAV/L8MgpOAAAIAAjRMApOAAAA1+RGMApOAAAIAAjRMgpOAAA");
	this.shape_5.setTransform(140.8,109.4);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("rgba(255,246,0,0.318)").ss(2,0,0,3).p("A1+xFMApOAAAIAADcMgpOAAAA1+mxMApOAAAIAADcMgpOAAAA1+DhMApOAAAIAADcMgpOAAAAV/ofMgpOAAAIAAjcMApOAAAAV/BzMgpOAAAIAAjaMApOAAAAV/L8MgpOAAAIAAjRMApOAAAA1+RGMApOAAAIAAjRMgpOAAA");
	this.shape_6.setTransform(140.8,109.4);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("rgba(255,246,0,0.369)").ss(2,0,0,3).p("A1+xFMApOAAAIAADcMgpOAAAA1+mxMApOAAAIAADcMgpOAAAA1+DhMApOAAAIAADcMgpOAAAAV/ofMgpOAAAIAAjcMApOAAAAV/BzMgpOAAAIAAjaMApOAAAAV/L8MgpOAAAIAAjRMApOAAAA1+RGMApOAAAIAAjRMgpOAAA");
	this.shape_7.setTransform(140.8,109.4);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("rgba(255,246,0,0.42)").ss(2,0,0,3).p("A1+xFMApOAAAIAADcMgpOAAAA1+mxMApOAAAIAADcMgpOAAAA1+DhMApOAAAIAADcMgpOAAAAV/ofMgpOAAAIAAjcMApOAAAAV/BzMgpOAAAIAAjaMApOAAAAV/L8MgpOAAAIAAjRMApOAAAA1+RGMApOAAAIAAjRMgpOAAA");
	this.shape_8.setTransform(140.8,109.4);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("rgba(255,246,0,0.475)").ss(2,0,0,3).p("A1+xFMApOAAAIAADcMgpOAAAA1+mxMApOAAAIAADcMgpOAAAA1+DhMApOAAAIAADcMgpOAAAAV/ofMgpOAAAIAAjcMApOAAAAV/BzMgpOAAAIAAjaMApOAAAAV/L8MgpOAAAIAAjRMApOAAAA1+RGMApOAAAIAAjRMgpOAAA");
	this.shape_9.setTransform(140.8,109.4);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("rgba(255,246,0,0.525)").ss(2,0,0,3).p("A1+xFMApOAAAIAADcMgpOAAAA1+mxMApOAAAIAADcMgpOAAAA1+DhMApOAAAIAADcMgpOAAAAV/ofMgpOAAAIAAjcMApOAAAAV/BzMgpOAAAIAAjaMApOAAAAV/L8MgpOAAAIAAjRMApOAAAA1+RGMApOAAAIAAjRMgpOAAA");
	this.shape_10.setTransform(140.8,109.4);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("rgba(255,246,0,0.58)").ss(2,0,0,3).p("A1+xFMApOAAAIAADcMgpOAAAA1+mxMApOAAAIAADcMgpOAAAA1+DhMApOAAAIAADcMgpOAAAAV/ofMgpOAAAIAAjcMApOAAAAV/BzMgpOAAAIAAjaMApOAAAAV/L8MgpOAAAIAAjRMApOAAAA1+RGMApOAAAIAAjRMgpOAAA");
	this.shape_11.setTransform(140.8,109.4);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("rgba(255,246,0,0.631)").ss(2,0,0,3).p("A1+xFMApOAAAIAADcMgpOAAAA1+mxMApOAAAIAADcMgpOAAAA1+DhMApOAAAIAADcMgpOAAAAV/ofMgpOAAAIAAjcMApOAAAAV/BzMgpOAAAIAAjaMApOAAAAV/L8MgpOAAAIAAjRMApOAAAA1+RGMApOAAAIAAjRMgpOAAA");
	this.shape_12.setTransform(140.8,109.4);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("rgba(255,246,0,0.682)").ss(2,0,0,3).p("A1+xFMApOAAAIAADcMgpOAAAA1+mxMApOAAAIAADcMgpOAAAA1+DhMApOAAAIAADcMgpOAAAAV/ofMgpOAAAIAAjcMApOAAAAV/BzMgpOAAAIAAjaMApOAAAAV/L8MgpOAAAIAAjRMApOAAAA1+RGMApOAAAIAAjRMgpOAAA");
	this.shape_13.setTransform(140.8,109.4);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("rgba(255,246,0,0.737)").ss(2,0,0,3).p("A1+xFMApOAAAIAADcMgpOAAAA1+mxMApOAAAIAADcMgpOAAAA1+DhMApOAAAIAADcMgpOAAAAV/ofMgpOAAAIAAjcMApOAAAAV/BzMgpOAAAIAAjaMApOAAAAV/L8MgpOAAAIAAjRMApOAAAA1+RGMApOAAAIAAjRMgpOAAA");
	this.shape_14.setTransform(140.8,109.4);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("rgba(255,246,0,0.788)").ss(2,0,0,3).p("A1+xFMApOAAAIAADcMgpOAAAA1+mxMApOAAAIAADcMgpOAAAA1+DhMApOAAAIAADcMgpOAAAAV/ofMgpOAAAIAAjcMApOAAAAV/BzMgpOAAAIAAjaMApOAAAAV/L8MgpOAAAIAAjRMApOAAAA1+RGMApOAAAIAAjRMgpOAAA");
	this.shape_15.setTransform(140.8,109.4);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("rgba(255,246,0,0.843)").ss(2,0,0,3).p("A1+xFMApOAAAIAADcMgpOAAAA1+mxMApOAAAIAADcMgpOAAAA1+DhMApOAAAIAADcMgpOAAAAV/ofMgpOAAAIAAjcMApOAAAAV/BzMgpOAAAIAAjaMApOAAAAV/L8MgpOAAAIAAjRMApOAAAA1+RGMApOAAAIAAjRMgpOAAA");
	this.shape_16.setTransform(140.8,109.4);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().s("rgba(255,246,0,0.894)").ss(2,0,0,3).p("A1+xFMApOAAAIAADcMgpOAAAA1+mxMApOAAAIAADcMgpOAAAA1+DhMApOAAAIAADcMgpOAAAAV/ofMgpOAAAIAAjcMApOAAAAV/BzMgpOAAAIAAjaMApOAAAAV/L8MgpOAAAIAAjRMApOAAAA1+RGMApOAAAIAAjRMgpOAAA");
	this.shape_17.setTransform(140.8,109.4);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("rgba(255,246,0,0.949)").ss(2,0,0,3).p("A1+xFMApOAAAIAADcMgpOAAAA1+mxMApOAAAIAADcMgpOAAAA1+DhMApOAAAIAADcMgpOAAAAV/ofMgpOAAAIAAjcMApOAAAAV/BzMgpOAAAIAAjaMApOAAAAV/L8MgpOAAAIAAjRMApOAAAA1+RGMApOAAAIAAjRMgpOAAA");
	this.shape_18.setTransform(140.8,109.4);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f().s("#FFF600").ss(2,0,0,3).p("A1+tpMApOAAAIAAjcMgpOAAAA1+jVMApOAAAIAAjcMgpOAAAA1+G9MApOAAAIAAjcMgpOAAAAV/r7MgpOAAAIAADcMApOAAAAV/hnMgpOAAAIAADaMApOAAAAV/IrMgpOAAAIAADRMApOAAAA1+N1MApOAAAIAADRMgpOAAA");
	this.shape_19.setTransform(140.8,109.4);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f().s("#FFF600").ss(2.1,0,0,3).p("A1+xFMApOAAAIAADcMgpOAAAA1+mxMApOAAAIAADcMgpOAAAA1+DhMApOAAAIAADcMgpOAAAAV/ofMgpOAAAIAAjcMApOAAAAV/BzMgpOAAAIAAjaMApOAAAAV/L8MgpOAAAIAAjRMApOAAAA1+RGMApOAAAIAAjRMgpOAAA");
	this.shape_20.setTransform(140.8,109.4);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f().s("#FFF600").ss(2.2,0,0,3).p("A1+xFMApOAAAIAADcMgpOAAAA1+mxMApOAAAIAADcMgpOAAAA1+DhMApOAAAIAADcMgpOAAAAV/ofMgpOAAAIAAjcMApOAAAAV/BzMgpOAAAIAAjaMApOAAAAV/L8MgpOAAAIAAjRMApOAAAA1+RGMApOAAAIAAjRMgpOAAA");
	this.shape_21.setTransform(140.8,109.4);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f().s("#FFF600").ss(2.3,0,0,3).p("A1+xFMApOAAAIAADcMgpOAAAA1+mxMApOAAAIAADcMgpOAAAA1+DhMApOAAAIAADcMgpOAAAAV/ofMgpOAAAIAAjcMApOAAAAV/BzMgpOAAAIAAjaMApOAAAAV/L8MgpOAAAIAAjRMApOAAAA1+RGMApOAAAIAAjRMgpOAAA");
	this.shape_22.setTransform(140.8,109.4);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f().s("#FFF600").ss(2.4,0,0,3).p("A1+xFMApOAAAIAADcMgpOAAAA1+mxMApOAAAIAADcMgpOAAAA1+DhMApOAAAIAADcMgpOAAAAV/ofMgpOAAAIAAjcMApOAAAAV/BzMgpOAAAIAAjaMApOAAAAV/L8MgpOAAAIAAjRMApOAAAA1+RGMApOAAAIAAjRMgpOAAA");
	this.shape_23.setTransform(140.8,109.4);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f().s("#FFF600").ss(2.5,0,0,3).p("A1+xFMApOAAAIAADcMgpOAAAA1+mxMApOAAAIAADcMgpOAAAA1+DhMApOAAAIAADcMgpOAAAAV/ofMgpOAAAIAAjcMApOAAAAV/BzMgpOAAAIAAjaMApOAAAAV/L8MgpOAAAIAAjRMApOAAAA1+RGMApOAAAIAAjRMgpOAAA");
	this.shape_24.setTransform(140.8,109.4);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f().s("#FFF600").ss(2.6,0,0,3).p("A1+xFMApOAAAIAADcMgpOAAAA1+mxMApOAAAIAADcMgpOAAAA1+DhMApOAAAIAADcMgpOAAAAV/ofMgpOAAAIAAjcMApOAAAAV/BzMgpOAAAIAAjaMApOAAAAV/L8MgpOAAAIAAjRMApOAAAA1+RGMApOAAAIAAjRMgpOAAA");
	this.shape_25.setTransform(140.8,109.4);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f().s("#FFF600").ss(2.7,0,0,3).p("A1+xFMApOAAAIAADcMgpOAAAA1+mxMApOAAAIAADcMgpOAAAA1+DhMApOAAAIAADcMgpOAAAAV/ofMgpOAAAIAAjcMApOAAAAV/BzMgpOAAAIAAjaMApOAAAAV/L8MgpOAAAIAAjRMApOAAAA1+RGMApOAAAIAAjRMgpOAAA");
	this.shape_26.setTransform(140.8,109.4);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f().s("#FFF600").ss(2.8,0,0,3).p("A1+xFMApOAAAIAADcMgpOAAAA1+mxMApOAAAIAADcMgpOAAAA1+DhMApOAAAIAADcMgpOAAAAV/ofMgpOAAAIAAjcMApOAAAAV/BzMgpOAAAIAAjaMApOAAAAV/L8MgpOAAAIAAjRMApOAAAA1+RGMApOAAAIAAjRMgpOAAA");
	this.shape_27.setTransform(140.8,109.4);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f().s("#FFF600").ss(2.9,0,0,3).p("A1+xFMApOAAAIAADcMgpOAAAA1+mxMApOAAAIAADcMgpOAAAA1+DhMApOAAAIAADcMgpOAAAAV/ofMgpOAAAIAAjcMApOAAAAV/BzMgpOAAAIAAjaMApOAAAAV/L8MgpOAAAIAAjRMApOAAAA1+RGMApOAAAIAAjRMgpOAAA");
	this.shape_28.setTransform(140.8,109.4);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f().s("#FFF600").ss(3,0,0,3).p("A1+xFMApOAAAIAADcMgpOAAAA1+mxMApOAAAIAADcMgpOAAAA1+DhMApOAAAIAADcMgpOAAAAV/ofMgpOAAAIAAjcMApOAAAAV/BzMgpOAAAIAAjaMApOAAAAV/L8MgpOAAAIAAjRMApOAAAA1+RGMApOAAAIAAjRMgpOAAA");
	this.shape_29.setTransform(140.8,109.4);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f().s("#FFF600").ss(3,0,0,3).p("A1+tpMApOAAAIAAjcMgpOAAAA1+jVMApOAAAIAAjcMgpOAAAA1+G9MApOAAAIAAjcMgpOAAAAV/r7MgpOAAAIAADcMApOAAAAV/hnMgpOAAAIAADaMApOAAAAV/IrMgpOAAAIAADRMApOAAAA1+N1MApOAAAIAADRMgpOAAA");
	this.shape_30.setTransform(140.8,109.4);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f().s("#FFF000").ss(3.1,0,0,3).p("A1+xFMApOAAAIAADcMgpOAAAA1+mxMApOAAAIAADcMgpOAAAA1+DhMApOAAAIAADcMgpOAAAAV/ofMgpOAAAIAAjcMApOAAAAV/BzMgpOAAAIAAjaMApOAAAAV/L8MgpOAAAIAAjRMApOAAAA1+RGMApOAAAIAAjRMgpOAAA");
	this.shape_31.setTransform(140.8,109.4);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f().s("#FFEB00").ss(3.1,0,0,3).p("A1+xFMApOAAAIAADcMgpOAAAA1+mxMApOAAAIAADcMgpOAAAA1+DhMApOAAAIAADcMgpOAAAAV/ofMgpOAAAIAAjcMApOAAAAV/BzMgpOAAAIAAjaMApOAAAAV/L8MgpOAAAIAAjRMApOAAAA1+RGMApOAAAIAAjRMgpOAAA");
	this.shape_32.setTransform(140.8,109.4);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f().s("#FFE500").ss(3.2,0,0,3).p("A1+xFMApOAAAIAADcMgpOAAAA1+mxMApOAAAIAADcMgpOAAAA1+DhMApOAAAIAADcMgpOAAAAV/ofMgpOAAAIAAjcMApOAAAAV/BzMgpOAAAIAAjaMApOAAAAV/L8MgpOAAAIAAjRMApOAAAA1+RGMApOAAAIAAjRMgpOAAA");
	this.shape_33.setTransform(140.8,109.4);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f().s("#FFDF00").ss(3.2,0,0,3).p("A1+xFMApOAAAIAADcMgpOAAAA1+mxMApOAAAIAADcMgpOAAAA1+DhMApOAAAIAADcMgpOAAAAV/ofMgpOAAAIAAjcMApOAAAAV/BzMgpOAAAIAAjaMApOAAAAV/L8MgpOAAAIAAjRMApOAAAA1+RGMApOAAAIAAjRMgpOAAA");
	this.shape_34.setTransform(140.8,109.4);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f().s("#FFDA00").ss(3.3,0,0,3).p("A1+xFMApOAAAIAADcMgpOAAAA1+mxMApOAAAIAADcMgpOAAAA1+DhMApOAAAIAADcMgpOAAAAV/ofMgpOAAAIAAjcMApOAAAAV/BzMgpOAAAIAAjaMApOAAAAV/L8MgpOAAAIAAjRMApOAAAA1+RGMApOAAAIAAjRMgpOAAA");
	this.shape_35.setTransform(140.8,109.4);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f().s("#FFD400").ss(3.3,0,0,3).p("A1+xFMApOAAAIAADcMgpOAAAA1+mxMApOAAAIAADcMgpOAAAA1+DhMApOAAAIAADcMgpOAAAAV/ofMgpOAAAIAAjcMApOAAAAV/BzMgpOAAAIAAjaMApOAAAAV/L8MgpOAAAIAAjRMApOAAAA1+RGMApOAAAIAAjRMgpOAAA");
	this.shape_36.setTransform(140.8,109.4);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f().s("#FFCE00").ss(3.4,0,0,3).p("A1+xFMApOAAAIAADcMgpOAAAA1+mxMApOAAAIAADcMgpOAAAA1+DhMApOAAAIAADcMgpOAAAAV/ofMgpOAAAIAAjcMApOAAAAV/BzMgpOAAAIAAjaMApOAAAAV/L8MgpOAAAIAAjRMApOAAAA1+RGMApOAAAIAAjRMgpOAAA");
	this.shape_37.setTransform(140.8,109.4);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f().s("#FFC800").ss(3.4,0,0,3).p("A1+xFMApOAAAIAADcMgpOAAAA1+mxMApOAAAIAADcMgpOAAAA1+DhMApOAAAIAADcMgpOAAAAV/ofMgpOAAAIAAjcMApOAAAAV/BzMgpOAAAIAAjaMApOAAAAV/L8MgpOAAAIAAjRMApOAAAA1+RGMApOAAAIAAjRMgpOAAA");
	this.shape_38.setTransform(140.8,109.4);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f().s("#FFC300").ss(3.5,0,0,3).p("A1+xFMApOAAAIAADcMgpOAAAA1+mxMApOAAAIAADcMgpOAAAA1+DhMApOAAAIAADcMgpOAAAAV/ofMgpOAAAIAAjcMApOAAAAV/BzMgpOAAAIAAjaMApOAAAAV/L8MgpOAAAIAAjRMApOAAAA1+RGMApOAAAIAAjRMgpOAAA");
	this.shape_39.setTransform(140.8,109.4);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f().s("#FFBD00").ss(3.5,0,0,3).p("A1+xFMApOAAAIAADcMgpOAAAA1+mxMApOAAAIAADcMgpOAAAA1+DhMApOAAAIAADcMgpOAAAAV/ofMgpOAAAIAAjcMApOAAAAV/BzMgpOAAAIAAjaMApOAAAAV/L8MgpOAAAIAAjRMApOAAAA1+RGMApOAAAIAAjRMgpOAAA");
	this.shape_40.setTransform(140.8,109.4);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f().s("#FFB700").ss(3.6,0,0,3).p("A1+xFMApOAAAIAADcMgpOAAAA1+mxMApOAAAIAADcMgpOAAAA1+DhMApOAAAIAADcMgpOAAAAV/ofMgpOAAAIAAjcMApOAAAAV/BzMgpOAAAIAAjaMApOAAAAV/L8MgpOAAAIAAjRMApOAAAA1+RGMApOAAAIAAjRMgpOAAA");
	this.shape_41.setTransform(140.8,109.4);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f().s("#FFB200").ss(3.6,0,0,3).p("A1+xFMApOAAAIAADcMgpOAAAA1+mxMApOAAAIAADcMgpOAAAA1+DhMApOAAAIAADcMgpOAAAAV/ofMgpOAAAIAAjcMApOAAAAV/BzMgpOAAAIAAjaMApOAAAAV/L8MgpOAAAIAAjRMApOAAAA1+RGMApOAAAIAAjRMgpOAAA");
	this.shape_42.setTransform(140.8,109.4);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f().s("#FFAC00").ss(3.7,0,0,3).p("A1+xFMApOAAAIAADcMgpOAAAA1+mxMApOAAAIAADcMgpOAAAA1+DhMApOAAAIAADcMgpOAAAAV/ofMgpOAAAIAAjcMApOAAAAV/BzMgpOAAAIAAjaMApOAAAAV/L8MgpOAAAIAAjRMApOAAAA1+RGMApOAAAIAAjRMgpOAAA");
	this.shape_43.setTransform(140.8,109.4);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f().s("#FFA600").ss(3.7,0,0,3).p("A1+xFMApOAAAIAADcMgpOAAAA1+mxMApOAAAIAADcMgpOAAAA1+DhMApOAAAIAADcMgpOAAAAV/ofMgpOAAAIAAjcMApOAAAAV/BzMgpOAAAIAAjaMApOAAAAV/L8MgpOAAAIAAjRMApOAAAA1+RGMApOAAAIAAjRMgpOAAA");
	this.shape_44.setTransform(140.8,109.4);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f().s("#FFA100").ss(3.8,0,0,3).p("A1+xFMApOAAAIAADcMgpOAAAA1+mxMApOAAAIAADcMgpOAAAA1+DhMApOAAAIAADcMgpOAAAAV/ofMgpOAAAIAAjcMApOAAAAV/BzMgpOAAAIAAjaMApOAAAAV/L8MgpOAAAIAAjRMApOAAAA1+RGMApOAAAIAAjRMgpOAAA");
	this.shape_45.setTransform(140.8,109.4);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f().s("#FF9B00").ss(3.8,0,0,3).p("A1+xFMApOAAAIAADcMgpOAAAA1+mxMApOAAAIAADcMgpOAAAA1+DhMApOAAAIAADcMgpOAAAAV/ofMgpOAAAIAAjcMApOAAAAV/BzMgpOAAAIAAjaMApOAAAAV/L8MgpOAAAIAAjRMApOAAAA1+RGMApOAAAIAAjRMgpOAAA");
	this.shape_46.setTransform(140.8,109.4);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f().s("#FF9500").ss(3.9,0,0,3).p("A1+xFMApOAAAIAADcMgpOAAAA1+mxMApOAAAIAADcMgpOAAAA1+DhMApOAAAIAADcMgpOAAAAV/ofMgpOAAAIAAjcMApOAAAAV/BzMgpOAAAIAAjaMApOAAAAV/L8MgpOAAAIAAjRMApOAAAA1+RGMApOAAAIAAjRMgpOAAA");
	this.shape_47.setTransform(140.8,109.4);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f().s("#FF8F00").ss(3.9,0,0,3).p("A1+xFMApOAAAIAADcMgpOAAAA1+mxMApOAAAIAADcMgpOAAAA1+DhMApOAAAIAADcMgpOAAAAV/ofMgpOAAAIAAjcMApOAAAAV/BzMgpOAAAIAAjaMApOAAAAV/L8MgpOAAAIAAjRMApOAAAA1+RGMApOAAAIAAjRMgpOAAA");
	this.shape_48.setTransform(140.8,109.4);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f().s("#FF8A00").ss(4,0,0,3).p("A1+xFMApOAAAIAADcMgpOAAAA1+mxMApOAAAIAADcMgpOAAAA1+DhMApOAAAIAADcMgpOAAAAV/ofMgpOAAAIAAjcMApOAAAAV/BzMgpOAAAIAAjaMApOAAAAV/L8MgpOAAAIAAjRMApOAAAA1+RGMApOAAAIAAjRMgpOAAA");
	this.shape_49.setTransform(140.8,109.4);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f().s("#FF8400").ss(4,0,0,3).p("A1+tpMApOAAAIAAjcMgpOAAAA1+jVMApOAAAIAAjcMgpOAAAA1+G9MApOAAAIAAjcMgpOAAAAV/r7MgpOAAAIAADcMApOAAAAV/hnMgpOAAAIAADaMApOAAAAV/IrMgpOAAAIAADRMApOAAAA1+N1MApOAAAIAADRMgpOAAA");
	this.shape_50.setTransform(140.8,109.4);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f().s("#FD7D01").ss(4.1,0,0,3).p("A1+xFMApOAAAIAADcMgpOAAAA1+mxMApOAAAIAADcMgpOAAAA1+DhMApOAAAIAADcMgpOAAAAV/ofMgpOAAAIAAjcMApOAAAAV/BzMgpOAAAIAAjaMApOAAAAV/L8MgpOAAAIAAjRMApOAAAA1+RGMApOAAAIAAjRMgpOAAA");
	this.shape_51.setTransform(140.8,109.4);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f().s("#FB7703").ss(4.1,0,0,3).p("A1+xFMApOAAAIAADcMgpOAAAA1+mxMApOAAAIAADcMgpOAAAA1+DhMApOAAAIAADcMgpOAAAAV/ofMgpOAAAIAAjcMApOAAAAV/BzMgpOAAAIAAjaMApOAAAAV/L8MgpOAAAIAAjRMApOAAAA1+RGMApOAAAIAAjRMgpOAAA");
	this.shape_52.setTransform(140.8,109.4);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f().s("#F97004").ss(4.2,0,0,3).p("A1+xFMApOAAAIAADcMgpOAAAA1+mxMApOAAAIAADcMgpOAAAA1+DhMApOAAAIAADcMgpOAAAAV/ofMgpOAAAIAAjcMApOAAAAV/BzMgpOAAAIAAjaMApOAAAAV/L8MgpOAAAIAAjRMApOAAAA1+RGMApOAAAIAAjRMgpOAAA");
	this.shape_53.setTransform(140.8,109.4);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f().s("#F76A06").ss(4.2,0,0,3).p("A1+xFMApOAAAIAADcMgpOAAAA1+mxMApOAAAIAADcMgpOAAAA1+DhMApOAAAIAADcMgpOAAAAV/ofMgpOAAAIAAjcMApOAAAAV/BzMgpOAAAIAAjaMApOAAAAV/L8MgpOAAAIAAjRMApOAAAA1+RGMApOAAAIAAjRMgpOAAA");
	this.shape_54.setTransform(140.8,109.4);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f().s("#F56307").ss(4.3,0,0,3).p("A1+xFMApOAAAIAADcMgpOAAAA1+mxMApOAAAIAADcMgpOAAAA1+DhMApOAAAIAADcMgpOAAAAV/ofMgpOAAAIAAjcMApOAAAAV/BzMgpOAAAIAAjaMApOAAAAV/L8MgpOAAAIAAjRMApOAAAA1+RGMApOAAAIAAjRMgpOAAA");
	this.shape_55.setTransform(140.8,109.4);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f().s("#F25C08").ss(4.3,0,0,3).p("A1+xFMApOAAAIAADcMgpOAAAA1+mxMApOAAAIAADcMgpOAAAA1+DhMApOAAAIAADcMgpOAAAAV/ofMgpOAAAIAAjcMApOAAAAV/BzMgpOAAAIAAjaMApOAAAAV/L8MgpOAAAIAAjRMApOAAAA1+RGMApOAAAIAAjRMgpOAAA");
	this.shape_56.setTransform(140.8,109.4);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f().s("#F0560A").ss(4.4,0,0,3).p("A1+xFMApOAAAIAADcMgpOAAAA1+mxMApOAAAIAADcMgpOAAAA1+DhMApOAAAIAADcMgpOAAAAV/ofMgpOAAAIAAjcMApOAAAAV/BzMgpOAAAIAAjaMApOAAAAV/L8MgpOAAAIAAjRMApOAAAA1+RGMApOAAAIAAjRMgpOAAA");
	this.shape_57.setTransform(140.8,109.4);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f().s("#EE4F0B").ss(4.4,0,0,3).p("A1+xFMApOAAAIAADcMgpOAAAA1+mxMApOAAAIAADcMgpOAAAA1+DhMApOAAAIAADcMgpOAAAAV/ofMgpOAAAIAAjcMApOAAAAV/BzMgpOAAAIAAjaMApOAAAAV/L8MgpOAAAIAAjRMApOAAAA1+RGMApOAAAIAAjRMgpOAAA");
	this.shape_58.setTransform(140.8,109.4);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f().s("#EC490D").ss(4.5,0,0,3).p("A1+xFMApOAAAIAADcMgpOAAAA1+mxMApOAAAIAADcMgpOAAAA1+DhMApOAAAIAADcMgpOAAAAV/ofMgpOAAAIAAjcMApOAAAAV/BzMgpOAAAIAAjaMApOAAAAV/L8MgpOAAAIAAjRMApOAAAA1+RGMApOAAAIAAjRMgpOAAA");
	this.shape_59.setTransform(140.8,109.4);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f().s("#EA420E").ss(4.5,0,0,3).p("A1+xFMApOAAAIAADcMgpOAAAA1+mxMApOAAAIAADcMgpOAAAA1+DhMApOAAAIAADcMgpOAAAAV/ofMgpOAAAIAAjcMApOAAAAV/BzMgpOAAAIAAjaMApOAAAAV/L8MgpOAAAIAAjRMApOAAAA1+RGMApOAAAIAAjRMgpOAAA");
	this.shape_60.setTransform(140.8,109.4);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f().s("#E83B0F").ss(4.6,0,0,3).p("A1+xFMApOAAAIAADcMgpOAAAA1+mxMApOAAAIAADcMgpOAAAA1+DhMApOAAAIAADcMgpOAAAAV/ofMgpOAAAIAAjcMApOAAAAV/BzMgpOAAAIAAjaMApOAAAAV/L8MgpOAAAIAAjRMApOAAAA1+RGMApOAAAIAAjRMgpOAAA");
	this.shape_61.setTransform(140.8,109.4);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f().s("#E63511").ss(4.6,0,0,3).p("A1+xFMApOAAAIAADcMgpOAAAA1+mxMApOAAAIAADcMgpOAAAA1+DhMApOAAAIAADcMgpOAAAAV/ofMgpOAAAIAAjcMApOAAAAV/BzMgpOAAAIAAjaMApOAAAAV/L8MgpOAAAIAAjRMApOAAAA1+RGMApOAAAIAAjRMgpOAAA");
	this.shape_62.setTransform(140.8,109.4);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f().s("#E42E12").ss(4.7,0,0,3).p("A1+xFMApOAAAIAADcMgpOAAAA1+mxMApOAAAIAADcMgpOAAAA1+DhMApOAAAIAADcMgpOAAAAV/ofMgpOAAAIAAjcMApOAAAAV/BzMgpOAAAIAAjaMApOAAAAV/L8MgpOAAAIAAjRMApOAAAA1+RGMApOAAAIAAjRMgpOAAA");
	this.shape_63.setTransform(140.8,109.4);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f().s("#E22814").ss(4.7,0,0,3).p("A1+xFMApOAAAIAADcMgpOAAAA1+mxMApOAAAIAADcMgpOAAAA1+DhMApOAAAIAADcMgpOAAAAV/ofMgpOAAAIAAjcMApOAAAAV/BzMgpOAAAIAAjaMApOAAAAV/L8MgpOAAAIAAjRMApOAAAA1+RGMApOAAAIAAjRMgpOAAA");
	this.shape_64.setTransform(140.8,109.4);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f().s("#E02115").ss(4.8,0,0,3).p("A1+xFMApOAAAIAADcMgpOAAAA1+mxMApOAAAIAADcMgpOAAAA1+DhMApOAAAIAADcMgpOAAAAV/ofMgpOAAAIAAjcMApOAAAAV/BzMgpOAAAIAAjaMApOAAAAV/L8MgpOAAAIAAjRMApOAAAA1+RGMApOAAAIAAjRMgpOAAA");
	this.shape_65.setTransform(140.8,109.4);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f().s("#DD1A16").ss(4.8,0,0,3).p("A1+xFMApOAAAIAADcMgpOAAAA1+mxMApOAAAIAADcMgpOAAAA1+DhMApOAAAIAADcMgpOAAAAV/ofMgpOAAAIAAjcMApOAAAAV/BzMgpOAAAIAAjaMApOAAAAV/L8MgpOAAAIAAjRMApOAAAA1+RGMApOAAAIAAjRMgpOAAA");
	this.shape_66.setTransform(140.8,109.4);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f().s("#DB1418").ss(4.9,0,0,3).p("A1+xFMApOAAAIAADcMgpOAAAA1+mxMApOAAAIAADcMgpOAAAA1+DhMApOAAAIAADcMgpOAAAAV/ofMgpOAAAIAAjcMApOAAAAV/BzMgpOAAAIAAjaMApOAAAAV/L8MgpOAAAIAAjRMApOAAAA1+RGMApOAAAIAAjRMgpOAAA");
	this.shape_67.setTransform(140.8,109.4);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f().s("#D90D19").ss(4.9,0,0,3).p("A1+xFMApOAAAIAADcMgpOAAAA1+mxMApOAAAIAADcMgpOAAAA1+DhMApOAAAIAADcMgpOAAAAV/ofMgpOAAAIAAjcMApOAAAAV/BzMgpOAAAIAAjaMApOAAAAV/L8MgpOAAAIAAjRMApOAAAA1+RGMApOAAAIAAjRMgpOAAA");
	this.shape_68.setTransform(140.8,109.4);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f().s("#D7071B").ss(5,0,0,3).p("A1+xFMApOAAAIAADcMgpOAAAA1+mxMApOAAAIAADcMgpOAAAA1+DhMApOAAAIAADcMgpOAAAAV/ofMgpOAAAIAAjcMApOAAAAV/BzMgpOAAAIAAjaMApOAAAAV/L8MgpOAAAIAAjRMApOAAAA1+RGMApOAAAIAAjRMgpOAAA");
	this.shape_69.setTransform(140.8,109.4);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f().s("#D5001C").ss(5,0,0,3).p("A1+tpMApOAAAIAAjcMgpOAAAA1+jVMApOAAAIAAjcMgpOAAAA1+G9MApOAAAIAAjcMgpOAAAAV/r7MgpOAAAIAADcMApOAAAAV/hnMgpOAAAIAADaMApOAAAAV/IrMgpOAAAIAADRMApOAAAA1+N1MApOAAAIAADRMgpOAAA");
	this.shape_70.setTransform(140.8,109.4);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f().s("#CA001B").ss(5.1,0,0,3).p("A1+xFMApOAAAIAADcMgpOAAAA1+mxMApOAAAIAADcMgpOAAAA1+DhMApOAAAIAADcMgpOAAAAV/ofMgpOAAAIAAjcMApOAAAAV/BzMgpOAAAIAAjaMApOAAAAV/L8MgpOAAAIAAjRMApOAAAA1+RGMApOAAAIAAjRMgpOAAA");
	this.shape_71.setTransform(140.8,109.4);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f().s("#C00019").ss(5.1,0,0,3).p("A1+xFMApOAAAIAADcMgpOAAAA1+mxMApOAAAIAADcMgpOAAAA1+DhMApOAAAIAADcMgpOAAAAV/ofMgpOAAAIAAjcMApOAAAAV/BzMgpOAAAIAAjaMApOAAAAV/L8MgpOAAAIAAjRMApOAAAA1+RGMApOAAAIAAjRMgpOAAA");
	this.shape_72.setTransform(140.8,109.4);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f().s("#B50018").ss(5.2,0,0,3).p("A1+xFMApOAAAIAADcMgpOAAAA1+mxMApOAAAIAADcMgpOAAAA1+DhMApOAAAIAADcMgpOAAAAV/ofMgpOAAAIAAjcMApOAAAAV/BzMgpOAAAIAAjaMApOAAAAV/L8MgpOAAAIAAjRMApOAAAA1+RGMApOAAAIAAjRMgpOAAA");
	this.shape_73.setTransform(140.8,109.4);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f().s("#AA0016").ss(5.2,0,0,3).p("A1+xFMApOAAAIAADcMgpOAAAA1+mxMApOAAAIAADcMgpOAAAA1+DhMApOAAAIAADcMgpOAAAAV/ofMgpOAAAIAAjcMApOAAAAV/BzMgpOAAAIAAjaMApOAAAAV/L8MgpOAAAIAAjRMApOAAAA1+RGMApOAAAIAAjRMgpOAAA");
	this.shape_74.setTransform(140.8,109.4);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f().s("#A00015").ss(5.3,0,0,3).p("A1+xFMApOAAAIAADcMgpOAAAA1+mxMApOAAAIAADcMgpOAAAA1+DhMApOAAAIAADcMgpOAAAAV/ofMgpOAAAIAAjcMApOAAAAV/BzMgpOAAAIAAjaMApOAAAAV/L8MgpOAAAIAAjRMApOAAAA1+RGMApOAAAIAAjRMgpOAAA");
	this.shape_75.setTransform(140.8,109.4);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f().s("#950014").ss(5.3,0,0,3).p("A1+xFMApOAAAIAADcMgpOAAAA1+mxMApOAAAIAADcMgpOAAAA1+DhMApOAAAIAADcMgpOAAAAV/ofMgpOAAAIAAjcMApOAAAAV/BzMgpOAAAIAAjaMApOAAAAV/L8MgpOAAAIAAjRMApOAAAA1+RGMApOAAAIAAjRMgpOAAA");
	this.shape_76.setTransform(140.8,109.4);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f().s("#8A0012").ss(5.4,0,0,3).p("A1+xFMApOAAAIAADcMgpOAAAA1+mxMApOAAAIAADcMgpOAAAA1+DhMApOAAAIAADcMgpOAAAAV/ofMgpOAAAIAAjcMApOAAAAV/BzMgpOAAAIAAjaMApOAAAAV/L8MgpOAAAIAAjRMApOAAAA1+RGMApOAAAIAAjRMgpOAAA");
	this.shape_77.setTransform(140.8,109.4);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f().s("#800011").ss(5.4,0,0,3).p("A1+xFMApOAAAIAADcMgpOAAAA1+mxMApOAAAIAADcMgpOAAAA1+DhMApOAAAIAADcMgpOAAAAV/ofMgpOAAAIAAjcMApOAAAAV/BzMgpOAAAIAAjaMApOAAAAV/L8MgpOAAAIAAjRMApOAAAA1+RGMApOAAAIAAjRMgpOAAA");
	this.shape_78.setTransform(140.8,109.4);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f().s("#75000F").ss(5.5,0,0,3).p("A1+xFMApOAAAIAADcMgpOAAAA1+mxMApOAAAIAADcMgpOAAAA1+DhMApOAAAIAADcMgpOAAAAV/ofMgpOAAAIAAjcMApOAAAAV/BzMgpOAAAIAAjaMApOAAAAV/L8MgpOAAAIAAjRMApOAAAA1+RGMApOAAAIAAjRMgpOAAA");
	this.shape_79.setTransform(140.8,109.4);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f().s("#6B000E").ss(5.5,0,0,3).p("A1+xFMApOAAAIAADcMgpOAAAA1+mxMApOAAAIAADcMgpOAAAA1+DhMApOAAAIAADcMgpOAAAAV/ofMgpOAAAIAAjcMApOAAAAV/BzMgpOAAAIAAjaMApOAAAAV/L8MgpOAAAIAAjRMApOAAAA1+RGMApOAAAIAAjRMgpOAAA");
	this.shape_80.setTransform(140.8,109.4);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f().s("#60000D").ss(5.6,0,0,3).p("A1+xFMApOAAAIAADcMgpOAAAA1+mxMApOAAAIAADcMgpOAAAA1+DhMApOAAAIAADcMgpOAAAAV/ofMgpOAAAIAAjcMApOAAAAV/BzMgpOAAAIAAjaMApOAAAAV/L8MgpOAAAIAAjRMApOAAAA1+RGMApOAAAIAAjRMgpOAAA");
	this.shape_81.setTransform(140.8,109.4);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f().s("#55000B").ss(5.6,0,0,3).p("A1+xFMApOAAAIAADcMgpOAAAA1+mxMApOAAAIAADcMgpOAAAA1+DhMApOAAAIAADcMgpOAAAAV/ofMgpOAAAIAAjcMApOAAAAV/BzMgpOAAAIAAjaMApOAAAAV/L8MgpOAAAIAAjRMApOAAAA1+RGMApOAAAIAAjRMgpOAAA");
	this.shape_82.setTransform(140.8,109.4);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f().s("#4B000A").ss(5.7,0,0,3).p("A1+xFMApOAAAIAADcMgpOAAAA1+mxMApOAAAIAADcMgpOAAAA1+DhMApOAAAIAADcMgpOAAAAV/ofMgpOAAAIAAjcMApOAAAAV/BzMgpOAAAIAAjaMApOAAAAV/L8MgpOAAAIAAjRMApOAAAA1+RGMApOAAAIAAjRMgpOAAA");
	this.shape_83.setTransform(140.8,109.4);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f().s("#400008").ss(5.7,0,0,3).p("A1+xFMApOAAAIAADcMgpOAAAA1+mxMApOAAAIAADcMgpOAAAA1+DhMApOAAAIAADcMgpOAAAAV/ofMgpOAAAIAAjcMApOAAAAV/BzMgpOAAAIAAjaMApOAAAAV/L8MgpOAAAIAAjRMApOAAAA1+RGMApOAAAIAAjRMgpOAAA");
	this.shape_84.setTransform(140.8,109.4);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f().s("#350007").ss(5.8,0,0,3).p("A1+xFMApOAAAIAADcMgpOAAAA1+mxMApOAAAIAADcMgpOAAAA1+DhMApOAAAIAADcMgpOAAAAV/ofMgpOAAAIAAjcMApOAAAAV/BzMgpOAAAIAAjaMApOAAAAV/L8MgpOAAAIAAjRMApOAAAA1+RGMApOAAAIAAjRMgpOAAA");
	this.shape_85.setTransform(140.8,109.4);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f().s("#2B0006").ss(5.8,0,0,3).p("A1+xFMApOAAAIAADcMgpOAAAA1+mxMApOAAAIAADcMgpOAAAA1+DhMApOAAAIAADcMgpOAAAAV/ofMgpOAAAIAAjcMApOAAAAV/BzMgpOAAAIAAjaMApOAAAAV/L8MgpOAAAIAAjRMApOAAAA1+RGMApOAAAIAAjRMgpOAAA");
	this.shape_86.setTransform(140.8,109.4);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f().s("#200004").ss(5.9,0,0,3).p("A1+xFMApOAAAIAADcMgpOAAAA1+mxMApOAAAIAADcMgpOAAAA1+DhMApOAAAIAADcMgpOAAAAV/ofMgpOAAAIAAjcMApOAAAAV/BzMgpOAAAIAAjaMApOAAAAV/L8MgpOAAAIAAjRMApOAAAA1+RGMApOAAAIAAjRMgpOAAA");
	this.shape_87.setTransform(140.8,109.4);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f().s("#150003").ss(5.9,0,0,3).p("A1+xFMApOAAAIAADcMgpOAAAA1+mxMApOAAAIAADcMgpOAAAA1+DhMApOAAAIAADcMgpOAAAAV/ofMgpOAAAIAAjcMApOAAAAV/BzMgpOAAAIAAjaMApOAAAAV/L8MgpOAAAIAAjRMApOAAAA1+RGMApOAAAIAAjRMgpOAAA");
	this.shape_88.setTransform(140.8,109.4);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f().s("#0B0001").ss(6,0,0,3).p("A1+xFMApOAAAIAADcMgpOAAAA1+mxMApOAAAIAADcMgpOAAAA1+DhMApOAAAIAADcMgpOAAAAV/ofMgpOAAAIAAjcMApOAAAAV/BzMgpOAAAIAAjaMApOAAAAV/L8MgpOAAAIAAjRMApOAAAA1+RGMApOAAAIAAjRMgpOAAA");
	this.shape_89.setTransform(140.8,109.4);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f().s("#000000").ss(6,0,0,3).p("A1+tpMApOAAAIAAjcMgpOAAAA1+jVMApOAAAIAAjcMgpOAAAA1+G9MApOAAAIAAjcMgpOAAAAV/r7MgpOAAAIAADcMApOAAAAV/hnMgpOAAAIAADaMApOAAAAV/IrMgpOAAAIAADRMApOAAAA1+N1MApOAAAIAADRMgpOAAA");
	this.shape_90.setTransform(140.8,109.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_35}]},1).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_37}]},1).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_42}]},1).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_44}]},1).to({state:[{t:this.shape_45}]},1).to({state:[{t:this.shape_46}]},1).to({state:[{t:this.shape_47}]},1).to({state:[{t:this.shape_48}]},1).to({state:[{t:this.shape_49}]},1).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_52}]},1).to({state:[{t:this.shape_53}]},1).to({state:[{t:this.shape_54}]},1).to({state:[{t:this.shape_55}]},1).to({state:[{t:this.shape_56}]},1).to({state:[{t:this.shape_57}]},1).to({state:[{t:this.shape_58}]},1).to({state:[{t:this.shape_59}]},1).to({state:[{t:this.shape_60}]},1).to({state:[{t:this.shape_61}]},1).to({state:[{t:this.shape_62}]},1).to({state:[{t:this.shape_63}]},1).to({state:[{t:this.shape_64}]},1).to({state:[{t:this.shape_65}]},1).to({state:[{t:this.shape_66}]},1).to({state:[{t:this.shape_67}]},1).to({state:[{t:this.shape_68}]},1).to({state:[{t:this.shape_69}]},1).to({state:[{t:this.shape_70}]},1).to({state:[{t:this.shape_71}]},1).to({state:[{t:this.shape_72}]},1).to({state:[{t:this.shape_73}]},1).to({state:[{t:this.shape_74}]},1).to({state:[{t:this.shape_75}]},1).to({state:[{t:this.shape_76}]},1).to({state:[{t:this.shape_77}]},1).to({state:[{t:this.shape_78}]},1).to({state:[{t:this.shape_79}]},1).to({state:[{t:this.shape_80}]},1).to({state:[{t:this.shape_81}]},1).to({state:[{t:this.shape_82}]},1).to({state:[{t:this.shape_83}]},1).to({state:[{t:this.shape_84}]},1).to({state:[{t:this.shape_85}]},1).to({state:[{t:this.shape_86}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_88}]},1).to({state:[{t:this.shape_89}]},1).to({state:[{t:this.shape_90}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-1,283.5,220.9);


(lib.ani_backpressureMask = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// mask
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("A6dICIAAmkIEXAPIAApuMAwlAAAIAAQDg");
	this.shape.setTransform(106,-19.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("A6eICIAAmkIFnANQgFk9gPkvMAvqAAAIAAQDg");
	this.shape_1.setTransform(107.6,-19.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("A6eICIAAmkIG1AMQgLlFgdkmMAuwAAAIAAQDg");
	this.shape_2.setTransform(109.3,-19.1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("A6eICIAAmkIIEAKQgQlLgtkeMAt1AAAIAAQDg");
	this.shape_3.setTransform(111,-19.1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("A6dICIAAmkIJRAJQgVlUg7kUMAs6AAAIAAQDg");
	this.shape_4.setTransform(112.6,-19.1);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("A6dICIAAmkIKfAHQgalahKkMMAsAAAAIAAQDg");
	this.shape_5.setTransform(114.3,-19.1);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("A6eICIAAmkILuAGQgelhhakEMArHAAAIAAQDg");
	this.shape_6.setTransform(116,-19.1);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("A6eICIAAmkIM9AFQgllqhnj6MAqMAAAIAAQDg");
	this.shape_7.setTransform(117.6,-19.1);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("A6dICIAAmkIOKAEQgplxh2jyMApQAAAIAAQDg");
	this.shape_8.setTransform(119.3,-19.1);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("A6dICIAAmkIPZACQgvl4iFjpMAoWAAAIAAQDg");
	this.shape_9.setTransform(121,-19.1);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("A6dICIAAmkIQnAAQg0l+iUjhMAndAAAIAAQDg");
	this.shape_10.setTransform(122.6,-19.1);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("A6dICIAAmkISHAAQgqmBjWjeMAm0AAAIAAQDg");
	this.shape_11.setTransform(124.3,-19.1);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("A6eICIAAmkITpAAQghmFkYjaMAmNAAAIAAQDg");
	this.shape_12.setTransform(126,-19.1);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("A6eICIAAmkIT+AAQA1mIjdjXMAjmAAAIAAQDg");
	this.shape_13.setTransform(127.6,-19.1);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("A6eICIAAmkIUTAAQCJmMihjTMAhBAAAIAAQDg");
	this.shape_14.setTransform(129.3,-19.1);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("A6dICIAAmkIUnAAQDemOhljRIebAAIAAQDg");
	this.shape_15.setTransform(131,-19.1);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("Au+JhIAAmkIQ2AAQH+i9FJphIAATCg");
	this.shape_16.setTransform(57.5,-28.6);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AupG4IAAmkIQ2AAQH/i8EekPIAANvg");
	this.shape_17.setTransform(52.9,-11.6);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AuTEYIAAmjIQ2AAQH/i9DyBDIAAIdg");
	this.shape_18.setTransform(48.4,4.4);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("At9DwIAAmiIQ2AAQH/i+DGGUIAADMg");
	this.shape_19.setTransform(43.9,8.4);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("At0DtIAAmeIQ2AAQH+i9C1GdIAAC+g");
	this.shape_20.setTransform(32.7,8.6);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AtsDrIAAmaIQ2AAQH/i+CkGmIAACyg");
	this.shape_21.setTransform(21.6,8.9);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AtjDoIAAmWIQ2AAQH+i9CUGvIAACkg");
	this.shape_22.setTransform(10.5,9.1);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AtbDmIAAmSIQ2AAQH/i+CCG4IAACYg");
	this.shape_23.setTransform(-0.7,9.4);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AtTDkIAAmOIQ2AAQH/i+ByHBIAACLg");
	this.shape_24.setTransform(-11.8,9.6);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AtKDhIAAmKIQ2AAQH+i9BhHJIAAB+g");
	this.shape_25.setTransform(-23,9.8);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AtCDfIAAmGIQ2AAQH/i+BQHTIAABxg");
	this.shape_26.setTransform(-34.1,10.1);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("As6DcIAAmCIQ2AAQH/i9A/HbIAABkg");
	this.shape_27.setTransform(-45.2,10.3);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AsxDaIAAl+IQ2AAQH+i9AvHkIAABXg");
	this.shape_28.setTransform(-56.4,10.5);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("rgba(255,255,255,0)").s().p("AunGAIAAr/IdPAAIAAL/g");
	this.shape_29.setTransform(36.7,-17);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("rgba(255,255,255,0.2)").s().p("AunGAIAAr/IdPAAIAAL/g");
	this.shape_30.setTransform(36.7,-17);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("rgba(255,255,255,0.4)").s().p("AunGAIAAr/IdPAAIAAL/g");
	this.shape_31.setTransform(36.7,-17);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("rgba(255,255,255,0.6)").s().p("AunGAIAAr/IdPAAIAAL/g");
	this.shape_32.setTransform(36.7,-17);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("rgba(255,255,255,0.8)").s().p("AunGAIAAr/IdPAAIAAL/g");
	this.shape_33.setTransform(36.7,-17);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#FFFFFF").s().p("AunGAIAAr/IdPAAIAAL/g");
	this.shape_34.setTransform(36.7,-17);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_34}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-63.5,-70.6,339,103);


(lib.ani_airflow_ = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#D5001C","rgba(213,0,28,0)","#D5001C","rgba(213,0,28,0)"],[0,0.275,0.667,1],-700,-1.2,700,-1.2).s().p("EhtWgC0YAAAAA4AABoAAYANAAAOAAAPgBYAHAAAHAAAIAAYAHAAAIAAAIAAYAgAAAjgBAlAAYAlABAoAAArACYAKABALAAALAAYALABAKABALABYAGAAAFABAGAAIAIABIACAAYgCAAADAAAAAAIAFABYALABAMACAMABYAYADAZADAaACYAMABANABANACYANACAMABANACYA0AHA1AHA4ALYAcAFAdAFAdAFYAdAGAeAGAeAGYAPADAQADAPADIALADIAGABIADAAYAAABAEAAgDAAYAIACAIACAIACYAgAHAgAIAhAIYAgAIAiAHAiAJYAhAIAiAIAjAJYBFAPBHASBIARYAmAIAlAJAmAJYAmAIAmAJAnAJYBPAQBSARBTAPYApAHAqAHArAHYAWADAVADAWADYALACALACALABYALACAMABALABYArAFArAFAsAFYArAGAuADAuADYAuAEAvAEAvACYAuACAvACAvACYAXAAAYABAYABYAYAAAXAAAYAAYAwAAAwAAAxAAIAKAAIAJAAIASgBYAMAAAMgBAMAAYAYgBAYgBAYAAYAvgCAzgDAygDYAZgCAZgBAZgCYAZgBAZgDAZgCYAZgDAZgCAZgCYANgBAMgCANgBYANgBAMgCANgBYAZgDAZgDAagDIAmgFIATgDIAFAAYAFgBgBAAACAAIAKgBYAxgIAygIAzgIYAZgEAZgEAagFYAZgEAZgFAagFYAzgJAzgJA0gKYBmgSBngTBngSYAagFAagEAagFYAagFAbgFAZgDYA0gIA0gHA0gGYAbgEAagEAagEIAUgCIAFgBYABAAAAAAADgBIAKgBIAogEYA1gGA2gGA1gGYA1gEA2gGA1gEYA2gFA2gCA2gDYBsgIBtgCBugEIAUAAYADAAAAAAACAAIAFAAIAKAAIApAAYAcAAAbAAAcAAYANAAAOAAAOAAIApABIBSADYDaAKDdATDYAcIClAVYA3AFA3AHA2AIYBtARBtAQBtASYDaAiDYAmDXAlYBrATBrATBqASIAUADIAKACYABAAAEABABAAIAFABIAoAGYAbAEAaAEAbAEYAbAEAaAEAbAEYAbADAbAEAaADYAbAEAbADAbAEYAbACAbADAbADYAbACAbADAbACYAcACAbABAcABIAUACYgBAAAIAAABAAIAFAAIAKAAIAngBIAoAAYANAAAMAAAPgBYA4gEA4gDA2gIYAbgDAbgDAagFYAbgFAagFAbgFIAUgEIAKgCYADAAgDABAIgCIAEgCIAmgJYAYgHAZgGAZgHYAxgMAygQAxgPYAxgPAxgQAxgPYAXgHAYgHAXgIIAjgLYAMgEAMgDALgEYAugNAugOAugMYAWgFAXgHAXgFYAXgGAWgFAXgFIAIgCYAAAAAGgBgEABIAEgBIASgDYAMgDALgCAMgCYAYgEAXgFAXgEYAGgBAGgBAFAAIARgBYALgBALgCALgBYAWgDAWgDAWgDYAtgEAtgDAsgEYAWgCAXAAAWgBYAWgBAWgBAWgBIARAAIAEAAYgDAAAEAAABAAIAIAAYAMAAALAAALAAYALAAAMAAALAAYAKABALAAAKABYApABArAEArADYAVACAVADAWACYAVACAVACAVADYBUAIBTAMBRANYAoAGAoAGAoAHYAoAHAoAHAnAHYBOANBNANBKANYAmAGAkAGAlAGYAJACAJABAJACIAPACIAOACYASADASACASACYAIABAJABAJACYAJABAKAAAJABYASACASACASABYASACASABASABYASABARABASAAYAJAAAJAAAJAAIANAAIAHAAIADAAYgBAAAGAAABAAYAQgCARgBAQgBYAQgBAQgBARgCYAQgDARgCAQgCYARgDAQgCAQgCYAQgCAPgEAPgDYAfgFAdgGAdgGYAdgHAcgHAcgHYANgDAOgDANgDIAKgDIAFgBIAEgBIACgBYAHgBAGgCAHgCYAzgOAxgOAvgNYAvgOAsgNApgNYAVgHAUgGATgHYATgHATgGASgHYBHgZA8gVAwgVYBhgnAzgVAAAAYADgBABgDgBgCYgBgCgDgCgCABIAAAAYAAAAg2AOhkAcYgZAGgcAIgfAHYgfAIghAIglAJYgSAFgTAFgTAFYgUAEgUAEgVAFYgqAJgsAKgvAKYgwAJgyAJg0AKYgHACgHABgGABIgDABYgBAAABAAgBAAIgFABIgKABYgOACgNACgOACYgbAEgcADgdAEYgcADgdAEgeAEYgPABgPADgOABYgPABgPABgPABYgPABgPABgPABYgPABgRAAgQAAYgQAAgRAAgQABYgCAAAEgBgDAAIgDAAIgGAAIgLgBYgIgBgIAAgIgBYgQAAgQgDgQgCYgRgCgQgBgRgDYgQgDgRgDgQgCYgJgCgIgBgJgCYgIgBgJgCgJAAYgRgDgSgDgSgEIgNgCYgDgBADABgCgBIgDgBIgHgBYgJgCgJgCgJgCYgkgIgkgIglgJYhKgQhLgRhOgRYgngJgngIgngJYgogJgpgIgpgJYhSgQhVgPhXgOYgVgEgWgDgWgDYgWgDgWgDgXgDYgtgFgtgFgwgDYgMgBgMgBgMgBYgLgBgLAAgMAAYgLgBgLAAgLgBIgJAAIgGAAIgFAAIgRAAYgvABgwgBgvACYgwADgwADgxADYgYADgZADgZADYgMABgMABgNACIgTACYgGABgGAAgGABYgXAEgYAEgXAEYgMACgMACgMACIgSADIgEABYgHABACAAgCAAIgJACYgZAFgZAGgYAFYgZAFgYAHgYAGYgxAMgxAOgxAOYgMADgMAEgMADYgLAEgMAEgMADYgYAIgYAHgZAIYguAOgvAPgvAOYgvAPguANgyANYgZAHgYAHgZAHIglAKIgFACYAFgCgGACAAAAIgJACIgSADYgYAGgYAFgYAFYgYAFgYADgYAEYgxAJgwADgwAGYgMACgNAAgNABIgnACIgoACIgKAAIgFABYgCAAAFAAgFAAIgSAAYgaAAgZAAgZgBYgZAAgbgBgZgBYgagBgagCgagBYgagBgbgCgagCYgagBgagCgbgCYgagCgbgCgbgCYgagCgbgCgbgDIgogDIgFAAYgCAAABAAgDAAIgKgBIgUgCYhsgLhsgLhsgLYhtgLhsgKhtgLYhtgMhugJhtgMYhugLhugNhugMYhugNhugJhugNYjbgZjcgUjdgPYjegPjcgCjagBYhugBhtADhtABYg2ACg2ABg2ACIgoABIgKABYgBAAgDAAgCAAIgFAAIgUACYgbABgbACgbACYg2ADg2ADg2ADYgbACgaACgaADYgaACgbACgaACYg1AFg0AFg0AEYgaACgbADgaACYgaADgZACgaACYgzAFgzAFgzAFYgZACgaACgZADYgZACgaACgZACYgzAEgyAEgzAEIgJAAYgBAAgEABACAAIgFAAIgSABIglABYgZACgYABgZABIgkACYgNAAgMABgMAAYgYABgZAAgYABYgYABgYABgYAAYgYAAgYAAgYAAYgvABgvABgwgBYgwgBgvAAgvgBYgvgBgugCgugBYgXgBgXAAgXgBYgWgBgXgBgXgCYgtgCgtgCgsgDYgsgDgrgEgrgDYhVgFhZgMhWgIYgKgBgKgBgKgBYgKgBgKgCgLgBYgUgDgVgDgUgCYgVgDgUgCgVgDYgUgDgUgDgUgEYhRgLhOgNhNgMYhOgOhMgNhKgMYhMgOhJgLhHgMYgkgGgjgGgjgFYgigFgigFgigFYghgEghgFgggEYgIgBgIgBgIgBYgFgBABAAgBAAIgEAAIgGgBIgMgBYgQgBgRgCgQgBYgggDgfgCgfgDYgggBgegBgegBYgPgBgPAAgOgBYgIAAgHAAgHgBYgIAAgHAAgHAAYgdABgcAAgcAAYgOAAgOAAgNAAYgOAAgMABgNABYgaABgYABgZACYgMABgMABgMABIgEAAYgBAAABAAgEAAIgCABIgJABYgGAAgGABgGABYgMABgMACgLABYgLACgLABgLACYgsAGgpAIglAHYgmAHgiAHgfAGYgIACgIABgIACYgHACgIABgHACYgOADgNADgNADYhlAag2AOAAAAYgDAAgCADABADYABACACACACAA");
	this.shape.setTransform(3500,22.8,1,1,0,0,0,0,-1.2);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Ebene 2
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["#D5001C","rgba(213,0,28,0)","#D5001C","rgba(213,0,28,0)"],[0,0.275,0.667,1],-700,-1.2,700,-1.2).s().p("EhtWgC0YAAAAA4AABoAAYANAAAOAAAPgBYAHAAAHAAAIAAYAHAAAIAAAIAAYAgAAAjgBAlAAYAlABAoAAArACYAKABALAAALAAYALABAKABALABYAGAAAFABAGAAIAIABIACAAYgCAAADAAAAAAIAFABYALABAMACAMABYAYADAZADAaACYAMABANABANACYANACAMABANACYA0AHA1AHA4ALYAcAFAdAFAdAFYAdAGAeAGAeAGYAPADAQADAPADIALADIAGABIADAAYAAABAEAAgDAAYAIACAIACAIACYAgAHAgAIAhAIYAgAIAiAHAiAJYAhAIAiAIAjAJYBFAPBHASBIARYAmAIAlAJAmAJYAmAIAmAJAnAJYBPAQBSARBTAPYApAHAqAHArAHYAWADAVADAWADYALACALACALABYALACAMABALABYArAFArAFAsAFYArAGAuADAuADYAuAEAvAEAvACYAuACAvACAvACYAXAAAYABAYABYAYAAAXAAAYAAYAwAAAwAAAxAAIAKAAIAJAAIASgBYAMAAAMgBAMAAYAYgBAYgBAYAAYAvgCAzgDAygDYAZgCAZgBAZgCYAZgBAZgDAZgCYAZgDAZgCAZgCYANgBAMgCANgBYANgBAMgCANgBYAZgDAZgDAagDIAmgFIATgDIAFAAYAFgBgBAAACAAIAKgBYAxgIAygIAzgIYAZgEAZgEAagFYAZgEAZgFAagFYAzgJAzgJA0gKYBmgSBngTBngSYAagFAagEAagFYAagFAbgFAZgDYA0gIA0gHA0gGYAbgEAagEAagEIAUgCIAFgBYABAAAAAAADgBIAKgBIAogEYA1gGA2gGA1gGYA1gEA2gGA1gEYA2gFA2gCA2gDYBsgIBtgCBugEIAUAAYADAAAAAAACAAIAFAAIAKAAIApAAYAcAAAbAAAcAAYANAAAOAAAOAAIApABIBSADYDaAKDdATDYAcIClAVYA3AFA3AHA2AIYBtARBtAQBtASYDaAiDYAmDXAlYBrATBrATBqASIAUADIAKACYABAAAEABABAAIAFABIAoAGYAbAEAaAEAbAEYAbAEAaAEAbAEYAbADAbAEAaADYAbAEAbADAbAEYAbACAbADAbADYAbACAbADAbACYAcACAbABAcABIAUACYgBAAAIAAABAAIAFAAIAKAAIAngBIAoAAYANAAAMAAAPgBYA4gEA4gDA2gIYAbgDAbgDAagFYAbgFAagFAbgFIAUgEIAKgCYADAAgDABAIgCIAEgCIAmgJYAYgHAZgGAZgHYAxgMAygQAxgPYAxgPAxgQAxgPYAXgHAYgHAXgIIAjgLYAMgEAMgDALgEYAugNAugOAugMYAWgFAXgHAXgFYAXgGAWgFAXgFIAIgCYAAAAAGgBgEABIAEgBIASgDYAMgDALgCAMgCYAYgEAXgFAXgEYAGgBAGgBAFAAIARgBYALgBALgCALgBYAWgDAWgDAWgDYAtgEAtgDAsgEYAWgCAXAAAWgBYAWgBAWgBAWgBIARAAIAEAAYgDAAAEAAABAAIAIAAYAMAAALAAALAAYALAAAMAAALAAYAKABALAAAKABYApABArAEArADYAVACAVADAWACYAVACAVACAVADYBUAIBTAMBRANYAoAGAoAGAoAHYAoAHAoAHAnAHYBOANBNANBKANYAmAGAkAGAlAGYAJACAJABAJACIAPACIAOACYASADASACASACYAIABAJABAJACYAJABAKAAAJABYASACASACASABYASACASABASABYASABARABASAAYAJAAAJAAAJAAIANAAIAHAAIADAAYgBAAAGAAABAAYAQgCARgBAQgBYAQgBAQgBARgCYAQgDARgCAQgCYARgDAQgCAQgCYAQgCAPgEAPgDYAfgFAdgGAdgGYAdgHAcgHAcgHYANgDAOgDANgDIAKgDIAFgBIAEgBIACgBYAHgBAGgCAHgCYAzgOAxgOAvgNYAvgOAsgNApgNYAVgHAUgGATgHYATgHATgGASgHYBHgZA8gVAwgVYBhgnAzgVAAAAYADgBABgDgBgCYgBgCgDgCgCABIAAAAYAAAAg2AOhkAcYgZAGgcAIgfAHYgfAIghAIglAJYgSAFgTAFgTAFYgUAEgUAEgVAFYgqAJgsAKgvAKYgwAJgyAJg0AKYgHACgHABgGABIgDABYgBAAABAAgBAAIgFABIgKABYgOACgNACgOACYgbAEgcADgdAEYgcADgdAEgeAEYgPABgPADgOABYgPABgPABgPABYgPABgPABgPABYgPABgRAAgQAAYgQAAgRAAgQABYgCAAAEgBgDAAIgDAAIgGAAIgLgBYgIgBgIAAgIgBYgQAAgQgDgQgCYgRgCgQgBgRgDYgQgDgRgDgQgCYgJgCgIgBgJgCYgIgBgJgCgJAAYgRgDgSgDgSgEIgNgCYgDgBADABgCgBIgDgBIgHgBYgJgCgJgCgJgCYgkgIgkgIglgJYhKgQhLgRhOgRYgngJgngIgngJYgogJgpgIgpgJYhSgQhVgPhXgOYgVgEgWgDgWgDYgWgDgWgDgXgDYgtgFgtgFgwgDYgMgBgMgBgMgBYgLgBgLAAgMAAYgLgBgLAAgLgBIgJAAIgGAAIgFAAIgRAAYgvABgwgBgvACYgwADgwADgxADYgYADgZADgZADYgMABgMABgNACIgTACYgGABgGAAgGABYgXAEgYAEgXAEYgMACgMACgMACIgSADIgEABYgHABACAAgCAAIgJACYgZAFgZAGgYAFYgZAFgYAHgYAGYgxAMgxAOgxAOYgMADgMAEgMADYgLAEgMAEgMADYgYAIgYAHgZAIYguAOgvAPgvAOYgvAPguANgyANYgZAHgYAHgZAHIglAKIgFACYAFgCgGACAAAAIgJACIgSADYgYAGgYAFgYAFYgYAFgYADgYAEYgxAJgwADgwAGYgMACgNAAgNABIgnACIgoACIgKAAIgFABYgCAAAFAAgFAAIgSAAYgaAAgZAAgZgBYgZAAgbgBgZgBYgagBgagCgagBYgagBgbgCgagCYgagBgagCgbgCYgagCgbgCgbgCYgagCgbgCgbgDIgogDIgFAAYgCAAABAAgDAAIgKgBIgUgCYhsgLhsgLhsgLYhtgLhsgKhtgLYhtgMhugJhtgMYhugLhugNhugMYhugNhugJhugNYjbgZjcgUjdgPYjegPjcgCjagBYhugBhtADhtABYg2ACg2ABg2ACIgoABIgKABYgBAAgDAAgCAAIgFAAIgUACYgbABgbACgbACYg2ADg2ADg2ADYgbACgaACgaADYgaACgbACgaACYg1AFg0AFg0AEYgaACgbADgaACYgaADgZACgaACYgzAFgzAFgzAFYgZACgaACgZADYgZACgaACgZACYgzAEgyAEgzAEIgJAAYgBAAgEABACAAIgFAAIgSABIglABYgZACgYABgZABIgkACYgNAAgMABgMAAYgYABgZAAgYABYgYABgYABgYAAYgYAAgYAAgYAAYgvABgvABgwgBYgwgBgvAAgvgBYgvgBgugCgugBYgXgBgXAAgXgBYgWgBgXgBgXgCYgtgCgtgCgsgDYgsgDgrgEgrgDYhVgFhZgMhWgIYgKgBgKgBgKgBYgKgBgKgCgLgBYgUgDgVgDgUgCYgVgDgUgCgVgDYgUgDgUgDgUgEYhRgLhOgNhNgMYhOgOhMgNhKgMYhMgOhJgLhHgMYgkgGgjgGgjgFYgigFgigFgigFYghgEghgFgggEYgIgBgIgBgIgBYgFgBABAAgBAAIgEAAIgGgBIgMgBYgQgBgRgCgQgBYgggDgfgCgfgDYgggBgegBgegBYgPgBgPAAgOgBYgIAAgHAAgHgBYgIAAgHAAgHAAYgdABgcAAgcAAYgOAAgOAAgNAAYgOAAgMABgNABYgaABgYABgZACYgMABgMABgMABIgEAAYgBAAABAAgEAAIgCABIgJABYgGAAgGABgGABYgMABgMACgLABYgLACgLABgLACYgsAGgpAIglAHYgmAHgiAHgfAGYgIACgIABgIACYgHACgIABgHACYgOADgNADgNADYhlAag2AOAAAAYgDAAgCADABADYABACACACACAA");
	this.shape_1.setTransform(2100,22.8,1,1,0,0,0,0,-1.2);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

	// Ebene 1
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.lf(["#D5001C","rgba(213,0,28,0)","#D5001C","rgba(213,0,28,0)"],[0,0.275,0.667,1],-700,-1.2,700,-1.2).s().p("EhtWgC0YAAAAA4AABoAAYANAAAOAAAPgBYAHAAAHAAAIAAYAHAAAIAAAIAAYAgAAAjgBAlAAYAlABAoAAArACYAKABALAAALAAYALABAKABALABYAGAAAFABAGAAIAIABIACAAYgCAAADAAAAAAIAFABYALABAMACAMABYAYADAZADAaACYAMABANABANACYANACAMABANACYA0AHA1AHA4ALYAcAFAdAFAdAFYAdAGAeAGAeAGYAPADAQADAPADIALADIAGABIADAAYAAABAEAAgDAAYAIACAIACAIACYAgAHAgAIAhAIYAgAIAiAHAiAJYAhAIAiAIAjAJYBFAPBHASBIARYAmAIAlAJAmAJYAmAIAmAJAnAJYBPAQBSARBTAPYApAHAqAHArAHYAWADAVADAWADYALACALACALABYALACAMABALABYArAFArAFAsAFYArAGAuADAuADYAuAEAvAEAvACYAuACAvACAvACYAXAAAYABAYABYAYAAAXAAAYAAYAwAAAwAAAxAAIAKAAIAJAAIASgBYAMAAAMgBAMAAYAYgBAYgBAYAAYAvgCAzgDAygDYAZgCAZgBAZgCYAZgBAZgDAZgCYAZgDAZgCAZgCYANgBAMgCANgBYANgBAMgCANgBYAZgDAZgDAagDIAmgFIATgDIAFAAYAFgBgBAAACAAIAKgBYAxgIAygIAzgIYAZgEAZgEAagFYAZgEAZgFAagFYAzgJAzgJA0gKYBmgSBngTBngSYAagFAagEAagFYAagFAbgFAZgDYA0gIA0gHA0gGYAbgEAagEAagEIAUgCIAFgBYABAAAAAAADgBIAKgBIAogEYA1gGA2gGA1gGYA1gEA2gGA1gEYA2gFA2gCA2gDYBsgIBtgCBugEIAUAAYADAAAAAAACAAIAFAAIAKAAIApAAYAcAAAbAAAcAAYANAAAOAAAOAAIApABIBSADYDaAKDdATDYAcIClAVYA3AFA3AHA2AIYBtARBtAQBtASYDaAiDYAmDXAlYBrATBrATBqASIAUADIAKACYABAAAEABABAAIAFABIAoAGYAbAEAaAEAbAEYAbAEAaAEAbAEYAbADAbAEAaADYAbAEAbADAbAEYAbACAbADAbADYAbACAbADAbACYAcACAbABAcABIAUACYgBAAAIAAABAAIAFAAIAKAAIAngBIAoAAYANAAAMAAAPgBYA4gEA4gDA2gIYAbgDAbgDAagFYAbgFAagFAbgFIAUgEIAKgCYADAAgDABAIgCIAEgCIAmgJYAYgHAZgGAZgHYAxgMAygQAxgPYAxgPAxgQAxgPYAXgHAYgHAXgIIAjgLYAMgEAMgDALgEYAugNAugOAugMYAWgFAXgHAXgFYAXgGAWgFAXgFIAIgCYAAAAAGgBgEABIAEgBIASgDYAMgDALgCAMgCYAYgEAXgFAXgEYAGgBAGgBAFAAIARgBYALgBALgCALgBYAWgDAWgDAWgDYAtgEAtgDAsgEYAWgCAXAAAWgBYAWgBAWgBAWgBIARAAIAEAAYgDAAAEAAABAAIAIAAYAMAAALAAALAAYALAAAMAAALAAYAKABALAAAKABYApABArAEArADYAVACAVADAWACYAVACAVACAVADYBUAIBTAMBRANYAoAGAoAGAoAHYAoAHAoAHAnAHYBOANBNANBKANYAmAGAkAGAlAGYAJACAJABAJACIAPACIAOACYASADASACASACYAIABAJABAJACYAJABAKAAAJABYASACASACASABYASACASABASABYASABARABASAAYAJAAAJAAAJAAIANAAIAHAAIADAAYgBAAAGAAABAAYAQgCARgBAQgBYAQgBAQgBARgCYAQgDARgCAQgCYARgDAQgCAQgCYAQgCAPgEAPgDYAfgFAdgGAdgGYAdgHAcgHAcgHYANgDAOgDANgDIAKgDIAFgBIAEgBIACgBYAHgBAGgCAHgCYAzgOAxgOAvgNYAvgOAsgNApgNYAVgHAUgGATgHYATgHATgGASgHYBHgZA8gVAwgVYBhgnAzgVAAAAYADgBABgDgBgCYgBgCgDgCgCABIAAAAYAAAAg2AOhkAcYgZAGgcAIgfAHYgfAIghAIglAJYgSAFgTAFgTAFYgUAEgUAEgVAFYgqAJgsAKgvAKYgwAJgyAJg0AKYgHACgHABgGABIgDABYgBAAABAAgBAAIgFABIgKABYgOACgNACgOACYgbAEgcADgdAEYgcADgdAEgeAEYgPABgPADgOABYgPABgPABgPABYgPABgPABgPABYgPABgRAAgQAAYgQAAgRAAgQABYgCAAAEgBgDAAIgDAAIgGAAIgLgBYgIgBgIAAgIgBYgQAAgQgDgQgCYgRgCgQgBgRgDYgQgDgRgDgQgCYgJgCgIgBgJgCYgIgBgJgCgJAAYgRgDgSgDgSgEIgNgCYgDgBADABgCgBIgDgBIgHgBYgJgCgJgCgJgCYgkgIgkgIglgJYhKgQhLgRhOgRYgngJgngIgngJYgogJgpgIgpgJYhSgQhVgPhXgOYgVgEgWgDgWgDYgWgDgWgDgXgDYgtgFgtgFgwgDYgMgBgMgBgMgBYgLgBgLAAgMAAYgLgBgLAAgLgBIgJAAIgGAAIgFAAIgRAAYgvABgwgBgvACYgwADgwADgxADYgYADgZADgZADYgMABgMABgNACIgTACYgGABgGAAgGABYgXAEgYAEgXAEYgMACgMACgMACIgSADIgEABYgHABACAAgCAAIgJACYgZAFgZAGgYAFYgZAFgYAHgYAGYgxAMgxAOgxAOYgMADgMAEgMADYgLAEgMAEgMADYgYAIgYAHgZAIYguAOgvAPgvAOYgvAPguANgyANYgZAHgYAHgZAHIglAKIgFACYAFgCgGACAAAAIgJACIgSADYgYAGgYAFgYAFYgYAFgYADgYAEYgxAJgwADgwAGYgMACgNAAgNABIgnACIgoACIgKAAIgFABYgCAAAFAAgFAAIgSAAYgaAAgZAAgZgBYgZAAgbgBgZgBYgagBgagCgagBYgagBgbgCgagCYgagBgagCgbgCYgagCgbgCgbgCYgagCgbgCgbgDIgogDIgFAAYgCAAABAAgDAAIgKgBIgUgCYhsgLhsgLhsgLYhtgLhsgKhtgLYhtgMhugJhtgMYhugLhugNhugMYhugNhugJhugNYjbgZjcgUjdgPYjegPjcgCjagBYhugBhtADhtABYg2ACg2ABg2ACIgoABIgKABYgBAAgDAAgCAAIgFAAIgUACYgbABgbACgbACYg2ADg2ADg2ADYgbACgaACgaADYgaACgbACgaACYg1AFg0AFg0AEYgaACgbADgaACYgaADgZACgaACYgzAFgzAFgzAFYgZACgaACgZADYgZACgaACgZACYgzAEgyAEgzAEIgJAAYgBAAgEABACAAIgFAAIgSABIglABYgZACgYABgZABIgkACYgNAAgMABgMAAYgYABgZAAgYABYgYABgYABgYAAYgYAAgYAAgYAAYgvABgvABgwgBYgwgBgvAAgvgBYgvgBgugCgugBYgXgBgXAAgXgBYgWgBgXgBgXgCYgtgCgtgCgsgDYgsgDgrgEgrgDYhVgFhZgMhWgIYgKgBgKgBgKgBYgKgBgKgCgLgBYgUgDgVgDgUgCYgVgDgUgCgVgDYgUgDgUgDgUgEYhRgLhOgNhNgMYhOgOhMgNhKgMYhMgOhJgLhHgMYgkgGgjgGgjgFYgigFgigFgigFYghgEghgFgggEYgIgBgIgBgIgBYgFgBABAAgBAAIgEAAIgGgBIgMgBYgQgBgRgCgQgBYgggDgfgCgfgDYgggBgegBgegBYgPgBgPAAgOgBYgIAAgHAAgHgBYgIAAgHAAgHAAYgdABgcAAgcAAYgOAAgOAAgNAAYgOAAgMABgNABYgaABgYABgZACYgMABgMABgMABIgEAAYgBAAABAAgEAAIgCABIgJABYgGAAgGABgGABYgMABgMACgLABYgLACgLABgLACYgsAGgpAIglAHYgmAHgiAHgfAGYgIACgIABgIACYgHACgIABgHACYgOADgNADgNADYhlAag2AOAAAAYgDAAgCADABADYABACACACACAA");
	this.shape_2.setTransform(700,22.8,1,1,0,0,0,0,-1.2);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.4,-7.5,4200.8,63);


(lib.scrollerContent_text_sideBar03 = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// container_text
	this.instance = new lib.container_text("single",41);
	this.instance.setTransform(51.3,704.2,1,1,0,0,0,51.3,14.2);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// container_text
	this.instance_1 = new lib.container_text("single",40);
	this.instance_1.setTransform(51.3,14.2,1,1,0,0,0,51.3,14.2);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	// Ebene 1
	this.instance_2 = new lib.container_pics("single",17);
	this.instance_2.setTransform(556.1,951.5,1,1,0,0,0,556.1,351.5);

	this.instance_3 = new lib.pic_plane_white();
	this.instance_3.setTransform(170,405.6,0.294,1.531,0,0,0,579,265);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_3},{t:this.instance_2}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,340,811.3);


(lib.scrollerContent_text_sideBar02 = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// container_text
	this.instance = new lib.container_text("single",30);
	this.instance.setTransform(51.3,14.2,1,1,0,0,0,51.3,14.2);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,340,473);


(lib.scrollerContent_text_sideBar = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// container_text
	this.instance = new lib.container_text("single",1);
	this.instance.setTransform(51.3,14.2,1,1,0,0,0,51.3,14.2);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,340,449.6);


(lib.scroller_500 = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.slider = new lib.scroller_handle();

	this.bg = new lib.scroller_back_500();
	this.bg.setTransform(2,0);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.bg},{t:this.slider}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,9,500);


(lib.pics_table02 = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.instance = new lib.container_text("single",54);
	this.instance.setTransform(103.2,280);

	this.instance_1 = new lib.container_text("single",53);
	this.instance_1.setTransform(0,303.8,1,1,-90);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance,p:{x:103.2}}]}).to({state:[{t:this.instance,p:{x:210.1}}]},1).wait(1));

	// Ebene 8
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgPAzQgGgDgEgGQgFgHgBgKQgCgLAAgOQAAgOABgKQACgKAEgGQAEgHAHgDQAGgDAJAAQAJAAAHADQAHADAEAGQAEAHABAKQACAKAAAOQAAAOgCALQgBAKgFAHQgEAGgGADQgHADgJAAQgIAAgHgDgAgJgoQgFACgCAFQgDAFgBAIIgBAUIABAUQABAJADAFQACAGAEACQAFACAFAAQAGAAAFgCQAEgCACgGQADgFABgJIABgUIgBgUQgBgIgDgFQgDgFgEgCQgEgCgGAAQgFAAgEACg");
	this.shape.setTransform(85.4,49.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgdA1IAAgKQAAgGACgFQABgFADgDIAHgHIAIgHIAJgHIAHgDIAGgFIAEgHQABgEABgGQAAgKgGgEQgFgFgJAAQgEAAgDACQgEABgDACQgDADgBAFIgCALIgLAAQAAgIACgHQACgGAEgFQAEgEAFgCQAGgDAIAAQAQAAAIAIQAIAIAAAOQAAAHgCAFIgFAJIgHAFIgHAGIgLAHIgHAGIgGAGIgDAFIgBAHIAAACIAwAAIAAAKg");
	this.shape_1.setTransform(77.1,49.4);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AAIA0IAAhaIgbALIAAgLIAdgNIAKAAIAABng");
	this.shape_2.setTransform(68.4,49.5);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgPAzQgGgDgEgGQgFgHgBgKQgCgLAAgOQAAgOABgKQACgKAEgGQAEgHAHgDQAGgDAJAAQAJAAAHADQAHADAEAGQAEAHABAKQACAKAAAOQAAAOgCALQgBAKgFAHQgEAGgGADQgHADgJAAQgIAAgHgDgAgJgoQgFACgCAFQgDAFgBAIIgBAUIABAUQABAJADAFQACAGAEACQAFACAFAAQAGAAAFgCQAEgCACgGQADgFABgJIABgUIgBgUQgBgIgDgFQgDgFgEgCQgEgCgGAAQgFAAgEACg");
	this.shape_3.setTransform(85.4,83.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgPAzQgGgDgEgGQgFgHgBgKQgCgLAAgOQAAgOABgKQACgKAEgGQAEgHAHgDQAGgDAJAAQAJAAAHADQAHADAEAGQAEAHABAKQACAKAAAOQAAAOgCALQgBAKgFAHQgEAGgGADQgHADgJAAQgIAAgHgDgAgJgoQgFACgCAFQgDAFgBAIIgBAUIABAUQABAJADAFQACAGAEACQAFACAFAAQAGAAAFgCQAEgCACgGQADgFABgJIABgUIgBgUQgBgIgDgFQgDgFgEgCQgEgCgGAAQgFAAgEACg");
	this.shape_4.setTransform(77.1,83.4);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AAIA0IAAhaIgbALIAAgLIAdgNIAKAAIAABng");
	this.shape_5.setTransform(68.4,83.4);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgPAzQgGgDgEgGQgFgHgBgKQgCgLAAgOQAAgOABgKQACgKAEgGQAEgHAHgDQAGgDAJAAQAJAAAHADQAHADAEAGQAEAHABAKQACAKAAAOQAAAOgCALQgBAKgFAHQgEAGgGADQgHADgJAAQgIAAgHgDgAgJgoQgFACgCAFQgDAFgBAIIgBAUIABAUQABAJADAFQACAGAEACQAFACAFAAQAGAAAFgCQAEgCACgGQADgFABgJIABgUIgBgUQgBgIgDgFQgDgFgEgCQgEgCgGAAQgFAAgEACg");
	this.shape_6.setTransform(85.4,117.2);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AgYAuQgJgHAAgPQAAgJAEgHQAEgGAIgCQgGgCgEgGQgDgGAAgJQAAgOAHgIQAIgIAPAAQAQAAAIAIQAHAIAAAOQAAAJgDAGQgEAGgGACQAIACAEAGQAEAHAAAJQAAAPgJAHQgJAIgQAAQgPAAgJgIgAgPAJQgGAFAAAKQAAAKAGAFQAFAFAKAAQALAAAFgFQAGgFAAgKQAAgKgGgFQgFgFgLAAQgKAAgFAFgAgNglQgFAEAAAKQAAAJAEAFQAFAFAJAAQAKAAAFgFQAEgFAAgJQAAgKgFgEQgFgFgJAAQgIAAgFAFg");
	this.shape_7.setTransform(77.1,117.2);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AgPAzQgGgDgEgGQgFgHgBgKQgCgLAAgOQAAgOABgKQACgKAEgGQAEgHAHgDQAGgDAJAAQAJAAAHADQAHADAEAGQAEAHABAKQACAKAAAOQAAAOgCALQgBAKgFAHQgEAGgGADQgHADgJAAQgIAAgHgDgAgJgoQgFACgCAFQgDAFgBAIIgBAUIABAUQABAJADAFQACAGAEACQAFACAFAAQAGAAAFgCQAEgCACgGQADgFABgJIABgUIgBgUQgBgIgDgFQgDgFgEgCQgEgCgGAAQgFAAgEACg");
	this.shape_8.setTransform(85.4,151.1);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AgYAsQgJgIAAgSIABgJIACgIIADgFIAEgHIAZgpIANAAIgZApQAFgCAGAAQAQgBAJAJQAIAGAAARQAAASgJAIQgJAJgQAAQgPAAgJgJgAgQABQgEAGAAAMQAAAMAEAGQAFAGALAAQAMAAAFgGQAFgGAAgMQAAgMgFgGQgFgFgMABQgLgBgFAFg");
	this.shape_9.setTransform(77.1,151.2);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AgPAzQgGgDgEgGQgFgHgBgKQgCgLAAgOQAAgOABgKQACgKAEgGQAEgHAHgDQAGgDAJAAQAJAAAHADQAHADAEAGQAEAHABAKQACAKAAAOQAAAOgCALQgBAKgFAHQgEAGgGADQgHADgJAAQgIAAgHgDgAgJgoQgFACgCAFQgDAFgBAIIgBAUIABAUQABAJADAFQACAGAEACQAFACAFAAQAGAAAFgCQAEgCACgGQADgFABgJIABgUIgBgUQgBgIgDgFQgDgFgEgCQgEgCgGAAQgFAAgEACg");
	this.shape_10.setTransform(85.4,184.9);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AAKA0IAAgYIgtAAIAAgJIAnhGIARAAIAABEIAQAAIAAALIgQAAIAAAYgAgXARIAhAAIAAg5g");
	this.shape_11.setTransform(77.1,184.9);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AgPAzQgGgDgEgGQgFgHgBgKQgCgLAAgOQAAgOABgKQACgKAEgGQAEgHAHgDQAGgDAJAAQAJAAAHADQAHADAEAGQAEAHABAKQACAKAAAOQAAAOgCALQgBAKgFAHQgEAGgGADQgHADgJAAQgIAAgHgDgAgJgoQgFACgCAFQgDAFgBAIIgBAUIABAUQABAJADAFQACAGAEACQAFACAFAAQAGAAAFgCQAEgCACgGQADgFABgJIABgUIgBgUQgBgIgDgFQgDgFgEgCQgEgCgGAAQgFAAgEACg");
	this.shape_12.setTransform(85.4,218.7);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("AgdA1IAAgKQAAgGACgFQABgFADgDIAHgHIAIgHIAJgHIAHgDIAGgFIAEgHQABgEABgGQAAgKgGgEQgFgFgJAAQgEAAgDACQgEABgDACQgDADgBAFIgCALIgLAAQAAgIACgHQACgGAEgFQAEgEAFgCQAGgDAIAAQAQAAAIAIQAIAIAAAOQAAAHgCAFIgFAJIgHAFIgHAGIgLAHIgHAGIgGAGIgDAFIgBAHIAAACIAwAAIAAAKg");
	this.shape_13.setTransform(77.1,218.6);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AgPAzQgGgDgEgGQgFgHgBgKQgCgLAAgOQAAgOABgKQACgKAEgGQAEgHAHgDQAGgDAJAAQAJAAAHADQAHADAEAGQAEAHABAKQACAKAAAOQAAAOgCALQgBAKgFAHQgEAGgGADQgHADgJAAQgIAAgHgDgAgJgoQgFACgCAFQgDAFgBAIIgBAUIABAUQABAJADAFQACAGAEACQAFACAFAAQAGAAAFgCQAEgCACgGQADgFABgJIABgUIgBgUQgBgIgDgFQgDgFgEgCQgEgCgGAAQgFAAgEACg");
	this.shape_14.setTransform(103.2,267.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(2));

	// Ebene 9
	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("AgPAzQgGgDgEgGQgFgHgBgKQgCgLAAgOQAAgOABgKQACgKAEgGQAEgHAHgDQAGgDAJAAQAJAAAHADQAHADAEAGQAEAHABAKQACAKAAAOQAAAOgCALQgBAKgFAHQgEAGgGADQgHADgJAAQgIAAgHgDgAgJgoQgFACgCAFQgDAFgBAIIgBAUIABAUQABAJADAFQACAGAEACQAFACAFAAQAGAAAFgCQAEgCACgGQADgFABgJIABgUIgBgUQgBgIgDgFQgDgFgEgCQgEgCgGAAQgFAAgEACg");
	this.shape_15.setTransform(541.5,267.8);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("AgPAzQgGgDgEgGQgFgHgBgKQgCgLAAgOQAAgOABgKQACgKAEgGQAEgHAHgDQAGgDAJAAQAJAAAHADQAHADAEAGQAEAHABAKQACAKAAAOQAAAOgCALQgBAKgFAHQgEAGgGADQgHADgJAAQgIAAgHgDgAgJgoQgFACgCAFQgDAFgBAIIgBAUIABAUQABAJADAFQACAGAEACQAFACAFAAQAGAAAFgCQAEgCACgGQADgFABgJIABgUIgBgUQgBgIgDgFQgDgFgEgCQgEgCgGAAQgFAAgEACg");
	this.shape_16.setTransform(533.2,267.8);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AgdA1IAAgKQABgGABgFQACgFACgDIAGgHIAIgHIAKgHIAHgDIAGgFIAEgHQACgEAAgGQgBgKgEgEQgGgFgJAAQgDAAgFACQgEABgCACQgCADgCAFIgCALIgLAAQAAgIACgHQACgGAEgFQADgEAHgCQAGgDAHAAQAQAAAIAIQAIAIAAAOQAAAHgCAFIgFAJIgHAFIgHAGIgLAHIgHAGIgGAGIgDAFIgBAHIAAACIAwAAIAAAKg");
	this.shape_17.setTransform(525,267.7);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#000000").s().p("AAIA0IAAhaIgbALIAAgLIAdgNIAKAAIAABng");
	this.shape_18.setTransform(516.3,267.8);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#000000").s().p("AgPAzQgGgDgEgGQgFgHgBgKQgCgLAAgOQAAgOABgKQACgKAEgGQAEgHAHgDQAGgDAJAAQAJAAAHADQAHADAEAGQAEAHABAKQACAKAAAOQAAAOgCALQgBAKgFAHQgEAGgGADQgHADgJAAQgIAAgHgDgAgJgoQgFACgCAFQgDAFgBAIIgBAUIABAUQABAJADAFQACAGAEACQAFACAFAAQAGAAAFgCQAEgCACgGQADgFABgJIABgUIgBgUQgBgIgDgFQgDgFgEgCQgEgCgGAAQgFAAgEACg");
	this.shape_19.setTransform(470.3,267.8);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#000000").s().p("AgPAzQgGgDgEgGQgFgHgBgKQgCgLAAgOQAAgOABgKQACgKAEgGQAEgHAHgDQAGgDAJAAQAJAAAHADQAHADAEAGQAEAHABAKQACAKAAAOQAAAOgCALQgBAKgFAHQgEAGgGADQgHADgJAAQgIAAgHgDgAgJgoQgFACgCAFQgDAFgBAIIgBAUIABAUQABAJADAFQACAGAEACQAFACAFAAQAGAAAFgCQAEgCACgGQADgFABgJIABgUIgBgUQgBgIgDgFQgDgFgEgCQgEgCgGAAQgFAAgEACg");
	this.shape_20.setTransform(462.1,267.8);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#000000").s().p("AgPAzQgGgDgEgGQgFgHgBgKQgCgLAAgOQAAgOABgKQACgKAEgGQAEgHAHgDQAGgDAJAAQAJAAAHADQAHADAEAGQAEAHABAKQACAKAAAOQAAAOgCALQgBAKgFAHQgEAGgGADQgHADgJAAQgIAAgHgDgAgJgoQgFACgCAFQgDAFgBAIIgBAUIABAUQABAJADAFQACAGAEACQAFACAFAAQAGAAAFgCQAEgCACgGQADgFABgJIABgUIgBgUQgBgIgDgFQgDgFgEgCQgEgCgGAAQgFAAgEACg");
	this.shape_21.setTransform(453.9,267.8);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#000000").s().p("AAIA0IAAhaIgbALIAAgLIAdgNIAKAAIAABng");
	this.shape_22.setTransform(445.2,267.8);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#000000").s().p("AgPAzQgGgDgEgGQgFgHgBgKQgCgLAAgOQAAgOABgKQACgKAEgGQAEgHAHgDQAGgDAJAAQAJAAAHADQAHADAEAGQAEAHABAKQACAKAAAOQAAAOgCALQgBAKgFAHQgEAGgGADQgHADgJAAQgIAAgHgDgAgJgoQgFACgCAFQgDAFgBAIIgBAUIABAUQABAJADAFQACAGAEACQAFACAFAAQAGAAAFgCQAEgCACgGQADgFABgJIABgUIgBgUQgBgIgDgFQgDgFgEgCQgEgCgGAAQgFAAgEACg");
	this.shape_23.setTransform(395.3,267.8);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#000000").s().p("AgPAzQgGgDgEgGQgFgHgBgKQgCgLAAgOQAAgOABgKQACgKAEgGQAEgHAHgDQAGgDAJAAQAJAAAHADQAHADAEAGQAEAHABAKQACAKAAAOQAAAOgCALQgBAKgFAHQgEAGgGADQgHADgJAAQgIAAgHgDgAgJgoQgFACgCAFQgDAFgBAIIgBAUIABAUQABAJADAFQACAGAEACQAFACAFAAQAGAAAFgCQAEgCACgGQADgFABgJIABgUIgBgUQgBgIgDgFQgDgFgEgCQgEgCgGAAQgFAAgEACg");
	this.shape_24.setTransform(387,267.8);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#000000").s().p("AgYAuQgJgHAAgPQAAgJAEgHQAEgGAIgCQgGgCgEgGQgDgGAAgJQAAgOAHgIQAIgIAPAAQAQAAAIAIQAHAIAAAOQAAAJgDAGQgEAGgGACQAIACAEAGQAEAHAAAJQAAAPgJAHQgJAIgQAAQgPAAgJgIgAgPAJQgGAFAAAKQAAAKAGAFQAFAFAKAAQALAAAFgFQAGgFAAgKQAAgKgGgFQgFgFgLAAQgKAAgFAFgAgNglQgFAEAAAKQAAAJAEAFQAFAFAJAAQAKAAAFgFQAEgFAAgJQAAgKgFgEQgFgFgJAAQgIAAgFAFg");
	this.shape_25.setTransform(378.8,267.8);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#000000").s().p("AgPAzQgGgDgEgGQgFgHgBgKQgCgLAAgOQAAgOABgKQACgKAEgGQAEgHAHgDQAGgDAJAAQAJAAAHADQAHADAEAGQAEAHABAKQACAKAAAOQAAAOgCALQgBAKgFAHQgEAGgGADQgHADgJAAQgIAAgHgDgAgJgoQgFACgCAFQgDAFgBAIIgBAUIABAUQABAJADAFQACAGAEACQAFACAFAAQAGAAAFgCQAEgCACgGQADgFABgJIABgUIgBgUQgBgIgDgFQgDgFgEgCQgEgCgGAAQgFAAgEACg");
	this.shape_26.setTransform(324.3,267.8);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#000000").s().p("AgPAzQgGgDgEgGQgFgHgBgKQgCgLAAgOQAAgOABgKQACgKAEgGQAEgHAHgDQAGgDAJAAQAJAAAHADQAHADAEAGQAEAHABAKQACAKAAAOQAAAOgCALQgBAKgFAHQgEAGgGADQgHADgJAAQgIAAgHgDgAgJgoQgFACgCAFQgDAFgBAIIgBAUIABAUQABAJADAFQACAGAEACQAFACAFAAQAGAAAFgCQAEgCACgGQADgFABgJIABgUIgBgUQgBgIgDgFQgDgFgEgCQgEgCgGAAQgFAAgEACg");
	this.shape_27.setTransform(316.1,267.8);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#000000").s().p("AgYAsQgJgHAAgTIABgJIACgIIADgFIAEgHIAZgpIANAAIgZAqQAFgDAGgBQAQABAJAHQAIAHAAARQAAATgJAHQgJAJgQAAQgPAAgJgJgAgQAAQgEAHAAALQAAANAEAGQAFAGALAAQAMAAAFgGQAFgGAAgNQAAgLgFgHQgFgDgMAAQgLAAgFADg");
	this.shape_28.setTransform(307.8,267.9);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#000000").s().p("AgPAzQgGgDgEgGQgFgHgBgKQgCgLAAgOQAAgOABgKQACgKAEgGQAEgHAHgDQAGgDAJAAQAJAAAHADQAHADAEAGQAEAHABAKQACAKAAAOQAAAOgCALQgBAKgFAHQgEAGgGADQgHADgJAAQgIAAgHgDgAgJgoQgFACgCAFQgDAFgBAIIgBAUIABAUQABAJADAFQACAGAEACQAFACAFAAQAGAAAFgCQAEgCACgGQADgFABgJIABgUIgBgUQgBgIgDgFQgDgFgEgCQgEgCgGAAQgFAAgEACg");
	this.shape_29.setTransform(253.4,267.8);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#000000").s().p("AgPAzQgGgDgEgGQgFgHgBgKQgCgLAAgOQAAgOABgKQACgKAEgGQAEgHAHgDQAGgDAJAAQAJAAAHADQAHADAEAGQAEAHABAKQACAKAAAOQAAAOgCALQgBAKgFAHQgEAGgGADQgHADgJAAQgIAAgHgDgAgJgoQgFACgCAFQgDAFgBAIIgBAUIABAUQABAJADAFQACAGAEACQAFACAFAAQAGAAAFgCQAEgCACgGQADgFABgJIABgUIgBgUQgBgIgDgFQgDgFgEgCQgEgCgGAAQgFAAgEACg");
	this.shape_30.setTransform(245.1,267.8);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#000000").s().p("AAKA0IAAgYIgtAAIAAgKIAnhFIARAAIAABEIAQAAIAAALIgQAAIAAAYgAgXARIAhAAIAAg5g");
	this.shape_31.setTransform(236.9,267.8);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#000000").s().p("AgPAzQgGgDgEgGQgFgHgBgKQgCgLAAgOQAAgOABgKQACgKAEgGQAEgHAHgDQAGgDAJAAQAJAAAHADQAHADAEAGQAEAHABAKQACAKAAAOQAAAOgCALQgBAKgFAHQgEAGgGADQgHADgJAAQgIAAgHgDgAgJgoQgFACgCAFQgDAFgBAIIgBAUIABAUQABAJADAFQACAGAEACQAFACAFAAQAGAAAFgCQAEgCACgGQADgFABgJIABgUIgBgUQgBgIgDgFQgDgFgEgCQgEgCgGAAQgFAAgEACg");
	this.shape_32.setTransform(182.4,267.8);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#000000").s().p("AgPAzQgGgDgEgGQgFgHgBgKQgCgLAAgOQAAgOABgKQACgKAEgGQAEgHAHgDQAGgDAJAAQAJAAAHADQAHADAEAGQAEAHABAKQACAKAAAOQAAAOgCALQgBAKgFAHQgEAGgGADQgHADgJAAQgIAAgHgDgAgJgoQgFACgCAFQgDAFgBAIIgBAUIABAUQABAJADAFQACAGAEACQAFACAFAAQAGAAAFgCQAEgCACgGQADgFABgJIABgUIgBgUQgBgIgDgFQgDgFgEgCQgEgCgGAAQgFAAgEACg");
	this.shape_33.setTransform(174.2,267.8);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#000000").s().p("AgdA1IAAgKQABgGABgFQACgFACgDIAGgHIAIgHIAKgHIAHgDIAGgFIAEgHQACgEAAgGQgBgKgFgEQgFgFgJAAQgDAAgFACQgEABgCACQgCADgCAFIgCALIgLAAQAAgIACgHQACgGAEgFQADgEAHgCQAGgDAHAAQAQAAAIAIQAIAIAAAOQAAAHgCAFIgFAJIgHAFIgHAGIgLAHIgHAGIgGAGIgDAFIgBAHIAAACIAwAAIAAAKg");
	this.shape_34.setTransform(165.9,267.7);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#000000").s().p("AAKA0IAAgYIguAAIAAgKIAphFIARAAIAABEIAOAAIAAALIgOAAIAAAYgAgXARIAhAAIAAg5g");
	this.shape_35.setTransform(596.1,267.8);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#000000").s().p("AAIA0IAAhaIgbALIAAgLIAdgNIAKAAIAABng");
	this.shape_36.setTransform(729.6,267.8);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#000000").s().p("AgdA1IAAgKQABgGABgFQACgFACgDIAGgHIAIgHIAKgHIAHgDIAGgFIAEgHQACgEAAgGQgBgKgFgEQgFgFgJAAQgDAAgFACQgEABgCACQgCADgCAFIgCALIgLAAQAAgIACgHQABgGAFgFQADgEAHgCQAGgDAHAAQAQAAAIAIQAIAIAAAOQAAAHgCAFIgFAJIgHAFIgHAGIgLAHIgHAGIgGAGIgDAFIgBAHIAAACIAwAAIAAAKg");
	this.shape_37.setTransform(525.1,267.7);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#000000").s().p("AAIA0IAAhaIgbALIAAgLIAdgNIAKAAIAABng");
	this.shape_38.setTransform(516.4,267.8);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#000000").s().p("AAIA0IAAhaIgbALIAAgLIAdgNIAKAAIAABng");
	this.shape_39.setTransform(445.4,267.8);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#000000").s().p("AgYAuQgJgHAAgPQAAgJAEgHQAEgGAIgCQgGgCgEgGQgDgGAAgJQAAgOAHgIQAIgIAPAAQAQAAAIAIQAHAIAAAOQAAAJgDAGQgEAGgGACQAIACAEAGQAEAHAAAJQAAAPgJAHQgJAIgQAAQgPAAgJgIgAgPAJQgGAFAAAKQAAAKAGAFQAFAFAKAAQALAAAFgFQAGgFAAgKQAAgKgGgFQgFgFgLAAQgKAAgFAFgAgNglQgFAEAAAKQAAAJAEAFQAFAFAJAAQAKAAAFgFQAEgFAAgJQAAgKgFgEQgFgFgJAAQgIAAgFAFg");
	this.shape_40.setTransform(379,267.8);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#000000").s().p("AgPAzQgGgDgEgGQgFgHgBgKQgCgLAAgOQAAgOABgKQACgKAEgGQAEgHAHgDQAGgDAJAAQAJAAAHADQAHADAEAGQAEAHABAKQACAKAAAOQAAAOgCALQgBAKgFAHQgEAGgGADQgHADgJAAQgIAAgHgDgAgJgoQgFACgCAFQgDAFgBAIIgBAUIABAUQABAJADAFQACAGAEACQAFACAFAAQAGAAAFgCQAEgCACgGQADgFABgJIABgUIgBgUQgBgIgDgFQgDgFgEgCQgEgCgGAAQgFAAgEACg");
	this.shape_41.setTransform(324.5,267.8);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#000000").s().p("AgPAzQgGgDgEgGQgFgHgBgKQgCgLAAgOQAAgOABgKQACgKAEgGQAEgHAHgDQAGgDAJAAQAJAAAHADQAHADAEAGQAEAHABAKQACAKAAAOQAAAOgCALQgBAKgFAHQgEAGgGADQgHADgJAAQgIAAgHgDgAgJgoQgFACgCAFQgDAFgBAIIgBAUIABAUQABAJADAFQACAGAEACQAFACAFAAQAGAAAFgCQAEgCACgGQADgFABgJIABgUIgBgUQgBgIgDgFQgDgFgEgCQgEgCgGAAQgFAAgEACg");
	this.shape_42.setTransform(316.2,267.8);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#000000").s().p("AgYAsQgJgHAAgTIABgJIACgIIADgFIAEgHIAZgpIANAAIgZAqQAFgDAGgBQAQABAJAHQAIAHAAARQAAATgJAHQgJAJgQAAQgPAAgJgJgAgQAAQgEAHAAALQAAANAEAGQAFAGALAAQAMAAAFgGQAFgGAAgNQAAgLgFgHQgFgDgMAAQgLAAgFADg");
	this.shape_43.setTransform(308,267.9);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#000000").s().p("AgPAzQgGgDgEgGQgFgHgBgKQgCgLAAgOQAAgOABgKQACgKAEgGQAEgHAHgDQAGgDAJAAQAJAAAHADQAHADAEAGQAEAHABAKQACAKAAAOQAAAOgCALQgBAKgFAHQgEAGgGADQgHADgJAAQgIAAgHgDgAgJgoQgFACgCAFQgDAFgBAIIgBAUIABAUQABAJADAFQACAGAEACQAFACAFAAQAGAAAFgCQAEgCACgGQADgFABgJIABgUIgBgUQgBgIgDgFQgDgFgEgCQgEgCgGAAQgFAAgEACg");
	this.shape_44.setTransform(253.5,267.8);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#000000").s().p("AgPAzQgGgDgEgGQgFgHgBgKQgCgLAAgOQAAgOABgKQACgKAEgGQAEgHAHgDQAGgDAJAAQAJAAAHADQAHADAEAGQAEAHABAKQACAKAAAOQAAAOgCALQgBAKgFAHQgEAGgGADQgHADgJAAQgIAAgHgDgAgJgoQgFACgCAFQgDAFgBAIIgBAUIABAUQABAJADAFQACAGAEACQAFACAFAAQAGAAAFgCQAEgCACgGQADgFABgJIABgUIgBgUQgBgIgDgFQgDgFgEgCQgEgCgGAAQgFAAgEACg");
	this.shape_45.setTransform(245.2,267.8);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#000000").s().p("AgPAzQgGgDgEgGQgFgHgBgKQgCgLAAgOQAAgOABgKQACgKAEgGQAEgHAHgDQAGgDAJAAQAJAAAHADQAHADAEAGQAEAHABAKQACAKAAAOQAAAOgCALQgBAKgFAHQgEAGgGADQgHADgJAAQgIAAgHgDgAgJgoQgFACgCAFQgDAFgBAIIgBAUIABAUQABAJADAFQACAGAEACQAFACAFAAQAGAAAFgCQAEgCACgGQADgFABgJIABgUIgBgUQgBgIgDgFQgDgFgEgCQgEgCgGAAQgFAAgEACg");
	this.shape_46.setTransform(182.5,267.8);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#000000").s().p("AgPAzQgGgDgEgGQgFgHgBgKQgCgLAAgOQAAgOABgKQACgKAEgGQAEgHAHgDQAGgDAJAAQAJAAAHADQAHADAEAGQAEAHABAKQACAKAAAOQAAAOgCALQgBAKgFAHQgEAGgGADQgHADgJAAQgIAAgHgDgAgJgoQgFACgCAFQgDAFgBAIIgBAUIABAUQABAJADAFQACAGAEACQAFACAFAAQAGAAAFgCQAEgCACgGQADgFABgJIABgUIgBgUQgBgIgDgFQgDgFgEgCQgEgCgGAAQgFAAgEACg");
	this.shape_47.setTransform(174.2,267.8);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#000000").s().p("AgcA1IAAgKQAAgGABgFQABgFADgDIAHgHIAIgHIAJgHIAHgDIAGgFIAEgHQACgEgBgGQAAgKgEgEQgGgFgJAAQgDAAgEACQgEABgDACQgDADgBAFIgCALIgLAAQAAgIACgHQACgGADgFQAEgEAGgCQAHgDAHAAQAQAAAIAIQAIAIAAAOQAAAHgCAFIgFAJIgHAFIgIAGIgKAHIgHAGIgGAGIgDAFIgBAHIAAACIAwAAIAAAKg");
	this.shape_48.setTransform(166,267.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_34},{t:this.shape_33,p:{x:174.2}},{t:this.shape_32,p:{x:182.4}},{t:this.shape_31,p:{x:236.9}},{t:this.shape_30,p:{x:245.1}},{t:this.shape_29,p:{x:253.4}},{t:this.shape_28,p:{x:307.8}},{t:this.shape_27,p:{x:316.1}},{t:this.shape_26,p:{x:324.3}},{t:this.shape_25,p:{x:378.8}},{t:this.shape_24,p:{x:387}},{t:this.shape_23,p:{x:395.3}},{t:this.shape_22,p:{x:445.2}},{t:this.shape_21,p:{x:453.9}},{t:this.shape_20,p:{x:462.1}},{t:this.shape_19,p:{x:470.3}},{t:this.shape_18,p:{x:516.3}},{t:this.shape_17},{t:this.shape_16,p:{x:533.2}},{t:this.shape_15,p:{x:541.5}}]}).to({state:[{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_31,p:{x:237}},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_33,p:{x:387.2}},{t:this.shape_32,p:{x:395.5}},{t:this.shape_39},{t:this.shape_30,p:{x:454.1}},{t:this.shape_29,p:{x:462.4}},{t:this.shape_27,p:{x:470.6}},{t:this.shape_38},{t:this.shape_37},{t:this.shape_26,p:{x:533.3}},{t:this.shape_24,p:{x:541.6}},{t:this.shape_36},{t:this.shape_25,p:{x:738.3}},{t:this.shape_23,p:{x:746.5}},{t:this.shape_21,p:{x:754.8}},{t:this.shape_22,p:{x:587.4}},{t:this.shape_35},{t:this.shape_20,p:{x:604.3}},{t:this.shape_19,p:{x:612.6}},{t:this.shape_18,p:{x:658.4}},{t:this.shape_28,p:{x:667.1}},{t:this.shape_16,p:{x:675.3}},{t:this.shape_15,p:{x:683.6}}]},1).wait(1));

	// Ebene 2
	this.instance_2 = new lib.container_text("single",45);
	this.instance_2.setTransform(689.6,188.8,1,1,0,0,0,585,188.8);

	this.instance_3 = new lib.container_text("single",46);
	this.instance_3.setTransform(971.1,188.8,1,1,0,0,0,585,188.8);

	this.instance_4 = new lib.container_text("single",48);
	this.instance_4.setTransform(855.9,188.8,1,1,0,0,0,585,188.8);

	this.instance_5 = new lib.container_text("single",47);
	this.instance_5.setTransform(696.1,188.8,1,1,0,0,0,585,188.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_3,p:{x:971.1,startPosition:46}},{t:this.instance_2,p:{x:689.6,startPosition:45}}]}).to({state:[{t:this.instance_5},{t:this.instance_4},{t:this.instance_3,p:{x:1015.7,startPosition:49}},{t:this.instance_2,p:{x:1175.5,startPosition:50}}]},1).wait(1));

	// frame
	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f().s("#B5B3B9").ss(1,1,0,3).p("EAhRgThMAAAAnDMhChAAAMAAAgnD");
	this.shape_49.setTransform(316.1,128.8);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f().s("#B5B3B9").ss(1,1,0,3).p("EAx7gThMAAAAnDMhj2AAAMAAAgnD");
	this.shape_50.setTransform(422.8,128.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_49}]}).to({state:[{t:this.shape_50}]},1).wait(1));

	// curve
	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f().s("#D5001C").ss(1,0,1).p("EghQAP+IAUAAIATjmIAjAAIAUDmIBSAAIAroGIBIAAIArIGIBaAAIBFtDIBDAAIAVEDIA4AAIAwJAIA3AAIATjmIAjAAIATDmIBTAAIAqoGIBJAAIArIGIBaAAIBFtDIBDAAIAVEDIA4AAIAwJAIA2AAIATjmIAkAAIATDmIBSAAIAroGIBJAAIArIGIBZAAIBGtDIBCAAIAWEDIA4AAIAwJAIA0AAIATjmIAjAAIAUDmIBGAAIAroGIBIAAIAqIGIBVAAIBFtDIBDAAIAVEDIA5AAIAvJAIBUAAIBiycIDvAAIAcFSID8AAIAdlSIDEAAICAoIIBwAAIBFlXIAnAAICAf7IAfAA");
	this.shape_51.setTransform(316.1,150.2);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f().s("#D5001C").ss(1.5,1,1).p("EgxqARsIAnAAIADgDIAcnXIAPgcIAYjnIAKghIAEgBIAEAEIAgGSIADAKIAHAiIALARIAKBcIAEACIAHAAIAHgLIADgkIAZhAIAZknIAOhCIADgDIAcBVIAFAGIAUGAIASDOICGAAIAEgDIASlDIAVixIAEgMIADAIIAOEWIAEAXIADgLIAPi6IARiWIAEgTIAHhGIADgOIADALIAPDRIAEADIAJhGIAFgHIAKAWIAZDuIASAsIAKAAIAIgSIAKg9IAZlCIAmkuIAcg9IAEgFIAIAFIANBvIALAzIAjG/IAEAKIALAsIAGAHIAHAyIAEgQIAqoOIADgCIAIAMIATD5IAGClIADAUIAgn1IAEgKIAOA0IADABIALgKIALAMIARBlIAPAaIAfDjIAcAxIAHBjIAaA4IAGgUIALiWIAdhFIANAEIALgFIAEADIANBpIALAVIAHgJIAHgnIAIgRIADALIAWECIAcCZIARAAIAEgIIAcmyIAHAMIAVCnIAIAXIANgRIALhCIAEgHIADAFIAHAnIAEAHIAHgRIANj5IAFgfIADgBIAKAlIAHANIALCCIASF3IAHAWIDpAAIADgIIAWlyIALAcIAZE8IAGAiIAHAAIAIgVIAYmRIALAPIAVCNIASAoIANgYIAFgjIADgIIAHAAIAOElIB1AAIAHgjIAfrBIAIhdIADgHIASAdIAHAlIADAIIASgcIAHAAIADgCIAIgbIAOhUIADgHIAIACIADADIAHgIIAHgjIARgeIAEACIADAOIAhGvIANE1IAEAUIAEgKIARlQIAOiKIAHgIIAFAZIANEYIAHBDIAEAAIARjEIAIgOIAKgkIADAOIAPC2IAHAOIAIABIANCMIADAPIAEgVIAIiJIADgMIADAKIALCgIAHgSIAHhgIALheIAUkvIAhgsIAKg2IAPgFIAOgnIAHACIADAGIAKA0IAdJRIAEgPIAYnUIAclsIAZhIIASgLIADAEIAVGSIAEAQIADACIAEgPIAOi2IADgFIAEAIIALBYIAZH7IADASIAEgSIAqoAIAWg3IAVhhIANgVIAWhaIAEgGIAHgEIAYiVIAHgTIALg4IARAfIAPBNIAGAGIAIAjIAHAAIAPgNIAGALIASBdIAHAMIAGACIAKAkIANEsIADAQIAFACIADgPIALigIARiGIAEAEIAHgKIAOhgIAHApIAdBHIAHAiIAOAnIAOAIIASgoIADADIAHA6IAVHcIADgPIAPlOIAKh1IAEgCIAEACIADAHIAHArIAcJuIAVDRIAFASICNAAIADgNIAZoWIAflcIASgZIAHASIALBkIAgJUIAGgPIALi2IAHggIAMhyIANkuIASjlIADgHIADAJIAIA3IAEAMIASgEIADgEIAOhQIADgDIAFAGIAJBQIAEAIIADgHIAMhXIADgLIADABIAHAqIAEAOIAEgCIANiJIAEgGIAEAHIAKA2IAHAUIAHBPIAnL4IAIAkIAJgPIAPihIAEgHIAODeIAHAAIAjpyIAtlxIAZhmIAriGIAIgOIAYhCIAyhYIANgOIBVg8IAZACIA0AwIAPAEIAHAGIAxCfIAhBcIAjA6IAHAAIAmAvIAIgMIARhtIAIgMIANAAIAWAVIAIAAIAGgEIAOgZIAEgCIAHADIAuFtIADAGIALgwIAEgCIADAOIAHA8IADALIAIAAIAHAbIAYHzIAKiOIAIgjIARkHIAIgkIAHAEIAVB9IASFWIADAMIAHgKIALANIAEgBIARj0IAEgOIADAOIAHBhIADARIAFgEIAKh9IADgMIAEAKIAIBcIAJETIAEAaIALgyIAEgBIADANIAGA1IAEAEIAIgJIADAMIANEfIAFAVIBcAAIANiIIALg+IA1qiIAjhzIAdj8IAKghIAEgEIAIAHIAVDFIAHAiIADADIADgHIALhaIARkWIAPiNIAPgjIAUhPIBDnLIAEgHIAHAAIASAkIAcByIAVAjIAZBkIAKAPIAIAAIAKgKIAPgtIANhRIALgqIAEgDIAGAJIAZCuIADAFIAIACIARAeIAFADIAGgLIAyj/IAchkIARgcIALgFIAHAAIAWAWIA4gzIAqAgIAPgLIAcg/IAHgFIALAaIA4JKIAVBhIA9CqIANCMIAuKhIAfFpIALDTIASAA");
	this.shape_52.setTransform(423,140.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_51}]}).to({state:[{t:this.shape_52}]},1).wait(1));

	// vertical
	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#B5B3B9").s().p("AgESXQgCgCAAgEIAAg7QAAgEACgCQACgCACAAQADAAACACQACACAAAEIAAA7QAAAEgCACQgCACgDAAQgCAAgCgCgAgEQfQgCgCAAgEIAAg8QAAgDACgCQACgCACAAQADAAACACQACACAAADIAAA8QAAAEgCACQgCACgDAAQgCAAgCgCgAgEOnQgCgCAAgDIAAg9QAAgDACgCQACgCACAAQADAAACACQACACAAADIAAA9QAAADgCACQgCACgDAAQgCAAgCgCgAgEMvQgCgCAAgEIAAg7QAAgEACgCQACgCACAAQADAAACACQACACAAAEIAAA7QAAAEgCACQgCACgDAAQgCAAgCgCgAgEK3QgCgCAAgEIAAg8QAAgDACgCQACgCACAAQADAAACACQACACAAADIAAA8QAAAEgCACQgCACgDAAQgCAAgCgCgAgEI/QgCgCAAgDIAAg9QAAgDACgCQACgCACAAQADAAACACQACACAAADIAAA9QAAADgCACQgCACgDAAQgCAAgCgCgAgEHHQgCgCAAgEIAAg7QAAgEACgCQACgCACAAQADAAACACQACACAAAEIAAA7QAAAEgCACQgCACgDAAQgCAAgCgCgAgEFPQgCgCAAgEIAAg8QAAgDACgCQACgCACAAQADAAACACQACACAAADIAAA8QAAAEgCACQgCACgDAAQgCAAgCgCgAgEDXQgCgCAAgDIAAg9QAAgDACgCQACgCACAAQADAAACACQACACAAADIAAA9QAAADgCACQgCACgDAAQgCAAgCgCgAgEBfQgCgCAAgEIAAg7QAAgEACgCQACgCACAAQADAAACACQACACAAAEIAAA7QAAAEgCACQgCACgDAAQgCAAgCgCgAgEgXQgCgCAAgEIAAg8QAAgDACgCQACgCACAAQADAAACACQACACAAADIAAA8QAAAEgCACQgCACgDAAQgCAAgCgCgAgEiPQgCgCAAgDIAAg8QAAgEACgCQACgCACAAQADAAACACQACACAAAEIAAA8QAAADgCACQgCACgDAAQgCAAgCgCgAgEkHQgCgCAAgEIAAg7QAAgEACgCQACgCACAAQADAAACACQACACAAAEIAAA7QAAAEgCACQgCACgDAAQgCAAgCgCgAgEl/QgCgCAAgDIAAg9QAAgDACgCQACgCACAAQADAAACACQACACAAADIAAA9QAAADgCACQgCACgDAAQgCAAgCgCgAgEn3QgCgCAAgDIAAg8QAAgEACgCQACgCACAAQADAAACACQACACAAAEIAAA8QAAADgCACQgCACgDAAQgCAAgCgCgAgEpvQgCgCAAgEIAAg7QAAgEACgCQACgCACAAQADAAACACQACACAAAEIAAA7QAAAEgCACQgCACgDAAQgCAAgCgCgAgErnQgCgCAAgEIAAg8QAAgDACgCQACgCACAAQADAAACACQACACAAADIAAA8QAAAEgCACQgCACgDAAQgCAAgCgCgAgEtfQgCgCAAgDIAAg9QAAgDACgCQACgCACAAQADAAACACQACACAAADIAAA9QAAADgCACQgCACgDAAQgCAAgCgCgAgEvXQgCgCAAgEIAAg7QAAgEACgCQACgCACAAQADAAACACQACACAAAEIAAA7QAAAEgCACQgCACgDAAQgCAAgCgCgAgExPQgCgCAAgEIAAg8QAAgDACgCQACgCACAAQADAAACACQACACAAADIAAA8QAAAEgCACQgCACgDAAQgCAAgCgCg");
	this.shape_53.setTransform(386.1,134.4);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#B5B3B9").s().p("AY4R/QgCgCAAgDIAAgNQAAgDACgDQACgCADAAQAEAAACACQACADAAADIAAANQAAADgCACQgCADgEAAQgDAAgCgDgAgER/QgCgCAAgDIAAgNQAAgDACgDQACgCACAAQADAAACACQACADAAADIAAANQAAADgCACQgCADgDAAQgCAAgCgDgA5CR/QgCgCAAgDIAAgNQAAgDACgDQACgCADAAQAEAAACACQACADAAADIAAANQAAADgCACQgCADgEAAQgDAAgCgDgAY4Q2QgCgCAAgDIAAg8QAAgDACgDQACgCADAAQAEAAACACQACADAAADIAAA8QAAADgCACQgCACgEAAQgDAAgCgCgAgEQ2QgCgCAAgDIAAg8QAAgDACgDQACgCACAAQADAAACACQACADAAADIAAA8QAAADgCACQgCACgDAAQgCAAgCgCgA5CQ2QgCgCAAgDIAAg8QAAgDACgDQACgCADAAQAEAAACACQACADAAADIAAA8QAAADgCACQgCACgEAAQgDAAgCgCgAY4O+QgCgCAAgDIAAg8QAAgDACgCQACgDADAAQAEAAACADQACACAAADIAAA8QAAADgCACQgCACgEAAQgDAAgCgCgAgEO+QgCgCAAgDIAAg8QAAgDACgCQACgDACAAQADAAACADQACACAAADIAAA8QAAADgCACQgCACgDAAQgCAAgCgCgA5CO+QgCgCAAgDIAAg8QAAgDACgCQACgDADAAQAEAAACADQACACAAADIAAA8QAAADgCACQgCACgEAAQgDAAgCgCgAY4NGQgCgCAAgDIAAg8QAAgDACgDQACgCADAAQAEAAACACQACADAAADIAAA8QAAADgCACQgCACgEAAQgDAAgCgCgAgENGQgCgCAAgDIAAg8QAAgDACgDQACgCACAAQADAAACACQACADAAADIAAA8QAAADgCACQgCACgDAAQgCAAgCgCgA5CNGQgCgCAAgDIAAg8QAAgDACgDQACgCADAAQAEAAACACQACADAAADIAAA8QAAADgCACQgCACgEAAQgDAAgCgCgAY4LOQgCgCAAgDIAAg8QAAgDACgDQACgCADAAQAEAAACACQACADAAADIAAA8QAAADgCACQgCACgEAAQgDAAgCgCgAgELOQgCgCAAgDIAAg8QAAgDACgDQACgCACAAQADAAACACQACADAAADIAAA8QAAADgCACQgCACgDAAQgCAAgCgCgA5CLOQgCgCAAgDIAAg8QAAgDACgDQACgCADAAQAEAAACACQACADAAADIAAA8QAAADgCACQgCACgEAAQgDAAgCgCgAY4JWQgCgCAAgDIAAg8QAAgDACgCQACgDADAAQAEAAACADQACACAAADIAAA8QAAADgCACQgCACgEAAQgDAAgCgCgAgEJWQgCgCAAgDIAAg8QAAgDACgCQACgDACAAQADAAACADQACACAAADIAAA8QAAADgCACQgCACgDAAQgCAAgCgCgA5CJWQgCgCAAgDIAAg8QAAgDACgCQACgDADAAQAEAAACADQACACAAADIAAA8QAAADgCACQgCACgEAAQgDAAgCgCgAY4HeQgCgCAAgDIAAg8QAAgDACgDQACgCADAAQAEAAACACQACADAAADIAAA8QAAADgCACQgCACgEAAQgDAAgCgCgAgEHeQgCgCAAgDIAAg8QAAgDACgDQACgCACAAQADAAACACQACADAAADIAAA8QAAADgCACQgCACgDAAQgCAAgCgCgA5CHeQgCgCAAgDIAAg8QAAgDACgDQACgCADAAQAEAAACACQACADAAADIAAA8QAAADgCACQgCACgEAAQgDAAgCgCgAY4FmQgCgCAAgDIAAg8QAAgDACgDQACgCADAAQAEAAACACQACADAAADIAAA8QAAADgCACQgCACgEAAQgDAAgCgCgAgEFmQgCgCAAgDIAAg8QAAgDACgDQACgCACAAQADAAACACQACADAAADIAAA8QAAADgCACQgCACgDAAQgCAAgCgCgA5CFmQgCgCAAgDIAAg8QAAgDACgDQACgCADAAQAEAAACACQACADAAADIAAA8QAAADgCACQgCACgEAAQgDAAgCgCgAY4DuQgCgCAAgDIAAg8QAAgDACgCQACgDADAAQAEAAACADQACACAAADIAAA8QAAADgCACQgCACgEAAQgDAAgCgCgAgEDuQgCgCAAgDIAAg8QAAgDACgCQACgDACAAQADAAACADQACACAAADIAAA8QAAADgCACQgCACgDAAQgCAAgCgCgA5CDuQgCgCAAgDIAAg8QAAgDACgCQACgDADAAQAEAAACADQACACAAADIAAA8QAAADgCACQgCACgEAAQgDAAgCgCgAY4B2QgCgCAAgDIAAg8QAAgDACgDQACgCADAAQAEAAACACQACADAAADIAAA8QAAADgCACQgCACgEAAQgDAAgCgCgAgEB2QgCgCAAgDIAAg8QAAgDACgDQACgCACAAQADAAACACQACADAAADIAAA8QAAADgCACQgCACgDAAQgCAAgCgCgA5CB2QgCgCAAgDIAAg8QAAgDACgDQACgCADAAQAEAAACACQACADAAADIAAA8QAAADgCACQgCACgEAAQgDAAgCgCgAY4AAQgCgCAAgDIAAg8QAAgDACgDQACgCADAAQAEAAACACQACADAAADIAAA8QAAADgCACQgCAAgEAAQgDAAgCAAgAgEAAQgCgCAAgDIAAg8QAAgDACgDQACgCACAAQADAAACACQACADAAADIAAA8QAAADgCACQgCAAgDAAQgCAAgCAAgA5CAAQgCgCAAgDIAAg8QAAgDACgDQACgCADAAQAEAAACACQACADAAADIAAA8QAAADgCACQgCAAgEAAQgDAAgCAAgAY4h4QgCgCAAgDIAAg8QAAgDACgCQACgDADAAQAEAAACADQACACAAADIAAA8QAAADgCACQgCACgEAAQgDAAgCgCgAgEh4QgCgCAAgDIAAg8QAAgDACgCQACgDACAAQADAAACADQACACAAADIAAA8QAAADgCACQgCACgDAAQgCAAgCgCgA5Ch4QgCgCAAgDIAAg8QAAgDACgCQACgDADAAQAEAAACADQACACAAADIAAA8QAAADgCACQgCACgEAAQgDAAgCgCgAY4jwQgCgCAAgDIAAg8QAAgDACgDQACgCADAAQAEAAACACQACADAAADIAAA8QAAADgCACQgCACgEAAQgDAAgCgCgAgEjwQgCgCAAgDIAAg8QAAgDACgDQACgCACAAQADAAACACQACADAAADIAAA8QAAADgCACQgCACgDAAQgCAAgCgCgA5CjwQgCgCAAgDIAAg8QAAgDACgDQACgCADAAQAEAAACACQACADAAADIAAA8QAAADgCACQgCACgEAAQgDAAgCgCgAY4loQgCgCAAgDIAAg8QAAgDACgDQACgCADAAQAEAAACACQACADAAADIAAA8QAAADgCACQgCACgEAAQgDAAgCgCgAgEloQgCgCAAgDIAAg8QAAgDACgDQACgCACAAQADAAACACQACADAAADIAAA8QAAADgCACQgCACgDAAQgCAAgCgCgA5CloQgCgCAAgDIAAg8QAAgDACgDQACgCADAAQAEAAACACQACADAAADIAAA8QAAADgCACQgCACgEAAQgDAAgCgCgAY4ngQgCgCAAgDIAAg8QAAgDACgCQACgDADAAQAEAAACADQACACAAADIAAA8QAAADgCACQgCACgEAAQgDAAgCgCgAgEngQgCgCAAgDIAAg8QAAgDACgCQACgDACAAQADAAACADQACACAAADIAAA8QAAADgCACQgCACgDAAQgCAAgCgCgA5CngQgCgCAAgDIAAg8QAAgDACgCQACgDADAAQAEAAACADQACACAAADIAAA8QAAADgCACQgCACgEAAQgDAAgCgCgAY4pYQgCgCAAgDIAAg8QAAgDACgDQACgCADAAQAEAAACACQACADAAADIAAA8QAAADgCACQgCACgEAAQgDAAgCgCgAgEpYQgCgCAAgDIAAg8QAAgDACgDQACgCACAAQADAAACACQACADAAADIAAA8QAAADgCACQgCACgDAAQgCAAgCgCgA5CpYQgCgCAAgDIAAg8QAAgDACgDQACgCADAAQAEAAACACQACADAAADIAAA8QAAADgCACQgCACgEAAQgDAAgCgCgAY4rQQgCgCAAgDIAAg8QAAgDACgDQACgCADAAQAEAAACACQACADAAADIAAA8QAAADgCACQgCACgEAAQgDAAgCgCgAgErQQgCgCAAgDIAAg8QAAgDACgDQACgCACAAQADAAACACQACADAAADIAAA8QAAADgCACQgCACgDAAQgCAAgCgCgA5CrQQgCgCAAgDIAAg8QAAgDACgDQACgCADAAQAEAAACACQACADAAADIAAA8QAAADgCACQgCACgEAAQgDAAgCgCgAY4tIQgCgCAAgDIAAg8QAAgDACgCQACgDADAAQAEAAACADQACACAAADIAAA8QAAADgCACQgCACgEAAQgDAAgCgCgAgEtIQgCgCAAgDIAAg8QAAgDACgCQACgDACAAQADAAACADQACACAAADIAAA8QAAADgCACQgCACgDAAQgCAAgCgCgA5CtIQgCgCAAgDIAAg8QAAgDACgCQACgDADAAQAEAAACADQACACAAADIAAA8QAAADgCACQgCACgEAAQgDAAgCgCgAY4vAQgCgCAAgDIAAg8QAAgDACgDQACgCADAAQAEAAACACQACADAAADIAAA8QAAADgCACQgCACgEAAQgDAAgCgCgAgEvAQgCgCAAgDIAAg8QAAgDACgDQACgCACAAQADAAACACQACADAAADIAAA8QAAADgCACQgCACgDAAQgCAAgCgCgA5CvAQgCgCAAgDIAAg8QAAgDACgDQACgCADAAQAEAAACACQACADAAADIAAA8QAAADgCACQgCACgEAAQgDAAgCgCgAY4w4QgCgCAAgDIAAg8QAAgDACgDQACgCADAAQAEAAACACQACADAAADIAAA8QAAADgCACQgCACgEAAQgDAAgCgCgAgEw4QgCgCAAgDIAAg8QAAgDACgDQACgCACAAQADAAACACQACADAAADIAAA8QAAADgCACQgCACgDAAQgCAAgCgCgA5Cw4QgCgCAAgDIAAg8QAAgDACgDQACgCADAAQAEAAACACQACADAAADIAAA8QAAADgCACQgCACgEAAQgDAAgCgCg");
	this.shape_54.setTransform(422.8,138.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_53}]}).to({state:[{t:this.shape_54}]},1).wait(1));

	// horizontal
	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f().s("#B5B3B9").ss(1,0,1).p("EghQANOMBChAAAEghQAH7MBChAAAEghQACpMBChAAAEghQgCoMBChAAAEghQgH6MBChAAAEghQgNNMBChAAA");
	this.shape_55.setTransform(316.1,135);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f().s("#B5B3B9").ss(1,0,1).p("Egx0ANOMBjqAAAEgx0AH7MBjqAAAEgx0ACoMBjqAAAEgx0gCoMBjqAAAEgx0gNNMBjqAAAEgx0gH6MBjqAAA");
	this.shape_56.setTransform(422.6,135.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_55}]}).to({state:[{t:this.shape_56}]},1).wait(1));

	// Ebene 4
	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#D9D9DD").s().p("A2EBkIgBAAIAAjGMAsLAAAIAADGg");
	this.shape_57.setTransform(244.6,13.8);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#737278").s().p("ArKBkIAAjGIWUAAIAACHIAAA/g");
	this.shape_58.setTransform(457.6,13.8);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#FFFFFF").s().p("EghPASdMAAAgj6MAsJAAAIWWAAIAAg/IABAAMAAAAk5g");
	this.shape_59.setTransform(316.2,135.6);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#D9D9DD").s().p("AsdBjIAAAAIAAjGIY7AAIAADGg");
	this.shape_60.setTransform(183.1,13.8);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#B5B3B9").s().p("AseBjIAAjGIY9AAIAADGg");
	this.shape_61.setTransform(342.9,13.8);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#737278").s().p("AsdBjIAAjGIY7AAIAADGg");
	this.shape_62.setTransform(502.7,13.8);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#FFFFFF").s().p("Egx6AR+MAAAgj7IY9AAIY9AAIY9AAIY+AAMAAAAj7g");
	this.shape_63.setTransform(422.8,138.8);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#403F45").s().p("AseBjIAAjGIY9AAIAADGg");
	this.shape_64.setTransform(662.5,13.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_59},{t:this.shape_58},{t:this.shape_57}]}).to({state:[{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,555.7,307.5);


(lib.pics_table = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// container_text
	this.instance = new lib.container_text("single",11);
	this.instance.setTransform(860,422.3,1,1,0,0,0,540,236.5);

	this.instance_1 = new lib.container_text("single",10);
	this.instance_1.setTransform(860,361.4,1,1,0,0,0,540,236.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1,p:{startPosition:10}},{t:this.instance,p:{y:422.3,startPosition:11}}]}).to({state:[{t:this.instance_1,p:{startPosition:21}},{t:this.instance,p:{y:398.9,startPosition:22}}]},1).wait(1));

	// container_text
	this.instance_2 = new lib.container_text("single",9);
	this.instance_2.setTransform(860,324,1,1,0,0,0,540,236.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1).to({startPosition:20},0).wait(1));

	// container_text
	this.instance_3 = new lib.container_text("single",8);
	this.instance_3.setTransform(860,286.5,1,1,0,0,0,540,236.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(1).to({startPosition:19},0).wait(1));

	// container_text
	this.instance_4 = new lib.container_text("single",7);
	this.instance_4.setTransform(550,422.3,1,1,0,0,0,540,236.5);

	this.instance_5 = new lib.container_text("single",6);
	this.instance_5.setTransform(550,361.4,1,1,0,0,0,540,236.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_5,p:{startPosition:6}},{t:this.instance_4,p:{y:422.3}}]}).to({state:[{t:this.instance_5,p:{startPosition:5}},{t:this.instance_4,p:{y:398.9}}]},1).wait(1));

	// container_text
	this.instance_6 = new lib.container_text("single",4);
	this.instance_6.setTransform(550,324,1,1,0,0,0,540,236.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(1).to({startPosition:4},0).wait(1));

	// container_text
	this.instance_7 = new lib.container_text("single",3);
	this.instance_7.setTransform(550,286.5,1,1,0,0,0,540,236.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(1).to({startPosition:3},0).wait(1));

	// container_text
	this.instance_8 = new lib.container_text("single",2);
	this.instance_8.setTransform(550,246.5,1,1,0,0,0,540,236.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(1).to({startPosition:2},0).wait(1));

	// pic_plane_white
	this.instance_9 = new lib.pic_plane_white();
	this.instance_9.setTransform(315,115.1,0.544,0.434,0,0,0,579,265.3);

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(2));

	// Ebene 11
	this.instance_10 = new lib.pic_plane_white();
	this.instance_10.setTransform(315,115.1,0.544,0.434,0,0,0,579,265.3);
	this.instance_10.shadow = new cjs.Shadow("rgba(0,0,0,0.498)",0,0,8);

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-9,-9,652,252);


(lib.pics_icons = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.instance = new lib.pics_arrowHead("single",0);
	this.instance.setTransform(18.2,26.2,0.288,0.318,0,0,180,0.1,0.1);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-31.5,0,15.9,0).ss(1,2,1).p("AiWAKQAkAAAZABQAYABAOADQAhAIAZAaQAGAGAHAGQAUAPAZAGQAVAFASgGQAGgCAGgDQAWgLAJgXQABgEACgFQABgHAAgIQAAgIgCgJQgBgEgCgGQgSgyg7gRQgFgBgEgBQgPgEgPgB");
	this.shape.setTransform(15.1,34.6);

	this.instance_1 = new lib.pics_arrowHead("single",0);
	this.instance_1.setTransform(18.2,16.9,0.288,0.318,180,0,0,0.1,0.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-31.4,0,15.9,0).ss(1,2,1).p("AiWgJQAkAAAZgBQAYgBAOgDQAhgIAZgaQAGgGAHgGQAUgPAZgGQAVgFASAGQAGACAGADQAWALAJAXQABAEACAFQABAHAAAIQAAAIgCAJQgBAEgCAGQgSAyg7ARQgFABgEABQgPAEgPAB");
	this.shape_1.setTransform(15.1,8.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.instance_1},{t:this.shape},{t:this.instance}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-1,32.4,45.1);


(lib.pic_text_sideBar03 = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// Ebene 6
	this.scrollerItem = new lib.scroller_500();
	this.scrollerItem.setTransform(350,60);

	this.timeline.addTween(cjs.Tween.get(this.scrollerItem).wait(1));

	// container_text
	this.instance = new lib.container_text("single",39);
	this.instance.setTransform(51.3,14.2,1,1,0,0,0,51.3,14.2);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// container_text
	this.scrollerContent = new lib.scrollerContent_text_sideBar03();
	this.scrollerContent.setTransform(0,60);

	this.timeline.addTween(cjs.Tween.get(this.scrollerContent).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,360,871.3);


(lib.pic_text_sideBar02 = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// Ebene 6
	this.scrollerItem = new lib.scroller_500();
	this.scrollerItem.setTransform(350,60);

	this.timeline.addTween(cjs.Tween.get(this.scrollerItem).wait(1));

	// container_text
	this.instance = new lib.container_text("single",29);
	this.instance.setTransform(51.3,14.2,1,1,0,0,0,51.3,14.2);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// container_text
	this.scrollerContent = new lib.scrollerContent_text_sideBar02();
	this.scrollerContent.setTransform(0,60);

	this.timeline.addTween(cjs.Tween.get(this.scrollerContent).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,360,560);


(lib.pic_text_sideBar01 = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// Ebene 6
	this.scrollerItem = new lib.scroller_500();
	this.scrollerItem.setTransform(350,60);

	this.timeline.addTween(cjs.Tween.get(this.scrollerItem).wait(1));

	// container_text
	this.instance = new lib.container_text("single",0);
	this.instance.setTransform(51.3,14.2,1,1,0,0,0,51.3,14.2);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// container_text
	this.scrollerContent = new lib.scrollerContent_text_sideBar();
	this.scrollerContent.setTransform(0,60);

	this.timeline.addTween(cjs.Tween.get(this.scrollerContent).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,360,560);


(lib.pic_text_sideBar_back = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.instance = new lib.pic_plane_white();
	this.instance.setTransform(209,325,1,1,0,0,0,209,325);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,1158,530);


(lib.pic_particleFilter = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// Ebene 3
	this.instance = new lib.ani_coating("synched",0,false);
	this.instance.setTransform(247.1,131,1,1,0,0,0,140.8,109.4);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({_off:true},99).wait(19));

	// Ebene 8
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(64,63,69,0.988)","#403F45"],[0,1],-333.7,-114.2,-52.2,-114.2).s().p("A1+S0IAAgWIAAhYMAr9AAAIAABugA1+N1IAAh5MAr9AAAIAAB5gA1+IrIAAhuMAr9AAAIAABugA1+DhIAAhuMAr9AAAIAABugA1+hnIAAhuMAr9AAAIAABugA1+mxIAAhuMAr9AAAIAABugA1+r7IAAhuMAr9AAAIAABugA1+xFIAAhuMAr9AAAIAABug");
	this.shape.setTransform(247.1,131);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["rgba(64,63,69,0.937)","#403F45"],[0,1],-332.9,-113.7,-51.4,-113.7).s().p("A1+S0IAAhuMAr9AAAIAABugA1+N1IAAh5MAr9AAAIAAB5gA1+IrIAAhuMAr9AAAIAABugA1+DhIAAhuMAr9AAAIAABugA1+hnIAAhuMAr9AAAIAABugA1+mxIAAhuMAr9AAAIAABugA1+r7IAAhuMAr9AAAIAABugA1+xFIAAhuMAr9AAAIAABug");
	this.shape_1.setTransform(247.1,131);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.lf(["rgba(64,63,69,0.882)","#403F45"],[0,1],-332.1,-113.3,-50.6,-113.3).s().p("A1+S0IAAhuMAr9AAAIAABugA1+N1IAAh5MAr9AAAIAAB5gA1+IrIAAhuMAr9AAAIAABugA1+DhIAAhuMAr9AAAIAABugA1+hnIAAhuMAr9AAAIAABugA1+mxIAAhuMAr9AAAIAABugA1+r7IAAhuMAr9AAAIAABugA1+xFIAAhuMAr9AAAIAABug");
	this.shape_2.setTransform(247.1,131);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.lf(["rgba(64,63,69,0.831)","#403F45"],[0,1],-331.3,-112.8,-49.8,-112.8).s().p("A1+S0IAAhuMAr9AAAIAABugA1+N1IAAh5MAr9AAAIAAB5gA1+IrIAAhuMAr9AAAIAABugA1+DhIAAhuMAr9AAAIAABugA1+hnIAAhuMAr9AAAIAABugA1+mxIAAhuMAr9AAAIAABugA1+r7IAAhuMAr9AAAIAABugA1+xFIAAhuMAr9AAAIAABug");
	this.shape_3.setTransform(247.1,131);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.lf(["rgba(64,63,69,0.78)","#403F45"],[0,1],-330.5,-112.4,-49,-112.4).s().p("A1+S0IAAhuMAr9AAAIAABugA1+N1IAAh5MAr9AAAIAAB5gA1+IrIAAhuMAr9AAAIAABugA1+DhIAAhuMAr9AAAIAABugA1+hnIAAhuMAr9AAAIAABugA1+mxIAAhuMAr9AAAIAABugA1+r7IAAhuMAr9AAAIAABugA1+xFIAAhuMAr9AAAIAABug");
	this.shape_4.setTransform(247.1,131);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.lf(["rgba(64,63,69,0.729)","#403F45"],[0,1],-329.6,-111.9,-48.1,-111.9).s().p("A1+S0IAAhuMAr9AAAIAABugA1+N1IAAh5MAr9AAAIAAB5gA1+IrIAAhuMAr9AAAIAABugA1+DhIAAhuMAr9AAAIAABugA1+hnIAAhuMAr9AAAIAABugA1+mxIAAhuMAr9AAAIAABugA1+r7IAAhuMAr9AAAIAABugA1+xFIAAhuMAr9AAAIAABug");
	this.shape_5.setTransform(247.1,131);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.lf(["rgba(64,63,69,0.675)","#403F45"],[0,1],-328.8,-111.5,-47.3,-111.5).s().p("A1+S0IAAhuMAr9AAAIAABugA1+N1IAAh5MAr9AAAIAAB5gA1+IrIAAhuMAr9AAAIAABugA1+DhIAAhuMAr9AAAIAABugA1+hnIAAhuMAr9AAAIAABugA1+mxIAAhuMAr9AAAIAABugA1+r7IAAhuMAr9AAAIAABugA1+xFIAAhuMAr9AAAIAABug");
	this.shape_6.setTransform(247.1,131);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.lf(["rgba(64,63,69,0.624)","#403F45"],[0,1],-328,-111,-46.5,-111).s().p("A1+S0IAAhuMAr9AAAIAABugA1+N1IAAh5MAr9AAAIAAB5gA1+IrIAAhuMAr9AAAIAABugA1+DhIAAhuMAr9AAAIAABugA1+hnIAAhuMAr9AAAIAABugA1+mxIAAhuMAr9AAAIAABugA1+r7IAAhuMAr9AAAIAABugA1+xFIAAhuMAr9AAAIAABug");
	this.shape_7.setTransform(247.1,131);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.lf(["rgba(64,63,69,0.573)","#403F45"],[0,1],-327.2,-110.6,-45.7,-110.6).s().p("A1+S0IAAhuMAr9AAAIAABugA1+N1IAAh5MAr9AAAIAAB5gA1+IrIAAhuMAr9AAAIAABugA1+DhIAAhuMAr9AAAIAABugA1+hnIAAhuMAr9AAAIAABugA1+mxIAAhuMAr9AAAIAABugA1+r7IAAhuMAr9AAAIAABugA1+xFIAAhuMAr9AAAIAABug");
	this.shape_8.setTransform(247.1,131);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.lf(["rgba(64,63,69,0.522)","#403F45"],[0,1],-326.4,-110.1,-44.9,-110.1).s().p("A1+S0IAAhuMAr9AAAIAABugA1+N1IAAh5MAr9AAAIAAB5gA1+IrIAAhuMAr9AAAIAABugA1+DhIAAhuMAr9AAAIAABugA1+hnIAAhuMAr9AAAIAABugA1+mxIAAhuMAr9AAAIAABugA1+r7IAAhuMAr9AAAIAABugA1+xFIAAhuMAr9AAAIAABug");
	this.shape_9.setTransform(247.1,131);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.lf(["rgba(64,63,69,0.467)","#403F45"],[0,1],-325.6,-109.7,-44.1,-109.7).s().p("A1+S0IAAhuMAr9AAAIAABugA1+N1IAAh5MAr9AAAIAAB5gA1+IrIAAhuMAr9AAAIAABugA1+DhIAAhuMAr9AAAIAABugA1+hnIAAhuMAr9AAAIAABugA1+mxIAAhuMAr9AAAIAABugA1+r7IAAhuMAr9AAAIAABugA1+xFIAAhuMAr9AAAIAABug");
	this.shape_10.setTransform(247.1,131);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.lf(["rgba(64,63,69,0.416)","#403F45"],[0,1],-324.8,-109.2,-43.3,-109.2).s().p("A1+S0IAAhuMAr9AAAIAABugA1+N1IAAh5MAr9AAAIAAB5gA1+IrIAAhuMAr9AAAIAABugA1+DhIAAhuMAr9AAAIAABugA1+hnIAAhuMAr9AAAIAABugA1+mxIAAhuMAr9AAAIAABugA1+r7IAAhuMAr9AAAIAABugA1+xFIAAhuMAr9AAAIAABug");
	this.shape_11.setTransform(247.1,131);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.lf(["rgba(64,63,69,0.365)","#403F45"],[0,1],-323.9,-108.8,-42.4,-108.8).s().p("A1+S0IAAhuMAr9AAAIAABugA1+N1IAAh5MAr9AAAIAAB5gA1+IrIAAhuMAr9AAAIAABugA1+DhIAAhuMAr9AAAIAABugA1+hnIAAhuMAr9AAAIAABugA1+mxIAAhuMAr9AAAIAABugA1+r7IAAhuMAr9AAAIAABugA1+xFIAAhuMAr9AAAIAABug");
	this.shape_12.setTransform(247.1,131);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.lf(["rgba(64,63,69,0.314)","#403F45"],[0,1],-323.1,-108.3,-41.6,-108.3).s().p("A1+S0IAAhuMAr9AAAIAABugA1+N1IAAh5MAr9AAAIAAB5gA1+IrIAAhuMAr9AAAIAABugA1+DhIAAhuMAr9AAAIAABugA1+hnIAAhuMAr9AAAIAABugA1+mxIAAhuMAr9AAAIAABugA1+r7IAAhuMAr9AAAIAABugA1+xFIAAhuMAr9AAAIAABug");
	this.shape_13.setTransform(247.1,131);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.lf(["rgba(64,63,69,0.259)","#403F45"],[0,1],-322.3,-107.9,-40.8,-107.9).s().p("A1+S0IAAhuMAr9AAAIAABugA1+N1IAAh5MAr9AAAIAAB5gA1+IrIAAhuMAr9AAAIAABugA1+DhIAAhuMAr9AAAIAABugA1+hnIAAhuMAr9AAAIAABugA1+mxIAAhuMAr9AAAIAABugA1+r7IAAhuMAr9AAAIAABugA1+xFIAAhuMAr9AAAIAABug");
	this.shape_14.setTransform(247.1,131);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.lf(["rgba(64,63,69,0.208)","#403F45"],[0,1],-321.5,-107.4,-40,-107.4).s().p("A1+S0IAAhuMAr9AAAIAABugA1+N1IAAh5MAr9AAAIAAB5gA1+IrIAAhuMAr9AAAIAABugA1+DhIAAhuMAr9AAAIAABugA1+hnIAAhuMAr9AAAIAABugA1+mxIAAhuMAr9AAAIAABugA1+r7IAAhuMAr9AAAIAABugA1+xFIAAhuMAr9AAAIAABug");
	this.shape_15.setTransform(247.1,131);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.lf(["rgba(64,63,69,0.157)","#403F45"],[0,1],-320.7,-107,-39.2,-107).s().p("A1+S0IAAhuMAr9AAAIAABugA1+N1IAAh5MAr9AAAIAAB5gA1+IrIAAhuMAr9AAAIAABugA1+DhIAAhuMAr9AAAIAABugA1+hnIAAhuMAr9AAAIAABugA1+mxIAAhuMAr9AAAIAABugA1+r7IAAhuMAr9AAAIAABugA1+xFIAAhuMAr9AAAIAABug");
	this.shape_16.setTransform(247.1,131);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.lf(["rgba(64,63,69,0.106)","#403F45"],[0,1],-319.9,-106.5,-38.4,-106.5).s().p("A1+S0IAAhuMAr9AAAIAABugA1+N1IAAh5MAr9AAAIAAB5gA1+IrIAAhuMAr9AAAIAABugA1+DhIAAhuMAr9AAAIAABugA1+hnIAAhuMAr9AAAIAABugA1+mxIAAhuMAr9AAAIAABugA1+r7IAAhuMAr9AAAIAABugA1+xFIAAhuMAr9AAAIAABug");
	this.shape_17.setTransform(247.1,131);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.lf(["rgba(64,63,69,0.051)","#403F45"],[0,1],-319,-106.1,-37.5,-106.1).s().p("A1+S0IAAhuMAr9AAAIAABugA1+N1IAAh5MAr9AAAIAAB5gA1+IrIAAhuMAr9AAAIAABugA1+DhIAAhuMAr9AAAIAABugA1+hnIAAhuMAr9AAAIAABugA1+mxIAAhuMAr9AAAIAABugA1+r7IAAhuMAr9AAAIAABugA1+xFIAAhuMAr9AAAIAABug");
	this.shape_18.setTransform(247.1,131);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.lf(["rgba(64,63,69,0)","#403F45"],[0,1],-318.2,-105.6,-36.7,-105.6).s().p("A1+S0IAAgWIAAhYMAr9AAAIAABugA1+N1IAAh5MAr9AAAIAAB5gA1+IrIAAhuMAr9AAAIAABugA1+DhIAAhuMAr9AAAIAABugA1+hnIAAhuMAr9AAAIAABugA1+mxIAAhuMAr9AAAIAABugA1+r7IAAhuMAr9AAAIAABugA1+xFIAAhuMAr9AAAIAABug");
	this.shape_19.setTransform(247.1,131);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.lf(["rgba(64,63,69,0)","#403F45"],[0,1],-314.1,-105.7,-35.3,-105.7).s().p("A1+S0IAAhuMAr9AAAIAABugA1+N1IAAh5MAr9AAAIAAB5gA1+IrIAAhuMAr9AAAIAABugA1+DhIAAhuMAr9AAAIAABugA1+hnIAAhuMAr9AAAIAABugA1+mxIAAhuMAr9AAAIAABugA1+r7IAAhuMAr9AAAIAABugA1+xFIAAhuMAr9AAAIAABug");
	this.shape_20.setTransform(247.1,131);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.lf(["rgba(64,63,69,0)","#403F45"],[0,1],-309.9,-105.8,-33.7,-105.8).s().p("A1+S0IAAhuMAr9AAAIAABugA1+N1IAAh5MAr9AAAIAAB5gA1+IrIAAhuMAr9AAAIAABugA1+DhIAAhuMAr9AAAIAABugA1+hnIAAhuMAr9AAAIAABugA1+mxIAAhuMAr9AAAIAABugA1+r7IAAhuMAr9AAAIAABugA1+xFIAAhuMAr9AAAIAABug");
	this.shape_21.setTransform(247.1,131);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.lf(["rgba(64,63,69,0)","#403F45"],[0,1],-305.8,-105.8,-32.2,-105.8).s().p("A1+S0IAAhuMAr9AAAIAABugA1+N1IAAh5MAr9AAAIAAB5gA1+IrIAAhuMAr9AAAIAABugA1+DhIAAhuMAr9AAAIAABugA1+hnIAAhuMAr9AAAIAABugA1+mxIAAhuMAr9AAAIAABugA1+r7IAAhuMAr9AAAIAABugA1+xFIAAhuMAr9AAAIAABug");
	this.shape_22.setTransform(247.1,131);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.lf(["rgba(64,63,69,0)","#403F45"],[0,1],-301.7,-105.9,-30.8,-105.9).s().p("A1+S0IAAhuMAr9AAAIAABugA1+N1IAAh5MAr9AAAIAAB5gA1+IrIAAhuMAr9AAAIAABugA1+DhIAAhuMAr9AAAIAABugA1+hnIAAhuMAr9AAAIAABugA1+mxIAAhuMAr9AAAIAABugA1+r7IAAhuMAr9AAAIAABugA1+xFIAAhuMAr9AAAIAABug");
	this.shape_23.setTransform(247.1,131);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.lf(["rgba(64,63,69,0)","#403F45"],[0,1],-297.5,-106,-29.2,-106).s().p("A1+S0IAAhuMAr9AAAIAABugA1+N1IAAh5MAr9AAAIAAB5gA1+IrIAAhuMAr9AAAIAABugA1+DhIAAhuMAr9AAAIAABugA1+hnIAAhuMAr9AAAIAABugA1+mxIAAhuMAr9AAAIAABugA1+r7IAAhuMAr9AAAIAABugA1+xFIAAhuMAr9AAAIAABug");
	this.shape_24.setTransform(247.1,131);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.lf(["rgba(64,63,69,0)","#403F45"],[0,1],-293.4,-106,-27.8,-106).s().p("A1+S0IAAhuMAr9AAAIAABugA1+N1IAAh5MAr9AAAIAAB5gA1+IrIAAhuMAr9AAAIAABugA1+DhIAAhuMAr9AAAIAABugA1+hnIAAhuMAr9AAAIAABugA1+mxIAAhuMAr9AAAIAABugA1+r7IAAhuMAr9AAAIAABugA1+xFIAAhuMAr9AAAIAABug");
	this.shape_25.setTransform(247.1,131);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.lf(["rgba(64,63,69,0)","#403F45"],[0,1],-289.2,-106.1,-26.2,-106.1).s().p("A1+S0IAAhuMAr9AAAIAABugA1+N1IAAh5MAr9AAAIAAB5gA1+IrIAAhuMAr9AAAIAABugA1+DhIAAhuMAr9AAAIAABugA1+hnIAAhuMAr9AAAIAABugA1+mxIAAhuMAr9AAAIAABugA1+r7IAAhuMAr9AAAIAABugA1+xFIAAhuMAr9AAAIAABug");
	this.shape_26.setTransform(247.1,131);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.lf(["rgba(64,63,69,0)","#403F45"],[0,1],-285.1,-106.2,-24.7,-106.2).s().p("A1+S0IAAhuMAr9AAAIAABugA1+N1IAAh5MAr9AAAIAAB5gA1+IrIAAhuMAr9AAAIAABugA1+DhIAAhuMAr9AAAIAABugA1+hnIAAhuMAr9AAAIAABugA1+mxIAAhuMAr9AAAIAABugA1+r7IAAhuMAr9AAAIAABugA1+xFIAAhuMAr9AAAIAABug");
	this.shape_27.setTransform(247.1,131);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.lf(["rgba(64,63,69,0)","#403F45"],[0,1],-281,-106.2,-23.3,-106.2).s().p("A1+S0IAAhuMAr9AAAIAABugA1+N1IAAh5MAr9AAAIAAB5gA1+IrIAAhuMAr9AAAIAABugA1+DhIAAhuMAr9AAAIAABugA1+hnIAAhuMAr9AAAIAABugA1+mxIAAhuMAr9AAAIAABugA1+r7IAAhuMAr9AAAIAABugA1+xFIAAhuMAr9AAAIAABug");
	this.shape_28.setTransform(247.1,131);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.lf(["rgba(64,63,69,0)","#403F45"],[0,1],-276.8,-106.3,-21.7,-106.3).s().p("A1+S0IAAhuMAr9AAAIAABugA1+N1IAAh5MAr9AAAIAAB5gA1+IrIAAhuMAr9AAAIAABugA1+DhIAAhuMAr9AAAIAABugA1+hnIAAhuMAr9AAAIAABugA1+mxIAAhuMAr9AAAIAABugA1+r7IAAhuMAr9AAAIAABugA1+xFIAAhuMAr9AAAIAABug");
	this.shape_29.setTransform(247.1,131);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.lf(["rgba(64,63,69,0)","#403F45"],[0,1],-272.7,-106.4,-20.3,-106.4).s().p("A1+S0IAAhuMAr9AAAIAABugA1+N1IAAh5MAr9AAAIAAB5gA1+IrIAAhuMAr9AAAIAABugA1+DhIAAhuMAr9AAAIAABugA1+hnIAAhuMAr9AAAIAABugA1+mxIAAhuMAr9AAAIAABugA1+r7IAAhuMAr9AAAIAABugA1+xFIAAhuMAr9AAAIAABug");
	this.shape_30.setTransform(247.1,131);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.lf(["rgba(64,63,69,0)","#403F45"],[0,1],-268.5,-106.4,-18.8,-106.4).s().p("A1+S0IAAhuMAr9AAAIAABugA1+N1IAAh5MAr9AAAIAAB5gA1+IrIAAhuMAr9AAAIAABugA1+DhIAAhuMAr9AAAIAABugA1+hnIAAhuMAr9AAAIAABugA1+mxIAAhuMAr9AAAIAABugA1+r7IAAhuMAr9AAAIAABugA1+xFIAAhuMAr9AAAIAABug");
	this.shape_31.setTransform(247.1,131);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.lf(["rgba(64,63,69,0)","#403F45"],[0,1],-264.4,-106.5,-17.3,-106.5).s().p("A1+S0IAAhuMAr9AAAIAABugA1+N1IAAh5MAr9AAAIAAB5gA1+IrIAAhuMAr9AAAIAABugA1+DhIAAhuMAr9AAAIAABugA1+hnIAAhuMAr9AAAIAABugA1+mxIAAhuMAr9AAAIAABugA1+r7IAAhuMAr9AAAIAABugA1+xFIAAhuMAr9AAAIAABug");
	this.shape_32.setTransform(247.1,131);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.lf(["rgba(64,63,69,0)","#403F45"],[0,1],-260.3,-106.6,-15.8,-106.6).s().p("A1+S0IAAhuMAr9AAAIAABugA1+N1IAAh5MAr9AAAIAAB5gA1+IrIAAhuMAr9AAAIAABugA1+DhIAAhuMAr9AAAIAABugA1+hnIAAhuMAr9AAAIAABugA1+mxIAAhuMAr9AAAIAABugA1+r7IAAhuMAr9AAAIAABugA1+xFIAAhuMAr9AAAIAABug");
	this.shape_33.setTransform(247.1,131);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.lf(["rgba(64,63,69,0)","#403F45"],[0,1],-256.1,-106.6,-14.3,-106.6).s().p("A1+S0IAAhuMAr9AAAIAABugA1+N1IAAh5MAr9AAAIAAB5gA1+IrIAAhuMAr9AAAIAABugA1+DhIAAhuMAr9AAAIAABugA1+hnIAAhuMAr9AAAIAABugA1+mxIAAhuMAr9AAAIAABugA1+r7IAAhuMAr9AAAIAABugA1+xFIAAhuMAr9AAAIAABug");
	this.shape_34.setTransform(247.1,131);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.lf(["rgba(64,63,69,0)","#403F45"],[0,1],-251.9,-106.7,-12.8,-106.7).s().p("A1+S0IAAhuMAr9AAAIAABugA1+N1IAAh5MAr9AAAIAAB5gA1+IrIAAhuMAr9AAAIAABugA1+DhIAAhuMAr9AAAIAABugA1+hnIAAhuMAr9AAAIAABugA1+mxIAAhuMAr9AAAIAABugA1+r7IAAhuMAr9AAAIAABugA1+xFIAAhuMAr9AAAIAABug");
	this.shape_35.setTransform(247.1,131);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.lf(["rgba(64,63,69,0)","#403F45"],[0,1],-247.8,-106.8,-11.3,-106.8).s().p("A1+S0IAAhuMAr9AAAIAABugA1+N1IAAh5MAr9AAAIAAB5gA1+IrIAAhuMAr9AAAIAABugA1+DhIAAhuMAr9AAAIAABugA1+hnIAAhuMAr9AAAIAABugA1+mxIAAhuMAr9AAAIAABugA1+r7IAAhuMAr9AAAIAABugA1+xFIAAhuMAr9AAAIAABug");
	this.shape_36.setTransform(247.1,131);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.lf(["rgba(64,63,69,0)","#403F45"],[0,1],-243.7,-106.8,-9.8,-106.8).s().p("A1+S0IAAhuMAr9AAAIAABugA1+N1IAAh5MAr9AAAIAAB5gA1+IrIAAhuMAr9AAAIAABugA1+DhIAAhuMAr9AAAIAABugA1+hnIAAhuMAr9AAAIAABugA1+mxIAAhuMAr9AAAIAABugA1+r7IAAhuMAr9AAAIAABugA1+xFIAAhuMAr9AAAIAABug");
	this.shape_37.setTransform(247.1,131);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.lf(["rgba(64,63,69,0)","#403F45"],[0,1],-239.5,-106.9,-8.3,-106.9).s().p("A1+S0IAAhuMAr9AAAIAABugA1+N1IAAh5MAr9AAAIAAB5gA1+IrIAAhuMAr9AAAIAABugA1+DhIAAhuMAr9AAAIAABugA1+hnIAAhuMAr9AAAIAABugA1+mxIAAhuMAr9AAAIAABugA1+r7IAAhuMAr9AAAIAABugA1+xFIAAhuMAr9AAAIAABug");
	this.shape_38.setTransform(247.1,131);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.lf(["rgba(64,63,69,0)","#403F45"],[0,1],-235.4,-107,-6.8,-107).s().p("A1+S0IAAhuMAr9AAAIAABugA1+N1IAAh5MAr9AAAIAAB5gA1+IrIAAhuMAr9AAAIAABugA1+DhIAAhuMAr9AAAIAABugA1+hnIAAhuMAr9AAAIAABugA1+mxIAAhuMAr9AAAIAABugA1+r7IAAhuMAr9AAAIAABugA1+xFIAAhuMAr9AAAIAABug");
	this.shape_39.setTransform(247.1,131);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.lf(["rgba(64,63,69,0)","#403F45"],[0,1],-231.2,-107,-5.3,-107).s().p("A1+S0IAAhuMAr9AAAIAABugA1+N1IAAh5MAr9AAAIAAB5gA1+IrIAAhuMAr9AAAIAABugA1+DhIAAhuMAr9AAAIAABugA1+hnIAAhuMAr9AAAIAABugA1+mxIAAhuMAr9AAAIAABugA1+r7IAAhuMAr9AAAIAABugA1+xFIAAhuMAr9AAAIAABug");
	this.shape_40.setTransform(247.1,131);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.lf(["rgba(64,63,69,0)","#403F45"],[0,1],-227.1,-107.1,-3.8,-107.1).s().p("A1+S0IAAhuMAr9AAAIAABugA1+N1IAAh5MAr9AAAIAAB5gA1+IrIAAhuMAr9AAAIAABugA1+DhIAAhuMAr9AAAIAABugA1+hnIAAhuMAr9AAAIAABugA1+mxIAAhuMAr9AAAIAABugA1+r7IAAhuMAr9AAAIAABugA1+xFIAAhuMAr9AAAIAABug");
	this.shape_41.setTransform(247.1,131);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.lf(["rgba(64,63,69,0)","#403F45"],[0,1],-223,-107.2,-2.3,-107.2).s().p("A1+S0IAAhuMAr9AAAIAABugA1+N1IAAh5MAr9AAAIAAB5gA1+IrIAAhuMAr9AAAIAABugA1+DhIAAhuMAr9AAAIAABugA1+hnIAAhuMAr9AAAIAABugA1+mxIAAhuMAr9AAAIAABugA1+r7IAAhuMAr9AAAIAABugA1+xFIAAhuMAr9AAAIAABug");
	this.shape_42.setTransform(247.1,131);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.lf(["rgba(64,63,69,0)","#403F45"],[0,1],-218.8,-107.2,-0.8,-107.2).s().p("A1+S0IAAhuMAr9AAAIAABugA1+N1IAAh5MAr9AAAIAAB5gA1+IrIAAhuMAr9AAAIAABugA1+DhIAAhuMAr9AAAIAABugA1+hnIAAhuMAr9AAAIAABugA1+mxIAAhuMAr9AAAIAABugA1+r7IAAhuMAr9AAAIAABugA1+xFIAAhuMAr9AAAIAABug");
	this.shape_43.setTransform(247.1,131);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.lf(["rgba(64,63,69,0)","#403F45"],[0,1],-214.7,-107.3,0.7,-107.3).s().p("A1+S0IAAhuMAr9AAAIAABugA1+N1IAAh5MAr9AAAIAAB5gA1+IrIAAhuMAr9AAAIAABugA1+DhIAAhuMAr9AAAIAABugA1+hnIAAhuMAr9AAAIAABugA1+mxIAAhuMAr9AAAIAABugA1+r7IAAhuMAr9AAAIAABugA1+xFIAAhuMAr9AAAIAABug");
	this.shape_44.setTransform(247.1,131);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.lf(["rgba(64,63,69,0)","#403F45"],[0,1],-210.6,-107.4,2.1,-107.4).s().p("A1+S0IAAhuMAr9AAAIAABugA1+N1IAAh5MAr9AAAIAAB5gA1+IrIAAhuMAr9AAAIAABugA1+DhIAAhuMAr9AAAIAABugA1+hnIAAhuMAr9AAAIAABugA1+mxIAAhuMAr9AAAIAABugA1+r7IAAhuMAr9AAAIAABugA1+xFIAAhuMAr9AAAIAABug");
	this.shape_45.setTransform(247.1,131);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.lf(["rgba(64,63,69,0)","#403F45"],[0,1],-206.4,-107.4,3.7,-107.4).s().p("A1+S0IAAhuMAr9AAAIAABugA1+N1IAAh5MAr9AAAIAAB5gA1+IrIAAhuMAr9AAAIAABugA1+DhIAAhuMAr9AAAIAABugA1+hnIAAhuMAr9AAAIAABugA1+mxIAAhuMAr9AAAIAABugA1+r7IAAhuMAr9AAAIAABugA1+xFIAAhuMAr9AAAIAABug");
	this.shape_46.setTransform(247.1,131);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.lf(["rgba(64,63,69,0)","#403F45"],[0,1],-202.3,-107.5,5.1,-107.5).s().p("A1+S0IAAhuMAr9AAAIAABugA1+N1IAAh5MAr9AAAIAAB5gA1+IrIAAhuMAr9AAAIAABugA1+DhIAAhuMAr9AAAIAABugA1+hnIAAhuMAr9AAAIAABugA1+mxIAAhuMAr9AAAIAABugA1+r7IAAhuMAr9AAAIAABugA1+xFIAAhuMAr9AAAIAABug");
	this.shape_47.setTransform(247.1,131);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.lf(["rgba(64,63,69,0)","#403F45"],[0,1],-198.1,-107.6,6.7,-107.6).s().p("A1+S0IAAhuMAr9AAAIAABugA1+N1IAAh5MAr9AAAIAAB5gA1+IrIAAhuMAr9AAAIAABugA1+DhIAAhuMAr9AAAIAABugA1+hnIAAhuMAr9AAAIAABugA1+mxIAAhuMAr9AAAIAABugA1+r7IAAhuMAr9AAAIAABugA1+xFIAAhuMAr9AAAIAABug");
	this.shape_48.setTransform(247.1,131);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.lf(["rgba(64,63,69,0)","#403F45"],[0,1],-194,-107.6,8.2,-107.6).s().p("A1+S0IAAhuMAr9AAAIAABugA1+N1IAAh5MAr9AAAIAAB5gA1+IrIAAhuMAr9AAAIAABugA1+DhIAAhuMAr9AAAIAABugA1+hnIAAhuMAr9AAAIAABugA1+mxIAAhuMAr9AAAIAABugA1+r7IAAhuMAr9AAAIAABugA1+xFIAAhuMAr9AAAIAABug");
	this.shape_49.setTransform(247.1,131);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.lf(["rgba(64,63,69,0)","#403F45"],[0,1],-189.9,-107.7,9.6,-107.7).s().p("A1+S0IAAhuMAr9AAAIAABugA1+N1IAAh5MAr9AAAIAAB5gA1+IrIAAhuMAr9AAAIAABugA1+DhIAAhuMAr9AAAIAABugA1+hnIAAhuMAr9AAAIAABugA1+mxIAAhuMAr9AAAIAABugA1+r7IAAhuMAr9AAAIAABugA1+xFIAAhuMAr9AAAIAABug");
	this.shape_50.setTransform(247.1,131);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.lf(["rgba(64,63,69,0)","#403F45"],[0,1],-185.7,-107.8,11.2,-107.8).s().p("A1+S0IAAhuMAr9AAAIAABugA1+N1IAAh5MAr9AAAIAAB5gA1+IrIAAhuMAr9AAAIAABugA1+DhIAAhuMAr9AAAIAABugA1+hnIAAhuMAr9AAAIAABugA1+mxIAAhuMAr9AAAIAABugA1+r7IAAhuMAr9AAAIAABugA1+xFIAAhuMAr9AAAIAABug");
	this.shape_51.setTransform(247.1,131);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.lf(["rgba(64,63,69,0)","#403F45"],[0,1],-181.6,-107.9,12.6,-107.9).s().p("A1+S0IAAhuMAr9AAAIAABugA1+N1IAAh5MAr9AAAIAAB5gA1+IrIAAhuMAr9AAAIAABugA1+DhIAAhuMAr9AAAIAABugA1+hnIAAhuMAr9AAAIAABugA1+mxIAAhuMAr9AAAIAABugA1+r7IAAhuMAr9AAAIAABugA1+xFIAAhuMAr9AAAIAABug");
	this.shape_52.setTransform(247.1,131);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.lf(["rgba(64,63,69,0)","#403F45"],[0,1],-177.4,-107.9,14.1,-107.9).s().p("A1+S0IAAhuMAr9AAAIAABugA1+N1IAAh5MAr9AAAIAAB5gA1+IrIAAhuMAr9AAAIAABugA1+DhIAAhuMAr9AAAIAABugA1+hnIAAhuMAr9AAAIAABugA1+mxIAAhuMAr9AAAIAABugA1+r7IAAhuMAr9AAAIAABugA1+xFIAAhuMAr9AAAIAABug");
	this.shape_53.setTransform(247.1,131);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.lf(["rgba(64,63,69,0)","#403F45"],[0,1],-173.3,-108,15.6,-108).s().p("A1+S0IAAhuMAr9AAAIAABugA1+N1IAAh5MAr9AAAIAAB5gA1+IrIAAhuMAr9AAAIAABugA1+DhIAAhuMAr9AAAIAABugA1+hnIAAhuMAr9AAAIAABugA1+mxIAAhuMAr9AAAIAABugA1+r7IAAhuMAr9AAAIAABugA1+xFIAAhuMAr9AAAIAABug");
	this.shape_54.setTransform(247.1,131);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.lf(["rgba(64,63,69,0)","#403F45"],[0,1],-169.2,-108.1,17.1,-108.1).s().p("A1+S0IAAhuMAr9AAAIAABugA1+N1IAAh5MAr9AAAIAAB5gA1+IrIAAhuMAr9AAAIAABugA1+DhIAAhuMAr9AAAIAABugA1+hnIAAhuMAr9AAAIAABugA1+mxIAAhuMAr9AAAIAABugA1+r7IAAhuMAr9AAAIAABugA1+xFIAAhuMAr9AAAIAABug");
	this.shape_55.setTransform(247.1,131);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.lf(["rgba(64,63,69,0)","#403F45"],[0,1],-165,-108.1,18.6,-108.1).s().p("A1+S0IAAhuMAr9AAAIAABugA1+N1IAAh5MAr9AAAIAAB5gA1+IrIAAhuMAr9AAAIAABugA1+DhIAAhuMAr9AAAIAABugA1+hnIAAhuMAr9AAAIAABugA1+mxIAAhuMAr9AAAIAABugA1+r7IAAhuMAr9AAAIAABugA1+xFIAAhuMAr9AAAIAABug");
	this.shape_56.setTransform(247.1,131);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.lf(["rgba(64,63,69,0)","#403F45"],[0,1],-160.9,-108.2,20.1,-108.2).s().p("A1+S0IAAhuMAr9AAAIAABugA1+N1IAAh5MAr9AAAIAAB5gA1+IrIAAhuMAr9AAAIAABugA1+DhIAAhuMAr9AAAIAABugA1+hnIAAhuMAr9AAAIAABugA1+mxIAAhuMAr9AAAIAABugA1+r7IAAhuMAr9AAAIAABugA1+xFIAAhuMAr9AAAIAABug");
	this.shape_57.setTransform(247.1,131);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.lf(["rgba(64,63,69,0)","#403F45"],[0,1],-156.7,-108.3,21.6,-108.3).s().p("A1+S0IAAhuMAr9AAAIAABugA1+N1IAAh5MAr9AAAIAAB5gA1+IrIAAhuMAr9AAAIAABugA1+DhIAAhuMAr9AAAIAABugA1+hnIAAhuMAr9AAAIAABugA1+mxIAAhuMAr9AAAIAABugA1+r7IAAhuMAr9AAAIAABugA1+xFIAAhuMAr9AAAIAABug");
	this.shape_58.setTransform(247.1,131);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.lf(["rgba(64,63,69,0)","#403F45"],[0,1],-152.6,-108.3,23.1,-108.3).s().p("A1+S0IAAhuMAr9AAAIAABugA1+N1IAAh5MAr9AAAIAAB5gA1+IrIAAhuMAr9AAAIAABugA1+DhIAAhuMAr9AAAIAABugA1+hnIAAhuMAr9AAAIAABugA1+mxIAAhuMAr9AAAIAABugA1+r7IAAhuMAr9AAAIAABugA1+xFIAAhuMAr9AAAIAABug");
	this.shape_59.setTransform(247.1,131);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.lf(["rgba(64,63,69,0)","#403F45"],[0,1],-148.4,-108.4,24.6,-108.4).s().p("A1+S0IAAhuMAr9AAAIAABugA1+N1IAAh5MAr9AAAIAAB5gA1+IrIAAhuMAr9AAAIAABugA1+DhIAAhuMAr9AAAIAABugA1+hnIAAhuMAr9AAAIAABugA1+mxIAAhuMAr9AAAIAABugA1+r7IAAhuMAr9AAAIAABugA1+xFIAAhuMAr9AAAIAABug");
	this.shape_60.setTransform(247.1,131);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.lf(["rgba(64,63,69,0)","#403F45"],[0,1],-144.3,-108.5,26.1,-108.5).s().p("A1+S0IAAhuMAr9AAAIAABugA1+N1IAAh5MAr9AAAIAAB5gA1+IrIAAhuMAr9AAAIAABugA1+DhIAAhuMAr9AAAIAABugA1+hnIAAhuMAr9AAAIAABugA1+mxIAAhuMAr9AAAIAABugA1+r7IAAhuMAr9AAAIAABugA1+xFIAAhuMAr9AAAIAABug");
	this.shape_61.setTransform(247.1,131);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.lf(["rgba(64,63,69,0)","#403F45"],[0,1],-140.1,-108.5,27.6,-108.5).s().p("A1+S0IAAhuMAr9AAAIAABugA1+N1IAAh5MAr9AAAIAAB5gA1+IrIAAhuMAr9AAAIAABugA1+DhIAAhuMAr9AAAIAABugA1+hnIAAhuMAr9AAAIAABugA1+mxIAAhuMAr9AAAIAABugA1+r7IAAhuMAr9AAAIAABugA1+xFIAAhuMAr9AAAIAABug");
	this.shape_62.setTransform(247.1,131);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.lf(["rgba(64,63,69,0)","#403F45"],[0,1],-136,-108.6,29.1,-108.6).s().p("A1+S0IAAhuMAr9AAAIAABugA1+N1IAAh5MAr9AAAIAAB5gA1+IrIAAhuMAr9AAAIAABugA1+DhIAAhuMAr9AAAIAABugA1+hnIAAhuMAr9AAAIAABugA1+mxIAAhuMAr9AAAIAABugA1+r7IAAhuMAr9AAAIAABugA1+xFIAAhuMAr9AAAIAABug");
	this.shape_63.setTransform(247.1,131);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.lf(["rgba(64,63,69,0)","#403F45"],[0,1],-131.9,-108.7,30.6,-108.7).s().p("A1+S0IAAhuMAr9AAAIAABugA1+N1IAAh5MAr9AAAIAAB5gA1+IrIAAhuMAr9AAAIAABugA1+DhIAAhuMAr9AAAIAABugA1+hnIAAhuMAr9AAAIAABugA1+mxIAAhuMAr9AAAIAABugA1+r7IAAhuMAr9AAAIAABugA1+xFIAAhuMAr9AAAIAABug");
	this.shape_64.setTransform(247.1,131);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.lf(["rgba(64,63,69,0)","#403F45"],[0,1],-127.7,-108.7,32.1,-108.7).s().p("A1+S0IAAhuMAr9AAAIAABugA1+N1IAAh5MAr9AAAIAAB5gA1+IrIAAhuMAr9AAAIAABugA1+DhIAAhuMAr9AAAIAABugA1+hnIAAhuMAr9AAAIAABugA1+mxIAAhuMAr9AAAIAABugA1+r7IAAhuMAr9AAAIAABugA1+xFIAAhuMAr9AAAIAABug");
	this.shape_65.setTransform(247.1,131);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.lf(["rgba(64,63,69,0)","#403F45"],[0,1],-123.6,-108.8,33.6,-108.8).s().p("A1+S0IAAhuMAr9AAAIAABugA1+N1IAAh5MAr9AAAIAAB5gA1+IrIAAhuMAr9AAAIAABugA1+DhIAAhuMAr9AAAIAABugA1+hnIAAhuMAr9AAAIAABugA1+mxIAAhuMAr9AAAIAABugA1+r7IAAhuMAr9AAAIAABugA1+xFIAAhuMAr9AAAIAABug");
	this.shape_66.setTransform(247.1,131);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.lf(["rgba(64,63,69,0)","#403F45"],[0,1],-119.5,-108.9,35,-108.9).s().p("A1+S0IAAhuMAr9AAAIAABugA1+N1IAAh5MAr9AAAIAAB5gA1+IrIAAhuMAr9AAAIAABugA1+DhIAAhuMAr9AAAIAABugA1+hnIAAhuMAr9AAAIAABugA1+mxIAAhuMAr9AAAIAABugA1+r7IAAhuMAr9AAAIAABugA1+xFIAAhuMAr9AAAIAABug");
	this.shape_67.setTransform(247.1,131);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.lf(["rgba(64,63,69,0)","#403F45"],[0,1],-115.3,-108.9,36.6,-108.9).s().p("A1+S0IAAhuMAr9AAAIAABugA1+N1IAAh5MAr9AAAIAAB5gA1+IrIAAhuMAr9AAAIAABugA1+DhIAAhuMAr9AAAIAABugA1+hnIAAhuMAr9AAAIAABugA1+mxIAAhuMAr9AAAIAABugA1+r7IAAhuMAr9AAAIAABugA1+xFIAAhuMAr9AAAIAABug");
	this.shape_68.setTransform(247.1,131);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.lf(["rgba(64,63,69,0)","#403F45"],[0,1],-111.2,-109,38,-109).s().p("A1+S0IAAhuMAr9AAAIAABugA1+N1IAAh5MAr9AAAIAAB5gA1+IrIAAhuMAr9AAAIAABugA1+DhIAAhuMAr9AAAIAABugA1+hnIAAhuMAr9AAAIAABugA1+mxIAAhuMAr9AAAIAABugA1+r7IAAhuMAr9AAAIAABugA1+xFIAAhuMAr9AAAIAABug");
	this.shape_69.setTransform(247.1,131);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.lf(["rgba(64,63,69,0)","#403F45"],[0,1],-107.1,-109.1,39.5,-109.1).s().p("A1+S0IAAhuMAr9AAAIAABugA1+N1IAAh5MAr9AAAIAAB5gA1+IrIAAhuMAr9AAAIAABugA1+DhIAAhuMAr9AAAIAABugA1+hnIAAhuMAr9AAAIAABugA1+mxIAAhuMAr9AAAIAABugA1+r7IAAhuMAr9AAAIAABugA1+xFIAAhuMAr9AAAIAABug");
	this.shape_70.setTransform(247.1,131);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.lf(["rgba(64,63,69,0)","#403F45"],[0,1],-102.9,-109.1,41.1,-109.1).s().p("A1+S0IAAhuMAr9AAAIAABugA1+N1IAAh5MAr9AAAIAAB5gA1+IrIAAhuMAr9AAAIAABugA1+DhIAAhuMAr9AAAIAABugA1+hnIAAhuMAr9AAAIAABugA1+mxIAAhuMAr9AAAIAABugA1+r7IAAhuMAr9AAAIAABugA1+xFIAAhuMAr9AAAIAABug");
	this.shape_71.setTransform(247.1,131);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.lf(["rgba(64,63,69,0)","#403F45"],[0,1],-98.8,-109.2,42.5,-109.2).s().p("A1+S0IAAhuMAr9AAAIAABugA1+N1IAAh5MAr9AAAIAAB5gA1+IrIAAhuMAr9AAAIAABugA1+DhIAAhuMAr9AAAIAABugA1+hnIAAhuMAr9AAAIAABugA1+mxIAAhuMAr9AAAIAABugA1+r7IAAhuMAr9AAAIAABugA1+xFIAAhuMAr9AAAIAABug");
	this.shape_72.setTransform(247.1,131);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.lf(["rgba(64,63,69,0)","#403F45"],[0,1],-94.6,-109.3,44.1,-109.3).s().p("A1+S0IAAhuMAr9AAAIAABugA1+N1IAAh5MAr9AAAIAAB5gA1+IrIAAhuMAr9AAAIAABugA1+DhIAAhuMAr9AAAIAABugA1+hnIAAhuMAr9AAAIAABugA1+mxIAAhuMAr9AAAIAABugA1+r7IAAhuMAr9AAAIAABugA1+xFIAAhuMAr9AAAIAABug");
	this.shape_73.setTransform(247.1,131);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.lf(["rgba(64,63,69,0)","#403F45"],[0,1],-90.5,-109.3,45.5,-109.3).s().p("A1+S0IAAhuMAr9AAAIAABugA1+N1IAAh5MAr9AAAIAAB5gA1+IrIAAhuMAr9AAAIAABugA1+DhIAAhuMAr9AAAIAABugA1+hnIAAhuMAr9AAAIAABugA1+mxIAAhuMAr9AAAIAABugA1+r7IAAhuMAr9AAAIAABugA1+xFIAAhuMAr9AAAIAABug");
	this.shape_74.setTransform(247.1,131);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.lf(["rgba(64,63,69,0)","#403F45"],[0,1],-86.4,-109.4,47,-109.4).s().p("A1+S0IAAhuMAr9AAAIAABugA1+N1IAAh5MAr9AAAIAAB5gA1+IrIAAhuMAr9AAAIAABugA1+DhIAAhuMAr9AAAIAABugA1+hnIAAhuMAr9AAAIAABugA1+mxIAAhuMAr9AAAIAABugA1+r7IAAhuMAr9AAAIAABugA1+xFIAAhuMAr9AAAIAABug");
	this.shape_75.setTransform(247.1,131);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.lf(["rgba(64,63,69,0)","#403F45"],[0,1],-82.2,-109.5,48.5,-109.5).s().p("A1+S0IAAhuMAr9AAAIAABugA1+N1IAAh5MAr9AAAIAAB5gA1+IrIAAhuMAr9AAAIAABugA1+DhIAAhuMAr9AAAIAABugA1+hnIAAhuMAr9AAAIAABugA1+mxIAAhuMAr9AAAIAABugA1+r7IAAhuMAr9AAAIAABugA1+xFIAAhuMAr9AAAIAABug");
	this.shape_76.setTransform(247.1,131);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.lf(["rgba(64,63,69,0)","#403F45"],[0,1],-78.1,-109.5,50,-109.5).s().p("A1+S0IAAhuMAr9AAAIAABugA1+N1IAAh5MAr9AAAIAAB5gA1+IrIAAhuMAr9AAAIAABugA1+DhIAAhuMAr9AAAIAABugA1+hnIAAhuMAr9AAAIAABugA1+mxIAAhuMAr9AAAIAABugA1+r7IAAhuMAr9AAAIAABugA1+xFIAAhuMAr9AAAIAABug");
	this.shape_77.setTransform(247.1,131);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.lf(["rgba(64,63,69,0)","#403F45"],[0,1],-73.9,-109.6,51.5,-109.6).s().p("A1+S0IAAhuMAr9AAAIAABugA1+N1IAAh5MAr9AAAIAAB5gA1+IrIAAhuMAr9AAAIAABugA1+DhIAAhuMAr9AAAIAABugA1+hnIAAhuMAr9AAAIAABugA1+mxIAAhuMAr9AAAIAABugA1+r7IAAhuMAr9AAAIAABugA1+xFIAAhuMAr9AAAIAABug");
	this.shape_78.setTransform(247.1,131);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.lf(["rgba(64,63,69,0)","#403F45"],[0,1],-69.8,-109.7,53,-109.7).s().p("A1+S0IAAhuMAr9AAAIAABugA1+N1IAAh5MAr9AAAIAAB5gA1+IrIAAhuMAr9AAAIAABugA1+DhIAAhuMAr9AAAIAABugA1+hnIAAhuMAr9AAAIAABugA1+mxIAAhuMAr9AAAIAABugA1+r7IAAhuMAr9AAAIAABugA1+xFIAAhuMAr9AAAIAABug");
	this.shape_79.setTransform(247.1,131);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.lf(["rgba(64,63,69,0)","#403F45"],[0,1],-65.6,-109.7,54.5,-109.7).s().p("A1+S0IAAhuMAr9AAAIAABugA1+N1IAAh5MAr9AAAIAAB5gA1+IrIAAhuMAr9AAAIAABugA1+DhIAAhuMAr9AAAIAABugA1+hnIAAhuMAr9AAAIAABugA1+mxIAAhuMAr9AAAIAABugA1+r7IAAhuMAr9AAAIAABugA1+xFIAAhuMAr9AAAIAABug");
	this.shape_80.setTransform(247.1,131);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.lf(["rgba(64,63,69,0)","#403F45"],[0,1],-61.5,-109.8,56,-109.8).s().p("A1+S0IAAhuMAr9AAAIAABugA1+N1IAAh5MAr9AAAIAAB5gA1+IrIAAhuMAr9AAAIAABugA1+DhIAAhuMAr9AAAIAABugA1+hnIAAhuMAr9AAAIAABugA1+mxIAAhuMAr9AAAIAABugA1+r7IAAhuMAr9AAAIAABugA1+xFIAAhuMAr9AAAIAABug");
	this.shape_81.setTransform(247.1,131);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.lf(["rgba(64,63,69,0)","#403F45"],[0,1],-57.4,-109.9,57.5,-109.9).s().p("A1+S0IAAhuMAr9AAAIAABugA1+N1IAAh5MAr9AAAIAAB5gA1+IrIAAhuMAr9AAAIAABugA1+DhIAAhuMAr9AAAIAABugA1+hnIAAhuMAr9AAAIAABugA1+mxIAAhuMAr9AAAIAABugA1+r7IAAhuMAr9AAAIAABugA1+xFIAAhuMAr9AAAIAABug");
	this.shape_82.setTransform(247.1,131);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.lf(["rgba(64,63,69,0)","#403F45"],[0,1],-53.2,-109.9,59,-109.9).s().p("A1+S0IAAhuMAr9AAAIAABugA1+N1IAAh5MAr9AAAIAAB5gA1+IrIAAhuMAr9AAAIAABugA1+DhIAAhuMAr9AAAIAABugA1+hnIAAhuMAr9AAAIAABugA1+mxIAAhuMAr9AAAIAABugA1+r7IAAhuMAr9AAAIAABugA1+xFIAAhuMAr9AAAIAABug");
	this.shape_83.setTransform(247.1,131);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.lf(["rgba(64,63,69,0)","#403F45"],[0,1],-49,-110,60.5,-110).s().p("A1+S0IAAhuMAr9AAAIAABugA1+N1IAAh5MAr9AAAIAAB5gA1+IrIAAhuMAr9AAAIAABugA1+DhIAAhuMAr9AAAIAABugA1+hnIAAhuMAr9AAAIAABugA1+mxIAAhuMAr9AAAIAABugA1+r7IAAhuMAr9AAAIAABugA1+xFIAAhuMAr9AAAIAABug");
	this.shape_84.setTransform(247.1,131);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.lf(["rgba(64,63,69,0)","#403F45"],[0,1],-44.9,-110.1,62,-110.1).s().p("A1+S0IAAhuMAr9AAAIAABugA1+N1IAAh5MAr9AAAIAAB5gA1+IrIAAhuMAr9AAAIAABugA1+DhIAAhuMAr9AAAIAABugA1+hnIAAhuMAr9AAAIAABugA1+mxIAAhuMAr9AAAIAABugA1+r7IAAhuMAr9AAAIAABugA1+xFIAAhuMAr9AAAIAABug");
	this.shape_85.setTransform(247.1,131);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.lf(["rgba(64,63,69,0)","#403F45"],[0,1],-40.8,-110.1,63.5,-110.1).s().p("A1+S0IAAhuMAr9AAAIAABugA1+N1IAAh5MAr9AAAIAAB5gA1+IrIAAhuMAr9AAAIAABugA1+DhIAAhuMAr9AAAIAABugA1+hnIAAhuMAr9AAAIAABugA1+mxIAAhuMAr9AAAIAABugA1+r7IAAhuMAr9AAAIAABugA1+xFIAAhuMAr9AAAIAABug");
	this.shape_86.setTransform(247.1,131);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.lf(["rgba(64,63,69,0)","#403F45"],[0,1],-36.6,-110.2,65,-110.2).s().p("A1+S0IAAhuMAr9AAAIAABugA1+N1IAAh5MAr9AAAIAAB5gA1+IrIAAhuMAr9AAAIAABugA1+DhIAAhuMAr9AAAIAABugA1+hnIAAhuMAr9AAAIAABugA1+mxIAAhuMAr9AAAIAABugA1+r7IAAhuMAr9AAAIAABugA1+xFIAAhuMAr9AAAIAABug");
	this.shape_87.setTransform(247.1,131);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.lf(["rgba(64,63,69,0)","#403F45"],[0,1],-32.5,-110.3,66.5,-110.3).s().p("A1+S0IAAhuMAr9AAAIAABugA1+N1IAAh5MAr9AAAIAAB5gA1+IrIAAhuMAr9AAAIAABugA1+DhIAAhuMAr9AAAIAABugA1+hnIAAhuMAr9AAAIAABugA1+mxIAAhuMAr9AAAIAABugA1+r7IAAhuMAr9AAAIAABugA1+xFIAAhuMAr9AAAIAABug");
	this.shape_88.setTransform(247.1,131);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.lf(["rgba(64,63,69,0)","#403F45"],[0,1],-28.4,-110.3,67.9,-110.3).s().p("A1+S0IAAhuMAr9AAAIAABugA1+N1IAAh5MAr9AAAIAAB5gA1+IrIAAhuMAr9AAAIAABugA1+DhIAAhuMAr9AAAIAABugA1+hnIAAhuMAr9AAAIAABugA1+mxIAAhuMAr9AAAIAABugA1+r7IAAhuMAr9AAAIAABugA1+xFIAAhuMAr9AAAIAABug");
	this.shape_89.setTransform(247.1,131);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.lf(["rgba(64,63,69,0)","#403F45"],[0,1],-24.2,-110.4,69.5,-110.4).s().p("A1+S0IAAhuMAr9AAAIAABugA1+N1IAAh5MAr9AAAIAAB5gA1+IrIAAhuMAr9AAAIAABugA1+DhIAAhuMAr9AAAIAABugA1+hnIAAhuMAr9AAAIAABugA1+mxIAAhuMAr9AAAIAABugA1+r7IAAhuMAr9AAAIAABugA1+xFIAAhuMAr9AAAIAABug");
	this.shape_90.setTransform(247.1,131);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.lf(["rgba(64,63,69,0)","#403F45"],[0,1],-20.1,-110.5,71,-110.5).s().p("A1+S0IAAhuMAr9AAAIAABugA1+N1IAAh5MAr9AAAIAAB5gA1+IrIAAhuMAr9AAAIAABugA1+DhIAAhuMAr9AAAIAABugA1+hnIAAhuMAr9AAAIAABugA1+mxIAAhuMAr9AAAIAABugA1+r7IAAhuMAr9AAAIAABugA1+xFIAAhuMAr9AAAIAABug");
	this.shape_91.setTransform(247.1,131);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.lf(["rgba(64,63,69,0)","#403F45"],[0,1],-16,-110.6,72.4,-110.6).s().p("A1+S0IAAhuMAr9AAAIAABugA1+N1IAAh5MAr9AAAIAAB5gA1+IrIAAhuMAr9AAAIAABugA1+DhIAAhuMAr9AAAIAABugA1+hnIAAhuMAr9AAAIAABugA1+mxIAAhuMAr9AAAIAABugA1+r7IAAhuMAr9AAAIAABugA1+xFIAAhuMAr9AAAIAABug");
	this.shape_92.setTransform(247.1,131);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.lf(["rgba(64,63,69,0)","#403F45"],[0,1],-11.8,-110.6,74,-110.6).s().p("A1+S0IAAhuMAr9AAAIAABugA1+N1IAAh5MAr9AAAIAAB5gA1+IrIAAhuMAr9AAAIAABugA1+DhIAAhuMAr9AAAIAABugA1+hnIAAhuMAr9AAAIAABugA1+mxIAAhuMAr9AAAIAABugA1+r7IAAhuMAr9AAAIAABugA1+xFIAAhuMAr9AAAIAABug");
	this.shape_93.setTransform(247.1,131);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.lf(["rgba(64,63,69,0)","#403F45"],[0,1],-7.7,-110.7,75.4,-110.7).s().p("A1+S0IAAhuMAr9AAAIAABugA1+N1IAAh5MAr9AAAIAAB5gA1+IrIAAhuMAr9AAAIAABugA1+DhIAAhuMAr9AAAIAABugA1+hnIAAhuMAr9AAAIAABugA1+mxIAAhuMAr9AAAIAABugA1+r7IAAhuMAr9AAAIAABugA1+xFIAAhuMAr9AAAIAABug");
	this.shape_94.setTransform(247.1,131);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.lf(["rgba(64,63,69,0)","#403F45"],[0,1],-3.5,-110.8,77,-110.8).s().p("A1+S0IAAhuMAr9AAAIAABugA1+N1IAAh5MAr9AAAIAAB5gA1+IrIAAhuMAr9AAAIAABugA1+DhIAAhuMAr9AAAIAABugA1+hnIAAhuMAr9AAAIAABugA1+mxIAAhuMAr9AAAIAABugA1+r7IAAhuMAr9AAAIAABugA1+xFIAAhuMAr9AAAIAABug");
	this.shape_95.setTransform(247.1,131);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.lf(["rgba(64,63,69,0)","#403F45"],[0,1],0.6,-110.8,78.4,-110.8).s().p("A1+S0IAAhuMAr9AAAIAABugA1+N1IAAh5MAr9AAAIAAB5gA1+IrIAAhuMAr9AAAIAABugA1+DhIAAhuMAr9AAAIAABugA1+hnIAAhuMAr9AAAIAABugA1+mxIAAhuMAr9AAAIAABugA1+r7IAAhuMAr9AAAIAABugA1+xFIAAhuMAr9AAAIAABug");
	this.shape_96.setTransform(247.1,131);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.lf(["rgba(64,63,69,0)","#403F45"],[0,1],4.7,-110.9,79.9,-110.9).s().p("A1+S0IAAhuMAr9AAAIAABugA1+N1IAAh5MAr9AAAIAAB5gA1+IrIAAhuMAr9AAAIAABugA1+DhIAAhuMAr9AAAIAABugA1+hnIAAhuMAr9AAAIAABugA1+mxIAAhuMAr9AAAIAABugA1+r7IAAhuMAr9AAAIAABugA1+xFIAAhuMAr9AAAIAABug");
	this.shape_97.setTransform(247.1,131);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.lf(["rgba(64,63,69,0)","#403F45"],[0,1],8.9,-111,81.5,-111).s().p("A1+S0IAAhuMAr9AAAIAABugA1+N1IAAh5MAr9AAAIAAB5gA1+IrIAAhuMAr9AAAIAABugA1+DhIAAhuMAr9AAAIAABugA1+hnIAAhuMAr9AAAIAABugA1+mxIAAhuMAr9AAAIAABugA1+r7IAAhuMAr9AAAIAABugA1+xFIAAhuMAr9AAAIAABug");
	this.shape_98.setTransform(247.1,131);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_35}]},1).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_37}]},1).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_42}]},1).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_44}]},1).to({state:[{t:this.shape_45}]},1).to({state:[{t:this.shape_46}]},1).to({state:[{t:this.shape_47}]},1).to({state:[{t:this.shape_48}]},1).to({state:[{t:this.shape_49}]},1).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_52}]},1).to({state:[{t:this.shape_53}]},1).to({state:[{t:this.shape_54}]},1).to({state:[{t:this.shape_55}]},1).to({state:[{t:this.shape_56}]},1).to({state:[{t:this.shape_57}]},1).to({state:[{t:this.shape_58}]},1).to({state:[{t:this.shape_59}]},1).to({state:[{t:this.shape_60}]},1).to({state:[{t:this.shape_61}]},1).to({state:[{t:this.shape_62}]},1).to({state:[{t:this.shape_63}]},1).to({state:[{t:this.shape_64}]},1).to({state:[{t:this.shape_65}]},1).to({state:[{t:this.shape_66}]},1).to({state:[{t:this.shape_67}]},1).to({state:[{t:this.shape_68}]},1).to({state:[{t:this.shape_69}]},1).to({state:[{t:this.shape_70}]},1).to({state:[{t:this.shape_71}]},1).to({state:[{t:this.shape_72}]},1).to({state:[{t:this.shape_73}]},1).to({state:[{t:this.shape_74}]},1).to({state:[{t:this.shape_75}]},1).to({state:[{t:this.shape_76}]},1).to({state:[{t:this.shape_77}]},1).to({state:[{t:this.shape_78}]},1).to({state:[{t:this.shape_79}]},1).to({state:[{t:this.shape_80}]},1).to({state:[{t:this.shape_81}]},1).to({state:[{t:this.shape_82}]},1).to({state:[{t:this.shape_83}]},1).to({state:[{t:this.shape_84}]},1).to({state:[{t:this.shape_85}]},1).to({state:[{t:this.shape_86}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_88}]},1).to({state:[{t:this.shape_89}]},1).to({state:[{t:this.shape_90}]},1).to({state:[{t:this.shape_91}]},1).to({state:[{t:this.shape_92}]},1).to({state:[{t:this.shape_93}]},1).to({state:[{t:this.shape_94}]},1).to({state:[{t:this.shape_95}]},1).to({state:[{t:this.shape_96}]},1).to({state:[{t:this.shape_97}]},1).to({state:[{t:this.shape_98}]},1).to({state:[]},1).wait(19));

	// Ebene 6
	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.lf(["rgba(115,114,120,0)","#737278"],[0,1],-403.2,-97.4,-139.2,-97.4).s().p("A1+RGIAAjRICvAAIAAm4IivAAIAAjcICvAAIAAm2IivAAIAAjcICvAAIAAlKIivAAIAAlKMApOAAAIAAFKICvAAIAADcIivAAIAAG4ICvAAIAADaIivAAIAAG4ICvAAIAADRIivAAIAAFKg");
	this.shape_99.setTransform(247.1,131);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.lf(["rgba(115,114,120,0)","#737278"],[0,1],-399.3,-97.4,-135.3,-97.4).s().p("A1+RGIAAjRICvAAIAAm4IivAAIAAjcICvAAIAAm2IivAAIAAjcICvAAIAAlKIivAAIAAlKMApOAAAIAAFKICvAAIAADcIivAAIAAG4ICvAAIAADaIivAAIAAG4ICvAAIAADRIivAAIAAFKg");
	this.shape_100.setTransform(247.1,131);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.lf(["rgba(115,114,120,0)","#737278"],[0,1],-395.5,-97.5,-131.5,-97.5).s().p("A1+RGIAAjRICvAAIAAm4IivAAIAAjcICvAAIAAm2IivAAIAAjcICvAAIAAlKIivAAIAAlKMApOAAAIAAFKICvAAIAADcIivAAIAAG4ICvAAIAADaIivAAIAAG4ICvAAIAADRIivAAIAAFKg");
	this.shape_101.setTransform(247.1,131);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.lf(["rgba(115,114,120,0)","#737278"],[0,1],-391.6,-97.5,-127.6,-97.5).s().p("A1+RGIAAjRICvAAIAAm4IivAAIAAjcICvAAIAAm2IivAAIAAjcICvAAIAAlKIivAAIAAlKMApOAAAIAAFKICvAAIAADcIivAAIAAG4ICvAAIAADaIivAAIAAG4ICvAAIAADRIivAAIAAFKg");
	this.shape_102.setTransform(247.1,131);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.lf(["rgba(115,114,120,0)","#737278"],[0,1],-387.7,-97.5,-123.7,-97.5).s().p("A1+RGIAAjRICvAAIAAm4IivAAIAAjcICvAAIAAm2IivAAIAAjcICvAAIAAlKIivAAIAAlKMApOAAAIAAFKICvAAIAADcIivAAIAAG4ICvAAIAADaIivAAIAAG4ICvAAIAADRIivAAIAAFKg");
	this.shape_103.setTransform(247.1,131);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.lf(["rgba(115,114,120,0)","#737278"],[0,1],-383.8,-97.5,-119.8,-97.5).s().p("A1+RGIAAjRICvAAIAAm4IivAAIAAjcICvAAIAAm2IivAAIAAjcICvAAIAAlKIivAAIAAlKMApOAAAIAAFKICvAAIAADcIivAAIAAG4ICvAAIAADaIivAAIAAG4ICvAAIAADRIivAAIAAFKg");
	this.shape_104.setTransform(247.1,131);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.lf(["rgba(115,114,120,0)","#737278"],[0,1],-379.9,-97.5,-115.9,-97.5).s().p("A1+RGIAAjRICvAAIAAm4IivAAIAAjcICvAAIAAm2IivAAIAAjcICvAAIAAlKIivAAIAAlKMApOAAAIAAFKICvAAIAADcIivAAIAAG4ICvAAIAADaIivAAIAAG4ICvAAIAADRIivAAIAAFKg");
	this.shape_105.setTransform(247.1,131);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.lf(["rgba(115,114,120,0)","#737278"],[0,1],-376,-97.5,-112,-97.5).s().p("A1+RGIAAjRICvAAIAAm4IivAAIAAjcICvAAIAAm2IivAAIAAjcICvAAIAAlKIivAAIAAlKMApOAAAIAAFKICvAAIAADcIivAAIAAG4ICvAAIAADaIivAAIAAG4ICvAAIAADRIivAAIAAFKg");
	this.shape_106.setTransform(247.1,131);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.lf(["rgba(115,114,120,0)","#737278"],[0,1],-372.2,-97.5,-108.2,-97.5).s().p("A1+RGIAAjRICvAAIAAm4IivAAIAAjcICvAAIAAm2IivAAIAAjcICvAAIAAlKIivAAIAAlKMApOAAAIAAFKICvAAIAADcIivAAIAAG4ICvAAIAADaIivAAIAAG4ICvAAIAADRIivAAIAAFKg");
	this.shape_107.setTransform(247.1,131);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.lf(["rgba(115,114,120,0)","#737278"],[0,1],-368.3,-97.5,-104.3,-97.5).s().p("A1+RGIAAjRICvAAIAAm4IivAAIAAjcICvAAIAAm2IivAAIAAjcICvAAIAAlKIivAAIAAlKMApOAAAIAAFKICvAAIAADcIivAAIAAG4ICvAAIAADaIivAAIAAG4ICvAAIAADRIivAAIAAFKg");
	this.shape_108.setTransform(247.1,131);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.lf(["rgba(115,114,120,0)","#737278"],[0,1],-364.4,-97.6,-100.4,-97.6).s().p("A1+RGIAAjRICvAAIAAm4IivAAIAAjcICvAAIAAm2IivAAIAAjcICvAAIAAlKIivAAIAAlKMApOAAAIAAFKICvAAIAADcIivAAIAAG4ICvAAIAADaIivAAIAAG4ICvAAIAADRIivAAIAAFKg");
	this.shape_109.setTransform(247.1,131);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.lf(["rgba(115,114,120,0)","#737278"],[0,1],-360.5,-97.6,-96.5,-97.6).s().p("A1+RGIAAjRICvAAIAAm4IivAAIAAjcICvAAIAAm2IivAAIAAjcICvAAIAAlKIivAAIAAlKMApOAAAIAAFKICvAAIAADcIivAAIAAG4ICvAAIAADaIivAAIAAG4ICvAAIAADRIivAAIAAFKg");
	this.shape_110.setTransform(247.1,131);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.lf(["rgba(115,114,120,0)","#737278"],[0,1],-356.6,-97.6,-92.6,-97.6).s().p("A1+RGIAAjRICvAAIAAm4IivAAIAAjcICvAAIAAm2IivAAIAAjcICvAAIAAlKIivAAIAAlKMApOAAAIAAFKICvAAIAADcIivAAIAAG4ICvAAIAADaIivAAIAAG4ICvAAIAADRIivAAIAAFKg");
	this.shape_111.setTransform(247.1,131);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.lf(["rgba(115,114,120,0)","#737278"],[0,1],-352.7,-97.6,-88.7,-97.6).s().p("A1+RGIAAjRICvAAIAAm4IivAAIAAjcICvAAIAAm2IivAAIAAjcICvAAIAAlKIivAAIAAlKMApOAAAIAAFKICvAAIAADcIivAAIAAG4ICvAAIAADaIivAAIAAG4ICvAAIAADRIivAAIAAFKg");
	this.shape_112.setTransform(247.1,131);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.lf(["rgba(115,114,120,0)","#737278"],[0,1],-348.8,-97.6,-84.8,-97.6).s().p("A1+RGIAAjRICvAAIAAm4IivAAIAAjcICvAAIAAm2IivAAIAAjcICvAAIAAlKIivAAIAAlKMApOAAAIAAFKICvAAIAADcIivAAIAAG4ICvAAIAADaIivAAIAAG4ICvAAIAADRIivAAIAAFKg");
	this.shape_113.setTransform(247.1,131);

	this.shape_114 = new cjs.Shape();
	this.shape_114.graphics.lf(["rgba(115,114,120,0)","#737278"],[0,1],-345,-97.6,-81,-97.6).s().p("A1+RGIAAjRICvAAIAAm4IivAAIAAjcICvAAIAAm2IivAAIAAjcICvAAIAAlKIivAAIAAlKMApOAAAIAAFKICvAAIAADcIivAAIAAG4ICvAAIAADaIivAAIAAG4ICvAAIAADRIivAAIAAFKg");
	this.shape_114.setTransform(247.1,131);

	this.shape_115 = new cjs.Shape();
	this.shape_115.graphics.lf(["rgba(115,114,120,0)","#737278"],[0,1],-341.1,-97.6,-77.1,-97.6).s().p("A1+RGIAAjRICvAAIAAm4IivAAIAAjcICvAAIAAm2IivAAIAAjcICvAAIAAlKIivAAIAAlKMApOAAAIAAFKICvAAIAADcIivAAIAAG4ICvAAIAADaIivAAIAAG4ICvAAIAADRIivAAIAAFKg");
	this.shape_115.setTransform(247.1,131);

	this.shape_116 = new cjs.Shape();
	this.shape_116.graphics.lf(["rgba(115,114,120,0)","#737278"],[0,1],-337.2,-97.6,-73.2,-97.6).s().p("A1+RGIAAjRICvAAIAAm4IivAAIAAjcICvAAIAAm2IivAAIAAjcICvAAIAAlKIivAAIAAlKMApOAAAIAAFKICvAAIAADcIivAAIAAG4ICvAAIAADaIivAAIAAG4ICvAAIAADRIivAAIAAFKg");
	this.shape_116.setTransform(247.1,131);

	this.shape_117 = new cjs.Shape();
	this.shape_117.graphics.lf(["rgba(115,114,120,0)","#737278"],[0,1],-333.3,-97.7,-69.3,-97.7).s().p("A1+RGIAAjRICvAAIAAm4IivAAIAAjcICvAAIAAm2IivAAIAAjcICvAAIAAlKIivAAIAAlKMApOAAAIAAFKICvAAIAADcIivAAIAAG4ICvAAIAADaIivAAIAAG4ICvAAIAADRIivAAIAAFKg");
	this.shape_117.setTransform(247.1,131);

	this.shape_118 = new cjs.Shape();
	this.shape_118.graphics.lf(["rgba(115,114,120,0)","#737278"],[0,1],-329.4,-97.7,-65.4,-97.7).s().p("A1+RGIAAjRICvAAIAAm4IivAAIAAjcICvAAIAAm2IivAAIAAjcICvAAIAAlKIivAAIAAlKMApOAAAIAAFKICvAAIAADcIivAAIAAG4ICvAAIAADaIivAAIAAG4ICvAAIAADRIivAAIAAFKg");
	this.shape_118.setTransform(247.1,131);

	this.shape_119 = new cjs.Shape();
	this.shape_119.graphics.lf(["rgba(115,114,120,0)","#737278"],[0,1],-324.9,-97.9,-62.9,-97.9).s().p("A1+RGIAAjRICvAAIAAm4IivAAIAAjcICvAAIAAm2IivAAIAAjcICvAAIAAlKIivAAIAAlKMApOAAAIAAFKICvAAIAADcIivAAIAAG4ICvAAIAADaIivAAIAAG4ICvAAIAADRIivAAIAAFKg");
	this.shape_119.setTransform(247.1,131);

	this.shape_120 = new cjs.Shape();
	this.shape_120.graphics.lf(["rgba(115,114,120,0)","#737278"],[0,1],-320.4,-98.1,-60.4,-98.1).s().p("A1+RGIAAjRICvAAIAAm4IivAAIAAjcICvAAIAAm2IivAAIAAjcICvAAIAAlKIivAAIAAlKMApOAAAIAAFKICvAAIAADcIivAAIAAG4ICvAAIAADaIivAAIAAG4ICvAAIAADRIivAAIAAFKg");
	this.shape_120.setTransform(247.1,131);

	this.shape_121 = new cjs.Shape();
	this.shape_121.graphics.lf(["rgba(115,114,120,0)","#737278"],[0,1],-315.9,-98.3,-58,-98.3).s().p("A1+RGIAAjRICvAAIAAm4IivAAIAAjcICvAAIAAm2IivAAIAAjcICvAAIAAlKIivAAIAAlKMApOAAAIAAFKICvAAIAADcIivAAIAAG4ICvAAIAADaIivAAIAAG4ICvAAIAADRIivAAIAAFKg");
	this.shape_121.setTransform(247.1,131);

	this.shape_122 = new cjs.Shape();
	this.shape_122.graphics.lf(["rgba(115,114,120,0)","#737278"],[0,1],-311.4,-98.5,-55.5,-98.5).s().p("A1+RGIAAjRICvAAIAAm4IivAAIAAjcICvAAIAAm2IivAAIAAjcICvAAIAAlKIivAAIAAlKMApOAAAIAAFKICvAAIAADcIivAAIAAG4ICvAAIAADaIivAAIAAG4ICvAAIAADRIivAAIAAFKg");
	this.shape_122.setTransform(247.1,131);

	this.shape_123 = new cjs.Shape();
	this.shape_123.graphics.lf(["rgba(115,114,120,0)","#737278"],[0,1],-306.8,-98.7,-52.9,-98.7).s().p("A1+RGIAAjRICvAAIAAm4IivAAIAAjcICvAAIAAm2IivAAIAAjcICvAAIAAlKIivAAIAAlKMApOAAAIAAFKICvAAIAADcIivAAIAAG4ICvAAIAADaIivAAIAAG4ICvAAIAADRIivAAIAAFKg");
	this.shape_123.setTransform(247.1,131);

	this.shape_124 = new cjs.Shape();
	this.shape_124.graphics.lf(["rgba(115,114,120,0)","#737278"],[0,1],-302.3,-98.9,-50.5,-98.9).s().p("A1+RGIAAjRICvAAIAAm4IivAAIAAjcICvAAIAAm2IivAAIAAjcICvAAIAAlKIivAAIAAlKMApOAAAIAAFKICvAAIAADcIivAAIAAG4ICvAAIAADaIivAAIAAG4ICvAAIAADRIivAAIAAFKg");
	this.shape_124.setTransform(247.1,131);

	this.shape_125 = new cjs.Shape();
	this.shape_125.graphics.lf(["rgba(115,114,120,0)","#737278"],[0,1],-297.8,-99.1,-48,-99.1).s().p("A1+RGIAAjRICvAAIAAm4IivAAIAAjcICvAAIAAm2IivAAIAAjcICvAAIAAlKIivAAIAAlKMApOAAAIAAFKICvAAIAADcIivAAIAAG4ICvAAIAADaIivAAIAAG4ICvAAIAADRIivAAIAAFKg");
	this.shape_125.setTransform(247.1,131);

	this.shape_126 = new cjs.Shape();
	this.shape_126.graphics.lf(["rgba(115,114,120,0)","#737278"],[0,1],-293.3,-99.3,-45.5,-99.3).s().p("A1+RGIAAjRICvAAIAAm4IivAAIAAjcICvAAIAAm2IivAAIAAjcICvAAIAAlKIivAAIAAlKMApOAAAIAAFKICvAAIAADcIivAAIAAG4ICvAAIAADaIivAAIAAG4ICvAAIAADRIivAAIAAFKg");
	this.shape_126.setTransform(247.1,131);

	this.shape_127 = new cjs.Shape();
	this.shape_127.graphics.lf(["rgba(115,114,120,0)","#737278"],[0,1],-288.8,-99.5,-43,-99.5).s().p("A1+RGIAAjRICvAAIAAm4IivAAIAAjcICvAAIAAm2IivAAIAAjcICvAAIAAlKIivAAIAAlKMApOAAAIAAFKICvAAIAADcIivAAIAAG4ICvAAIAADaIivAAIAAG4ICvAAIAADRIivAAIAAFKg");
	this.shape_127.setTransform(247.1,131);

	this.shape_128 = new cjs.Shape();
	this.shape_128.graphics.lf(["rgba(115,114,120,0)","#737278"],[0,1],-284.2,-99.7,-40.5,-99.7).s().p("A1+RGIAAjRICvAAIAAm4IivAAIAAjcICvAAIAAm2IivAAIAAjcICvAAIAAlKIivAAIAAlKMApOAAAIAAFKICvAAIAADcIivAAIAAG4ICvAAIAADaIivAAIAAG4ICvAAIAADRIivAAIAAFKg");
	this.shape_128.setTransform(247.1,131);

	this.shape_129 = new cjs.Shape();
	this.shape_129.graphics.lf(["rgba(115,114,120,0)","#737278"],[0,1],-279.7,-100,-38,-100).s().p("A1+RGIAAjRICvAAIAAm4IivAAIAAjcICvAAIAAm2IivAAIAAjcICvAAIAAlKIivAAIAAlKMApOAAAIAAFKICvAAIAADcIivAAIAAG4ICvAAIAADaIivAAIAAG4ICvAAIAADRIivAAIAAFKg");
	this.shape_129.setTransform(247.1,131);

	this.shape_130 = new cjs.Shape();
	this.shape_130.graphics.lf(["rgba(115,114,120,0)","#737278"],[0,1],-275.2,-100.2,-35.5,-100.2).s().p("A1+RGIAAjRICvAAIAAm4IivAAIAAjcICvAAIAAm2IivAAIAAjcICvAAIAAlKIivAAIAAlKMApOAAAIAAFKICvAAIAADcIivAAIAAG4ICvAAIAADaIivAAIAAG4ICvAAIAADRIivAAIAAFKg");
	this.shape_130.setTransform(247.1,131);

	this.shape_131 = new cjs.Shape();
	this.shape_131.graphics.lf(["rgba(115,114,120,0)","#737278"],[0,1],-270.7,-100.4,-33,-100.4).s().p("A1+RGIAAjRICvAAIAAm4IivAAIAAjcICvAAIAAm2IivAAIAAjcICvAAIAAlKIivAAIAAlKMApOAAAIAAFKICvAAIAADcIivAAIAAG4ICvAAIAADaIivAAIAAG4ICvAAIAADRIivAAIAAFKg");
	this.shape_131.setTransform(247.1,131);

	this.shape_132 = new cjs.Shape();
	this.shape_132.graphics.lf(["rgba(115,114,120,0)","#737278"],[0,1],-266.2,-100.6,-30.5,-100.6).s().p("A1+RGIAAjRICvAAIAAm4IivAAIAAjcICvAAIAAm2IivAAIAAjcICvAAIAAlKIivAAIAAlKMApOAAAIAAFKICvAAIAADcIivAAIAAG4ICvAAIAADaIivAAIAAG4ICvAAIAADRIivAAIAAFKg");
	this.shape_132.setTransform(247.1,131);

	this.shape_133 = new cjs.Shape();
	this.shape_133.graphics.lf(["rgba(115,114,120,0)","#737278"],[0,1],-261.6,-100.8,-28,-100.8).s().p("A1+RGIAAjRICvAAIAAm4IivAAIAAjcICvAAIAAm2IivAAIAAjcICvAAIAAlKIivAAIAAlKMApOAAAIAAFKICvAAIAADcIivAAIAAG4ICvAAIAADaIivAAIAAG4ICvAAIAADRIivAAIAAFKg");
	this.shape_133.setTransform(247.1,131);

	this.shape_134 = new cjs.Shape();
	this.shape_134.graphics.lf(["rgba(115,114,120,0)","#737278"],[0,1],-257.1,-101,-25.5,-101).s().p("A1+RGIAAjRICvAAIAAm4IivAAIAAjcICvAAIAAm2IivAAIAAjcICvAAIAAlKIivAAIAAlKMApOAAAIAAFKICvAAIAADcIivAAIAAG4ICvAAIAADaIivAAIAAG4ICvAAIAADRIivAAIAAFKg");
	this.shape_134.setTransform(247.1,131);

	this.shape_135 = new cjs.Shape();
	this.shape_135.graphics.lf(["rgba(115,114,120,0)","#737278"],[0,1],-252.6,-101.2,-23,-101.2).s().p("A1+RGIAAjRICvAAIAAm4IivAAIAAjcICvAAIAAm2IivAAIAAjcICvAAIAAlKIivAAIAAlKMApOAAAIAAFKICvAAIAADcIivAAIAAG4ICvAAIAADaIivAAIAAG4ICvAAIAADRIivAAIAAFKg");
	this.shape_135.setTransform(247.1,131);

	this.shape_136 = new cjs.Shape();
	this.shape_136.graphics.lf(["rgba(115,114,120,0)","#737278"],[0,1],-248.1,-101.4,-20.5,-101.4).s().p("A1+RGIAAjRICvAAIAAm4IivAAIAAjcICvAAIAAm2IivAAIAAjcICvAAIAAlKIivAAIAAlKMApOAAAIAAFKICvAAIAADcIivAAIAAG4ICvAAIAADaIivAAIAAG4ICvAAIAADRIivAAIAAFKg");
	this.shape_136.setTransform(247.1,131);

	this.shape_137 = new cjs.Shape();
	this.shape_137.graphics.lf(["rgba(115,114,120,0)","#737278"],[0,1],-243.6,-101.6,-18.1,-101.6).s().p("A1+RGIAAjRICvAAIAAm4IivAAIAAjcICvAAIAAm2IivAAIAAjcICvAAIAAlKIivAAIAAlKMApOAAAIAAFKICvAAIAADcIivAAIAAG4ICvAAIAADaIivAAIAAG4ICvAAIAADRIivAAIAAFKg");
	this.shape_137.setTransform(247.1,131);

	this.shape_138 = new cjs.Shape();
	this.shape_138.graphics.lf(["rgba(115,114,120,0)","#737278"],[0,1],-239.1,-101.8,-15.6,-101.8).s().p("A1+RGIAAjRICvAAIAAm4IivAAIAAjcICvAAIAAm2IivAAIAAjcICvAAIAAlKIivAAIAAlKMApOAAAIAAFKICvAAIAADcIivAAIAAG4ICvAAIAADaIivAAIAAG4ICvAAIAADRIivAAIAAFKg");
	this.shape_138.setTransform(247.1,131);

	this.shape_139 = new cjs.Shape();
	this.shape_139.graphics.lf(["rgba(115,114,120,0)","#737278"],[0,1],-234.5,-102,-13.1,-102).s().p("A1+RGIAAjRICvAAIAAm4IivAAIAAjcICvAAIAAm2IivAAIAAjcICvAAIAAlKIivAAIAAlKMApOAAAIAAFKICvAAIAADcIivAAIAAG4ICvAAIAADaIivAAIAAG4ICvAAIAADRIivAAIAAFKg");
	this.shape_139.setTransform(247.1,131);

	this.shape_140 = new cjs.Shape();
	this.shape_140.graphics.lf(["rgba(115,114,120,0)","#737278"],[0,1],-230,-102.2,-10.6,-102.2).s().p("A1+RGIAAjRICvAAIAAm4IivAAIAAjcICvAAIAAm2IivAAIAAjcICvAAIAAlKIivAAIAAlKMApOAAAIAAFKICvAAIAADcIivAAIAAG4ICvAAIAADaIivAAIAAG4ICvAAIAADRIivAAIAAFKg");
	this.shape_140.setTransform(247.1,131);

	this.shape_141 = new cjs.Shape();
	this.shape_141.graphics.lf(["rgba(115,114,120,0)","#737278"],[0,1],-225.5,-102.4,-8.1,-102.4).s().p("A1+RGIAAjRICvAAIAAm4IivAAIAAjcICvAAIAAm2IivAAIAAjcICvAAIAAlKIivAAIAAlKMApOAAAIAAFKICvAAIAADcIivAAIAAG4ICvAAIAADaIivAAIAAG4ICvAAIAADRIivAAIAAFKg");
	this.shape_141.setTransform(247.1,131);

	this.shape_142 = new cjs.Shape();
	this.shape_142.graphics.lf(["rgba(115,114,120,0)","#737278"],[0,1],-221,-102.7,-5.6,-102.7).s().p("A1+RGIAAjRICvAAIAAm4IivAAIAAjcICvAAIAAm2IivAAIAAjcICvAAIAAlKIivAAIAAlKMApOAAAIAAFKICvAAIAADcIivAAIAAG4ICvAAIAADaIivAAIAAG4ICvAAIAADRIivAAIAAFKg");
	this.shape_142.setTransform(247.1,131);

	this.shape_143 = new cjs.Shape();
	this.shape_143.graphics.lf(["rgba(115,114,120,0)","#737278"],[0,1],-216.4,-102.9,-3.1,-102.9).s().p("A1+RGIAAjRICvAAIAAm4IivAAIAAjcICvAAIAAm2IivAAIAAjcICvAAIAAlKIivAAIAAlKMApOAAAIAAFKICvAAIAADcIivAAIAAG4ICvAAIAADaIivAAIAAG4ICvAAIAADRIivAAIAAFKg");
	this.shape_143.setTransform(247.1,131);

	this.shape_144 = new cjs.Shape();
	this.shape_144.graphics.lf(["rgba(115,114,120,0)","#737278"],[0,1],-211.9,-103.1,-0.6,-103.1).s().p("A1+RGIAAjRICvAAIAAm4IivAAIAAjcICvAAIAAm2IivAAIAAjcICvAAIAAlKIivAAIAAlKMApOAAAIAAFKICvAAIAADcIivAAIAAG4ICvAAIAADaIivAAIAAG4ICvAAIAADRIivAAIAAFKg");
	this.shape_144.setTransform(247.1,131);

	this.shape_145 = new cjs.Shape();
	this.shape_145.graphics.lf(["rgba(115,114,120,0)","#737278"],[0,1],-207.4,-103.3,1.9,-103.3).s().p("A1+RGIAAjRICvAAIAAm4IivAAIAAjcICvAAIAAm2IivAAIAAjcICvAAIAAlKIivAAIAAlKMApOAAAIAAFKICvAAIAADcIivAAIAAG4ICvAAIAADaIivAAIAAG4ICvAAIAADRIivAAIAAFKg");
	this.shape_145.setTransform(247.1,131);

	this.shape_146 = new cjs.Shape();
	this.shape_146.graphics.lf(["rgba(115,114,120,0)","#737278"],[0,1],-202.9,-103.5,4.4,-103.5).s().p("A1+RGIAAjRICvAAIAAm4IivAAIAAjcICvAAIAAm2IivAAIAAjcICvAAIAAlKIivAAIAAlKMApOAAAIAAFKICvAAIAADcIivAAIAAG4ICvAAIAADaIivAAIAAG4ICvAAIAADRIivAAIAAFKg");
	this.shape_146.setTransform(247.1,131);

	this.shape_147 = new cjs.Shape();
	this.shape_147.graphics.lf(["rgba(115,114,120,0)","#737278"],[0,1],-198.4,-103.7,6.9,-103.7).s().p("A1+RGIAAjRICvAAIAAm4IivAAIAAjcICvAAIAAm2IivAAIAAjcICvAAIAAlKIivAAIAAlKMApOAAAIAAFKICvAAIAADcIivAAIAAG4ICvAAIAADaIivAAIAAG4ICvAAIAADRIivAAIAAFKg");
	this.shape_147.setTransform(247.1,131);

	this.shape_148 = new cjs.Shape();
	this.shape_148.graphics.lf(["rgba(115,114,120,0)","#737278"],[0,1],-193.9,-103.9,9.4,-103.9).s().p("A1+RGIAAjRICvAAIAAm4IivAAIAAjcICvAAIAAm2IivAAIAAjcICvAAIAAlKIivAAIAAlKMApOAAAIAAFKICvAAIAADcIivAAIAAG4ICvAAIAADaIivAAIAAG4ICvAAIAADRIivAAIAAFKg");
	this.shape_148.setTransform(247.1,131);

	this.shape_149 = new cjs.Shape();
	this.shape_149.graphics.lf(["rgba(115,114,120,0)","#737278"],[0,1],-189.4,-104.1,11.8,-104.1).s().p("A1+RGIAAjRICvAAIAAm4IivAAIAAjcICvAAIAAm2IivAAIAAjcICvAAIAAlKIivAAIAAlKMApOAAAIAAFKICvAAIAADcIivAAIAAG4ICvAAIAADaIivAAIAAG4ICvAAIAADRIivAAIAAFKg");
	this.shape_149.setTransform(247.1,131);

	this.shape_150 = new cjs.Shape();
	this.shape_150.graphics.lf(["rgba(115,114,120,0)","#737278"],[0,1],-184.9,-104.3,14.3,-104.3).s().p("A1+RGIAAjRICvAAIAAm4IivAAIAAjcICvAAIAAm2IivAAIAAjcICvAAIAAlKIivAAIAAlKMApOAAAIAAFKICvAAIAADcIivAAIAAG4ICvAAIAADaIivAAIAAG4ICvAAIAADRIivAAIAAFKg");
	this.shape_150.setTransform(247.1,131);

	this.shape_151 = new cjs.Shape();
	this.shape_151.graphics.lf(["rgba(115,114,120,0)","#737278"],[0,1],-180.4,-104.5,16.8,-104.5).s().p("A1+RGIAAjRICvAAIAAm4IivAAIAAjcICvAAIAAm2IivAAIAAjcICvAAIAAlKIivAAIAAlKMApOAAAIAAFKICvAAIAADcIivAAIAAG4ICvAAIAADaIivAAIAAG4ICvAAIAADRIivAAIAAFKg");
	this.shape_151.setTransform(247.1,131);

	this.shape_152 = new cjs.Shape();
	this.shape_152.graphics.lf(["rgba(115,114,120,0)","#737278"],[0,1],-175.8,-104.7,19.3,-104.7).s().p("A1+RGIAAjRICvAAIAAm4IivAAIAAjcICvAAIAAm2IivAAIAAjcICvAAIAAlKIivAAIAAlKMApOAAAIAAFKICvAAIAADcIivAAIAAG4ICvAAIAADaIivAAIAAG4ICvAAIAADRIivAAIAAFKg");
	this.shape_152.setTransform(247.1,131);

	this.shape_153 = new cjs.Shape();
	this.shape_153.graphics.lf(["rgba(115,114,120,0)","#737278"],[0,1],-171.3,-104.9,21.8,-104.9).s().p("A1+RGIAAjRICvAAIAAm4IivAAIAAjcICvAAIAAm2IivAAIAAjcICvAAIAAlKIivAAIAAlKMApOAAAIAAFKICvAAIAADcIivAAIAAG4ICvAAIAADaIivAAIAAG4ICvAAIAADRIivAAIAAFKg");
	this.shape_153.setTransform(247.1,131);

	this.shape_154 = new cjs.Shape();
	this.shape_154.graphics.lf(["rgba(115,114,120,0)","#737278"],[0,1],-166.8,-105.1,24.3,-105.1).s().p("A1+RGIAAjRICvAAIAAm4IivAAIAAjcICvAAIAAm2IivAAIAAjcICvAAIAAlKIivAAIAAlKMApOAAAIAAFKICvAAIAADcIivAAIAAG4ICvAAIAADaIivAAIAAG4ICvAAIAADRIivAAIAAFKg");
	this.shape_154.setTransform(247.1,131);

	this.shape_155 = new cjs.Shape();
	this.shape_155.graphics.lf(["rgba(115,114,120,0)","#737278"],[0,1],-162.2,-105.4,26.8,-105.4).s().p("A1+RGIAAjRICvAAIAAm4IivAAIAAjcICvAAIAAm2IivAAIAAjcICvAAIAAlKIivAAIAAlKMApOAAAIAAFKICvAAIAADcIivAAIAAG4ICvAAIAADaIivAAIAAG4ICvAAIAADRIivAAIAAFKg");
	this.shape_155.setTransform(247.1,131);

	this.shape_156 = new cjs.Shape();
	this.shape_156.graphics.lf(["rgba(115,114,120,0)","#737278"],[0,1],-157.7,-105.6,29.3,-105.6).s().p("A1+RGIAAjRICvAAIAAm4IivAAIAAjcICvAAIAAm2IivAAIAAjcICvAAIAAlKIivAAIAAlKMApOAAAIAAFKICvAAIAADcIivAAIAAG4ICvAAIAADaIivAAIAAG4ICvAAIAADRIivAAIAAFKg");
	this.shape_156.setTransform(247.1,131);

	this.shape_157 = new cjs.Shape();
	this.shape_157.graphics.lf(["rgba(115,114,120,0)","#737278"],[0,1],-153.2,-105.8,31.8,-105.8).s().p("A1+RGIAAjRICvAAIAAm4IivAAIAAjcICvAAIAAm2IivAAIAAjcICvAAIAAlKIivAAIAAlKMApOAAAIAAFKICvAAIAADcIivAAIAAG4ICvAAIAADaIivAAIAAG4ICvAAIAADRIivAAIAAFKg");
	this.shape_157.setTransform(247.1,131);

	this.shape_158 = new cjs.Shape();
	this.shape_158.graphics.lf(["rgba(115,114,120,0)","#737278"],[0,1],-148.7,-106,34.3,-106).s().p("A1+RGIAAjRICvAAIAAm4IivAAIAAjcICvAAIAAm2IivAAIAAjcICvAAIAAlKIivAAIAAlKMApOAAAIAAFKICvAAIAADcIivAAIAAG4ICvAAIAADaIivAAIAAG4ICvAAIAADRIivAAIAAFKg");
	this.shape_158.setTransform(247.1,131);

	this.shape_159 = new cjs.Shape();
	this.shape_159.graphics.lf(["rgba(115,114,120,0)","#737278"],[0,1],-144.2,-106.2,36.8,-106.2).s().p("A1+RGIAAjRICvAAIAAm4IivAAIAAjcICvAAIAAm2IivAAIAAjcICvAAIAAlKIivAAIAAlKMApOAAAIAAFKICvAAIAADcIivAAIAAG4ICvAAIAADaIivAAIAAG4ICvAAIAADRIivAAIAAFKg");
	this.shape_159.setTransform(247.1,131);

	this.shape_160 = new cjs.Shape();
	this.shape_160.graphics.lf(["rgba(115,114,120,0)","#737278"],[0,1],-139.7,-106.4,39.2,-106.4).s().p("A1+RGIAAjRICvAAIAAm4IivAAIAAjcICvAAIAAm2IivAAIAAjcICvAAIAAlKIivAAIAAlKMApOAAAIAAFKICvAAIAADcIivAAIAAG4ICvAAIAADaIivAAIAAG4ICvAAIAADRIivAAIAAFKg");
	this.shape_160.setTransform(247.1,131);

	this.shape_161 = new cjs.Shape();
	this.shape_161.graphics.lf(["rgba(115,114,120,0)","#737278"],[0,1],-135.2,-106.6,41.7,-106.6).s().p("A1+RGIAAjRICvAAIAAm4IivAAIAAjcICvAAIAAm2IivAAIAAjcICvAAIAAlKIivAAIAAlKMApOAAAIAAFKICvAAIAADcIivAAIAAG4ICvAAIAADaIivAAIAAG4ICvAAIAADRIivAAIAAFKg");
	this.shape_161.setTransform(247.1,131);

	this.shape_162 = new cjs.Shape();
	this.shape_162.graphics.lf(["rgba(115,114,120,0)","#737278"],[0,1],-130.7,-106.8,44.2,-106.8).s().p("A1+RGIAAjRICvAAIAAm4IivAAIAAjcICvAAIAAm2IivAAIAAjcICvAAIAAlKIivAAIAAlKMApOAAAIAAFKICvAAIAADcIivAAIAAG4ICvAAIAADaIivAAIAAG4ICvAAIAADRIivAAIAAFKg");
	this.shape_162.setTransform(247.1,131);

	this.shape_163 = new cjs.Shape();
	this.shape_163.graphics.lf(["rgba(115,114,120,0)","#737278"],[0,1],-126.1,-107,46.8,-107).s().p("A1+RGIAAjRICvAAIAAm4IivAAIAAjcICvAAIAAm2IivAAIAAjcICvAAIAAlKIivAAIAAlKMApOAAAIAAFKICvAAIAADcIivAAIAAG4ICvAAIAADaIivAAIAAG4ICvAAIAADRIivAAIAAFKg");
	this.shape_163.setTransform(247.1,131);

	this.shape_164 = new cjs.Shape();
	this.shape_164.graphics.lf(["rgba(115,114,120,0)","#737278"],[0,1],-121.6,-107.2,49.2,-107.2).s().p("A1+RGIAAjRICvAAIAAm4IivAAIAAjcICvAAIAAm2IivAAIAAjcICvAAIAAlKIivAAIAAlKMApOAAAIAAFKICvAAIAADcIivAAIAAG4ICvAAIAADaIivAAIAAG4ICvAAIAADRIivAAIAAFKg");
	this.shape_164.setTransform(247.1,131);

	this.shape_165 = new cjs.Shape();
	this.shape_165.graphics.lf(["rgba(115,114,120,0)","#737278"],[0,1],-117.1,-107.4,51.7,-107.4).s().p("A1+RGIAAjRICvAAIAAm4IivAAIAAjcICvAAIAAm2IivAAIAAjcICvAAIAAlKIivAAIAAlKMApOAAAIAAFKICvAAIAADcIivAAIAAG4ICvAAIAADaIivAAIAAG4ICvAAIAADRIivAAIAAFKg");
	this.shape_165.setTransform(247.1,131);

	this.shape_166 = new cjs.Shape();
	this.shape_166.graphics.lf(["rgba(115,114,120,0)","#737278"],[0,1],-112.5,-107.6,54.2,-107.6).s().p("A1+RGIAAjRICvAAIAAm4IivAAIAAjcICvAAIAAm2IivAAIAAjcICvAAIAAlKIivAAIAAlKMApOAAAIAAFKICvAAIAADcIivAAIAAG4ICvAAIAADaIivAAIAAG4ICvAAIAADRIivAAIAAFKg");
	this.shape_166.setTransform(247.1,131);

	this.shape_167 = new cjs.Shape();
	this.shape_167.graphics.lf(["rgba(115,114,120,0)","#737278"],[0,1],-108,-107.8,56.7,-107.8).s().p("A1+RGIAAjRICvAAIAAm4IivAAIAAjcICvAAIAAm2IivAAIAAjcICvAAIAAlKIivAAIAAlKMApOAAAIAAFKICvAAIAADcIivAAIAAG4ICvAAIAADaIivAAIAAG4ICvAAIAADRIivAAIAAFKg");
	this.shape_167.setTransform(247.1,131);

	this.shape_168 = new cjs.Shape();
	this.shape_168.graphics.lf(["rgba(115,114,120,0)","#737278"],[0,1],-103.5,-108,59.2,-108).s().p("A1+RGIAAjRICvAAIAAm4IivAAIAAjcICvAAIAAm2IivAAIAAjcICvAAIAAlKIivAAIAAlKMApOAAAIAAFKICvAAIAADcIivAAIAAG4ICvAAIAADaIivAAIAAG4ICvAAIAADRIivAAIAAFKg");
	this.shape_168.setTransform(247.1,131);

	this.shape_169 = new cjs.Shape();
	this.shape_169.graphics.lf(["rgba(115,114,120,0)","#737278"],[0,1],-99,-108.3,61.7,-108.3).s().p("A1+RGIAAjRICvAAIAAm4IivAAIAAjcICvAAIAAm2IivAAIAAjcICvAAIAAlKIivAAIAAlKMApOAAAIAAFKICvAAIAADcIivAAIAAG4ICvAAIAADaIivAAIAAG4ICvAAIAADRIivAAIAAFKg");
	this.shape_169.setTransform(247.1,131);

	this.shape_170 = new cjs.Shape();
	this.shape_170.graphics.lf(["rgba(115,114,120,0)","#737278"],[0,1],-94.5,-108.5,64.2,-108.5).s().p("A1+RGIAAjRICvAAIAAm4IivAAIAAjcICvAAIAAm2IivAAIAAjcICvAAIAAlKIivAAIAAlKMApOAAAIAAFKICvAAIAADcIivAAIAAG4ICvAAIAADaIivAAIAAG4ICvAAIAADRIivAAIAAFKg");
	this.shape_170.setTransform(247.1,131);

	this.shape_171 = new cjs.Shape();
	this.shape_171.graphics.lf(["rgba(115,114,120,0)","#737278"],[0,1],-90,-108.7,66.6,-108.7).s().p("A1+RGIAAjRICvAAIAAm4IivAAIAAjcICvAAIAAm2IivAAIAAjcICvAAIAAlKIivAAIAAlKMApOAAAIAAFKICvAAIAADcIivAAIAAG4ICvAAIAADaIivAAIAAG4ICvAAIAADRIivAAIAAFKg");
	this.shape_171.setTransform(247.1,131);

	this.shape_172 = new cjs.Shape();
	this.shape_172.graphics.lf(["rgba(115,114,120,0)","#737278"],[0,1],-85.5,-108.9,69.1,-108.9).s().p("A1+RGIAAjRICvAAIAAm4IivAAIAAjcICvAAIAAm2IivAAIAAjcICvAAIAAlKIivAAIAAlKMApOAAAIAAFKICvAAIAADcIivAAIAAG4ICvAAIAADaIivAAIAAG4ICvAAIAADRIivAAIAAFKg");
	this.shape_172.setTransform(247.1,131);

	this.shape_173 = new cjs.Shape();
	this.shape_173.graphics.lf(["rgba(115,114,120,0)","#737278"],[0,1],-80.9,-109.1,71.7,-109.1).s().p("A1+RGIAAjRICvAAIAAm4IivAAIAAjcICvAAIAAm2IivAAIAAjcICvAAIAAlKIivAAIAAlKMApOAAAIAAFKICvAAIAADcIivAAIAAG4ICvAAIAADaIivAAIAAG4ICvAAIAADRIivAAIAAFKg");
	this.shape_173.setTransform(247.1,131);

	this.shape_174 = new cjs.Shape();
	this.shape_174.graphics.lf(["rgba(115,114,120,0)","#737278"],[0,1],-76.4,-109.3,74.2,-109.3).s().p("A1+RGIAAjRICvAAIAAm4IivAAIAAjcICvAAIAAm2IivAAIAAjcICvAAIAAlKIivAAIAAlKMApOAAAIAAFKICvAAIAADcIivAAIAAG4ICvAAIAADaIivAAIAAG4ICvAAIAADRIivAAIAAFKg");
	this.shape_174.setTransform(247.1,131);

	this.shape_175 = new cjs.Shape();
	this.shape_175.graphics.lf(["rgba(115,114,120,0)","#737278"],[0,1],-71.9,-109.5,76.6,-109.5).s().p("A1+RGIAAjRICvAAIAAm4IivAAIAAjcICvAAIAAm2IivAAIAAjcICvAAIAAlKIivAAIAAlKMApOAAAIAAFKICvAAIAADcIivAAIAAG4ICvAAIAADaIivAAIAAG4ICvAAIAADRIivAAIAAFKg");
	this.shape_175.setTransform(247.1,131);

	this.shape_176 = new cjs.Shape();
	this.shape_176.graphics.lf(["rgba(115,114,120,0)","#737278"],[0,1],-67.4,-109.7,79.1,-109.7).s().p("A1+RGIAAjRICvAAIAAm4IivAAIAAjcICvAAIAAm2IivAAIAAjcICvAAIAAlKIivAAIAAlKMApOAAAIAAFKICvAAIAADcIivAAIAAG4ICvAAIAADaIivAAIAAG4ICvAAIAADRIivAAIAAFKg");
	this.shape_176.setTransform(247.1,131);

	this.shape_177 = new cjs.Shape();
	this.shape_177.graphics.lf(["rgba(115,114,120,0)","#737278"],[0,1],-62.9,-109.9,81.6,-109.9).s().p("A1+RGIAAjRICvAAIAAm4IivAAIAAjcICvAAIAAm2IivAAIAAjcICvAAIAAlKIivAAIAAlKMApOAAAIAAFKICvAAIAADcIivAAIAAG4ICvAAIAADaIivAAIAAG4ICvAAIAADRIivAAIAAFKg");
	this.shape_177.setTransform(247.1,131);

	this.shape_178 = new cjs.Shape();
	this.shape_178.graphics.lf(["rgba(115,114,120,0)","#737278"],[0,1],-58.4,-110.1,84.1,-110.1).s().p("A1+RGIAAjRICvAAIAAm4IivAAIAAjcICvAAIAAm2IivAAIAAjcICvAAIAAlKIivAAIAAlKMApOAAAIAAFKICvAAIAADcIivAAIAAG4ICvAAIAADaIivAAIAAG4ICvAAIAADRIivAAIAAFKg");
	this.shape_178.setTransform(247.1,131);

	this.shape_179 = new cjs.Shape();
	this.shape_179.graphics.lf(["rgba(115,114,120,0)","#737278"],[0,1],-53.8,-110.3,86.6,-110.3).s().p("A1+RGIAAjRICvAAIAAm4IivAAIAAjcICvAAIAAm2IivAAIAAjcICvAAIAAlKIivAAIAAlKMApOAAAIAAFKICvAAIAADcIivAAIAAG4ICvAAIAADaIivAAIAAG4ICvAAIAADRIivAAIAAFKg");
	this.shape_179.setTransform(247.1,131);

	this.shape_180 = new cjs.Shape();
	this.shape_180.graphics.lf(["rgba(115,114,120,0)","#737278"],[0,1],-49.3,-110.5,89.1,-110.5).s().p("A1+RGIAAjRICvAAIAAm4IivAAIAAjcICvAAIAAm2IivAAIAAjcICvAAIAAlKIivAAIAAlKMApOAAAIAAFKICvAAIAADcIivAAIAAG4ICvAAIAADaIivAAIAAG4ICvAAIAADRIivAAIAAFKg");
	this.shape_180.setTransform(247.1,131);

	this.shape_181 = new cjs.Shape();
	this.shape_181.graphics.lf(["rgba(115,114,120,0)","#737278"],[0,1],-44.8,-110.7,91.6,-110.7).s().p("A1+RGIAAjRICvAAIAAm4IivAAIAAjcICvAAIAAm2IivAAIAAjcICvAAIAAlKIivAAIAAlKMApOAAAIAAFKICvAAIAADcIivAAIAAG4ICvAAIAADaIivAAIAAG4ICvAAIAADRIivAAIAAFKg");
	this.shape_181.setTransform(247.1,131);

	this.shape_182 = new cjs.Shape();
	this.shape_182.graphics.lf(["rgba(115,114,120,0)","#737278"],[0,1],-40.3,-111,94.1,-111).s().p("A1+RGIAAjRICvAAIAAm4IivAAIAAjcICvAAIAAm2IivAAIAAjcICvAAIAAlKIivAAIAAlKMApOAAAIAAFKICvAAIAADcIivAAIAAG4ICvAAIAADaIivAAIAAG4ICvAAIAADRIivAAIAAFKg");
	this.shape_182.setTransform(247.1,131);

	this.shape_183 = new cjs.Shape();
	this.shape_183.graphics.lf(["rgba(115,114,120,0)","#737278"],[0,1],-35.7,-111.2,96.6,-111.2).s().p("A1+RGIAAjRICvAAIAAm4IivAAIAAjcICvAAIAAm2IivAAIAAjcICvAAIAAlKIivAAIAAlKMApOAAAIAAFKICvAAIAADcIivAAIAAG4ICvAAIAADaIivAAIAAG4ICvAAIAADRIivAAIAAFKg");
	this.shape_183.setTransform(247.1,131);

	this.shape_184 = new cjs.Shape();
	this.shape_184.graphics.lf(["rgba(115,114,120,0)","#737278"],[0,1],-31.2,-111.4,99.1,-111.4).s().p("A1+RGIAAjRICvAAIAAm4IivAAIAAjcICvAAIAAm2IivAAIAAjcICvAAIAAlKIivAAIAAlKMApOAAAIAAFKICvAAIAADcIivAAIAAG4ICvAAIAADaIivAAIAAG4ICvAAIAADRIivAAIAAFKg");
	this.shape_184.setTransform(247.1,131);

	this.shape_185 = new cjs.Shape();
	this.shape_185.graphics.lf(["rgba(115,114,120,0)","#737278"],[0,1],-26.7,-111.6,101.6,-111.6).s().p("A1+RGIAAjRICvAAIAAm4IivAAIAAjcICvAAIAAm2IivAAIAAjcICvAAIAAlKIivAAIAAlKMApOAAAIAAFKICvAAIAADcIivAAIAAG4ICvAAIAADaIivAAIAAG4ICvAAIAADRIivAAIAAFKg");
	this.shape_185.setTransform(247.1,131);

	this.shape_186 = new cjs.Shape();
	this.shape_186.graphics.lf(["rgba(115,114,120,0)","#737278"],[0,1],-22.2,-111.8,104.1,-111.8).s().p("A1+RGIAAjRICvAAIAAm4IivAAIAAjcICvAAIAAm2IivAAIAAjcICvAAIAAlKIivAAIAAlKMApOAAAIAAFKICvAAIAADcIivAAIAAG4ICvAAIAADaIivAAIAAG4ICvAAIAADRIivAAIAAFKg");
	this.shape_186.setTransform(247.1,131);

	this.shape_187 = new cjs.Shape();
	this.shape_187.graphics.lf(["rgba(115,114,120,0)","#737278"],[0,1],-17.7,-112,106.5,-112).s().p("A1+RGIAAjRICvAAIAAm4IivAAIAAjcICvAAIAAm2IivAAIAAjcICvAAIAAlKIivAAIAAlKMApOAAAIAAFKICvAAIAADcIivAAIAAG4ICvAAIAADaIivAAIAAG4ICvAAIAADRIivAAIAAFKg");
	this.shape_187.setTransform(247.1,131);

	this.shape_188 = new cjs.Shape();
	this.shape_188.graphics.lf(["rgba(115,114,120,0)","#737278"],[0,1],-13.2,-112.2,109,-112.2).s().p("A1+RGIAAjRICvAAIAAm4IivAAIAAjcICvAAIAAm2IivAAIAAjcICvAAIAAlKIivAAIAAlKMApOAAAIAAFKICvAAIAADcIivAAIAAG4ICvAAIAADaIivAAIAAG4ICvAAIAADRIivAAIAAFKg");
	this.shape_188.setTransform(247.1,131);

	this.shape_189 = new cjs.Shape();
	this.shape_189.graphics.lf(["rgba(115,114,120,0)","#737278"],[0,1],-8.7,-112.4,111.5,-112.4).s().p("A1+RGIAAjRICvAAIAAm4IivAAIAAjcICvAAIAAm2IivAAIAAjcICvAAIAAlKIivAAIAAlKMApOAAAIAAFKICvAAIAADcIivAAIAAG4ICvAAIAADaIivAAIAAG4ICvAAIAADRIivAAIAAFKg");
	this.shape_189.setTransform(247.1,131);

	this.shape_190 = new cjs.Shape();
	this.shape_190.graphics.lf(["rgba(115,114,120,0)","#737278"],[0,1],-4.2,-112.6,114,-112.6).s().p("A1+RGIAAjRICvAAIAAm4IivAAIAAjcICvAAIAAm2IivAAIAAjcICvAAIAAlKIivAAIAAlKMApOAAAIAAFKICvAAIAADcIivAAIAAG4ICvAAIAADaIivAAIAAG4ICvAAIAADRIivAAIAAFKg");
	this.shape_190.setTransform(247.1,131);

	this.shape_191 = new cjs.Shape();
	this.shape_191.graphics.lf(["rgba(115,114,120,0)","#737278"],[0,1],0.4,-112.8,116.5,-112.8).s().p("A1+RGIAAjRICvAAIAAm4IivAAIAAjcICvAAIAAm2IivAAIAAjcICvAAIAAlKIivAAIAAlKMApOAAAIAAFKICvAAIAADcIivAAIAAG4ICvAAIAADaIivAAIAAG4ICvAAIAADRIivAAIAAFKg");
	this.shape_191.setTransform(247.1,131);

	this.shape_192 = new cjs.Shape();
	this.shape_192.graphics.lf(["rgba(115,114,120,0)","#737278"],[0,1],4.9,-113,119,-113).s().p("A1+RGIAAjRICvAAIAAm4IivAAIAAjcICvAAIAAm2IivAAIAAjcICvAAIAAlKIivAAIAAlKMApOAAAIAAFKICvAAIAADcIivAAIAAG4ICvAAIAADaIivAAIAAG4ICvAAIAADRIivAAIAAFKg");
	this.shape_192.setTransform(247.1,131);

	this.shape_193 = new cjs.Shape();
	this.shape_193.graphics.lf(["rgba(115,114,120,0)","#737278"],[0,1],9.4,-113.2,121.5,-113.2).s().p("A1+RGIAAjRICvAAIAAm4IivAAIAAjcICvAAIAAm2IivAAIAAjcICvAAIAAlKIivAAIAAlKMApOAAAIAAFKICvAAIAADcIivAAIAAG4ICvAAIAADaIivAAIAAG4ICvAAIAADRIivAAIAAFKg");
	this.shape_193.setTransform(247.1,131);

	this.shape_194 = new cjs.Shape();
	this.shape_194.graphics.lf(["rgba(115,114,120,0)","#737278"],[0,1],13.9,-113.4,124,-113.4).s().p("A1+RGIAAjRICvAAIAAm4IivAAIAAjcICvAAIAAm2IivAAIAAjcICvAAIAAlKIivAAIAAlKMApOAAAIAAFKICvAAIAADcIivAAIAAG4ICvAAIAADaIivAAIAAG4ICvAAIAADRIivAAIAAFKg");
	this.shape_194.setTransform(247.1,131);

	this.shape_195 = new cjs.Shape();
	this.shape_195.graphics.lf(["rgba(115,114,120,0)","#737278"],[0,1],18.5,-113.7,126.5,-113.7).s().p("A1+RGIAAjRICvAAIAAm4IivAAIAAjcICvAAIAAm2IivAAIAAjcICvAAIAAlKIivAAIAAlKMApOAAAIAAFKICvAAIAADcIivAAIAAG4ICvAAIAADaIivAAIAAG4ICvAAIAADRIivAAIAAFKg");
	this.shape_195.setTransform(247.1,131);

	this.shape_196 = new cjs.Shape();
	this.shape_196.graphics.lf(["rgba(115,114,120,0)","#737278"],[0,1],23,-113.9,129,-113.9).s().p("A1+RGIAAjRICvAAIAAm4IivAAIAAjcICvAAIAAm2IivAAIAAjcICvAAIAAlKIivAAIAAlKMApOAAAIAAFKICvAAIAADcIivAAIAAG4ICvAAIAADaIivAAIAAG4ICvAAIAADRIivAAIAAFKg");
	this.shape_196.setTransform(247.1,131);

	this.shape_197 = new cjs.Shape();
	this.shape_197.graphics.lf(["rgba(115,114,120,0)","#737278"],[0,1],27.5,-114.1,131.5,-114.1).s().p("A1+RGIAAjRICvAAIAAm4IivAAIAAjcICvAAIAAm2IivAAIAAjcICvAAIAAlKIivAAIAAlKMApOAAAIAAFKICvAAIAADcIivAAIAAG4ICvAAIAADaIivAAIAAG4ICvAAIAADRIivAAIAAFKg");
	this.shape_197.setTransform(247.1,131);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_99}]}).to({state:[{t:this.shape_100}]},1).to({state:[{t:this.shape_101}]},1).to({state:[{t:this.shape_102}]},1).to({state:[{t:this.shape_103}]},1).to({state:[{t:this.shape_104}]},1).to({state:[{t:this.shape_105}]},1).to({state:[{t:this.shape_106}]},1).to({state:[{t:this.shape_107}]},1).to({state:[{t:this.shape_108}]},1).to({state:[{t:this.shape_109}]},1).to({state:[{t:this.shape_110}]},1).to({state:[{t:this.shape_111}]},1).to({state:[{t:this.shape_112}]},1).to({state:[{t:this.shape_113}]},1).to({state:[{t:this.shape_114}]},1).to({state:[{t:this.shape_115}]},1).to({state:[{t:this.shape_116}]},1).to({state:[{t:this.shape_117}]},1).to({state:[{t:this.shape_118}]},1).to({state:[{t:this.shape_119}]},1).to({state:[{t:this.shape_120}]},1).to({state:[{t:this.shape_121}]},1).to({state:[{t:this.shape_122}]},1).to({state:[{t:this.shape_123}]},1).to({state:[{t:this.shape_124}]},1).to({state:[{t:this.shape_125}]},1).to({state:[{t:this.shape_126}]},1).to({state:[{t:this.shape_127}]},1).to({state:[{t:this.shape_128}]},1).to({state:[{t:this.shape_129}]},1).to({state:[{t:this.shape_130}]},1).to({state:[{t:this.shape_131}]},1).to({state:[{t:this.shape_132}]},1).to({state:[{t:this.shape_133}]},1).to({state:[{t:this.shape_134}]},1).to({state:[{t:this.shape_135}]},1).to({state:[{t:this.shape_136}]},1).to({state:[{t:this.shape_137}]},1).to({state:[{t:this.shape_138}]},1).to({state:[{t:this.shape_139}]},1).to({state:[{t:this.shape_140}]},1).to({state:[{t:this.shape_141}]},1).to({state:[{t:this.shape_142}]},1).to({state:[{t:this.shape_143}]},1).to({state:[{t:this.shape_144}]},1).to({state:[{t:this.shape_145}]},1).to({state:[{t:this.shape_146}]},1).to({state:[{t:this.shape_147}]},1).to({state:[{t:this.shape_148}]},1).to({state:[{t:this.shape_149}]},1).to({state:[{t:this.shape_150}]},1).to({state:[{t:this.shape_151}]},1).to({state:[{t:this.shape_152}]},1).to({state:[{t:this.shape_153}]},1).to({state:[{t:this.shape_154}]},1).to({state:[{t:this.shape_155}]},1).to({state:[{t:this.shape_156}]},1).to({state:[{t:this.shape_157}]},1).to({state:[{t:this.shape_158}]},1).to({state:[{t:this.shape_159}]},1).to({state:[{t:this.shape_160}]},1).to({state:[{t:this.shape_161}]},1).to({state:[{t:this.shape_162}]},1).to({state:[{t:this.shape_163}]},1).to({state:[{t:this.shape_164}]},1).to({state:[{t:this.shape_165}]},1).to({state:[{t:this.shape_166}]},1).to({state:[{t:this.shape_167}]},1).to({state:[{t:this.shape_168}]},1).to({state:[{t:this.shape_169}]},1).to({state:[{t:this.shape_170}]},1).to({state:[{t:this.shape_171}]},1).to({state:[{t:this.shape_172}]},1).to({state:[{t:this.shape_173}]},1).to({state:[{t:this.shape_174}]},1).to({state:[{t:this.shape_175}]},1).to({state:[{t:this.shape_176}]},1).to({state:[{t:this.shape_177}]},1).to({state:[{t:this.shape_178}]},1).to({state:[{t:this.shape_179}]},1).to({state:[{t:this.shape_180}]},1).to({state:[{t:this.shape_181}]},1).to({state:[{t:this.shape_182}]},1).to({state:[{t:this.shape_183}]},1).to({state:[{t:this.shape_184}]},1).to({state:[{t:this.shape_185}]},1).to({state:[{t:this.shape_186}]},1).to({state:[{t:this.shape_187}]},1).to({state:[{t:this.shape_188}]},1).to({state:[{t:this.shape_189}]},1).to({state:[{t:this.shape_190}]},1).to({state:[{t:this.shape_191}]},1).to({state:[{t:this.shape_192}]},1).to({state:[{t:this.shape_193}]},1).to({state:[{t:this.shape_194}]},1).to({state:[{t:this.shape_195}]},1).to({state:[{t:this.shape_196}]},1).to({state:[{t:this.shape_197}]},1).to({state:[]},1).wait(19));

	// Ebene 5
	this.instance_1 = new lib.container_pics("single",15);
	this.instance_1.setTransform(656.9,333.5,1,1,0,0,0,549.3,321.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({_off:true},99).wait(19));

	// Ebene 2
	this.shape_198 = new cjs.Shape();
	this.shape_198.graphics.f("#737278").s().p("A1+RGIAAjRMApOAAAIAADRgAzPL8IAAjRMApOAAAIAADRgA1+G9IAAjcMApOAAAIAADcgAzPBzIAAjaMApOAAAIAADagA1+jVIAAjcMApOAAAIAADcgAzPofIAAjcMApOAAAIAADcgA1+tpIAAjcMApOAAAIAADcg");
	this.shape_198.setTransform(247.1,131);

	this.shape_199 = new cjs.Shape();
	this.shape_199.graphics.f("#403F45").s().p("A1+S0IAAgWIAAhYMApOAAAICvAAIAABugATQN1MgpOAAAIAAh5ICvAAMApOAAAIAAB5gAzPIrIivAAIAAhuMApOAAAICvAAIAABugATQDhMgpOAAAIAAhuICvAAMApOAAAIAABugAzPhnIivAAIAAhuMApOAAAICvAAIAABugATQmxMgpOAAAIAAhuICvAAMApOAAAIAABugAzPr7IivAAIAAhuMApOAAAICvAAIAABugATQxFMgpOAAAIAAhuMAr9AAAIAABug");
	this.shape_199.setTransform(247.1,131);

	this.shape_200 = new cjs.Shape();
	this.shape_200.graphics.f().s("#403F45").ss(1.5,0,1).p("AWg0dIBPA+IEnDlIIYGgIAAgLQAAgZARgSQASgRAZAAIAeAAQAZAAARARQASASAAAZIAATMQAAAZgSARQgRASgZAAIgeAAQgZAAgSgSQgRgRAAgZIAAgMIuOLDMgs/AAAIuOrDIAAALQAAAZgRARQgSASgZAAIgeAAQgZAAgRgSQgSgRAAgZIAAzqQAAgZASgRQARgSAZAAIAeAAQAZAAASASQARARAAAZIAAAqIOOrDg");
	this.shape_200.setTransform(247,131);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_200},{t:this.shape_199},{t:this.shape_198}]}).to({state:[]},99).wait(19));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-4,-1,502,264);


(lib.button03 = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{"out":0,"over":1,"down":2,visited:3});

	// Ebene 1
	this.instance = new lib.container_text("single",44);
	this.instance.setTransform(585.5,266.8,1,1,0,0,0,555.5,258);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(4));

	// Ebene 4
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D5001C").s().p("AgtBZIgBgBIBKhYIhKhXIABgBIARAAIBLBYIhLBZg");
	this.shape.setTransform(14.7,22.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#737278").s().p("AgtBZIgBgBIBKhYIhKhXIABgBIARAAIBLBYIhLBZg");
	this.shape_1.setTransform(14.7,22.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},3).wait(1));

	// btn_blind_rectangle
	this.instance_1 = new lib.btn_blind_rectangle();
	this.instance_1.setTransform(0,0.1,6.8,0.9,0,0,0,0,0.1);
	new cjs.ButtonHelper(this.instance_1, 0, 1, 2, false, new lib.btn_blind_rectangle(), 3);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(4));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,340,45);


(lib.button02 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"out":0,"over":1,"down":2,"visited":3});

	// Ebene 1
	this.instance = new lib.container_text("single",43);
	this.instance.setTransform(585.5,266.8,1,1,0,0,0,555.5,258);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(4));

	// Ebene 4
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D5001C").s().p("AgtBZIgBgBIBKhYIhKhXIABgBIARAAIBLBYIhLBZg");
	this.shape.setTransform(14.7,22.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#737278").s().p("AgtBZIgBgBIBKhYIhKhXIABgBIARAAIBLBYIhLBZg");
	this.shape_1.setTransform(14.7,22.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},3).wait(1));

	// btn_blind_rectangle
	this.instance_1 = new lib.btn_blind_rectangle();
	this.instance_1.setTransform(0,0,6.8,0.9);
	new cjs.ButtonHelper(this.instance_1, 0, 1, 2, false, new lib.btn_blind_rectangle(), 3);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(4));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,340,45);


(lib.button01 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"out":0,"over":1,"down":2,"visited":3});

	// Ebene 1
	this.instance = new lib.container_text("single",42);
	this.instance.setTransform(585.5,266.8,1,1,0,0,0,555.5,258);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(4));

	// Ebene 4
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D5001C").s().p("AgtBZIgBgBIBKhYIhKhXIABgBIARAAIBLBYIhLBZg");
	this.shape.setTransform(14.7,22.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#737278").s().p("AgtBZIgBgBIBKhYIhKhXIABgBIARAAIBLBYIhLBZg");
	this.shape_1.setTransform(14.7,22.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},3).wait(1));

	// btn_blind_rectangle
	this.instance_1 = new lib.btn_blind_rectangle();
	this.instance_1.setTransform(0,0,6.8,0.9);
	new cjs.ButtonHelper(this.instance_1, 0, 1, 2, false, new lib.btn_blind_rectangle(), 3);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(4));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,340,45);


(lib.btn_ppe_link02 = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// Ebene 3
	this.instance = new lib.container_pics("single",36);
	this.instance.setTransform(724,477.5,1,1,0,0,0,724,477.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhIBJIAAiRICRAAIAACRg");
	mask.setTransform(7.4,7.4);

	// link
	this.to = new cjs.Text("https://ppn.porsche.com/portal/docs/DOC-133304", "10px 'Arial'", "#D5001C");
	this.to.name = "to";
	this.to.lineHeight = 13;
	this.to.lineWidth = 213;
	this.to.setTransform(136.8,31.7);

	this.to.mask = mask;

	this.timeline.addTween(cjs.Tween.get(this.to).wait(1));

	// icons
	this.instance_1 = new lib.pic_shadow_occlusionRound();
	this.instance_1.setTransform(56.2,56.2,0.65,0.65,0,0,0,0.3,0.3);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-16.5,-16.5,145.1,145.1);


(lib.btn_ppe_link01 = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// Ebene 3
	this.instance = new lib.container_pics("single",36);
	this.instance.setTransform(724,477.5,1,1,0,0,0,724,477.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhIBJIAAiRICRAAIAACRg");
	mask.setTransform(7.4,7.4);

	// link
	this.to = new cjs.Text("https://ppn.porsche.com/portal/docs/DOC-133355", "10px 'Arial'", "#D5001C");
	this.to.name = "to";
	this.to.lineHeight = 13;
	this.to.lineWidth = 179;
	this.to.setTransform(136.8,31.7);

	this.to.mask = mask;

	this.timeline.addTween(cjs.Tween.get(this.to).wait(1));

	// icons
	this.instance_1 = new lib.pic_shadow_occlusionRound();
	this.instance_1.setTransform(56.2,56.2,0.65,0.65,0,0,0,0.3,0.3);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-16.5,-16.5,145.1,145.1);


(lib.btn_close02 = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// background
	this.instance = new lib.btn_blind();
	this.instance.setTransform(12,11.7,0.48,0.48,0,0,0,24.9,25);
	new cjs.ButtonHelper(this.instance, 0, 1, 2, false, new lib.btn_blind(), 3);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Ebene 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#333333").ss(1.5,2,1).p("Ah0h1IB0B0Ih3B3AAAgBIB3B3AB0h1Ih0B0");
	this.shape.setTransform(12,11.8);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1.4,-1.4,26.8,26.5);


(lib.ani_text_sideBar03_ = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_1 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(1).call(this.frame_1).wait(12));

	// pic_arrow_textbox
	this.button_play_parent = new lib.btn_arrow_openSideBar();
	this.button_play_parent.setTransform(20,320,1,1,0,0,0,20,20);

	this.timeline.addTween(cjs.Tween.get(this.button_play_parent).wait(2).to({visible:false},0).wait(11));

	// pic_arrow_textbox
	this.button_back_parent = new lib.btn_arrow_openSideBar();
	this.button_back_parent.setTransform(-485.9,276.9,1,1,0,0,0,20,20);
	this.button_back_parent.visible = false;

	this.timeline.addTween(cjs.Tween.get(this.button_back_parent).wait(12).to({regX:25,regY:35,skewY:180,x:443,y:335,visible:true},0).wait(1));

	// Ebene 5
	this.scrollerWidget = new lib.pic_text_sideBar03();
	this.scrollerWidget.setTransform(-218,330,1,1,0,0,0,160,280);

	this.timeline.addTween(cjs.Tween.get(this.scrollerWidget).wait(2).to({x:200},10).wait(1));

	// pic_plane_white
	this.instance = new lib.pic_text_sideBar_back();
	this.instance.setTransform(-337.7,431.1,0.361,1.326,0,0,0,222.3,325);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(2).to({regX:222.5,x:80.3},10).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-505.9,0,556,921.3);


(lib.ani_text_sideBar03 = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{I:12});

	// Ebene 1
	this.instance = new lib.ani_text_sideBar03_("synched",2,false);
	this.instance.setTransform(209,325,1,1,0,0,0,209,325);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(12).to({mode:"independent"},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-505.9,0,556,921.3);


(lib.ani_text_sideBar02_ = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_1 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(1).call(this.frame_1).wait(12));

	// pic_arrow_textbox
	this.button_play_parent = new lib.btn_arrow_openSideBar();
	this.button_play_parent.setTransform(20,320,1,1,0,0,0,20,20);

	this.timeline.addTween(cjs.Tween.get(this.button_play_parent).wait(2).to({visible:false},0).wait(11));

	// pic_arrow_textbox
	this.button_back_parent = new lib.btn_arrow_openSideBar();
	this.button_back_parent.setTransform(-485.9,276.9,1,1,0,0,0,20,20);
	this.button_back_parent.visible = false;

	this.timeline.addTween(cjs.Tween.get(this.button_back_parent).wait(12).to({regX:25,regY:35,skewY:180,x:443,y:335,visible:true},0).wait(1));

	// Ebene 5
	this.scrollerWidget = new lib.pic_text_sideBar02();
	this.scrollerWidget.setTransform(-218,330,1,1,0,0,0,160,280);

	this.timeline.addTween(cjs.Tween.get(this.scrollerWidget).wait(2).to({x:200},10).wait(1));

	// pic_plane_white
	this.instance = new lib.pic_text_sideBar_back();
	this.instance.setTransform(-337.7,431.1,0.361,1.326,0,0,0,222.3,325);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(2).to({regX:222.5,x:80.3},10).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-505.9,0,556,703);


(lib.ani_text_sideBar02 = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{"I":12});

	// Ebene 1
	this.instance = new lib.ani_text_sideBar02_("synched",2,false);
	this.instance.setTransform(209,325,1,1,0,0,0,209,325);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(12).to({mode:"independent"},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-505.9,0,556,703);


(lib.ani_text_sideBar01_ = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{end:12});

	// timeline functions:
	this.frame_1 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(1).call(this.frame_1).wait(12));

	// pic_arrow_textbox
	this.button_play_parent = new lib.btn_arrow_openSideBar();
	this.button_play_parent.setTransform(20,320,1,1,0,0,0,20,20);

	this.timeline.addTween(cjs.Tween.get(this.button_play_parent).wait(2).to({visible:false},0).wait(11));

	// pic_arrow_textbox
	this.button_back_parent = new lib.btn_arrow_openSideBar();
	this.button_back_parent.setTransform(-485.9,276.9,1,1,0,0,0,20,20);
	this.button_back_parent.visible = false;

	this.timeline.addTween(cjs.Tween.get(this.button_back_parent).wait(12).to({regX:25,regY:35,skewY:180,x:443,y:335,visible:true},0).wait(1));

	// Ebene 5
	this.scrollerWidget = new lib.pic_text_sideBar01();
	this.scrollerWidget.setTransform(-218,330,1,1,0,0,0,160,280);

	this.timeline.addTween(cjs.Tween.get(this.scrollerWidget).wait(2).to({x:200},10).wait(1));

	// pic_plane_white
	this.instance = new lib.pic_text_sideBar_back();
	this.instance.setTransform(-337.7,431.1,0.361,1.326,0,0,0,222.3,325);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(2).to({regX:222.5,x:80.3},10).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-505.9,0,556,703);


(lib.ani_text_sideBar01 = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{"I":12});

	// Ebene 1
	this.instance = new lib.ani_text_sideBar01_("synched",2,false);
	this.instance.setTransform(209,325,1,1,0,0,0,209,325);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(12).to({mode:"independent"},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-505.9,0,556,703);


(lib.ani_particle04 = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.instance = new lib.pic_particle();
	this.instance.setTransform(0.5,-1.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({x:12.1,y:-2.5},0).wait(1).to({x:23.8,y:-3.3},0).wait(1).to({x:35.8,y:-4.2},0).wait(1).to({x:48,y:-4.9},0).wait(1).to({x:60.5,y:-5.6},0).wait(1).to({x:73.2,y:-6.2},0).wait(1).to({x:86.1,y:-6.7},0).wait(1).to({x:99.2,y:-7.2},0).wait(1).to({x:112.5,y:-7.5},0).wait(1).to({x:126,y:-7.7},0).wait(1).to({x:139.7,y:-7.8},0).wait(1).to({x:153.6,y:-7.9},0).wait(1).to({x:168,y:-8.3},0).wait(1).to({x:182.7,y:-9.2},0).wait(1).to({x:197.4,y:-10.4},0).wait(1).to({x:212.3,y:-12},0).wait(1).to({x:227.2,y:-14},0).wait(1).to({x:242.1,y:-16.4},0).wait(1).to({x:257.1,y:-19.1},0).wait(1).to({x:272,y:-22.2},0).wait(1).to({x:286.9,y:-25.7},0).wait(1).to({x:301.8,y:-29.3},0).wait(1).to({x:316.5,y:-32},0).wait(1).to({x:331.5,y:-33.9},0).wait(1).to({x:346.9,y:-34.9},0).wait(1).to({x:362.5},0).wait(1).to({x:378.4,y:-33.9},0).wait(1).to({x:394.4,y:-31.9},0).wait(1).to({x:410.3,y:-28.8},0).wait(1).to({x:426.1,y:-24.7},0).wait(1).to({x:441.5,y:-19.7},0).wait(1).to({x:456,y:-14.6},0).wait(1).to({x:466.7,y:-11},0).wait(1).to({x:478.7,y:-7.1},0).wait(1).to({x:490.7,y:-3.3},0).wait(1).to({x:502.9,y:0.3},0).wait(1).to({x:515.5,y:3.8},0).wait(1).to({x:528.5,y:7},0).wait(1).to({x:542.1,y:9.5},0).wait(1).to({x:558.4,y:11.6},0).wait(1).to({x:575.9,y:13.8},0).wait(1).to({x:593.1,y:16},0).wait(1).to({x:609.9,y:18},0).wait(1).to({x:628.5,y:20.1},0).wait(1).to({x:649.8,y:22.1},0).wait(1).to({x:669.5,y:23.7},0).wait(1).to({x:687.6,y:25.1},0).wait(1).to({x:704.4,y:26.2},0).wait(1).to({x:719.9,y:26.7},0).wait(1).to({x:734.8,y:26.6},0).wait(1).to({x:750,y:25.8},0).wait(1).to({x:765.4,y:24.3},0).wait(1).to({x:780.9,y:21.9},0).wait(1).to({x:796.5,y:18.4},0).wait(1).to({x:812.1,y:14.3},0).wait(1).to({x:825.9,y:10.8},0).wait(1).to({x:840.2,y:7.2},0).wait(1).to({x:854.6,y:3.6},0).wait(1).to({x:869.5,y:0.1},0).wait(1).to({x:885.1,y:-3.4},0).wait(1).to({x:901.4,y:-6.6},0).wait(1).to({x:917.6,y:-9.2},0).wait(1).to({x:933.6,y:-11.4},0).wait(1).to({x:950.1,y:-12.7},0).wait(1).to({x:972.5,y:-11.7},0).wait(1).to({x:995.6,y:-8.6},0).wait(1).to({x:1015.2,y:-5},0).wait(1).to({x:1032.5,y:-1.3},0).wait(1).to({x:1048.4,y:2.5},0).to({_off:true},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-2.5,-36,1051.9,63.8);


(lib.ani_particle03 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.instance = new lib.pic_particle();
	this.instance.setTransform(0.5,-1.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({x:10.4,y:1.4},0).wait(1).to({x:21.8,y:4.2},0).wait(1).to({x:33.6,y:6.8},0).wait(1).to({x:45.6,y:8.9},0).wait(1).to({x:57.8,y:10.7},0).wait(1).to({x:70.2,y:12},0).wait(1).to({x:82.8,y:13.1},0).wait(1).to({x:95.4,y:13.8},0).wait(1).to({x:108.2,y:14.2},0).wait(1).to({x:121},0).wait(1).to({x:133.8,y:14},0).wait(1).to({x:145.5,y:13.8},0).wait(1).to({x:156.2,y:13.5},0).wait(1).to({x:167.5,y:13.1},0).wait(1).to({x:179,y:12.6},0).wait(1).to({x:190.8,y:12},0).wait(1).to({x:203,y:11.3},0).wait(1).to({x:215.5,y:10.5},0).wait(1).to({x:228.5,y:9.4},0).wait(1).to({x:241.9,y:8},0).wait(1).to({x:257,y:6.8},0).wait(1).to({x:277.1,y:6.7},0).wait(1).to({x:297.1,y:8},0).wait(1).to({x:315.5,y:9.9},0).wait(1).to({x:332.7,y:12.3},0).wait(1).to({x:349,y:15},0).wait(1).to({x:364.8,y:17.9},0).wait(1).to({x:379.5,y:20.6},0).wait(1).to({x:393.6,y:23.1},0).wait(1).to({x:408.1,y:25.5},0).wait(1).to({x:422.7,y:27.7},0).wait(1).to({x:437.7,y:29.9},0).wait(1).to({x:452.9,y:31.9},0).wait(1).to({x:468.4,y:33.8},0).wait(1).to({x:484.2,y:35.5},0).wait(1).to({x:500.4,y:37},0).wait(1).to({x:515.6,y:38.1},0).wait(1).to({x:530.2,y:38.9},0).wait(1).to({x:545.1,y:39.5},0).wait(1).to({x:560.3,y:39.6},0).wait(1).to({x:575.9,y:39.3},0).wait(1).to({x:591.8,y:38.5},0).wait(1).to({x:608.5,y:37.4},0).wait(1).to({x:625.5,y:37.5},0).wait(1).to({x:642.6,y:38.7},0).wait(1).to({x:659.6,y:41},0).wait(1).to({x:676.4,y:44.4},0).wait(1).to({x:692.7,y:48.3},0).wait(1).to({x:707.5,y:51.2},0).wait(1).to({x:722.3,y:53.4},0).wait(1).to({x:737.5,y:54.8},0).wait(1).to({x:753.2,y:55.1},0).wait(1).to({x:769.6,y:54.2},0).wait(1).to({x:784.8,y:52.9},0).wait(1).to({x:800,y:51.3},0).wait(1).to({x:815.5,y:49.2},0).wait(1).to({x:833.9,y:46.7},0).wait(1).to({x:860.8,y:43.4},0).wait(1).to({x:883,y:40.9},0).wait(1).to({x:901.2,y:39},0).wait(1).to({x:917.6,y:37.1},0).wait(1).to({x:935.3,y:34.3},0).wait(1).to({x:953.2,y:30.8},0).wait(1).to({x:970.4,y:26.9},0).wait(1).to({x:987.1,y:22.5},0).wait(1).to({x:1003.2,y:17.8},0).wait(1).to({x:1018.7,y:12.9},0).wait(1).to({x:1033.8,y:7.8},0).wait(1).to({x:1048.4,y:2.5},0).to({_off:true},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-2.5,-4.5,1051.9,60.7);


(lib.ani_particle02 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.instance = new lib.pic_particle();
	this.instance.setTransform(0.5,-1.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({x:11.2,y:-2.3},0).wait(1).to({x:22.4,y:-2.9},0).wait(1).to({x:33.8,y:-3.5},0).wait(1).to({x:45.4,y:-3.9},0).wait(1).to({x:57.2,y:-4.2},0).wait(1).to({x:69.2,y:-4.4},0).wait(1).to({x:81.4,y:-4.5},0).wait(1).to({x:93.7,y:-4.4},0).wait(1).to({x:106.2,y:-4.2},0).wait(1).to({x:118.9,y:-3.9},0).wait(1).to({x:131.3,y:-3.6},0).wait(1).to({x:143.9,y:-3.4},0).wait(1).to({x:156.7,y:-3.2},0).wait(1).to({x:169.9,y:-3},0).wait(1).to({x:183.3,y:-2.8},0).wait(1).to({x:196.9,y:-2.7},0).wait(1).to({x:210.9},0).wait(1).to({x:225.4,y:-2},0).wait(1).to({x:243.5,y:0.4},0).wait(1).to({x:261.7,y:4.3},0).wait(1).to({x:278.9,y:9.2},0).wait(1).to({x:295.1,y:14.7},0).wait(1).to({x:310.5,y:20.6},0).wait(1).to({x:325.4,y:26.9},0).wait(1).to({x:339.7,y:33.3},0).wait(1).to({x:353.2,y:38.6},0).wait(1).to({x:366.2,y:42.9},0).wait(1).to({x:380.1,y:46.4},0).wait(1).to({x:394.7,y:49},0).wait(1).to({x:409.9,y:50.3},0).wait(1).to({x:425.6,y:50.2},0).wait(1).to({x:441.7,y:48.4},0).wait(1).to({x:457.9,y:44.8},0).wait(1).to({x:473.7,y:39.6},0).wait(1).to({x:488.9,y:34.8},0).wait(1).to({x:503.7,y:30.8},0).wait(1).to({x:519,y:27.4},0).wait(1).to({x:534.8,y:24.8},0).wait(1).to({x:550.9,y:23.1},0).wait(1).to({x:567.5,y:22.4},0).wait(1).to({x:584.3,y:22.9},0).wait(1).to({x:601.4,y:24},0).wait(1).to({x:618.6,y:24.8},0).wait(1).to({x:635.7,y:25.2},0).wait(1).to({x:653},0).wait(1).to({x:670.2,y:24.7},0).wait(1).to({x:687.5,y:23.9},0).wait(1).to({x:704.7,y:22.7},0).wait(1).to({x:721.9,y:22},0).wait(1).to({x:739,y:21.9},0).wait(1).to({x:756.2,y:22.5},0).wait(1).to({x:773.4,y:23.9},0).wait(1).to({x:790.4,y:25.8},0).wait(1).to({x:807.4,y:28.5},0).wait(1).to({x:824.1,y:31.6},0).wait(1).to({x:840.8,y:33.1},0).wait(1).to({x:857.6,y:32.4},0).wait(1).to({x:874.4,y:29.5},0).wait(1).to({x:890.6,y:25.4},0).wait(1).to({x:906.7,y:21.4},0).wait(1).to({x:922.8,y:17.6},0).wait(1).to({x:938.7,y:13.8},0).wait(1).to({x:954.6,y:10.2},0).wait(1).to({x:970.4,y:6.7},0).wait(1).to({x:986.1,y:3.3},0).wait(1).to({x:1001.7,y:0.6},0).wait(1).to({x:1017.2,y:-0.5},0).wait(1).to({x:1032.9,y:0.2},0).wait(1).to({x:1048.4,y:2.5},0).to({_off:true},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-2.5,-5.5,1051.9,57);


(lib.ani_particle01 = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.instance = new lib.pic_particle();
	this.instance.setTransform(0.5,-1.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({x:12.3,y:-1.4},0).wait(1).to({x:24.2,y:-1.1},0).wait(1).to({x:36.3,y:-0.4},0).wait(1).to({x:48.5,y:0.5},0).wait(1).to({x:61,y:1.8},0).wait(1).to({x:73.6,y:3.4},0).wait(1).to({x:86.3,y:5.3},0).wait(1).to({x:99.2,y:7.5},0).wait(1).to({x:112.1,y:10.2},0).wait(1).to({x:125.2,y:13},0).wait(1).to({x:138.4,y:15.7},0).wait(1).to({x:151.8,y:18.2},0).wait(1).to({x:165.5,y:20.5},0).wait(1).to({x:179.3,y:22.6},0).wait(1).to({x:193.3,y:24.4},0).wait(1).to({x:207.5,y:26},0).wait(1).to({x:221.8,y:27.4},0).wait(1).to({x:236.3,y:28.5},0).wait(1).to({x:250.9,y:29.3},0).wait(1).to({x:265.4,y:29.9},0).wait(1).to({x:280.2,y:30.2},0).wait(1).to({x:295,y:30.4},0).wait(1).to({x:310.1,y:30.3},0).wait(1).to({x:325.2,y:29.9},0).wait(1).to({x:340.5,y:29.3},0).wait(1).to({x:355.9,y:28.4},0).wait(1).to({x:371.6,y:27},0).wait(1).to({x:387.6,y:25},0).wait(1).to({x:403.5,y:22.3},0).wait(1).to({x:419.3,y:19.1},0).wait(1).to({x:435.1,y:15.4},0).wait(1).to({x:450.7,y:11.1},0).wait(1).to({x:466.2,y:6.4},0).wait(1).to({x:481.4,y:1.9},0).wait(1).to({x:495,y:-1.2},0).wait(1).to({x:509.4,y:-3.3},0).wait(1).to({x:524.3,y:-4.1},0).wait(1).to({x:539.7,y:-3.5},0).wait(1).to({x:555.4,y:-1},0).wait(1).to({x:571,y:3.4},0).wait(1).to({x:586.4,y:8.6},0).wait(1).to({x:602.1,y:12.7},0).wait(1).to({x:618.3,y:15.6},0).wait(1).to({x:634.8,y:17.2},0).wait(1).to({x:651.4,y:17.6},0).wait(1).to({x:668.1,y:16.7},0).wait(1).to({x:684.2,y:15.3},0).wait(1).to({x:698.1,y:14.7},0).wait(1).to({x:712.4,y:14.6},0).wait(1).to({x:727,y:15.4},0).wait(1).to({x:741.8,y:17.2},0).wait(1).to({x:757.2,y:20.5},0).wait(1).to({x:772.3,y:23.6},0).wait(1).to({x:786.7,y:25.8},0).wait(1).to({x:801.7,y:27.3},0).wait(1).to({x:817.9,y:27.8},0).wait(1).to({x:839,y:28},0).wait(1).to({x:860.8,y:28.2},0).wait(1).to({x:879.4,y:28.3},0).wait(1).to({x:895.9},0).wait(1).to({x:912.4},0).wait(1).to({x:929,y:28.2},0).wait(1).to({x:945.3,y:28.1},0).wait(1).to({x:961.5,y:27.9},0).wait(1).to({x:977.4,y:27.7},0).wait(1).to({x:993.1,y:27.5},0).wait(1).to({x:1008.6,y:27.3},0).wait(1).to({x:1024},0).wait(1).to({x:1039.4,y:27.5},0).to({_off:true},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-2.5,-5.1,1042.9,36.6);


(lib.ani_fadeIn = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.loop = true;
	}
	this.frame_9 = function() {
		this.loop = true;
	}
	this.frame_10 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(9).call(this.frame_9).wait(1).call(this.frame_10).wait(1));

	// Ebene 1
	this.instance = new lib.pic_plane_white();
	this.instance.setTransform(609,351.5,1.052,1.326,0,0,0,579,265);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({alpha:0},9).to({_off:true},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,1218,703);


(lib.ani_backpressure_arrowHead = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.instance = new lib.pics_arrowHead("single",0);
	this.instance.setTransform(-39,-20.7,1,1.106);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({regX:13.5,x:-16.6},0).wait(1).to({x:-7.5},0).wait(1).to({x:1.7},0).wait(1).to({x:11.1},0).wait(1).to({x:20.6},0).wait(1).to({rotation:0.3,x:30.3,y:-20.5},0).wait(1).to({rotation:-0.8,x:39.4,y:-20.9},0).wait(1).to({rotation:-2.2,x:46.7,y:-21.4},0).wait(1).to({rotation:-4.8,x:54.6,y:-22.4},0).wait(1).to({rotation:-11.3,x:62.4,y:-25},0).wait(1).to({rotation:-26.3,x:70.9,y:-31.7},0).wait(1).to({rotation:-40.3,x:78.3,y:-40.5},0).wait(1).to({rotation:-36.7,x:86.8,y:-46.8},0).wait(1).to({rotation:-23.1,x:96.8,y:-49},0).wait(1).to({rotation:-5.6,x:107.8,y:-47.6},0).wait(1).to({rotation:17.1,x:117.5,y:-41.4},0).wait(1).to({rotation:43,x:123.6,y:-30.9},0).wait(1).to({rotation:71.3,x:123.9,y:-18.2},0).wait(1).to({rotation:97.4,x:118.9,y:-6.7},0).wait(1).to({rotation:116.8,x:111.1,y:2.7},0).wait(1).to({rotation:134.9,x:101.4,y:8.9},0).wait(1).to({rotation:152.5,x:89.5,y:12.4},0).wait(1).to({rotation:165.2,x:77.6,y:13.8},0).wait(1).to({rotation:174.8,x:66.4,y:13.5},0).wait(1).to({rotation:180,x:55.6,y:12.4},0).wait(1).to({x:44.9},0).wait(1).to({x:34.3},0).wait(1).to({x:23.8,y:12.5},0).wait(1).to({regX:0,x:27},0).to({alpha:0},5).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-39,-33.2,27,25);


(lib.ani_arrowsBackpressure02 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// arrowHead
	this.instance = new lib.ani_backpressure_arrowHead();
	this.instance.setTransform(52.5,59,1,1,0,0,0,13.5,12.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(102));

	// arrowHead
	this.instance_1 = new lib.ani_backpressure_arrowHead();
	this.instance_1.setTransform(52.5,90.7,1,1,0,180,0,13.5,12.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(102));

	// ani_backpressure_cover
	this.instance_2 = new lib.ani_backpressureMask();
	this.instance_2.setTransform(52.5,59,1,1,0,0,0,13.5,12.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(102));

	// Ebene 4
	this.shape = new cjs.Shape();
	this.shape.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-83.6,0,81.2,0).ss(5,0,1).p("AsqgkIIgAAQD4ACBdgUQBygaBehbQBghdBrgXQBhgUBQAoQBOAoAeBQQAgBVgkBgQg+CujNA8QhAAThHAGIoEAB");
	this.shape.setTransform(81.2,29.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-83.6,0,81.2,0).ss(5.1,0,1).p("AsqgkIIgAAQD4ACBdgUQBygaBehbQBghdBrgXQBhgUBQAoQBOAoAeBQQAgBVgkBgQg+CujNA8QhAAThHAGIoEAB");
	this.shape_1.setTransform(81.2,29.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-83.7,0,81.1,0).ss(5.2,0,1).p("AsrgkIIgAAQD5ACBcgUQBzgaBehbQBghdBrgXQBhgUBQAoQBNAoAeBQQAgBVgjBgQg/CujNA8QhAAThGAGIoEAB");
	this.shape_2.setTransform(81.2,29.5);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-83.7,0,81.1,0).ss(5.3,0,1).p("AsrgkIIgAAQD5ACBcgUQBzgaBehbQBghdBrgXQBhgUBQAoQBNAoAeBQQAgBVgjBgQg/CujNA8QhAAThGAGIoEAB");
	this.shape_3.setTransform(81.2,29.5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-83.7,0,81.1,0).ss(5.4,0,1).p("AsrgkIIgAAQD4ACBdgUQBygaBehbQBghdBrgXQBhgUBQAoQBOAoAeBQQAgBVgkBgQg+CujNA8QhAAThHAGIoEAB");
	this.shape_4.setTransform(81.3,29.5);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-83.7,0,81.1,0).ss(5.5,0,1).p("AsrgkIIgAAQD4ACBdgUQBygaBehbQBghdBrgXQBhgUBQAoQBOAoAeBQQAgBVgkBgQg+CujNA8QhAAThHAGIoEAB");
	this.shape_5.setTransform(81.3,29.5);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-83.8,0,81,0).ss(5.6,0,1).p("AssgkIIgAAQD5ACBcgUQBzgaBehbQBghdBrgXQBhgUBQAoQBNAoAeBQQAgBVgjBgQg/CujNA8QhAAThGAGIoEAB");
	this.shape_6.setTransform(81.3,29.5);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-83.8,0,81,0).ss(5.7,0,1).p("AssgkIIgAAQD5ACBcgUQBzgaBehbQBghdBrgXQBhgUBQAoQBNAoAeBQQAgBVgjBgQg/CujNA8QhAAThGAGIoEAB");
	this.shape_7.setTransform(81.3,29.5);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-83.8,0,81,0).ss(5.8,0,1).p("AssgkIIgAAQD4ACBdgUQBygaBehbQBghdBrgXQBhgUBQAoQBOAoAeBQQAgBVgkBgQg+CujNA8QhAAThHAGIoEAB");
	this.shape_8.setTransform(81.4,29.5);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-83.8,0,81,0).ss(5.9,0,1).p("AssgkIIgAAQD4ACBdgUQBygaBehbQBghdBrgXQBhgUBQAoQBOAoAeBQQAgBVgkBgQg+CujNA8QhAAThHAGIoEAB");
	this.shape_9.setTransform(81.4,29.5);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-83.9,0,80.9,0).ss(6,0,1).p("AstgkIIgAAQD5ACBcgUQBzgaBehbQBghdBrgXQBhgUBQAoQBNAoAeBQQAgBVgjBgQg/CujNA8QhAAThGAGIoEAB");
	this.shape_10.setTransform(81.4,29.5);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-83.9,0,80.9,0).ss(6.1,0,1).p("AstgkIIgAAQD5ACBcgUQBzgaBehbQBghdBrgXQBhgUBQAoQBNAoAeBQQAgBVgjBgQg/CujNA8QhAAThGAGIoEAB");
	this.shape_11.setTransform(81.4,29.5);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-83.9,0,80.9,0).ss(6.2,0,1).p("AstgkIIgAAQD4ACBdgUQBygaBehbQBghdBrgXQBhgUBQAoQBOAoAeBQQAgBVgkBgQg+CujNA8QhAAThHAGIoEAB");
	this.shape_12.setTransform(81.5,29.5);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-83.9,0,80.9,0).ss(6.3,0,1).p("AstgkIIgAAQD4ACBdgUQBygaBehbQBghdBrgXQBhgUBQAoQBOAoAeBQQAgBVgkBgQg+CujNA8QhAAThHAGIoEAB");
	this.shape_13.setTransform(81.5,29.5);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-84,0,80.8,0).ss(6.4,0,1).p("AsugkIIgAAQD5ACBcgUQBzgaBehbQBghdBrgXQBhgUBQAoQBNAoAeBQQAgBVgjBgQg/CujNA8QhAAThGAGIoEAB");
	this.shape_14.setTransform(81.5,29.5);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-84,0,80.8,0).ss(6.5,0,1).p("AsugkIIgAAQD5ACBcgUQBzgaBehbQBghdBrgXQBhgUBQAoQBNAoAeBQQAgBVgjBgQg/CujNA8QhAAThGAGIoEAB");
	this.shape_15.setTransform(81.5,29.5);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-84,0,80.8,0).ss(6.6,0,1).p("AsugkIIgAAQD4ACBdgUQBygaBehbQBghdBrgXQBhgUBQAoQBOAoAeBQQAgBVgkBgQg+CujNA8QhAAThHAGIoEAB");
	this.shape_16.setTransform(81.6,29.5);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-84,0,80.8,0).ss(6.7,0,1).p("AsugkIIgAAQD4ACBdgUQBygaBehbQBghdBrgXQBhgUBQAoQBOAoAeBQQAgBVgkBgQg+CujNA8QhAAThHAGIoEAB");
	this.shape_17.setTransform(81.6,29.5);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-84.1,0,80.7,0).ss(6.8,0,1).p("AsvgkIIgAAQD5ACBcgUQBzgaBehbQBghdBrgXQBhgUBQAoQBNAoAeBQQAgBVgjBgQg/CujNA8QhAAThGAGIoEAB");
	this.shape_18.setTransform(81.6,29.5);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-84.1,0,80.7,0).ss(6.9,0,1).p("AsvgkIIgAAQD5ACBcgUQBzgaBehbQBghdBrgXQBhgUBQAoQBNAoAeBQQAgBVgjBgQg/CujNA8QhAAThGAGIoEAB");
	this.shape_19.setTransform(81.6,29.5);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-84.1,0,80.7,0).ss(7,0,1).p("AsvgkIIgAAQD4ACBdgUQBygaBehbQBghdBrgXQBhgUBQAoQBOAoAeBQQAgBVgkBgQg+CujNA8QhAAThHAGIoEAB");
	this.shape_20.setTransform(81.7,29.5);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-84.1,0,80.7,0).ss(7.1,0,1).p("AsvgkIIgAAQD4ACBdgUQBygaBehbQBghdBrgXQBhgUBQAoQBOAoAeBQQAgBVgkBgQg+CujNA8QhAAThHAGIoEAB");
	this.shape_21.setTransform(81.7,29.5);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-84.2,0,80.6,0).ss(7.2,0,1).p("AswgkIIgAAQD5ACBcgUQBzgaBehbQBghdBrgXQBhgUBQAoQBNAoAeBQQAgBVgjBgQg/CujNA8QhAAThGAGIoEAB");
	this.shape_22.setTransform(81.7,29.5);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-84.2,0,80.6,0).ss(7.3,0,1).p("AswgkIIgAAQD5ACBcgUQBzgaBehbQBghdBrgXQBhgUBQAoQBNAoAeBQQAgBVgjBgQg/CujNA8QhAAThGAGIoEAB");
	this.shape_23.setTransform(81.7,29.5);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-84.2,0,80.6,0).ss(7.4,0,1).p("AswgkIIgAAQD4ACBdgUQBygaBehbQBghdBrgXQBhgUBQAoQBOAoAeBQQAgBVgkBgQg+CujNA8QhAAThHAGIoEAB");
	this.shape_24.setTransform(81.8,29.5);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-84.2,0,80.6,0).ss(7.5,0,1).p("AswgkIIgAAQD4ACBdgUQBygaBehbQBghdBrgXQBhgUBQAoQBOAoAeBQQAgBVgkBgQg+CujNA8QhAAThHAGIoEAB");
	this.shape_25.setTransform(81.8,29.5);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-84.2,0,80.6,0).ss(7.6,0,1).p("AswgkIIgAAQD4ACBdgUQBygaBehbQBghdBrgXQBhgUBQAoQBOAoAeBQQAgBVgkBgQg+CujNA8QhAAThHAGIoEAB");
	this.shape_26.setTransform(81.8,29.5);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-84.3,0,80.5,0).ss(7.7,0,1).p("AsxgkIIgAAQD5ACBcgUQBzgaBehbQBghdBrgXQBhgUBQAoQBNAoAeBQQAgBVgjBgQg/CujNA8QhAAThGAGIoEAB");
	this.shape_27.setTransform(81.8,29.5);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-84.3,0,80.5,0).ss(7.8,0,1).p("AsxgkIIgAAQD5ACBcgUQBzgaBehbQBghdBrgXQBhgUBQAoQBNAoAeBQQAgBVgjBgQg/CujNA8QhAAThGAGIoEAB");
	this.shape_28.setTransform(81.8,29.5);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-84.3,0,80.5,0).ss(7.9,0,1).p("AsxgkIIgAAQD4ACBdgUQBygaBehbQBghdBrgXQBhgUBQAoQBOAoAeBQQAgBVgkBgQg+CujNA8QhAAThHAGIoEAB");
	this.shape_29.setTransform(81.9,29.5);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-84.3,0,80.5,0).ss(8,0,1).p("AsxgkIIgAAQD4ACBdgUQBygaBehbQBghdBrgXQBhgUBQAoQBOAoAeBQQAgBVgkBgQg+CujNA8QhAAThHAGIoEAB");
	this.shape_30.setTransform(81.9,29.5);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-84.4,0,80.4,0).ss(8.1,0,1).p("AsygkIIgAAQD5ACBcgUQBzgaBehbQBghdBrgXQBhgUBQAoQBNAoAeBQQAgBVgjBgQg/CujNA8QhAAThGAGIoEAB");
	this.shape_31.setTransform(81.9,29.5);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-84.4,0,80.4,0).ss(8.2,0,1).p("AsygkIIgAAQD5ACBcgUQBzgaBehbQBghdBrgXQBhgUBQAoQBNAoAeBQQAgBVgjBgQg/CujNA8QhAAThGAGIoEAB");
	this.shape_32.setTransform(81.9,29.5);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-84.4,0,80.4,0).ss(8.3,0,1).p("AsygkIIgAAQD4ACBdgUQBygaBehbQBghdBrgXQBhgUBQAoQBOAoAeBQQAgBVgkBgQg+CujNA8QhAAThHAGIoEAB");
	this.shape_33.setTransform(82,29.5);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-84.4,0,80.4,0).ss(8.4,0,1).p("AsygkIIgAAQD4ACBdgUQBygaBehbQBghdBrgXQBhgUBQAoQBOAoAeBQQAgBVgkBgQg+CujNA8QhAAThHAGIoEAB");
	this.shape_34.setTransform(82,29.5);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-84.5,0,80.3,0).ss(8.5,0,1).p("AszgkIIgAAQD5ACBcgUQBzgaBehbQBghdBrgXQBhgUBQAoQBNAoAeBQQAgBVgjBgQg/CujNA8QhAAThGAGIoEAB");
	this.shape_35.setTransform(82,29.5);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-84.5,0,80.3,0).ss(8.6,0,1).p("AszgkIIgAAQD5ACBcgUQBzgaBehbQBghdBrgXQBhgUBQAoQBNAoAeBQQAgBVgjBgQg/CujNA8QhAAThGAGIoEAB");
	this.shape_36.setTransform(82,29.5);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-84.5,0,80.3,0).ss(8.7,0,1).p("AszgkIIgAAQD4ACBdgUQBygaBehbQBghdBrgXQBhgUBQAoQBOAoAeBQQAgBVgkBgQg+CujNA8QhAAThHAGIoEAB");
	this.shape_37.setTransform(82.1,29.5);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-84.5,0,80.3,0).ss(8.8,0,1).p("AszgkIIgAAQD4ACBdgUQBygaBehbQBghdBrgXQBhgUBQAoQBOAoAeBQQAgBVgkBgQg+CujNA8QhAAThHAGIoEAB");
	this.shape_38.setTransform(82.1,29.5);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-84.6,0,80.2,0).ss(8.9,0,1).p("As0gkIIgAAQD5ACBcgUQBzgaBehbQBghdBrgXQBhgUBQAoQBNAoAeBQQAgBVgjBgQg/CujNA8QhAAThGAGIoEAB");
	this.shape_39.setTransform(82.1,29.5);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-84.6,0,80.2,0).ss(9,0,1).p("As0gkIIgAAQD5ACBcgUQBzgaBehbQBghdBrgXQBhgUBQAoQBNAoAeBQQAgBVgjBgQg/CujNA8QhAAThGAGIoEAB");
	this.shape_40.setTransform(82.1,29.5);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-84.6,0,80.2,0).ss(9.1,0,1).p("As0gkIIgAAQD4ACBdgUQBygaBehbQBghdBrgXQBhgUBQAoQBOAoAeBQQAgBVgkBgQg+CujNA8QhAAThHAGIoEAB");
	this.shape_41.setTransform(82.2,29.5);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-84.6,0,80.2,0).ss(9.2,0,1).p("As0gkIIgAAQD4ACBdgUQBygaBehbQBghdBrgXQBhgUBQAoQBOAoAeBQQAgBVgkBgQg+CujNA8QhAAThHAGIoEAB");
	this.shape_42.setTransform(82.2,29.5);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-84.7,0,80.1,0).ss(9.3,0,1).p("As1gkIIgAAQD5ACBcgUQBzgaBehbQBghdBrgXQBhgUBQAoQBNAoAeBQQAgBVgjBgQg/CujNA8QhAAThGAGIoEAB");
	this.shape_43.setTransform(82.2,29.5);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-84.7,0,80.1,0).ss(9.4,0,1).p("As1gkIIgAAQD5ACBcgUQBzgaBehbQBghdBrgXQBhgUBQAoQBNAoAeBQQAgBVgjBgQg/CujNA8QhAAThGAGIoEAB");
	this.shape_44.setTransform(82.2,29.5);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-84.7,0,80.1,0).ss(9.5,0,1).p("As1gkIIgAAQD4ACBdgUQBygaBehbQBghdBrgXQBhgUBQAoQBOAoAeBQQAgBVgkBgQg+CujNA8QhAAThHAGIoEAB");
	this.shape_45.setTransform(82.3,29.5);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-84.7,0,80.1,0).ss(9.6,0,1).p("As1gkIIgAAQD4ACBdgUQBygaBehbQBghdBrgXQBhgUBQAoQBOAoAeBQQAgBVgkBgQg+CujNA8QhAAThHAGIoEAB");
	this.shape_46.setTransform(82.3,29.5);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-84.8,0,80,0).ss(9.7,0,1).p("As2gkIIgAAQD5ACBcgUQBzgaBehbQBghdBrgXQBhgUBQAoQBNAoAeBQQAgBVgjBgQg/CujNA8QhAAThGAGIoEAB");
	this.shape_47.setTransform(82.3,29.5);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-84.8,0,80,0).ss(9.8,0,1).p("As2gkIIgAAQD5ACBcgUQBzgaBehbQBghdBrgXQBhgUBQAoQBNAoAeBQQAgBVgjBgQg/CujNA8QhAAThGAGIoEAB");
	this.shape_48.setTransform(82.3,29.5);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-84.8,0,80,0).ss(9.9,0,1).p("As2gkIIgAAQD4ACBdgUQBygaBehbQBghdBrgXQBhgUBQAoQBOAoAeBQQAgBVgkBgQg+CujNA8QhAAThHAGIoEAB");
	this.shape_49.setTransform(82.4,29.5);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-84.8,0,80,0).ss(10,0,1).p("As2gkIIgAAQD4ACBdgUQBygaBehbQBghdBrgXQBhgUBQAoQBOAoAeBQQAgBVgkBgQg+CujNA8QhAAThHAGIoEAB");
	this.shape_50.setTransform(82.4,29.5);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-84.9,0,79.9,0).ss(10.1,0,1).p("As3gkIIgAAQD5ACBcgUQBzgaBehbQBghdBrgXQBhgUBQAoQBNAoAeBQQAgBVgjBgQg/CujNA8QhAAThGAGIoEAB");
	this.shape_51.setTransform(82.4,29.5);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-84.9,0,79.9,0).ss(10.2,0,1).p("As3gkIIgAAQD5ACBcgUQBzgaBehbQBghdBrgXQBhgUBQAoQBNAoAeBQQAgBVgjBgQg/CujNA8QhAAThGAGIoEAB");
	this.shape_52.setTransform(82.4,29.5);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-84.9,0,79.9,0).ss(10.3,0,1).p("As3gkIIgAAQD4ACBdgUQBygaBehbQBghdBrgXQBhgUBQAoQBOAoAeBQQAgBVgkBgQg+CujNA8QhAAThHAGIoEAB");
	this.shape_53.setTransform(82.5,29.5);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-84.9,0,79.9,0).ss(10.4,0,1).p("As3gkIIgAAQD4ACBdgUQBygaBehbQBghdBrgXQBhgUBQAoQBOAoAeBQQAgBVgkBgQg+CujNA8QhAAThHAGIoEAB");
	this.shape_54.setTransform(82.5,29.5);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-85,0,79.8,0).ss(10.5,0,1).p("As4gkIIgAAQD5ACBcgUQBzgaBehbQBghdBrgXQBhgUBQAoQBNAoAeBQQAgBVgjBgQg/CujNA8QhAAThGAGIoEAB");
	this.shape_55.setTransform(82.5,29.5);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-85,0,79.8,0).ss(10.6,0,1).p("As4gkIIgAAQD5ACBcgUQBzgaBehbQBghdBrgXQBhgUBQAoQBNAoAeBQQAgBVgjBgQg/CujNA8QhAAThGAGIoEAB");
	this.shape_56.setTransform(82.5,29.5);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-85,0,79.8,0).ss(10.7,0,1).p("As4gkIIgAAQD4ACBdgUQBygaBehbQBghdBrgXQBhgUBQAoQBOAoAeBQQAgBVgkBgQg+CujNA8QhAAThHAGIoEAB");
	this.shape_57.setTransform(82.6,29.5);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-85,0,79.8,0).ss(10.8,0,1).p("As4gkIIgAAQD4ACBdgUQBygaBehbQBghdBrgXQBhgUBQAoQBOAoAeBQQAgBVgkBgQg+CujNA8QhAAThHAGIoEAB");
	this.shape_58.setTransform(82.6,29.5);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-85.1,0,79.7,0).ss(10.9,0,1).p("As5gkIIgAAQD5ACBcgUQBzgaBehbQBghdBrgXQBhgUBQAoQBNAoAeBQQAgBVgjBgQg/CujNA8QhAAThGAGIoEAB");
	this.shape_59.setTransform(82.6,29.5);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-85.1,0,79.7,0).ss(11,0,1).p("As5gkIIgAAQD5ACBcgUQBzgaBehbQBghdBrgXQBhgUBQAoQBNAoAeBQQAgBVgjBgQg/CujNA8QhAAThGAGIoEAB");
	this.shape_60.setTransform(82.6,29.5);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-85.1,0,79.7,0).ss(11.1,0,1).p("As5gkIIgAAQD4ACBdgUQBygaBehbQBghdBrgXQBhgUBQAoQBOAoAeBQQAgBVgkBgQg+CujNA8QhAAThHAGIoEAB");
	this.shape_61.setTransform(82.7,29.5);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-85.1,0,79.7,0).ss(11.2,0,1).p("As5gkIIgAAQD4ACBdgUQBygaBehbQBghdBrgXQBhgUBQAoQBOAoAeBQQAgBVgkBgQg+CujNA8QhAAThHAGIoEAB");
	this.shape_62.setTransform(82.7,29.5);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-85.2,0,79.6,0).ss(11.3,0,1).p("As6gkIIgAAQD5ACBcgUQBzgaBehbQBghdBrgXQBhgUBQAoQBNAoAeBQQAgBVgjBgQg/CujNA8QhAAThGAGIoEAB");
	this.shape_63.setTransform(82.7,29.5);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-85.2,0,79.6,0).ss(11.4,0,1).p("As6gkIIgAAQD5ACBcgUQBzgaBehbQBghdBrgXQBhgUBQAoQBNAoAeBQQAgBVgjBgQg/CujNA8QhAAThGAGIoEAB");
	this.shape_64.setTransform(82.7,29.5);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-85.2,0,79.6,0).ss(11.5,0,1).p("As6gkIIgAAQD4ACBdgUQBygaBehbQBghdBrgXQBhgUBQAoQBOAoAeBQQAgBVgkBgQg+CujNA8QhAAThHAGIoEAB");
	this.shape_65.setTransform(82.8,29.5);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-85.2,0,79.6,0).ss(11.6,0,1).p("As6gkIIgAAQD4ACBdgUQBygaBehbQBghdBrgXQBhgUBQAoQBOAoAeBQQAgBVgkBgQg+CujNA8QhAAThHAGIoEAB");
	this.shape_66.setTransform(82.8,29.5);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-85.3,0,79.5,0).ss(11.7,0,1).p("As7gkIIgAAQD5ACBcgUQBzgaBehbQBghdBrgXQBhgUBQAoQBNAoAeBQQAgBVgjBgQg/CujNA8QhAAThGAGIoEAB");
	this.shape_67.setTransform(82.8,29.5);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-85.3,0,79.5,0).ss(11.8,0,1).p("As7gkIIgAAQD5ACBcgUQBzgaBehbQBghdBrgXQBhgUBQAoQBNAoAeBQQAgBVgjBgQg/CujNA8QhAAThGAGIoEAB");
	this.shape_68.setTransform(82.8,29.5);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-85.3,0,79.5,0).ss(11.9,0,1).p("As7gkIIgAAQD4ACBdgUQBygaBehbQBghdBrgXQBhgUBQAoQBOAoAeBQQAgBVgkBgQg+CujNA8QhAAThHAGIoEAB");
	this.shape_69.setTransform(82.9,29.5);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-85.3,0,79.5,0).ss(12,0,1).p("As7gkIIgAAQD4ACBdgUQBygaBehbQBghdBrgXQBhgUBQAoQBOAoAeBQQAgBVgkBgQg+CujNA8QhAAThHAGIoEAB");
	this.shape_70.setTransform(82.9,29.5);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-85.4,0,79.4,0).ss(12.1,0,1).p("As8gkIIgAAQD5ACBcgUQBzgaBehbQBghdBrgXQBhgUBQAoQBNAoAeBQQAgBVgjBgQg/CujNA8QhAAThGAGIoEAB");
	this.shape_71.setTransform(82.9,29.5);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-85.4,0,79.4,0).ss(12.2,0,1).p("As8gkIIgAAQD5ACBcgUQBzgaBehbQBghdBrgXQBhgUBQAoQBNAoAeBQQAgBVgjBgQg/CujNA8QhAAThGAGIoEAB");
	this.shape_72.setTransform(82.9,29.5);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-85.4,0,79.4,0).ss(12.3,0,1).p("As8gkIIgAAQD4ACBdgUQBygaBehbQBghdBrgXQBhgUBQAoQBOAoAeBQQAgBVgkBgQg+CujNA8QhAAThHAGIoEAB");
	this.shape_73.setTransform(83,29.5);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-85.4,0,79.4,0).ss(12.4,0,1).p("As8gkIIgAAQD4ACBdgUQBygaBehbQBghdBrgXQBhgUBQAoQBOAoAeBQQAgBVgkBgQg+CujNA8QhAAThHAGIoEAB");
	this.shape_74.setTransform(83,29.5);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-85.5,0,79.3,0).ss(12.5,0,1).p("As9gkIIgAAQD5ACBcgUQBzgaBehbQBghdBrgXQBhgUBQAoQBNAoAeBQQAgBVgjBgQg/CujNA8QhAAThGAGIoEAB");
	this.shape_75.setTransform(83,29.5);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-85.5,0,79.3,0).ss(12.6,0,1).p("As9gkIIgAAQD4ACBdgUQBygaBehbQBghdBrgXQBhgUBQAoQBOAoAeBQQAgBVgkBgQg+CujNA8QhAAThHAGIoEAB");
	this.shape_76.setTransform(83.1,29.5);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-85.5,0,79.3,0).ss(12.7,0,1).p("As9gkIIgAAQD4ACBdgUQBygaBehbQBghdBrgXQBhgUBQAoQBOAoAeBQQAgBVgkBgQg+CujNA8QhAAThHAGIoEAB");
	this.shape_77.setTransform(83.1,29.5);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-85.6,0,79.2,0).ss(12.8,0,1).p("As+gkIIgAAQD5ACBcgUQBzgaBehbQBghdBrgXQBhgUBQAoQBNAoAeBQQAgBVgjBgQg/CujNA8QhAAThGAGIoEAB");
	this.shape_78.setTransform(83.1,29.5);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-85.6,0,79.2,0).ss(12.9,0,1).p("As+gkIIgAAQD5ACBcgUQBzgaBehbQBghdBrgXQBhgUBQAoQBNAoAeBQQAgBVgjBgQg/CujNA8QhAAThGAGIoEAB");
	this.shape_79.setTransform(83.1,29.5);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-85.6,0,79.2,0).ss(13,0,1).p("As+gkIIgAAQD4ACBdgUQBygaBehbQBghdBrgXQBhgUBQAoQBOAoAeBQQAgBVgkBgQg+CujNA8QhAAThHAGIoEAB");
	this.shape_80.setTransform(83.2,29.5);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-85.6,0,79.2,0).ss(13.1,0,1).p("As+gkIIgAAQD4ACBdgUQBygaBehbQBghdBrgXQBhgUBQAoQBOAoAeBQQAgBVgkBgQg+CujNA8QhAAThHAGIoEAB");
	this.shape_81.setTransform(83.2,29.5);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-85.7,0,79.1,0).ss(13.2,0,1).p("As/gkIIgAAQD5ACBcgUQBzgaBehbQBghdBrgXQBhgUBQAoQBNAoAeBQQAgBVgjBgQg/CujNA8QhAAThGAGIoEAB");
	this.shape_82.setTransform(83.2,29.5);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-85.7,0,79.1,0).ss(13.3,0,1).p("As/gkIIgAAQD5ACBcgUQBzgaBehbQBghdBrgXQBhgUBQAoQBNAoAeBQQAgBVgjBgQg/CujNA8QhAAThGAGIoEAB");
	this.shape_83.setTransform(83.2,29.5);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-85.7,0,79.1,0).ss(13.4,0,1).p("As/gkIIgAAQD4ACBdgUQBygaBehbQBghdBrgXQBhgUBQAoQBOAoAeBQQAgBVgkBgQg+CujNA8QhAAThHAGIoEAB");
	this.shape_84.setTransform(83.3,29.5);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-85.7,0,79.1,0).ss(13.5,0,1).p("As/gkIIgAAQD4ACBdgUQBygaBehbQBghdBrgXQBhgUBQAoQBOAoAeBQQAgBVgkBgQg+CujNA8QhAAThHAGIoEAB");
	this.shape_85.setTransform(83.3,29.5);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-85.8,0,79,0).ss(13.6,0,1).p("AtAgkIIgAAQD5ACBcgUQBzgaBehbQBghdBrgXQBhgUBQAoQBNAoAeBQQAgBVgjBgQg/CujNA8QhAAThGAGIoEAB");
	this.shape_86.setTransform(83.3,29.5);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-85.8,0,79,0).ss(13.7,0,1).p("AtAgkIIgAAQD5ACBcgUQBzgaBehbQBghdBrgXQBhgUBQAoQBNAoAeBQQAgBVgjBgQg/CujNA8QhAAThGAGIoEAB");
	this.shape_87.setTransform(83.3,29.5);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-85.8,0,79,0).ss(13.8,0,1).p("AtAgkIIgAAQD4ACBdgUQBygaBehbQBghdBrgXQBhgUBQAoQBOAoAeBQQAgBVgkBgQg+CujNA8QhAAThHAGIoEAB");
	this.shape_88.setTransform(83.4,29.5);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-85.8,0,79,0).ss(13.9,0,1).p("AtAgkIIgAAQD4ACBdgUQBygaBehbQBghdBrgXQBhgUBQAoQBOAoAeBQQAgBVgkBgQg+CujNA8QhAAThHAGIoEAB");
	this.shape_89.setTransform(83.4,29.5);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-85.9,0,78.9,0).ss(14,0,1).p("AtBgkIIgAAQD5ACBcgUQBzgaBehbQBghdBrgXQBhgUBQAoQBNAoAeBQQAgBVgjBgQg/CujNA8QhAAThGAGIoEAB");
	this.shape_90.setTransform(83.4,29.5);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-85.9,0,78.9,0).ss(14.1,0,1).p("AtBgkIIgAAQD5ACBcgUQBzgaBehbQBghdBrgXQBhgUBQAoQBNAoAeBQQAgBVgjBgQg/CujNA8QhAAThGAGIoEAB");
	this.shape_91.setTransform(83.4,29.5);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-85.9,0,78.9,0).ss(14.2,0,1).p("AtBgkIIgAAQD4ACBdgUQBygaBehbQBghdBrgXQBhgUBQAoQBOAoAeBQQAgBVgkBgQg+CujNA8QhAAThHAGIoEAB");
	this.shape_92.setTransform(83.5,29.5);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-85.9,0,78.9,0).ss(14.3,0,1).p("AtBgkIIgAAQD4ACBdgUQBygaBehbQBghdBrgXQBhgUBQAoQBOAoAeBQQAgBVgkBgQg+CujNA8QhAAThHAGIoEAB");
	this.shape_93.setTransform(83.5,29.5);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-86,0,78.8,0).ss(14.4,0,1).p("AtCgkIIgAAQD5ACBcgUQBzgaBehbQBghdBrgXQBhgUBQAoQBNAoAeBQQAgBVgjBgQg/CujNA8QhAAThGAGIoEAB");
	this.shape_94.setTransform(83.5,29.5);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-86,0,78.8,0).ss(14.5,0,1).p("AtCgkIIgAAQD5ACBcgUQBzgaBehbQBghdBrgXQBhgUBQAoQBNAoAeBQQAgBVgjBgQg/CujNA8QhAAThGAGIoEAB");
	this.shape_95.setTransform(83.5,29.5);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-86,0,78.8,0).ss(14.6,0,1).p("AtCgkIIgAAQD4ACBdgUQBygaBehbQBghdBrgXQBhgUBQAoQBOAoAeBQQAgBVgkBgQg+CujNA8QhAAThHAGIoEAB");
	this.shape_96.setTransform(83.6,29.5);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-86,0,78.8,0).ss(14.7,0,1).p("AtCgkIIgAAQD4ACBdgUQBygaBehbQBghdBrgXQBhgUBQAoQBOAoAeBQQAgBVgkBgQg+CujNA8QhAAThHAGIoEAB");
	this.shape_97.setTransform(83.6,29.5);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-86.1,0,78.7,0).ss(14.8,0,1).p("AtDgkIIgAAQD5ACBcgUQBzgaBehbQBghdBrgXQBhgUBQAoQBNAoAeBQQAgBVgjBgQg/CujNA8QhAAThGAGIoEAB");
	this.shape_98.setTransform(83.6,29.5);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-86.1,0,78.7,0).ss(14.9,0,1).p("AtDgkIIgAAQD5ACBcgUQBzgaBehbQBghdBrgXQBhgUBQAoQBNAoAeBQQAgBVgjBgQg/CujNA8QhAAThGAGIoEAB");
	this.shape_99.setTransform(83.6,29.5);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-86.1,0,78.7,0).ss(15,0,1).p("AtDgkIIgAAQD4ACBdgUQBygaBehbQBghdBrgXQBhgUBQAoQBOAoAeBQQAgBVgkBgQg+CujNA8QhAAThHAGIoEAB");
	this.shape_100.setTransform(83.7,29.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_35}]},1).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_37}]},1).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_42}]},1).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_44}]},1).to({state:[{t:this.shape_45}]},1).to({state:[{t:this.shape_46}]},1).to({state:[{t:this.shape_47}]},1).to({state:[{t:this.shape_48}]},1).to({state:[{t:this.shape_49}]},1).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_52}]},1).to({state:[{t:this.shape_53}]},1).to({state:[{t:this.shape_54}]},1).to({state:[{t:this.shape_55}]},1).to({state:[{t:this.shape_56}]},1).to({state:[{t:this.shape_57}]},1).to({state:[{t:this.shape_58}]},1).to({state:[{t:this.shape_59}]},1).to({state:[{t:this.shape_60}]},1).to({state:[{t:this.shape_61}]},1).to({state:[{t:this.shape_62}]},1).to({state:[{t:this.shape_63}]},1).to({state:[{t:this.shape_64}]},1).to({state:[{t:this.shape_65}]},1).to({state:[{t:this.shape_66}]},1).to({state:[{t:this.shape_67}]},1).to({state:[{t:this.shape_68}]},1).to({state:[{t:this.shape_69}]},1).to({state:[{t:this.shape_70}]},1).to({state:[{t:this.shape_71}]},1).to({state:[{t:this.shape_72}]},1).to({state:[{t:this.shape_73}]},1).to({state:[{t:this.shape_74}]},1).to({state:[{t:this.shape_75}]},1).to({state:[{t:this.shape_75}]},1).to({state:[{t:this.shape_76}]},1).to({state:[{t:this.shape_77}]},1).to({state:[{t:this.shape_78}]},1).to({state:[{t:this.shape_79}]},1).to({state:[{t:this.shape_80}]},1).to({state:[{t:this.shape_81}]},1).to({state:[{t:this.shape_82}]},1).to({state:[{t:this.shape_83}]},1).to({state:[{t:this.shape_84}]},1).to({state:[{t:this.shape_85}]},1).to({state:[{t:this.shape_86}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_88}]},1).to({state:[{t:this.shape_89}]},1).to({state:[{t:this.shape_90}]},1).to({state:[{t:this.shape_91}]},1).to({state:[{t:this.shape_92}]},1).to({state:[{t:this.shape_93}]},1).to({state:[{t:this.shape_94}]},1).to({state:[{t:this.shape_95}]},1).to({state:[{t:this.shape_96}]},1).to({state:[{t:this.shape_97}]},1).to({state:[{t:this.shape_98}]},1).to({state:[{t:this.shape_99}]},1).to({state:[{t:this.shape_100}]},1).wait(1));

	// ani_backpressure_cover
	this.instance_3 = new lib.ani_backpressureMask();
	this.instance_3.setTransform(52.5,90.7,1,1,0,180,0,13.5,12.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(102));

	// Ebene 3
	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-83.6,0,81.2,0).ss(5,0,1).p("AsqAlIIgAAQD4gCBdAUQByAaBeBbQBgBdBrAXQBhAUBQgoQBOgoAehQQAghVgkhgQg+iujNg8QhAgThHgGIoEgB");
	this.shape_101.setTransform(81.2,120.2);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-83.6,0,81.2,0).ss(5.1,0,1).p("AsqAlIIgAAQD4gCBdAUQByAaBeBbQBgBdBrAXQBhAUBQgoQBOgoAehQQAghVgkhgQg+iujNg8QhAgThHgGIoEgB");
	this.shape_102.setTransform(81.2,120.2);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-83.7,0,81.1,0).ss(5.2,0,1).p("AsrAlIIgAAQD5gCBcAUQBzAaBeBbQBgBdBrAXQBhAUBQgoQBNgoAehQQAghVgjhgQg/iujNg8QhAgThGgGIoEgB");
	this.shape_103.setTransform(81.2,120.2);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-83.7,0,81.1,0).ss(5.3,0,1).p("AsrAlIIgAAQD5gCBcAUQBzAaBeBbQBgBdBrAXQBhAUBQgoQBNgoAehQQAghVgjhgQg/iujNg8QhAgThGgGIoEgB");
	this.shape_104.setTransform(81.2,120.2);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-83.7,0,81.1,0).ss(5.4,0,1).p("AsrAlIIgAAQD4gCBdAUQByAaBeBbQBgBdBrAXQBhAUBQgoQBOgoAehQQAghVgkhgQg+iujNg8QhAgThHgGIoEgB");
	this.shape_105.setTransform(81.3,120.2);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-83.7,0,81.1,0).ss(5.5,0,1).p("AsrAlIIgAAQD4gCBdAUQByAaBeBbQBgBdBrAXQBhAUBQgoQBOgoAehQQAghVgkhgQg+iujNg8QhAgThHgGIoEgB");
	this.shape_106.setTransform(81.3,120.2);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-83.8,0,81,0).ss(5.6,0,1).p("AssAlIIgAAQD5gCBcAUQBzAaBeBbQBgBdBrAXQBhAUBQgoQBNgoAehQQAghVgjhgQg/iujNg8QhAgThGgGIoEgB");
	this.shape_107.setTransform(81.3,120.2);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-83.8,0,81,0).ss(5.7,0,1).p("AssAlIIgAAQD5gCBcAUQBzAaBeBbQBgBdBrAXQBhAUBQgoQBNgoAehQQAghVgjhgQg/iujNg8QhAgThGgGIoEgB");
	this.shape_108.setTransform(81.3,120.2);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-83.8,0,81,0).ss(5.8,0,1).p("AssAlIIgAAQD4gCBdAUQByAaBeBbQBgBdBrAXQBhAUBQgoQBOgoAehQQAghVgkhgQg+iujNg8QhAgThHgGIoEgB");
	this.shape_109.setTransform(81.4,120.2);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-83.8,0,81,0).ss(5.9,0,1).p("AssAlIIgAAQD4gCBdAUQByAaBeBbQBgBdBrAXQBhAUBQgoQBOgoAehQQAghVgkhgQg+iujNg8QhAgThHgGIoEgB");
	this.shape_110.setTransform(81.4,120.2);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-83.9,0,80.9,0).ss(6,0,1).p("AstAlIIgAAQD5gCBcAUQBzAaBeBbQBgBdBrAXQBhAUBQgoQBNgoAehQQAghVgjhgQg/iujNg8QhAgThGgGIoEgB");
	this.shape_111.setTransform(81.4,120.2);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-83.9,0,80.9,0).ss(6.1,0,1).p("AstAlIIgAAQD5gCBcAUQBzAaBeBbQBgBdBrAXQBhAUBQgoQBNgoAehQQAghVgjhgQg/iujNg8QhAgThGgGIoEgB");
	this.shape_112.setTransform(81.4,120.2);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-83.9,0,80.9,0).ss(6.2,0,1).p("AstAlIIgAAQD4gCBdAUQByAaBeBbQBgBdBrAXQBhAUBQgoQBOgoAehQQAghVgkhgQg+iujNg8QhAgThHgGIoEgB");
	this.shape_113.setTransform(81.5,120.2);

	this.shape_114 = new cjs.Shape();
	this.shape_114.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-83.9,0,80.9,0).ss(6.3,0,1).p("AstAlIIgAAQD4gCBdAUQByAaBeBbQBgBdBrAXQBhAUBQgoQBOgoAehQQAghVgkhgQg+iujNg8QhAgThHgGIoEgB");
	this.shape_114.setTransform(81.5,120.2);

	this.shape_115 = new cjs.Shape();
	this.shape_115.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-84,0,80.8,0).ss(6.4,0,1).p("AsuAlIIgAAQD5gCBcAUQBzAaBeBbQBgBdBrAXQBhAUBQgoQBNgoAehQQAghVgjhgQg/iujNg8QhAgThGgGIoEgB");
	this.shape_115.setTransform(81.5,120.2);

	this.shape_116 = new cjs.Shape();
	this.shape_116.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-84,0,80.8,0).ss(6.5,0,1).p("AsuAlIIgAAQD5gCBcAUQBzAaBeBbQBgBdBrAXQBhAUBQgoQBNgoAehQQAghVgjhgQg/iujNg8QhAgThGgGIoEgB");
	this.shape_116.setTransform(81.5,120.2);

	this.shape_117 = new cjs.Shape();
	this.shape_117.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-84,0,80.8,0).ss(6.6,0,1).p("AsuAlIIgAAQD4gCBdAUQByAaBeBbQBgBdBrAXQBhAUBQgoQBOgoAehQQAghVgkhgQg+iujNg8QhAgThHgGIoEgB");
	this.shape_117.setTransform(81.6,120.2);

	this.shape_118 = new cjs.Shape();
	this.shape_118.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-84,0,80.8,0).ss(6.7,0,1).p("AsuAlIIgAAQD4gCBdAUQByAaBeBbQBgBdBrAXQBhAUBQgoQBOgoAehQQAghVgkhgQg+iujNg8QhAgThHgGIoEgB");
	this.shape_118.setTransform(81.6,120.2);

	this.shape_119 = new cjs.Shape();
	this.shape_119.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-84.1,0,80.7,0).ss(6.8,0,1).p("AsvAlIIgAAQD5gCBcAUQBzAaBeBbQBgBdBrAXQBhAUBQgoQBNgoAehQQAghVgjhgQg/iujNg8QhAgThGgGIoEgB");
	this.shape_119.setTransform(81.6,120.2);

	this.shape_120 = new cjs.Shape();
	this.shape_120.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-84.1,0,80.7,0).ss(6.9,0,1).p("AsvAlIIgAAQD5gCBcAUQBzAaBeBbQBgBdBrAXQBhAUBQgoQBNgoAehQQAghVgjhgQg/iujNg8QhAgThGgGIoEgB");
	this.shape_120.setTransform(81.6,120.2);

	this.shape_121 = new cjs.Shape();
	this.shape_121.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-84.1,0,80.7,0).ss(7,0,1).p("AsvAlIIgAAQD4gCBdAUQByAaBeBbQBgBdBrAXQBhAUBQgoQBOgoAehQQAghVgkhgQg+iujNg8QhAgThHgGIoEgB");
	this.shape_121.setTransform(81.7,120.2);

	this.shape_122 = new cjs.Shape();
	this.shape_122.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-84.1,0,80.7,0).ss(7.1,0,1).p("AsvAlIIgAAQD4gCBdAUQByAaBeBbQBgBdBrAXQBhAUBQgoQBOgoAehQQAghVgkhgQg+iujNg8QhAgThHgGIoEgB");
	this.shape_122.setTransform(81.7,120.2);

	this.shape_123 = new cjs.Shape();
	this.shape_123.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-84.2,0,80.6,0).ss(7.2,0,1).p("AswAlIIgAAQD5gCBcAUQBzAaBeBbQBgBdBrAXQBhAUBQgoQBNgoAehQQAghVgjhgQg/iujNg8QhAgThGgGIoEgB");
	this.shape_123.setTransform(81.7,120.2);

	this.shape_124 = new cjs.Shape();
	this.shape_124.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-84.2,0,80.6,0).ss(7.3,0,1).p("AswAlIIgAAQD5gCBcAUQBzAaBeBbQBgBdBrAXQBhAUBQgoQBNgoAehQQAghVgjhgQg/iujNg8QhAgThGgGIoEgB");
	this.shape_124.setTransform(81.7,120.2);

	this.shape_125 = new cjs.Shape();
	this.shape_125.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-84.2,0,80.6,0).ss(7.4,0,1).p("AswAlIIgAAQD4gCBdAUQByAaBeBbQBgBdBrAXQBhAUBQgoQBOgoAehQQAghVgkhgQg+iujNg8QhAgThHgGIoEgB");
	this.shape_125.setTransform(81.8,120.2);

	this.shape_126 = new cjs.Shape();
	this.shape_126.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-84.2,0,80.6,0).ss(7.5,0,1).p("AswAlIIgAAQD4gCBdAUQByAaBeBbQBgBdBrAXQBhAUBQgoQBOgoAehQQAghVgkhgQg+iujNg8QhAgThHgGIoEgB");
	this.shape_126.setTransform(81.8,120.2);

	this.shape_127 = new cjs.Shape();
	this.shape_127.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-84.2,0,80.6,0).ss(7.6,0,1).p("AswAlIIgAAQD4gCBdAUQByAaBeBbQBgBdBrAXQBhAUBQgoQBOgoAehQQAghVgkhgQg+iujNg8QhAgThHgGIoEgB");
	this.shape_127.setTransform(81.8,120.2);

	this.shape_128 = new cjs.Shape();
	this.shape_128.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-84.3,0,80.5,0).ss(7.7,0,1).p("AsxAlIIgAAQD5gCBcAUQBzAaBeBbQBgBdBrAXQBhAUBQgoQBNgoAehQQAghVgjhgQg/iujNg8QhAgThGgGIoEgB");
	this.shape_128.setTransform(81.8,120.2);

	this.shape_129 = new cjs.Shape();
	this.shape_129.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-84.3,0,80.5,0).ss(7.8,0,1).p("AsxAlIIgAAQD5gCBcAUQBzAaBeBbQBgBdBrAXQBhAUBQgoQBNgoAehQQAghVgjhgQg/iujNg8QhAgThGgGIoEgB");
	this.shape_129.setTransform(81.8,120.2);

	this.shape_130 = new cjs.Shape();
	this.shape_130.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-84.3,0,80.5,0).ss(7.9,0,1).p("AsxAlIIgAAQD4gCBdAUQByAaBeBbQBgBdBrAXQBhAUBQgoQBOgoAehQQAghVgkhgQg+iujNg8QhAgThHgGIoEgB");
	this.shape_130.setTransform(81.9,120.2);

	this.shape_131 = new cjs.Shape();
	this.shape_131.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-84.3,0,80.5,0).ss(8,0,1).p("AsxAlIIgAAQD4gCBdAUQByAaBeBbQBgBdBrAXQBhAUBQgoQBOgoAehQQAghVgkhgQg+iujNg8QhAgThHgGIoEgB");
	this.shape_131.setTransform(81.9,120.2);

	this.shape_132 = new cjs.Shape();
	this.shape_132.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-84.4,0,80.4,0).ss(8.1,0,1).p("AsyAlIIgAAQD5gCBcAUQBzAaBeBbQBgBdBrAXQBhAUBQgoQBNgoAehQQAghVgjhgQg/iujNg8QhAgThGgGIoEgB");
	this.shape_132.setTransform(81.9,120.2);

	this.shape_133 = new cjs.Shape();
	this.shape_133.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-84.4,0,80.4,0).ss(8.2,0,1).p("AsyAlIIgAAQD5gCBcAUQBzAaBeBbQBgBdBrAXQBhAUBQgoQBNgoAehQQAghVgjhgQg/iujNg8QhAgThGgGIoEgB");
	this.shape_133.setTransform(81.9,120.2);

	this.shape_134 = new cjs.Shape();
	this.shape_134.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-84.4,0,80.4,0).ss(8.3,0,1).p("AsyAlIIgAAQD4gCBdAUQByAaBeBbQBgBdBrAXQBhAUBQgoQBOgoAehQQAghVgkhgQg+iujNg8QhAgThHgGIoEgB");
	this.shape_134.setTransform(82,120.2);

	this.shape_135 = new cjs.Shape();
	this.shape_135.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-84.4,0,80.4,0).ss(8.4,0,1).p("AsyAlIIgAAQD4gCBdAUQByAaBeBbQBgBdBrAXQBhAUBQgoQBOgoAehQQAghVgkhgQg+iujNg8QhAgThHgGIoEgB");
	this.shape_135.setTransform(82,120.2);

	this.shape_136 = new cjs.Shape();
	this.shape_136.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-84.5,0,80.3,0).ss(8.5,0,1).p("AszAlIIgAAQD5gCBcAUQBzAaBeBbQBgBdBrAXQBhAUBQgoQBNgoAehQQAghVgjhgQg/iujNg8QhAgThGgGIoEgB");
	this.shape_136.setTransform(82,120.2);

	this.shape_137 = new cjs.Shape();
	this.shape_137.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-84.5,0,80.3,0).ss(8.6,0,1).p("AszAlIIgAAQD5gCBcAUQBzAaBeBbQBgBdBrAXQBhAUBQgoQBNgoAehQQAghVgjhgQg/iujNg8QhAgThGgGIoEgB");
	this.shape_137.setTransform(82,120.2);

	this.shape_138 = new cjs.Shape();
	this.shape_138.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-84.5,0,80.3,0).ss(8.7,0,1).p("AszAlIIgAAQD4gCBdAUQByAaBeBbQBgBdBrAXQBhAUBQgoQBOgoAehQQAghVgkhgQg+iujNg8QhAgThHgGIoEgB");
	this.shape_138.setTransform(82.1,120.2);

	this.shape_139 = new cjs.Shape();
	this.shape_139.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-84.5,0,80.3,0).ss(8.8,0,1).p("AszAlIIgAAQD4gCBdAUQByAaBeBbQBgBdBrAXQBhAUBQgoQBOgoAehQQAghVgkhgQg+iujNg8QhAgThHgGIoEgB");
	this.shape_139.setTransform(82.1,120.2);

	this.shape_140 = new cjs.Shape();
	this.shape_140.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-84.6,0,80.2,0).ss(8.9,0,1).p("As0AlIIgAAQD5gCBcAUQBzAaBeBbQBgBdBrAXQBhAUBQgoQBNgoAehQQAghVgjhgQg/iujNg8QhAgThGgGIoEgB");
	this.shape_140.setTransform(82.1,120.2);

	this.shape_141 = new cjs.Shape();
	this.shape_141.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-84.6,0,80.2,0).ss(9,0,1).p("As0AlIIgAAQD5gCBcAUQBzAaBeBbQBgBdBrAXQBhAUBQgoQBNgoAehQQAghVgjhgQg/iujNg8QhAgThGgGIoEgB");
	this.shape_141.setTransform(82.1,120.2);

	this.shape_142 = new cjs.Shape();
	this.shape_142.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-84.6,0,80.2,0).ss(9.1,0,1).p("As0AlIIgAAQD4gCBdAUQByAaBeBbQBgBdBrAXQBhAUBQgoQBOgoAehQQAghVgkhgQg+iujNg8QhAgThHgGIoEgB");
	this.shape_142.setTransform(82.2,120.2);

	this.shape_143 = new cjs.Shape();
	this.shape_143.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-84.6,0,80.2,0).ss(9.2,0,1).p("As0AlIIgAAQD4gCBdAUQByAaBeBbQBgBdBrAXQBhAUBQgoQBOgoAehQQAghVgkhgQg+iujNg8QhAgThHgGIoEgB");
	this.shape_143.setTransform(82.2,120.2);

	this.shape_144 = new cjs.Shape();
	this.shape_144.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-84.7,0,80.1,0).ss(9.3,0,1).p("As1AlIIgAAQD5gCBcAUQBzAaBeBbQBgBdBrAXQBhAUBQgoQBNgoAehQQAghVgjhgQg/iujNg8QhAgThGgGIoEgB");
	this.shape_144.setTransform(82.2,120.2);

	this.shape_145 = new cjs.Shape();
	this.shape_145.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-84.7,0,80.1,0).ss(9.4,0,1).p("As1AlIIgAAQD5gCBcAUQBzAaBeBbQBgBdBrAXQBhAUBQgoQBNgoAehQQAghVgjhgQg/iujNg8QhAgThGgGIoEgB");
	this.shape_145.setTransform(82.2,120.2);

	this.shape_146 = new cjs.Shape();
	this.shape_146.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-84.7,0,80.1,0).ss(9.5,0,1).p("As1AlIIgAAQD4gCBdAUQByAaBeBbQBgBdBrAXQBhAUBQgoQBOgoAehQQAghVgkhgQg+iujNg8QhAgThHgGIoEgB");
	this.shape_146.setTransform(82.3,120.2);

	this.shape_147 = new cjs.Shape();
	this.shape_147.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-84.7,0,80.1,0).ss(9.6,0,1).p("As1AlIIgAAQD4gCBdAUQByAaBeBbQBgBdBrAXQBhAUBQgoQBOgoAehQQAghVgkhgQg+iujNg8QhAgThHgGIoEgB");
	this.shape_147.setTransform(82.3,120.2);

	this.shape_148 = new cjs.Shape();
	this.shape_148.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-84.8,0,80,0).ss(9.7,0,1).p("As2AlIIgAAQD5gCBcAUQBzAaBeBbQBgBdBrAXQBhAUBQgoQBNgoAehQQAghVgjhgQg/iujNg8QhAgThGgGIoEgB");
	this.shape_148.setTransform(82.3,120.2);

	this.shape_149 = new cjs.Shape();
	this.shape_149.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-84.8,0,80,0).ss(9.8,0,1).p("As2AlIIgAAQD5gCBcAUQBzAaBeBbQBgBdBrAXQBhAUBQgoQBNgoAehQQAghVgjhgQg/iujNg8QhAgThGgGIoEgB");
	this.shape_149.setTransform(82.3,120.2);

	this.shape_150 = new cjs.Shape();
	this.shape_150.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-84.8,0,80,0).ss(9.9,0,1).p("As2AlIIgAAQD4gCBdAUQByAaBeBbQBgBdBrAXQBhAUBQgoQBOgoAehQQAghVgkhgQg+iujNg8QhAgThHgGIoEgB");
	this.shape_150.setTransform(82.4,120.2);

	this.shape_151 = new cjs.Shape();
	this.shape_151.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-84.8,0,80,0).ss(10,0,1).p("As2AlIIgAAQD4gCBdAUQByAaBeBbQBgBdBrAXQBhAUBQgoQBOgoAehQQAghVgkhgQg+iujNg8QhAgThHgGIoEgB");
	this.shape_151.setTransform(82.4,120.2);

	this.shape_152 = new cjs.Shape();
	this.shape_152.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-84.9,0,79.9,0).ss(10.1,0,1).p("As3AlIIgAAQD5gCBcAUQBzAaBeBbQBgBdBrAXQBhAUBQgoQBNgoAehQQAghVgjhgQg/iujNg8QhAgThGgGIoEgB");
	this.shape_152.setTransform(82.4,120.2);

	this.shape_153 = new cjs.Shape();
	this.shape_153.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-84.9,0,79.9,0).ss(10.2,0,1).p("As3AlIIgAAQD5gCBcAUQBzAaBeBbQBgBdBrAXQBhAUBQgoQBNgoAehQQAghVgjhgQg/iujNg8QhAgThGgGIoEgB");
	this.shape_153.setTransform(82.4,120.2);

	this.shape_154 = new cjs.Shape();
	this.shape_154.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-84.9,0,79.9,0).ss(10.3,0,1).p("As3AlIIgAAQD4gCBdAUQByAaBeBbQBgBdBrAXQBhAUBQgoQBOgoAehQQAghVgkhgQg+iujNg8QhAgThHgGIoEgB");
	this.shape_154.setTransform(82.5,120.2);

	this.shape_155 = new cjs.Shape();
	this.shape_155.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-84.9,0,79.9,0).ss(10.4,0,1).p("As3AlIIgAAQD4gCBdAUQByAaBeBbQBgBdBrAXQBhAUBQgoQBOgoAehQQAghVgkhgQg+iujNg8QhAgThHgGIoEgB");
	this.shape_155.setTransform(82.5,120.2);

	this.shape_156 = new cjs.Shape();
	this.shape_156.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-85,0,79.8,0).ss(10.5,0,1).p("As4AlIIgAAQD5gCBcAUQBzAaBeBbQBgBdBrAXQBhAUBQgoQBNgoAehQQAghVgjhgQg/iujNg8QhAgThGgGIoEgB");
	this.shape_156.setTransform(82.5,120.2);

	this.shape_157 = new cjs.Shape();
	this.shape_157.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-85,0,79.8,0).ss(10.6,0,1).p("As4AlIIgAAQD5gCBcAUQBzAaBeBbQBgBdBrAXQBhAUBQgoQBNgoAehQQAghVgjhgQg/iujNg8QhAgThGgGIoEgB");
	this.shape_157.setTransform(82.5,120.2);

	this.shape_158 = new cjs.Shape();
	this.shape_158.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-85,0,79.8,0).ss(10.7,0,1).p("As4AlIIgAAQD4gCBdAUQByAaBeBbQBgBdBrAXQBhAUBQgoQBOgoAehQQAghVgkhgQg+iujNg8QhAgThHgGIoEgB");
	this.shape_158.setTransform(82.6,120.2);

	this.shape_159 = new cjs.Shape();
	this.shape_159.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-85,0,79.8,0).ss(10.8,0,1).p("As4AlIIgAAQD4gCBdAUQByAaBeBbQBgBdBrAXQBhAUBQgoQBOgoAehQQAghVgkhgQg+iujNg8QhAgThHgGIoEgB");
	this.shape_159.setTransform(82.6,120.2);

	this.shape_160 = new cjs.Shape();
	this.shape_160.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-85.1,0,79.7,0).ss(10.9,0,1).p("As5AlIIgAAQD5gCBcAUQBzAaBeBbQBgBdBrAXQBhAUBQgoQBNgoAehQQAghVgjhgQg/iujNg8QhAgThGgGIoEgB");
	this.shape_160.setTransform(82.6,120.2);

	this.shape_161 = new cjs.Shape();
	this.shape_161.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-85.1,0,79.7,0).ss(11,0,1).p("As5AlIIgAAQD5gCBcAUQBzAaBeBbQBgBdBrAXQBhAUBQgoQBNgoAehQQAghVgjhgQg/iujNg8QhAgThGgGIoEgB");
	this.shape_161.setTransform(82.6,120.2);

	this.shape_162 = new cjs.Shape();
	this.shape_162.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-85.1,0,79.7,0).ss(11.1,0,1).p("As5AlIIgAAQD4gCBdAUQByAaBeBbQBgBdBrAXQBhAUBQgoQBOgoAehQQAghVgkhgQg+iujNg8QhAgThHgGIoEgB");
	this.shape_162.setTransform(82.7,120.2);

	this.shape_163 = new cjs.Shape();
	this.shape_163.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-85.1,0,79.7,0).ss(11.2,0,1).p("As5AlIIgAAQD4gCBdAUQByAaBeBbQBgBdBrAXQBhAUBQgoQBOgoAehQQAghVgkhgQg+iujNg8QhAgThHgGIoEgB");
	this.shape_163.setTransform(82.7,120.2);

	this.shape_164 = new cjs.Shape();
	this.shape_164.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-85.2,0,79.6,0).ss(11.3,0,1).p("As6AlIIgAAQD5gCBcAUQBzAaBeBbQBgBdBrAXQBhAUBQgoQBNgoAehQQAghVgjhgQg/iujNg8QhAgThGgGIoEgB");
	this.shape_164.setTransform(82.7,120.2);

	this.shape_165 = new cjs.Shape();
	this.shape_165.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-85.2,0,79.6,0).ss(11.4,0,1).p("As6AlIIgAAQD5gCBcAUQBzAaBeBbQBgBdBrAXQBhAUBQgoQBNgoAehQQAghVgjhgQg/iujNg8QhAgThGgGIoEgB");
	this.shape_165.setTransform(82.7,120.2);

	this.shape_166 = new cjs.Shape();
	this.shape_166.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-85.2,0,79.6,0).ss(11.5,0,1).p("As6AlIIgAAQD4gCBdAUQByAaBeBbQBgBdBrAXQBhAUBQgoQBOgoAehQQAghVgkhgQg+iujNg8QhAgThHgGIoEgB");
	this.shape_166.setTransform(82.8,120.2);

	this.shape_167 = new cjs.Shape();
	this.shape_167.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-85.2,0,79.6,0).ss(11.6,0,1).p("As6AlIIgAAQD4gCBdAUQByAaBeBbQBgBdBrAXQBhAUBQgoQBOgoAehQQAghVgkhgQg+iujNg8QhAgThHgGIoEgB");
	this.shape_167.setTransform(82.8,120.2);

	this.shape_168 = new cjs.Shape();
	this.shape_168.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-85.3,0,79.5,0).ss(11.7,0,1).p("As7AlIIgAAQD5gCBcAUQBzAaBeBbQBgBdBrAXQBhAUBQgoQBNgoAehQQAghVgjhgQg/iujNg8QhAgThGgGIoEgB");
	this.shape_168.setTransform(82.8,120.2);

	this.shape_169 = new cjs.Shape();
	this.shape_169.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-85.3,0,79.5,0).ss(11.8,0,1).p("As7AlIIgAAQD5gCBcAUQBzAaBeBbQBgBdBrAXQBhAUBQgoQBNgoAehQQAghVgjhgQg/iujNg8QhAgThGgGIoEgB");
	this.shape_169.setTransform(82.8,120.2);

	this.shape_170 = new cjs.Shape();
	this.shape_170.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-85.3,0,79.5,0).ss(11.9,0,1).p("As7AlIIgAAQD4gCBdAUQByAaBeBbQBgBdBrAXQBhAUBQgoQBOgoAehQQAghVgkhgQg+iujNg8QhAgThHgGIoEgB");
	this.shape_170.setTransform(82.9,120.2);

	this.shape_171 = new cjs.Shape();
	this.shape_171.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-85.3,0,79.5,0).ss(12,0,1).p("As7AlIIgAAQD4gCBdAUQByAaBeBbQBgBdBrAXQBhAUBQgoQBOgoAehQQAghVgkhgQg+iujNg8QhAgThHgGIoEgB");
	this.shape_171.setTransform(82.9,120.2);

	this.shape_172 = new cjs.Shape();
	this.shape_172.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-85.4,0,79.4,0).ss(12.1,0,1).p("As8AlIIgAAQD5gCBcAUQBzAaBeBbQBgBdBrAXQBhAUBQgoQBNgoAehQQAghVgjhgQg/iujNg8QhAgThGgGIoEgB");
	this.shape_172.setTransform(82.9,120.2);

	this.shape_173 = new cjs.Shape();
	this.shape_173.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-85.4,0,79.4,0).ss(12.2,0,1).p("As8AlIIgAAQD5gCBcAUQBzAaBeBbQBgBdBrAXQBhAUBQgoQBNgoAehQQAghVgjhgQg/iujNg8QhAgThGgGIoEgB");
	this.shape_173.setTransform(82.9,120.2);

	this.shape_174 = new cjs.Shape();
	this.shape_174.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-85.4,0,79.4,0).ss(12.3,0,1).p("As8AlIIgAAQD4gCBdAUQByAaBeBbQBgBdBrAXQBhAUBQgoQBOgoAehQQAghVgkhgQg+iujNg8QhAgThHgGIoEgB");
	this.shape_174.setTransform(83,120.2);

	this.shape_175 = new cjs.Shape();
	this.shape_175.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-85.4,0,79.4,0).ss(12.4,0,1).p("As8AlIIgAAQD4gCBdAUQByAaBeBbQBgBdBrAXQBhAUBQgoQBOgoAehQQAghVgkhgQg+iujNg8QhAgThHgGIoEgB");
	this.shape_175.setTransform(83,120.2);

	this.shape_176 = new cjs.Shape();
	this.shape_176.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-85.5,0,79.3,0).ss(12.5,0,1).p("As9AlIIgAAQD5gCBcAUQBzAaBeBbQBgBdBrAXQBhAUBQgoQBNgoAehQQAghVgjhgQg/iujNg8QhAgThGgGIoEgB");
	this.shape_176.setTransform(83,120.2);

	this.shape_177 = new cjs.Shape();
	this.shape_177.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-85.5,0,79.3,0).ss(12.6,0,1).p("As9AlIIgAAQD4gCBdAUQByAaBeBbQBgBdBrAXQBhAUBQgoQBOgoAehQQAghVgkhgQg+iujNg8QhAgThHgGIoEgB");
	this.shape_177.setTransform(83.1,120.2);

	this.shape_178 = new cjs.Shape();
	this.shape_178.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-85.5,0,79.3,0).ss(12.7,0,1).p("As9AlIIgAAQD4gCBdAUQByAaBeBbQBgBdBrAXQBhAUBQgoQBOgoAehQQAghVgkhgQg+iujNg8QhAgThHgGIoEgB");
	this.shape_178.setTransform(83.1,120.2);

	this.shape_179 = new cjs.Shape();
	this.shape_179.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-85.6,0,79.2,0).ss(12.8,0,1).p("As+AlIIgAAQD5gCBcAUQBzAaBeBbQBgBdBrAXQBhAUBQgoQBNgoAehQQAghVgjhgQg/iujNg8QhAgThGgGIoEgB");
	this.shape_179.setTransform(83.1,120.2);

	this.shape_180 = new cjs.Shape();
	this.shape_180.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-85.6,0,79.2,0).ss(12.9,0,1).p("As+AlIIgAAQD5gCBcAUQBzAaBeBbQBgBdBrAXQBhAUBQgoQBNgoAehQQAghVgjhgQg/iujNg8QhAgThGgGIoEgB");
	this.shape_180.setTransform(83.1,120.2);

	this.shape_181 = new cjs.Shape();
	this.shape_181.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-85.6,0,79.2,0).ss(13,0,1).p("As+AlIIgAAQD4gCBdAUQByAaBeBbQBgBdBrAXQBhAUBQgoQBOgoAehQQAghVgkhgQg+iujNg8QhAgThHgGIoEgB");
	this.shape_181.setTransform(83.2,120.2);

	this.shape_182 = new cjs.Shape();
	this.shape_182.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-85.6,0,79.2,0).ss(13.1,0,1).p("As+AlIIgAAQD4gCBdAUQByAaBeBbQBgBdBrAXQBhAUBQgoQBOgoAehQQAghVgkhgQg+iujNg8QhAgThHgGIoEgB");
	this.shape_182.setTransform(83.2,120.2);

	this.shape_183 = new cjs.Shape();
	this.shape_183.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-85.7,0,79.1,0).ss(13.2,0,1).p("As/AlIIgAAQD5gCBcAUQBzAaBeBbQBgBdBrAXQBhAUBQgoQBNgoAehQQAghVgjhgQg/iujNg8QhAgThGgGIoEgB");
	this.shape_183.setTransform(83.2,120.2);

	this.shape_184 = new cjs.Shape();
	this.shape_184.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-85.7,0,79.1,0).ss(13.3,0,1).p("As/AlIIgAAQD5gCBcAUQBzAaBeBbQBgBdBrAXQBhAUBQgoQBNgoAehQQAghVgjhgQg/iujNg8QhAgThGgGIoEgB");
	this.shape_184.setTransform(83.2,120.2);

	this.shape_185 = new cjs.Shape();
	this.shape_185.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-85.7,0,79.1,0).ss(13.4,0,1).p("As/AlIIgAAQD4gCBdAUQByAaBeBbQBgBdBrAXQBhAUBQgoQBOgoAehQQAghVgkhgQg+iujNg8QhAgThHgGIoEgB");
	this.shape_185.setTransform(83.3,120.2);

	this.shape_186 = new cjs.Shape();
	this.shape_186.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-85.7,0,79.1,0).ss(13.5,0,1).p("As/AlIIgAAQD4gCBdAUQByAaBeBbQBgBdBrAXQBhAUBQgoQBOgoAehQQAghVgkhgQg+iujNg8QhAgThHgGIoEgB");
	this.shape_186.setTransform(83.3,120.2);

	this.shape_187 = new cjs.Shape();
	this.shape_187.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-85.8,0,79,0).ss(13.6,0,1).p("AtAAlIIgAAQD5gCBcAUQBzAaBeBbQBgBdBrAXQBhAUBQgoQBNgoAehQQAghVgjhgQg/iujNg8QhAgThGgGIoEgB");
	this.shape_187.setTransform(83.3,120.2);

	this.shape_188 = new cjs.Shape();
	this.shape_188.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-85.8,0,79,0).ss(13.7,0,1).p("AtAAlIIgAAQD5gCBcAUQBzAaBeBbQBgBdBrAXQBhAUBQgoQBNgoAehQQAghVgjhgQg/iujNg8QhAgThGgGIoEgB");
	this.shape_188.setTransform(83.3,120.2);

	this.shape_189 = new cjs.Shape();
	this.shape_189.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-85.8,0,79,0).ss(13.8,0,1).p("AtAAlIIgAAQD4gCBdAUQByAaBeBbQBgBdBrAXQBhAUBQgoQBOgoAehQQAghVgkhgQg+iujNg8QhAgThHgGIoEgB");
	this.shape_189.setTransform(83.4,120.2);

	this.shape_190 = new cjs.Shape();
	this.shape_190.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-85.8,0,79,0).ss(13.9,0,1).p("AtAAlIIgAAQD4gCBdAUQByAaBeBbQBgBdBrAXQBhAUBQgoQBOgoAehQQAghVgkhgQg+iujNg8QhAgThHgGIoEgB");
	this.shape_190.setTransform(83.4,120.2);

	this.shape_191 = new cjs.Shape();
	this.shape_191.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-85.9,0,78.9,0).ss(14,0,1).p("AtBAlIIgAAQD5gCBcAUQBzAaBeBbQBgBdBrAXQBhAUBQgoQBNgoAehQQAghVgjhgQg/iujNg8QhAgThGgGIoEgB");
	this.shape_191.setTransform(83.4,120.2);

	this.shape_192 = new cjs.Shape();
	this.shape_192.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-85.9,0,78.9,0).ss(14.1,0,1).p("AtBAlIIgAAQD5gCBcAUQBzAaBeBbQBgBdBrAXQBhAUBQgoQBNgoAehQQAghVgjhgQg/iujNg8QhAgThGgGIoEgB");
	this.shape_192.setTransform(83.4,120.2);

	this.shape_193 = new cjs.Shape();
	this.shape_193.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-85.9,0,78.9,0).ss(14.2,0,1).p("AtBAlIIgAAQD4gCBdAUQByAaBeBbQBgBdBrAXQBhAUBQgoQBOgoAehQQAghVgkhgQg+iujNg8QhAgThHgGIoEgB");
	this.shape_193.setTransform(83.5,120.2);

	this.shape_194 = new cjs.Shape();
	this.shape_194.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-85.9,0,78.9,0).ss(14.3,0,1).p("AtBAlIIgAAQD4gCBdAUQByAaBeBbQBgBdBrAXQBhAUBQgoQBOgoAehQQAghVgkhgQg+iujNg8QhAgThHgGIoEgB");
	this.shape_194.setTransform(83.5,120.2);

	this.shape_195 = new cjs.Shape();
	this.shape_195.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-86,0,78.8,0).ss(14.4,0,1).p("AtCAlIIgAAQD5gCBcAUQBzAaBeBbQBgBdBrAXQBhAUBQgoQBNgoAehQQAghVgjhgQg/iujNg8QhAgThGgGIoEgB");
	this.shape_195.setTransform(83.5,120.2);

	this.shape_196 = new cjs.Shape();
	this.shape_196.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-86,0,78.8,0).ss(14.5,0,1).p("AtCAlIIgAAQD5gCBcAUQBzAaBeBbQBgBdBrAXQBhAUBQgoQBNgoAehQQAghVgjhgQg/iujNg8QhAgThGgGIoEgB");
	this.shape_196.setTransform(83.5,120.2);

	this.shape_197 = new cjs.Shape();
	this.shape_197.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-86,0,78.8,0).ss(14.6,0,1).p("AtCAlIIgAAQD4gCBdAUQByAaBeBbQBgBdBrAXQBhAUBQgoQBOgoAehQQAghVgkhgQg+iujNg8QhAgThHgGIoEgB");
	this.shape_197.setTransform(83.6,120.2);

	this.shape_198 = new cjs.Shape();
	this.shape_198.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-86,0,78.8,0).ss(14.7,0,1).p("AtCAlIIgAAQD4gCBdAUQByAaBeBbQBgBdBrAXQBhAUBQgoQBOgoAehQQAghVgkhgQg+iujNg8QhAgThHgGIoEgB");
	this.shape_198.setTransform(83.6,120.2);

	this.shape_199 = new cjs.Shape();
	this.shape_199.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-86.1,0,78.7,0).ss(14.8,0,1).p("AtDAlIIgAAQD5gCBcAUQBzAaBeBbQBgBdBrAXQBhAUBQgoQBNgoAehQQAghVgjhgQg/iujNg8QhAgThGgGIoEgB");
	this.shape_199.setTransform(83.6,120.2);

	this.shape_200 = new cjs.Shape();
	this.shape_200.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-86.1,0,78.7,0).ss(14.9,0,1).p("AtDAlIIgAAQD5gCBcAUQBzAaBeBbQBgBdBrAXQBhAUBQgoQBNgoAehQQAghVgjhgQg/iujNg8QhAgThGgGIoEgB");
	this.shape_200.setTransform(83.6,120.2);

	this.shape_201 = new cjs.Shape();
	this.shape_201.graphics.f().ls(["rgba(213,0,28,0)","#D5001C"],[0,0.161],-86.1,0,78.7,0).ss(15,0,1).p("AtDAlIIgAAQD4gCBdAUQByAaBeBbQBgBdBrAXQBhAUBQgoQBOgoAehQQAghVgkhgQg+iujNg8QhAgThHgGIoEgB");
	this.shape_201.setTransform(83.7,120.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_101}]}).to({state:[{t:this.shape_102}]},1).to({state:[{t:this.shape_103}]},1).to({state:[{t:this.shape_104}]},1).to({state:[{t:this.shape_105}]},1).to({state:[{t:this.shape_106}]},1).to({state:[{t:this.shape_107}]},1).to({state:[{t:this.shape_108}]},1).to({state:[{t:this.shape_109}]},1).to({state:[{t:this.shape_110}]},1).to({state:[{t:this.shape_111}]},1).to({state:[{t:this.shape_112}]},1).to({state:[{t:this.shape_113}]},1).to({state:[{t:this.shape_114}]},1).to({state:[{t:this.shape_115}]},1).to({state:[{t:this.shape_116}]},1).to({state:[{t:this.shape_117}]},1).to({state:[{t:this.shape_118}]},1).to({state:[{t:this.shape_119}]},1).to({state:[{t:this.shape_120}]},1).to({state:[{t:this.shape_121}]},1).to({state:[{t:this.shape_122}]},1).to({state:[{t:this.shape_123}]},1).to({state:[{t:this.shape_124}]},1).to({state:[{t:this.shape_125}]},1).to({state:[{t:this.shape_126}]},1).to({state:[{t:this.shape_127}]},1).to({state:[{t:this.shape_128}]},1).to({state:[{t:this.shape_129}]},1).to({state:[{t:this.shape_130}]},1).to({state:[{t:this.shape_131}]},1).to({state:[{t:this.shape_132}]},1).to({state:[{t:this.shape_133}]},1).to({state:[{t:this.shape_134}]},1).to({state:[{t:this.shape_135}]},1).to({state:[{t:this.shape_136}]},1).to({state:[{t:this.shape_137}]},1).to({state:[{t:this.shape_138}]},1).to({state:[{t:this.shape_139}]},1).to({state:[{t:this.shape_140}]},1).to({state:[{t:this.shape_141}]},1).to({state:[{t:this.shape_142}]},1).to({state:[{t:this.shape_143}]},1).to({state:[{t:this.shape_144}]},1).to({state:[{t:this.shape_145}]},1).to({state:[{t:this.shape_146}]},1).to({state:[{t:this.shape_147}]},1).to({state:[{t:this.shape_148}]},1).to({state:[{t:this.shape_149}]},1).to({state:[{t:this.shape_150}]},1).to({state:[{t:this.shape_151}]},1).to({state:[{t:this.shape_152}]},1).to({state:[{t:this.shape_153}]},1).to({state:[{t:this.shape_154}]},1).to({state:[{t:this.shape_155}]},1).to({state:[{t:this.shape_156}]},1).to({state:[{t:this.shape_157}]},1).to({state:[{t:this.shape_158}]},1).to({state:[{t:this.shape_159}]},1).to({state:[{t:this.shape_160}]},1).to({state:[{t:this.shape_161}]},1).to({state:[{t:this.shape_162}]},1).to({state:[{t:this.shape_163}]},1).to({state:[{t:this.shape_164}]},1).to({state:[{t:this.shape_165}]},1).to({state:[{t:this.shape_166}]},1).to({state:[{t:this.shape_167}]},1).to({state:[{t:this.shape_168}]},1).to({state:[{t:this.shape_169}]},1).to({state:[{t:this.shape_170}]},1).to({state:[{t:this.shape_171}]},1).to({state:[{t:this.shape_172}]},1).to({state:[{t:this.shape_173}]},1).to({state:[{t:this.shape_174}]},1).to({state:[{t:this.shape_175}]},1).to({state:[{t:this.shape_176}]},1).to({state:[{t:this.shape_176}]},1).to({state:[{t:this.shape_177}]},1).to({state:[{t:this.shape_178}]},1).to({state:[{t:this.shape_179}]},1).to({state:[{t:this.shape_180}]},1).to({state:[{t:this.shape_181}]},1).to({state:[{t:this.shape_182}]},1).to({state:[{t:this.shape_183}]},1).to({state:[{t:this.shape_184}]},1).to({state:[{t:this.shape_185}]},1).to({state:[{t:this.shape_186}]},1).to({state:[{t:this.shape_187}]},1).to({state:[{t:this.shape_188}]},1).to({state:[{t:this.shape_189}]},1).to({state:[{t:this.shape_190}]},1).to({state:[{t:this.shape_191}]},1).to({state:[{t:this.shape_192}]},1).to({state:[{t:this.shape_193}]},1).to({state:[{t:this.shape_194}]},1).to({state:[{t:this.shape_195}]},1).to({state:[{t:this.shape_196}]},1).to({state:[{t:this.shape_197}]},1).to({state:[{t:this.shape_198}]},1).to({state:[{t:this.shape_199}]},1).to({state:[{t:this.shape_200}]},1).to({state:[{t:this.shape_201}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-24.5,-24.1,339,197.9);


(lib.ani_airflow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 4
	this.instance = new lib.ani_airflow_();
	this.instance.setTransform(-900,72.7,1,1,0,0,0,700,22.7);
	this.instance.filters = [new cjs.BlurFilter(15, 15, 3)];
	this.instance.cache(-2,-9,4205,67);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({regX:2100,regY:24,scaleY:0.97,x:520.3,y:74.9},0).wait(1).to({scaleY:0.95,x:540.6,y:75.8},0).wait(1).to({scaleY:0.92,x:560.9,y:76.7},0).wait(1).to({scaleY:0.9,x:581.1,y:77.7},0).wait(1).to({scaleY:0.87,x:601.4,y:78.6},0).wait(1).to({scaleY:0.84,x:621.7,y:79.5},0).wait(1).to({scaleY:0.82,x:642,y:80.4},0).wait(1).to({scaleY:0.79,x:662.3,y:81.4},0).wait(1).to({scaleY:0.77,x:682.6,y:82.3},0).wait(1).to({scaleY:0.74,x:702.9,y:83.2},0).wait(1).to({scaleY:0.71,x:723.2,y:84.1},0).wait(1).to({scaleY:0.69,x:743.4,y:85.1},0).wait(1).to({scaleY:0.66,x:763.7,y:86},0).wait(1).to({scaleY:0.64,x:784,y:86.9},0).wait(1).to({scaleY:0.61,x:804.3,y:87.8},0).wait(1).to({scaleY:0.58,x:824.6,y:88.8},0).wait(1).to({scaleY:0.56,x:844.9,y:89.7},0).wait(1).to({scaleY:0.53,x:865.2,y:90.6},0).wait(1).to({scaleY:0.5,x:885.5,y:91.5},0).wait(1).to({scaleY:0.48,x:905.7,y:92.5},0).wait(1).to({scaleY:0.45,x:926,y:93.4},0).wait(1).to({scaleY:0.43,x:946.3,y:94.3},0).wait(1).to({regX:700,regY:22.9,scaleY:0.4,x:-433.4,y:94.7},0).wait(1).to({regX:2100,regY:24,scaleY:0.41,x:986.9},0).wait(1).to({scaleY:0.43,x:1007.2,y:94.2},0).wait(1).to({scaleY:0.44,x:1027.5,y:93.8},0).wait(1).to({scaleY:0.45,x:1047.8,y:93.3},0).wait(1).to({scaleY:0.47,x:1068.1,y:92.8},0).wait(1).to({scaleY:0.48,x:1088.3,y:92.4},0).wait(1).to({scaleY:0.49,x:1108.6,y:91.9},0).wait(1).to({scaleY:0.5,x:1128.9,y:91.4},0).wait(1).to({scaleY:0.52,x:1149.2,y:91},0).wait(1).to({scaleY:0.53,x:1169.5,y:90.5},0).wait(1).to({scaleY:0.54,x:1189.8,y:90.1},0).wait(1).to({scaleY:0.56,x:1210.1,y:89.6},0).wait(1).to({scaleY:0.57,x:1230.4,y:89.1},0).wait(1).to({scaleY:0.58,x:1250.7,y:88.7},0).wait(1).to({scaleY:0.6,x:1271,y:88.2},0).wait(1).to({scaleY:0.61,x:1291.3,y:87.7},0).wait(1).to({scaleY:0.62,x:1311.6,y:87.2},0).wait(1).to({scaleY:0.64,x:1331.8,y:86.8},0).wait(1).to({scaleY:0.65,x:1352.1,y:86.3},0).wait(1).to({scaleY:0.66,x:1372.4,y:85.9},0).wait(1).to({scaleY:0.67,x:1392.7,y:85.4},0).wait(1).to({scaleY:0.69,x:1413,y:85},0).wait(1).to({scaleY:0.7,x:1433.3,y:84.5},0).wait(1).to({scaleY:0.71,x:1453.6,y:84},0).wait(1).to({scaleY:0.73,x:1473.9,y:83.6},0).wait(1).to({scaleY:0.74,x:1494.2,y:83.1},0).wait(1).to({scaleY:0.75,x:1514.5,y:82.6},0).wait(1).to({scaleY:0.77,x:1534.8,y:82.1},0).wait(1).to({scaleY:0.78,x:1555,y:81.7},0).wait(1).to({scaleY:0.79,x:1575.3,y:81.2},0).wait(1).to({scaleY:0.8,x:1595.6,y:80.8},0).wait(1).to({scaleY:0.82,x:1615.9,y:80.3},0).wait(1).to({scaleY:0.83,x:1636.2,y:79.9},0).wait(1).to({scaleY:0.84,x:1656.5,y:79.4},0).wait(1).to({scaleY:0.86,x:1676.8,y:78.9},0).wait(1).to({scaleY:0.87,x:1697.1,y:78.4},0).wait(1).to({scaleY:0.88,x:1717.4,y:78},0).wait(1).to({scaleY:0.9,x:1737.7,y:77.5},0).wait(1).to({scaleY:0.91,x:1758,y:77},0).wait(1).to({scaleY:0.92,x:1778.3,y:76.6},0).wait(1).to({scaleY:0.94,x:1798.5,y:76.1},0).wait(1).to({scaleY:0.95,x:1818.8,y:75.7},0).wait(1).to({scaleY:0.96,x:1839.1,y:75.2},0).wait(1).to({scaleY:0.97,x:1859.4,y:74.7},0).wait(1).to({scaleY:0.99,x:1879.7,y:74.3},0).wait(1).to({regX:700,regY:22.7,scaleY:1,x:500,y:72.7},0).wait(1));

	// Ebene 3
	this.instance_1 = new lib.ani_airflow_();
	this.instance_1.setTransform(-1400,119.7,1,1,0,0,0,700,22.7);
	this.instance_1.filters = [new cjs.BlurFilter(15, 15, 3)];
	this.instance_1.cache(-2,-9,4205,67);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({regX:2100,regY:24,scaleY:0.99,x:20.3,y:120.5},0).wait(1).to({scaleY:0.97,x:40.6,y:120},0).wait(1).to({scaleY:0.96,x:60.9,y:119.5},0).wait(1).to({scaleY:0.95,x:81.2,y:119},0).wait(1).to({scaleY:0.93,x:101.4,y:118.5},0).wait(1).to({scaleY:0.92,x:121.7,y:118},0).wait(1).to({scaleY:0.91,x:142,y:117.4},0).wait(1).to({scaleY:0.89,x:162.3,y:117},0).wait(1).to({scaleY:0.88,x:182.6,y:116.4},0).wait(1).to({scaleY:0.87,x:202.9,y:115.9},0).wait(1).to({scaleY:0.85,x:223.2,y:115.5},0).wait(1).to({scaleY:0.84,x:243.5,y:114.9},0).wait(1).to({scaleY:0.83,x:263.8,y:114.4},0).wait(1).to({scaleY:0.81,x:284,y:113.9},0).wait(1).to({scaleY:0.8,x:304.3,y:113.4},0).wait(1).to({scaleY:0.79,x:324.6,y:112.9},0).wait(1).to({scaleY:0.77,x:344.9,y:112.4},0).wait(1).to({scaleY:0.76,x:365.2,y:111.9},0).wait(1).to({scaleY:0.75,x:385.5,y:111.4},0).wait(1).to({scaleY:0.73,x:405.8,y:110.9},0).wait(1).to({scaleY:0.72,x:426.1,y:110.4},0).wait(1).to({scaleY:0.71,x:446.4,y:109.9},0).wait(1).to({scaleY:0.69,x:466.6,y:109.4},0).wait(1).to({scaleY:0.68,x:486.9,y:108.8},0).wait(1).to({scaleY:0.67,x:507.2,y:108.3},0).wait(1).to({scaleY:0.65,x:527.5,y:107.9},0).wait(1).to({scaleY:0.64,x:547.8,y:107.3},0).wait(1).to({scaleY:0.63,x:568.1,y:106.8},0).wait(1).to({scaleY:0.61,x:588.4,y:106.3},0).wait(1).to({scaleY:0.6,x:608.7,y:105.8},0).wait(1).to({scaleY:0.59,x:629,y:105.3},0).wait(1).to({scaleY:0.57,x:649.2,y:104.8},0).wait(1).to({scaleY:0.56,x:669.5,y:104.3},0).wait(1).to({scaleY:0.55,x:689.8,y:103.8},0).wait(1).to({scaleY:0.53,x:710.1,y:103.3},0).wait(1).to({scaleY:0.52,x:730.4,y:102.8},0).wait(1).to({scaleY:0.51,x:750.7,y:102.3},0).wait(1).to({scaleY:0.49,x:771,y:101.8},0).wait(1).to({scaleY:0.48,x:791.3,y:101.2},0).wait(1).to({scaleY:0.47,x:811.6,y:100.8},0).wait(1).to({scaleY:0.45,x:831.8,y:100.3},0).wait(1).to({scaleY:0.44,x:852.1,y:99.7},0).wait(1).to({scaleY:0.43,x:872.4,y:99.3},0).wait(1).to({scaleY:0.41,x:892.7,y:98.7},0).wait(1).to({regX:700,regY:22.9,scaleY:0.4,x:-487,y:97.7},0).wait(1).to({regX:2100,regY:24,scaleY:0.43,x:933.3,y:99.1},0).wait(1).to({scaleY:0.45,x:953.6,y:100},0).wait(1).to({scaleY:0.48,x:973.9,y:101},0).wait(1).to({scaleY:0.5,x:994.2,y:101.9},0).wait(1).to({scaleY:0.53,x:1014.5,y:102.8},0).wait(1).to({scaleY:0.55,x:1034.7,y:103.8},0).wait(1).to({scaleY:0.57,x:1055,y:104.7},0).wait(1).to({scaleY:0.6,x:1075.3,y:105.7},0).wait(1).to({scaleY:0.63,x:1095.6,y:106.6},0).wait(1).to({scaleY:0.65,x:1115.9,y:107.5},0).wait(1).to({scaleY:0.68,x:1136.2,y:108.5},0).wait(1).to({scaleY:0.7,x:1156.5,y:109.4},0).wait(1).to({scaleY:0.73,x:1176.8,y:110.4},0).wait(1).to({scaleY:0.75,x:1197.1,y:111.3},0).wait(1).to({scaleY:0.78,x:1217.4,y:112.2},0).wait(1).to({scaleY:0.8,x:1237.7,y:113.2},0).wait(1).to({scaleY:0.83,x:1258,y:114.1},0).wait(1).to({scaleY:0.85,x:1278.2,y:115.1},0).wait(1).to({scaleY:0.88,x:1298.5,y:116},0).wait(1).to({scaleY:0.9,x:1318.8,y:116.9},0).wait(1).to({scaleY:0.93,x:1339.1,y:117.9},0).wait(1).to({scaleY:0.95,x:1359.4,y:118.8},0).wait(1).to({scaleY:0.98,x:1379.7,y:119.8},0).wait(1).to({regX:700,regY:22.7,scaleY:1,x:0,y:119.7},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-2156.6,-6.5,4819,214);


(lib.popup02 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgMAnQgGgDgEgFQgDgFgCgIQgCgIAAgKQAAgVAHgJQAJgKAOAAQAIAAAFACQAGADADAFQAEAFACAHQABAIAAAJIAAACIguAAIABAPQABAGACADQACADAFABIAGABQAIAAAEgDQAEgDABgIIALAAQgBAMgGAGQgHAHgOAAQgGAAgHgCgAgFgcQgDABgDADIgDAGIgCALIAiAAQAAgHgCgEQgBgEgCgCQgCgDgDgBIgIAAIgFAAg");
	this.shape.setTransform(1373.6,155);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AALAxQgWAAAAgZIAAgqIgLAAIAAgLIALAAIAAgUIALAAIAAAUIAXAAIAAALIgXAAIAAAqQAAAIACAEQADADAIAAIAKAAIAAAKg");
	this.shape_1.setTransform(1367.1,154.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgMAnQgFgCgDgDQgDgDgBgEIgCgKIALAAQABAIAEADQAEADAGAAQAIAAAEgDQADgDAAgGIgBgFQAAgBAAAAQAAgBgBAAQAAgBAAAAQgBAAAAgBIgEgCIgIgCIgGgCQgJgCgFgEQgGgFAAgKQAAgMAHgGQAIgFALAAQAMAAAHAFQAHAGAAAOIgLAAQgBgIgDgDQgEgDgHAAQgHAAgDADQgDADAAAGQAAAFADADQACACAIACIAGACQAMADAFAEQAEAFAAAKQAAAFgBAEQgCAEgDADQgDADgGABQgFACgHAAQgGAAgGgCg");
	this.shape_2.setTransform(1361,155);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgFA4IAAhOIALAAIAABOgAgFgpIAAgOIALAAIAAAOg");
	this.shape_3.setTransform(1355.9,153.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgFA4IAAhvIALAAIAABvg");
	this.shape_4.setTransform(1352.4,153.4);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AgRAoIAAg3QAAgLAGgHQAHgGAJAAIANAAIAAALIgMAAQgKAAAAAMIAAA4g");
	this.shape_5.setTransform(1348.6,155);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgLAnQgGgDgFgFQgDgFgCgIQgCgIAAgKQAAgVAHgJQAJgKAOAAQAIAAAGACQAFADAEAFQADAFABAHQACAIAAAJIAAACIguAAIABAPQABAGADADQACADADABIAHABQAIAAAEgDQAEgDABgIIALAAQAAAMgHAGQgGAHgPAAQgHAAgFgCgAgFgcQgDABgCADIgEAGIgCALIAhAAQABgHgCgEQgBgEgCgCQgCgDgDgBIgIAAIgFAAg");
	this.shape_6.setTransform(1342,155);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AgOA3QgGgDgDgFQgEgFgCgIQgBgIAAgLQAAgTAHgKQAIgKAPAAQANAAAFAKIAAgqIANAAIAABwIgMAAIAAgMQgGANgOAAQgIAAgFgCgAgHgLQgEABgCAEQgCADgBAEIgBAOIABAPQABAGACAEQACADAEACQADABAEAAQAFAAADgBQAEgCACgDQACgEABgGIABgPIgBgOQgBgEgCgDQgCgEgEgBIgIgBIgHABg");
	this.shape_7.setTransform(1334,153.4);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AAQAoIAAgwQAAgLgEgEQgDgEgJgBQgGABgEAEQgFADAAAMIAAAwIgMAAIAAhOIALAAIAAAKQAFgLAOgBQANABAGAHQAHAHgBANIAAA0g");
	this.shape_8.setTransform(1326.2,155);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AgVAxQgGgFAAgKQAAgGACgFQADgEAEgDQAEgDAFgCIAMgDIAMgDIAAgEQAAgHgDgFQgDgDgJAAQgGAAgEACQgDAEAAAIIgMAAQABgMAGgHQAGgHAOAAQAHAAAFACQAFACADADQADAEABAFQACAFAAAFIAAA2IgNAAIAAgKQgCAEgFAEQgFADgGABQgMAAgGgHgAAEASIgIACIgGADQAAAAgBABQAAAAgBABQAAAAAAABQgBAAAAABIgBAFQAAANAOAAQAGAAAEgFQAFgFAAgHIAAgMgAAIgoIAAgPIAMAAIAAAPgAgRgoIAAgPIANAAIAAAPg");
	this.shape_9.setTransform(1318.3,153.6);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AgdA4IAAhvIANAAIAABlIAuAAIAAAKg");
	this.shape_10.setTransform(1311.6,153.4);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AgnAFIAAgJIBPAAIAAAJg");
	this.shape_11.setTransform(1302.6,159.8);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AgfA5IAAgKQAAgGACgGQABgFADgEIAHgIIAJgHIAKgIIAHgDQAEgCADgEQADgDACgFQACgEAAgGQAAgKgGgGQgGgEgKAAIgIABQgFABgCADQgDAEgBAEIgCANIgNAAQAAgKACgGQADgIADgFQAEgEAHgDQAHgDAIAAQARAAAJAJQAJAJAAAPQAAAIgCAFQgCAGgEAEIgHAFIgJAGIgLAJIgIAHIgGAFIgEAHIgBAHIAAACIA1AAIAAAKg");
	this.shape_12.setTransform(1293.5,153.3);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("AgQA3QgHgCgFgIQgEgGgCgMQgCgLAAgQQAAgPACgLQABgLAFgHQAEgHAHgDQAIgEAJAAQAKAAAIAEQAHADAEAHQAFAHABALQACALAAAPQAAAQgCALQgCALgEAHQgFAIgHACQgHADgKAAQgJAAgHgDgAgKgrQgFACgDAGQgCAFgBAIQgCAJAAANIABAWQABAKADAFQADAGAEACQAFADAGAAQAHAAAFgDQAEgCADgGQADgFABgKIABgWIgBgWQgCgIgCgFQgDgGgFgCQgEgCgHAAQgGAAgEACg");
	this.shape_13.setTransform(1284.6,153.4);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AgeA5IAAhwIAMAAIAAALQAGgMAMAAQAJAAAGACQAFADAFAFQADAFABAIQACAIAAAKQAAAUgHAKQgHAKgRAAQgMAAgFgKIAAAqgAgHgrQgEABgCAEQgCADgBAGQgCAGABAIIABAPIADAIQACADAEACQAEABADAAQAFAAADgBQAEgCADgDQACgEABgEIAAgPIAAgOQgBgGgCgDQgDgEgEgBIgIgBIgHABg");
	this.shape_14.setTransform(1276.2,156.6);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("AgVAhQgHgHAAgNIAAg0IANAAIAAAwQAAALAEAFQADAFAIAAQAIAAAEgFQAEgFAAgLIAAgwIANAAIAABOIgNAAIAAgKQgCAGgFADQgFADgGAAQgNgBgGgHg");
	this.shape_15.setTransform(1267.9,155.1);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("AgeA5IAAhwIAMAAIAAALQAGgMAMAAQAJAAAGACQAGADAEAFQADAFABAIQACAIAAAKQAAAUgHAKQgHAKgRAAQgMAAgGgKIAAAqgAgHgrQgEABgCAEQgCADgBAGQgBAGgBAIIABAPIAEAIQACADAEACQAEABADAAQAFAAADgBQAEgCADgDQABgEABgEIABgPIgBgOQgBgGgBgDQgDgEgEgBIgIgBIgHABg");
	this.shape_16.setTransform(1260.1,156.6);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AgNAnQgGgDgEgFQgEgFgBgIQgCgIAAgKQAAgJACgIQABgIAEgFQAEgFAGgDQAGgCAHAAQAIAAAGACQAGADAEAFQAEAFACAIQABAIAAAJQAAAVgHAKQgIAKgQAAQgHAAgGgCgAgHgbQgEABgCAEQgCADgBAGIgBANIABAOQABAGACAEQACADAEACQADABAEAAQAFAAADgBQAEgCACgDQACgEABgGIABgOIgBgNQgBgGgCgDQgCgEgEgBIgIgBIgHABg");
	this.shape_17.setTransform(1252,155);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#000000").s().p("AgeA5IAAhwIAMAAIAAALQAGgMANAAQAIAAAGACQAFADAEAFQAEAFACAIQABAIAAAKQAAAUgHAKQgIAKgQAAQgLAAgHgKIAAAqgAgHgrQgEABgCAEQgCADgBAGQgCAGAAAIIABAPIAEAIQACADAEACQADABAEAAQAFAAADgBQAEgCACgDQACgEABgEIABgPIgBgOQgBgGgCgDQgCgEgEgBIgIgBIgHABg");
	this.shape_18.setTransform(1244.2,156.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(10));

	// Ebene 2
	this.closeBtn = new lib.btn_close02();
	this.closeBtn.setTransform(1162,58.2,1,1,0,0,0,12,11.8);
	this.closeBtn._off = true;

	this.timeline.addTween(cjs.Tween.get(this.closeBtn).wait(4).to({_off:false},0).wait(6));

	// scrollerWidget_1
	this.instance = new lib.container_text("single",72);
	this.instance.setTransform(1206,355.3,1,1,0,0,0,585,188.8);

	this.instance_1 = new lib.container_text("single",71);
	this.instance_1.setTransform(925.5,355.3,1,1,0,0,0,585,188.8);

	this.instance_2 = new lib.container_text("single",70);
	this.instance_2.setTransform(645,355.3,1,1,0,0,0,585,188.8);

	this.instance_3 = new lib.container_text("single",73);
	this.instance_3.setTransform(645,762.8,1,1,0,0,0,585,188.8);

	this.instance_4 = new lib.container_text("single",69);
	this.instance_4.setTransform(645,278.8,1,1,0,0,0,585,188.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]},4).wait(6));

	// Ebene 4
	this.instance_5 = new lib.container_pics("single",6);
	this.instance_5.setTransform(590.1,387.5,1,1,0,0,0,556.1,351.5);
	this.instance_5.alpha = 0.5;
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(4).to({_off:false},0).wait(6));

	// scrollerWidget_1
	this.instance_6 = new lib.pic_plane_white();
	this.instance_6.setTransform(609,336,0.993,1.132,0,0,0,579,265);
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(4).to({_off:false},0).wait(6));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(1238,140.7,232,27.4);


(lib.popup01 = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// Ebene 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgeA5IAAhwIAMAAIAAALQAGgMAMAAQAJAAAGACQAGADADAFQAEAFACAIQABAIAAAKQAAAUgHAKQgHAKgRAAQgLAAgHgKIAAAqgAgHgrQgEABgCAEQgCADgBAGQgCAGAAAIIABAPIAEAIQACADAEACQADABAEAAQAFAAADgBQAEgCADgDQABgEABgEIABgPIgBgOQgBgGgBgDQgDgEgEgBIgIgBIgHABg");
	this.shape.setTransform(1331.4,126.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AALAyQgWAAAAgaIAAgqIgLAAIAAgLIALAAIAAgTIALAAIAAATIAXAAIAAALIgXAAIAAAqQAAAIACADQADAEAIAAIAKAAIAAALg");
	this.shape_1.setTransform(1324.5,124.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgFA5IAAhxIALAAIAABxg");
	this.shape_2.setTransform(1320.1,123.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AARAoIgRg4IgQA4IgMAAIgYhPIANAAIASA8IASg8IAIAAIASA8IASg8IAMAAIgYBPg");
	this.shape_3.setTransform(1312.8,125);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgnAFIAAgJIBPAAIAAAJg");
	this.shape_4.setTransform(1302.6,129.8);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AAIA5IAAhiIgdALIAAgMIAggOIALAAIAABxg");
	this.shape_5.setTransform(1293.1,123.4);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgQA4QgHgDgFgHQgEgHgCgMQgCgLAAgQQAAgPACgLQABgLAFgHQAEgHAHgDQAIgDAJgBQAKABAIADQAHADAEAHQAFAHABALQACALAAAPQAAAQgCALQgCALgEAIQgFAHgHADQgHACgKAAQgJAAgHgCgAgKgrQgFACgDAFQgCAFgBAJQgCAJAAANIABAWQABAKADAGQADAFAEADQAFACAGAAQAHAAAFgCQAEgDADgFQADgGABgKIABgWIgBgWQgCgJgCgFQgDgFgFgCQgEgCgHAAQgGAAgEACg");
	this.shape_6.setTransform(1284.6,123.4);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AgeA5IAAhwIAMAAIAAALQAGgMAMAAQAJAAAGACQAFADAFAFQADAFABAIQACAIAAAKQAAAUgHAKQgHAKgRAAQgMAAgFgKIAAAqgAgHgrQgEABgCAEQgCADgBAGQgCAGABAIIABAPIADAIQACADAEACQAEABADAAQAFAAADgBQAEgCADgDQACgEABgEIAAgPIAAgOQgBgGgCgDQgDgEgEgBIgIgBIgHABg");
	this.shape_7.setTransform(1276.2,126.6);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AgVAhQgHgHAAgOIAAg0IANAAIAAAxQAAALAEAFQADAFAIgBQAIABAEgFQAEgFAAgLIAAgxIANAAIAABPIgNAAIAAgKQgCAFgFADQgFADgGABQgNAAgGgIg");
	this.shape_8.setTransform(1267.9,125.1);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AgeA5IAAhwIAMAAIAAALQAGgMAMAAQAJAAAGACQAGADAEAFQADAFABAIQACAIAAAKQAAAUgHAKQgHAKgRAAQgMAAgGgKIAAAqgAgHgrQgEABgCAEQgCADgBAGQgBAGgBAIIABAPIAEAIQACADAEACQAEABADAAQAFAAADgBQAEgCADgDQABgEABgEIABgPIgBgOQgBgGgBgDQgDgEgEgBIgIgBIgHABg");
	this.shape_9.setTransform(1260.1,126.6);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AgNAnQgGgDgEgFQgEgFgBgIQgCgIAAgKQAAgJACgIQABgIAEgFQAEgFAGgDQAGgCAHAAQAIAAAGACQAGADAEAFQAEAFACAIQABAIAAAJQAAAVgHAKQgIAKgQAAQgHAAgGgCgAgHgbQgEABgCAEQgCADgBAGIgBANIABAOQABAGACAEQACADAEACQADABAEAAQAFAAADgBQAEgCACgDQACgEABgGIABgOIgBgNQgBgGgCgDQgCgEgEgBIgIgBIgHABg");
	this.shape_10.setTransform(1252,125);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AgeA5IAAhwIAMAAIAAALQAGgMANAAQAIAAAGACQAFADAEAFQAEAFACAIQABAIAAAKQAAAUgHAKQgIAKgQAAQgLAAgHgKIAAAqgAgHgrQgEABgCAEQgCADgBAGQgCAGAAAIIABAPIAEAIQACADAEACQADABAEAAQAFAAADgBQAEgCACgDQACgEABgEIABgPIgBgOQgBgGgCgDQgCgEgEgBIgIgBIgHABg");
	this.shape_11.setTransform(1244.2,126.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(10));

	// Ebene 2
	this.instance = new lib.container_text("single",52);
	this.instance.setTransform(1187,359,1,1,0,0,0,585,188.8);

	this.instance_1 = new lib.container_text("single",51);
	this.instance_1.setTransform(736,359,1,1,0,0,0,585,188.8);

	this.linkWidget2 = new lib.btn_ppe_link02();
	this.linkWidget2.setTransform(1390.3,721,1,1,0,0,0,358.8,235.5);

	this.instance_2 = new lib.container_text("single",60);
	this.instance_2.setTransform(645,635.3,1,1,0,0,0,585,188.8);

	this.instance_3 = new lib.container_text("single",59);
	this.instance_3.setTransform(645,278.8,1,1,0,0,0,585,188.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_3},{t:this.instance_2},{t:this.linkWidget2},{t:this.instance_1},{t:this.instance}]},4).wait(6));

	// Ebene 5
	this.closeBtn = new lib.btn_close02();
	this.closeBtn.setTransform(1162,58.2,1,1,0,0,0,12,11.8);
	this.closeBtn._off = true;

	this.timeline.addTween(cjs.Tween.get(this.closeBtn).wait(4).to({_off:false},0).wait(6));

	// scrollerWidget_1
	this.instance_4 = new lib.pics_table02("single",1);
	this.instance_4.setTransform(851.8,270.6,0.881,0.881,0,0,0,386.6,136.7);

	this.instance_5 = new lib.pics_table02("single",0);
	this.instance_5.setTransform(400.8,270.6,0.881,0.881,0,0,0,386.6,136.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_5},{t:this.instance_4}]},4).wait(6));

	// Ebene 1
	this.instance_6 = new lib.pic_plane_white();
	this.instance_6.setTransform(609,336,0.993,1.132,0,0,0,579,265);
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(4).to({_off:false},0).wait(6));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(1238,110.7,232,27.4);


(lib.ani_particles = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.loop = true;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(71));

	// ani_particle03
	this.instance = new lib.ani_particle03("synched",7);
	this.instance.setTransform(130.9,47.3);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(71));

	// ani_particle04
	this.instance_1 = new lib.ani_particle04("synched",16);
	this.instance_1.setTransform(50.3,105.7,1,1,0,180,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(71));

	// ani_particle02
	this.instance_2 = new lib.ani_particle02("synched",30);
	this.instance_2.setTransform(124.9,103.2,1,1,0,180,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(71));

	// ani_particle03
	this.instance_3 = new lib.ani_particle03("synched",29);
	this.instance_3.setTransform(32.3,55.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(71));

	// ani_particle04
	this.instance_4 = new lib.ani_particle04("synched",42);
	this.instance_4.setTransform(77.3,83.7,1,1,0,180,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(71));

	// ani_particle03
	this.instance_5 = new lib.ani_particle03("synched",56);
	this.instance_5.setTransform(137.9,80.9,1,1,0,180,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(71));

	// ani_particle02
	this.instance_6 = new lib.ani_particle02("synched",52);
	this.instance_6.setTransform(95.9,121.2,1,1,0,180,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(71));

	// ani_particle01
	this.instance_7 = new lib.ani_particle01("synched",43);
	this.instance_7.setTransform(80.3,138.3,1,1,0,180,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(71));

	// ani_particle03
	this.instance_8 = new lib.ani_particle03("synched",54);
	this.instance_8.setTransform(110.9,95.4,1,1,0,180,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(71));

	// ani_particle04
	this.instance_9 = new lib.ani_particle04("synched",0);
	this.instance_9.setTransform(30.3,36.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(71));

	// ani_particle02
	this.instance_10 = new lib.ani_particle02("synched",64);
	this.instance_10.setTransform(104.9,39.4);

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(71));

	// ani_particle03
	this.instance_11 = new lib.ani_particle03("synched",0);
	this.instance_11.setTransform(57.3,73.8,1,1,0,180,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(71));

	// ani_particle04
	this.instance_12 = new lib.ani_particle04("synched",7);
	this.instance_12.setTransform(57.3,58.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(71));

	// ani_particle03
	this.instance_13 = new lib.ani_particle03("synched",17);
	this.instance_13.setTransform(81.9,44.7);

	this.timeline.addTween(cjs.Tween.get(this.instance_13).wait(71));

	// ani_particle02
	this.instance_14 = new lib.ani_particle02("synched",16);
	this.instance_14.setTransform(75.9,21.4);

	this.timeline.addTween(cjs.Tween.get(this.instance_14).wait(71));

	// ani_particle01
	this.instance_15 = new lib.ani_particle01("synched",28);
	this.instance_15.setTransform(60.3,4.3);

	this.timeline.addTween(cjs.Tween.get(this.instance_15).wait(71));

	// ani_particle03
	this.instance_16 = new lib.ani_particle03("synched",7);
	this.instance_16.setTransform(73.9,37.3);

	this.timeline.addTween(cjs.Tween.get(this.instance_16).wait(71));

	// ani_particle04
	this.instance_17 = new lib.ani_particle04("synched",16);
	this.instance_17.setTransform(-6.7,95.7,1,1,0,180,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_17).wait(71));

	// ani_particle02
	this.instance_18 = new lib.ani_particle02("synched",30);
	this.instance_18.setTransform(67.9,93.2,1,1,0,180,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_18).wait(71));

	// ani_particle03
	this.instance_19 = new lib.ani_particle03("synched",29);
	this.instance_19.setTransform(-24.7,45.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_19).wait(71));

	// ani_particle04
	this.instance_20 = new lib.ani_particle04("synched",42);
	this.instance_20.setTransform(20.3,73.7,1,1,0,180,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_20).wait(71));

	// ani_particle03
	this.instance_21 = new lib.ani_particle03("synched",56);
	this.instance_21.setTransform(80.9,70.9,1,1,0,180,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_21).wait(71));

	// ani_particle02
	this.instance_22 = new lib.ani_particle02("synched",52);
	this.instance_22.setTransform(38.9,111.2,1,1,0,180,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_22).wait(71));

	// ani_particle01
	this.instance_23 = new lib.ani_particle01("synched",43);
	this.instance_23.setTransform(23.3,128.3,1,1,0,180,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_23).wait(71));

	// ani_particle03
	this.instance_24 = new lib.ani_particle03("synched",54);
	this.instance_24.setTransform(53.9,85.4,1,1,0,180,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_24).wait(71));

	// ani_particle04
	this.instance_25 = new lib.ani_particle04("synched",0);
	this.instance_25.setTransform(-26.7,26.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_25).wait(71));

	// ani_particle02
	this.instance_26 = new lib.ani_particle02("synched",64);
	this.instance_26.setTransform(47.9,29.4);

	this.timeline.addTween(cjs.Tween.get(this.instance_26).wait(71));

	// ani_particle03
	this.instance_27 = new lib.ani_particle03("synched",0);
	this.instance_27.setTransform(0.3,63.8,1,1,0,180,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_27).wait(71));

	// ani_particle04
	this.instance_28 = new lib.ani_particle04("synched",7);
	this.instance_28.setTransform(0.3,48.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_28).wait(71));

	// ani_particle03
	this.instance_29 = new lib.ani_particle03("synched",17);
	this.instance_29.setTransform(24.9,34.7);

	this.timeline.addTween(cjs.Tween.get(this.instance_29).wait(71));

	// ani_particle02
	this.instance_30 = new lib.ani_particle02("synched",16);
	this.instance_30.setTransform(18.9,11.4);

	this.timeline.addTween(cjs.Tween.get(this.instance_30).wait(71));

	// ani_particle01
	this.instance_31 = new lib.ani_particle01("synched",28);
	this.instance_31.setTransform(3.3,-5.7);

	this.timeline.addTween(cjs.Tween.get(this.instance_31).wait(71));

	// ani_particle03
	this.instance_32 = new lib.ani_particle03("synched",7);
	this.instance_32.setTransform(150.9,37.3);

	this.timeline.addTween(cjs.Tween.get(this.instance_32).wait(71));

	// ani_particle04
	this.instance_33 = new lib.ani_particle04("synched",16);
	this.instance_33.setTransform(70.3,95.7,1,1,0,180,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_33).wait(71));

	// ani_particle02
	this.instance_34 = new lib.ani_particle02("synched",30);
	this.instance_34.setTransform(144.9,93.2,1,1,0,180,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_34).wait(71));

	// ani_particle03
	this.instance_35 = new lib.ani_particle03("synched",29);
	this.instance_35.setTransform(52.3,45.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_35).wait(71));

	// ani_particle04
	this.instance_36 = new lib.ani_particle04("synched",42);
	this.instance_36.setTransform(97.3,73.7,1,1,0,180,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_36).wait(71));

	// ani_particle03
	this.instance_37 = new lib.ani_particle03("synched",56);
	this.instance_37.setTransform(157.9,70.9,1,1,0,180,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_37).wait(71));

	// ani_particle02
	this.instance_38 = new lib.ani_particle02("synched",52);
	this.instance_38.setTransform(115.9,111.2,1,1,0,180,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_38).wait(71));

	// ani_particle01
	this.instance_39 = new lib.ani_particle01("synched",43);
	this.instance_39.setTransform(100.3,128.3,1,1,0,180,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_39).wait(71));

	// ani_particle03
	this.instance_40 = new lib.ani_particle03("synched",54);
	this.instance_40.setTransform(130.9,85.4,1,1,0,180,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_40).wait(71));

	// ani_particle04
	this.instance_41 = new lib.ani_particle04("synched",0);
	this.instance_41.setTransform(50.3,26.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_41).wait(71));

	// ani_particle02
	this.instance_42 = new lib.ani_particle02("synched",64);
	this.instance_42.setTransform(124.9,29.4);

	this.timeline.addTween(cjs.Tween.get(this.instance_42).wait(71));

	// ani_particle03
	this.instance_43 = new lib.ani_particle03("synched",0);
	this.instance_43.setTransform(77.3,63.8,1,1,0,180,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_43).wait(71));

	// ani_particle04
	this.instance_44 = new lib.ani_particle04("synched",7);
	this.instance_44.setTransform(77.3,48.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_44).wait(71));

	// ani_particle03
	this.instance_45 = new lib.ani_particle03("synched",17);
	this.instance_45.setTransform(101.9,34.7);

	this.timeline.addTween(cjs.Tween.get(this.instance_45).wait(71));

	// ani_particle02
	this.instance_46 = new lib.ani_particle02("synched",16);
	this.instance_46.setTransform(95.9,11.4);

	this.timeline.addTween(cjs.Tween.get(this.instance_46).wait(71));

	// ani_particle01
	this.instance_47 = new lib.ani_particle01("synched",28);
	this.instance_47.setTransform(80.3,-5.7);

	this.timeline.addTween(cjs.Tween.get(this.instance_47).wait(71));

	// ani_particle03
	this.instance_48 = new lib.ani_particle03("synched",7);
	this.instance_48.setTransform(70.9,81.5,1,1,0,180,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_48).wait(71));

	// ani_particle04
	this.instance_49 = new lib.ani_particle04("synched",16);
	this.instance_49.setTransform(-9.7,23);

	this.timeline.addTween(cjs.Tween.get(this.instance_49).wait(71));

	// ani_particle02
	this.instance_50 = new lib.ani_particle02("synched",30);
	this.instance_50.setTransform(64.9,25.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_50).wait(71));

	// ani_particle03
	this.instance_51 = new lib.ani_particle03("synched",29);
	this.instance_51.setTransform(-27.7,73.2,1,1,0,180,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_51).wait(71));

	// ani_particle04
	this.instance_52 = new lib.ani_particle04("synched",42);
	this.instance_52.setTransform(17.3,45);

	this.timeline.addTween(cjs.Tween.get(this.instance_52).wait(71));

	// ani_particle03
	this.instance_53 = new lib.ani_particle03("synched",56);
	this.instance_53.setTransform(77.9,47.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_53).wait(71));

	// ani_particle02
	this.instance_54 = new lib.ani_particle02("synched",52);
	this.instance_54.setTransform(35.9,7.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_54).wait(71));

	// ani_particle01
	this.instance_55 = new lib.ani_particle01("synched",43);
	this.instance_55.setTransform(20.3,-9.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_55).wait(71));

	// ani_particle03
	this.instance_56 = new lib.ani_particle03("synched",54);
	this.instance_56.setTransform(50.9,33.4);

	this.timeline.addTween(cjs.Tween.get(this.instance_56).wait(71));

	// ani_particle04
	this.instance_57 = new lib.ani_particle04("synched",0);
	this.instance_57.setTransform(-29.7,91.8,1,1,0,180,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_57).wait(71));

	// ani_particle02
	this.instance_58 = new lib.ani_particle02("synched",64);
	this.instance_58.setTransform(44.9,89.3,1,1,0,180,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_58).wait(71));

	// ani_particle03
	this.instance_59 = new lib.ani_particle03("synched",0);
	this.instance_59.setTransform(-2.7,55);

	this.timeline.addTween(cjs.Tween.get(this.instance_59).wait(71));

	// ani_particle04
	this.instance_60 = new lib.ani_particle04("synched",7);
	this.instance_60.setTransform(-2.7,69.8,1,1,0,180,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_60).wait(71));

	// ani_particle03
	this.instance_61 = new lib.ani_particle03("synched",17);
	this.instance_61.setTransform(21.9,84,1,1,0,180,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_61).wait(71));

	// ani_particle02
	this.instance_62 = new lib.ani_particle02("synched",16);
	this.instance_62.setTransform(15.9,107.3,1,1,0,180,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_62).wait(71));

	// ani_particle01
	this.instance_63 = new lib.ani_particle01("synched",28);
	this.instance_63.setTransform(0.3,124.4,1,1,0,180,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_63).wait(71));

	// ani_particle03
	this.instance_64 = new lib.ani_particle03("synched",7);
	this.instance_64.setTransform(120.9,81.5,1,1,0,180,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_64).wait(71));

	// ani_particle04
	this.instance_65 = new lib.ani_particle04("synched",16);
	this.instance_65.setTransform(40.3,23);

	this.timeline.addTween(cjs.Tween.get(this.instance_65).wait(71));

	// ani_particle02
	this.instance_66 = new lib.ani_particle02("synched",30);
	this.instance_66.setTransform(114.9,25.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_66).wait(71));

	// ani_particle03
	this.instance_67 = new lib.ani_particle03("synched",29);
	this.instance_67.setTransform(22.3,73.2,1,1,0,180,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_67).wait(71));

	// ani_particle04
	this.instance_68 = new lib.ani_particle04("synched",42);
	this.instance_68.setTransform(67.3,45);

	this.timeline.addTween(cjs.Tween.get(this.instance_68).wait(71));

	// ani_particle03
	this.instance_69 = new lib.ani_particle03("synched",56);
	this.instance_69.setTransform(127.9,47.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_69).wait(71));

	// ani_particle02
	this.instance_70 = new lib.ani_particle02("synched",52);
	this.instance_70.setTransform(85.9,7.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_70).wait(71));

	// ani_particle01
	this.instance_71 = new lib.ani_particle01("synched",43);
	this.instance_71.setTransform(70.3,-9.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_71).wait(71));

	// ani_particle03
	this.instance_72 = new lib.ani_particle03("synched",54);
	this.instance_72.setTransform(100.9,33.4);

	this.timeline.addTween(cjs.Tween.get(this.instance_72).wait(71));

	// ani_particle04
	this.instance_73 = new lib.ani_particle04("synched",0);
	this.instance_73.setTransform(20.3,91.8,1,1,0,180,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_73).wait(71));

	// ani_particle02
	this.instance_74 = new lib.ani_particle02("synched",64);
	this.instance_74.setTransform(94.9,89.3,1,1,0,180,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_74).wait(71));

	// ani_particle03
	this.instance_75 = new lib.ani_particle03("synched",0);
	this.instance_75.setTransform(47.3,55);

	this.timeline.addTween(cjs.Tween.get(this.instance_75).wait(71));

	// ani_particle04
	this.instance_76 = new lib.ani_particle04("synched",7);
	this.instance_76.setTransform(47.3,69.8,1,1,0,180,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_76).wait(71));

	// ani_particle03
	this.instance_77 = new lib.ani_particle03("synched",17);
	this.instance_77.setTransform(71.9,84,1,1,0,180,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_77).wait(71));

	// ani_particle02
	this.instance_78 = new lib.ani_particle02("synched",16);
	this.instance_78.setTransform(65.9,107.3,1,1,0,180,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_78).wait(71));

	// ani_particle01
	this.instance_79 = new lib.ani_particle01("synched",28);
	this.instance_79.setTransform(50.3,124.4,1,1,0,180,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_79).wait(71));

	// ani_particle03
	this.instance_80 = new lib.ani_particle03("synched",7);
	this.instance_80.setTransform(40.9,37.3);

	this.timeline.addTween(cjs.Tween.get(this.instance_80).wait(71));

	// ani_particle04
	this.instance_81 = new lib.ani_particle04("synched",16);
	this.instance_81.setTransform(-39.7,95.7,1,1,0,180,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_81).wait(71));

	// ani_particle02
	this.instance_82 = new lib.ani_particle02("synched",30);
	this.instance_82.setTransform(34.9,93.2,1,1,0,180,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_82).wait(71));

	// ani_particle03
	this.instance_83 = new lib.ani_particle03("synched",29);
	this.instance_83.setTransform(-57.7,45.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_83).wait(71));

	// ani_particle04
	this.instance_84 = new lib.ani_particle04("synched",42);
	this.instance_84.setTransform(-12.7,73.7,1,1,0,180,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_84).wait(71));

	// ani_particle03
	this.instance_85 = new lib.ani_particle03("synched",56);
	this.instance_85.setTransform(47.9,70.9,1,1,0,180,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_85).wait(71));

	// ani_particle02
	this.instance_86 = new lib.ani_particle02("synched",52);
	this.instance_86.setTransform(5.9,111.2,1,1,0,180,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_86).wait(71));

	// ani_particle01
	this.instance_87 = new lib.ani_particle01("synched",43);
	this.instance_87.setTransform(-9.7,128.3,1,1,0,180,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_87).wait(71));

	// ani_particle03
	this.instance_88 = new lib.ani_particle03("synched",54);
	this.instance_88.setTransform(20.9,85.4,1,1,0,180,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_88).wait(71));

	// ani_particle04
	this.instance_89 = new lib.ani_particle04("synched",0);
	this.instance_89.setTransform(-59.7,26.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_89).wait(71));

	// ani_particle02
	this.instance_90 = new lib.ani_particle02("synched",64);
	this.instance_90.setTransform(14.9,29.4);

	this.timeline.addTween(cjs.Tween.get(this.instance_90).wait(71));

	// ani_particle03
	this.instance_91 = new lib.ani_particle03("synched",0);
	this.instance_91.setTransform(-32.7,63.8,1,1,0,180,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_91).wait(71));

	// ani_particle04
	this.instance_92 = new lib.ani_particle04("synched",7);
	this.instance_92.setTransform(-32.7,48.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_92).wait(71));

	// ani_particle03
	this.instance_93 = new lib.ani_particle03("synched",17);
	this.instance_93.setTransform(-8.1,34.7);

	this.timeline.addTween(cjs.Tween.get(this.instance_93).wait(71));

	// ani_particle02
	this.instance_94 = new lib.ani_particle02("synched",16);
	this.instance_94.setTransform(-14.1,11.4);

	this.timeline.addTween(cjs.Tween.get(this.instance_94).wait(71));

	// ani_particle01
	this.instance_95 = new lib.ani_particle01("synched",28);
	this.instance_95.setTransform(-29.7,-5.7);

	this.timeline.addTween(cjs.Tween.get(this.instance_95).wait(71));

	// ani_particle03
	this.instance_96 = new lib.ani_particle03("synched",41);
	this.instance_96.setTransform(150.9,47.3);

	this.timeline.addTween(cjs.Tween.get(this.instance_96).wait(71));

	// ani_particle04
	this.instance_97 = new lib.ani_particle04("synched",32);
	this.instance_97.setTransform(70.3,105.7,1,1,0,180,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_97).wait(71));

	// ani_particle02
	this.instance_98 = new lib.ani_particle02("synched",28);
	this.instance_98.setTransform(144.9,103.2,1,1,0,180,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_98).wait(71));

	// ani_particle03
	this.instance_99 = new lib.ani_particle03("synched",9);
	this.instance_99.setTransform(52.3,55.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_99).wait(71));

	// ani_particle04
	this.instance_100 = new lib.ani_particle04("synched",4);
	this.instance_100.setTransform(97.3,83.7,1,1,0,180,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_100).wait(71));

	// ani_particle03
	this.instance_101 = new lib.ani_particle03("synched",0);
	this.instance_101.setTransform(157.9,80.9,1,1,0,180,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_101).wait(71));

	// ani_particle02
	this.instance_102 = new lib.ani_particle02("synched",48);
	this.instance_102.setTransform(115.9,121.2,1,1,0,180,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_102).wait(71));

	// ani_particle01
	this.instance_103 = new lib.ani_particle01("synched",21);
	this.instance_103.setTransform(100.3,138.3,1,1,0,180,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_103).wait(71));

	// ani_particle03
	this.instance_104 = new lib.ani_particle03("synched",14);
	this.instance_104.setTransform(130.9,95.4,1,1,0,180,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_104).wait(71));

	// ani_particle04
	this.instance_105 = new lib.ani_particle04("synched",12);
	this.instance_105.setTransform(50.3,36.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_105).wait(71));

	// ani_particle02
	this.instance_106 = new lib.ani_particle02("synched",58);
	this.instance_106.setTransform(124.9,39.4);

	this.timeline.addTween(cjs.Tween.get(this.instance_106).wait(71));

	// ani_particle03
	this.instance_107 = new lib.ani_particle03("synched",46);
	this.instance_107.setTransform(77.3,73.8,1,1,0,180,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_107).wait(71));

	// ani_particle04
	this.instance_108 = new lib.ani_particle04("synched",35);
	this.instance_108.setTransform(77.3,58.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_108).wait(71));

	// ani_particle03
	this.instance_109 = new lib.ani_particle03("synched",27);
	this.instance_109.setTransform(101.9,44.7);

	this.timeline.addTween(cjs.Tween.get(this.instance_109).wait(71));

	// ani_particle02
	this.instance_110 = new lib.ani_particle02("synched",8);
	this.instance_110.setTransform(95.9,21.4);

	this.timeline.addTween(cjs.Tween.get(this.instance_110).wait(71));

	// ani_particle01
	this.instance_111 = new lib.ani_particle01("synched",2);
	this.instance_111.setTransform(80.3,4.3);

	this.timeline.addTween(cjs.Tween.get(this.instance_111).wait(71));

	// ani_particle03
	this.instance_112 = new lib.ani_particle03("synched",29);
	this.instance_112.setTransform(93.9,37.3);

	this.timeline.addTween(cjs.Tween.get(this.instance_112).wait(71));

	// ani_particle04
	this.instance_113 = new lib.ani_particle04("synched",49);
	this.instance_113.setTransform(13.3,95.7,1,1,0,180,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_113).wait(71));

	// ani_particle02
	this.instance_114 = new lib.ani_particle02("synched",4);
	this.instance_114.setTransform(87.9,93.2,1,1,0,180,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_114).wait(71));

	// ani_particle03
	this.instance_115 = new lib.ani_particle03("synched",14);
	this.instance_115.setTransform(-4.7,45.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_115).wait(71));

	// ani_particle04
	this.instance_116 = new lib.ani_particle04("synched",38);
	this.instance_116.setTransform(40.3,73.7,1,1,0,180,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_116).wait(71));

	// ani_particle03
	this.instance_117 = new lib.ani_particle03("synched",63);
	this.instance_117.setTransform(100.9,70.9,1,1,0,180,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_117).wait(71));

	// ani_particle02
	this.instance_118 = new lib.ani_particle02("synched",0);
	this.instance_118.setTransform(58.9,111.2,1,1,0,180,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_118).wait(71));

	// ani_particle01
	this.instance_119 = new lib.ani_particle01("synched",2);
	this.instance_119.setTransform(43.3,128.3,1,1,0,180,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_119).wait(71));

	// ani_particle03
	this.instance_120 = new lib.ani_particle03("synched",24);
	this.instance_120.setTransform(73.9,85.4,1,1,0,180,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_120).wait(71));

	// ani_particle04
	this.instance_121 = new lib.ani_particle04("synched",51);
	this.instance_121.setTransform(-6.7,26.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_121).wait(71));

	// ani_particle02
	this.instance_122 = new lib.ani_particle02("synched",56);
	this.instance_122.setTransform(67.9,29.4);

	this.timeline.addTween(cjs.Tween.get(this.instance_122).wait(71));

	// ani_particle03
	this.instance_123 = new lib.ani_particle03("synched",3);
	this.instance_123.setTransform(20.3,63.8,1,1,0,180,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_123).wait(71));

	// ani_particle04
	this.instance_124 = new lib.ani_particle04("synched",21);
	this.instance_124.setTransform(20.3,48.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_124).wait(71));

	// ani_particle03
	this.instance_125 = new lib.ani_particle03("synched",42);
	this.instance_125.setTransform(44.9,34.7);

	this.timeline.addTween(cjs.Tween.get(this.instance_125).wait(71));

	// ani_particle02
	this.instance_126 = new lib.ani_particle02("synched",52);
	this.instance_126.setTransform(38.9,11.4);

	this.timeline.addTween(cjs.Tween.get(this.instance_126).wait(71));

	// ani_particle01
	this.instance_127 = new lib.ani_particle01("synched",5);
	this.instance_127.setTransform(23.3,-5.7);

	this.timeline.addTween(cjs.Tween.get(this.instance_127).wait(71));

	// ani_particle03
	this.instance_128 = new lib.ani_particle03("synched",41);
	this.instance_128.setTransform(170.9,37.3);

	this.timeline.addTween(cjs.Tween.get(this.instance_128).wait(71));

	// ani_particle04
	this.instance_129 = new lib.ani_particle04("synched",67);
	this.instance_129.setTransform(90.3,95.7,1,1,0,180,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_129).wait(71));

	// ani_particle02
	this.instance_130 = new lib.ani_particle02("synched",28);
	this.instance_130.setTransform(164.9,93.2,1,1,0,180,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_130).wait(71));

	// ani_particle03
	this.instance_131 = new lib.ani_particle03("synched",44);
	this.instance_131.setTransform(72.3,45.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_131).wait(71));

	// ani_particle04
	this.instance_132 = new lib.ani_particle04("synched",4);
	this.instance_132.setTransform(117.3,73.7,1,1,0,180,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_132).wait(71));

	// ani_particle03
	this.instance_133 = new lib.ani_particle03("synched",35);
	this.instance_133.setTransform(177.9,70.9,1,1,0,180,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_133).wait(71));

	// ani_particle02
	this.instance_134 = new lib.ani_particle02("synched",48);
	this.instance_134.setTransform(135.9,111.2,1,1,0,180,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_134).wait(71));

	// ani_particle01
	this.instance_135 = new lib.ani_particle01("synched",56);
	this.instance_135.setTransform(120.3,128.3,1,1,0,180,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_135).wait(71));

	// ani_particle03
	this.instance_136 = new lib.ani_particle03("synched",14);
	this.instance_136.setTransform(150.9,85.4,1,1,0,180,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_136).wait(71));

	// ani_particle04
	this.instance_137 = new lib.ani_particle04("synched",47);
	this.instance_137.setTransform(70.3,26.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_137).wait(71));

	// ani_particle02
	this.instance_138 = new lib.ani_particle02("synched",58);
	this.instance_138.setTransform(144.9,29.4);

	this.timeline.addTween(cjs.Tween.get(this.instance_138).wait(71));

	// ani_particle03
	this.instance_139 = new lib.ani_particle03("synched",11);
	this.instance_139.setTransform(97.3,63.8,1,1,0,180,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_139).wait(71));

	// ani_particle04
	this.instance_140 = new lib.ani_particle04("synched",35);
	this.instance_140.setTransform(97.3,48.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_140).wait(71));

	// ani_particle03
	this.instance_141 = new lib.ani_particle03("synched",62);
	this.instance_141.setTransform(121.9,34.7);

	this.timeline.addTween(cjs.Tween.get(this.instance_141).wait(71));

	// ani_particle02
	this.instance_142 = new lib.ani_particle02("synched",8);
	this.instance_142.setTransform(115.9,11.4);

	this.timeline.addTween(cjs.Tween.get(this.instance_142).wait(71));

	// ani_particle01
	this.instance_143 = new lib.ani_particle01("synched",37);
	this.instance_143.setTransform(100.3,-5.7);

	this.timeline.addTween(cjs.Tween.get(this.instance_143).wait(71));

	// ani_particle03
	this.instance_144 = new lib.ani_particle03("synched",41);
	this.instance_144.setTransform(90.9,81.5,1,1,0,180,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_144).wait(71));

	// ani_particle04
	this.instance_145 = new lib.ani_particle04("synched",67);
	this.instance_145.setTransform(10.3,23);

	this.timeline.addTween(cjs.Tween.get(this.instance_145).wait(71));

	// ani_particle02
	this.instance_146 = new lib.ani_particle02("synched",28);
	this.instance_146.setTransform(84.9,25.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_146).wait(71));

	// ani_particle03
	this.instance_147 = new lib.ani_particle03("synched",44);
	this.instance_147.setTransform(-7.7,73.2,1,1,0,180,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_147).wait(71));

	// ani_particle04
	this.instance_148 = new lib.ani_particle04("synched",4);
	this.instance_148.setTransform(37.3,45);

	this.timeline.addTween(cjs.Tween.get(this.instance_148).wait(71));

	// ani_particle03
	this.instance_149 = new lib.ani_particle03("synched",35);
	this.instance_149.setTransform(97.9,47.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_149).wait(71));

	// ani_particle02
	this.instance_150 = new lib.ani_particle02("synched",48);
	this.instance_150.setTransform(55.9,7.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_150).wait(71));

	// ani_particle01
	this.instance_151 = new lib.ani_particle01("synched",56);
	this.instance_151.setTransform(40.3,-9.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_151).wait(71));

	// ani_particle03
	this.instance_152 = new lib.ani_particle03("synched",14);
	this.instance_152.setTransform(70.9,33.4);

	this.timeline.addTween(cjs.Tween.get(this.instance_152).wait(71));

	// ani_particle04
	this.instance_153 = new lib.ani_particle04("synched",47);
	this.instance_153.setTransform(-9.7,91.8,1,1,0,180,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_153).wait(71));

	// ani_particle02
	this.instance_154 = new lib.ani_particle02("synched",58);
	this.instance_154.setTransform(64.9,89.3,1,1,0,180,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_154).wait(71));

	// ani_particle03
	this.instance_155 = new lib.ani_particle03("synched",11);
	this.instance_155.setTransform(17.3,55);

	this.timeline.addTween(cjs.Tween.get(this.instance_155).wait(71));

	// ani_particle04
	this.instance_156 = new lib.ani_particle04("synched",35);
	this.instance_156.setTransform(17.3,69.8,1,1,0,180,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_156).wait(71));

	// ani_particle03
	this.instance_157 = new lib.ani_particle03("synched",62);
	this.instance_157.setTransform(41.9,84,1,1,0,180,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_157).wait(71));

	// ani_particle02
	this.instance_158 = new lib.ani_particle02("synched",8);
	this.instance_158.setTransform(35.9,107.3,1,1,0,180,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_158).wait(71));

	// ani_particle01
	this.instance_159 = new lib.ani_particle01("synched",37);
	this.instance_159.setTransform(20.3,124.4,1,1,0,180,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_159).wait(71));

	// ani_particle03
	this.instance_160 = new lib.ani_particle03("synched",3);
	this.instance_160.setTransform(140.9,81.5,1,1,0,180,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_160).wait(71));

	// ani_particle04
	this.instance_161 = new lib.ani_particle04("synched",10);
	this.instance_161.setTransform(60.3,23);

	this.timeline.addTween(cjs.Tween.get(this.instance_161).wait(71));

	// ani_particle02
	this.instance_162 = new lib.ani_particle02("synched",22);
	this.instance_162.setTransform(134.9,25.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_162).wait(71));

	// ani_particle03
	this.instance_163 = new lib.ani_particle03("synched",19);
	this.instance_163.setTransform(42.3,73.2,1,1,0,180,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_163).wait(71));

	// ani_particle04
	this.instance_164 = new lib.ani_particle04("synched",30);
	this.instance_164.setTransform(87.3,45);

	this.timeline.addTween(cjs.Tween.get(this.instance_164).wait(71));

	// ani_particle03
	this.instance_165 = new lib.ani_particle03("synched",42);
	this.instance_165.setTransform(147.9,47.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_165).wait(71));

	// ani_particle02
	this.instance_166 = new lib.ani_particle02("synched",36);
	this.instance_166.setTransform(105.9,7.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_166).wait(71));

	// ani_particle01
	this.instance_167 = new lib.ani_particle01("synched",25);
	this.instance_167.setTransform(90.3,-9.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_167).wait(71));

	// ani_particle03
	this.instance_168 = new lib.ani_particle03("synched",34);
	this.instance_168.setTransform(120.9,33.4);

	this.timeline.addTween(cjs.Tween.get(this.instance_168).wait(71));

	// ani_particle04
	this.instance_169 = new lib.ani_particle04("synched",48);
	this.instance_169.setTransform(40.3,91.8,1,1,0,180,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_169).wait(71));

	// ani_particle02
	this.instance_170 = new lib.ani_particle02("synched",40);
	this.instance_170.setTransform(114.9,89.3,1,1,0,180,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_170).wait(71));

	// ani_particle03
	this.instance_171 = new lib.ani_particle03("synched",44);
	this.instance_171.setTransform(67.3,55);

	this.timeline.addTween(cjs.Tween.get(this.instance_171).wait(71));

	// ani_particle04
	this.instance_172 = new lib.ani_particle04("synched",49);
	this.instance_172.setTransform(67.3,69.8,1,1,0,180,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_172).wait(71));

	// ani_particle03
	this.instance_173 = new lib.ani_particle03("synched",57);
	this.instance_173.setTransform(91.9,84,1,1,0,180,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_173).wait(71));

	// ani_particle02
	this.instance_174 = new lib.ani_particle02("synched",54);
	this.instance_174.setTransform(85.9,107.3,1,1,0,180,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_174).wait(71));

	// ani_particle01
	this.instance_175 = new lib.ani_particle01("synched",64);
	this.instance_175.setTransform(70.3,124.4,1,1,0,180,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_175).wait(71));

	// ani_particle03
	this.instance_176 = new lib.ani_particle03("synched",3);
	this.instance_176.setTransform(60.9,37.3);

	this.timeline.addTween(cjs.Tween.get(this.instance_176).wait(71));

	// ani_particle04
	this.instance_177 = new lib.ani_particle04("synched",10);
	this.instance_177.setTransform(-19.7,95.7,1,1,0,180,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_177).wait(71));

	// ani_particle02
	this.instance_178 = new lib.ani_particle02("synched",22);
	this.instance_178.setTransform(54.9,93.2,1,1,0,180,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_178).wait(71));

	// ani_particle03
	this.instance_179 = new lib.ani_particle03("synched",19);
	this.instance_179.setTransform(-37.7,45.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_179).wait(71));

	// ani_particle04
	this.instance_180 = new lib.ani_particle04("synched",30);
	this.instance_180.setTransform(7.3,73.7,1,1,0,180,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_180).wait(71));

	// ani_particle03
	this.instance_181 = new lib.ani_particle03("synched",42);
	this.instance_181.setTransform(67.9,70.9,1,1,0,180,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_181).wait(71));

	// ani_particle02
	this.instance_182 = new lib.ani_particle02("synched",36);
	this.instance_182.setTransform(25.9,111.2,1,1,0,180,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_182).wait(71));

	// ani_particle01
	this.instance_183 = new lib.ani_particle01("synched",25);
	this.instance_183.setTransform(10.3,128.3,1,1,0,180,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_183).wait(71));

	// ani_particle03
	this.instance_184 = new lib.ani_particle03("synched",34);
	this.instance_184.setTransform(40.9,85.4,1,1,0,180,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_184).wait(71));

	// ani_particle04
	this.instance_185 = new lib.ani_particle04("synched",48);
	this.instance_185.setTransform(-39.7,26.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_185).wait(71));

	// ani_particle02
	this.instance_186 = new lib.ani_particle02("synched",40);
	this.instance_186.setTransform(34.9,29.4);

	this.timeline.addTween(cjs.Tween.get(this.instance_186).wait(71));

	// ani_particle03
	this.instance_187 = new lib.ani_particle03("synched",44);
	this.instance_187.setTransform(-12.7,63.8,1,1,0,180,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_187).wait(71));

	// ani_particle04
	this.instance_188 = new lib.ani_particle04("synched",49);
	this.instance_188.setTransform(-12.7,48.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_188).wait(71));

	// ani_particle03
	this.instance_189 = new lib.ani_particle03("synched",57);
	this.instance_189.setTransform(11.9,34.7);

	this.timeline.addTween(cjs.Tween.get(this.instance_189).wait(71));

	// ani_particle02
	this.instance_190 = new lib.ani_particle02("synched",54);
	this.instance_190.setTransform(5.9,11.4);

	this.timeline.addTween(cjs.Tween.get(this.instance_190).wait(71));

	// ani_particle01
	this.instance_191 = new lib.ani_particle01("synched",64);
	this.instance_191.setTransform(-9.7,-5.7);

	this.timeline.addTween(cjs.Tween.get(this.instance_191).wait(71));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-62.2,-12.8,1173.4,145.2);


(lib.ani_inLine = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 20
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#002F6C").s().p("AgMAnQgFgCgDgDQgDgDgBgEIgCgKIALAAQABAIAEADQAEADAGAAQAIAAAEgDQADgDAAgGIgBgFQAAgBAAAAQAAgBgBAAQAAgBAAAAQgBAAAAgBIgEgCIgIgCIgGgCQgJgCgFgEQgGgFAAgKQAAgMAHgGQAIgFALAAQAMAAAHAFQAHAGAAAOIgLAAQgBgIgDgDQgEgDgHAAQgHAAgDADQgDADAAAGQAAAFADADQACACAIACIAGACQAMADAFAEQAEAFAAAKQAAAFgBAEQgCAEgDADQgDADgGABQgFACgHAAQgGAAgGgCg");
	this.shape.setTransform(1381.3,43);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#002F6C").s().p("AgeA5IAAhwIAMAAIAAALQAGgMANAAQAIAAAGACQAFADAEAFQAEAFACAIQABAIAAAKQAAAUgHAKQgIAKgQAAQgLAAgHgKIAAAqgAgHgrQgDABgDAEQgCADgBAGQgCAGAAAIIACAPIADAIQACADAEACQADABAEAAQAFAAAEgBQADgCACgDQACgEACgEIABgPIgBgOQgCgGgCgDQgCgEgDgBIgJgBIgHABg");
	this.shape_1.setTransform(1374,44.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#002F6C").s().p("AgMAnQgGgDgEgFQgEgFgBgIQgCgIAAgKQAAgVAHgJQAJgKAOAAQAIAAAFACQAGADADAFQAEAFACAHQABAIAAAJIAAACIguAAIABAPQABAGACADQACADAEABIAHABQAIAAAEgDQAEgDABgIIALAAQgBAMgGAGQgGAHgPAAQgGAAgHgCgAgFgcQgDABgDADIgDAGIgCALIAiAAQgBgHgBgEQgBgEgCgCQgCgDgDgBIgIAAIgFAAg");
	this.shape_2.setTransform(1366,43);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#002F6C").s().p("AALAyQgWAAAAgaIAAgqIgLAAIAAgLIALAAIAAgTIALAAIAAATIAXAAIAAALIgXAAIAAAqQAAAJACACQADAEAIAAIAKAAIAAALg");
	this.shape_3.setTransform(1359.6,42.1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#002F6C").s().p("AgaAxQgIgJgBgSIAMAAQABAOAGAGQAFAGALAAQALAAAGgFQAGgFAAgKIgBgIQgCgEgDgDQgCgCgEgBIgJgEIgHgCIgLgDQgGgBgDgEQgEgDgCgGQgDgFAAgJQAAgOAJgIQAJgIAQAAQAKgBAGADQAHADAEAFQAEAEACAHQACAHAAAJIgMAAIgCgLQgCgGgDgCQgCgDgFgCIgJgBQgJAAgGAFQgFAEAAAJQAAAGABADIAEAGQADADAEABIAIADIAHACIAMADQAGACAEAEQADADACAGQACAFAAAIQAAAOgJAIQgJAIgSAAQgRABgJgKg");
	this.shape_4.setTransform(1352.5,41.4);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#002F6C").s().p("AAQApIAAgxQAAgLgEgFQgEgDgIgBQgHABgDADQgFAFAAALIAAAxIgNAAIAAhPIAMAAIAAAKQAGgLANAAQANgBAHAIQAFAIABANIAAA0g");
	this.shape_5.setTransform(1340.9,43);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#002F6C").s().p("AgFA5IAAhxIALAAIAABxg");
	this.shape_6.setTransform(1334.9,41.4);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#002F6C").s().p("AgLA4QgGgCgDgDQgDgEgCgFQgCgFAAgGIAMAAQABAJADAEQAEADAHAAQAKAAAEgEQAEgDAAgKIAAgRQgGAMgNAAQgIAAgFgDQgGgCgDgFQgEgFgCgIQgBgGAAgLQAAgWAHgKQAIgKAPAAQAGAAAFADQAFADADAGIAAgKIAMAAIAABVQAAAOgHAHQgIAHgPAAQgHAAgFgCgAgHgsQgEACgCADQgCAEgBAGIgBAOIABAPQABAEACADQACAEAEABQADACAEAAIAIgBQADgCADgDQACgEABgEIABgPIgBgOQgBgGgCgEQgCgDgEgCIgIgBIgHABg");
	this.shape_7.setTransform(1325.3,44.7);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#002F6C").s().p("AAQApIAAgxQAAgLgEgFQgEgDgIgBQgHABgDADQgFAFAAALIAAAxIgNAAIAAhPIAMAAIAAAKQAGgLANAAQANgBAHAIQAFAIAAANIAAA0g");
	this.shape_8.setTransform(1317.5,43);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#002F6C").s().p("AgFA5IAAhPIALAAIAABPgAgFgoIAAgQIALAAIAAAQg");
	this.shape_9.setTransform(1311.7,41.4);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#002F6C").s().p("AgOA3QgGgDgDgFQgEgFgCgIQgBgIAAgLQAAgTAHgKQAIgKAPAAQANAAAFAKIAAgqIANAAIAABwIgMAAIAAgMQgGANgOAAQgIAAgFgCgAgHgLQgEABgCAEQgCADgBAEIgBAOIABAPQABAGACAEQACADAEACQADABAEAAQAFAAADgBQAEgCACgDQACgEABgGIABgPIgBgOQgBgEgCgDQgCgEgEgBIgIgBIgHABg");
	this.shape_10.setTransform(1305.7,41.4);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#002F6C").s().p("AgVAjQgGgFAAgKQAAgHACgEQADgEAEgDQAEgCAFgBIAMgEIAMgCIAAgFQAAgIgDgFQgDgEgJAAQgGAAgEADQgDAEAAAJIgMAAQABgNAGgHQAGgHAOAAQAHAAAFACQAFACADADQADAEABAFQACAFAAAGIAAA1IgNAAIAAgKQgCAEgFAEQgFADgGAAQgMAAgGgGgAAEADIgIACIgGAEQgCABgBADIgBAFQAAANAOAAQAGAAAEgFQAFgFAAgIIAAgLg");
	this.shape_11.setTransform(1298,43);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#002F6C").s().p("AgLA5IAAhEIgKAAIAAgLIAKAAIAAgIQAAgMAGgHQAFgGAMgBIAKAAIAAAMIgJAAQgHAAgDAEQgDACAAAIIAAAIIAUAAIAAALIgUAAIAABEg");
	this.shape_12.setTransform(1292.2,41.4);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#002F6C").s().p("AgnAFIAAgJIBPAAIAAAJg");
	this.shape_13.setTransform(1285,47.8);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#002F6C").s().p("AgFA5IAAhPIALAAIAABPgAgFgoIAAgQIALAAIAAAQg");
	this.shape_14.setTransform(1278.6,41.4);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#002F6C").s().p("AAQApIAAgxQAAgLgEgFQgEgDgIgBQgGABgEADQgFAFAAALIAAAxIgMAAIAAhPIAMAAIAAAKQAEgLAOAAQANgBAGAIQAHAIgBANIAAA0g");
	this.shape_15.setTransform(1273,43);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#002F6C").s().p("AAdA5IgJgcIgpAAIgIAcIgMAAIAjhxIANAAIAjBxgAgRASIAiAAIgRg6g");
	this.shape_16.setTransform(1264.5,41.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).to({state:[]},30).wait(120));

	// Ebene 4
	this.instance = new lib.ani_fadeIn();
	this.instance.setTransform(609,351.5,1,1,0,0,0,609,351.5);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(20).to({_off:false},0).to({_off:true},10).wait(120));

	// Ebene 3
	this.instance_1 = new lib.ani_fadeIn();
	this.instance_1.setTransform(609,351.5,1,1,0,0,0,609,351.5);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(10).to({_off:false},0).to({_off:true},10).wait(130));

	// Ebene 1
	this.instance_2 = new lib.ani_fadeIn();
	this.instance_2.setTransform(609,351.5,1,1,0,0,0,609,351.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({_off:true},10).wait(140));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,1425,703);


(lib.ani_airFlowComplete = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("EhVdgPcQctGeR0AaMB8aAAAIAAReMh9+AAAQ3oBd1VFGg");
	mask.setTransform(547.1,99);

	// Ebene 1
	this.instance = new lib.ani_airflow();
	this.instance.setTransform(547.2,99,1,1,0,0,0,547.1,99);

	this.instance.mask = mask;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({regX:0,regY:0,x:0.1,y:0},0).wait(1).to({y:0.2},0).wait(1).to({y:0.4},0).wait(1).to({y:0.8},0).wait(1).to({y:1.2},0).wait(1).to({y:1.7},0).wait(1).to({y:2.4},0).wait(1).to({y:3.1},0).wait(1).to({y:4},0).wait(1).to({y:4.9},0).wait(1).to({y:5.9},0).wait(1).to({y:7},0).wait(1).to({y:8.2},0).wait(1).to({y:9.5},0).wait(1).to({y:10.9},0).wait(1).to({y:12.3},0).wait(1).to({y:13.7},0).wait(1).to({y:15.1},0).wait(1).to({y:16.6},0).wait(1).to({y:18},0).wait(1).to({y:19.4},0).wait(1).to({y:20.7},0).wait(1).to({y:21.9},0).wait(1).to({y:23},0).wait(1).to({y:24},0).wait(1).to({y:24.9},0).wait(1).to({y:25.7},0).wait(1).to({y:26.2},0).wait(1).to({y:26.7},0).wait(1).to({y:26.9},0).wait(1).to({regX:547.1,regY:99,x:547.2,y:126},0).wait(1).to({regX:0,regY:0,x:0.1,y:27},0).wait(1).to({y:26.9},0).wait(1).to({y:26.7},0).wait(1).to({y:26.5},0).wait(1).to({y:26.2},0).wait(1).to({y:25.9},0).wait(1).to({y:25.4},0).wait(1).to({y:24.9},0).wait(1).to({y:24.4},0).wait(1).to({y:23.8},0).wait(1).to({y:23.1},0).wait(1).to({y:22.3},0).wait(1).to({y:21.5},0).wait(1).to({y:20.6},0).wait(1).to({y:19.7},0).wait(1).to({y:18.7},0).wait(1).to({y:17.6},0).wait(1).to({y:16.6},0).wait(1).to({y:15.4},0).wait(1).to({y:14.3},0).wait(1).to({y:13.1},0).wait(1).to({y:12},0).wait(1).to({y:10.8},0).wait(1).to({y:9.6},0).wait(1).to({y:8.5},0).wait(1).to({y:7.4},0).wait(1).to({y:6.3},0).wait(1).to({y:5.3},0).wait(1).to({y:4.3},0).wait(1).to({y:3.5},0).wait(1).to({y:2.7},0).wait(1).to({y:2},0).wait(1).to({y:1.4},0).wait(1).to({y:0.9},0).wait(1).to({y:0.5},0).wait(1).to({y:0.2},0).wait(1).to({y:0.1},0).wait(1).to({regX:547.1,regY:99,x:547.2,y:99},0).wait(1));

	// ani_airflow
	this.instance_1 = new lib.ani_airflow();
	this.instance_1.setTransform(1167.2,99,1,1,0,0,0,547.1,99);

	this.instance_1.mask = mask;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({regX:0,regY:0,x:620.1,y:0},0).wait(1).to({y:-0.1},0).wait(1).to({y:-0.2},0).wait(1).to({y:-0.4},0).wait(1).to({y:-0.6},0).wait(1).to({y:-0.9},0).wait(1).to({y:-1.2},0).wait(1).to({y:-1.6},0).wait(1).to({y:-2},0).wait(1).to({y:-2.4},0).wait(1).to({y:-3},0).wait(1).to({y:-3.5},0).wait(1).to({y:-4.1},0).wait(1).to({y:-4.8},0).wait(1).to({y:-5.4},0).wait(1).to({y:-6.1},0).wait(1).to({y:-6.8},0).wait(1).to({y:-7.6},0).wait(1).to({y:-8.3},0).wait(1).to({y:-9},0).wait(1).to({y:-9.7},0).wait(1).to({y:-10.3},0).wait(1).to({y:-11},0).wait(1).to({y:-11.5},0).wait(1).to({y:-12},0).wait(1).to({y:-12.5},0).wait(1).to({y:-12.8},0).wait(1).to({y:-13.1},0).wait(1).to({y:-13.3},0).wait(1).to({y:-13.5},0).wait(1).to({regX:547.1,regY:99,x:1167.2,y:85.5},0).wait(1).to({regX:0,regY:0,x:620.1,y:-13.5},0).wait(1).to({y:-13.4},0).wait(2).to({y:-13.2},0).wait(1).to({y:-13.1},0).wait(1).to({y:-12.9},0).wait(1).to({y:-12.7},0).wait(1).to({y:-12.5},0).wait(1).to({y:-12.2},0).wait(1).to({y:-11.9},0).wait(1).to({y:-11.5},0).wait(1).to({y:-11.2},0).wait(1).to({y:-10.7},0).wait(1).to({y:-10.3},0).wait(1).to({y:-9.8},0).wait(1).to({y:-9.3},0).wait(1).to({y:-8.8},0).wait(1).to({y:-8.3},0).wait(1).to({y:-7.7},0).wait(1).to({y:-7.1},0).wait(1).to({y:-6.6},0).wait(1).to({y:-6},0).wait(1).to({y:-5.4},0).wait(1).to({y:-4.8},0).wait(1).to({y:-4.2},0).wait(1).to({y:-3.7},0).wait(1).to({y:-3.1},0).wait(1).to({y:-2.6},0).wait(1).to({y:-2.2},0).wait(1).to({y:-1.7},0).wait(1).to({y:-1.3},0).wait(1).to({y:-1},0).wait(1).to({y:-0.7},0).wait(1).to({y:-0.4},0).wait(1).to({y:-0.3},0).wait(1).to({y:-0.1},0).wait(1).to({y:0},0).wait(1).to({regX:547.1,regY:99,x:1167.2,y:99},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,14.5,1094.2,168);


(lib.ani_opfCycle = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Egl/AS0MAAAglnMBL/AAAIAABuIivAAIAADcICvAAIAAG4IivAAIAADcICvAAIAAFIIAABuIivAAIAADcICvAAIAAE/IAAB5IivAAIAADRICvAAIAABug");
	mask.setTransform(144.6,131.1);

	// ani_particles
	this.instance = new lib.ani_particles();
	this.instance.setTransform(218.2,132.7,1,0.758,0,0,0,537,64.4);
	this.instance.alpha = 0.5;

	this.instance.mask = mask;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(111));

	// Ebene 3
	this.instance_1 = new lib.pic_particleFilter("synched",0,false);
	this.instance_1.setTransform(247,131.1,1,1,0,0,0,247,131);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(111));

	// mask (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("EhLhAX+MAAAgv8MCXDAAAMAAAAv8g");
	mask_1.setTransform(344.5,130.6);

	// Ebene 7
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#FFFFFF","rgba(255,255,255,0)","rgba(255,255,255,0)","#FFFFFF"],[0.063,0.176,0.678,0.859],-465.7,0,465.7,0).s().p("EhIvAaPMAAAg0eMCRfAAAMAAAA0eg");
	this.shape.setTransform(326.7,137.1);

	this.shape.mask = mask_1;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(111));

	// ani_flow
	this.instance_2 = new lib.ani_airFlowComplete();
	this.instance_2.setTransform(2358.3,123.1,1,1,0,0,0,2660,99);
	this.instance_2.alpha = 0.5;

	this.instance_2.mask = mask_1;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(111));

	// ani_backpressure
	this.instance_3 = new lib.ani_arrowsBackpressure02("synched",0,false);
	this.instance_3.setTransform(-19.5,132,1,1,0,0,0,46.4,74.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(111));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-139,-22.9,967,307);


(lib.ani_slider_opf = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{slide1:0,slide2:19,slide3:39,slide4:59,slide5:79});

	// Ebene 7
	this.instance = new lib.container_text("single",81);
	this.instance.setTransform(1161.3,373.4,1,1,0,0,0,550,283.4);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(19).to({startPosition:83},0).wait(20).to({startPosition:92},0).wait(20).to({startPosition:93},0).wait(20).to({startPosition:94},0).wait(20));

	// Ebene 6
	this.instance_1 = new lib.container_text("single",82);
	this.instance_1.setTransform(1161.3,533.4,1,1,0,0,0,550,283.4);

	this.instance_2 = new lib.container_text("single",90);
	this.instance_2.setTransform(1161.3,753.4,1,1,0,0,0,550,283.4);

	this.instance_3 = new lib.container_text("single",89);
	this.instance_3.setTransform(1381.3,643.4,1,1,0,0,0,550,283.4);

	this.instance_4 = new lib.container_text("single",88);
	this.instance_4.setTransform(1161.3,643.4,1,1,0,0,0,550,283.4);

	this.instance_5 = new lib.container_text("single",87);
	this.instance_5.setTransform(1381.3,583.4,1,1,0,0,0,550,283.4);

	this.instance_6 = new lib.container_text("single",86);
	this.instance_6.setTransform(1161.3,583.4,1,1,0,0,0,550,283.4);

	this.instance_7 = new lib.container_text("single",85);
	this.instance_7.setTransform(1381.3,533.4,1,1,0,0,0,550,283.4);

	this.instance_8 = new lib.container_text("single",84);
	this.instance_8.setTransform(1161.3,533.4,1,1,0,0,0,550,283.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1,p:{x:1161.3,y:533.4,startPosition:82}}]}).to({state:[{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1,p:{x:1381.3,y:753.4,startPosition:91}}]},19).to({state:[]},20).wait(60));

	// Ebene 16
	this.instance_9 = new lib.pics_icons("single",0);
	this.instance_9.setTransform(57.3,451,1,1,0,0,0,15.2,21.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(99));

	// Ebene 4
	this.instance_10 = new lib.container_text("single",80);
	this.instance_10.setTransform(671,624.8,1,1,0,0,0,585,188.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(99));

	// Ebene 5
	this.instance_11 = new lib.ani_opfCycle("synched",0,false);
	this.instance_11.setTransform(317.9,290.3,0.809,0.809,0,0,0,254.1,151.4);

	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(99));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,90,1041.3,383.5);


(lib.slider_opf = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// nextBtn
	this.nextBtn = new lib.PreviousBtn();
	this.nextBtn.setTransform(1089.5,227,1,1,0,0,180,30.5,13);
	new cjs.ButtonHelper(this.nextBtn, 0, 1, 2, false, new lib.PreviousBtn(), 3);

	this.timeline.addTween(cjs.Tween.get(this.nextBtn).wait(1));

	// prevBtn
	this.prevBtn = new lib.PreviousBtn();
	this.prevBtn.setTransform(20.5,227,1,1,0,0,0,30.5,13);
	new cjs.ButtonHelper(this.prevBtn, 0, 1, 2, false, new lib.PreviousBtn(), 3);

	this.timeline.addTween(cjs.Tween.get(this.prevBtn).wait(1));

	// Ebene 1
	this.slideShowContent = new lib.ani_slider_opf();
	this.slideShowContent.setTransform(540,259,1,1,0,0,0,540,259);

	this.timeline.addTween(cjs.Tween.get(this.slideShowContent).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1862.3,90,4369.6,383.2);


(lib.popup03 = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// Ebene 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgcA5IAAhwIA5AAIAAALIgsAAIAAAmIApAAIAAAKIgpAAIAAA1g");
	this.shape.setTransform(1330.1,183.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AghA5IAAhwIAiAAQAJAAAGABQAGACAEAFQAEAEACAGQACAHAAAKQAAAJgDAHQgCAEgEAEQgEAEgGABQgGACgIAAIgUAAIAAAugAgTAAIAUAAIAJAAQAEAAACgCQACgDABgEIABgLIgBgLQgBgFgCgCQgCgDgEgBQgEgBgFgBIgUAAg");
	this.shape_1.setTransform(1321.9,183.4);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgSA3QgIgDgFgHQgFgHgCgMQgCgLAAgPQAAgPACgLQACgLAFgHQAFgHAIgDQAIgEAKABQAMgBAIAEQAHADAFAHQAFAHACALQACALAAAPQAAAPgCALQgCAMgEAHQgFAHgIADQgIAEgMAAQgKAAgIgEgAgMgrQgGACgDAFQgDAFgBAKQgCAIAAANQAAAOACAJQABAKADAFQADAFAGACQAFADAHAAQAIAAAGgDQAFgCADgFQADgFACgKIABgXIgBgVQgCgKgDgFQgDgFgFgCQgGgCgIAAQgHAAgFACg");
	this.shape_2.setTransform(1312.2,183.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgnAFIAAgJIBPAAIAAAJg");
	this.shape_3.setTransform(1302.6,189.8);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgaAyQgIgJgCgTIANAAQABAOAGAGQAFAGALAAQAMAAAFgFQAHgFAAgMQgBgLgFgFQgGgGgMABIgJAAIAAgKIAJAAQALAAAEgFQAGgGAAgJQAAgLgGgEQgGgFgJAAQgKAAgGAGQgFAFgCAPIgNAAQABgJACgHQACgHAEgFQAFgFAGgCQAHgDAJAAQARgBAIAJQAJAJAAAPQAAAHgDAIQgFAGgHADQAIABAFAHQAFAGgBANQAAAPgJAJQgJAJgSAAQgRgBgJgIg");
	this.shape_4.setTransform(1293.5,183.4);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AgQA3QgHgCgFgIQgEgGgCgMQgCgMAAgPQAAgPACgLQABgLAFgHQAEgHAHgDQAIgEAJABQAKgBAIAEQAHADAEAHQAFAHABALQACALAAAPQAAAPgCAMQgCAMgEAGQgFAIgHACQgHAEgKAAQgJAAgHgEgAgKgrQgFACgDAFQgCAFgBAKQgCAIAAANIABAXQABAJADAFQADAGAEACQAFADAGAAQAHAAAFgDQAEgCADgGQADgFABgJIABgXIgBgVQgCgKgCgFQgDgFgFgCQgEgCgHAAQgGAAgEACg");
	this.shape_5.setTransform(1284.6,183.4);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgeA5IAAhwIAMAAIAAALQAGgMAMAAQAJAAAGACQAFADAFAFQADAFABAIQACAIAAAKQAAAUgHAKQgHAKgRAAQgMAAgFgKIAAAqgAgHgrQgEABgCAEQgCADgBAGQgCAGABAIIABAPIADAIQACADAEACQAEABADAAQAFAAADgBQAEgCADgDQACgEABgEIAAgPIAAgOQgBgGgCgDQgDgEgEgBIgIgBIgHABg");
	this.shape_6.setTransform(1276.2,186.6);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AgVAhQgHgIAAgNIAAg0IANAAIAAAxQAAALAEAFQADAEAIAAQAIAAAEgEQAEgEAAgMIAAgxIANAAIAABPIgNAAIAAgKQgCAGgFADQgFACgGAAQgNAAgGgHg");
	this.shape_7.setTransform(1267.9,185.1);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AgeA5IAAhwIAMAAIAAALQAGgMAMAAQAJAAAGACQAGADAEAFQADAFABAIQACAIAAAKQAAAUgHAKQgHAKgRAAQgMAAgGgKIAAAqgAgHgrQgEABgCAEQgCADgBAGQgBAGgBAIIABAPIAEAIQACADAEACQAEABADAAQAFAAADgBQAEgCADgDQABgEABgEIABgPIgBgOQgBgGgBgDQgDgEgEgBIgIgBIgHABg");
	this.shape_8.setTransform(1260.1,186.6);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AgNAnQgGgDgEgFQgEgFgBgIQgCgIAAgKQAAgJACgIQABgIAEgFQAEgFAGgDQAGgCAHAAQAIAAAGACQAGADAEAFQAEAFACAIQABAIAAAJQAAAVgHAKQgIAKgQAAQgHAAgGgCgAgHgbQgEABgCAEQgCADgBAGIgBANIABAOQABAGACAEQACADAEACQADABAEAAQAFAAADgBQAEgCACgDQACgEABgGIABgOIgBgNQgBgGgCgDQgCgEgEgBIgIgBIgHABg");
	this.shape_9.setTransform(1252,185);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AgeA5IAAhwIAMAAIAAALQAGgMANAAQAIAAAGACQAFADAEAFQAEAFACAIQABAIAAAKQAAAUgHAKQgIAKgQAAQgLAAgHgKIAAAqgAgHgrQgEABgCAEQgCADgBAGQgCAGAAAIIABAPIAEAIQACADAEACQADABAEAAQAFAAADgBQAEgCACgDQACgEABgEIABgPIgBgOQgBgGgCgDQgCgEgEgBIgIgBIgHABg");
	this.shape_10.setTransform(1244.2,186.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(10));

	// Ebene 2
	this.instance = new lib.container_text("single",79);
	this.instance.setTransform(645,278.8,1,1,0,0,0,585,188.8);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(4).to({_off:false},0).wait(6));

	// Ebene 5
	this.closeBtn = new lib.btn_close02();
	this.closeBtn.setTransform(1162,58.2,1,1,0,0,0,12,11.8);
	this.closeBtn._off = true;

	this.timeline.addTween(cjs.Tween.get(this.closeBtn).wait(4).to({_off:false},0).wait(6));

	// scrollerWidget_1
	this.slideShowWidget = new lib.slider_opf();
	this.slideShowWidget.setTransform(600,349,1,1,0,0,0,540,259);
	this.slideShowWidget._off = true;

	this.timeline.addTween(cjs.Tween.get(this.slideShowWidget).wait(4).to({_off:false},0).wait(6));

	// Ebene 1
	this.instance_1 = new lib.pic_plane_white();
	this.instance_1.setTransform(609,336,0.993,1.132,0,0,0,579,265);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(4).to({_off:false},0).wait(6));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(1238,170.7,322,27.4);


(lib.popupCluster01 = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// popup_3
	this.popup_3_continueOnClose = new lib.popup03();
	this.popup_3_continueOnClose.setTransform(1354,124.4,1,1,0,0,0,1354,124.4);

	this.timeline.addTween(cjs.Tween.get(this.popup_3_continueOnClose).wait(1));

	// popup_2
	this.popup_2_continueOnClose = new lib.popup02();
	this.popup_2_continueOnClose.setTransform(1354,124.4,1,1,0,0,0,1354,124.4);

	this.timeline.addTween(cjs.Tween.get(this.popup_2_continueOnClose).wait(1));

	// popup_1
	this.popup_1_continueOnClose = new lib.popup01();
	this.popup_1_continueOnClose.setTransform(1354,124.4,1,1,0,0,0,1354,124.4);

	this.timeline.addTween(cjs.Tween.get(this.popup_1_continueOnClose).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(1238,110.7,322,87.4);


(lib.timelineJumpWidget = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{step1:0,step2:10,step3:20});

	// fadeIn
	this.instance = new lib.ani_inLine("synched",0);
	this.instance.setTransform(609,351.5,1,1,0,0,0,609,351.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(30));

	// popup_09
	this.instance_1 = new lib.ani_text_sideBar01();
	this.instance_1.setTransform(-104.5,351.5,1,1,0,0,0,-104.5,351.5);

	this.instance_2 = new lib.ani_text_sideBar02();
	this.instance_2.setTransform(-148.5,351.5,1,1,0,0,0,-148.5,351.5);

	this.instance_3 = new lib.ani_text_sideBar03();
	this.instance_3.setTransform(-148.5,351.5,1,1,0,0,0,-148.5,351.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1}]}).to({state:[]},9).to({state:[{t:this.instance_2}]},1).to({state:[]},9).to({state:[{t:this.instance_3}]},1).wait(10));

	// popup_09
	this.linkWidget = new lib.btn_ppe_link01();
	this.linkWidget.setTransform(950.7,744.6,1,1,0,0,0,353.7,230.5);

	this.instance_4 = new lib.popupCluster01();
	this.instance_4.setTransform(161,43.7,1,1,0,0,0,161,43.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.linkWidget}]}).to({state:[]},19).to({state:[{t:this.instance_4}]},1).wait(10));

	// popup_09
	this.instance_5 = new lib.pics_table("single",0);
	this.instance_5.setTransform(445,598.9,1,1,0,0,0,425,186.2);

	this.instance_6 = new lib.container_text("single",139);
	this.instance_6.setTransform(1430,824.8,1,1,0,0,0,540,224.8);

	this.clickPopup_3 = new lib.button03();
	this.clickPopup_3.setTransform(1030,500.2,1,1,0,0,0,170,30);

	this.clickPopup_2 = new lib.button02();
	this.clickPopup_2.setTransform(1030,445.2,1,1,0,0,0,170,30);

	this.clickPopup_1 = new lib.button01();
	this.clickPopup_1.setTransform(1030,390.2,1,1,0,0,0,170,30);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_5,p:{startPosition:0}}]}).to({state:[]},9).to({state:[{t:this.instance_5,p:{startPosition:1}}]},1).to({state:[]},9).to({state:[{t:this.clickPopup_1},{t:this.clickPopup_2},{t:this.clickPopup_3},{t:this.instance_6}]},1).wait(10));

	// popup_10
	this.instance_7 = new lib.container_pics("single",0);
	this.instance_7.setTransform(549.3,321.5,1,1,0,0,0,549.3,321.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(10).to({startPosition:1},0).wait(10).to({startPosition:2},0).wait(10));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-505.9,-1,1930.9,705);


// stage content:



(lib.c4p1 = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{"I":6});

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_2 = new cjs.Graphics().p("EhfJA26MAAAht0MC+SAAAMAAABt0g");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(2).to({graphics:mask_graphics_2,x:609,y:351.5}).wait(8));

	// timelineJumpWidget
	this.timelineJumpWidget = new lib.timelineJumpWidget();
	this.timelineJumpWidget._off = true;

	this.timelineJumpWidget.mask = mask;

	this.timeline.addTween(cjs.Tween.get(this.timelineJumpWidget).wait(2).to({_off:false},0).wait(8));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;

})(lib = lib||{}, images = images||{}, createjs = createjs||{}, ss = ss||{});
var lib, images, createjs, ss;