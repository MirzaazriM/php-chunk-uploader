(function (lib, img, cjs, ss) {

var p; // shortcut to reference prototypes
lib.webFontTxtFilters = {}; 

// library properties:
lib.properties = {
	width: 1218,
	height: 703,
	fps: 25,
	color: "#FFFFFF",
	opacity: 1.00,
	webfonts: {},
	manifest: [
		{src:"assets/content/images/c1p1_pic01.jpg", id:"c1p1_pic01"},
		{src:"assets/content/images/c1p1_pic03.jpg", id:"c1p1_pic03"},
		{src:"assets/content/images/c1p1_pic04.jpg", id:"c1p1_pic04"},
		{src:"assets/content/images/c1p1_pic05.jpg", id:"c1p1_pic05"},
		{src:"assets/content/images/pic_menu01.png", id:"pic_menu01"}
	]
};



lib.ssMetadata = [];


lib.webfontAvailable = function(family) { 
	lib.properties.webfonts[family] = true;
	var txtFilters = lib.webFontTxtFilters && lib.webFontTxtFilters[family] || [];
	for(var f = 0; f < txtFilters.length; ++f) {
		txtFilters[f].updateCache();
	}
};
// symbols:



(lib.c1p1_pic01 = function() {
	this.initialize(img.c1p1_pic01);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2000,1096);


(lib.c1p1_pic03 = function() {
	this.initialize(img.c1p1_pic03);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2000,1498);


(lib.c1p1_pic04 = function() {
	this.initialize(img.c1p1_pic04);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2000,1591);


(lib.c1p1_pic05 = function() {
	this.initialize(img.c1p1_pic05);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2000,1500);


(lib.pic_menu01 = function() {
	this.initialize(img.pic_menu01);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1000,545);


(lib.pic_shadow_round_occlusion = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#000000","rgba(0,0,0,0)"],[0,1],0,0,0,0,0,221.2).s().p("A4LYMQqCqBAAuLQAAuKKCqBQKBqCOKAAQOLAAKBKCQKCKBAAOKQAAOLqCKBQqBKCuLAAQuKAAqBqCg");
	this.shape.setTransform(219.1,219.1);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,438.1,438.1);


(lib.pic_shadow_occlusionRound = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#000000","rgba(0,0,0,0)"],[0,1],0,0,0,0,0,102.5).s().p("AsTMUQlGlHgBnNQABnMFGlHQFHlGHMgBQHNABFHFGQFGFHABHMQgBHNlGFHQlHFGnNABQnMgBlHlGg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-111.5,-111.5,223,223);


(lib.container_text = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// Ebene 8
	this.text_45 = new cjs.Text("Überspringen", "16px 'Porsche Next TT'", "#FFFFFF");
	this.text_45.name = "text_45";
	this.text_45.lineHeight = 23;
	this.text_45.lineWidth = 252;
	this.text_45.setTransform(2,2);
	this.text_45._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_45).wait(44).to({_off:false},0).to({_off:true},1).wait(3));

	// Ebene 18
	this.text_42 = new cjs.Text("Zur Themenübersicht ", "16px 'Porsche Next TT'", "#FFFFFF");
	this.text_42.name = "text_42";
	this.text_42.lineHeight = 23;
	this.text_42.lineWidth = 226;
	this.text_42.setTransform(2,2);
	this.text_42._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_42).wait(41).to({_off:false},0).to({_off:true},1).wait(6));

	// Ebene 7
	this.text_13 = new cjs.Text("Für den Alltag.", "80px 'Porsche Next TT'", "#FFFFFF");
	this.text_13.name = "text_13";
	this.text_13.textAlign = "right";
	this.text_13.lineHeight = 119;
	this.text_13.lineWidth = 864;
	this.text_13.setTransform(866.2,2);
	this.text_13._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_13).wait(12).to({_off:false},0).to({_off:true},1).wait(35));

	// Ebene 5
	this.text_11 = new cjs.Text("Lernen Sie die wichtigsten Neuerungen kennen! ", "24px 'Porsche Next TT'");
	this.text_11.name = "text_11";
	this.text_11.lineHeight = 37;
	this.text_11.lineWidth = 696;
	this.text_11.setTransform(2,2);
	this.text_11._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_11).wait(10).to({_off:false},0).to({_off:true},1).wait(37));

	// Ebene 4
	this.text_10 = new cjs.Text("umfassendes Infotainment", "32px 'Porsche Next TT'", "#FFFFFF");
	this.text_10.name = "text_10";
	this.text_10.lineHeight = 49;
	this.text_10.lineWidth = 528;
	this.text_10.setTransform(2,2);
	this.text_10._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_10).wait(9).to({_off:false},0).to({_off:true},1).wait(38));

	// Ebene 3
	this.text_09 = new cjs.Text("innovative Fahrassistenz ", "32px 'Porsche Next TT'", "#FFFFFF");
	this.text_09.name = "text_09";
	this.text_09.lineHeight = 49;
	this.text_09.lineWidth = 528;
	this.text_09.setTransform(2,2);
	this.text_09._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_09).wait(8).to({_off:false},0).to({_off:true},1).wait(39));

	// Ebene 13
	this.text_08 = new cjs.Text("noch mehr Performance ", "32px 'Porsche Next TT'", "#FFFFFF");
	this.text_08.name = "text_08";
	this.text_08.lineHeight = 49;
	this.text_08.lineWidth = 528;
	this.text_08.setTransform(2,2);
	this.text_08._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_08).wait(7).to({_off:false},0).to({_off:true},1).wait(40));

	// Ebene 15
	this.text_07 = new cjs.Text("gesteigerte Alltagstauglichkeit ", "32px 'Porsche Next TT'", "#FFFFFF");
	this.text_07.name = "text_07";
	this.text_07.lineHeight = 49;
	this.text_07.lineWidth = 528;
	this.text_07.setTransform(2,2);
	this.text_07._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_07).wait(6).to({_off:false},0).to({_off:true},1).wait(41));

	// Ebene 21
	this.text_06 = new cjs.Text("geschärftes Design ", "32px 'Porsche Next TT'", "#FFFFFF");
	this.text_06.name = "text_06";
	this.text_06.lineHeight = 49;
	this.text_06.lineWidth = 528;
	this.text_06.setTransform(2,2);
	this.text_06._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_06).wait(5).to({_off:false},0).to({_off:true},1).wait(42));

	// Ebene 20
	this.text_05 = new cjs.Text("Der neue Porsche Macan (MJ 19): ", "32px 'Porsche Next TT'", "#FFFFFF");
	this.text_05.name = "text_05";
	this.text_05.lineHeight = 49;
	this.text_05.lineWidth = 528;
	this.text_05.setTransform(2,2);
	this.text_05._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_05).wait(4).to({_off:false},0).to({_off:true},1).wait(43));

	// Ebene 19
	this.text_04 = new cjs.Text("80% Neukunden", "32px 'Porsche Next TT'", "#FFFFFF");
	this.text_04.name = "text_04";
	this.text_04.lineHeight = 49;
	this.text_04.lineWidth = 528;
	this.text_04.setTransform(2,2);
	this.text_04._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_04).wait(3).to({_off:false},0).to({_off:true},1).wait(44));

	// Ebene 14
	this.text_03 = new cjs.Text("Meistverkauftes Porsche Modell", "32px 'Porsche Next TT'", "#FFFFFF");
	this.text_03.name = "text_03";
	this.text_03.lineHeight = 49;
	this.text_03.lineWidth = 528;
	this.text_03.setTransform(2,2);
	this.text_03._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_03).wait(2).to({_off:false},0).to({_off:true},1).wait(45));

	// Ebene 2
	this.text_02 = new cjs.Text("Erfolgsgeschichte Macan:", "50px 'Porsche Next TT'", "#FFFFFF");
	this.text_02.name = "text_02";
	this.text_02.textAlign = "right";
	this.text_02.lineHeight = 75;
	this.text_02.lineWidth = 963;
	this.text_02.setTransform(965.4,2);
	this.text_02._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_02).wait(1).to({_off:false},0).to({_off:true},1).wait(46));

	// Ebene 1
	this.text_01 = new cjs.Text("Erfolgsgeschichte Macan:", "50px 'Porsche Next TT'", "#FFFFFF");
	this.text_01.name = "text_01";
	this.text_01.lineHeight = 75;
	this.text_01.lineWidth = 963;
	this.text_01.setTransform(2,2);

	this.timeline.addTween(cjs.Tween.get(this.text_01).to({_off:true},1).wait(47));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,967.4,77.2);


(lib.btn_blind_rectangular = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(153,0,0,0.498)").s().p("AmKGLIAAsVIMVAAIAAMVg");
	this.shape.setTransform(39.5,39.5);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(3).to({_off:false},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.btn_blind_rectangle = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("Aj5D6IAAnzIHzAAIAAHzg");
	this.shape.setTransform(25,25);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(3).to({_off:false},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.text10_ = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.instance = new lib.container_text("single",9);
	this.instance.setTransform(500,148.4,1,1,0,0,0,500,148.4);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,532.2,68.1);


(lib.text10 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// text03_
	this.instance = new lib.text10_();
	this.instance.setTransform(266.1,74.2,1,1,0,0,0,266.1,74.2);
	this.instance.shadow = new cjs.Shadow("rgba(255,255,255,1)",0,0,20);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// text04_
	this.instance_1 = new lib.text10_();
	this.instance_1.setTransform(266.1,74.2,1,1,0,0,0,266.1,74.2);
	this.instance_1.shadow = new cjs.Shadow("rgba(255,255,255,1)",0,0,20);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	// text04_
	this.instance_2 = new lib.text10_();
	this.instance_2.setTransform(266.1,74.2,1,1,0,0,0,266.1,74.2);
	this.instance_2.shadow = new cjs.Shadow("rgba(255,255,255,1)",0,0,20);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

	// text04_
	this.instance_3 = new lib.text10_();
	this.instance_3.setTransform(266.1,74.2,1,1,0,0,0,266.1,74.2);
	this.instance_3.shadow = new cjs.Shadow("rgba(255,255,255,1)",0,0,20);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(1));

	// text04_
	this.instance_4 = new lib.text10_();
	this.instance_4.setTransform(266.1,74.2,1,1,0,0,0,266.1,74.2);
	this.instance_4.shadow = new cjs.Shadow("rgba(255,255,255,1)",0,0,20);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(1));

	// text04_
	this.instance_5 = new lib.text10_();
	this.instance_5.setTransform(266.1,74.2,1,1,0,0,0,266.1,74.2);
	this.instance_5.shadow = new cjs.Shadow("rgba(255,255,255,1)",0,0,20);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(1));

	// text04_
	this.instance_6 = new lib.text10_();
	this.instance_6.setTransform(266.1,74.2,1,1,0,0,0,266.1,74.2);
	this.instance_6.shadow = new cjs.Shadow("rgba(255,255,255,1)",0,0,20);

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(1));

	// text04_
	this.instance_7 = new lib.text10_();
	this.instance_7.setTransform(266.1,74.2,1,1,0,0,0,266.1,74.2);
	this.instance_7.shadow = new cjs.Shadow("rgba(255,255,255,1)",0,0,20);

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(1));

	// text04_
	this.instance_8 = new lib.text10_();
	this.instance_8.setTransform(266.1,74.2,1,1,0,0,0,266.1,74.2);
	this.instance_8.shadow = new cjs.Shadow("rgba(255,255,255,1)",0,0,20);

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(1));

	// text04_
	this.instance_9 = new lib.text10_();
	this.instance_9.setTransform(266.1,74.2,1,1,0,0,0,266.1,74.2);
	this.instance_9.shadow = new cjs.Shadow("rgba(255,255,255,1)",0,0,20);

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(1));

	// text04_
	this.instance_10 = new lib.text10_();
	this.instance_10.setTransform(266.1,74.2,1,1,0,0,0,266.1,74.2);
	this.instance_10.shadow = new cjs.Shadow("rgba(255,255,255,1)",0,0,20);

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-21,-21,578,114);


(lib.text09_ = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.instance = new lib.container_text("single",8);
	this.instance.setTransform(500,148.4,1,1,0,0,0,500,148.4);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,532.2,68.1);


(lib.text09 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// text03_
	this.instance = new lib.text09_();
	this.instance.setTransform(266.1,74.2,1,1,0,0,0,266.1,74.2);
	this.instance.shadow = new cjs.Shadow("rgba(255,255,255,1)",0,0,20);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// text04_
	this.instance_1 = new lib.text09_();
	this.instance_1.setTransform(266.1,74.2,1,1,0,0,0,266.1,74.2);
	this.instance_1.shadow = new cjs.Shadow("rgba(255,255,255,1)",0,0,20);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	// text04_
	this.instance_2 = new lib.text09_();
	this.instance_2.setTransform(266.1,74.2,1,1,0,0,0,266.1,74.2);
	this.instance_2.shadow = new cjs.Shadow("rgba(255,255,255,1)",0,0,20);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

	// text04_
	this.instance_3 = new lib.text09_();
	this.instance_3.setTransform(266.1,74.2,1,1,0,0,0,266.1,74.2);
	this.instance_3.shadow = new cjs.Shadow("rgba(255,255,255,1)",0,0,20);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(1));

	// text04_
	this.instance_4 = new lib.text09_();
	this.instance_4.setTransform(266.1,74.2,1,1,0,0,0,266.1,74.2);
	this.instance_4.shadow = new cjs.Shadow("rgba(255,255,255,1)",0,0,20);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(1));

	// text04_
	this.instance_5 = new lib.text09_();
	this.instance_5.setTransform(266.1,74.2,1,1,0,0,0,266.1,74.2);
	this.instance_5.shadow = new cjs.Shadow("rgba(255,255,255,1)",0,0,20);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(1));

	// text04_
	this.instance_6 = new lib.text09_();
	this.instance_6.setTransform(266.1,74.2,1,1,0,0,0,266.1,74.2);
	this.instance_6.shadow = new cjs.Shadow("rgba(255,255,255,1)",0,0,20);

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(1));

	// text04_
	this.instance_7 = new lib.text09_();
	this.instance_7.setTransform(266.1,74.2,1,1,0,0,0,266.1,74.2);
	this.instance_7.shadow = new cjs.Shadow("rgba(255,255,255,1)",0,0,20);

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(1));

	// text04_
	this.instance_8 = new lib.text09_();
	this.instance_8.setTransform(266.1,74.2,1,1,0,0,0,266.1,74.2);
	this.instance_8.shadow = new cjs.Shadow("rgba(255,255,255,1)",0,0,20);

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(1));

	// text04_
	this.instance_9 = new lib.text09_();
	this.instance_9.setTransform(266.1,74.2,1,1,0,0,0,266.1,74.2);
	this.instance_9.shadow = new cjs.Shadow("rgba(255,255,255,1)",0,0,20);

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(1));

	// text04_
	this.instance_10 = new lib.text09_();
	this.instance_10.setTransform(266.1,74.2,1,1,0,0,0,266.1,74.2);
	this.instance_10.shadow = new cjs.Shadow("rgba(255,255,255,1)",0,0,20);

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-21,-21,578,114);


(lib.text08_ = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.instance = new lib.container_text("single",7);
	this.instance.setTransform(500,148.4,1,1,0,0,0,500,148.4);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,532.2,68.1);


(lib.text08 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// text03_
	this.instance = new lib.text08_();
	this.instance.setTransform(266.1,74.2,1,1,0,0,0,266.1,74.2);
	this.instance.shadow = new cjs.Shadow("rgba(255,255,255,1)",0,0,20);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// text04_
	this.instance_1 = new lib.text08_();
	this.instance_1.setTransform(266.1,74.2,1,1,0,0,0,266.1,74.2);
	this.instance_1.shadow = new cjs.Shadow("rgba(255,255,255,1)",0,0,20);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	// text04_
	this.instance_2 = new lib.text08_();
	this.instance_2.setTransform(266.1,74.2,1,1,0,0,0,266.1,74.2);
	this.instance_2.shadow = new cjs.Shadow("rgba(255,255,255,1)",0,0,20);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

	// text04_
	this.instance_3 = new lib.text08_();
	this.instance_3.setTransform(266.1,74.2,1,1,0,0,0,266.1,74.2);
	this.instance_3.shadow = new cjs.Shadow("rgba(255,255,255,1)",0,0,20);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(1));

	// text04_
	this.instance_4 = new lib.text08_();
	this.instance_4.setTransform(266.1,74.2,1,1,0,0,0,266.1,74.2);
	this.instance_4.shadow = new cjs.Shadow("rgba(255,255,255,1)",0,0,20);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(1));

	// text04_
	this.instance_5 = new lib.text08_();
	this.instance_5.setTransform(266.1,74.2,1,1,0,0,0,266.1,74.2);
	this.instance_5.shadow = new cjs.Shadow("rgba(255,255,255,1)",0,0,20);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(1));

	// text04_
	this.instance_6 = new lib.text08_();
	this.instance_6.setTransform(266.1,74.2,1,1,0,0,0,266.1,74.2);
	this.instance_6.shadow = new cjs.Shadow("rgba(255,255,255,1)",0,0,20);

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(1));

	// text04_
	this.instance_7 = new lib.text08_();
	this.instance_7.setTransform(266.1,74.2,1,1,0,0,0,266.1,74.2);
	this.instance_7.shadow = new cjs.Shadow("rgba(255,255,255,1)",0,0,20);

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(1));

	// text04_
	this.instance_8 = new lib.text08_();
	this.instance_8.setTransform(266.1,74.2,1,1,0,0,0,266.1,74.2);
	this.instance_8.shadow = new cjs.Shadow("rgba(255,255,255,1)",0,0,20);

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(1));

	// text04_
	this.instance_9 = new lib.text08_();
	this.instance_9.setTransform(266.1,74.2,1,1,0,0,0,266.1,74.2);
	this.instance_9.shadow = new cjs.Shadow("rgba(255,255,255,1)",0,0,20);

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(1));

	// text04_
	this.instance_10 = new lib.text08_();
	this.instance_10.setTransform(266.1,74.2,1,1,0,0,0,266.1,74.2);
	this.instance_10.shadow = new cjs.Shadow("rgba(255,255,255,1)",0,0,20);

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-21,-21,578,114);


(lib.text07_ = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.instance = new lib.container_text("single",6);
	this.instance.setTransform(500,148.4,1,1,0,0,0,500,148.4);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,532.2,68.1);


(lib.text07 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// text03_
	this.instance = new lib.text07_();
	this.instance.setTransform(266.1,74.2,1,1,0,0,0,266.1,74.2);
	this.instance.shadow = new cjs.Shadow("rgba(255,255,255,1)",0,0,20);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// text04_
	this.instance_1 = new lib.text07_();
	this.instance_1.setTransform(266.1,74.2,1,1,0,0,0,266.1,74.2);
	this.instance_1.shadow = new cjs.Shadow("rgba(255,255,255,1)",0,0,20);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	// text04_
	this.instance_2 = new lib.text07_();
	this.instance_2.setTransform(266.1,74.2,1,1,0,0,0,266.1,74.2);
	this.instance_2.shadow = new cjs.Shadow("rgba(255,255,255,1)",0,0,20);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

	// text04_
	this.instance_3 = new lib.text07_();
	this.instance_3.setTransform(266.1,74.2,1,1,0,0,0,266.1,74.2);
	this.instance_3.shadow = new cjs.Shadow("rgba(255,255,255,1)",0,0,20);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(1));

	// text04_
	this.instance_4 = new lib.text07_();
	this.instance_4.setTransform(266.1,74.2,1,1,0,0,0,266.1,74.2);
	this.instance_4.shadow = new cjs.Shadow("rgba(255,255,255,1)",0,0,20);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(1));

	// text04_
	this.instance_5 = new lib.text07_();
	this.instance_5.setTransform(266.1,74.2,1,1,0,0,0,266.1,74.2);
	this.instance_5.shadow = new cjs.Shadow("rgba(255,255,255,1)",0,0,20);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(1));

	// text04_
	this.instance_6 = new lib.text07_();
	this.instance_6.setTransform(266.1,74.2,1,1,0,0,0,266.1,74.2);
	this.instance_6.shadow = new cjs.Shadow("rgba(255,255,255,1)",0,0,20);

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(1));

	// text04_
	this.instance_7 = new lib.text07_();
	this.instance_7.setTransform(266.1,74.2,1,1,0,0,0,266.1,74.2);
	this.instance_7.shadow = new cjs.Shadow("rgba(255,255,255,1)",0,0,20);

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(1));

	// text04_
	this.instance_8 = new lib.text07_();
	this.instance_8.setTransform(266.1,74.2,1,1,0,0,0,266.1,74.2);
	this.instance_8.shadow = new cjs.Shadow("rgba(255,255,255,1)",0,0,20);

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(1));

	// text04_
	this.instance_9 = new lib.text07_();
	this.instance_9.setTransform(266.1,74.2,1,1,0,0,0,266.1,74.2);
	this.instance_9.shadow = new cjs.Shadow("rgba(255,255,255,1)",0,0,20);

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(1));

	// text04_
	this.instance_10 = new lib.text07_();
	this.instance_10.setTransform(266.1,74.2,1,1,0,0,0,266.1,74.2);
	this.instance_10.shadow = new cjs.Shadow("rgba(255,255,255,1)",0,0,20);

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-21,-21,578,114);


(lib.text06_ = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.instance = new lib.container_text("single",5);
	this.instance.setTransform(500,148.4,1,1,0,0,0,500,148.4);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,532.2,68.1);


(lib.text06 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// text03_
	this.instance = new lib.text06_();
	this.instance.setTransform(266.1,74.2,1,1,0,0,0,266.1,74.2);
	this.instance.shadow = new cjs.Shadow("rgba(255,255,255,1)",0,0,20);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// text04_
	this.instance_1 = new lib.text06_();
	this.instance_1.setTransform(266.1,74.2,1,1,0,0,0,266.1,74.2);
	this.instance_1.shadow = new cjs.Shadow("rgba(255,255,255,1)",0,0,20);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	// text04_
	this.instance_2 = new lib.text06_();
	this.instance_2.setTransform(266.1,74.2,1,1,0,0,0,266.1,74.2);
	this.instance_2.shadow = new cjs.Shadow("rgba(255,255,255,1)",0,0,20);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

	// text04_
	this.instance_3 = new lib.text06_();
	this.instance_3.setTransform(266.1,74.2,1,1,0,0,0,266.1,74.2);
	this.instance_3.shadow = new cjs.Shadow("rgba(255,255,255,1)",0,0,20);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(1));

	// text04_
	this.instance_4 = new lib.text06_();
	this.instance_4.setTransform(266.1,74.2,1,1,0,0,0,266.1,74.2);
	this.instance_4.shadow = new cjs.Shadow("rgba(255,255,255,1)",0,0,20);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(1));

	// text04_
	this.instance_5 = new lib.text06_();
	this.instance_5.setTransform(266.1,74.2,1,1,0,0,0,266.1,74.2);
	this.instance_5.shadow = new cjs.Shadow("rgba(255,255,255,1)",0,0,20);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(1));

	// text04_
	this.instance_6 = new lib.text06_();
	this.instance_6.setTransform(266.1,74.2,1,1,0,0,0,266.1,74.2);
	this.instance_6.shadow = new cjs.Shadow("rgba(255,255,255,1)",0,0,20);

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(1));

	// text04_
	this.instance_7 = new lib.text06_();
	this.instance_7.setTransform(266.1,74.2,1,1,0,0,0,266.1,74.2);
	this.instance_7.shadow = new cjs.Shadow("rgba(255,255,255,1)",0,0,20);

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(1));

	// text04_
	this.instance_8 = new lib.text06_();
	this.instance_8.setTransform(266.1,74.2,1,1,0,0,0,266.1,74.2);
	this.instance_8.shadow = new cjs.Shadow("rgba(255,255,255,1)",0,0,20);

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(1));

	// text04_
	this.instance_9 = new lib.text06_();
	this.instance_9.setTransform(266.1,74.2,1,1,0,0,0,266.1,74.2);
	this.instance_9.shadow = new cjs.Shadow("rgba(255,255,255,1)",0,0,20);

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(1));

	// text04_
	this.instance_10 = new lib.text06_();
	this.instance_10.setTransform(266.1,74.2,1,1,0,0,0,266.1,74.2);
	this.instance_10.shadow = new cjs.Shadow("rgba(255,255,255,1)",0,0,20);

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-21,-21,578,114);


(lib.text05_ = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.instance = new lib.container_text("single",4);
	this.instance.setTransform(500,148.4,1,1,0,0,0,500,148.4);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,532.2,68.1);


(lib.text05 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// text03_
	this.instance = new lib.text05_();
	this.instance.setTransform(266.1,74.2,1,1,0,0,0,266.1,74.2);
	this.instance.shadow = new cjs.Shadow("rgba(255,255,255,1)",0,0,20);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// text04_
	this.instance_1 = new lib.text05_();
	this.instance_1.setTransform(266.1,74.2,1,1,0,0,0,266.1,74.2);
	this.instance_1.shadow = new cjs.Shadow("rgba(255,255,255,1)",0,0,20);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	// text04_
	this.instance_2 = new lib.text05_();
	this.instance_2.setTransform(266.1,74.2,1,1,0,0,0,266.1,74.2);
	this.instance_2.shadow = new cjs.Shadow("rgba(255,255,255,1)",0,0,20);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

	// text04_
	this.instance_3 = new lib.text05_();
	this.instance_3.setTransform(266.1,74.2,1,1,0,0,0,266.1,74.2);
	this.instance_3.shadow = new cjs.Shadow("rgba(255,255,255,1)",0,0,20);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(1));

	// text04_
	this.instance_4 = new lib.text05_();
	this.instance_4.setTransform(266.1,74.2,1,1,0,0,0,266.1,74.2);
	this.instance_4.shadow = new cjs.Shadow("rgba(255,255,255,1)",0,0,20);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(1));

	// text04_
	this.instance_5 = new lib.text05_();
	this.instance_5.setTransform(266.1,74.2,1,1,0,0,0,266.1,74.2);
	this.instance_5.shadow = new cjs.Shadow("rgba(255,255,255,1)",0,0,20);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(1));

	// text04_
	this.instance_6 = new lib.text05_();
	this.instance_6.setTransform(266.1,74.2,1,1,0,0,0,266.1,74.2);
	this.instance_6.shadow = new cjs.Shadow("rgba(255,255,255,1)",0,0,20);

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(1));

	// text04_
	this.instance_7 = new lib.text05_();
	this.instance_7.setTransform(266.1,74.2,1,1,0,0,0,266.1,74.2);
	this.instance_7.shadow = new cjs.Shadow("rgba(255,255,255,1)",0,0,20);

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(1));

	// text04_
	this.instance_8 = new lib.text05_();
	this.instance_8.setTransform(266.1,74.2,1,1,0,0,0,266.1,74.2);
	this.instance_8.shadow = new cjs.Shadow("rgba(255,255,255,1)",0,0,20);

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(1));

	// text04_
	this.instance_9 = new lib.text05_();
	this.instance_9.setTransform(266.1,74.2,1,1,0,0,0,266.1,74.2);
	this.instance_9.shadow = new cjs.Shadow("rgba(255,255,255,1)",0,0,20);

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(1));

	// text04_
	this.instance_10 = new lib.text05_();
	this.instance_10.setTransform(266.1,74.2,1,1,0,0,0,266.1,74.2);
	this.instance_10.shadow = new cjs.Shadow("rgba(255,255,255,1)",0,0,20);

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-21,-21,578,114);


(lib.text04_ = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.instance = new lib.container_text("single",3);
	this.instance.setTransform(500,148.4,1,1,0,0,0,500,148.4);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,532.2,68.1);


(lib.text04 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// text04_
	this.instance = new lib.text04_();
	this.instance.setTransform(266.1,74.2,1,1,0,0,0,266.1,74.2);
	this.instance.shadow = new cjs.Shadow("rgba(255,255,255,1)",0,0,20);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// text04_
	this.instance_1 = new lib.text04_();
	this.instance_1.setTransform(266.1,74.2,1,1,0,0,0,266.1,74.2);
	this.instance_1.shadow = new cjs.Shadow("rgba(255,255,255,1)",0,0,20);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	// text04_
	this.instance_2 = new lib.text04_();
	this.instance_2.setTransform(266.1,74.2,1,1,0,0,0,266.1,74.2);
	this.instance_2.shadow = new cjs.Shadow("rgba(255,255,255,1)",0,0,20);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

	// text04_
	this.instance_3 = new lib.text04_();
	this.instance_3.setTransform(266.1,74.2,1,1,0,0,0,266.1,74.2);
	this.instance_3.shadow = new cjs.Shadow("rgba(255,255,255,1)",0,0,20);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(1));

	// text04_
	this.instance_4 = new lib.text04_();
	this.instance_4.setTransform(266.1,74.2,1,1,0,0,0,266.1,74.2);
	this.instance_4.shadow = new cjs.Shadow("rgba(255,255,255,1)",0,0,20);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(1));

	// text04_
	this.instance_5 = new lib.text04_();
	this.instance_5.setTransform(266.1,74.2,1,1,0,0,0,266.1,74.2);
	this.instance_5.shadow = new cjs.Shadow("rgba(255,255,255,1)",0,0,20);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(1));

	// text04_
	this.instance_6 = new lib.text04_();
	this.instance_6.setTransform(266.1,74.2,1,1,0,0,0,266.1,74.2);
	this.instance_6.shadow = new cjs.Shadow("rgba(255,255,255,1)",0,0,20);

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(1));

	// text04_
	this.instance_7 = new lib.text04_();
	this.instance_7.setTransform(266.1,74.2,1,1,0,0,0,266.1,74.2);
	this.instance_7.shadow = new cjs.Shadow("rgba(255,255,255,1)",0,0,20);

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(1));

	// text04_
	this.instance_8 = new lib.text04_();
	this.instance_8.setTransform(266.1,74.2,1,1,0,0,0,266.1,74.2);
	this.instance_8.shadow = new cjs.Shadow("rgba(255,255,255,1)",0,0,20);

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(1));

	// text04_
	this.instance_9 = new lib.text04_();
	this.instance_9.setTransform(266.1,74.2,1,1,0,0,0,266.1,74.2);
	this.instance_9.shadow = new cjs.Shadow("rgba(255,255,255,1)",0,0,20);

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(1));

	// text04_
	this.instance_10 = new lib.text04_();
	this.instance_10.setTransform(266.1,74.2,1,1,0,0,0,266.1,74.2);
	this.instance_10.shadow = new cjs.Shadow("rgba(255,255,255,1)",0,0,20);

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-21,-21,578,114);


(lib.text03_ = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.instance = new lib.container_text("single",2);
	this.instance.setTransform(500,148.4,1,1,0,0,0,500,148.4);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,532.2,68.1);


(lib.text03 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// text03_
	this.instance = new lib.text03_();
	this.instance.setTransform(266.1,74.2,1,1,0,0,0,266.1,74.2);
	this.instance.shadow = new cjs.Shadow("rgba(255,255,255,1)",0,0,20);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// text03_
	this.instance_1 = new lib.text03_();
	this.instance_1.setTransform(266.1,74.2,1,1,0,0,0,266.1,74.2);
	this.instance_1.shadow = new cjs.Shadow("rgba(255,255,255,1)",0,0,20);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	// text03_
	this.instance_2 = new lib.text03_();
	this.instance_2.setTransform(266.1,74.2,1,1,0,0,0,266.1,74.2);
	this.instance_2.shadow = new cjs.Shadow("rgba(255,255,255,1)",0,0,20);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

	// text03_
	this.instance_3 = new lib.text03_();
	this.instance_3.setTransform(266.1,74.2,1,1,0,0,0,266.1,74.2);
	this.instance_3.shadow = new cjs.Shadow("rgba(255,255,255,1)",0,0,20);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(1));

	// text03_
	this.instance_4 = new lib.text03_();
	this.instance_4.setTransform(266.1,74.2,1,1,0,0,0,266.1,74.2);
	this.instance_4.shadow = new cjs.Shadow("rgba(255,255,255,1)",0,0,20);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(1));

	// text03_
	this.instance_5 = new lib.text03_();
	this.instance_5.setTransform(266.1,74.2,1,1,0,0,0,266.1,74.2);
	this.instance_5.shadow = new cjs.Shadow("rgba(255,255,255,1)",0,0,20);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(1));

	// text03_
	this.instance_6 = new lib.text03_();
	this.instance_6.setTransform(266.1,74.2,1,1,0,0,0,266.1,74.2);
	this.instance_6.shadow = new cjs.Shadow("rgba(255,255,255,1)",0,0,20);

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(1));

	// text03_
	this.instance_7 = new lib.text03_();
	this.instance_7.setTransform(266.1,74.2,1,1,0,0,0,266.1,74.2);
	this.instance_7.shadow = new cjs.Shadow("rgba(255,255,255,1)",0,0,20);

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(1));

	// text03_
	this.instance_8 = new lib.text03_();
	this.instance_8.setTransform(266.1,74.2,1,1,0,0,0,266.1,74.2);
	this.instance_8.shadow = new cjs.Shadow("rgba(255,255,255,1)",0,0,20);

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(1));

	// text03_
	this.instance_9 = new lib.text03_();
	this.instance_9.setTransform(266.1,74.2,1,1,0,0,0,266.1,74.2);
	this.instance_9.shadow = new cjs.Shadow("rgba(255,255,255,1)",0,0,20);

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(1));

	// text03_
	this.instance_10 = new lib.text03_();
	this.instance_10.setTransform(266.1,74.2,1,1,0,0,0,266.1,74.2);
	this.instance_10.shadow = new cjs.Shadow("rgba(255,255,255,1)",0,0,20);

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-21,-21,578,114);


(lib.text01_ = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.instance = new lib.container_text("single",0);
	this.instance.setTransform(500,148.4,1,1,0,0,0,500,148.4);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,967.4,77.2);


(lib.text01 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// text01_
	this.instance = new lib.text01_();
	this.instance.setTransform(483.7,74.2,1,1,0,0,0,483.7,74.2);
	this.instance.shadow = new cjs.Shadow("rgba(255,255,255,1)",0,0,20);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// text01_
	this.instance_1 = new lib.text01_();
	this.instance_1.setTransform(483.7,74.2,1,1,0,0,0,483.7,74.2);
	this.instance_1.shadow = new cjs.Shadow("rgba(255,255,255,1)",0,0,20);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	// text01_
	this.instance_2 = new lib.text01_();
	this.instance_2.setTransform(483.7,74.2,1,1,0,0,0,483.7,74.2);
	this.instance_2.shadow = new cjs.Shadow("rgba(255,255,255,1)",0,0,20);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

	// text01_
	this.instance_3 = new lib.text01_();
	this.instance_3.setTransform(483.7,74.2,1,1,0,0,0,483.7,74.2);
	this.instance_3.shadow = new cjs.Shadow("rgba(255,255,255,1)",0,0,20);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(1));

	// text01_
	this.instance_4 = new lib.text01_();
	this.instance_4.setTransform(483.7,74.2,1,1,0,0,0,483.7,74.2);
	this.instance_4.shadow = new cjs.Shadow("rgba(255,255,255,1)",0,0,20);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(1));

	// text01_
	this.instance_5 = new lib.text01_();
	this.instance_5.setTransform(483.7,74.2,1,1,0,0,0,483.7,74.2);
	this.instance_5.shadow = new cjs.Shadow("rgba(255,255,255,1)",0,0,20);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(1));

	// text01_
	this.instance_6 = new lib.text01_();
	this.instance_6.setTransform(483.7,74.2,1,1,0,0,0,483.7,74.2);
	this.instance_6.shadow = new cjs.Shadow("rgba(255,255,255,1)",0,0,20);

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(1));

	// text01_
	this.instance_7 = new lib.text01_();
	this.instance_7.setTransform(483.7,74.2,1,1,0,0,0,483.7,74.2);
	this.instance_7.shadow = new cjs.Shadow("rgba(255,255,255,1)",0,0,20);

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(1));

	// text01_
	this.instance_8 = new lib.text01_();
	this.instance_8.setTransform(483.7,74.2,1,1,0,0,0,483.7,74.2);
	this.instance_8.shadow = new cjs.Shadow("rgba(255,255,255,1)",0,0,20);

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(1));

	// text01_
	this.instance_9 = new lib.text01_();
	this.instance_9.setTransform(483.7,74.2,1,1,0,0,0,483.7,74.2);
	this.instance_9.shadow = new cjs.Shadow("rgba(255,255,255,1)",0,0,20);

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(1));

	// text01_
	this.instance_10 = new lib.text01_();
	this.instance_10.setTransform(483.7,74.2,1,1,0,0,0,483.7,74.2);
	this.instance_10.shadow = new cjs.Shadow("rgba(255,255,255,1)",0,0,20);

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(1));

	// text01_
	this.instance_11 = new lib.text01_();
	this.instance_11.setTransform(483.7,74.2,1,1,0,0,0,483.7,74.2);
	this.instance_11.shadow = new cjs.Shadow("rgba(255,255,255,1)",0,0,20);

	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(1));

	// text01_
	this.instance_12 = new lib.text01_();
	this.instance_12.setTransform(483.7,74.2,1,1,0,0,0,483.7,74.2);
	this.instance_12.shadow = new cjs.Shadow("rgba(255,255,255,1)",0,0,20);

	this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-21,-21,1013,123);


(lib.container_pics = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 2
	this.instance = new lib.pic_shadow_round_occlusion();
	this.instance.setTransform(923.6,203.4,0.913,0.801,0,-44.6,154.9,219,219);
	this.instance.alpha = 0.18;

	this.instance_1 = new lib.pic_shadow_round_occlusion();
	this.instance_1.setTransform(1200.1,183.2,0.913,0.801,0,-44.6,154.9,219.1,219.1);
	this.instance_1.alpha = 0.18;

	this.instance_2 = new lib.pic_shadow_round_occlusion();
	this.instance_2.setTransform(171.9,356.9,0.913,0.801,0,-44.6,154.9,219.1,219.1);
	this.instance_2.alpha = 0.18;

	this.instance_3 = new lib.pic_shadow_round_occlusion();
	this.instance_3.setTransform(20.1,468,0.913,0.801,0,-44.6,154.9,219.1,219.2);
	this.instance_3.alpha = 0.18;

	this.instance_4 = new lib.pic_shadow_round_occlusion();
	this.instance_4.setTransform(519.4,394.8,0.913,0.801,0,-44.6,154.9,219.1,219.2);
	this.instance_4.alpha = 0.18;

	this.instance_5 = new lib.pic_shadow_round_occlusion();
	this.instance_5.setTransform(326,439.1,0.913,0.801,0,-44.6,154.9,219.1,219.2);
	this.instance_5.alpha = 0.18;

	this.instance_6 = new lib.pic_shadow_round_occlusion();
	this.instance_6.setTransform(802,321.4,0.913,0.801,0,-44.6,154.9,219,219.1);
	this.instance_6.alpha = 0.18;

	this.instance_7 = new lib.pic_shadow_round_occlusion();
	this.instance_7.setTransform(883.9,299.3,0.913,0.801,0,-44.6,154.9,219,219.1);
	this.instance_7.alpha = 0.18;

	this.instance_8 = new lib.pic_shadow_round_occlusion();
	this.instance_8.setTransform(326,439.1,0.913,0.801,0,-44.6,154.9,219.1,219.2);
	this.instance_8.alpha = 0.18;

	this.instance_9 = new lib.pic_shadow_round_occlusion();
	this.instance_9.setTransform(351,328.2,0.913,0.801,0,-44.6,154.9,219.1,219.1);
	this.instance_9.alpha = 0.18;

	this.instance_10 = new lib.pic_shadow_round_occlusion();
	this.instance_10.setTransform(1040.9,225.7,0.913,0.801,0,-44.6,154.9,219,219);
	this.instance_10.alpha = 0.18;

	this.instance_11 = new lib.pic_shadow_round_occlusion();
	this.instance_11.setTransform(1067.2,161.9,0.913,0.801,0,-44.6,154.9,219.1,219.1);
	this.instance_11.alpha = 0.18;

	this.instance_12 = new lib.pic_shadow_round_occlusion();
	this.instance_12.setTransform(727.4,103,1,0.689,0,0,0,219.1,219);
	this.instance_12.alpha = 0.301;

	this.instance_13 = new lib.pic_shadow_round_occlusion();
	this.instance_13.setTransform(543.6,271.2,1,0.689,0,0,0,219.1,219.1);
	this.instance_13.alpha = 0.301;

	this.instance_14 = new lib.pic_shadow_round_occlusion();
	this.instance_14.setTransform(1175.2,78.6,1,0.689,0,0,0,219.1,219);
	this.instance_14.alpha = 0.301;

	this.instance_15 = new lib.pic_shadow_round_occlusion();
	this.instance_15.setTransform(1391.4,111.6,1,0.689,0,0,0,219.1,219);
	this.instance_15.alpha = 0.301;

	this.instance_16 = new lib.pic_shadow_round_occlusion();
	this.instance_16.setTransform(918.8,244.6,1,0.689,0,0,0,219.1,219.1);
	this.instance_16.alpha = 0.301;

	this.instance_17 = new lib.pic_shadow_round_occlusion();
	this.instance_17.setTransform(1114.9,206.3,1,0.689,0,0,0,219.1,219);
	this.instance_17.alpha = 0.301;

	this.instance_18 = new lib.pic_shadow_round_occlusion();
	this.instance_18.setTransform(625.4,293.6,1,0.689,0,0,0,219.1,219.1);
	this.instance_18.alpha = 0.301;

	this.instance_19 = new lib.pic_shadow_round_occlusion();
	this.instance_19.setTransform(838.5,166.9,1,0.689,0,0,0,219.1,219);
	this.instance_19.alpha = 0.301;

	this.instance_20 = new lib.pic_shadow_round_occlusion();
	this.instance_20.setTransform(1114.9,206.3,1,0.689,0,0,0,219.1,219);
	this.instance_20.alpha = 0.301;

	this.instance_21 = new lib.pic_shadow_round_occlusion();
	this.instance_21.setTransform(1003.7,124.3,1,0.689,0,0,0,219.1,219);
	this.instance_21.alpha = 0.301;

	this.instance_22 = new lib.pic_shadow_round_occlusion();
	this.instance_22.setTransform(648.6,166.9,1,0.689,0,0,0,219.1,219);
	this.instance_22.alpha = 0.301;

	this.instance_23 = new lib.pic_shadow_round_occlusion();
	this.instance_23.setTransform(574.7,124.3,1,0.689,0,0,0,219.1,219);
	this.instance_23.alpha = 0.301;

	this.instance_24 = new lib.pic_menu01();

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_23},{t:this.instance_22},{t:this.instance_21},{t:this.instance_20},{t:this.instance_19},{t:this.instance_18},{t:this.instance_17},{t:this.instance_16},{t:this.instance_15},{t:this.instance_14},{t:this.instance_13},{t:this.instance_12},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9,p:{scaleX:0.913,scaleY:0.801,skewX:-44.6,skewY:154.9,x:351,y:328.2,alpha:0.18}},{t:this.instance_8,p:{regY:219.2,scaleX:0.913,scaleY:0.801,skewX:-44.6,skewY:154.9,x:326,y:439.1,alpha:0.18}},{t:this.instance_7,p:{regX:219,scaleX:0.913,scaleY:0.801,skewX:-44.6,skewY:154.9,x:883.9,y:299.3,alpha:0.18}},{t:this.instance_6,p:{regX:219,scaleX:0.913,scaleY:0.801,skewX:-44.6,skewY:154.9,x:802,y:321.4,alpha:0.18}},{t:this.instance_5,p:{regY:219.2,scaleX:0.913,scaleY:0.801,skewX:-44.6,skewY:154.9,x:326,y:439.1,alpha:0.18}},{t:this.instance_4,p:{regY:219.2,scaleX:0.913,scaleY:0.801,skewX:-44.6,skewY:154.9,x:519.4,y:394.8,alpha:0.18}},{t:this.instance_3,p:{regY:219.2,scaleX:0.913,scaleY:0.801,skewX:-44.6,skewY:154.9,x:20.1,y:468,alpha:0.18}},{t:this.instance_2,p:{scaleX:0.913,scaleY:0.801,skewX:-44.6,skewY:154.9,x:171.9,y:356.9,alpha:0.18}},{t:this.instance_1,p:{scaleX:0.913,scaleY:0.801,skewX:-44.6,skewY:154.9,x:1200.1,y:183.2,alpha:0.18}},{t:this.instance,p:{regX:219,regY:219,scaleX:0.913,scaleY:0.801,skewX:-44.6,skewY:154.9,x:923.6,y:203.4,alpha:0.18}}]}).to({state:[]},1).to({state:[{t:this.instance_9,p:{scaleX:2.129,scaleY:1.867,skewX:0,skewY:0,x:1212.9,y:879.4,alpha:0.34}},{t:this.instance_8,p:{regY:219.1,scaleX:2.129,scaleY:1.867,skewX:0,skewY:0,x:1493.4,y:879.4,alpha:0.34}},{t:this.instance_7,p:{regX:219.1,scaleX:2.129,scaleY:1.867,skewX:0,skewY:0,x:1144.9,y:1036.6,alpha:0.34}},{t:this.instance_6,p:{regX:219.1,scaleX:2.129,scaleY:1.867,skewX:0,skewY:0,x:1034.4,y:1176.9,alpha:0.34}},{t:this.instance_5,p:{regY:219.1,scaleX:2.129,scaleY:1.867,skewX:0,skewY:0,x:1752.6,y:1270.4,alpha:0.34}},{t:this.instance_4,p:{regY:219.1,scaleX:2.129,scaleY:1.867,skewX:0,skewY:0,x:1846.1,y:879.4,alpha:0.34}},{t:this.instance_3,p:{regY:219.1,scaleX:2.129,scaleY:1.867,skewX:0,skewY:0,x:1463.6,y:1431.9,alpha:0.34}},{t:this.instance_2,p:{scaleX:2.129,scaleY:1.867,skewX:0,skewY:0,x:1569.9,y:1057.9,alpha:0.34}},{t:this.instance_1,p:{scaleX:2.129,scaleY:1.867,skewX:0,skewY:0,x:1752.6,y:960.2,alpha:0.34}},{t:this.instance,p:{regX:219.1,regY:219.1,scaleX:2.129,scaleY:1.867,skewX:0,skewY:0,x:1379.8,y:1288.3,alpha:0.34}}]},3).to({state:[{t:this.instance_24}]},1).wait(1));

	// Ebene 1
	this.instance_25 = new lib.c1p1_pic01();

	this.instance_26 = new lib.c1p1_pic03();

	this.instance_27 = new lib.c1p1_pic04();

	this.instance_28 = new lib.c1p1_pic05();

	this.instance_29 = new lib.pic_shadow_occlusionRound();
	this.instance_29.setTransform(60.1,426.4,1.072,0.143,0,0,0,0.1,0.4);

	this.instance_30 = new lib.pic_shadow_occlusionRound();
	this.instance_30.setTransform(845.3,481.5,1.072,0.143,0,0,0,0.1,0.4);

	this.instance_31 = new lib.pic_shadow_occlusionRound();
	this.instance_31.setTransform(365.2,542.5,1.072,0.143,0,0,0,0.1,0.4);

	this.instance_32 = new lib.pic_shadow_occlusionRound();
	this.instance_32.setTransform(314,506.1,3.523,0.47,0,0,0,0.1,0.3);
	this.instance_32.alpha = 0.5;

	this.instance_33 = new lib.pic_shadow_occlusionRound();
	this.instance_33.setTransform(228.6,398.9,3.523,0.47,0,0,0,0.1,0.3);
	this.instance_33.alpha = 0.5;

	this.instance_34 = new lib.pic_shadow_occlusionRound();
	this.instance_34.setTransform(221.8,413.2,3.523,0.47,0,0,0,0.1,0.3);
	this.instance_34.alpha = 0.5;

	this.instance_35 = new lib.pic_shadow_occlusionRound();
	this.instance_35.setTransform(249.2,428.5,3.523,0.47,0,0,0,0.1,0.3);
	this.instance_35.alpha = 0.5;

	this.instance_36 = new lib.pic_shadow_occlusionRound();
	this.instance_36.setTransform(270.2,481.1,3.523,0.47,0,0,0,0.1,0.3);
	this.instance_36.alpha = 0.5;

	this.instance_37 = new lib.pic_shadow_occlusionRound();
	this.instance_37.setTransform(249.2,458.5,3.523,0.47,0,0,0,0.1,0.3);
	this.instance_37.alpha = 0.5;

	this.instance_38 = new lib.pic_shadow_occlusionRound();
	this.instance_38.setTransform(200.4,428.5,3.523,0.47,0,0,0,0.1,0.3);
	this.instance_38.alpha = 0.5;

	this.instance_39 = new lib.pic_shadow_occlusionRound();
	this.instance_39.setTransform(139.8,428.5,3.523,0.47,0,0,0,0.1,0.3);
	this.instance_39.alpha = 0.5;

	this.instance_40 = new lib.pic_shadow_occlusionRound();
	this.instance_40.setTransform(200.4,428.5,3.523,0.47,0,0,0,0.1,0.3);
	this.instance_40.alpha = 0.5;

	this.instance_41 = new lib.pic_shadow_occlusionRound();
	this.instance_41.setTransform(162,434.2,3.523,0.47,0,0,0,0.1,0.3);
	this.instance_41.alpha = 0.5;

	this.instance_42 = new lib.pic_shadow_occlusionRound();
	this.instance_42.setTransform(200.4,481.1,3.523,0.47,0,0,0,0.1,0.3);
	this.instance_42.alpha = 0.5;

	this.instance_43 = new lib.pic_shadow_occlusionRound();
	this.instance_43.setTransform(221.8,465.7,3.523,0.47,0,0,0,0.1,0.3);
	this.instance_43.alpha = 0.5;

	this.instance_44 = new lib.pic_shadow_occlusionRound();
	this.instance_44.setTransform(448.4,518.1,3.523,0.47,0,0,0,0.1,0.3);
	this.instance_44.alpha = 0.5;

	this.instance_45 = new lib.pic_shadow_occlusionRound();
	this.instance_45.setTransform(405.2,524.5,3.523,0.47,0,0,0,0.1,0.3);
	this.instance_45.alpha = 0.5;

	this.instance_46 = new lib.pic_shadow_occlusionRound();
	this.instance_46.setTransform(382.8,492.7,3.523,0.47,0,0,0,0.1,0.3);
	this.instance_46.alpha = 0.5;

	this.instance_47 = new lib.pic_shadow_occlusionRound();
	this.instance_47.setTransform(667.3,465.7,3.523,0.47,0,0,0,0.1,0.3);
	this.instance_47.alpha = 0.5;

	this.instance_48 = new lib.pic_shadow_occlusionRound();
	this.instance_48.setTransform(362.3,524.5,3.523,0.47,0,0,0,0.1,0.3);
	this.instance_48.alpha = 0.5;

	this.instance_49 = new lib.pic_shadow_occlusionRound();
	this.instance_49.setTransform(533,481.1,3.523,0.47,0,0,0,0.1,0.3);
	this.instance_49.alpha = 0.5;

	this.instance_50 = new lib.pic_shadow_occlusionRound();
	this.instance_50.setTransform(649.1,458.5,3.523,0.47,0,0,0,0.1,0.3);
	this.instance_50.alpha = 0.5;

	this.instance_51 = new lib.pic_shadow_occlusionRound();
	this.instance_51.setTransform(593.1,481.1,3.523,0.47,0,0,0,0.1,0.3);
	this.instance_51.alpha = 0.5;

	this.instance_52 = new lib.pic_shadow_occlusionRound();
	this.instance_52.setTransform(533,506.1,3.523,0.47,0,0,0,0.1,0.3);
	this.instance_52.alpha = 0.5;

	this.instance_53 = new lib.pic_shadow_occlusionRound();
	this.instance_53.setTransform(622,481.1,3.523,0.47,0,0,0,0.1,0.3);
	this.instance_53.alpha = 0.5;

	this.instance_54 = new lib.pic_shadow_occlusionRound();
	this.instance_54.setTransform(708.3,456.7,2.004,0.267,0,0,0,0.1,0.2);
	this.instance_54.alpha = 0.5;

	this.instance_55 = new lib.pic_shadow_occlusionRound();
	this.instance_55.setTransform(845.4,481.1,2.004,0.267,0,0,0,0.1,0.2);
	this.instance_55.alpha = 0.5;

	this.instance_56 = new lib.pic_shadow_occlusionRound();
	this.instance_56.setTransform(369.7,540.7,2.004,0.267,0,0,0,0.1,0.2);
	this.instance_56.alpha = 0.5;

	this.instance_57 = new lib.pic_shadow_occlusionRound();
	this.instance_57.setTransform(249.3,456.7,2.004,0.267,0,0,0,0.1,0.2);
	this.instance_57.alpha = 0.5;

	this.instance_58 = new lib.pic_shadow_occlusionRound();
	this.instance_58.setTransform(164,397.1,2.004,0.267,0,0,0,0.1,0.2);
	this.instance_58.alpha = 0.5;

	this.instance_59 = new lib.pic_shadow_occlusionRound();
	this.instance_59.setTransform(59.1,423.7,2.004,0.267,0,0,0,0.1,0.2);
	this.instance_59.alpha = 0.5;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_25}]}).to({state:[]},1).to({state:[{t:this.instance_26}]},1).to({state:[{t:this.instance_27}]},1).to({state:[{t:this.instance_28}]},1).to({state:[{t:this.instance_59},{t:this.instance_58},{t:this.instance_57},{t:this.instance_56},{t:this.instance_55},{t:this.instance_54},{t:this.instance_53},{t:this.instance_52},{t:this.instance_51},{t:this.instance_50},{t:this.instance_49},{t:this.instance_48},{t:this.instance_47},{t:this.instance_46},{t:this.instance_45},{t:this.instance_44},{t:this.instance_43},{t:this.instance_42},{t:this.instance_41},{t:this.instance_40},{t:this.instance_39},{t:this.instance_38},{t:this.instance_37},{t:this.instance_36},{t:this.instance_35},{t:this.instance_34},{t:this.instance_33},{t:this.instance_32},{t:this.instance_31},{t:this.instance_30},{t:this.instance_29}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-284.2,-72.4,2284.3,1168.4);


(lib.button_skip = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.instance = new lib.btn_blind_rectangle();
	this.instance.setTransform(0,0,5.8,0.9);
	new cjs.ButtonHelper(this.instance, 0, 1, 2, false, new lib.btn_blind_rectangle(), 3);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Ebene 3
	this.instance_1 = new lib.container_text("single",44);
	this.instance_1.setTransform(170,430.9,1,1,0,0,0,160,420.9);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhBBnIBmhnIhmhmIAdAAIBlBmIhlBng");
	this.shape.setTransform(273.4,24.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.instance_1}]}).wait(1));

	// Ebene 4
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#D5001C").s().p("A2pDhIAAnBMAtSAAAIAAHBg");
	this.shape_1.setTransform(145,22.5);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,290,45);


(lib.button_home = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// background
	this.instance = new lib.btn_blind_rectangular();
	this.instance.setTransform(144.3,22.5,3.671,0.57,0,0,0,39.3,39.4);
	new cjs.ButtonHelper(this.instance, 0, 1, 2, false, new lib.btn_blind_rectangular(), 3);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Ebene 3
	this.instance_1 = new lib.container_text("single",41);
	this.instance_1.setTransform(169.5,26,1,1,0,0,0,119.5,16);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	// Ebene 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgtBZIgBgBIBKhYIhKhXIABgBIARAAIBLBYIhLBZg");
	this.shape.setTransform(29.7,22.9);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Ebene 4
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#D5001C").s().dr(-145,-22.5,290,45);
	this.shape_1.setTransform(145,22.5);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,290,45);


(lib.ani_text10 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_1 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_2 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_3 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_4 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_5 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_6 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_7 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_8 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_9 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_10 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_11 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_12 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_13 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_14 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_15 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_16 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_17 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_18 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_19 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_20 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_21 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_22 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_23 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_24 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_25 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_26 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_27 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_28 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_29 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_30 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_31 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_32 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_33 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_34 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_35 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_36 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_37 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_38 = new cjs.Graphics().p("AiGN0IAA7nIENAAIAAbng");
	var mask_graphics_39 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_40 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_41 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_42 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_43 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_44 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_45 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_46 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_47 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_48 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_49 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_50 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_51 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_52 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_53 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_54 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_55 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_56 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_57 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_58 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_59 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:-32.9,y:35.4}).wait(1).to({graphics:mask_graphics_1,x:-23.1,y:35.4}).wait(1).to({graphics:mask_graphics_2,x:-13.3,y:35.4}).wait(1).to({graphics:mask_graphics_3,x:-3.5,y:35.4}).wait(1).to({graphics:mask_graphics_4,x:6.3,y:35.4}).wait(1).to({graphics:mask_graphics_5,x:16.1,y:35.4}).wait(1).to({graphics:mask_graphics_6,x:25.9,y:35.4}).wait(1).to({graphics:mask_graphics_7,x:35.7,y:35.4}).wait(1).to({graphics:mask_graphics_8,x:45.5,y:35.4}).wait(1).to({graphics:mask_graphics_9,x:55.3,y:35.4}).wait(1).to({graphics:mask_graphics_10,x:65.2,y:35.4}).wait(1).to({graphics:mask_graphics_11,x:75,y:35.4}).wait(1).to({graphics:mask_graphics_12,x:84.8,y:35.4}).wait(1).to({graphics:mask_graphics_13,x:94.6,y:35.4}).wait(1).to({graphics:mask_graphics_14,x:104.4,y:35.4}).wait(1).to({graphics:mask_graphics_15,x:114.2,y:35.4}).wait(1).to({graphics:mask_graphics_16,x:124,y:35.4}).wait(1).to({graphics:mask_graphics_17,x:133.8,y:35.4}).wait(1).to({graphics:mask_graphics_18,x:143.6,y:35.4}).wait(1).to({graphics:mask_graphics_19,x:153.4,y:35.4}).wait(1).to({graphics:mask_graphics_20,x:163.2,y:35.4}).wait(1).to({graphics:mask_graphics_21,x:173,y:35.4}).wait(1).to({graphics:mask_graphics_22,x:182.8,y:35.4}).wait(1).to({graphics:mask_graphics_23,x:192.7,y:35.4}).wait(1).to({graphics:mask_graphics_24,x:202.5,y:35.4}).wait(1).to({graphics:mask_graphics_25,x:212.3,y:35.4}).wait(1).to({graphics:mask_graphics_26,x:222.1,y:35.4}).wait(1).to({graphics:mask_graphics_27,x:231.9,y:35.4}).wait(1).to({graphics:mask_graphics_28,x:241.7,y:35.4}).wait(1).to({graphics:mask_graphics_29,x:251.5,y:35.4}).wait(1).to({graphics:mask_graphics_30,x:261.3,y:35.4}).wait(1).to({graphics:mask_graphics_31,x:271.1,y:35.4}).wait(1).to({graphics:mask_graphics_32,x:280.9,y:35.4}).wait(1).to({graphics:mask_graphics_33,x:290.7,y:35.4}).wait(1).to({graphics:mask_graphics_34,x:300.5,y:35.4}).wait(1).to({graphics:mask_graphics_35,x:310.3,y:35.4}).wait(1).to({graphics:mask_graphics_36,x:320.1,y:35.4}).wait(1).to({graphics:mask_graphics_37,x:330,y:35.4}).wait(1).to({graphics:mask_graphics_38,x:339.8,y:35.4}).wait(1).to({graphics:mask_graphics_39,x:349.6,y:35.4}).wait(1).to({graphics:mask_graphics_40,x:359.4,y:35.4}).wait(1).to({graphics:mask_graphics_41,x:369.2,y:35.4}).wait(1).to({graphics:mask_graphics_42,x:379,y:35.4}).wait(1).to({graphics:mask_graphics_43,x:388.8,y:35.4}).wait(1).to({graphics:mask_graphics_44,x:398.6,y:35.4}).wait(1).to({graphics:mask_graphics_45,x:408.4,y:35.4}).wait(1).to({graphics:mask_graphics_46,x:418.2,y:35.4}).wait(1).to({graphics:mask_graphics_47,x:428,y:35.4}).wait(1).to({graphics:mask_graphics_48,x:437.8,y:35.4}).wait(1).to({graphics:mask_graphics_49,x:447.6,y:35.4}).wait(1).to({graphics:mask_graphics_50,x:457.5,y:35.4}).wait(1).to({graphics:mask_graphics_51,x:467.3,y:35.4}).wait(1).to({graphics:mask_graphics_52,x:477.1,y:35.4}).wait(1).to({graphics:mask_graphics_53,x:486.9,y:35.4}).wait(1).to({graphics:mask_graphics_54,x:496.7,y:35.4}).wait(1).to({graphics:mask_graphics_55,x:506.5,y:35.4}).wait(1).to({graphics:mask_graphics_56,x:516.3,y:35.4}).wait(1).to({graphics:mask_graphics_57,x:526.1,y:35.4}).wait(1).to({graphics:mask_graphics_58,x:535.9,y:35.4}).wait(1).to({graphics:mask_graphics_59,x:545.7,y:35.4}).wait(1).to({graphics:null,x:0,y:0}).wait(1));

	// Ebene 1
	this.instance = new lib.text10();
	this.instance.setTransform(266.1,74.2,1,1,0,0,0,266.1,74.2);

	this.instance.mask = mask;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({_off:true},60).wait(1));

	// Ebene 4 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_0 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_1_graphics_1 = new cjs.Graphics().p("Ai6N0IAA7nIF1AAIAAbng");
	var mask_1_graphics_2 = new cjs.Graphics().p("AjvN0IAA7nIHeAAIAAbng");
	var mask_1_graphics_3 = new cjs.Graphics().p("AkjN0IAA7nIJHAAIAAbng");
	var mask_1_graphics_4 = new cjs.Graphics().p("AlYN0IAA7nIKxAAIAAbng");
	var mask_1_graphics_5 = new cjs.Graphics().p("AmMN0IAA7nIMZAAIAAbng");
	var mask_1_graphics_6 = new cjs.Graphics().p("AnAN0IAA7nIOBAAIAAbng");
	var mask_1_graphics_7 = new cjs.Graphics().p("An1N0IAA7nIPrAAIAAbng");
	var mask_1_graphics_8 = new cjs.Graphics().p("AopN0IAA7nIRTAAIAAbng");
	var mask_1_graphics_9 = new cjs.Graphics().p("ApeN0IAA7nIS9AAIAAbng");
	var mask_1_graphics_10 = new cjs.Graphics().p("AqSN0IAA7nIUlAAIAAbng");
	var mask_1_graphics_11 = new cjs.Graphics().p("ArHN0IAA7nIWPAAIAAbng");
	var mask_1_graphics_12 = new cjs.Graphics().p("Ar7N0IAA7nIX3AAIAAbng");
	var mask_1_graphics_13 = new cjs.Graphics().p("AswN0IAA7nIZhAAIAAbng");
	var mask_1_graphics_14 = new cjs.Graphics().p("AtkN0IAA7nIbJAAIAAbng");
	var mask_1_graphics_15 = new cjs.Graphics().p("AuZN0IAA7nIczAAIAAbng");
	var mask_1_graphics_16 = new cjs.Graphics().p("AvNN0IAA7nIebAAIAAbng");
	var mask_1_graphics_17 = new cjs.Graphics().p("AwCN0IAA7nMAgFAAAIAAbng");
	var mask_1_graphics_18 = new cjs.Graphics().p("Aw2N0IAA7nMAhtAAAIAAbng");
	var mask_1_graphics_19 = new cjs.Graphics().p("AxqN0IAA7nMAjVAAAIAAbng");
	var mask_1_graphics_20 = new cjs.Graphics().p("AyfN0IAA7nMAk/AAAIAAbng");
	var mask_1_graphics_21 = new cjs.Graphics().p("AzTN0IAA7nMAmoAAAIAAbng");
	var mask_1_graphics_22 = new cjs.Graphics().p("A0IN0IAA7nMAoRAAAIAAbng");
	var mask_1_graphics_23 = new cjs.Graphics().p("A08N0IAA7nMAp6AAAIAAbng");
	var mask_1_graphics_24 = new cjs.Graphics().p("A1xN0IAA7nMArjAAAIAAbng");
	var mask_1_graphics_25 = new cjs.Graphics().p("A2lN0IAA7nMAtLAAAIAAbng");
	var mask_1_graphics_26 = new cjs.Graphics().p("A3aN0IAA7nMAu1AAAIAAbng");
	var mask_1_graphics_27 = new cjs.Graphics().p("A4PN0IAA7nMAwfAAAIAAbng");
	var mask_1_graphics_28 = new cjs.Graphics().p("A5DN0IAA7nMAyHAAAIAAbng");
	var mask_1_graphics_29 = new cjs.Graphics().p("A54N0IAA7nMAzwAAAIAAbng");
	var mask_1_graphics_30 = new cjs.Graphics().p("A6sN0IAA7nMA1ZAAAIAAbng");
	var mask_1_graphics_31 = new cjs.Graphics().p("A7gN0IAA7nMA3BAAAIAAbng");
	var mask_1_graphics_32 = new cjs.Graphics().p("A8VN0IAA7nMA4qAAAIAAbng");
	var mask_1_graphics_33 = new cjs.Graphics().p("A9JN0IAA7nMA6TAAAIAAbng");
	var mask_1_graphics_34 = new cjs.Graphics().p("A9+N0IAA7nMA79AAAIAAbng");
	var mask_1_graphics_35 = new cjs.Graphics().p("A+yN0IAA7nMA9lAAAIAAbng");
	var mask_1_graphics_36 = new cjs.Graphics().p("A/mN0IAA7nMA/NAAAIAAbng");
	var mask_1_graphics_37 = new cjs.Graphics().p("EggbAN0IAA7nMBA3AAAIAAbng");
	var mask_1_graphics_38 = new cjs.Graphics().p("EghPAN0IAA7nMBCgAAAIAAbng");
	var mask_1_graphics_39 = new cjs.Graphics().p("EgiEAN0IAA7nMBEJAAAIAAbng");
	var mask_1_graphics_40 = new cjs.Graphics().p("Egi4AN0IAA7nMBFxAAAIAAbng");
	var mask_1_graphics_41 = new cjs.Graphics().p("EgjtAN0IAA7nMBHbAAAIAAbng");
	var mask_1_graphics_42 = new cjs.Graphics().p("EgkhAN0IAA7nMBJDAAAIAAbng");
	var mask_1_graphics_43 = new cjs.Graphics().p("EglWAN0IAA7nMBKtAAAIAAbng");
	var mask_1_graphics_44 = new cjs.Graphics().p("EgmKAN0IAA7nMBMVAAAIAAbng");
	var mask_1_graphics_45 = new cjs.Graphics().p("Egm/AN0IAA7nMBN/AAAIAAbng");
	var mask_1_graphics_46 = new cjs.Graphics().p("EgnzAN0IAA7nMBPnAAAIAAbng");
	var mask_1_graphics_47 = new cjs.Graphics().p("EgooAN0IAA7nMBRRAAAIAAbng");
	var mask_1_graphics_48 = new cjs.Graphics().p("EgpcAN0IAA7nMBS5AAAIAAbng");
	var mask_1_graphics_49 = new cjs.Graphics().p("EgqRAN0IAA7nMBUjAAAIAAbng");
	var mask_1_graphics_50 = new cjs.Graphics().p("EgrFAN0IAA7nMBWLAAAIAAbng");
	var mask_1_graphics_51 = new cjs.Graphics().p("Egr6AN0IAA7nMBX1AAAIAAbng");
	var mask_1_graphics_52 = new cjs.Graphics().p("EgsuAN0IAA7nMBZdAAAIAAbng");
	var mask_1_graphics_53 = new cjs.Graphics().p("EgtjAN0IAA7nMBbHAAAIAAbng");
	var mask_1_graphics_54 = new cjs.Graphics().p("EguXAN0IAA7nMBcvAAAIAAbng");
	var mask_1_graphics_55 = new cjs.Graphics().p("EgvMAN0IAA7nMBeZAAAIAAbng");
	var mask_1_graphics_56 = new cjs.Graphics().p("EgwAAN0IAA7nMBgBAAAIAAbng");
	var mask_1_graphics_57 = new cjs.Graphics().p("Egw1AN0IAA7nMBhqAAAIAAbng");
	var mask_1_graphics_58 = new cjs.Graphics().p("EgxpAN0IAA7nMBjTAAAIAAbng");
	var mask_1_graphics_59 = new cjs.Graphics().p("EgyeAN0IAA7nMBk8AAAIAAbng");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:mask_1_graphics_0,x:-32.9,y:35.4}).wait(1).to({graphics:mask_1_graphics_1,x:-28.5,y:35.4}).wait(1).to({graphics:mask_1_graphics_2,x:-24.1,y:35.4}).wait(1).to({graphics:mask_1_graphics_3,x:-19.7,y:35.4}).wait(1).to({graphics:mask_1_graphics_4,x:-15.3,y:35.4}).wait(1).to({graphics:mask_1_graphics_5,x:-10.9,y:35.4}).wait(1).to({graphics:mask_1_graphics_6,x:-6.5,y:35.4}).wait(1).to({graphics:mask_1_graphics_7,x:-2.1,y:35.4}).wait(1).to({graphics:mask_1_graphics_8,x:2.3,y:35.4}).wait(1).to({graphics:mask_1_graphics_9,x:6.7,y:35.4}).wait(1).to({graphics:mask_1_graphics_10,x:11.1,y:35.4}).wait(1).to({graphics:mask_1_graphics_11,x:15.5,y:35.4}).wait(1).to({graphics:mask_1_graphics_12,x:19.9,y:35.4}).wait(1).to({graphics:mask_1_graphics_13,x:24.3,y:35.4}).wait(1).to({graphics:mask_1_graphics_14,x:28.7,y:35.4}).wait(1).to({graphics:mask_1_graphics_15,x:33.1,y:35.4}).wait(1).to({graphics:mask_1_graphics_16,x:37.5,y:35.4}).wait(1).to({graphics:mask_1_graphics_17,x:41.9,y:35.4}).wait(1).to({graphics:mask_1_graphics_18,x:46.3,y:35.4}).wait(1).to({graphics:mask_1_graphics_19,x:50.7,y:35.4}).wait(1).to({graphics:mask_1_graphics_20,x:55.1,y:35.4}).wait(1).to({graphics:mask_1_graphics_21,x:59.5,y:35.4}).wait(1).to({graphics:mask_1_graphics_22,x:63.9,y:35.4}).wait(1).to({graphics:mask_1_graphics_23,x:68.3,y:35.4}).wait(1).to({graphics:mask_1_graphics_24,x:72.7,y:35.4}).wait(1).to({graphics:mask_1_graphics_25,x:77.1,y:35.4}).wait(1).to({graphics:mask_1_graphics_26,x:81.5,y:35.4}).wait(1).to({graphics:mask_1_graphics_27,x:85.9,y:35.4}).wait(1).to({graphics:mask_1_graphics_28,x:90.3,y:35.4}).wait(1).to({graphics:mask_1_graphics_29,x:94.7,y:35.4}).wait(1).to({graphics:mask_1_graphics_30,x:99.1,y:35.4}).wait(1).to({graphics:mask_1_graphics_31,x:103.5,y:35.4}).wait(1).to({graphics:mask_1_graphics_32,x:107.9,y:35.4}).wait(1).to({graphics:mask_1_graphics_33,x:112.3,y:35.4}).wait(1).to({graphics:mask_1_graphics_34,x:116.7,y:35.4}).wait(1).to({graphics:mask_1_graphics_35,x:121.1,y:35.4}).wait(1).to({graphics:mask_1_graphics_36,x:125.5,y:35.4}).wait(1).to({graphics:mask_1_graphics_37,x:129.9,y:35.4}).wait(1).to({graphics:mask_1_graphics_38,x:134.3,y:35.4}).wait(1).to({graphics:mask_1_graphics_39,x:138.7,y:35.4}).wait(1).to({graphics:mask_1_graphics_40,x:143.1,y:35.4}).wait(1).to({graphics:mask_1_graphics_41,x:147.5,y:35.4}).wait(1).to({graphics:mask_1_graphics_42,x:151.9,y:35.4}).wait(1).to({graphics:mask_1_graphics_43,x:156.3,y:35.4}).wait(1).to({graphics:mask_1_graphics_44,x:160.7,y:35.4}).wait(1).to({graphics:mask_1_graphics_45,x:165.1,y:35.4}).wait(1).to({graphics:mask_1_graphics_46,x:169.5,y:35.4}).wait(1).to({graphics:mask_1_graphics_47,x:173.9,y:35.4}).wait(1).to({graphics:mask_1_graphics_48,x:178.3,y:35.4}).wait(1).to({graphics:mask_1_graphics_49,x:182.7,y:35.4}).wait(1).to({graphics:mask_1_graphics_50,x:187.1,y:35.4}).wait(1).to({graphics:mask_1_graphics_51,x:191.5,y:35.4}).wait(1).to({graphics:mask_1_graphics_52,x:195.9,y:35.4}).wait(1).to({graphics:mask_1_graphics_53,x:200.3,y:35.4}).wait(1).to({graphics:mask_1_graphics_54,x:204.8,y:35.4}).wait(1).to({graphics:mask_1_graphics_55,x:209.2,y:35.4}).wait(1).to({graphics:mask_1_graphics_56,x:213.6,y:35.4}).wait(1).to({graphics:mask_1_graphics_57,x:218,y:35.4}).wait(1).to({graphics:mask_1_graphics_58,x:222.4,y:35.4}).wait(1).to({graphics:mask_1_graphics_59,x:226.8,y:35.4}).wait(1).to({graphics:null,x:0,y:0}).wait(1));

	// Ebene 3
	this.instance_1 = new lib.text10();
	this.instance_1.setTransform(266.1,74.2,1,1,0,0,0,266.1,74.2);

	this.instance_1.mask = mask_1;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({alpha:0},59).to({_off:true},1).wait(1));

	// Ebene 5
	this.instance_2 = new lib.text10_();
	this.instance_2.setTransform(266.1,74.2,1,1,0,0,0,266.1,74.2);

	this.instance_2.mask = mask_1;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(61));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-21,-21,1.6,114);


(lib.ani_text09 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_1 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_2 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_3 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_4 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_5 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_6 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_7 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_8 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_9 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_10 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_11 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_12 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_13 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_14 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_15 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_16 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_17 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_18 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_19 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_20 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_21 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_22 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_23 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_24 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_25 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_26 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_27 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_28 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_29 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_30 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_31 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_32 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_33 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_34 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_35 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_36 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_37 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_38 = new cjs.Graphics().p("AiGN0IAA7nIENAAIAAbng");
	var mask_graphics_39 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_40 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_41 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_42 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_43 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_44 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_45 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_46 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_47 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_48 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_49 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_50 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_51 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_52 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_53 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_54 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_55 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_56 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_57 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_58 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_59 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:-32.9,y:35.4}).wait(1).to({graphics:mask_graphics_1,x:-23.1,y:35.4}).wait(1).to({graphics:mask_graphics_2,x:-13.3,y:35.4}).wait(1).to({graphics:mask_graphics_3,x:-3.5,y:35.4}).wait(1).to({graphics:mask_graphics_4,x:6.3,y:35.4}).wait(1).to({graphics:mask_graphics_5,x:16.1,y:35.4}).wait(1).to({graphics:mask_graphics_6,x:25.9,y:35.4}).wait(1).to({graphics:mask_graphics_7,x:35.7,y:35.4}).wait(1).to({graphics:mask_graphics_8,x:45.5,y:35.4}).wait(1).to({graphics:mask_graphics_9,x:55.3,y:35.4}).wait(1).to({graphics:mask_graphics_10,x:65.2,y:35.4}).wait(1).to({graphics:mask_graphics_11,x:75,y:35.4}).wait(1).to({graphics:mask_graphics_12,x:84.8,y:35.4}).wait(1).to({graphics:mask_graphics_13,x:94.6,y:35.4}).wait(1).to({graphics:mask_graphics_14,x:104.4,y:35.4}).wait(1).to({graphics:mask_graphics_15,x:114.2,y:35.4}).wait(1).to({graphics:mask_graphics_16,x:124,y:35.4}).wait(1).to({graphics:mask_graphics_17,x:133.8,y:35.4}).wait(1).to({graphics:mask_graphics_18,x:143.6,y:35.4}).wait(1).to({graphics:mask_graphics_19,x:153.4,y:35.4}).wait(1).to({graphics:mask_graphics_20,x:163.2,y:35.4}).wait(1).to({graphics:mask_graphics_21,x:173,y:35.4}).wait(1).to({graphics:mask_graphics_22,x:182.8,y:35.4}).wait(1).to({graphics:mask_graphics_23,x:192.7,y:35.4}).wait(1).to({graphics:mask_graphics_24,x:202.5,y:35.4}).wait(1).to({graphics:mask_graphics_25,x:212.3,y:35.4}).wait(1).to({graphics:mask_graphics_26,x:222.1,y:35.4}).wait(1).to({graphics:mask_graphics_27,x:231.9,y:35.4}).wait(1).to({graphics:mask_graphics_28,x:241.7,y:35.4}).wait(1).to({graphics:mask_graphics_29,x:251.5,y:35.4}).wait(1).to({graphics:mask_graphics_30,x:261.3,y:35.4}).wait(1).to({graphics:mask_graphics_31,x:271.1,y:35.4}).wait(1).to({graphics:mask_graphics_32,x:280.9,y:35.4}).wait(1).to({graphics:mask_graphics_33,x:290.7,y:35.4}).wait(1).to({graphics:mask_graphics_34,x:300.5,y:35.4}).wait(1).to({graphics:mask_graphics_35,x:310.3,y:35.4}).wait(1).to({graphics:mask_graphics_36,x:320.1,y:35.4}).wait(1).to({graphics:mask_graphics_37,x:330,y:35.4}).wait(1).to({graphics:mask_graphics_38,x:339.8,y:35.4}).wait(1).to({graphics:mask_graphics_39,x:349.6,y:35.4}).wait(1).to({graphics:mask_graphics_40,x:359.4,y:35.4}).wait(1).to({graphics:mask_graphics_41,x:369.2,y:35.4}).wait(1).to({graphics:mask_graphics_42,x:379,y:35.4}).wait(1).to({graphics:mask_graphics_43,x:388.8,y:35.4}).wait(1).to({graphics:mask_graphics_44,x:398.6,y:35.4}).wait(1).to({graphics:mask_graphics_45,x:408.4,y:35.4}).wait(1).to({graphics:mask_graphics_46,x:418.2,y:35.4}).wait(1).to({graphics:mask_graphics_47,x:428,y:35.4}).wait(1).to({graphics:mask_graphics_48,x:437.8,y:35.4}).wait(1).to({graphics:mask_graphics_49,x:447.6,y:35.4}).wait(1).to({graphics:mask_graphics_50,x:457.5,y:35.4}).wait(1).to({graphics:mask_graphics_51,x:467.3,y:35.4}).wait(1).to({graphics:mask_graphics_52,x:477.1,y:35.4}).wait(1).to({graphics:mask_graphics_53,x:486.9,y:35.4}).wait(1).to({graphics:mask_graphics_54,x:496.7,y:35.4}).wait(1).to({graphics:mask_graphics_55,x:506.5,y:35.4}).wait(1).to({graphics:mask_graphics_56,x:516.3,y:35.4}).wait(1).to({graphics:mask_graphics_57,x:526.1,y:35.4}).wait(1).to({graphics:mask_graphics_58,x:535.9,y:35.4}).wait(1).to({graphics:mask_graphics_59,x:545.7,y:35.4}).wait(1).to({graphics:null,x:0,y:0}).wait(1));

	// Ebene 1
	this.instance = new lib.text09();
	this.instance.setTransform(266.1,74.2,1,1,0,0,0,266.1,74.2);

	this.instance.mask = mask;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({_off:true},60).wait(1));

	// Ebene 4 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_0 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_1_graphics_1 = new cjs.Graphics().p("Ai6N0IAA7nIF1AAIAAbng");
	var mask_1_graphics_2 = new cjs.Graphics().p("AjvN0IAA7nIHeAAIAAbng");
	var mask_1_graphics_3 = new cjs.Graphics().p("AkjN0IAA7nIJHAAIAAbng");
	var mask_1_graphics_4 = new cjs.Graphics().p("AlYN0IAA7nIKxAAIAAbng");
	var mask_1_graphics_5 = new cjs.Graphics().p("AmMN0IAA7nIMZAAIAAbng");
	var mask_1_graphics_6 = new cjs.Graphics().p("AnAN0IAA7nIOBAAIAAbng");
	var mask_1_graphics_7 = new cjs.Graphics().p("An1N0IAA7nIPrAAIAAbng");
	var mask_1_graphics_8 = new cjs.Graphics().p("AopN0IAA7nIRTAAIAAbng");
	var mask_1_graphics_9 = new cjs.Graphics().p("ApeN0IAA7nIS9AAIAAbng");
	var mask_1_graphics_10 = new cjs.Graphics().p("AqSN0IAA7nIUlAAIAAbng");
	var mask_1_graphics_11 = new cjs.Graphics().p("ArHN0IAA7nIWPAAIAAbng");
	var mask_1_graphics_12 = new cjs.Graphics().p("Ar7N0IAA7nIX3AAIAAbng");
	var mask_1_graphics_13 = new cjs.Graphics().p("AswN0IAA7nIZhAAIAAbng");
	var mask_1_graphics_14 = new cjs.Graphics().p("AtkN0IAA7nIbJAAIAAbng");
	var mask_1_graphics_15 = new cjs.Graphics().p("AuZN0IAA7nIczAAIAAbng");
	var mask_1_graphics_16 = new cjs.Graphics().p("AvNN0IAA7nIebAAIAAbng");
	var mask_1_graphics_17 = new cjs.Graphics().p("AwCN0IAA7nMAgFAAAIAAbng");
	var mask_1_graphics_18 = new cjs.Graphics().p("Aw2N0IAA7nMAhtAAAIAAbng");
	var mask_1_graphics_19 = new cjs.Graphics().p("AxqN0IAA7nMAjVAAAIAAbng");
	var mask_1_graphics_20 = new cjs.Graphics().p("AyfN0IAA7nMAk/AAAIAAbng");
	var mask_1_graphics_21 = new cjs.Graphics().p("AzTN0IAA7nMAmoAAAIAAbng");
	var mask_1_graphics_22 = new cjs.Graphics().p("A0IN0IAA7nMAoRAAAIAAbng");
	var mask_1_graphics_23 = new cjs.Graphics().p("A08N0IAA7nMAp6AAAIAAbng");
	var mask_1_graphics_24 = new cjs.Graphics().p("A1xN0IAA7nMArjAAAIAAbng");
	var mask_1_graphics_25 = new cjs.Graphics().p("A2lN0IAA7nMAtLAAAIAAbng");
	var mask_1_graphics_26 = new cjs.Graphics().p("A3aN0IAA7nMAu1AAAIAAbng");
	var mask_1_graphics_27 = new cjs.Graphics().p("A4PN0IAA7nMAwfAAAIAAbng");
	var mask_1_graphics_28 = new cjs.Graphics().p("A5DN0IAA7nMAyHAAAIAAbng");
	var mask_1_graphics_29 = new cjs.Graphics().p("A54N0IAA7nMAzwAAAIAAbng");
	var mask_1_graphics_30 = new cjs.Graphics().p("A6sN0IAA7nMA1ZAAAIAAbng");
	var mask_1_graphics_31 = new cjs.Graphics().p("A7gN0IAA7nMA3BAAAIAAbng");
	var mask_1_graphics_32 = new cjs.Graphics().p("A8VN0IAA7nMA4qAAAIAAbng");
	var mask_1_graphics_33 = new cjs.Graphics().p("A9JN0IAA7nMA6TAAAIAAbng");
	var mask_1_graphics_34 = new cjs.Graphics().p("A9+N0IAA7nMA79AAAIAAbng");
	var mask_1_graphics_35 = new cjs.Graphics().p("A+yN0IAA7nMA9lAAAIAAbng");
	var mask_1_graphics_36 = new cjs.Graphics().p("A/mN0IAA7nMA/NAAAIAAbng");
	var mask_1_graphics_37 = new cjs.Graphics().p("EggbAN0IAA7nMBA3AAAIAAbng");
	var mask_1_graphics_38 = new cjs.Graphics().p("EghPAN0IAA7nMBCgAAAIAAbng");
	var mask_1_graphics_39 = new cjs.Graphics().p("EgiEAN0IAA7nMBEJAAAIAAbng");
	var mask_1_graphics_40 = new cjs.Graphics().p("Egi4AN0IAA7nMBFxAAAIAAbng");
	var mask_1_graphics_41 = new cjs.Graphics().p("EgjtAN0IAA7nMBHbAAAIAAbng");
	var mask_1_graphics_42 = new cjs.Graphics().p("EgkhAN0IAA7nMBJDAAAIAAbng");
	var mask_1_graphics_43 = new cjs.Graphics().p("EglWAN0IAA7nMBKtAAAIAAbng");
	var mask_1_graphics_44 = new cjs.Graphics().p("EgmKAN0IAA7nMBMVAAAIAAbng");
	var mask_1_graphics_45 = new cjs.Graphics().p("Egm/AN0IAA7nMBN/AAAIAAbng");
	var mask_1_graphics_46 = new cjs.Graphics().p("EgnzAN0IAA7nMBPnAAAIAAbng");
	var mask_1_graphics_47 = new cjs.Graphics().p("EgooAN0IAA7nMBRRAAAIAAbng");
	var mask_1_graphics_48 = new cjs.Graphics().p("EgpcAN0IAA7nMBS5AAAIAAbng");
	var mask_1_graphics_49 = new cjs.Graphics().p("EgqRAN0IAA7nMBUjAAAIAAbng");
	var mask_1_graphics_50 = new cjs.Graphics().p("EgrFAN0IAA7nMBWLAAAIAAbng");
	var mask_1_graphics_51 = new cjs.Graphics().p("Egr6AN0IAA7nMBX1AAAIAAbng");
	var mask_1_graphics_52 = new cjs.Graphics().p("EgsuAN0IAA7nMBZdAAAIAAbng");
	var mask_1_graphics_53 = new cjs.Graphics().p("EgtjAN0IAA7nMBbHAAAIAAbng");
	var mask_1_graphics_54 = new cjs.Graphics().p("EguXAN0IAA7nMBcvAAAIAAbng");
	var mask_1_graphics_55 = new cjs.Graphics().p("EgvMAN0IAA7nMBeZAAAIAAbng");
	var mask_1_graphics_56 = new cjs.Graphics().p("EgwAAN0IAA7nMBgBAAAIAAbng");
	var mask_1_graphics_57 = new cjs.Graphics().p("Egw1AN0IAA7nMBhqAAAIAAbng");
	var mask_1_graphics_58 = new cjs.Graphics().p("EgxpAN0IAA7nMBjTAAAIAAbng");
	var mask_1_graphics_59 = new cjs.Graphics().p("EgyeAN0IAA7nMBk8AAAIAAbng");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:mask_1_graphics_0,x:-32.9,y:35.4}).wait(1).to({graphics:mask_1_graphics_1,x:-28.5,y:35.4}).wait(1).to({graphics:mask_1_graphics_2,x:-24.1,y:35.4}).wait(1).to({graphics:mask_1_graphics_3,x:-19.7,y:35.4}).wait(1).to({graphics:mask_1_graphics_4,x:-15.3,y:35.4}).wait(1).to({graphics:mask_1_graphics_5,x:-10.9,y:35.4}).wait(1).to({graphics:mask_1_graphics_6,x:-6.5,y:35.4}).wait(1).to({graphics:mask_1_graphics_7,x:-2.1,y:35.4}).wait(1).to({graphics:mask_1_graphics_8,x:2.3,y:35.4}).wait(1).to({graphics:mask_1_graphics_9,x:6.7,y:35.4}).wait(1).to({graphics:mask_1_graphics_10,x:11.1,y:35.4}).wait(1).to({graphics:mask_1_graphics_11,x:15.5,y:35.4}).wait(1).to({graphics:mask_1_graphics_12,x:19.9,y:35.4}).wait(1).to({graphics:mask_1_graphics_13,x:24.3,y:35.4}).wait(1).to({graphics:mask_1_graphics_14,x:28.7,y:35.4}).wait(1).to({graphics:mask_1_graphics_15,x:33.1,y:35.4}).wait(1).to({graphics:mask_1_graphics_16,x:37.5,y:35.4}).wait(1).to({graphics:mask_1_graphics_17,x:41.9,y:35.4}).wait(1).to({graphics:mask_1_graphics_18,x:46.3,y:35.4}).wait(1).to({graphics:mask_1_graphics_19,x:50.7,y:35.4}).wait(1).to({graphics:mask_1_graphics_20,x:55.1,y:35.4}).wait(1).to({graphics:mask_1_graphics_21,x:59.5,y:35.4}).wait(1).to({graphics:mask_1_graphics_22,x:63.9,y:35.4}).wait(1).to({graphics:mask_1_graphics_23,x:68.3,y:35.4}).wait(1).to({graphics:mask_1_graphics_24,x:72.7,y:35.4}).wait(1).to({graphics:mask_1_graphics_25,x:77.1,y:35.4}).wait(1).to({graphics:mask_1_graphics_26,x:81.5,y:35.4}).wait(1).to({graphics:mask_1_graphics_27,x:85.9,y:35.4}).wait(1).to({graphics:mask_1_graphics_28,x:90.3,y:35.4}).wait(1).to({graphics:mask_1_graphics_29,x:94.7,y:35.4}).wait(1).to({graphics:mask_1_graphics_30,x:99.1,y:35.4}).wait(1).to({graphics:mask_1_graphics_31,x:103.5,y:35.4}).wait(1).to({graphics:mask_1_graphics_32,x:107.9,y:35.4}).wait(1).to({graphics:mask_1_graphics_33,x:112.3,y:35.4}).wait(1).to({graphics:mask_1_graphics_34,x:116.7,y:35.4}).wait(1).to({graphics:mask_1_graphics_35,x:121.1,y:35.4}).wait(1).to({graphics:mask_1_graphics_36,x:125.5,y:35.4}).wait(1).to({graphics:mask_1_graphics_37,x:129.9,y:35.4}).wait(1).to({graphics:mask_1_graphics_38,x:134.3,y:35.4}).wait(1).to({graphics:mask_1_graphics_39,x:138.7,y:35.4}).wait(1).to({graphics:mask_1_graphics_40,x:143.1,y:35.4}).wait(1).to({graphics:mask_1_graphics_41,x:147.5,y:35.4}).wait(1).to({graphics:mask_1_graphics_42,x:151.9,y:35.4}).wait(1).to({graphics:mask_1_graphics_43,x:156.3,y:35.4}).wait(1).to({graphics:mask_1_graphics_44,x:160.7,y:35.4}).wait(1).to({graphics:mask_1_graphics_45,x:165.1,y:35.4}).wait(1).to({graphics:mask_1_graphics_46,x:169.5,y:35.4}).wait(1).to({graphics:mask_1_graphics_47,x:173.9,y:35.4}).wait(1).to({graphics:mask_1_graphics_48,x:178.3,y:35.4}).wait(1).to({graphics:mask_1_graphics_49,x:182.7,y:35.4}).wait(1).to({graphics:mask_1_graphics_50,x:187.1,y:35.4}).wait(1).to({graphics:mask_1_graphics_51,x:191.5,y:35.4}).wait(1).to({graphics:mask_1_graphics_52,x:195.9,y:35.4}).wait(1).to({graphics:mask_1_graphics_53,x:200.3,y:35.4}).wait(1).to({graphics:mask_1_graphics_54,x:204.8,y:35.4}).wait(1).to({graphics:mask_1_graphics_55,x:209.2,y:35.4}).wait(1).to({graphics:mask_1_graphics_56,x:213.6,y:35.4}).wait(1).to({graphics:mask_1_graphics_57,x:218,y:35.4}).wait(1).to({graphics:mask_1_graphics_58,x:222.4,y:35.4}).wait(1).to({graphics:mask_1_graphics_59,x:226.8,y:35.4}).wait(1).to({graphics:null,x:0,y:0}).wait(1));

	// Ebene 3
	this.instance_1 = new lib.text09();
	this.instance_1.setTransform(266.1,74.2,1,1,0,0,0,266.1,74.2);

	this.instance_1.mask = mask_1;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({alpha:0},59).to({_off:true},1).wait(1));

	// Ebene 5
	this.instance_2 = new lib.text09_();
	this.instance_2.setTransform(266.1,74.2,1,1,0,0,0,266.1,74.2);

	this.instance_2.mask = mask_1;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(61));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-21,-21,1.6,114);


(lib.ani_text08 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_1 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_2 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_3 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_4 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_5 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_6 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_7 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_8 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_9 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_10 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_11 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_12 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_13 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_14 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_15 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_16 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_17 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_18 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_19 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_20 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_21 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_22 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_23 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_24 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_25 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_26 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_27 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_28 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_29 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_30 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_31 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_32 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_33 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_34 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_35 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_36 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_37 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_38 = new cjs.Graphics().p("AiGN0IAA7nIENAAIAAbng");
	var mask_graphics_39 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_40 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_41 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_42 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_43 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_44 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_45 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_46 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_47 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_48 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_49 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_50 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_51 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_52 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_53 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_54 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_55 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_56 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_57 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_58 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_59 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:-32.9,y:35.4}).wait(1).to({graphics:mask_graphics_1,x:-23.1,y:35.4}).wait(1).to({graphics:mask_graphics_2,x:-13.3,y:35.4}).wait(1).to({graphics:mask_graphics_3,x:-3.5,y:35.4}).wait(1).to({graphics:mask_graphics_4,x:6.3,y:35.4}).wait(1).to({graphics:mask_graphics_5,x:16.1,y:35.4}).wait(1).to({graphics:mask_graphics_6,x:25.9,y:35.4}).wait(1).to({graphics:mask_graphics_7,x:35.7,y:35.4}).wait(1).to({graphics:mask_graphics_8,x:45.5,y:35.4}).wait(1).to({graphics:mask_graphics_9,x:55.3,y:35.4}).wait(1).to({graphics:mask_graphics_10,x:65.2,y:35.4}).wait(1).to({graphics:mask_graphics_11,x:75,y:35.4}).wait(1).to({graphics:mask_graphics_12,x:84.8,y:35.4}).wait(1).to({graphics:mask_graphics_13,x:94.6,y:35.4}).wait(1).to({graphics:mask_graphics_14,x:104.4,y:35.4}).wait(1).to({graphics:mask_graphics_15,x:114.2,y:35.4}).wait(1).to({graphics:mask_graphics_16,x:124,y:35.4}).wait(1).to({graphics:mask_graphics_17,x:133.8,y:35.4}).wait(1).to({graphics:mask_graphics_18,x:143.6,y:35.4}).wait(1).to({graphics:mask_graphics_19,x:153.4,y:35.4}).wait(1).to({graphics:mask_graphics_20,x:163.2,y:35.4}).wait(1).to({graphics:mask_graphics_21,x:173,y:35.4}).wait(1).to({graphics:mask_graphics_22,x:182.8,y:35.4}).wait(1).to({graphics:mask_graphics_23,x:192.7,y:35.4}).wait(1).to({graphics:mask_graphics_24,x:202.5,y:35.4}).wait(1).to({graphics:mask_graphics_25,x:212.3,y:35.4}).wait(1).to({graphics:mask_graphics_26,x:222.1,y:35.4}).wait(1).to({graphics:mask_graphics_27,x:231.9,y:35.4}).wait(1).to({graphics:mask_graphics_28,x:241.7,y:35.4}).wait(1).to({graphics:mask_graphics_29,x:251.5,y:35.4}).wait(1).to({graphics:mask_graphics_30,x:261.3,y:35.4}).wait(1).to({graphics:mask_graphics_31,x:271.1,y:35.4}).wait(1).to({graphics:mask_graphics_32,x:280.9,y:35.4}).wait(1).to({graphics:mask_graphics_33,x:290.7,y:35.4}).wait(1).to({graphics:mask_graphics_34,x:300.5,y:35.4}).wait(1).to({graphics:mask_graphics_35,x:310.3,y:35.4}).wait(1).to({graphics:mask_graphics_36,x:320.1,y:35.4}).wait(1).to({graphics:mask_graphics_37,x:330,y:35.4}).wait(1).to({graphics:mask_graphics_38,x:339.8,y:35.4}).wait(1).to({graphics:mask_graphics_39,x:349.6,y:35.4}).wait(1).to({graphics:mask_graphics_40,x:359.4,y:35.4}).wait(1).to({graphics:mask_graphics_41,x:369.2,y:35.4}).wait(1).to({graphics:mask_graphics_42,x:379,y:35.4}).wait(1).to({graphics:mask_graphics_43,x:388.8,y:35.4}).wait(1).to({graphics:mask_graphics_44,x:398.6,y:35.4}).wait(1).to({graphics:mask_graphics_45,x:408.4,y:35.4}).wait(1).to({graphics:mask_graphics_46,x:418.2,y:35.4}).wait(1).to({graphics:mask_graphics_47,x:428,y:35.4}).wait(1).to({graphics:mask_graphics_48,x:437.8,y:35.4}).wait(1).to({graphics:mask_graphics_49,x:447.6,y:35.4}).wait(1).to({graphics:mask_graphics_50,x:457.5,y:35.4}).wait(1).to({graphics:mask_graphics_51,x:467.3,y:35.4}).wait(1).to({graphics:mask_graphics_52,x:477.1,y:35.4}).wait(1).to({graphics:mask_graphics_53,x:486.9,y:35.4}).wait(1).to({graphics:mask_graphics_54,x:496.7,y:35.4}).wait(1).to({graphics:mask_graphics_55,x:506.5,y:35.4}).wait(1).to({graphics:mask_graphics_56,x:516.3,y:35.4}).wait(1).to({graphics:mask_graphics_57,x:526.1,y:35.4}).wait(1).to({graphics:mask_graphics_58,x:535.9,y:35.4}).wait(1).to({graphics:mask_graphics_59,x:545.7,y:35.4}).wait(1).to({graphics:null,x:0,y:0}).wait(1));

	// Ebene 1
	this.instance = new lib.text08();
	this.instance.setTransform(266.1,74.2,1,1,0,0,0,266.1,74.2);

	this.instance.mask = mask;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({_off:true},60).wait(1));

	// Ebene 4 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_0 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_1_graphics_1 = new cjs.Graphics().p("Ai6N0IAA7nIF1AAIAAbng");
	var mask_1_graphics_2 = new cjs.Graphics().p("AjvN0IAA7nIHeAAIAAbng");
	var mask_1_graphics_3 = new cjs.Graphics().p("AkjN0IAA7nIJHAAIAAbng");
	var mask_1_graphics_4 = new cjs.Graphics().p("AlYN0IAA7nIKxAAIAAbng");
	var mask_1_graphics_5 = new cjs.Graphics().p("AmMN0IAA7nIMZAAIAAbng");
	var mask_1_graphics_6 = new cjs.Graphics().p("AnAN0IAA7nIOBAAIAAbng");
	var mask_1_graphics_7 = new cjs.Graphics().p("An1N0IAA7nIPrAAIAAbng");
	var mask_1_graphics_8 = new cjs.Graphics().p("AopN0IAA7nIRTAAIAAbng");
	var mask_1_graphics_9 = new cjs.Graphics().p("ApeN0IAA7nIS9AAIAAbng");
	var mask_1_graphics_10 = new cjs.Graphics().p("AqSN0IAA7nIUlAAIAAbng");
	var mask_1_graphics_11 = new cjs.Graphics().p("ArHN0IAA7nIWPAAIAAbng");
	var mask_1_graphics_12 = new cjs.Graphics().p("Ar7N0IAA7nIX3AAIAAbng");
	var mask_1_graphics_13 = new cjs.Graphics().p("AswN0IAA7nIZhAAIAAbng");
	var mask_1_graphics_14 = new cjs.Graphics().p("AtkN0IAA7nIbJAAIAAbng");
	var mask_1_graphics_15 = new cjs.Graphics().p("AuZN0IAA7nIczAAIAAbng");
	var mask_1_graphics_16 = new cjs.Graphics().p("AvNN0IAA7nIebAAIAAbng");
	var mask_1_graphics_17 = new cjs.Graphics().p("AwCN0IAA7nMAgFAAAIAAbng");
	var mask_1_graphics_18 = new cjs.Graphics().p("Aw2N0IAA7nMAhtAAAIAAbng");
	var mask_1_graphics_19 = new cjs.Graphics().p("AxqN0IAA7nMAjVAAAIAAbng");
	var mask_1_graphics_20 = new cjs.Graphics().p("AyfN0IAA7nMAk/AAAIAAbng");
	var mask_1_graphics_21 = new cjs.Graphics().p("AzTN0IAA7nMAmoAAAIAAbng");
	var mask_1_graphics_22 = new cjs.Graphics().p("A0IN0IAA7nMAoRAAAIAAbng");
	var mask_1_graphics_23 = new cjs.Graphics().p("A08N0IAA7nMAp6AAAIAAbng");
	var mask_1_graphics_24 = new cjs.Graphics().p("A1xN0IAA7nMArjAAAIAAbng");
	var mask_1_graphics_25 = new cjs.Graphics().p("A2lN0IAA7nMAtLAAAIAAbng");
	var mask_1_graphics_26 = new cjs.Graphics().p("A3aN0IAA7nMAu1AAAIAAbng");
	var mask_1_graphics_27 = new cjs.Graphics().p("A4PN0IAA7nMAwfAAAIAAbng");
	var mask_1_graphics_28 = new cjs.Graphics().p("A5DN0IAA7nMAyHAAAIAAbng");
	var mask_1_graphics_29 = new cjs.Graphics().p("A54N0IAA7nMAzwAAAIAAbng");
	var mask_1_graphics_30 = new cjs.Graphics().p("A6sN0IAA7nMA1ZAAAIAAbng");
	var mask_1_graphics_31 = new cjs.Graphics().p("A7gN0IAA7nMA3BAAAIAAbng");
	var mask_1_graphics_32 = new cjs.Graphics().p("A8VN0IAA7nMA4qAAAIAAbng");
	var mask_1_graphics_33 = new cjs.Graphics().p("A9JN0IAA7nMA6TAAAIAAbng");
	var mask_1_graphics_34 = new cjs.Graphics().p("A9+N0IAA7nMA79AAAIAAbng");
	var mask_1_graphics_35 = new cjs.Graphics().p("A+yN0IAA7nMA9lAAAIAAbng");
	var mask_1_graphics_36 = new cjs.Graphics().p("A/mN0IAA7nMA/NAAAIAAbng");
	var mask_1_graphics_37 = new cjs.Graphics().p("EggbAN0IAA7nMBA3AAAIAAbng");
	var mask_1_graphics_38 = new cjs.Graphics().p("EghPAN0IAA7nMBCgAAAIAAbng");
	var mask_1_graphics_39 = new cjs.Graphics().p("EgiEAN0IAA7nMBEJAAAIAAbng");
	var mask_1_graphics_40 = new cjs.Graphics().p("Egi4AN0IAA7nMBFxAAAIAAbng");
	var mask_1_graphics_41 = new cjs.Graphics().p("EgjtAN0IAA7nMBHbAAAIAAbng");
	var mask_1_graphics_42 = new cjs.Graphics().p("EgkhAN0IAA7nMBJDAAAIAAbng");
	var mask_1_graphics_43 = new cjs.Graphics().p("EglWAN0IAA7nMBKtAAAIAAbng");
	var mask_1_graphics_44 = new cjs.Graphics().p("EgmKAN0IAA7nMBMVAAAIAAbng");
	var mask_1_graphics_45 = new cjs.Graphics().p("Egm/AN0IAA7nMBN/AAAIAAbng");
	var mask_1_graphics_46 = new cjs.Graphics().p("EgnzAN0IAA7nMBPnAAAIAAbng");
	var mask_1_graphics_47 = new cjs.Graphics().p("EgooAN0IAA7nMBRRAAAIAAbng");
	var mask_1_graphics_48 = new cjs.Graphics().p("EgpcAN0IAA7nMBS5AAAIAAbng");
	var mask_1_graphics_49 = new cjs.Graphics().p("EgqRAN0IAA7nMBUjAAAIAAbng");
	var mask_1_graphics_50 = new cjs.Graphics().p("EgrFAN0IAA7nMBWLAAAIAAbng");
	var mask_1_graphics_51 = new cjs.Graphics().p("Egr6AN0IAA7nMBX1AAAIAAbng");
	var mask_1_graphics_52 = new cjs.Graphics().p("EgsuAN0IAA7nMBZdAAAIAAbng");
	var mask_1_graphics_53 = new cjs.Graphics().p("EgtjAN0IAA7nMBbHAAAIAAbng");
	var mask_1_graphics_54 = new cjs.Graphics().p("EguXAN0IAA7nMBcvAAAIAAbng");
	var mask_1_graphics_55 = new cjs.Graphics().p("EgvMAN0IAA7nMBeZAAAIAAbng");
	var mask_1_graphics_56 = new cjs.Graphics().p("EgwAAN0IAA7nMBgBAAAIAAbng");
	var mask_1_graphics_57 = new cjs.Graphics().p("Egw1AN0IAA7nMBhqAAAIAAbng");
	var mask_1_graphics_58 = new cjs.Graphics().p("EgxpAN0IAA7nMBjTAAAIAAbng");
	var mask_1_graphics_59 = new cjs.Graphics().p("EgyeAN0IAA7nMBk8AAAIAAbng");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:mask_1_graphics_0,x:-32.9,y:35.4}).wait(1).to({graphics:mask_1_graphics_1,x:-28.5,y:35.4}).wait(1).to({graphics:mask_1_graphics_2,x:-24.1,y:35.4}).wait(1).to({graphics:mask_1_graphics_3,x:-19.7,y:35.4}).wait(1).to({graphics:mask_1_graphics_4,x:-15.3,y:35.4}).wait(1).to({graphics:mask_1_graphics_5,x:-10.9,y:35.4}).wait(1).to({graphics:mask_1_graphics_6,x:-6.5,y:35.4}).wait(1).to({graphics:mask_1_graphics_7,x:-2.1,y:35.4}).wait(1).to({graphics:mask_1_graphics_8,x:2.3,y:35.4}).wait(1).to({graphics:mask_1_graphics_9,x:6.7,y:35.4}).wait(1).to({graphics:mask_1_graphics_10,x:11.1,y:35.4}).wait(1).to({graphics:mask_1_graphics_11,x:15.5,y:35.4}).wait(1).to({graphics:mask_1_graphics_12,x:19.9,y:35.4}).wait(1).to({graphics:mask_1_graphics_13,x:24.3,y:35.4}).wait(1).to({graphics:mask_1_graphics_14,x:28.7,y:35.4}).wait(1).to({graphics:mask_1_graphics_15,x:33.1,y:35.4}).wait(1).to({graphics:mask_1_graphics_16,x:37.5,y:35.4}).wait(1).to({graphics:mask_1_graphics_17,x:41.9,y:35.4}).wait(1).to({graphics:mask_1_graphics_18,x:46.3,y:35.4}).wait(1).to({graphics:mask_1_graphics_19,x:50.7,y:35.4}).wait(1).to({graphics:mask_1_graphics_20,x:55.1,y:35.4}).wait(1).to({graphics:mask_1_graphics_21,x:59.5,y:35.4}).wait(1).to({graphics:mask_1_graphics_22,x:63.9,y:35.4}).wait(1).to({graphics:mask_1_graphics_23,x:68.3,y:35.4}).wait(1).to({graphics:mask_1_graphics_24,x:72.7,y:35.4}).wait(1).to({graphics:mask_1_graphics_25,x:77.1,y:35.4}).wait(1).to({graphics:mask_1_graphics_26,x:81.5,y:35.4}).wait(1).to({graphics:mask_1_graphics_27,x:85.9,y:35.4}).wait(1).to({graphics:mask_1_graphics_28,x:90.3,y:35.4}).wait(1).to({graphics:mask_1_graphics_29,x:94.7,y:35.4}).wait(1).to({graphics:mask_1_graphics_30,x:99.1,y:35.4}).wait(1).to({graphics:mask_1_graphics_31,x:103.5,y:35.4}).wait(1).to({graphics:mask_1_graphics_32,x:107.9,y:35.4}).wait(1).to({graphics:mask_1_graphics_33,x:112.3,y:35.4}).wait(1).to({graphics:mask_1_graphics_34,x:116.7,y:35.4}).wait(1).to({graphics:mask_1_graphics_35,x:121.1,y:35.4}).wait(1).to({graphics:mask_1_graphics_36,x:125.5,y:35.4}).wait(1).to({graphics:mask_1_graphics_37,x:129.9,y:35.4}).wait(1).to({graphics:mask_1_graphics_38,x:134.3,y:35.4}).wait(1).to({graphics:mask_1_graphics_39,x:138.7,y:35.4}).wait(1).to({graphics:mask_1_graphics_40,x:143.1,y:35.4}).wait(1).to({graphics:mask_1_graphics_41,x:147.5,y:35.4}).wait(1).to({graphics:mask_1_graphics_42,x:151.9,y:35.4}).wait(1).to({graphics:mask_1_graphics_43,x:156.3,y:35.4}).wait(1).to({graphics:mask_1_graphics_44,x:160.7,y:35.4}).wait(1).to({graphics:mask_1_graphics_45,x:165.1,y:35.4}).wait(1).to({graphics:mask_1_graphics_46,x:169.5,y:35.4}).wait(1).to({graphics:mask_1_graphics_47,x:173.9,y:35.4}).wait(1).to({graphics:mask_1_graphics_48,x:178.3,y:35.4}).wait(1).to({graphics:mask_1_graphics_49,x:182.7,y:35.4}).wait(1).to({graphics:mask_1_graphics_50,x:187.1,y:35.4}).wait(1).to({graphics:mask_1_graphics_51,x:191.5,y:35.4}).wait(1).to({graphics:mask_1_graphics_52,x:195.9,y:35.4}).wait(1).to({graphics:mask_1_graphics_53,x:200.3,y:35.4}).wait(1).to({graphics:mask_1_graphics_54,x:204.8,y:35.4}).wait(1).to({graphics:mask_1_graphics_55,x:209.2,y:35.4}).wait(1).to({graphics:mask_1_graphics_56,x:213.6,y:35.4}).wait(1).to({graphics:mask_1_graphics_57,x:218,y:35.4}).wait(1).to({graphics:mask_1_graphics_58,x:222.4,y:35.4}).wait(1).to({graphics:mask_1_graphics_59,x:226.8,y:35.4}).wait(1).to({graphics:null,x:0,y:0}).wait(1));

	// Ebene 3
	this.instance_1 = new lib.text08();
	this.instance_1.setTransform(266.1,74.2,1,1,0,0,0,266.1,74.2);

	this.instance_1.mask = mask_1;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({alpha:0},59).wait(2));

	// Ebene 5
	this.instance_2 = new lib.text08_();
	this.instance_2.setTransform(266.1,74.2,1,1,0,0,0,266.1,74.2);

	this.instance_2.mask = mask_1;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(61));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-21,-21,1.6,114);


(lib.ani_text07 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_1 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_2 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_3 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_4 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_5 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_6 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_7 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_8 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_9 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_10 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_11 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_12 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_13 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_14 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_15 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_16 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_17 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_18 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_19 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_20 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_21 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_22 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_23 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_24 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_25 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_26 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_27 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_28 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_29 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_30 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_31 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_32 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_33 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_34 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_35 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_36 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_37 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_38 = new cjs.Graphics().p("AiGN0IAA7nIENAAIAAbng");
	var mask_graphics_39 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_40 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_41 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_42 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_43 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_44 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_45 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_46 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_47 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_48 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_49 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_50 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_51 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_52 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_53 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_54 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_55 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_56 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_57 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_58 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_59 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:-32.9,y:35.4}).wait(1).to({graphics:mask_graphics_1,x:-23.1,y:35.4}).wait(1).to({graphics:mask_graphics_2,x:-13.3,y:35.4}).wait(1).to({graphics:mask_graphics_3,x:-3.5,y:35.4}).wait(1).to({graphics:mask_graphics_4,x:6.3,y:35.4}).wait(1).to({graphics:mask_graphics_5,x:16.1,y:35.4}).wait(1).to({graphics:mask_graphics_6,x:25.9,y:35.4}).wait(1).to({graphics:mask_graphics_7,x:35.7,y:35.4}).wait(1).to({graphics:mask_graphics_8,x:45.5,y:35.4}).wait(1).to({graphics:mask_graphics_9,x:55.3,y:35.4}).wait(1).to({graphics:mask_graphics_10,x:65.2,y:35.4}).wait(1).to({graphics:mask_graphics_11,x:75,y:35.4}).wait(1).to({graphics:mask_graphics_12,x:84.8,y:35.4}).wait(1).to({graphics:mask_graphics_13,x:94.6,y:35.4}).wait(1).to({graphics:mask_graphics_14,x:104.4,y:35.4}).wait(1).to({graphics:mask_graphics_15,x:114.2,y:35.4}).wait(1).to({graphics:mask_graphics_16,x:124,y:35.4}).wait(1).to({graphics:mask_graphics_17,x:133.8,y:35.4}).wait(1).to({graphics:mask_graphics_18,x:143.6,y:35.4}).wait(1).to({graphics:mask_graphics_19,x:153.4,y:35.4}).wait(1).to({graphics:mask_graphics_20,x:163.2,y:35.4}).wait(1).to({graphics:mask_graphics_21,x:173,y:35.4}).wait(1).to({graphics:mask_graphics_22,x:182.8,y:35.4}).wait(1).to({graphics:mask_graphics_23,x:192.7,y:35.4}).wait(1).to({graphics:mask_graphics_24,x:202.5,y:35.4}).wait(1).to({graphics:mask_graphics_25,x:212.3,y:35.4}).wait(1).to({graphics:mask_graphics_26,x:222.1,y:35.4}).wait(1).to({graphics:mask_graphics_27,x:231.9,y:35.4}).wait(1).to({graphics:mask_graphics_28,x:241.7,y:35.4}).wait(1).to({graphics:mask_graphics_29,x:251.5,y:35.4}).wait(1).to({graphics:mask_graphics_30,x:261.3,y:35.4}).wait(1).to({graphics:mask_graphics_31,x:271.1,y:35.4}).wait(1).to({graphics:mask_graphics_32,x:280.9,y:35.4}).wait(1).to({graphics:mask_graphics_33,x:290.7,y:35.4}).wait(1).to({graphics:mask_graphics_34,x:300.5,y:35.4}).wait(1).to({graphics:mask_graphics_35,x:310.3,y:35.4}).wait(1).to({graphics:mask_graphics_36,x:320.1,y:35.4}).wait(1).to({graphics:mask_graphics_37,x:330,y:35.4}).wait(1).to({graphics:mask_graphics_38,x:339.8,y:35.4}).wait(1).to({graphics:mask_graphics_39,x:349.6,y:35.4}).wait(1).to({graphics:mask_graphics_40,x:359.4,y:35.4}).wait(1).to({graphics:mask_graphics_41,x:369.2,y:35.4}).wait(1).to({graphics:mask_graphics_42,x:379,y:35.4}).wait(1).to({graphics:mask_graphics_43,x:388.8,y:35.4}).wait(1).to({graphics:mask_graphics_44,x:398.6,y:35.4}).wait(1).to({graphics:mask_graphics_45,x:408.4,y:35.4}).wait(1).to({graphics:mask_graphics_46,x:418.2,y:35.4}).wait(1).to({graphics:mask_graphics_47,x:428,y:35.4}).wait(1).to({graphics:mask_graphics_48,x:437.8,y:35.4}).wait(1).to({graphics:mask_graphics_49,x:447.6,y:35.4}).wait(1).to({graphics:mask_graphics_50,x:457.5,y:35.4}).wait(1).to({graphics:mask_graphics_51,x:467.3,y:35.4}).wait(1).to({graphics:mask_graphics_52,x:477.1,y:35.4}).wait(1).to({graphics:mask_graphics_53,x:486.9,y:35.4}).wait(1).to({graphics:mask_graphics_54,x:496.7,y:35.4}).wait(1).to({graphics:mask_graphics_55,x:506.5,y:35.4}).wait(1).to({graphics:mask_graphics_56,x:516.3,y:35.4}).wait(1).to({graphics:mask_graphics_57,x:526.1,y:35.4}).wait(1).to({graphics:mask_graphics_58,x:535.9,y:35.4}).wait(1).to({graphics:mask_graphics_59,x:545.7,y:35.4}).wait(1).to({graphics:null,x:0,y:0}).wait(1));

	// Ebene 1
	this.instance = new lib.text07();
	this.instance.setTransform(266.1,74.2,1,1,0,0,0,266.1,74.2);

	this.instance.mask = mask;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({_off:true},60).wait(1));

	// Ebene 4 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_0 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_1_graphics_1 = new cjs.Graphics().p("Ai6N0IAA7nIF1AAIAAbng");
	var mask_1_graphics_2 = new cjs.Graphics().p("AjvN0IAA7nIHeAAIAAbng");
	var mask_1_graphics_3 = new cjs.Graphics().p("AkjN0IAA7nIJHAAIAAbng");
	var mask_1_graphics_4 = new cjs.Graphics().p("AlYN0IAA7nIKxAAIAAbng");
	var mask_1_graphics_5 = new cjs.Graphics().p("AmMN0IAA7nIMZAAIAAbng");
	var mask_1_graphics_6 = new cjs.Graphics().p("AnAN0IAA7nIOBAAIAAbng");
	var mask_1_graphics_7 = new cjs.Graphics().p("An1N0IAA7nIPrAAIAAbng");
	var mask_1_graphics_8 = new cjs.Graphics().p("AopN0IAA7nIRTAAIAAbng");
	var mask_1_graphics_9 = new cjs.Graphics().p("ApeN0IAA7nIS9AAIAAbng");
	var mask_1_graphics_10 = new cjs.Graphics().p("AqSN0IAA7nIUlAAIAAbng");
	var mask_1_graphics_11 = new cjs.Graphics().p("ArHN0IAA7nIWPAAIAAbng");
	var mask_1_graphics_12 = new cjs.Graphics().p("Ar7N0IAA7nIX3AAIAAbng");
	var mask_1_graphics_13 = new cjs.Graphics().p("AswN0IAA7nIZhAAIAAbng");
	var mask_1_graphics_14 = new cjs.Graphics().p("AtkN0IAA7nIbJAAIAAbng");
	var mask_1_graphics_15 = new cjs.Graphics().p("AuZN0IAA7nIczAAIAAbng");
	var mask_1_graphics_16 = new cjs.Graphics().p("AvNN0IAA7nIebAAIAAbng");
	var mask_1_graphics_17 = new cjs.Graphics().p("AwCN0IAA7nMAgFAAAIAAbng");
	var mask_1_graphics_18 = new cjs.Graphics().p("Aw2N0IAA7nMAhtAAAIAAbng");
	var mask_1_graphics_19 = new cjs.Graphics().p("AxqN0IAA7nMAjVAAAIAAbng");
	var mask_1_graphics_20 = new cjs.Graphics().p("AyfN0IAA7nMAk/AAAIAAbng");
	var mask_1_graphics_21 = new cjs.Graphics().p("AzTN0IAA7nMAmoAAAIAAbng");
	var mask_1_graphics_22 = new cjs.Graphics().p("A0IN0IAA7nMAoRAAAIAAbng");
	var mask_1_graphics_23 = new cjs.Graphics().p("A08N0IAA7nMAp6AAAIAAbng");
	var mask_1_graphics_24 = new cjs.Graphics().p("A1xN0IAA7nMArjAAAIAAbng");
	var mask_1_graphics_25 = new cjs.Graphics().p("A2lN0IAA7nMAtLAAAIAAbng");
	var mask_1_graphics_26 = new cjs.Graphics().p("A3aN0IAA7nMAu1AAAIAAbng");
	var mask_1_graphics_27 = new cjs.Graphics().p("A4PN0IAA7nMAwfAAAIAAbng");
	var mask_1_graphics_28 = new cjs.Graphics().p("A5DN0IAA7nMAyHAAAIAAbng");
	var mask_1_graphics_29 = new cjs.Graphics().p("A54N0IAA7nMAzwAAAIAAbng");
	var mask_1_graphics_30 = new cjs.Graphics().p("A6sN0IAA7nMA1ZAAAIAAbng");
	var mask_1_graphics_31 = new cjs.Graphics().p("A7gN0IAA7nMA3BAAAIAAbng");
	var mask_1_graphics_32 = new cjs.Graphics().p("A8VN0IAA7nMA4qAAAIAAbng");
	var mask_1_graphics_33 = new cjs.Graphics().p("A9JN0IAA7nMA6TAAAIAAbng");
	var mask_1_graphics_34 = new cjs.Graphics().p("A9+N0IAA7nMA79AAAIAAbng");
	var mask_1_graphics_35 = new cjs.Graphics().p("A+yN0IAA7nMA9lAAAIAAbng");
	var mask_1_graphics_36 = new cjs.Graphics().p("A/mN0IAA7nMA/NAAAIAAbng");
	var mask_1_graphics_37 = new cjs.Graphics().p("EggbAN0IAA7nMBA3AAAIAAbng");
	var mask_1_graphics_38 = new cjs.Graphics().p("EghPAN0IAA7nMBCgAAAIAAbng");
	var mask_1_graphics_39 = new cjs.Graphics().p("EgiEAN0IAA7nMBEJAAAIAAbng");
	var mask_1_graphics_40 = new cjs.Graphics().p("Egi4AN0IAA7nMBFxAAAIAAbng");
	var mask_1_graphics_41 = new cjs.Graphics().p("EgjtAN0IAA7nMBHbAAAIAAbng");
	var mask_1_graphics_42 = new cjs.Graphics().p("EgkhAN0IAA7nMBJDAAAIAAbng");
	var mask_1_graphics_43 = new cjs.Graphics().p("EglWAN0IAA7nMBKtAAAIAAbng");
	var mask_1_graphics_44 = new cjs.Graphics().p("EgmKAN0IAA7nMBMVAAAIAAbng");
	var mask_1_graphics_45 = new cjs.Graphics().p("Egm/AN0IAA7nMBN/AAAIAAbng");
	var mask_1_graphics_46 = new cjs.Graphics().p("EgnzAN0IAA7nMBPnAAAIAAbng");
	var mask_1_graphics_47 = new cjs.Graphics().p("EgooAN0IAA7nMBRRAAAIAAbng");
	var mask_1_graphics_48 = new cjs.Graphics().p("EgpcAN0IAA7nMBS5AAAIAAbng");
	var mask_1_graphics_49 = new cjs.Graphics().p("EgqRAN0IAA7nMBUjAAAIAAbng");
	var mask_1_graphics_50 = new cjs.Graphics().p("EgrFAN0IAA7nMBWLAAAIAAbng");
	var mask_1_graphics_51 = new cjs.Graphics().p("Egr6AN0IAA7nMBX1AAAIAAbng");
	var mask_1_graphics_52 = new cjs.Graphics().p("EgsuAN0IAA7nMBZdAAAIAAbng");
	var mask_1_graphics_53 = new cjs.Graphics().p("EgtjAN0IAA7nMBbHAAAIAAbng");
	var mask_1_graphics_54 = new cjs.Graphics().p("EguXAN0IAA7nMBcvAAAIAAbng");
	var mask_1_graphics_55 = new cjs.Graphics().p("EgvMAN0IAA7nMBeZAAAIAAbng");
	var mask_1_graphics_56 = new cjs.Graphics().p("EgwAAN0IAA7nMBgBAAAIAAbng");
	var mask_1_graphics_57 = new cjs.Graphics().p("Egw1AN0IAA7nMBhqAAAIAAbng");
	var mask_1_graphics_58 = new cjs.Graphics().p("EgxpAN0IAA7nMBjTAAAIAAbng");
	var mask_1_graphics_59 = new cjs.Graphics().p("EgyeAN0IAA7nMBk8AAAIAAbng");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:mask_1_graphics_0,x:-32.9,y:35.4}).wait(1).to({graphics:mask_1_graphics_1,x:-28.5,y:35.4}).wait(1).to({graphics:mask_1_graphics_2,x:-24.1,y:35.4}).wait(1).to({graphics:mask_1_graphics_3,x:-19.7,y:35.4}).wait(1).to({graphics:mask_1_graphics_4,x:-15.3,y:35.4}).wait(1).to({graphics:mask_1_graphics_5,x:-10.9,y:35.4}).wait(1).to({graphics:mask_1_graphics_6,x:-6.5,y:35.4}).wait(1).to({graphics:mask_1_graphics_7,x:-2.1,y:35.4}).wait(1).to({graphics:mask_1_graphics_8,x:2.3,y:35.4}).wait(1).to({graphics:mask_1_graphics_9,x:6.7,y:35.4}).wait(1).to({graphics:mask_1_graphics_10,x:11.1,y:35.4}).wait(1).to({graphics:mask_1_graphics_11,x:15.5,y:35.4}).wait(1).to({graphics:mask_1_graphics_12,x:19.9,y:35.4}).wait(1).to({graphics:mask_1_graphics_13,x:24.3,y:35.4}).wait(1).to({graphics:mask_1_graphics_14,x:28.7,y:35.4}).wait(1).to({graphics:mask_1_graphics_15,x:33.1,y:35.4}).wait(1).to({graphics:mask_1_graphics_16,x:37.5,y:35.4}).wait(1).to({graphics:mask_1_graphics_17,x:41.9,y:35.4}).wait(1).to({graphics:mask_1_graphics_18,x:46.3,y:35.4}).wait(1).to({graphics:mask_1_graphics_19,x:50.7,y:35.4}).wait(1).to({graphics:mask_1_graphics_20,x:55.1,y:35.4}).wait(1).to({graphics:mask_1_graphics_21,x:59.5,y:35.4}).wait(1).to({graphics:mask_1_graphics_22,x:63.9,y:35.4}).wait(1).to({graphics:mask_1_graphics_23,x:68.3,y:35.4}).wait(1).to({graphics:mask_1_graphics_24,x:72.7,y:35.4}).wait(1).to({graphics:mask_1_graphics_25,x:77.1,y:35.4}).wait(1).to({graphics:mask_1_graphics_26,x:81.5,y:35.4}).wait(1).to({graphics:mask_1_graphics_27,x:85.9,y:35.4}).wait(1).to({graphics:mask_1_graphics_28,x:90.3,y:35.4}).wait(1).to({graphics:mask_1_graphics_29,x:94.7,y:35.4}).wait(1).to({graphics:mask_1_graphics_30,x:99.1,y:35.4}).wait(1).to({graphics:mask_1_graphics_31,x:103.5,y:35.4}).wait(1).to({graphics:mask_1_graphics_32,x:107.9,y:35.4}).wait(1).to({graphics:mask_1_graphics_33,x:112.3,y:35.4}).wait(1).to({graphics:mask_1_graphics_34,x:116.7,y:35.4}).wait(1).to({graphics:mask_1_graphics_35,x:121.1,y:35.4}).wait(1).to({graphics:mask_1_graphics_36,x:125.5,y:35.4}).wait(1).to({graphics:mask_1_graphics_37,x:129.9,y:35.4}).wait(1).to({graphics:mask_1_graphics_38,x:134.3,y:35.4}).wait(1).to({graphics:mask_1_graphics_39,x:138.7,y:35.4}).wait(1).to({graphics:mask_1_graphics_40,x:143.1,y:35.4}).wait(1).to({graphics:mask_1_graphics_41,x:147.5,y:35.4}).wait(1).to({graphics:mask_1_graphics_42,x:151.9,y:35.4}).wait(1).to({graphics:mask_1_graphics_43,x:156.3,y:35.4}).wait(1).to({graphics:mask_1_graphics_44,x:160.7,y:35.4}).wait(1).to({graphics:mask_1_graphics_45,x:165.1,y:35.4}).wait(1).to({graphics:mask_1_graphics_46,x:169.5,y:35.4}).wait(1).to({graphics:mask_1_graphics_47,x:173.9,y:35.4}).wait(1).to({graphics:mask_1_graphics_48,x:178.3,y:35.4}).wait(1).to({graphics:mask_1_graphics_49,x:182.7,y:35.4}).wait(1).to({graphics:mask_1_graphics_50,x:187.1,y:35.4}).wait(1).to({graphics:mask_1_graphics_51,x:191.5,y:35.4}).wait(1).to({graphics:mask_1_graphics_52,x:195.9,y:35.4}).wait(1).to({graphics:mask_1_graphics_53,x:200.3,y:35.4}).wait(1).to({graphics:mask_1_graphics_54,x:204.8,y:35.4}).wait(1).to({graphics:mask_1_graphics_55,x:209.2,y:35.4}).wait(1).to({graphics:mask_1_graphics_56,x:213.6,y:35.4}).wait(1).to({graphics:mask_1_graphics_57,x:218,y:35.4}).wait(1).to({graphics:mask_1_graphics_58,x:222.4,y:35.4}).wait(1).to({graphics:mask_1_graphics_59,x:226.8,y:35.4}).wait(1).to({graphics:null,x:0,y:0}).wait(1));

	// Ebene 3
	this.instance_1 = new lib.text07();
	this.instance_1.setTransform(266.1,74.2,1,1,0,0,0,266.1,74.2);

	this.instance_1.mask = mask_1;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({alpha:0},59).wait(2));

	// Ebene 5
	this.instance_2 = new lib.text07_();
	this.instance_2.setTransform(266.1,74.2,1,1,0,0,0,266.1,74.2);

	this.instance_2.mask = mask_1;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(61));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-21,-21,1.6,114);


(lib.ani_text06 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_1 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_2 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_3 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_4 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_5 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_6 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_7 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_8 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_9 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_10 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_11 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_12 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_13 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_14 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_15 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_16 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_17 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_18 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_19 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_20 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_21 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_22 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_23 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_24 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_25 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_26 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_27 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_28 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_29 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_30 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_31 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_32 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_33 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_34 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_35 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_36 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_37 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_38 = new cjs.Graphics().p("AiGN0IAA7nIENAAIAAbng");
	var mask_graphics_39 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_40 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_41 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_42 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_43 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_44 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_45 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_46 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_47 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_48 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_49 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_50 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_51 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_52 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_53 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_54 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_55 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_56 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_57 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_58 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_59 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:-32.9,y:35.4}).wait(1).to({graphics:mask_graphics_1,x:-23.1,y:35.4}).wait(1).to({graphics:mask_graphics_2,x:-13.3,y:35.4}).wait(1).to({graphics:mask_graphics_3,x:-3.5,y:35.4}).wait(1).to({graphics:mask_graphics_4,x:6.3,y:35.4}).wait(1).to({graphics:mask_graphics_5,x:16.1,y:35.4}).wait(1).to({graphics:mask_graphics_6,x:25.9,y:35.4}).wait(1).to({graphics:mask_graphics_7,x:35.7,y:35.4}).wait(1).to({graphics:mask_graphics_8,x:45.5,y:35.4}).wait(1).to({graphics:mask_graphics_9,x:55.3,y:35.4}).wait(1).to({graphics:mask_graphics_10,x:65.2,y:35.4}).wait(1).to({graphics:mask_graphics_11,x:75,y:35.4}).wait(1).to({graphics:mask_graphics_12,x:84.8,y:35.4}).wait(1).to({graphics:mask_graphics_13,x:94.6,y:35.4}).wait(1).to({graphics:mask_graphics_14,x:104.4,y:35.4}).wait(1).to({graphics:mask_graphics_15,x:114.2,y:35.4}).wait(1).to({graphics:mask_graphics_16,x:124,y:35.4}).wait(1).to({graphics:mask_graphics_17,x:133.8,y:35.4}).wait(1).to({graphics:mask_graphics_18,x:143.6,y:35.4}).wait(1).to({graphics:mask_graphics_19,x:153.4,y:35.4}).wait(1).to({graphics:mask_graphics_20,x:163.2,y:35.4}).wait(1).to({graphics:mask_graphics_21,x:173,y:35.4}).wait(1).to({graphics:mask_graphics_22,x:182.8,y:35.4}).wait(1).to({graphics:mask_graphics_23,x:192.7,y:35.4}).wait(1).to({graphics:mask_graphics_24,x:202.5,y:35.4}).wait(1).to({graphics:mask_graphics_25,x:212.3,y:35.4}).wait(1).to({graphics:mask_graphics_26,x:222.1,y:35.4}).wait(1).to({graphics:mask_graphics_27,x:231.9,y:35.4}).wait(1).to({graphics:mask_graphics_28,x:241.7,y:35.4}).wait(1).to({graphics:mask_graphics_29,x:251.5,y:35.4}).wait(1).to({graphics:mask_graphics_30,x:261.3,y:35.4}).wait(1).to({graphics:mask_graphics_31,x:271.1,y:35.4}).wait(1).to({graphics:mask_graphics_32,x:280.9,y:35.4}).wait(1).to({graphics:mask_graphics_33,x:290.7,y:35.4}).wait(1).to({graphics:mask_graphics_34,x:300.5,y:35.4}).wait(1).to({graphics:mask_graphics_35,x:310.3,y:35.4}).wait(1).to({graphics:mask_graphics_36,x:320.1,y:35.4}).wait(1).to({graphics:mask_graphics_37,x:330,y:35.4}).wait(1).to({graphics:mask_graphics_38,x:339.8,y:35.4}).wait(1).to({graphics:mask_graphics_39,x:349.6,y:35.4}).wait(1).to({graphics:mask_graphics_40,x:359.4,y:35.4}).wait(1).to({graphics:mask_graphics_41,x:369.2,y:35.4}).wait(1).to({graphics:mask_graphics_42,x:379,y:35.4}).wait(1).to({graphics:mask_graphics_43,x:388.8,y:35.4}).wait(1).to({graphics:mask_graphics_44,x:398.6,y:35.4}).wait(1).to({graphics:mask_graphics_45,x:408.4,y:35.4}).wait(1).to({graphics:mask_graphics_46,x:418.2,y:35.4}).wait(1).to({graphics:mask_graphics_47,x:428,y:35.4}).wait(1).to({graphics:mask_graphics_48,x:437.8,y:35.4}).wait(1).to({graphics:mask_graphics_49,x:447.6,y:35.4}).wait(1).to({graphics:mask_graphics_50,x:457.5,y:35.4}).wait(1).to({graphics:mask_graphics_51,x:467.3,y:35.4}).wait(1).to({graphics:mask_graphics_52,x:477.1,y:35.4}).wait(1).to({graphics:mask_graphics_53,x:486.9,y:35.4}).wait(1).to({graphics:mask_graphics_54,x:496.7,y:35.4}).wait(1).to({graphics:mask_graphics_55,x:506.5,y:35.4}).wait(1).to({graphics:mask_graphics_56,x:516.3,y:35.4}).wait(1).to({graphics:mask_graphics_57,x:526.1,y:35.4}).wait(1).to({graphics:mask_graphics_58,x:535.9,y:35.4}).wait(1).to({graphics:mask_graphics_59,x:545.7,y:35.4}).wait(1).to({graphics:null,x:0,y:0}).wait(1));

	// Ebene 1
	this.instance = new lib.text06();
	this.instance.setTransform(266.1,74.2,1,1,0,0,0,266.1,74.2);

	this.instance.mask = mask;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({_off:true},60).wait(1));

	// Ebene 4 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_0 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_1_graphics_1 = new cjs.Graphics().p("Ai6N0IAA7nIF1AAIAAbng");
	var mask_1_graphics_2 = new cjs.Graphics().p("AjvN0IAA7nIHeAAIAAbng");
	var mask_1_graphics_3 = new cjs.Graphics().p("AkjN0IAA7nIJHAAIAAbng");
	var mask_1_graphics_4 = new cjs.Graphics().p("AlYN0IAA7nIKxAAIAAbng");
	var mask_1_graphics_5 = new cjs.Graphics().p("AmMN0IAA7nIMZAAIAAbng");
	var mask_1_graphics_6 = new cjs.Graphics().p("AnAN0IAA7nIOBAAIAAbng");
	var mask_1_graphics_7 = new cjs.Graphics().p("An1N0IAA7nIPrAAIAAbng");
	var mask_1_graphics_8 = new cjs.Graphics().p("AopN0IAA7nIRTAAIAAbng");
	var mask_1_graphics_9 = new cjs.Graphics().p("ApeN0IAA7nIS9AAIAAbng");
	var mask_1_graphics_10 = new cjs.Graphics().p("AqSN0IAA7nIUlAAIAAbng");
	var mask_1_graphics_11 = new cjs.Graphics().p("ArHN0IAA7nIWPAAIAAbng");
	var mask_1_graphics_12 = new cjs.Graphics().p("Ar7N0IAA7nIX3AAIAAbng");
	var mask_1_graphics_13 = new cjs.Graphics().p("AswN0IAA7nIZhAAIAAbng");
	var mask_1_graphics_14 = new cjs.Graphics().p("AtkN0IAA7nIbJAAIAAbng");
	var mask_1_graphics_15 = new cjs.Graphics().p("AuZN0IAA7nIczAAIAAbng");
	var mask_1_graphics_16 = new cjs.Graphics().p("AvNN0IAA7nIebAAIAAbng");
	var mask_1_graphics_17 = new cjs.Graphics().p("AwCN0IAA7nMAgFAAAIAAbng");
	var mask_1_graphics_18 = new cjs.Graphics().p("Aw2N0IAA7nMAhtAAAIAAbng");
	var mask_1_graphics_19 = new cjs.Graphics().p("AxqN0IAA7nMAjVAAAIAAbng");
	var mask_1_graphics_20 = new cjs.Graphics().p("AyfN0IAA7nMAk/AAAIAAbng");
	var mask_1_graphics_21 = new cjs.Graphics().p("AzTN0IAA7nMAmoAAAIAAbng");
	var mask_1_graphics_22 = new cjs.Graphics().p("A0IN0IAA7nMAoRAAAIAAbng");
	var mask_1_graphics_23 = new cjs.Graphics().p("A08N0IAA7nMAp6AAAIAAbng");
	var mask_1_graphics_24 = new cjs.Graphics().p("A1xN0IAA7nMArjAAAIAAbng");
	var mask_1_graphics_25 = new cjs.Graphics().p("A2lN0IAA7nMAtLAAAIAAbng");
	var mask_1_graphics_26 = new cjs.Graphics().p("A3aN0IAA7nMAu1AAAIAAbng");
	var mask_1_graphics_27 = new cjs.Graphics().p("A4PN0IAA7nMAwfAAAIAAbng");
	var mask_1_graphics_28 = new cjs.Graphics().p("A5DN0IAA7nMAyHAAAIAAbng");
	var mask_1_graphics_29 = new cjs.Graphics().p("A54N0IAA7nMAzwAAAIAAbng");
	var mask_1_graphics_30 = new cjs.Graphics().p("A6sN0IAA7nMA1ZAAAIAAbng");
	var mask_1_graphics_31 = new cjs.Graphics().p("A7gN0IAA7nMA3BAAAIAAbng");
	var mask_1_graphics_32 = new cjs.Graphics().p("A8VN0IAA7nMA4qAAAIAAbng");
	var mask_1_graphics_33 = new cjs.Graphics().p("A9JN0IAA7nMA6TAAAIAAbng");
	var mask_1_graphics_34 = new cjs.Graphics().p("A9+N0IAA7nMA79AAAIAAbng");
	var mask_1_graphics_35 = new cjs.Graphics().p("A+yN0IAA7nMA9lAAAIAAbng");
	var mask_1_graphics_36 = new cjs.Graphics().p("A/mN0IAA7nMA/NAAAIAAbng");
	var mask_1_graphics_37 = new cjs.Graphics().p("EggbAN0IAA7nMBA3AAAIAAbng");
	var mask_1_graphics_38 = new cjs.Graphics().p("EghPAN0IAA7nMBCgAAAIAAbng");
	var mask_1_graphics_39 = new cjs.Graphics().p("EgiEAN0IAA7nMBEJAAAIAAbng");
	var mask_1_graphics_40 = new cjs.Graphics().p("Egi4AN0IAA7nMBFxAAAIAAbng");
	var mask_1_graphics_41 = new cjs.Graphics().p("EgjtAN0IAA7nMBHbAAAIAAbng");
	var mask_1_graphics_42 = new cjs.Graphics().p("EgkhAN0IAA7nMBJDAAAIAAbng");
	var mask_1_graphics_43 = new cjs.Graphics().p("EglWAN0IAA7nMBKtAAAIAAbng");
	var mask_1_graphics_44 = new cjs.Graphics().p("EgmKAN0IAA7nMBMVAAAIAAbng");
	var mask_1_graphics_45 = new cjs.Graphics().p("Egm/AN0IAA7nMBN/AAAIAAbng");
	var mask_1_graphics_46 = new cjs.Graphics().p("EgnzAN0IAA7nMBPnAAAIAAbng");
	var mask_1_graphics_47 = new cjs.Graphics().p("EgooAN0IAA7nMBRRAAAIAAbng");
	var mask_1_graphics_48 = new cjs.Graphics().p("EgpcAN0IAA7nMBS5AAAIAAbng");
	var mask_1_graphics_49 = new cjs.Graphics().p("EgqRAN0IAA7nMBUjAAAIAAbng");
	var mask_1_graphics_50 = new cjs.Graphics().p("EgrFAN0IAA7nMBWLAAAIAAbng");
	var mask_1_graphics_51 = new cjs.Graphics().p("Egr6AN0IAA7nMBX1AAAIAAbng");
	var mask_1_graphics_52 = new cjs.Graphics().p("EgsuAN0IAA7nMBZdAAAIAAbng");
	var mask_1_graphics_53 = new cjs.Graphics().p("EgtjAN0IAA7nMBbHAAAIAAbng");
	var mask_1_graphics_54 = new cjs.Graphics().p("EguXAN0IAA7nMBcvAAAIAAbng");
	var mask_1_graphics_55 = new cjs.Graphics().p("EgvMAN0IAA7nMBeZAAAIAAbng");
	var mask_1_graphics_56 = new cjs.Graphics().p("EgwAAN0IAA7nMBgBAAAIAAbng");
	var mask_1_graphics_57 = new cjs.Graphics().p("Egw1AN0IAA7nMBhqAAAIAAbng");
	var mask_1_graphics_58 = new cjs.Graphics().p("EgxpAN0IAA7nMBjTAAAIAAbng");
	var mask_1_graphics_59 = new cjs.Graphics().p("EgyeAN0IAA7nMBk8AAAIAAbng");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:mask_1_graphics_0,x:-32.9,y:35.4}).wait(1).to({graphics:mask_1_graphics_1,x:-28.5,y:35.4}).wait(1).to({graphics:mask_1_graphics_2,x:-24.1,y:35.4}).wait(1).to({graphics:mask_1_graphics_3,x:-19.7,y:35.4}).wait(1).to({graphics:mask_1_graphics_4,x:-15.3,y:35.4}).wait(1).to({graphics:mask_1_graphics_5,x:-10.9,y:35.4}).wait(1).to({graphics:mask_1_graphics_6,x:-6.5,y:35.4}).wait(1).to({graphics:mask_1_graphics_7,x:-2.1,y:35.4}).wait(1).to({graphics:mask_1_graphics_8,x:2.3,y:35.4}).wait(1).to({graphics:mask_1_graphics_9,x:6.7,y:35.4}).wait(1).to({graphics:mask_1_graphics_10,x:11.1,y:35.4}).wait(1).to({graphics:mask_1_graphics_11,x:15.5,y:35.4}).wait(1).to({graphics:mask_1_graphics_12,x:19.9,y:35.4}).wait(1).to({graphics:mask_1_graphics_13,x:24.3,y:35.4}).wait(1).to({graphics:mask_1_graphics_14,x:28.7,y:35.4}).wait(1).to({graphics:mask_1_graphics_15,x:33.1,y:35.4}).wait(1).to({graphics:mask_1_graphics_16,x:37.5,y:35.4}).wait(1).to({graphics:mask_1_graphics_17,x:41.9,y:35.4}).wait(1).to({graphics:mask_1_graphics_18,x:46.3,y:35.4}).wait(1).to({graphics:mask_1_graphics_19,x:50.7,y:35.4}).wait(1).to({graphics:mask_1_graphics_20,x:55.1,y:35.4}).wait(1).to({graphics:mask_1_graphics_21,x:59.5,y:35.4}).wait(1).to({graphics:mask_1_graphics_22,x:63.9,y:35.4}).wait(1).to({graphics:mask_1_graphics_23,x:68.3,y:35.4}).wait(1).to({graphics:mask_1_graphics_24,x:72.7,y:35.4}).wait(1).to({graphics:mask_1_graphics_25,x:77.1,y:35.4}).wait(1).to({graphics:mask_1_graphics_26,x:81.5,y:35.4}).wait(1).to({graphics:mask_1_graphics_27,x:85.9,y:35.4}).wait(1).to({graphics:mask_1_graphics_28,x:90.3,y:35.4}).wait(1).to({graphics:mask_1_graphics_29,x:94.7,y:35.4}).wait(1).to({graphics:mask_1_graphics_30,x:99.1,y:35.4}).wait(1).to({graphics:mask_1_graphics_31,x:103.5,y:35.4}).wait(1).to({graphics:mask_1_graphics_32,x:107.9,y:35.4}).wait(1).to({graphics:mask_1_graphics_33,x:112.3,y:35.4}).wait(1).to({graphics:mask_1_graphics_34,x:116.7,y:35.4}).wait(1).to({graphics:mask_1_graphics_35,x:121.1,y:35.4}).wait(1).to({graphics:mask_1_graphics_36,x:125.5,y:35.4}).wait(1).to({graphics:mask_1_graphics_37,x:129.9,y:35.4}).wait(1).to({graphics:mask_1_graphics_38,x:134.3,y:35.4}).wait(1).to({graphics:mask_1_graphics_39,x:138.7,y:35.4}).wait(1).to({graphics:mask_1_graphics_40,x:143.1,y:35.4}).wait(1).to({graphics:mask_1_graphics_41,x:147.5,y:35.4}).wait(1).to({graphics:mask_1_graphics_42,x:151.9,y:35.4}).wait(1).to({graphics:mask_1_graphics_43,x:156.3,y:35.4}).wait(1).to({graphics:mask_1_graphics_44,x:160.7,y:35.4}).wait(1).to({graphics:mask_1_graphics_45,x:165.1,y:35.4}).wait(1).to({graphics:mask_1_graphics_46,x:169.5,y:35.4}).wait(1).to({graphics:mask_1_graphics_47,x:173.9,y:35.4}).wait(1).to({graphics:mask_1_graphics_48,x:178.3,y:35.4}).wait(1).to({graphics:mask_1_graphics_49,x:182.7,y:35.4}).wait(1).to({graphics:mask_1_graphics_50,x:187.1,y:35.4}).wait(1).to({graphics:mask_1_graphics_51,x:191.5,y:35.4}).wait(1).to({graphics:mask_1_graphics_52,x:195.9,y:35.4}).wait(1).to({graphics:mask_1_graphics_53,x:200.3,y:35.4}).wait(1).to({graphics:mask_1_graphics_54,x:204.8,y:35.4}).wait(1).to({graphics:mask_1_graphics_55,x:209.2,y:35.4}).wait(1).to({graphics:mask_1_graphics_56,x:213.6,y:35.4}).wait(1).to({graphics:mask_1_graphics_57,x:218,y:35.4}).wait(1).to({graphics:mask_1_graphics_58,x:222.4,y:35.4}).wait(1).to({graphics:mask_1_graphics_59,x:226.8,y:35.4}).wait(1).to({graphics:null,x:0,y:0}).wait(1));

	// Ebene 3
	this.instance_1 = new lib.text06();
	this.instance_1.setTransform(266.1,74.2,1,1,0,0,0,266.1,74.2);

	this.instance_1.mask = mask_1;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({alpha:0},59).to({_off:true},1).wait(1));

	// Ebene 5
	this.instance_2 = new lib.text06_();
	this.instance_2.setTransform(266.1,74.2,1,1,0,0,0,266.1,74.2);

	this.instance_2.mask = mask_1;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(61));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-21,-21,1.6,114);


(lib.ani_text05 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_1 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_2 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_3 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_4 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_5 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_6 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_7 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_8 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_9 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_10 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_11 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_12 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_13 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_14 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_15 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_16 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_17 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_18 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_19 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_20 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_21 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_22 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_23 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_24 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_25 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_26 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_27 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_28 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_29 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_30 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_31 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_32 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_33 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_34 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_35 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_36 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_37 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_38 = new cjs.Graphics().p("AiGN0IAA7nIENAAIAAbng");
	var mask_graphics_39 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_40 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_41 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_42 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_43 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_44 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_45 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_46 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_47 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_48 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_49 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_50 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_51 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_52 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_53 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_54 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_55 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_56 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_57 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_58 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_59 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:-32.9,y:35.4}).wait(1).to({graphics:mask_graphics_1,x:-23.1,y:35.4}).wait(1).to({graphics:mask_graphics_2,x:-13.3,y:35.4}).wait(1).to({graphics:mask_graphics_3,x:-3.5,y:35.4}).wait(1).to({graphics:mask_graphics_4,x:6.3,y:35.4}).wait(1).to({graphics:mask_graphics_5,x:16.1,y:35.4}).wait(1).to({graphics:mask_graphics_6,x:25.9,y:35.4}).wait(1).to({graphics:mask_graphics_7,x:35.7,y:35.4}).wait(1).to({graphics:mask_graphics_8,x:45.5,y:35.4}).wait(1).to({graphics:mask_graphics_9,x:55.3,y:35.4}).wait(1).to({graphics:mask_graphics_10,x:65.2,y:35.4}).wait(1).to({graphics:mask_graphics_11,x:75,y:35.4}).wait(1).to({graphics:mask_graphics_12,x:84.8,y:35.4}).wait(1).to({graphics:mask_graphics_13,x:94.6,y:35.4}).wait(1).to({graphics:mask_graphics_14,x:104.4,y:35.4}).wait(1).to({graphics:mask_graphics_15,x:114.2,y:35.4}).wait(1).to({graphics:mask_graphics_16,x:124,y:35.4}).wait(1).to({graphics:mask_graphics_17,x:133.8,y:35.4}).wait(1).to({graphics:mask_graphics_18,x:143.6,y:35.4}).wait(1).to({graphics:mask_graphics_19,x:153.4,y:35.4}).wait(1).to({graphics:mask_graphics_20,x:163.2,y:35.4}).wait(1).to({graphics:mask_graphics_21,x:173,y:35.4}).wait(1).to({graphics:mask_graphics_22,x:182.8,y:35.4}).wait(1).to({graphics:mask_graphics_23,x:192.7,y:35.4}).wait(1).to({graphics:mask_graphics_24,x:202.5,y:35.4}).wait(1).to({graphics:mask_graphics_25,x:212.3,y:35.4}).wait(1).to({graphics:mask_graphics_26,x:222.1,y:35.4}).wait(1).to({graphics:mask_graphics_27,x:231.9,y:35.4}).wait(1).to({graphics:mask_graphics_28,x:241.7,y:35.4}).wait(1).to({graphics:mask_graphics_29,x:251.5,y:35.4}).wait(1).to({graphics:mask_graphics_30,x:261.3,y:35.4}).wait(1).to({graphics:mask_graphics_31,x:271.1,y:35.4}).wait(1).to({graphics:mask_graphics_32,x:280.9,y:35.4}).wait(1).to({graphics:mask_graphics_33,x:290.7,y:35.4}).wait(1).to({graphics:mask_graphics_34,x:300.5,y:35.4}).wait(1).to({graphics:mask_graphics_35,x:310.3,y:35.4}).wait(1).to({graphics:mask_graphics_36,x:320.1,y:35.4}).wait(1).to({graphics:mask_graphics_37,x:330,y:35.4}).wait(1).to({graphics:mask_graphics_38,x:339.8,y:35.4}).wait(1).to({graphics:mask_graphics_39,x:349.6,y:35.4}).wait(1).to({graphics:mask_graphics_40,x:359.4,y:35.4}).wait(1).to({graphics:mask_graphics_41,x:369.2,y:35.4}).wait(1).to({graphics:mask_graphics_42,x:379,y:35.4}).wait(1).to({graphics:mask_graphics_43,x:388.8,y:35.4}).wait(1).to({graphics:mask_graphics_44,x:398.6,y:35.4}).wait(1).to({graphics:mask_graphics_45,x:408.4,y:35.4}).wait(1).to({graphics:mask_graphics_46,x:418.2,y:35.4}).wait(1).to({graphics:mask_graphics_47,x:428,y:35.4}).wait(1).to({graphics:mask_graphics_48,x:437.8,y:35.4}).wait(1).to({graphics:mask_graphics_49,x:447.6,y:35.4}).wait(1).to({graphics:mask_graphics_50,x:457.5,y:35.4}).wait(1).to({graphics:mask_graphics_51,x:467.3,y:35.4}).wait(1).to({graphics:mask_graphics_52,x:477.1,y:35.4}).wait(1).to({graphics:mask_graphics_53,x:486.9,y:35.4}).wait(1).to({graphics:mask_graphics_54,x:496.7,y:35.4}).wait(1).to({graphics:mask_graphics_55,x:506.5,y:35.4}).wait(1).to({graphics:mask_graphics_56,x:516.3,y:35.4}).wait(1).to({graphics:mask_graphics_57,x:526.1,y:35.4}).wait(1).to({graphics:mask_graphics_58,x:535.9,y:35.4}).wait(1).to({graphics:mask_graphics_59,x:545.7,y:35.4}).wait(1).to({graphics:null,x:0,y:0}).wait(1));

	// Ebene 1
	this.instance = new lib.text05();
	this.instance.setTransform(266.1,74.2,1,1,0,0,0,266.1,74.2);

	this.instance.mask = mask;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({_off:true},60).wait(1));

	// Ebene 4 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_0 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_1_graphics_1 = new cjs.Graphics().p("Ai6N0IAA7nIF1AAIAAbng");
	var mask_1_graphics_2 = new cjs.Graphics().p("AjvN0IAA7nIHeAAIAAbng");
	var mask_1_graphics_3 = new cjs.Graphics().p("AkjN0IAA7nIJHAAIAAbng");
	var mask_1_graphics_4 = new cjs.Graphics().p("AlYN0IAA7nIKxAAIAAbng");
	var mask_1_graphics_5 = new cjs.Graphics().p("AmMN0IAA7nIMZAAIAAbng");
	var mask_1_graphics_6 = new cjs.Graphics().p("AnAN0IAA7nIOBAAIAAbng");
	var mask_1_graphics_7 = new cjs.Graphics().p("An1N0IAA7nIPrAAIAAbng");
	var mask_1_graphics_8 = new cjs.Graphics().p("AopN0IAA7nIRTAAIAAbng");
	var mask_1_graphics_9 = new cjs.Graphics().p("ApeN0IAA7nIS9AAIAAbng");
	var mask_1_graphics_10 = new cjs.Graphics().p("AqSN0IAA7nIUlAAIAAbng");
	var mask_1_graphics_11 = new cjs.Graphics().p("ArHN0IAA7nIWPAAIAAbng");
	var mask_1_graphics_12 = new cjs.Graphics().p("Ar7N0IAA7nIX3AAIAAbng");
	var mask_1_graphics_13 = new cjs.Graphics().p("AswN0IAA7nIZhAAIAAbng");
	var mask_1_graphics_14 = new cjs.Graphics().p("AtkN0IAA7nIbJAAIAAbng");
	var mask_1_graphics_15 = new cjs.Graphics().p("AuZN0IAA7nIczAAIAAbng");
	var mask_1_graphics_16 = new cjs.Graphics().p("AvNN0IAA7nIebAAIAAbng");
	var mask_1_graphics_17 = new cjs.Graphics().p("AwCN0IAA7nMAgFAAAIAAbng");
	var mask_1_graphics_18 = new cjs.Graphics().p("Aw2N0IAA7nMAhtAAAIAAbng");
	var mask_1_graphics_19 = new cjs.Graphics().p("AxqN0IAA7nMAjVAAAIAAbng");
	var mask_1_graphics_20 = new cjs.Graphics().p("AyfN0IAA7nMAk/AAAIAAbng");
	var mask_1_graphics_21 = new cjs.Graphics().p("AzTN0IAA7nMAmoAAAIAAbng");
	var mask_1_graphics_22 = new cjs.Graphics().p("A0IN0IAA7nMAoRAAAIAAbng");
	var mask_1_graphics_23 = new cjs.Graphics().p("A08N0IAA7nMAp6AAAIAAbng");
	var mask_1_graphics_24 = new cjs.Graphics().p("A1xN0IAA7nMArjAAAIAAbng");
	var mask_1_graphics_25 = new cjs.Graphics().p("A2lN0IAA7nMAtLAAAIAAbng");
	var mask_1_graphics_26 = new cjs.Graphics().p("A3aN0IAA7nMAu1AAAIAAbng");
	var mask_1_graphics_27 = new cjs.Graphics().p("A4PN0IAA7nMAwfAAAIAAbng");
	var mask_1_graphics_28 = new cjs.Graphics().p("A5DN0IAA7nMAyHAAAIAAbng");
	var mask_1_graphics_29 = new cjs.Graphics().p("A54N0IAA7nMAzwAAAIAAbng");
	var mask_1_graphics_30 = new cjs.Graphics().p("A6sN0IAA7nMA1ZAAAIAAbng");
	var mask_1_graphics_31 = new cjs.Graphics().p("A7gN0IAA7nMA3BAAAIAAbng");
	var mask_1_graphics_32 = new cjs.Graphics().p("A8VN0IAA7nMA4qAAAIAAbng");
	var mask_1_graphics_33 = new cjs.Graphics().p("A9JN0IAA7nMA6TAAAIAAbng");
	var mask_1_graphics_34 = new cjs.Graphics().p("A9+N0IAA7nMA79AAAIAAbng");
	var mask_1_graphics_35 = new cjs.Graphics().p("A+yN0IAA7nMA9lAAAIAAbng");
	var mask_1_graphics_36 = new cjs.Graphics().p("A/mN0IAA7nMA/NAAAIAAbng");
	var mask_1_graphics_37 = new cjs.Graphics().p("EggbAN0IAA7nMBA3AAAIAAbng");
	var mask_1_graphics_38 = new cjs.Graphics().p("EghPAN0IAA7nMBCgAAAIAAbng");
	var mask_1_graphics_39 = new cjs.Graphics().p("EgiEAN0IAA7nMBEJAAAIAAbng");
	var mask_1_graphics_40 = new cjs.Graphics().p("Egi4AN0IAA7nMBFxAAAIAAbng");
	var mask_1_graphics_41 = new cjs.Graphics().p("EgjtAN0IAA7nMBHbAAAIAAbng");
	var mask_1_graphics_42 = new cjs.Graphics().p("EgkhAN0IAA7nMBJDAAAIAAbng");
	var mask_1_graphics_43 = new cjs.Graphics().p("EglWAN0IAA7nMBKtAAAIAAbng");
	var mask_1_graphics_44 = new cjs.Graphics().p("EgmKAN0IAA7nMBMVAAAIAAbng");
	var mask_1_graphics_45 = new cjs.Graphics().p("Egm/AN0IAA7nMBN/AAAIAAbng");
	var mask_1_graphics_46 = new cjs.Graphics().p("EgnzAN0IAA7nMBPnAAAIAAbng");
	var mask_1_graphics_47 = new cjs.Graphics().p("EgooAN0IAA7nMBRRAAAIAAbng");
	var mask_1_graphics_48 = new cjs.Graphics().p("EgpcAN0IAA7nMBS5AAAIAAbng");
	var mask_1_graphics_49 = new cjs.Graphics().p("EgqRAN0IAA7nMBUjAAAIAAbng");
	var mask_1_graphics_50 = new cjs.Graphics().p("EgrFAN0IAA7nMBWLAAAIAAbng");
	var mask_1_graphics_51 = new cjs.Graphics().p("Egr6AN0IAA7nMBX1AAAIAAbng");
	var mask_1_graphics_52 = new cjs.Graphics().p("EgsuAN0IAA7nMBZdAAAIAAbng");
	var mask_1_graphics_53 = new cjs.Graphics().p("EgtjAN0IAA7nMBbHAAAIAAbng");
	var mask_1_graphics_54 = new cjs.Graphics().p("EguXAN0IAA7nMBcvAAAIAAbng");
	var mask_1_graphics_55 = new cjs.Graphics().p("EgvMAN0IAA7nMBeZAAAIAAbng");
	var mask_1_graphics_56 = new cjs.Graphics().p("EgwAAN0IAA7nMBgBAAAIAAbng");
	var mask_1_graphics_57 = new cjs.Graphics().p("Egw1AN0IAA7nMBhqAAAIAAbng");
	var mask_1_graphics_58 = new cjs.Graphics().p("EgxpAN0IAA7nMBjTAAAIAAbng");
	var mask_1_graphics_59 = new cjs.Graphics().p("EgyeAN0IAA7nMBk8AAAIAAbng");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:mask_1_graphics_0,x:-32.9,y:35.4}).wait(1).to({graphics:mask_1_graphics_1,x:-28.5,y:35.4}).wait(1).to({graphics:mask_1_graphics_2,x:-24.1,y:35.4}).wait(1).to({graphics:mask_1_graphics_3,x:-19.7,y:35.4}).wait(1).to({graphics:mask_1_graphics_4,x:-15.3,y:35.4}).wait(1).to({graphics:mask_1_graphics_5,x:-10.9,y:35.4}).wait(1).to({graphics:mask_1_graphics_6,x:-6.5,y:35.4}).wait(1).to({graphics:mask_1_graphics_7,x:-2.1,y:35.4}).wait(1).to({graphics:mask_1_graphics_8,x:2.3,y:35.4}).wait(1).to({graphics:mask_1_graphics_9,x:6.7,y:35.4}).wait(1).to({graphics:mask_1_graphics_10,x:11.1,y:35.4}).wait(1).to({graphics:mask_1_graphics_11,x:15.5,y:35.4}).wait(1).to({graphics:mask_1_graphics_12,x:19.9,y:35.4}).wait(1).to({graphics:mask_1_graphics_13,x:24.3,y:35.4}).wait(1).to({graphics:mask_1_graphics_14,x:28.7,y:35.4}).wait(1).to({graphics:mask_1_graphics_15,x:33.1,y:35.4}).wait(1).to({graphics:mask_1_graphics_16,x:37.5,y:35.4}).wait(1).to({graphics:mask_1_graphics_17,x:41.9,y:35.4}).wait(1).to({graphics:mask_1_graphics_18,x:46.3,y:35.4}).wait(1).to({graphics:mask_1_graphics_19,x:50.7,y:35.4}).wait(1).to({graphics:mask_1_graphics_20,x:55.1,y:35.4}).wait(1).to({graphics:mask_1_graphics_21,x:59.5,y:35.4}).wait(1).to({graphics:mask_1_graphics_22,x:63.9,y:35.4}).wait(1).to({graphics:mask_1_graphics_23,x:68.3,y:35.4}).wait(1).to({graphics:mask_1_graphics_24,x:72.7,y:35.4}).wait(1).to({graphics:mask_1_graphics_25,x:77.1,y:35.4}).wait(1).to({graphics:mask_1_graphics_26,x:81.5,y:35.4}).wait(1).to({graphics:mask_1_graphics_27,x:85.9,y:35.4}).wait(1).to({graphics:mask_1_graphics_28,x:90.3,y:35.4}).wait(1).to({graphics:mask_1_graphics_29,x:94.7,y:35.4}).wait(1).to({graphics:mask_1_graphics_30,x:99.1,y:35.4}).wait(1).to({graphics:mask_1_graphics_31,x:103.5,y:35.4}).wait(1).to({graphics:mask_1_graphics_32,x:107.9,y:35.4}).wait(1).to({graphics:mask_1_graphics_33,x:112.3,y:35.4}).wait(1).to({graphics:mask_1_graphics_34,x:116.7,y:35.4}).wait(1).to({graphics:mask_1_graphics_35,x:121.1,y:35.4}).wait(1).to({graphics:mask_1_graphics_36,x:125.5,y:35.4}).wait(1).to({graphics:mask_1_graphics_37,x:129.9,y:35.4}).wait(1).to({graphics:mask_1_graphics_38,x:134.3,y:35.4}).wait(1).to({graphics:mask_1_graphics_39,x:138.7,y:35.4}).wait(1).to({graphics:mask_1_graphics_40,x:143.1,y:35.4}).wait(1).to({graphics:mask_1_graphics_41,x:147.5,y:35.4}).wait(1).to({graphics:mask_1_graphics_42,x:151.9,y:35.4}).wait(1).to({graphics:mask_1_graphics_43,x:156.3,y:35.4}).wait(1).to({graphics:mask_1_graphics_44,x:160.7,y:35.4}).wait(1).to({graphics:mask_1_graphics_45,x:165.1,y:35.4}).wait(1).to({graphics:mask_1_graphics_46,x:169.5,y:35.4}).wait(1).to({graphics:mask_1_graphics_47,x:173.9,y:35.4}).wait(1).to({graphics:mask_1_graphics_48,x:178.3,y:35.4}).wait(1).to({graphics:mask_1_graphics_49,x:182.7,y:35.4}).wait(1).to({graphics:mask_1_graphics_50,x:187.1,y:35.4}).wait(1).to({graphics:mask_1_graphics_51,x:191.5,y:35.4}).wait(1).to({graphics:mask_1_graphics_52,x:195.9,y:35.4}).wait(1).to({graphics:mask_1_graphics_53,x:200.3,y:35.4}).wait(1).to({graphics:mask_1_graphics_54,x:204.8,y:35.4}).wait(1).to({graphics:mask_1_graphics_55,x:209.2,y:35.4}).wait(1).to({graphics:mask_1_graphics_56,x:213.6,y:35.4}).wait(1).to({graphics:mask_1_graphics_57,x:218,y:35.4}).wait(1).to({graphics:mask_1_graphics_58,x:222.4,y:35.4}).wait(1).to({graphics:mask_1_graphics_59,x:226.8,y:35.4}).wait(1).to({graphics:null,x:0,y:0}).wait(1));

	// Ebene 3
	this.instance_1 = new lib.text05();
	this.instance_1.setTransform(266.1,74.2,1,1,0,0,0,266.1,74.2);

	this.instance_1.mask = mask_1;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({alpha:0},59).to({_off:true},1).wait(1));

	// Ebene 5
	this.instance_2 = new lib.text05_();
	this.instance_2.setTransform(266.1,74.2,1,1,0,0,0,266.1,74.2);

	this.instance_2.mask = mask_1;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(61));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-21,-21,1.6,114);


(lib.ani_text04 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_1 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_2 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_3 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_4 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_5 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_6 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_7 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_8 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_9 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_10 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_11 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_12 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_13 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_14 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_15 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_16 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_17 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_18 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_19 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_20 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_21 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_22 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_23 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_24 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_25 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_26 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_27 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_28 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_29 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_30 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_31 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_32 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_33 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_34 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_35 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_36 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_37 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_38 = new cjs.Graphics().p("AiGN0IAA7nIENAAIAAbng");
	var mask_graphics_39 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_40 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_41 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_42 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_43 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_44 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_45 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_46 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_47 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_48 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_49 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_50 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_51 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_52 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_53 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_54 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_55 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_56 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_57 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_58 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_59 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:-32.9,y:35.4}).wait(1).to({graphics:mask_graphics_1,x:-23.1,y:35.4}).wait(1).to({graphics:mask_graphics_2,x:-13.3,y:35.4}).wait(1).to({graphics:mask_graphics_3,x:-3.5,y:35.4}).wait(1).to({graphics:mask_graphics_4,x:6.3,y:35.4}).wait(1).to({graphics:mask_graphics_5,x:16.1,y:35.4}).wait(1).to({graphics:mask_graphics_6,x:25.9,y:35.4}).wait(1).to({graphics:mask_graphics_7,x:35.7,y:35.4}).wait(1).to({graphics:mask_graphics_8,x:45.5,y:35.4}).wait(1).to({graphics:mask_graphics_9,x:55.3,y:35.4}).wait(1).to({graphics:mask_graphics_10,x:65.2,y:35.4}).wait(1).to({graphics:mask_graphics_11,x:75,y:35.4}).wait(1).to({graphics:mask_graphics_12,x:84.8,y:35.4}).wait(1).to({graphics:mask_graphics_13,x:94.6,y:35.4}).wait(1).to({graphics:mask_graphics_14,x:104.4,y:35.4}).wait(1).to({graphics:mask_graphics_15,x:114.2,y:35.4}).wait(1).to({graphics:mask_graphics_16,x:124,y:35.4}).wait(1).to({graphics:mask_graphics_17,x:133.8,y:35.4}).wait(1).to({graphics:mask_graphics_18,x:143.6,y:35.4}).wait(1).to({graphics:mask_graphics_19,x:153.4,y:35.4}).wait(1).to({graphics:mask_graphics_20,x:163.2,y:35.4}).wait(1).to({graphics:mask_graphics_21,x:173,y:35.4}).wait(1).to({graphics:mask_graphics_22,x:182.8,y:35.4}).wait(1).to({graphics:mask_graphics_23,x:192.7,y:35.4}).wait(1).to({graphics:mask_graphics_24,x:202.5,y:35.4}).wait(1).to({graphics:mask_graphics_25,x:212.3,y:35.4}).wait(1).to({graphics:mask_graphics_26,x:222.1,y:35.4}).wait(1).to({graphics:mask_graphics_27,x:231.9,y:35.4}).wait(1).to({graphics:mask_graphics_28,x:241.7,y:35.4}).wait(1).to({graphics:mask_graphics_29,x:251.5,y:35.4}).wait(1).to({graphics:mask_graphics_30,x:261.3,y:35.4}).wait(1).to({graphics:mask_graphics_31,x:271.1,y:35.4}).wait(1).to({graphics:mask_graphics_32,x:280.9,y:35.4}).wait(1).to({graphics:mask_graphics_33,x:290.7,y:35.4}).wait(1).to({graphics:mask_graphics_34,x:300.5,y:35.4}).wait(1).to({graphics:mask_graphics_35,x:310.3,y:35.4}).wait(1).to({graphics:mask_graphics_36,x:320.1,y:35.4}).wait(1).to({graphics:mask_graphics_37,x:330,y:35.4}).wait(1).to({graphics:mask_graphics_38,x:339.8,y:35.4}).wait(1).to({graphics:mask_graphics_39,x:349.6,y:35.4}).wait(1).to({graphics:mask_graphics_40,x:359.4,y:35.4}).wait(1).to({graphics:mask_graphics_41,x:369.2,y:35.4}).wait(1).to({graphics:mask_graphics_42,x:379,y:35.4}).wait(1).to({graphics:mask_graphics_43,x:388.8,y:35.4}).wait(1).to({graphics:mask_graphics_44,x:398.6,y:35.4}).wait(1).to({graphics:mask_graphics_45,x:408.4,y:35.4}).wait(1).to({graphics:mask_graphics_46,x:418.2,y:35.4}).wait(1).to({graphics:mask_graphics_47,x:428,y:35.4}).wait(1).to({graphics:mask_graphics_48,x:437.8,y:35.4}).wait(1).to({graphics:mask_graphics_49,x:447.6,y:35.4}).wait(1).to({graphics:mask_graphics_50,x:457.5,y:35.4}).wait(1).to({graphics:mask_graphics_51,x:467.3,y:35.4}).wait(1).to({graphics:mask_graphics_52,x:477.1,y:35.4}).wait(1).to({graphics:mask_graphics_53,x:486.9,y:35.4}).wait(1).to({graphics:mask_graphics_54,x:496.7,y:35.4}).wait(1).to({graphics:mask_graphics_55,x:506.5,y:35.4}).wait(1).to({graphics:mask_graphics_56,x:516.3,y:35.4}).wait(1).to({graphics:mask_graphics_57,x:526.1,y:35.4}).wait(1).to({graphics:mask_graphics_58,x:535.9,y:35.4}).wait(1).to({graphics:mask_graphics_59,x:545.7,y:35.4}).wait(1).to({graphics:null,x:0,y:0}).wait(1));

	// Ebene 1
	this.instance = new lib.text04();
	this.instance.setTransform(266.1,74.2,1,1,0,0,0,266.1,74.2);

	this.instance.mask = mask;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({_off:true},60).wait(1));

	// Ebene 4 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_0 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_1_graphics_1 = new cjs.Graphics().p("Ai6N0IAA7nIF1AAIAAbng");
	var mask_1_graphics_2 = new cjs.Graphics().p("AjvN0IAA7nIHeAAIAAbng");
	var mask_1_graphics_3 = new cjs.Graphics().p("AkjN0IAA7nIJHAAIAAbng");
	var mask_1_graphics_4 = new cjs.Graphics().p("AlYN0IAA7nIKxAAIAAbng");
	var mask_1_graphics_5 = new cjs.Graphics().p("AmMN0IAA7nIMZAAIAAbng");
	var mask_1_graphics_6 = new cjs.Graphics().p("AnAN0IAA7nIOBAAIAAbng");
	var mask_1_graphics_7 = new cjs.Graphics().p("An1N0IAA7nIPrAAIAAbng");
	var mask_1_graphics_8 = new cjs.Graphics().p("AopN0IAA7nIRTAAIAAbng");
	var mask_1_graphics_9 = new cjs.Graphics().p("ApeN0IAA7nIS9AAIAAbng");
	var mask_1_graphics_10 = new cjs.Graphics().p("AqSN0IAA7nIUlAAIAAbng");
	var mask_1_graphics_11 = new cjs.Graphics().p("ArHN0IAA7nIWPAAIAAbng");
	var mask_1_graphics_12 = new cjs.Graphics().p("Ar7N0IAA7nIX3AAIAAbng");
	var mask_1_graphics_13 = new cjs.Graphics().p("AswN0IAA7nIZhAAIAAbng");
	var mask_1_graphics_14 = new cjs.Graphics().p("AtkN0IAA7nIbJAAIAAbng");
	var mask_1_graphics_15 = new cjs.Graphics().p("AuZN0IAA7nIczAAIAAbng");
	var mask_1_graphics_16 = new cjs.Graphics().p("AvNN0IAA7nIebAAIAAbng");
	var mask_1_graphics_17 = new cjs.Graphics().p("AwCN0IAA7nMAgFAAAIAAbng");
	var mask_1_graphics_18 = new cjs.Graphics().p("Aw2N0IAA7nMAhtAAAIAAbng");
	var mask_1_graphics_19 = new cjs.Graphics().p("AxqN0IAA7nMAjVAAAIAAbng");
	var mask_1_graphics_20 = new cjs.Graphics().p("AyfN0IAA7nMAk/AAAIAAbng");
	var mask_1_graphics_21 = new cjs.Graphics().p("AzTN0IAA7nMAmoAAAIAAbng");
	var mask_1_graphics_22 = new cjs.Graphics().p("A0IN0IAA7nMAoRAAAIAAbng");
	var mask_1_graphics_23 = new cjs.Graphics().p("A08N0IAA7nMAp6AAAIAAbng");
	var mask_1_graphics_24 = new cjs.Graphics().p("A1xN0IAA7nMArjAAAIAAbng");
	var mask_1_graphics_25 = new cjs.Graphics().p("A2lN0IAA7nMAtLAAAIAAbng");
	var mask_1_graphics_26 = new cjs.Graphics().p("A3aN0IAA7nMAu1AAAIAAbng");
	var mask_1_graphics_27 = new cjs.Graphics().p("A4PN0IAA7nMAwfAAAIAAbng");
	var mask_1_graphics_28 = new cjs.Graphics().p("A5DN0IAA7nMAyHAAAIAAbng");
	var mask_1_graphics_29 = new cjs.Graphics().p("A54N0IAA7nMAzwAAAIAAbng");
	var mask_1_graphics_30 = new cjs.Graphics().p("A6sN0IAA7nMA1ZAAAIAAbng");
	var mask_1_graphics_31 = new cjs.Graphics().p("A7gN0IAA7nMA3BAAAIAAbng");
	var mask_1_graphics_32 = new cjs.Graphics().p("A8VN0IAA7nMA4qAAAIAAbng");
	var mask_1_graphics_33 = new cjs.Graphics().p("A9JN0IAA7nMA6TAAAIAAbng");
	var mask_1_graphics_34 = new cjs.Graphics().p("A9+N0IAA7nMA79AAAIAAbng");
	var mask_1_graphics_35 = new cjs.Graphics().p("A+yN0IAA7nMA9lAAAIAAbng");
	var mask_1_graphics_36 = new cjs.Graphics().p("A/mN0IAA7nMA/NAAAIAAbng");
	var mask_1_graphics_37 = new cjs.Graphics().p("EggbAN0IAA7nMBA3AAAIAAbng");
	var mask_1_graphics_38 = new cjs.Graphics().p("EghPAN0IAA7nMBCgAAAIAAbng");
	var mask_1_graphics_39 = new cjs.Graphics().p("EgiEAN0IAA7nMBEJAAAIAAbng");
	var mask_1_graphics_40 = new cjs.Graphics().p("Egi4AN0IAA7nMBFxAAAIAAbng");
	var mask_1_graphics_41 = new cjs.Graphics().p("EgjtAN0IAA7nMBHbAAAIAAbng");
	var mask_1_graphics_42 = new cjs.Graphics().p("EgkhAN0IAA7nMBJDAAAIAAbng");
	var mask_1_graphics_43 = new cjs.Graphics().p("EglWAN0IAA7nMBKtAAAIAAbng");
	var mask_1_graphics_44 = new cjs.Graphics().p("EgmKAN0IAA7nMBMVAAAIAAbng");
	var mask_1_graphics_45 = new cjs.Graphics().p("Egm/AN0IAA7nMBN/AAAIAAbng");
	var mask_1_graphics_46 = new cjs.Graphics().p("EgnzAN0IAA7nMBPnAAAIAAbng");
	var mask_1_graphics_47 = new cjs.Graphics().p("EgooAN0IAA7nMBRRAAAIAAbng");
	var mask_1_graphics_48 = new cjs.Graphics().p("EgpcAN0IAA7nMBS5AAAIAAbng");
	var mask_1_graphics_49 = new cjs.Graphics().p("EgqRAN0IAA7nMBUjAAAIAAbng");
	var mask_1_graphics_50 = new cjs.Graphics().p("EgrFAN0IAA7nMBWLAAAIAAbng");
	var mask_1_graphics_51 = new cjs.Graphics().p("Egr6AN0IAA7nMBX1AAAIAAbng");
	var mask_1_graphics_52 = new cjs.Graphics().p("EgsuAN0IAA7nMBZdAAAIAAbng");
	var mask_1_graphics_53 = new cjs.Graphics().p("EgtjAN0IAA7nMBbHAAAIAAbng");
	var mask_1_graphics_54 = new cjs.Graphics().p("EguXAN0IAA7nMBcvAAAIAAbng");
	var mask_1_graphics_55 = new cjs.Graphics().p("EgvMAN0IAA7nMBeZAAAIAAbng");
	var mask_1_graphics_56 = new cjs.Graphics().p("EgwAAN0IAA7nMBgBAAAIAAbng");
	var mask_1_graphics_57 = new cjs.Graphics().p("Egw1AN0IAA7nMBhqAAAIAAbng");
	var mask_1_graphics_58 = new cjs.Graphics().p("EgxpAN0IAA7nMBjTAAAIAAbng");
	var mask_1_graphics_59 = new cjs.Graphics().p("EgyeAN0IAA7nMBk8AAAIAAbng");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:mask_1_graphics_0,x:-32.9,y:35.4}).wait(1).to({graphics:mask_1_graphics_1,x:-28.5,y:35.4}).wait(1).to({graphics:mask_1_graphics_2,x:-24.1,y:35.4}).wait(1).to({graphics:mask_1_graphics_3,x:-19.7,y:35.4}).wait(1).to({graphics:mask_1_graphics_4,x:-15.3,y:35.4}).wait(1).to({graphics:mask_1_graphics_5,x:-10.9,y:35.4}).wait(1).to({graphics:mask_1_graphics_6,x:-6.5,y:35.4}).wait(1).to({graphics:mask_1_graphics_7,x:-2.1,y:35.4}).wait(1).to({graphics:mask_1_graphics_8,x:2.3,y:35.4}).wait(1).to({graphics:mask_1_graphics_9,x:6.7,y:35.4}).wait(1).to({graphics:mask_1_graphics_10,x:11.1,y:35.4}).wait(1).to({graphics:mask_1_graphics_11,x:15.5,y:35.4}).wait(1).to({graphics:mask_1_graphics_12,x:19.9,y:35.4}).wait(1).to({graphics:mask_1_graphics_13,x:24.3,y:35.4}).wait(1).to({graphics:mask_1_graphics_14,x:28.7,y:35.4}).wait(1).to({graphics:mask_1_graphics_15,x:33.1,y:35.4}).wait(1).to({graphics:mask_1_graphics_16,x:37.5,y:35.4}).wait(1).to({graphics:mask_1_graphics_17,x:41.9,y:35.4}).wait(1).to({graphics:mask_1_graphics_18,x:46.3,y:35.4}).wait(1).to({graphics:mask_1_graphics_19,x:50.7,y:35.4}).wait(1).to({graphics:mask_1_graphics_20,x:55.1,y:35.4}).wait(1).to({graphics:mask_1_graphics_21,x:59.5,y:35.4}).wait(1).to({graphics:mask_1_graphics_22,x:63.9,y:35.4}).wait(1).to({graphics:mask_1_graphics_23,x:68.3,y:35.4}).wait(1).to({graphics:mask_1_graphics_24,x:72.7,y:35.4}).wait(1).to({graphics:mask_1_graphics_25,x:77.1,y:35.4}).wait(1).to({graphics:mask_1_graphics_26,x:81.5,y:35.4}).wait(1).to({graphics:mask_1_graphics_27,x:85.9,y:35.4}).wait(1).to({graphics:mask_1_graphics_28,x:90.3,y:35.4}).wait(1).to({graphics:mask_1_graphics_29,x:94.7,y:35.4}).wait(1).to({graphics:mask_1_graphics_30,x:99.1,y:35.4}).wait(1).to({graphics:mask_1_graphics_31,x:103.5,y:35.4}).wait(1).to({graphics:mask_1_graphics_32,x:107.9,y:35.4}).wait(1).to({graphics:mask_1_graphics_33,x:112.3,y:35.4}).wait(1).to({graphics:mask_1_graphics_34,x:116.7,y:35.4}).wait(1).to({graphics:mask_1_graphics_35,x:121.1,y:35.4}).wait(1).to({graphics:mask_1_graphics_36,x:125.5,y:35.4}).wait(1).to({graphics:mask_1_graphics_37,x:129.9,y:35.4}).wait(1).to({graphics:mask_1_graphics_38,x:134.3,y:35.4}).wait(1).to({graphics:mask_1_graphics_39,x:138.7,y:35.4}).wait(1).to({graphics:mask_1_graphics_40,x:143.1,y:35.4}).wait(1).to({graphics:mask_1_graphics_41,x:147.5,y:35.4}).wait(1).to({graphics:mask_1_graphics_42,x:151.9,y:35.4}).wait(1).to({graphics:mask_1_graphics_43,x:156.3,y:35.4}).wait(1).to({graphics:mask_1_graphics_44,x:160.7,y:35.4}).wait(1).to({graphics:mask_1_graphics_45,x:165.1,y:35.4}).wait(1).to({graphics:mask_1_graphics_46,x:169.5,y:35.4}).wait(1).to({graphics:mask_1_graphics_47,x:173.9,y:35.4}).wait(1).to({graphics:mask_1_graphics_48,x:178.3,y:35.4}).wait(1).to({graphics:mask_1_graphics_49,x:182.7,y:35.4}).wait(1).to({graphics:mask_1_graphics_50,x:187.1,y:35.4}).wait(1).to({graphics:mask_1_graphics_51,x:191.5,y:35.4}).wait(1).to({graphics:mask_1_graphics_52,x:195.9,y:35.4}).wait(1).to({graphics:mask_1_graphics_53,x:200.3,y:35.4}).wait(1).to({graphics:mask_1_graphics_54,x:204.8,y:35.4}).wait(1).to({graphics:mask_1_graphics_55,x:209.2,y:35.4}).wait(1).to({graphics:mask_1_graphics_56,x:213.6,y:35.4}).wait(1).to({graphics:mask_1_graphics_57,x:218,y:35.4}).wait(1).to({graphics:mask_1_graphics_58,x:222.4,y:35.4}).wait(1).to({graphics:mask_1_graphics_59,x:226.8,y:35.4}).wait(1).to({graphics:null,x:0,y:0}).wait(1));

	// Ebene 3
	this.instance_1 = new lib.text04();
	this.instance_1.setTransform(266.1,74.2,1,1,0,0,0,266.1,74.2);

	this.instance_1.mask = mask_1;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({alpha:0},59).to({_off:true},1).wait(1));

	// Ebene 5
	this.instance_2 = new lib.text04_();
	this.instance_2.setTransform(266.1,74.2,1,1,0,0,0,266.1,74.2);

	this.instance_2.mask = mask_1;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(61));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-21,-21,1.6,114);


(lib.ani_text03 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_1 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_2 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_3 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_4 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_5 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_6 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_7 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_8 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_9 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_10 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_11 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_12 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_13 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_14 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_15 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_16 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_17 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_18 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_19 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_20 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_21 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_22 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_23 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_24 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_25 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_26 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_27 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_28 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_29 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_30 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_31 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_32 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_33 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_34 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_35 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_36 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_37 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_38 = new cjs.Graphics().p("AiGN0IAA7nIENAAIAAbng");
	var mask_graphics_39 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_40 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_41 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_42 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_43 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_44 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_45 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_46 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_47 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_48 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_49 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_50 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_51 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_52 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_53 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_54 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_55 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_56 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_57 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_graphics_58 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");
	var mask_graphics_59 = new cjs.Graphics().p("AiGN0IAA7nIEMAAIAAbng");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:-32.9,y:35.4}).wait(1).to({graphics:mask_graphics_1,x:-23.1,y:35.4}).wait(1).to({graphics:mask_graphics_2,x:-13.3,y:35.4}).wait(1).to({graphics:mask_graphics_3,x:-3.5,y:35.4}).wait(1).to({graphics:mask_graphics_4,x:6.3,y:35.4}).wait(1).to({graphics:mask_graphics_5,x:16.1,y:35.4}).wait(1).to({graphics:mask_graphics_6,x:25.9,y:35.4}).wait(1).to({graphics:mask_graphics_7,x:35.7,y:35.4}).wait(1).to({graphics:mask_graphics_8,x:45.5,y:35.4}).wait(1).to({graphics:mask_graphics_9,x:55.3,y:35.4}).wait(1).to({graphics:mask_graphics_10,x:65.2,y:35.4}).wait(1).to({graphics:mask_graphics_11,x:75,y:35.4}).wait(1).to({graphics:mask_graphics_12,x:84.8,y:35.4}).wait(1).to({graphics:mask_graphics_13,x:94.6,y:35.4}).wait(1).to({graphics:mask_graphics_14,x:104.4,y:35.4}).wait(1).to({graphics:mask_graphics_15,x:114.2,y:35.4}).wait(1).to({graphics:mask_graphics_16,x:124,y:35.4}).wait(1).to({graphics:mask_graphics_17,x:133.8,y:35.4}).wait(1).to({graphics:mask_graphics_18,x:143.6,y:35.4}).wait(1).to({graphics:mask_graphics_19,x:153.4,y:35.4}).wait(1).to({graphics:mask_graphics_20,x:163.2,y:35.4}).wait(1).to({graphics:mask_graphics_21,x:173,y:35.4}).wait(1).to({graphics:mask_graphics_22,x:182.8,y:35.4}).wait(1).to({graphics:mask_graphics_23,x:192.7,y:35.4}).wait(1).to({graphics:mask_graphics_24,x:202.5,y:35.4}).wait(1).to({graphics:mask_graphics_25,x:212.3,y:35.4}).wait(1).to({graphics:mask_graphics_26,x:222.1,y:35.4}).wait(1).to({graphics:mask_graphics_27,x:231.9,y:35.4}).wait(1).to({graphics:mask_graphics_28,x:241.7,y:35.4}).wait(1).to({graphics:mask_graphics_29,x:251.5,y:35.4}).wait(1).to({graphics:mask_graphics_30,x:261.3,y:35.4}).wait(1).to({graphics:mask_graphics_31,x:271.1,y:35.4}).wait(1).to({graphics:mask_graphics_32,x:280.9,y:35.4}).wait(1).to({graphics:mask_graphics_33,x:290.7,y:35.4}).wait(1).to({graphics:mask_graphics_34,x:300.5,y:35.4}).wait(1).to({graphics:mask_graphics_35,x:310.3,y:35.4}).wait(1).to({graphics:mask_graphics_36,x:320.1,y:35.4}).wait(1).to({graphics:mask_graphics_37,x:330,y:35.4}).wait(1).to({graphics:mask_graphics_38,x:339.8,y:35.4}).wait(1).to({graphics:mask_graphics_39,x:349.6,y:35.4}).wait(1).to({graphics:mask_graphics_40,x:359.4,y:35.4}).wait(1).to({graphics:mask_graphics_41,x:369.2,y:35.4}).wait(1).to({graphics:mask_graphics_42,x:379,y:35.4}).wait(1).to({graphics:mask_graphics_43,x:388.8,y:35.4}).wait(1).to({graphics:mask_graphics_44,x:398.6,y:35.4}).wait(1).to({graphics:mask_graphics_45,x:408.4,y:35.4}).wait(1).to({graphics:mask_graphics_46,x:418.2,y:35.4}).wait(1).to({graphics:mask_graphics_47,x:428,y:35.4}).wait(1).to({graphics:mask_graphics_48,x:437.8,y:35.4}).wait(1).to({graphics:mask_graphics_49,x:447.6,y:35.4}).wait(1).to({graphics:mask_graphics_50,x:457.5,y:35.4}).wait(1).to({graphics:mask_graphics_51,x:467.3,y:35.4}).wait(1).to({graphics:mask_graphics_52,x:477.1,y:35.4}).wait(1).to({graphics:mask_graphics_53,x:486.9,y:35.4}).wait(1).to({graphics:mask_graphics_54,x:496.7,y:35.4}).wait(1).to({graphics:mask_graphics_55,x:506.5,y:35.4}).wait(1).to({graphics:mask_graphics_56,x:516.3,y:35.4}).wait(1).to({graphics:mask_graphics_57,x:526.1,y:35.4}).wait(1).to({graphics:mask_graphics_58,x:535.9,y:35.4}).wait(1).to({graphics:mask_graphics_59,x:545.7,y:35.4}).wait(1).to({graphics:null,x:0,y:0}).wait(1));

	// Ebene 1
	this.instance = new lib.text03();
	this.instance.setTransform(266.1,74.2,1,1,0,0,0,266.1,74.2);

	this.instance.mask = mask;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({_off:true},60).wait(1));

	// Ebene 4 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_0 = new cjs.Graphics().p("AiFN0IAA7nIEMAAIAAbng");
	var mask_1_graphics_1 = new cjs.Graphics().p("Ai6N0IAA7nIF1AAIAAbng");
	var mask_1_graphics_2 = new cjs.Graphics().p("AjvN0IAA7nIHeAAIAAbng");
	var mask_1_graphics_3 = new cjs.Graphics().p("AkjN0IAA7nIJHAAIAAbng");
	var mask_1_graphics_4 = new cjs.Graphics().p("AlYN0IAA7nIKxAAIAAbng");
	var mask_1_graphics_5 = new cjs.Graphics().p("AmMN0IAA7nIMZAAIAAbng");
	var mask_1_graphics_6 = new cjs.Graphics().p("AnAN0IAA7nIOBAAIAAbng");
	var mask_1_graphics_7 = new cjs.Graphics().p("An1N0IAA7nIPrAAIAAbng");
	var mask_1_graphics_8 = new cjs.Graphics().p("AopN0IAA7nIRTAAIAAbng");
	var mask_1_graphics_9 = new cjs.Graphics().p("ApeN0IAA7nIS9AAIAAbng");
	var mask_1_graphics_10 = new cjs.Graphics().p("AqSN0IAA7nIUlAAIAAbng");
	var mask_1_graphics_11 = new cjs.Graphics().p("ArHN0IAA7nIWPAAIAAbng");
	var mask_1_graphics_12 = new cjs.Graphics().p("Ar7N0IAA7nIX3AAIAAbng");
	var mask_1_graphics_13 = new cjs.Graphics().p("AswN0IAA7nIZhAAIAAbng");
	var mask_1_graphics_14 = new cjs.Graphics().p("AtkN0IAA7nIbJAAIAAbng");
	var mask_1_graphics_15 = new cjs.Graphics().p("AuZN0IAA7nIczAAIAAbng");
	var mask_1_graphics_16 = new cjs.Graphics().p("AvNN0IAA7nIebAAIAAbng");
	var mask_1_graphics_17 = new cjs.Graphics().p("AwCN0IAA7nMAgFAAAIAAbng");
	var mask_1_graphics_18 = new cjs.Graphics().p("Aw2N0IAA7nMAhtAAAIAAbng");
	var mask_1_graphics_19 = new cjs.Graphics().p("AxqN0IAA7nMAjVAAAIAAbng");
	var mask_1_graphics_20 = new cjs.Graphics().p("AyfN0IAA7nMAk/AAAIAAbng");
	var mask_1_graphics_21 = new cjs.Graphics().p("AzTN0IAA7nMAmoAAAIAAbng");
	var mask_1_graphics_22 = new cjs.Graphics().p("A0IN0IAA7nMAoRAAAIAAbng");
	var mask_1_graphics_23 = new cjs.Graphics().p("A08N0IAA7nMAp6AAAIAAbng");
	var mask_1_graphics_24 = new cjs.Graphics().p("A1xN0IAA7nMArjAAAIAAbng");
	var mask_1_graphics_25 = new cjs.Graphics().p("A2lN0IAA7nMAtLAAAIAAbng");
	var mask_1_graphics_26 = new cjs.Graphics().p("A3aN0IAA7nMAu1AAAIAAbng");
	var mask_1_graphics_27 = new cjs.Graphics().p("A4PN0IAA7nMAwfAAAIAAbng");
	var mask_1_graphics_28 = new cjs.Graphics().p("A5DN0IAA7nMAyHAAAIAAbng");
	var mask_1_graphics_29 = new cjs.Graphics().p("A54N0IAA7nMAzwAAAIAAbng");
	var mask_1_graphics_30 = new cjs.Graphics().p("A6sN0IAA7nMA1ZAAAIAAbng");
	var mask_1_graphics_31 = new cjs.Graphics().p("A7gN0IAA7nMA3BAAAIAAbng");
	var mask_1_graphics_32 = new cjs.Graphics().p("A8VN0IAA7nMA4qAAAIAAbng");
	var mask_1_graphics_33 = new cjs.Graphics().p("A9JN0IAA7nMA6TAAAIAAbng");
	var mask_1_graphics_34 = new cjs.Graphics().p("A9+N0IAA7nMA79AAAIAAbng");
	var mask_1_graphics_35 = new cjs.Graphics().p("A+yN0IAA7nMA9lAAAIAAbng");
	var mask_1_graphics_36 = new cjs.Graphics().p("A/mN0IAA7nMA/NAAAIAAbng");
	var mask_1_graphics_37 = new cjs.Graphics().p("EggbAN0IAA7nMBA3AAAIAAbng");
	var mask_1_graphics_38 = new cjs.Graphics().p("EghPAN0IAA7nMBCgAAAIAAbng");
	var mask_1_graphics_39 = new cjs.Graphics().p("EgiEAN0IAA7nMBEJAAAIAAbng");
	var mask_1_graphics_40 = new cjs.Graphics().p("Egi4AN0IAA7nMBFxAAAIAAbng");
	var mask_1_graphics_41 = new cjs.Graphics().p("EgjtAN0IAA7nMBHbAAAIAAbng");
	var mask_1_graphics_42 = new cjs.Graphics().p("EgkhAN0IAA7nMBJDAAAIAAbng");
	var mask_1_graphics_43 = new cjs.Graphics().p("EglWAN0IAA7nMBKtAAAIAAbng");
	var mask_1_graphics_44 = new cjs.Graphics().p("EgmKAN0IAA7nMBMVAAAIAAbng");
	var mask_1_graphics_45 = new cjs.Graphics().p("Egm/AN0IAA7nMBN/AAAIAAbng");
	var mask_1_graphics_46 = new cjs.Graphics().p("EgnzAN0IAA7nMBPnAAAIAAbng");
	var mask_1_graphics_47 = new cjs.Graphics().p("EgooAN0IAA7nMBRRAAAIAAbng");
	var mask_1_graphics_48 = new cjs.Graphics().p("EgpcAN0IAA7nMBS5AAAIAAbng");
	var mask_1_graphics_49 = new cjs.Graphics().p("EgqRAN0IAA7nMBUjAAAIAAbng");
	var mask_1_graphics_50 = new cjs.Graphics().p("EgrFAN0IAA7nMBWLAAAIAAbng");
	var mask_1_graphics_51 = new cjs.Graphics().p("Egr6AN0IAA7nMBX1AAAIAAbng");
	var mask_1_graphics_52 = new cjs.Graphics().p("EgsuAN0IAA7nMBZdAAAIAAbng");
	var mask_1_graphics_53 = new cjs.Graphics().p("EgtjAN0IAA7nMBbHAAAIAAbng");
	var mask_1_graphics_54 = new cjs.Graphics().p("EguXAN0IAA7nMBcvAAAIAAbng");
	var mask_1_graphics_55 = new cjs.Graphics().p("EgvMAN0IAA7nMBeZAAAIAAbng");
	var mask_1_graphics_56 = new cjs.Graphics().p("EgwAAN0IAA7nMBgBAAAIAAbng");
	var mask_1_graphics_57 = new cjs.Graphics().p("Egw1AN0IAA7nMBhqAAAIAAbng");
	var mask_1_graphics_58 = new cjs.Graphics().p("EgxpAN0IAA7nMBjTAAAIAAbng");
	var mask_1_graphics_59 = new cjs.Graphics().p("EgyeAN0IAA7nMBk8AAAIAAbng");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:mask_1_graphics_0,x:-32.9,y:35.4}).wait(1).to({graphics:mask_1_graphics_1,x:-28.5,y:35.4}).wait(1).to({graphics:mask_1_graphics_2,x:-24.1,y:35.4}).wait(1).to({graphics:mask_1_graphics_3,x:-19.7,y:35.4}).wait(1).to({graphics:mask_1_graphics_4,x:-15.3,y:35.4}).wait(1).to({graphics:mask_1_graphics_5,x:-10.9,y:35.4}).wait(1).to({graphics:mask_1_graphics_6,x:-6.5,y:35.4}).wait(1).to({graphics:mask_1_graphics_7,x:-2.1,y:35.4}).wait(1).to({graphics:mask_1_graphics_8,x:2.3,y:35.4}).wait(1).to({graphics:mask_1_graphics_9,x:6.7,y:35.4}).wait(1).to({graphics:mask_1_graphics_10,x:11.1,y:35.4}).wait(1).to({graphics:mask_1_graphics_11,x:15.5,y:35.4}).wait(1).to({graphics:mask_1_graphics_12,x:19.9,y:35.4}).wait(1).to({graphics:mask_1_graphics_13,x:24.3,y:35.4}).wait(1).to({graphics:mask_1_graphics_14,x:28.7,y:35.4}).wait(1).to({graphics:mask_1_graphics_15,x:33.1,y:35.4}).wait(1).to({graphics:mask_1_graphics_16,x:37.5,y:35.4}).wait(1).to({graphics:mask_1_graphics_17,x:41.9,y:35.4}).wait(1).to({graphics:mask_1_graphics_18,x:46.3,y:35.4}).wait(1).to({graphics:mask_1_graphics_19,x:50.7,y:35.4}).wait(1).to({graphics:mask_1_graphics_20,x:55.1,y:35.4}).wait(1).to({graphics:mask_1_graphics_21,x:59.5,y:35.4}).wait(1).to({graphics:mask_1_graphics_22,x:63.9,y:35.4}).wait(1).to({graphics:mask_1_graphics_23,x:68.3,y:35.4}).wait(1).to({graphics:mask_1_graphics_24,x:72.7,y:35.4}).wait(1).to({graphics:mask_1_graphics_25,x:77.1,y:35.4}).wait(1).to({graphics:mask_1_graphics_26,x:81.5,y:35.4}).wait(1).to({graphics:mask_1_graphics_27,x:85.9,y:35.4}).wait(1).to({graphics:mask_1_graphics_28,x:90.3,y:35.4}).wait(1).to({graphics:mask_1_graphics_29,x:94.7,y:35.4}).wait(1).to({graphics:mask_1_graphics_30,x:99.1,y:35.4}).wait(1).to({graphics:mask_1_graphics_31,x:103.5,y:35.4}).wait(1).to({graphics:mask_1_graphics_32,x:107.9,y:35.4}).wait(1).to({graphics:mask_1_graphics_33,x:112.3,y:35.4}).wait(1).to({graphics:mask_1_graphics_34,x:116.7,y:35.4}).wait(1).to({graphics:mask_1_graphics_35,x:121.1,y:35.4}).wait(1).to({graphics:mask_1_graphics_36,x:125.5,y:35.4}).wait(1).to({graphics:mask_1_graphics_37,x:129.9,y:35.4}).wait(1).to({graphics:mask_1_graphics_38,x:134.3,y:35.4}).wait(1).to({graphics:mask_1_graphics_39,x:138.7,y:35.4}).wait(1).to({graphics:mask_1_graphics_40,x:143.1,y:35.4}).wait(1).to({graphics:mask_1_graphics_41,x:147.5,y:35.4}).wait(1).to({graphics:mask_1_graphics_42,x:151.9,y:35.4}).wait(1).to({graphics:mask_1_graphics_43,x:156.3,y:35.4}).wait(1).to({graphics:mask_1_graphics_44,x:160.7,y:35.4}).wait(1).to({graphics:mask_1_graphics_45,x:165.1,y:35.4}).wait(1).to({graphics:mask_1_graphics_46,x:169.5,y:35.4}).wait(1).to({graphics:mask_1_graphics_47,x:173.9,y:35.4}).wait(1).to({graphics:mask_1_graphics_48,x:178.3,y:35.4}).wait(1).to({graphics:mask_1_graphics_49,x:182.7,y:35.4}).wait(1).to({graphics:mask_1_graphics_50,x:187.1,y:35.4}).wait(1).to({graphics:mask_1_graphics_51,x:191.5,y:35.4}).wait(1).to({graphics:mask_1_graphics_52,x:195.9,y:35.4}).wait(1).to({graphics:mask_1_graphics_53,x:200.3,y:35.4}).wait(1).to({graphics:mask_1_graphics_54,x:204.8,y:35.4}).wait(1).to({graphics:mask_1_graphics_55,x:209.2,y:35.4}).wait(1).to({graphics:mask_1_graphics_56,x:213.6,y:35.4}).wait(1).to({graphics:mask_1_graphics_57,x:218,y:35.4}).wait(1).to({graphics:mask_1_graphics_58,x:222.4,y:35.4}).wait(1).to({graphics:mask_1_graphics_59,x:226.8,y:35.4}).wait(1).to({graphics:null,x:0,y:0}).wait(1));

	// Ebene 3
	this.instance_1 = new lib.text03();
	this.instance_1.setTransform(266.1,74.2,1,1,0,0,0,266.1,74.2);

	this.instance_1.mask = mask_1;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({alpha:0},59).to({_off:true},1).wait(1));

	// Ebene 5
	this.instance_2 = new lib.text03_();
	this.instance_2.setTransform(266.1,74.2,1,1,0,0,0,266.1,74.2);

	this.instance_2.mask = mask_1;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(61));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-21,-21,1.6,114);


(lib.ani_text01 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// container_text
	this.instance = new lib.container_text("single",1);
	this.instance.setTransform(550,148.4,1,1,0,0,0,550,148.4);
	this.instance.alpha = 0.5;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({x:867.2},179).wait(1));

	// container_text
	this.instance_1 = new lib.container_text("single",0);
	this.instance_1.setTransform(1615.1,148.4,1,1,0,0,0,550,148.4);
	this.instance_1.alpha = 0.5;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({x:1323.3},179).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0.1,0,2032.3,77.2);


(lib.ani_pic05 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.instance = new lib.container_pics("single",4);
	this.instance.setTransform(706.7,497.9,0.648,0.648,0,0,0,1090.8,768.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({scaleX:1,scaleY:1},999).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,1498.1,1192.5);


(lib.ani_pic04 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.instance = new lib.container_pics("single",3);
	this.instance.setTransform(706.7,497.9,0.648,0.648,0,0,0,1090.8,768.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({scaleX:1,scaleY:1},999).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,1295.8,1030.7);


(lib.ani_pic03 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.instance = new lib.container_pics("single",2);
	this.instance.setTransform(706.7,497.9,0.648,0.648,0,0,0,1090.8,768.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({scaleX:1,scaleY:1},999).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,1295.8,970.5);


(lib.ani_pic01 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.instance = new lib.container_pics("single",0);
	this.instance.setTransform(706.7,497.9,0.648,0.648,0,0,0,1090.8,768.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({scaleX:1,scaleY:1},999).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-129.1,-46.9,1424.9,756.9);


(lib.ani_intro = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// Ebene 19
	this.instance = new lib.ani_text04("synched",0,false);
	this.instance.setTransform(906.6,520.4,1,1,0,0,0,266.1,74.2);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(185).to({_off:false},0).wait(108).to({startPosition:60},0).to({alpha:0},26).to({_off:true},1).wait(358));

	// Ebene 20
	this.instance_1 = new lib.text01();
	this.instance_1.setTransform(683.7,124.2,1,1,0,0,0,483.7,74.2);
	this.instance_1._off = true;

	this.instance_2 = new lib.ani_text03("synched",0,false);
	this.instance_2.setTransform(906.6,463.3,1,1,0,0,0,266.1,74.2);
	this.instance_2._off = true;

	this.instance_3 = new lib.ani_text07("synched",0,false);
	this.instance_3.setTransform(906.6,666.3,1,1,0,0,0,266.1,74.2);
	this.instance_3._off = true;

	this.instance_4 = new lib.ani_text10("synched",0,false);
	this.instance_4.setTransform(916.3,596.3,1,1,0,0,0,266.1,74.2);
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(148).to({_off:false},0).to({alpha:0},19).to({_off:true},1).wait(510));
	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(173).to({_off:false},0).wait(120).to({startPosition:60},0).to({alpha:0},26).to({_off:true},1).wait(358));
	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(364).to({_off:false},0).wait(71).to({startPosition:60},0).to({alpha:0},22).to({_off:true},1).wait(220));
	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(584).to({_off:false},0).wait(60).to({startPosition:60},0).to({alpha:0},22).to({_off:true},1).wait(11));

	// Ebene 21
	this.instance_5 = new lib.container_text("single",0);
	this.instance_5.setTransform(700,198.4,1,1,0,0,0,500,148.4);
	this.instance_5._off = true;

	this.instance_6 = new lib.ani_text06("synched",0,false);
	this.instance_6.setTransform(906.6,596.4,1,1,0,0,0,266.1,74.2);
	this.instance_6._off = true;

	this.instance_7 = new lib.ani_text09("synched",0,false);
	this.instance_7.setTransform(916.3,518.3,1,1,0,0,0,266.1,74.2);
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(148).to({_off:false},0).wait(145).to({startPosition:0},0).to({alpha:0},26).to({_off:true},1).wait(358));
	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(347).to({_off:false},0).wait(88).to({startPosition:60},0).to({alpha:0},22).to({_off:true},1).wait(220));
	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(570).to({_off:false},0).wait(74).to({startPosition:60},0).to({alpha:0},22).to({_off:true},1).wait(11));

	// Ebene 23
	this.instance_8 = new lib.ani_text01("synched",0);
	this.instance_8.setTransform(212670.5,16454.4,15,15,0,0,0,15152.2,1112.9);
	this.instance_8._off = true;

	this.instance_9 = new lib.ani_text05("synched",0,false);
	this.instance_9.setTransform(906.6,516.4,1,1,0,0,0,266.1,74.2);
	this.instance_9._off = true;

	this.instance_10 = new lib.ani_text08("synched",0,false);
	this.instance_10.setTransform(916.3,596.3,1,1,0,0,0,266.1,74.2);
	this.instance_10._off = true;

	this.instance_11 = new lib.ani_pic05("synched",26,false);
	this.instance_11.setTransform(601.2,182,0.953,0.952,0,0,0,647.9,354.9);
	this.instance_11._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(58).to({_off:false},0).wait(46).to({startPosition:46},0).to({regY:1113,scaleX:1.63,scaleY:1.63,x:23466.9,y:1837.9,startPosition:89},43,cjs.Ease.get(-1)).to({_off:true},1).wait(530));
	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(332).to({_off:false},0).wait(103).to({startPosition:60},0).to({alpha:0},22).to({_off:true},1).wait(220));
	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(470).to({_off:false},0).wait(70).to({startPosition:60},0).to({alpha:0},23).to({_off:true},1).wait(114));
	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(566).to({_off:false},0).wait(78).to({startPosition:104},0).to({regX:647.6,regY:354.8,scaleX:2.64,scaleY:2.64,x:-143.8,y:-202,alpha:0,startPosition:223},22).to({_off:true},1).wait(11));

	// Ebene 24
	this.instance_12 = new lib.ani_pic01("synched",0,false);
	this.instance_12.setTransform(607.9,353,1,1,0,0,0,647.9,355);
	this.instance_12.alpha = 0;

	this.instance_13 = new lib.ani_pic03("synched",56,false);
	this.instance_13.setTransform(617.2,158,0.953,0.952,0,0,0,647.9,354.9);
	this.instance_13._off = true;

	this.instance_14 = new lib.ani_pic04("synched",54,false);
	this.instance_14.setTransform(617.2,100,0.953,0.952,0,0,0,647.9,354.9);
	this.instance_14._off = true;

	this.instance_15 = new lib.container_pics("single",5);
	this.instance_15.setTransform(310,160,0.645,0.645,0,0,0,0.1,0.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_12}]}).to({state:[{t:this.instance_12}]},19).to({state:[{t:this.instance_12}]},274).to({state:[{t:this.instance_12}]},25).to({state:[]},1).to({state:[{t:this.instance_13}]},3).to({state:[{t:this.instance_13}]},113).to({state:[{t:this.instance_13}]},22).to({state:[]},1).to({state:[{t:this.instance_14}]},2).to({state:[{t:this.instance_14}]},80).to({state:[{t:this.instance_14}]},23).to({state:[]},1).to({state:[{t:this.instance_15}]},80).wait(34));
	this.timeline.addTween(cjs.Tween.get(this.instance_12).to({alpha:1,startPosition:19},19).wait(274).to({startPosition:390},0).to({regX:647.7,regY:354.9,scaleX:3.02,scaleY:3.02,x:893.5,y:468.8,alpha:0,startPosition:322},25,cjs.Ease.get(1)).to({_off:true},1).wait(359));
	this.timeline.addTween(cjs.Tween.get(this.instance_13).wait(322).to({_off:false},0).wait(113).to({startPosition:169},0).to({alpha:0,startPosition:191},22).to({_off:true},1).wait(220));
	this.timeline.addTween(cjs.Tween.get(this.instance_14).wait(460).to({_off:false},0).wait(80).to({startPosition:134},0).to({regX:647.8,regY:354.8,scaleX:2.28,scaleY:2.28,x:124.8,y:-268.4,alpha:0,startPosition:297},23).to({_off:true},1).wait(114));

	// Ebene 2
	this.instance_16 = new lib.ani_pic03("synched",27,false);
	this.instance_16.setTransform(617.2,158,0.953,0.952,0,0,0,647.9,354.9);

	this.instance_17 = new lib.ani_pic04("synched",27,false);
	this.instance_17.setTransform(617.2,99.9,0.953,0.952,0,0,0,647.9,354.9);

	this.instance_18 = new lib.ani_pic05("synched",0,false);
	this.instance_18.setTransform(601.2,182,0.953,0.952,0,0,0,647.9,354.9);

	this.instance_19 = new lib.container_text("single",10);
	this.instance_19.setTransform(662.1,188.2,1,1,0,0,0,500,123.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_16}]},293).to({state:[]},29).to({state:[{t:this.instance_17}]},113).to({state:[]},25).to({state:[{t:this.instance_18}]},80).to({state:[]},26).to({state:[{t:this.instance_19}]},78).wait(34));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-169.1,-48.9,1424.9,756.9);


// stage content:



(lib.c1p1 = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{Sa:9,end:681});

	// Ebene 24
	this.button_gotoAndPlay_parent_end = new lib.button_skip();
	this.button_gotoAndPlay_parent_end.setTransform(1048,671,1,1,0,0,0,150,25);

	this.menuButtonWidget = new lib.button_home();
	this.menuButtonWidget.setTransform(956,668.5,1,1,0,0,0,58,22.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.button_gotoAndPlay_parent_end}]},9).to({state:[{t:this.menuButtonWidget}]},672).wait(13));

	// label
	this.instance = new lib.ani_intro("synched",0,false);
	this.instance.setTransform(609,351.5,1,1,0,0,0,609,351.5);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(9).to({_off:false},0).wait(685));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;

})(lib = lib||{}, images = images||{}, createjs = createjs||{}, ss = ss||{});
var lib, images, createjs, ss;