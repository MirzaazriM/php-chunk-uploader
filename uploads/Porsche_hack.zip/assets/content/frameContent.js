(function (lib, img, cjs, ss) {

var p; // shortcut to reference prototypes
lib.webFontTxtInst = {}; 
var loadedTypekitCount = 0;
var loadedGoogleCount = 0;
var gFontsUpdateCacheList = [];
var tFontsUpdateCacheList = [];

// library properties:
lib.properties = {
	width: 1218,
	height: 803,
	fps: 25,
	color: "#000000",
	opacity: 1.00,
	webfonts: {},
	manifest: [
		{src:"assets/content/images/c1p1_pic01.jpg", id:"c1p1_pic01"},
		{src:"assets/content/images/c1p1_pic03.jpg", id:"c1p1_pic03"},
		{src:"assets/content/images/c1p1_pic04.jpg", id:"c1p1_pic04"},
		{src:"assets/content/images/c1p1_pic05.jpg", id:"c1p1_pic05"},
		{src:"assets/content/images/impressum_pic.jpg", id:"impressum_pic"},
		{src:"assets/content/images/logo_porsche.png", id:"logo_porsche"},
		{src:"assets/content/images/pic_chapter02.jpg", id:"pic_chapter02"},
		{src:"assets/content/images/pic_chapter03.jpg", id:"pic_chapter03"},
		{src:"assets/content/images/pic_chapter04.jpg", id:"pic_chapter04"},
		{src:"assets/content/images/pic_chapter05.jpg", id:"pic_chapter05"},
		{src:"assets/content/images/pic_chapter06.jpg", id:"pic_chapter06"},
		{src:"assets/content/images/pic_chapter07.jpg", id:"pic_chapter07"},
		{src:"assets/content/images/pic_chapter08.jpg", id:"pic_chapter08"},
		{src:"assets/content/images/pic_menu01.png", id:"pic_menu01"}
	]
};



lib.ssMetadata = [];



lib.updateListCache = function (cacheList) {		
	for(var i = 0; i < cacheList.length; i++) {		
		if(cacheList[i].cacheCanvas)		
			cacheList[i].updateCache();		
	}		
};		

lib.addElementsToCache = function (textInst, cacheList) {		
	var cur = textInst;		
	while(cur != exportRoot) {		
		if(cacheList.indexOf(cur) != -1)		
			break;		
		cur = cur.parent;		
	}		
	if(cur != exportRoot) {	//we have found an element in the list		
		var cur2 = textInst;		
		var index = cacheList.indexOf(cur);		
		while(cur2 != cur) { //insert all it's children just before it		
			cacheList.splice(index, 0, cur2);		
			cur2 = cur2.parent;		
			index++;		
		}		
	}		
	else {	//append element and it's parents in the array		
		cur = textInst;		
		while(cur != exportRoot) {		
			cacheList.push(cur);		
			cur = cur.parent;		
		}		
	}		
};		

lib.gfontAvailable = function(family, totalGoogleCount) {		
	lib.properties.webfonts[family] = true;		
	var txtInst = lib.webFontTxtInst && lib.webFontTxtInst[family] || [];		
	for(var f = 0; f < txtInst.length; ++f)		
		lib.addElementsToCache(txtInst[f], gFontsUpdateCacheList);		

	loadedGoogleCount++;		
	if(loadedGoogleCount == totalGoogleCount) {		
		lib.updateListCache(gFontsUpdateCacheList);		
	}		
};		

lib.tfontAvailable = function(family, totalTypekitCount) {		
	lib.properties.webfonts[family] = true;		
	var txtInst = lib.webFontTxtInst && lib.webFontTxtInst[family] || [];		
	for(var f = 0; f < txtInst.length; ++f)		
		lib.addElementsToCache(txtInst[f], tFontsUpdateCacheList);		

	loadedTypekitCount++;		
	if(loadedTypekitCount == totalTypekitCount) {		
		lib.updateListCache(tFontsUpdateCacheList);		
	}		
};
// symbols:



(lib.c1p1_pic01 = function() {
	this.initialize(img.c1p1_pic01);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2000,1096);


(lib.c1p1_pic03 = function() {
	this.initialize(img.c1p1_pic03);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2000,1498);


(lib.c1p1_pic04 = function() {
	this.initialize(img.c1p1_pic04);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2000,1591);


(lib.c1p1_pic05 = function() {
	this.initialize(img.c1p1_pic05);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2000,1500);


(lib.impressum_pic = function() {
	this.initialize(img.impressum_pic);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1078,285);


(lib.logo_porsche = function() {
	this.initialize(img.logo_porsche);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,206,104);


(lib.pic_chapter02 = function() {
	this.initialize(img.pic_chapter02);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,270,150);


(lib.pic_chapter03 = function() {
	this.initialize(img.pic_chapter03);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,270,150);


(lib.pic_chapter04 = function() {
	this.initialize(img.pic_chapter04);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,270,150);


(lib.pic_chapter05 = function() {
	this.initialize(img.pic_chapter05);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,270,150);


(lib.pic_chapter06 = function() {
	this.initialize(img.pic_chapter06);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,270,150);


(lib.pic_chapter07 = function() {
	this.initialize(img.pic_chapter07);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,270,150);


(lib.pic_chapter08 = function() {
	this.initialize(img.pic_chapter08);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,270,150);


(lib.pic_menu01 = function() {
	this.initialize(img.pic_menu01);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1000,545);


(lib.wrapperBackground = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EhfJA+uMAAAh9cMC+SAAAMAAAB9cg");
	this.shape.setTransform(609,401.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,1218,803);


(lib.ProgressMediator = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// background
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#666666").s().p("AzXE5IAApxMAmuAAAIAAJxg");
	this.shape.setTransform(122.6,30.9);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1.4,-0.4,248,62.7);


(lib.MobileStartMediator = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#737278").s().p("AvnzhIfOTeI/OTlg");
	this.shape.setTransform(100,125);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,200,250);


(lib.LogoMediator = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#CCCCCC").ss(1,0,0,3).p("EgonAAAMBRPAAA");
	this.shape.setTransform(938,78);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#CCCCCC").ss(1,2,0,3,true).p("EgonAAAMBRPAAA");
	this.shape_1.setTransform(280,78);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Ebene 2
	this.instance = new lib.logo_porsche();
	this.instance.parent = this;
	this.instance.setTransform(558,30,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Ebene 3
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("EhfJAHzIAAvmMC+SAAAIAAPmg");
	this.shape_2.setTransform(609,50);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,1218,100);


(lib.chapterDuration = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// durationTextfield
	this.durationTextfield = new cjs.Text("5 min", "12px 'Porsche Next TT'", "#FFFFFF");
	this.durationTextfield.name = "durationTextfield";
	this.durationTextfield.textAlign = "center";
	this.durationTextfield.lineHeight = 18;
	this.durationTextfield.lineWidth = 46;
	this.durationTextfield.parent = this;
	this.durationTextfield.setTransform(30,5);

	this.timeline.addTween(cjs.Tween.get(this.durationTextfield).wait(1));

	// background
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#737278").s().p("AkrB9IAAj5IJXAAIAAD5g");
	this.shape.setTransform(30,12.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,60,25);


(lib.sitemapBtn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#403F45").s().p("Ah8BaIAAgUID5AAIAAAUgAh8AJIAAgRID5AAIAAARgAh8hFIAAgUID5AAIAAAUg");
	this.shape.setTransform(12.5,9);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,25,18);


(lib.scroller_handle = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D5001C").s().p("AgsCVIAAkqIBZAAIAAEqg");
	this.shape.setTransform(4.5,15);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,9,30);


(lib.scroller_back_info02 = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CCCCCC").s().p("EgAYApyMAAAhTkIAxAAMAAABTkg");
	this.shape.setTransform(2.5,267.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,5,535);


(lib.scroller_back = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CCCCCC").s().p("EgAYAhlMAAAhDJIAxAAMAAABDJg");
	this.shape.setTransform(2.5,215);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,5,430);


(lib.pics_circles = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// Ebene 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(1,1,1).p("AA8AAQAAAYgSASQgSASgYAAQgXAAgSgSQgSgSAAgYQAAgXASgSQASgSAXAAQAYAAASASQASASAAAXg");
	this.shape.setTransform(6,6);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(2));

	// Ebene 1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#D5001C").s().p("AgpAqQgSgSAAgYQAAgXASgSQASgSAXAAQAYAAASASQARASAAAXQAAAYgRASQgSARgYAAQgXAAgSgRg");
	this.shape_1.setTransform(6,6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#403F45").s().p("AgpAqQgSgSAAgYQAAgXASgSQASgSAXAAQAYAAASASQARASAAAXQAAAYgRASQgSARgYAAQgXAAgSgRg");
	this.shape_2.setTransform(6,6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1}]}).to({state:[{t:this.shape_2}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-1,14,14);


(lib.pic_shadow_round_occlusion = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#000000","rgba(0,0,0,0)"],[0,1],0,0,0,0,0,221.2).s().p("A4LYMQqCqBAAuLQAAuKKCqBQKBqCOKAAQOLAAKBKCQKCKBAAOKQAAOLqCKBQqBKCuLAAQuKAAqBqCg");
	this.shape.setTransform(219.1,219.1);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,438.1,438.1);


(lib.pic_shadow_occlusionRound = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#000000","rgba(0,0,0,0)"],[0,1],0,0,0,0,0,102.5).s().p("AsTMUQlGlHgBnNQABnMFGlHQFHlGHMgBQHNABFHFGQFGFHABHMQgBHNlGFHQlHFGnNABQnMgBlHlGg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-111.5,-111.5,223,223);


(lib.pic_plane_white = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EgtOAq9MAAAhV6MBacAAAMAAABV6g");
	this.shape.setTransform(289.5,275);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,579,550);


(lib.pic_plane_black = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("EgtOAq9MAAAhV6MBacAAAMAAABV6g");
	this.shape.setTransform(289.5,275);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,579,550);


(lib.pic_MarginCover = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EhzKBO7MAAAid1MDmVAAAMAAACd1gEhfEA5BMC+IAAAMAAAhtlMi+IAAAg");
	this.shape.setTransform(609,437.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-128.1,-67.6,1474.4,1010.3);


(lib.pic_cover_fullscreen = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EhfJA26MAAAht0MC+SAAAMAAABt0g");
	this.shape.setTransform(609,351.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,1218,703);


(lib.overview_state = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{state0:0,state1:6,state2:12});

	// Ebene 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#737278").ss(1,2,0,3).p("ABGAAQAAAdgVAUQgUAVgdAAQgcAAgUgVQgVgUAAgdQAAgcAVgUQAUgVAcAAQAdAAAUAVQAVAUAAAcg");
	this.shape.setTransform(7,7);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(18));

	// Ebene 1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#B5B3B9").s().p("AgNAxQgVgVAAgcQAAgcAVgUQASgVAeAAIAACLQgegBgSgUg");
	this.shape_1.setTransform(3.5,7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#737278").ss(1,2,0,3).p("ABGAAQAAAdgVAUQgUAVgdAAQgcAAgUgVQgVgUAAgdQAAgcAVgUQAUgVAcAAQAdAAAUAVQAVAUAAAcg");
	this.shape_2.setTransform(7,7);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#B5B3B9").s().p("AgwAxQgVgVAAgcQAAgcAVgUQAUgVAcAAQAcAAAVAVQAUAUABAcQgBAcgUAVQgVAUgcABQgcgBgUgUg");
	this.shape_3.setTransform(7,7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_1}]},6).to({state:[{t:this.shape_3},{t:this.shape_2}]},6).wait(6));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-1,16,16);


(lib.container_text = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// Ebene 66
	this.frameText_75 = new cjs.Text("Die Porsche AG mißt dem Schutz Ihrer Privat- und Persönlichkeitssphäre höchste Bedeutung bei. Die Einhaltung gesetzlicher Regelungen über den Datenschutz ist für uns daher selbstverständlich.\n\n\nErhebung und Verarbeitung persönlicher Daten\n\nPersonenbezogene Daten werden nur erhoben, soweit diese für Ihre Aktivitäten in der Porsche Academy notwendig sind.\n\nDie Nutzung dieser Daten bleibt auf Trainingszwecke der Porsche Konzerngesellschaften und der Porsche Handelsorganisation beschränkt. Ihre Daten werden nicht verkauft, vermietet oder in anderer Weise Dritten zur Verfügung gestellt. Übermittlungen personenbezogener Daten an staatliche Einrichtungen und Behörden erfolgen nur im Rahmen zwingender nationaler Rechtsvorschriften. Unsere Mitarbeiter, Agenturen und Händler sind von uns zu strengster Vertraulichkeit verpflichtet.\n\n\nSicherheit\n\nPorsche setzt technische und organisatorische Sicherheitsmaßnahmen ein, um Ihre durch uns verwalteten Daten gegen zufällige oder vorsätzliche Manipulationen, Verlust, Zerstörung oder vor dem Zugriff unberechtigter Personen zu schützen.\n\nUnsere Sicherheitsmaßnahmen werden entsprechend der technologischen Entwicklung fortlaufend verbessert.\n\n\nCopyright Hinweise\n\nAlle Texte, Bilder, Audio-Dateien und weitere hier veröffentlichte Informationen, mit Ausnahme der gekennzeichneten Artikel, unterliegen dem Copyright der Dr. Ing. h.c. F. Porsche AG, Deutschland. Eine Reproduktion oder Wiedergabe des Ganzen oder von Teilen ist ohne die schriftliche Genehmigung der Dr. Ing. h.c. F. Porsche AG nicht gestattet. Der Porsche Schriftzug und das Porsche Wappen sind geschützte Marken der Dr. Ing. h.c. F. Porsche AG.\n\n\nAnbieter\n\nDr. Ing. h.c. F. Porsche AG\nPorscheplatz 1\nD-70435 Stuttgart\nTel: (+49) 0711 911-0\n\nvertreten durch den Vorstand:\nDr. Oliver Blume, Vorsitzender\nLutz Meschke, stv. Vorsitzender\nWolfgang Hatz \nDetlev von Platen\nUwe-Karsten Städter\nAndreas Haffner\n\nRegistergericht: Amtsgericht Stuttgart\nHRB-Nr. 5211\nUSt.-Ident.-Nr. DE 147 799 625\n\nE-Mail: info@porsche.de", "16px 'Porsche Next TT'");
	this.frameText_75.name = "frameText_75";
	this.frameText_75.lineHeight = 23;
	this.frameText_75.lineWidth = 516;
	this.frameText_75.parent = this;
	this.frameText_75.setTransform(2,2);
	this.frameText_75._off = true;

	this.timeline.addTween(cjs.Tween.get(this.frameText_75).wait(74).to({_off:false},0).to({_off:true},1).wait(2));

	// Ebene 65
	this.frameText_74 = new cjs.Text("Datenschutz", "20px 'Porsche Next TT Thin'");
	this.frameText_74.name = "frameText_74";
	this.frameText_74.lineHeight = 29;
	this.frameText_74.lineWidth = 516;
	this.frameText_74.parent = this;
	this.frameText_74.setTransform(2,2);
	this.frameText_74._off = true;

	this.timeline.addTween(cjs.Tween.get(this.frameText_74).wait(73).to({_off:false},0).to({_off:true},1).wait(3));

	// Ebene 64
	this.frameText_73 = new cjs.Text("Der Porsche Schriftzug, das Porsche Wappen, Porsche, 911, Carrera, Targa, 918 Spyder, Boxster, Cayman, Cayenne, Macan, Panamera, Tiptronic und Tequipment sind eingetragene Marken derDr. Ing. h.c. F. Porsche AG.\n\nDie abgebildeten Fahrzeugmodelle zeigen die Ausstattung für die Bundesrepublik Deutschland. Sie enthalten z.B. auch Sonderausstattungen, die nicht zum serienmäßigen Lieferumfang gehören und nur gegen Aufpreis erhältlich sind. In verschiedenen Ländern sind aufgrund länderspezifischer Bestimmungen und Auflagen nicht alle Modelle verfügbar. Bitte informieren Sie sich über die in ihrem Markt oder Land lieferbaren Modelle und den genauen Ausstattungsumfang.\n\nÄnderungen von Konstruktion, Ausstattung und Lieferumfang sowie Abweichungen im Farbton bleiben vorbehalten. Alle angegeben Preise sind unverbindlich.\n\nDr. Ing. h.c. F. Porsche AG\nPorscheplatz 1\nD-70435 Stuttgart\n\n", "16px 'Porsche Next TT'");
	this.frameText_73.name = "frameText_73";
	this.frameText_73.lineHeight = 23;
	this.frameText_73.lineWidth = 516;
	this.frameText_73.parent = this;
	this.frameText_73.setTransform(2,2);
	this.frameText_73._off = true;

	this.timeline.addTween(cjs.Tween.get(this.frameText_73).wait(72).to({_off:false},0).to({_off:true},1).wait(4));

	// Ebene 63
	this.frameText_72 = new cjs.Text("Rechtshinweis", "20px 'Porsche Next TT Thin'");
	this.frameText_72.name = "frameText_72";
	this.frameText_72.lineHeight = 29;
	this.frameText_72.lineWidth = 516;
	this.frameText_72.parent = this;
	this.frameText_72.setTransform(2,2);
	this.frameText_72._off = true;

	this.timeline.addTween(cjs.Tween.get(this.frameText_72).wait(71).to({_off:false},0).to({_off:true},1).wait(5));

	// Ebene 62
	this.frameText_71 = new cjs.Text("Impressum schließen", "16px 'Porsche Next TT'", "#B5B3B9");
	this.frameText_71.name = "frameText_71";
	this.frameText_71.textAlign = "right";
	this.frameText_71.lineHeight = 23;
	this.frameText_71.lineWidth = 356;
	this.frameText_71.parent = this;
	this.frameText_71.setTransform(358,2);
	this.frameText_71._off = true;

	this.timeline.addTween(cjs.Tween.get(this.frameText_71).wait(70).to({_off:false},0).to({_off:true},1).wait(6));

	// Ebene 61
	this.frameText_70 = new cjs.Text("Rechtliche Hinweise und Impressum", "30px 'Porsche Next TT Thin'");
	this.frameText_70.name = "frameText_70";
	this.frameText_70.textAlign = "center";
	this.frameText_70.lineHeight = 44;
	this.frameText_70.lineWidth = 1006;
	this.frameText_70.parent = this;
	this.frameText_70.setTransform(505,2);
	this.frameText_70._off = true;

	this.timeline.addTween(cjs.Tween.get(this.frameText_70).wait(69).to({_off:false},0).to({_off:true},1).wait(7));

	// Ebene 31
	this.frameText_53 = new cjs.Text("Menü schließen", "16px 'Porsche Next TT'", "#B5B3B9");
	this.frameText_53.name = "frameText_53";
	this.frameText_53.lineHeight = 23;
	this.frameText_53.lineWidth = 356;
	this.frameText_53.parent = this;
	this.frameText_53.setTransform(2,2);
	this.frameText_53._off = true;

	this.timeline.addTween(cjs.Tween.get(this.frameText_53).wait(52).to({_off:false},0).to({_off:true},1).wait(24));

	// Ebene 30
	this.frameText_52 = new cjs.Text("Themenübersicht", "16px 'Porsche Next TT'", "#B5B3B9");
	this.frameText_52.name = "frameText_52";
	this.frameText_52.textAlign = "right";
	this.frameText_52.lineHeight = 23;
	this.frameText_52.lineWidth = 377;
	this.frameText_52.parent = this;
	this.frameText_52.setTransform(379,2);
	this.frameText_52._off = true;

	this.timeline.addTween(cjs.Tween.get(this.frameText_52).wait(51).to({_off:false},0).to({_off:true},1).wait(25));

	// Ebene 29
	this.frameText_51 = new cjs.Text("Menü ", "16px 'Porsche Next TT'", "#B5B3B9");
	this.frameText_51.name = "frameText_51";
	this.frameText_51.lineHeight = 23;
	this.frameText_51.lineWidth = 376;
	this.frameText_51.parent = this;
	this.frameText_51.setTransform(2,2);
	this.frameText_51._off = true;

	this.timeline.addTween(cjs.Tween.get(this.frameText_51).wait(50).to({_off:false},0).to({_off:true},1).wait(26));

	// Ebene 35
	this.frameText_50 = new cjs.Text("Menü", "20px 'Porsche Next TT Thin'");
	this.frameText_50.name = "frameText_50";
	this.frameText_50.lineHeight = 29;
	this.frameText_50.lineWidth = 436;
	this.frameText_50.parent = this;
	this.frameText_50.setTransform(2,2);
	this.frameText_50._off = true;

	this.timeline.addTween(cjs.Tween.get(this.frameText_50).wait(49).to({_off:false},0).to({_off:true},1).wait(27));

	// Ebene 20
	this.frameText_32 = new cjs.Text("Kapitel abgeschlossen", "16px 'Porsche Next TT'");
	this.frameText_32.name = "frameText_32";
	this.frameText_32.textAlign = "right";
	this.frameText_32.lineHeight = 23;
	this.frameText_32.lineWidth = 264;
	this.frameText_32.parent = this;
	this.frameText_32.setTransform(266,2);
	this.frameText_32._off = true;

	this.timeline.addTween(cjs.Tween.get(this.frameText_32).wait(31).to({_off:false},0).to({_off:true},1).wait(45));

	// Ebene 8
	this.frameText_31 = new cjs.Text("Kapitel teilweise bearbeitet", "16px 'Porsche Next TT'");
	this.frameText_31.name = "frameText_31";
	this.frameText_31.textAlign = "right";
	this.frameText_31.lineHeight = 23;
	this.frameText_31.lineWidth = 264;
	this.frameText_31.parent = this;
	this.frameText_31.setTransform(266,2);
	this.frameText_31._off = true;

	this.timeline.addTween(cjs.Tween.get(this.frameText_31).wait(30).to({_off:false},0).to({_off:true},1).wait(46));

	// Ebene 7
	this.frameText_30 = new cjs.Text("Kapitel unbearbeitet", "16px 'Porsche Next TT'");
	this.frameText_30.name = "frameText_30";
	this.frameText_30.textAlign = "right";
	this.frameText_30.lineHeight = 23;
	this.frameText_30.lineWidth = 264;
	this.frameText_30.parent = this;
	this.frameText_30.setTransform(266,2);
	this.frameText_30._off = true;

	this.timeline.addTween(cjs.Tween.get(this.frameText_30).wait(29).to({_off:false},0).to({_off:true},1).wait(47));

	// Ebene 36
	this.frameText_29 = new cjs.Text("Durch Klick auf diesen Pfeil werden weitere Inhalte, wie zum Beispiel Pop-up-Fenster, Verlinkungen oder folgende Seiten geöffnet. Im Bildschirmtext finden Sie hierzu jeweils entsprechende Anweisungen.", "16px 'Porsche Next TT'");
	this.frameText_29.name = "frameText_29";
	this.frameText_29.lineHeight = 25;
	this.frameText_29.lineWidth = 416;
	this.frameText_29.parent = this;
	this.frameText_29.setTransform(2,2);
	this.frameText_29._off = true;

	this.timeline.addTween(cjs.Tween.get(this.frameText_29).wait(28).to({_off:false},0).to({_off:true},1).wait(48));

	// Ebene 18
	this.frameText_28 = new cjs.Text("Durch Klick auf diesen Pfeil werden weitere Inhalte, wie zum Beispiel Popup-Fenster, Verlinkungen oder folgende Seiten geöffnet.", "16px 'Porsche Next TT'");
	this.frameText_28.name = "frameText_28";
	this.frameText_28.lineHeight = 25;
	this.frameText_28.lineWidth = 416;
	this.frameText_28.parent = this;
	this.frameText_28.setTransform(2,2);
	this.frameText_28._off = true;

	this.timeline.addTween(cjs.Tween.get(this.frameText_28).wait(27).to({_off:false},0).to({_off:true},1).wait(49));

	// Ebene 26
	this.frameText_27 = new cjs.Text("This button on the left expands a text field with additional information. Please note that you do not find an expanding text field on every page of the training program.", "16px 'Porsche Next TT'");
	this.frameText_27.name = "frameText_27";
	this.frameText_27.lineHeight = 23;
	this.frameText_27.lineWidth = 386;
	this.frameText_27.parent = this;
	this.frameText_27.setTransform(2,2);
	this.frameText_27._off = true;

	this.timeline.addTween(cjs.Tween.get(this.frameText_27).wait(26).to({_off:false},0).to({_off:true},1).wait(50));

	// Ebene 25
	this.frameText_26 = new cjs.Text("This button on the left expands a text field with additional information. Please note that you do not find an expanding text field on every page of the training program.", "16px 'Porsche Next TT'");
	this.frameText_26.name = "frameText_26";
	this.frameText_26.lineHeight = 23;
	this.frameText_26.lineWidth = 386;
	this.frameText_26.parent = this;
	this.frameText_26.setTransform(2,2);
	this.frameText_26._off = true;

	this.timeline.addTween(cjs.Tween.get(this.frameText_26).wait(25).to({_off:false},0).to({_off:true},1).wait(51));

	// Ebene 24
	this.frameText_25 = new cjs.Text("Use the menu to select the learning modules of this online training directly. The menu also provides an overview of your learning progress: grey check – module not yet worked on; red check: module  started but not yet completed; green check – module completed.", "16px 'Porsche Next TT'");
	this.frameText_25.name = "frameText_25";
	this.frameText_25.lineHeight = 23;
	this.frameText_25.lineWidth = 386;
	this.frameText_25.parent = this;
	this.frameText_25.setTransform(2,2);
	this.frameText_25._off = true;

	this.timeline.addTween(cjs.Tween.get(this.frameText_25).wait(24).to({_off:false},0).to({_off:true},1).wait(52));

	// Ebene 23
	this.frameText_24 = new cjs.Text("The “Forward and backward” control bar at the bottom enables you to navigate scene by scene through each module – forward and backward.  Use the opening and closing parentheses. Alternatively, you may just jump to a scene by using one of the dots.", "16px 'Porsche Next TT'");
	this.frameText_24.name = "frameText_24";
	this.frameText_24.lineHeight = 25;
	this.frameText_24.lineWidth = 416;
	this.frameText_24.parent = this;
	this.frameText_24.setTransform(2,2);
	this.frameText_24._off = true;

	this.timeline.addTween(cjs.Tween.get(this.frameText_24).wait(23).to({_off:false},0).to({_off:true},1).wait(53));

	// Ebene 16
	this.frameText_22 = new cjs.Text("Die Themenübersicht zeigt alle Lernstrecken dieses Online-Trainings auf einen Blick. Daneben bietet sie einen Überblick über die durchschnittliche Bearbeitungsdauer der Lernstrecken sowie Ihren Bearbeitungsfortschritt im Online-Training. ", "16px 'Porsche Next TT'");
	this.frameText_22.name = "frameText_22";
	this.frameText_22.lineHeight = 23;
	this.frameText_22.lineWidth = 516;
	this.frameText_22.parent = this;
	this.frameText_22.setTransform(2,2);
	this.frameText_22._off = true;

	this.timeline.addTween(cjs.Tween.get(this.frameText_22).wait(21).to({_off:false},0).to({_off:true},1).wait(55));

	// Ebene 15
	this.frameText_21 = new cjs.Text("Sie können das Porsche Online-Training jederzeit nach einem abgeschlossenen Kapitel unterbrechen und zu einem späteren Zeitpunkt fortsetzen. Die abgeschlossenen Kapitel erkennen Sie im Menü an einem ausgefüllten Kreissymbol hinter dem Kapitelnamen. Zusätzlich zum Kreissymbol im Menü können begonnene bzw. abgeschlossene Kapitel durch die rote Färbung der Statusanziege in den Kapitelkacheln erkannt werden.", "16px 'Porsche Next TT'");
	this.frameText_21.name = "frameText_21";
	this.frameText_21.lineHeight = 25;
	this.frameText_21.lineWidth = 516;
	this.frameText_21.parent = this;
	this.frameText_21.setTransform(2,2);
	this.frameText_21._off = true;

	this.timeline.addTween(cjs.Tween.get(this.frameText_21).wait(20).to({_off:false},0).to({_off:true},1).wait(56));

	// Ebene 14
	this.frameText_20 = new cjs.Text("Im Online-Training erschließen Sie sich Inhalte und nützliche Informationen durch Kapitel. Zur Bearbeitung der Kapitel können Sie diese wahlweise über die Themenübersicht bzw. das Menü aufrufen, oder indem Sie der empfohlenen Route folgen. \n", "16px 'Porsche Next TT'");
	this.frameText_20.name = "frameText_20";
	this.frameText_20.lineHeight = 25;
	this.frameText_20.lineWidth = 516;
	this.frameText_20.parent = this;
	this.frameText_20.setTransform(2,2);
	this.frameText_20._off = true;

	this.timeline.addTween(cjs.Tween.get(this.frameText_20).wait(19).to({_off:false},0).to({_off:true},1).wait(57));

	// Ebene 34
	this.frameText_17 = new cjs.Text("Möchten Sie das Online-Training nun beenden?", "16px 'Porsche Next TT'");
	this.frameText_17.name = "frameText_17";
	this.frameText_17.lineHeight = 23;
	this.frameText_17.lineWidth = 356;
	this.frameText_17.parent = this;
	this.frameText_17.setTransform(2,2);
	this.frameText_17._off = true;

	this.timeline.addTween(cjs.Tween.get(this.frameText_17).wait(16).to({_off:false},0).to({_off:true},1).wait(60));

	// Ebene 4
	this.frameText_16 = new cjs.Text("...", "36px 'Porsche Next TT Thin'");
	this.frameText_16.name = "frameText_16";
	this.frameText_16.textAlign = "center";
	this.frameText_16.lineHeight = 53;
	this.frameText_16.lineWidth = 1122;
	this.frameText_16.parent = this;
	this.frameText_16.setTransform(563,2);
	this.frameText_16._off = true;

	this.timeline.addTween(cjs.Tween.get(this.frameText_16).wait(15).to({_off:false},0).to({_off:true},1).wait(61));

	// Ebene 5
	this.frameText_15 = new cjs.Text("Impressum", "18px 'Porsche Next TT'");
	this.frameText_15.name = "frameText_15";
	this.frameText_15.textAlign = "center";
	this.frameText_15.lineHeight = 26;
	this.frameText_15.lineWidth = 126;
	this.frameText_15.parent = this;
	this.frameText_15.setTransform(65,2);
	this.frameText_15._off = true;

	this.timeline.addTween(cjs.Tween.get(this.frameText_15).wait(14).to({_off:false},0).to({_off:true},1).wait(62));

	// Ebene 9
	this.frameText_14 = new cjs.Text("Hilfe", "18px 'Porsche Next TT'");
	this.frameText_14.name = "frameText_14";
	this.frameText_14.textAlign = "center";
	this.frameText_14.lineHeight = 26;
	this.frameText_14.lineWidth = 126;
	this.frameText_14.parent = this;
	this.frameText_14.setTransform(65,2);
	this.frameText_14._off = true;

	this.timeline.addTween(cjs.Tween.get(this.frameText_14).wait(13).to({_off:false},0).to({_off:true},1).wait(63));

	// Ebene 33
	this.frameText_13 = new cjs.Text("ja", "16px 'Porsche Next TT'");
	this.frameText_13.name = "frameText_13";
	this.frameText_13.textAlign = "center";
	this.frameText_13.lineHeight = 23;
	this.frameText_13.lineWidth = 111;
	this.frameText_13.parent = this;
	this.frameText_13.setTransform(57.5,2);
	this.frameText_13._off = true;

	this.timeline.addTween(cjs.Tween.get(this.frameText_13).wait(12).to({_off:false},0).to({_off:true},1).wait(64));

	// Ebene 32
	this.frameText_12 = new cjs.Text("nein", "16px 'Porsche Next TT'");
	this.frameText_12.name = "frameText_12";
	this.frameText_12.textAlign = "center";
	this.frameText_12.lineHeight = 23;
	this.frameText_12.lineWidth = 111;
	this.frameText_12.parent = this;
	this.frameText_12.setTransform(57.5,2);
	this.frameText_12._off = true;

	this.timeline.addTween(cjs.Tween.get(this.frameText_12).wait(11).to({_off:false},0).to({_off:true},1).wait(65));

	// Ebene 22
	this.frameText_11 = new cjs.Text("Glückwunsch! Sie haben alle Themen bearbeitet. \n\nSie kennen nun die Highlights des Porsche Macan (MJ 19) Facelift:\n\n• durchgängiges 3D-Leuchtenband am Heck \n• LED-Hauptscheinwerfer serienmäßig\n• 3,0-Liter V6-Monoturbo-Ottomotor  (Macan S)\n• Ottopartikelfilter \n• neues PCM 5.1 mit hochauflösendem 10,9-Zoll-Touchdisplay \n\nneue Assistenzsysteme: \n• Fußgängerwarnung \n• Anhaltewegverkürzung (AWV) \n• Stauassistent,\n• Spurhalteassistent", "16px 'Porsche Next TT'");
	this.frameText_11.name = "frameText_11";
	this.frameText_11.lineHeight = 23;
	this.frameText_11.lineWidth = 438;
	this.frameText_11.parent = this;
	this.frameText_11.setTransform(2,2);
	this.frameText_11._off = true;

	this.timeline.addTween(cjs.Tween.get(this.frameText_11).wait(10).to({_off:false},0).to({_off:true},1).wait(66));

	// Ebene 21
	this.frameText_10 = new cjs.Text("Bitte sehen Sie sich zuerst alle Inhalte an, bevor Sie das Quiz bearbeiten.", "16px 'Porsche Next TT'");
	this.frameText_10.name = "frameText_10";
	this.frameText_10.lineHeight = 23;
	this.frameText_10.lineWidth = 266;
	this.frameText_10.parent = this;
	this.frameText_10.setTransform(2,2);
	this.frameText_10._off = true;

	this.timeline.addTween(cjs.Tween.get(this.frameText_10).wait(9).to({_off:false},0).to({_off:true},1).wait(67));

	// Ebene 28
	this.frameText_09 = new cjs.Text("Navigationselemente", "24px 'Porsche Next TT Thin'");
	this.frameText_09.name = "frameText_09";
	this.frameText_09.lineHeight = 35;
	this.frameText_09.lineWidth = 1076;
	this.frameText_09.parent = this;
	this.frameText_09.setTransform(2,2);
	this.frameText_09._off = true;

	this.timeline.addTween(cjs.Tween.get(this.frameText_09).wait(8).to({_off:false},0).to({_off:true},1).wait(68));

	// Ebene 27
	this.frameText_08 = new cjs.Text("Die Themenübersicht", "24px 'Porsche Next TT Thin'");
	this.frameText_08.name = "frameText_08";
	this.frameText_08.lineHeight = 35;
	this.frameText_08.lineWidth = 1076;
	this.frameText_08.parent = this;
	this.frameText_08.setTransform(2,2);
	this.frameText_08._off = true;

	this.timeline.addTween(cjs.Tween.get(this.frameText_08).wait(7).to({_off:false},0).to({_off:true},1).wait(69));

	// Ebene 13
	this.frameText_07 = new cjs.Text("Das Konzept", "24px 'Porsche Next TT Thin'");
	this.frameText_07.name = "frameText_07";
	this.frameText_07.lineHeight = 35;
	this.frameText_07.lineWidth = 1076;
	this.frameText_07.parent = this;
	this.frameText_07.setTransform(2,2);
	this.frameText_07._off = true;

	this.timeline.addTween(cjs.Tween.get(this.frameText_07).wait(6).to({_off:false},0).to({_off:true},1).wait(70));

	// Ebene 12
	this.frameText_06 = new cjs.Text("Hilfe schließen", "16px 'Porsche Next TT'", "#B5B3B9");
	this.frameText_06.name = "frameText_06";
	this.frameText_06.textAlign = "right";
	this.frameText_06.lineHeight = 23;
	this.frameText_06.lineWidth = 356;
	this.frameText_06.parent = this;
	this.frameText_06.setTransform(358,2);
	this.frameText_06._off = true;

	this.timeline.addTween(cjs.Tween.get(this.frameText_06).wait(5).to({_off:false},0).to({_off:true},1).wait(71));

	// Ebene 11
	this.frameText_05 = new cjs.Text("Hilfe ", "30px 'Porsche Next TT Thin'");
	this.frameText_05.name = "frameText_05";
	this.frameText_05.textAlign = "center";
	this.frameText_05.lineHeight = 44;
	this.frameText_05.lineWidth = 350;
	this.frameText_05.parent = this;
	this.frameText_05.setTransform(177,2);
	this.frameText_05._off = true;

	this.timeline.addTween(cjs.Tween.get(this.frameText_05).wait(4).to({_off:false},0).to({_off:true},1).wait(72));

	// Ebene 10
	this.chapterTitleTextfield = new cjs.Text("Chapter Title", "18px 'Porsche Next TT'", "#FFFFFF");
	this.chapterTitleTextfield.name = "chapterTitleTextfield";
	this.chapterTitleTextfield.lineHeight = 26;
	this.chapterTitleTextfield.lineWidth = 362;
	this.chapterTitleTextfield.parent = this;
	this.chapterTitleTextfield.setTransform(2,2);
	this.chapterTitleTextfield._off = true;

	this.timeline.addTween(cjs.Tween.get(this.chapterTitleTextfield).wait(3).to({_off:false},0).to({_off:true},1).wait(73));

	// Ebene 3
	this.frameText_03 = new cjs.Text(".", "30px 'Porsche Next TT Thin'");
	this.frameText_03.name = "frameText_03";
	this.frameText_03.textAlign = "center";
	this.frameText_03.lineHeight = 44;
	this.frameText_03.lineWidth = 1122;
	this.frameText_03.parent = this;
	this.frameText_03.setTransform(563,2);
	this.frameText_03._off = true;

	this.timeline.addTween(cjs.Tween.get(this.frameText_03).wait(2).to({_off:false},0).to({_off:true},1).wait(74));

	// Ebene 2
	this.frameText_02 = new cjs.Text("weitere Infos", "16px 'Porsche Next TT'", "#D5001C");
	this.frameText_02.name = "frameText_02";
	this.frameText_02.textAlign = "center";
	this.frameText_02.lineHeight = 23;
	this.frameText_02.lineWidth = 166;
	this.frameText_02.parent = this;
	this.frameText_02.setTransform(85,2);
	this.frameText_02._off = true;

	this.timeline.addTween(cjs.Tween.get(this.frameText_02).wait(1).to({_off:false},0).to({_off:true},1).wait(75));

	// Ebene 1
	this.frameText_01 = new cjs.Text("Menü", "30px 'Porsche Next TT Thin'");
	this.frameText_01.name = "frameText_01";
	this.frameText_01.textAlign = "center";
	this.frameText_01.lineHeight = 44;
	this.frameText_01.lineWidth = 596;
	this.frameText_01.parent = this;
	this.frameText_01.setTransform(300,2);

	this.timeline.addTween(cjs.Tween.get(this.frameText_01).to({_off:true},1).wait(76));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,600,47.9);


(lib.container_pics = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// Ebene 4 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_1 = new cjs.Graphics().p("A1FLuIAA3bMAqLAAAIAAXbg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(1).to({graphics:mask_graphics_1,x:135,y:75}).wait(7).to({graphics:null,x:0,y:0}).wait(6));

	// Ebene 2
	this.instance = new lib.pic_chapter02();
	this.instance.parent = this;

	this.instance_1 = new lib.pic_chapter03();
	this.instance_1.parent = this;

	this.instance_2 = new lib.pic_chapter04();
	this.instance_2.parent = this;

	this.instance_3 = new lib.pic_chapter05();
	this.instance_3.parent = this;

	this.instance_4 = new lib.pic_chapter06();
	this.instance_4.parent = this;

	this.instance_5 = new lib.pic_chapter07();
	this.instance_5.parent = this;

	this.instance_6 = new lib.pic_chapter08();
	this.instance_6.parent = this;

	this.instance_7 = new lib.impressum_pic();
	this.instance_7.parent = this;

	this.instance.mask = this.instance_1.mask = this.instance_2.mask = this.instance_3.mask = this.instance_4.mask = this.instance_5.mask = this.instance_6.mask = this.instance_7.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).to({state:[]},1).to({state:[{t:this.instance_7}]},3).to({state:[]},1).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-253.3,0,1321.9,576.8);


(lib.Chaptertitle = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// text
	this.chapterTitleTextfield = new cjs.Text("Chapter Title gggggg", "16px 'Porsche Next TT'", "#FFFFFF");
	this.chapterTitleTextfield.name = "chapterTitleTextfield";
	this.chapterTitleTextfield.lineHeight = 23;
	this.chapterTitleTextfield.lineWidth = 226;
	this.chapterTitleTextfield.parent = this;
	this.chapterTitleTextfield.setTransform(2,2);

	this.timeline.addTween(cjs.Tween.get(this.chapterTitleTextfield).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,230,27.5);


(lib.btn_blind_circle = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EgzuAZyMAAAgzjMBndAAAMAAAAzjg");
	this.shape.setTransform(331.1,165);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(3).to({_off:false},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.btn_blind = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D5001C").s().p("Aj5D6IAAnzIHzAAIAAHzg");
	this.shape.setTransform(25,25);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(3).to({_off:false},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.ani_progress = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 9
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D5001C").s().p("ArqAZIAAgxIXVAAIAAAxg");
	this.shape.setTransform(74.7,2.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#D5001C").s().p("A3bAZIAAgxMAu2AAAIAAAxg");
	this.shape_1.setTransform(150,2.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},49).to({state:[]},1).to({state:[{t:this.shape_1}]},49).wait(1));

	// Ebene 7
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#B5B3B9").s().p("A3bAZIAAgxMAu2AAAIAAAxg");
	this.shape_2.setTransform(150,2.5);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).to({_off:true},1).wait(48).to({_off:false},0).to({_off:true},1).wait(49).to({_off:false},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,300,5);


(lib.BackgroundMediator = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// Ebene 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EhfJA+uMAAAh9cMC+SAAAMAAAB9cg");
	this.shape.setTransform(609,401.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,1218,803);


(lib.NextBtnMediator = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// background
	this.instance = new lib.btn_blind();
	this.instance.parent = this;
	this.instance.setTransform(-25,-25);
	new cjs.ButtonHelper(this.instance, 0, 1, 2, false, new lib.btn_blind(), 3);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Ebene 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D5001C").s().p("AhMCaIBeiaIheiZIA7AAIBeCZIheCag");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-25,-25,50,50);


(lib.sitemapChapterItem = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// chapterIcon
	this.instance = new lib.btn_blind();
	this.instance.parent = this;
	this.instance.setTransform(0,0,12,0.8);
	new cjs.ButtonHelper(this.instance, 0, 1, 2, false, new lib.btn_blind(), 3);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// chapterDuration
	this.chapterIcon = new lib.overview_state();
	this.chapterIcon.parent = this;
	this.chapterIcon.setTransform(592,21,1,1,0,0,0,7,7);

	this.timeline.addTween(cjs.Tween.get(this.chapterIcon).wait(1));

	// chapterTitleTextfield
	this.chapterTitleTextfield = new cjs.Text("Chapter Title gggggg", "18px 'Porsche Next TT Thin'", "#333333");
	this.chapterTitleTextfield.name = "chapterTitleTextfield";
	this.chapterTitleTextfield.lineHeight = 26;
	this.chapterTitleTextfield.lineWidth = 546;
	this.chapterTitleTextfield.parent = this;
	this.chapterTitleTextfield.setTransform(12,10);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#666666").ss(1,2,0,3,true).p("Egu3AAAMBdvAAA");
	this.shape.setTransform(300,40);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.chapterTitleTextfield}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,0,602,41);


(lib.chapterItemThumbnail = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{c1:0,c2:5,c3:10,c4:15,c5:20,c6:25,c7:30});

	// Ebene 2
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(0,0,0,0.498)","rgba(0,0,0,0)"],[0.502,1],3.9,31.1,3.9,-36.3).s().p("A1EFCIAAqDMAqJAAAIAAKDg");
	this.shape.setTransform(135,117.7);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(35));

	// thumbnail
	this.instance = new lib.container_pics("single",1);
	this.instance.parent = this;
	this.instance.setTransform(150,73.5,1,1,0,0,0,150,73.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(5).to({startPosition:2},0).wait(5).to({startPosition:3},0).wait(5).to({startPosition:4},0).wait(5).to({startPosition:5},0).wait(5).to({startPosition:6},0).wait(5).to({startPosition:7},0).wait(5));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,270,150);


(lib.chapterIcon = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"state0":0,"state1":6,"state2":12});

	// icon
	this.instance = new lib.ani_progress("single",0);
	this.instance.parent = this;
	this.instance.setTransform(24,24,1,1,0,0,0,24,24);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(6).to({startPosition:49},0).wait(6).to({startPosition:99},0).wait(6));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,300,5);


(lib.ImprintBtnMediator = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 3
	this.instance = new lib.container_text("single",14);
	this.instance.parent = this;
	this.instance.setTransform(119.5,16,1,1,0,0,0,119.5,16);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({_off:true},3).wait(1));

	// Ebene 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D5001C").s().p("AqJEsIAApXIUSAAIAAJXg");
	this.shape.setTransform(65,30);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(3).to({_off:false},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,130,60);


(lib.HelpBtnMediator = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 3
	this.instance = new lib.container_text("single",13);
	this.instance.parent = this;
	this.instance.setTransform(119.5,16,1,1,0,0,0,119.5,16);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({_off:true},3).wait(1));

	// Ebene 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D5001C").s().p("AqJEsIAApXIUSAAIAAJXg");
	this.shape.setTransform(65,30);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(3).to({_off:false},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,130,60);


(lib.stepBtn = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// Ebene 2
	this.instance = new lib.btn_blind_circle();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.182,0.182,0,0,0,55,55);
	new cjs.ButtonHelper(this.instance, 0, 1, 2, false, new lib.btn_blind_circle(), 3);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(2));

	// Ebene 1
	this.instance_1 = new lib.pics_circles("single",1);
	this.instance_1.parent = this;
	this.instance_1.setTransform(0,0,1,1,0,0,0,6,6);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({startPosition:0},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-10,-10,120.4,60);


(lib.sitemapOnBtn = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// btn_blind
	this.instance = new lib.btn_blind();
	this.instance.parent = this;
	this.instance.setTransform(107.5,7.2,8.601,0.8,0,0,0,12.5,9);
	new cjs.ButtonHelper(this.instance, 0, 1, 2, false, new lib.btn_blind(), 3);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// icon
	this.instance_1 = new lib.sitemapBtn();
	this.instance_1.parent = this;
	this.instance_1.setTransform(20,20,1,1,0,0,0,12.5,9);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	// container_text
	this.instance_2 = new lib.container_text("single",50);
	this.instance_2.parent = this;
	this.instance_2.setTransform(613,825.9,1,1,0,0,0,563,818.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,430.1,40);


(lib.sitemapContent = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.sitemapChapterItem = new lib.sitemapChapterItem();
	this.sitemapChapterItem.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.sitemapChapterItem).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.6,0,601.3,40.7);


(lib.scroller_imprint_help = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.slider = new lib.scroller_handle();
	this.slider.parent = this;

	this.bg = new lib.scroller_back_info02();
	this.bg.parent = this;
	this.bg.setTransform(2,0);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.bg},{t:this.slider}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,9,535);


(lib.scroller = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.slider = new lib.scroller_handle();
	this.slider.parent = this;

	this.bg = new lib.scroller_back();
	this.bg.parent = this;
	this.bg.setTransform(2,0);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.bg},{t:this.slider}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,9,430);


(lib.pics_icons = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 2
	this.instance = new lib.pics_circles("single",1);
	this.instance.parent = this;
	this.instance.setTransform(69.6,15.9,0.5,0.5,0,0,0,6,6);

	this.instance_1 = new lib.pics_circles("single",1);
	this.instance_1.parent = this;
	this.instance_1.setTransform(56.5,15.9,0.5,0.5,0,0,0,6,6);

	this.instance_2 = new lib.pics_circles("single",1);
	this.instance_2.parent = this;
	this.instance_2.setTransform(43.3,15.9,0.5,0.5,0,0,0,6,6);

	this.instance_3 = new lib.pics_circles("single",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(30.2,15.9,0.5,0.5,0,0,0,6,6);

	this.instance_4 = new lib.pics_circles("single",1);
	this.instance_4.parent = this;
	this.instance_4.setTransform(17,15.9,0.5,0.5,0,0,0,6,6);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D5001C").s().p("AglBNIAuhNIguhMIAdAAIAuBMIguBNg");
	this.shape.setTransform(82.8,15.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#D5001C").s().p("AAJBNIguhNIAuhMIAdAAIgtBMIAtBNg");
	this.shape_1.setTransform(3.9,15.9);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#403F45").ss(1.5,2,1).p("AB0h1Ih0B0IB3B3AAAgBIh3B3Ah0h1IB0B0");
	this.shape_2.setTransform(12,11.8);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#403F45").s().p("Ah8BaIAAgUID5AAIAAAUgAh8AJIAAgRID5AAIAAARgAh8hFIAAgUID5AAIAAAUg");
	this.shape_3.setTransform(12.5,9);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgNBLIAAg9Ig9AAIAAgbIA9AAIAAg9IAbAAIAAA9IA9AAIAAAbIg9AAIAAA9g");
	this.shape_4.setTransform(17.5,17.5);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#FFFFFF").ss(1,0,0,4).p("AAAiuQBIAAAzA0QA0AzAABHQAABIg0AzQgzA0hIAAQhHAAgzg0Qg0gzAAhIQAAhHA0gzQAzg0BHAAg");
	this.shape_5.setTransform(17.5,17.5);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#D5001C").s().p("Ah6B7Qg0gzAAhIQAAhHA0gzQAzg0BHAAQBIAAAzA0QAzAzABBHQgBBIgzAzQgzAzhIABQhHgBgzgzg");
	this.shape_6.setTransform(17.5,17.5);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#403F45").ss(1.5,2,0,3).p("AA5h1Ih0B0IB3B3");
	this.shape_7.setTransform(6,11.8);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#D5001C").s().p("Aj5FeIAAq7IHzAAIAAK7gAAlAAIhkB9IAbAAIBlh9Ihlh8IgbAAg");
	this.shape_8.setTransform(25,35);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("Ag/B9IBkh9Ihkh8IAbAAIBlB8IhlB9g");
	this.shape_9.setTransform(25,35);

	this.instance_5 = new lib.container_text("single",39);
	this.instance_5.parent = this;
	this.instance_5.setTransform(169.5,26,1,1,0,0,0,119.5,16);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#D5001C").s().p("AhAB9IBlh9Ihlh8IAcAAIBkB8IhkB9g");
	this.shape_10.setTransform(6.5,12.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[]},1).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4}]},1).to({state:[]},1).to({state:[{t:this.shape_7}]},6).to({state:[{t:this.shape_9},{t:this.shape_8}]},1).to({state:[{t:this.shape_10},{t:this.instance_5}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,8.2,86.7,15.5);


(lib.infoMenuContent = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// ImprintBtnMediator
	this.ImprintBtnMediator = new lib.ImprintBtnMediator();
	this.ImprintBtnMediator.parent = this;
	this.ImprintBtnMediator.setTransform(263,85.1,1,1,0,0,0,48,17.3);
	new cjs.ButtonHelper(this.ImprintBtnMediator, 0, 1, 2, false, new lib.ImprintBtnMediator(), 3);

	this.timeline.addTween(cjs.Tween.get(this.ImprintBtnMediator).wait(1));

	// HelpBtnMediator
	this.HelpBtnMediator = new lib.HelpBtnMediator();
	this.HelpBtnMediator.parent = this;
	this.HelpBtnMediator.setTransform(113.1,85.1,1,1,0,0,0,48,17.3);
	new cjs.ButtonHelper(this.HelpBtnMediator, 0, 1, 2, false, new lib.HelpBtnMediator(), 3);

	this.timeline.addTween(cjs.Tween.get(this.HelpBtnMediator).wait(1));

	// HelpBtnMediator
	this.instance = new lib.btn_blind();
	this.instance.parent = this;
	this.instance.setTransform(0,30,24.36,2.2);
	new cjs.ButtonHelper(this.instance, 0, 1, 2, false, new lib.btn_blind(), 3);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Ebene 8
	this.instance_1 = new lib.pic_plane_white();
	this.instance_1.parent = this;
	this.instance_1.setTransform(608.8,85.3,2.104,0.2,0,0,0,289.4,276.3);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,30,1218,110);


(lib.imrint_content = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// container_text
	this.instance = new lib.container_text("single",74);
	this.instance.parent = this;
	this.instance.setTransform(1022.4,406.5,1,1,0,0,0,462.4,45);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// container_text
	this.instance_1 = new lib.container_text("single",73);
	this.instance_1.parent = this;
	this.instance_1.setTransform(1022.4,356,1,1,0,0,0,462.4,45);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	// container_text
	this.instance_2 = new lib.container_text("single",72);
	this.instance_2.parent = this;
	this.instance_2.setTransform(462.4,406.5,1,1,0,0,0,462.4,45);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

	// container_text
	this.instance_3 = new lib.container_text("single",71);
	this.instance_3.parent = this;
	this.instance_3.setTransform(462.4,356,1,1,0,0,0,462.4,45);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(1));

	// container_pics
	this.instance_4 = new lib.container_pics("single",11);
	this.instance_4.parent = this;
	this.instance_4.setTransform(724,477.5,1,1,0,0,0,724,477.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(1));

	// Ebene 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EhUNCLtMAAAkXZMCobAAAMAAAEXZg");
	this.shape.setTransform(539,894.2);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,1080,1788.3);


(lib.help_content = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// Ebene 3
	this.instance = new lib.pics_icons("single",13);
	this.instance.parent = this;
	this.instance.setTransform(103.5,1026);

	this.instance_1 = new lib.pics_icons("single",2);
	this.instance_1.parent = this;
	this.instance_1.setTransform(670.5,680);

	this.instance_2 = new lib.pics_icons("single",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(110,710,1,1,0,0,0,40,30);

	this.instance_3 = new lib.pics_icons("single",4);
	this.instance_3.parent = this;
	this.instance_3.setTransform(92.5,870);

	this.instance_4 = new lib.pics_icons("single",12);
	this.instance_4.parent = this;
	this.instance_4.setTransform(665.9,870,0.654,0.654,0,0,0,0.1,0);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	// Ebene 1
	this.instance_5 = new lib.container_text("single",28);
	this.instance_5.parent = this;
	this.instance_5.setTransform(170,1026);

	this.instance_6 = new lib.container_text("single",27);
	this.instance_6.parent = this;
	this.instance_6.setTransform(170,870);

	this.instance_7 = new lib.container_text("single",26);
	this.instance_7.parent = this;
	this.instance_7.setTransform(760,870);

	this.instance_8 = new lib.container_text("single",8);
	this.instance_8.parent = this;
	this.instance_8.setTransform(532.4,665,1,1,0,0,0,462.4,45);

	this.instance_9 = new lib.container_text("single",24);
	this.instance_9.parent = this;
	this.instance_9.setTransform(760,680);

	this.instance_10 = new lib.container_text("single",23);
	this.instance_10.parent = this;
	this.instance_10.setTransform(170,680);

	this.instance_11 = new lib.container_text("single",7);
	this.instance_11.parent = this;
	this.instance_11.setTransform(532.4,385,1,1,0,0,0,462.4,45);

	this.instance_12 = new lib.container_text("single",21);
	this.instance_12.parent = this;
	this.instance_12.setTransform(70,380);

	this.instance_13 = new lib.container_text("single",20);
	this.instance_13.parent = this;
	this.instance_13.setTransform(628,60);

	this.instance_14 = new lib.container_text("single",19);
	this.instance_14.parent = this;
	this.instance_14.setTransform(70,60);

	this.instance_15 = new lib.container_text("single",6);
	this.instance_15.parent = this;
	this.instance_15.setTransform(532.4,65,1,1,0,0,0,462.4,45);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_15},{t:this.instance_14},{t:this.instance_13},{t:this.instance_12},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5}]}).wait(1));

	// Ebene 6
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#333333").ss(1,1,1).p("EBUOgV3MiobAAAEBUOAV4MiobAAA");
	this.shape.setTransform(609,420);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Ebene 2
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("EhfJBqUMAAAjUnMC+SAAAMAAADUng");
	this.shape_1.setTransform(609,680.5);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,1218,1360.9);


(lib.container_pics_intro = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 2
	this.instance = new lib.pic_shadow_round_occlusion();
	this.instance.parent = this;
	this.instance.setTransform(923.6,203.4,0.913,0.801,0,-44.6,154.9,219,219);
	this.instance.alpha = 0.18;

	this.instance_1 = new lib.pic_shadow_round_occlusion();
	this.instance_1.parent = this;
	this.instance_1.setTransform(1200.1,183.2,0.913,0.801,0,-44.6,154.9,219.1,219.1);
	this.instance_1.alpha = 0.18;

	this.instance_2 = new lib.pic_shadow_round_occlusion();
	this.instance_2.parent = this;
	this.instance_2.setTransform(171.9,356.9,0.913,0.801,0,-44.6,154.9,219.1,219.1);
	this.instance_2.alpha = 0.18;

	this.instance_3 = new lib.pic_shadow_round_occlusion();
	this.instance_3.parent = this;
	this.instance_3.setTransform(20.1,468,0.913,0.801,0,-44.6,154.9,219.1,219.2);
	this.instance_3.alpha = 0.18;

	this.instance_4 = new lib.pic_shadow_round_occlusion();
	this.instance_4.parent = this;
	this.instance_4.setTransform(519.4,394.8,0.913,0.801,0,-44.6,154.9,219.1,219.2);
	this.instance_4.alpha = 0.18;

	this.instance_5 = new lib.pic_shadow_round_occlusion();
	this.instance_5.parent = this;
	this.instance_5.setTransform(326,439.1,0.913,0.801,0,-44.6,154.9,219.1,219.2);
	this.instance_5.alpha = 0.18;

	this.instance_6 = new lib.pic_shadow_round_occlusion();
	this.instance_6.parent = this;
	this.instance_6.setTransform(802,321.4,0.913,0.801,0,-44.6,154.9,219,219.1);
	this.instance_6.alpha = 0.18;

	this.instance_7 = new lib.pic_shadow_round_occlusion();
	this.instance_7.parent = this;
	this.instance_7.setTransform(883.9,299.3,0.913,0.801,0,-44.6,154.9,219,219.1);
	this.instance_7.alpha = 0.18;

	this.instance_8 = new lib.pic_shadow_round_occlusion();
	this.instance_8.parent = this;
	this.instance_8.setTransform(326,439.1,0.913,0.801,0,-44.6,154.9,219.1,219.2);
	this.instance_8.alpha = 0.18;

	this.instance_9 = new lib.pic_shadow_round_occlusion();
	this.instance_9.parent = this;
	this.instance_9.setTransform(351,328.2,0.913,0.801,0,-44.6,154.9,219.1,219.1);
	this.instance_9.alpha = 0.18;

	this.instance_10 = new lib.pic_shadow_round_occlusion();
	this.instance_10.parent = this;
	this.instance_10.setTransform(1040.9,225.7,0.913,0.801,0,-44.6,154.9,219,219);
	this.instance_10.alpha = 0.18;

	this.instance_11 = new lib.pic_shadow_round_occlusion();
	this.instance_11.parent = this;
	this.instance_11.setTransform(1067.2,161.9,0.913,0.801,0,-44.6,154.9,219.1,219.1);
	this.instance_11.alpha = 0.18;

	this.instance_12 = new lib.pic_shadow_round_occlusion();
	this.instance_12.parent = this;
	this.instance_12.setTransform(727.4,103,1,0.689,0,0,0,219.1,219);
	this.instance_12.alpha = 0.301;

	this.instance_13 = new lib.pic_shadow_round_occlusion();
	this.instance_13.parent = this;
	this.instance_13.setTransform(543.6,271.2,1,0.689,0,0,0,219.1,219.1);
	this.instance_13.alpha = 0.301;

	this.instance_14 = new lib.pic_shadow_round_occlusion();
	this.instance_14.parent = this;
	this.instance_14.setTransform(1175.2,78.6,1,0.689,0,0,0,219.1,219);
	this.instance_14.alpha = 0.301;

	this.instance_15 = new lib.pic_shadow_round_occlusion();
	this.instance_15.parent = this;
	this.instance_15.setTransform(1391.4,111.6,1,0.689,0,0,0,219.1,219);
	this.instance_15.alpha = 0.301;

	this.instance_16 = new lib.pic_shadow_round_occlusion();
	this.instance_16.parent = this;
	this.instance_16.setTransform(918.8,244.6,1,0.689,0,0,0,219.1,219.1);
	this.instance_16.alpha = 0.301;

	this.instance_17 = new lib.pic_shadow_round_occlusion();
	this.instance_17.parent = this;
	this.instance_17.setTransform(1114.9,206.3,1,0.689,0,0,0,219.1,219);
	this.instance_17.alpha = 0.301;

	this.instance_18 = new lib.pic_shadow_round_occlusion();
	this.instance_18.parent = this;
	this.instance_18.setTransform(625.4,293.6,1,0.689,0,0,0,219.1,219.1);
	this.instance_18.alpha = 0.301;

	this.instance_19 = new lib.pic_shadow_round_occlusion();
	this.instance_19.parent = this;
	this.instance_19.setTransform(838.5,166.9,1,0.689,0,0,0,219.1,219);
	this.instance_19.alpha = 0.301;

	this.instance_20 = new lib.pic_shadow_round_occlusion();
	this.instance_20.parent = this;
	this.instance_20.setTransform(1114.9,206.3,1,0.689,0,0,0,219.1,219);
	this.instance_20.alpha = 0.301;

	this.instance_21 = new lib.pic_shadow_round_occlusion();
	this.instance_21.parent = this;
	this.instance_21.setTransform(1003.7,124.3,1,0.689,0,0,0,219.1,219);
	this.instance_21.alpha = 0.301;

	this.instance_22 = new lib.pic_shadow_round_occlusion();
	this.instance_22.parent = this;
	this.instance_22.setTransform(648.6,166.9,1,0.689,0,0,0,219.1,219);
	this.instance_22.alpha = 0.301;

	this.instance_23 = new lib.pic_shadow_round_occlusion();
	this.instance_23.parent = this;
	this.instance_23.setTransform(574.7,124.3,1,0.689,0,0,0,219.1,219);
	this.instance_23.alpha = 0.301;

	this.instance_24 = new lib.pic_menu01();
	this.instance_24.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_23},{t:this.instance_22},{t:this.instance_21},{t:this.instance_20},{t:this.instance_19},{t:this.instance_18},{t:this.instance_17},{t:this.instance_16},{t:this.instance_15},{t:this.instance_14},{t:this.instance_13},{t:this.instance_12},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9,p:{scaleX:0.913,scaleY:0.801,skewX:-44.6,skewY:154.9,x:351,y:328.2,alpha:0.18}},{t:this.instance_8,p:{regY:219.2,scaleX:0.913,scaleY:0.801,skewX:-44.6,skewY:154.9,x:326,y:439.1,alpha:0.18}},{t:this.instance_7,p:{regX:219,scaleX:0.913,scaleY:0.801,skewX:-44.6,skewY:154.9,x:883.9,y:299.3,alpha:0.18}},{t:this.instance_6,p:{regX:219,scaleX:0.913,scaleY:0.801,skewX:-44.6,skewY:154.9,x:802,y:321.4,alpha:0.18}},{t:this.instance_5,p:{regY:219.2,scaleX:0.913,scaleY:0.801,skewX:-44.6,skewY:154.9,x:326,y:439.1,alpha:0.18}},{t:this.instance_4,p:{regY:219.2,scaleX:0.913,scaleY:0.801,skewX:-44.6,skewY:154.9,x:519.4,y:394.8,alpha:0.18}},{t:this.instance_3,p:{regY:219.2,scaleX:0.913,scaleY:0.801,skewX:-44.6,skewY:154.9,x:20.1,y:468,alpha:0.18}},{t:this.instance_2,p:{scaleX:0.913,scaleY:0.801,skewX:-44.6,skewY:154.9,x:171.9,y:356.9,alpha:0.18}},{t:this.instance_1,p:{scaleX:0.913,scaleY:0.801,skewX:-44.6,skewY:154.9,x:1200.1,y:183.2,alpha:0.18}},{t:this.instance,p:{regX:219,regY:219,scaleX:0.913,scaleY:0.801,skewX:-44.6,skewY:154.9,x:923.6,y:203.4,alpha:0.18}}]}).to({state:[]},1).to({state:[{t:this.instance_9,p:{scaleX:2.129,scaleY:1.867,skewX:0,skewY:0,x:1212.9,y:879.4,alpha:0.34}},{t:this.instance_8,p:{regY:219.1,scaleX:2.129,scaleY:1.867,skewX:0,skewY:0,x:1493.4,y:879.4,alpha:0.34}},{t:this.instance_7,p:{regX:219.1,scaleX:2.129,scaleY:1.867,skewX:0,skewY:0,x:1144.9,y:1036.6,alpha:0.34}},{t:this.instance_6,p:{regX:219.1,scaleX:2.129,scaleY:1.867,skewX:0,skewY:0,x:1034.4,y:1176.9,alpha:0.34}},{t:this.instance_5,p:{regY:219.1,scaleX:2.129,scaleY:1.867,skewX:0,skewY:0,x:1752.6,y:1270.4,alpha:0.34}},{t:this.instance_4,p:{regY:219.1,scaleX:2.129,scaleY:1.867,skewX:0,skewY:0,x:1846.1,y:879.4,alpha:0.34}},{t:this.instance_3,p:{regY:219.1,scaleX:2.129,scaleY:1.867,skewX:0,skewY:0,x:1463.6,y:1431.9,alpha:0.34}},{t:this.instance_2,p:{scaleX:2.129,scaleY:1.867,skewX:0,skewY:0,x:1569.9,y:1057.9,alpha:0.34}},{t:this.instance_1,p:{scaleX:2.129,scaleY:1.867,skewX:0,skewY:0,x:1752.6,y:960.2,alpha:0.34}},{t:this.instance,p:{regX:219.1,regY:219.1,scaleX:2.129,scaleY:1.867,skewX:0,skewY:0,x:1379.8,y:1288.3,alpha:0.34}}]},3).to({state:[{t:this.instance_24}]},1).wait(1));

	// Ebene 1
	this.instance_25 = new lib.c1p1_pic01();
	this.instance_25.parent = this;

	this.instance_26 = new lib.c1p1_pic03();
	this.instance_26.parent = this;

	this.instance_27 = new lib.c1p1_pic04();
	this.instance_27.parent = this;

	this.instance_28 = new lib.c1p1_pic05();
	this.instance_28.parent = this;

	this.instance_29 = new lib.pic_shadow_occlusionRound();
	this.instance_29.parent = this;
	this.instance_29.setTransform(60.1,426.4,1.072,0.143,0,0,0,0.1,0.4);

	this.instance_30 = new lib.pic_shadow_occlusionRound();
	this.instance_30.parent = this;
	this.instance_30.setTransform(845.3,481.5,1.072,0.143,0,0,0,0.1,0.4);

	this.instance_31 = new lib.pic_shadow_occlusionRound();
	this.instance_31.parent = this;
	this.instance_31.setTransform(365.2,542.5,1.072,0.143,0,0,0,0.1,0.4);

	this.instance_32 = new lib.pic_shadow_occlusionRound();
	this.instance_32.parent = this;
	this.instance_32.setTransform(314,506.1,3.523,0.47,0,0,0,0.1,0.3);
	this.instance_32.alpha = 0.5;

	this.instance_33 = new lib.pic_shadow_occlusionRound();
	this.instance_33.parent = this;
	this.instance_33.setTransform(228.6,398.9,3.523,0.47,0,0,0,0.1,0.3);
	this.instance_33.alpha = 0.5;

	this.instance_34 = new lib.pic_shadow_occlusionRound();
	this.instance_34.parent = this;
	this.instance_34.setTransform(221.8,413.2,3.523,0.47,0,0,0,0.1,0.3);
	this.instance_34.alpha = 0.5;

	this.instance_35 = new lib.pic_shadow_occlusionRound();
	this.instance_35.parent = this;
	this.instance_35.setTransform(249.2,428.5,3.523,0.47,0,0,0,0.1,0.3);
	this.instance_35.alpha = 0.5;

	this.instance_36 = new lib.pic_shadow_occlusionRound();
	this.instance_36.parent = this;
	this.instance_36.setTransform(270.2,481.1,3.523,0.47,0,0,0,0.1,0.3);
	this.instance_36.alpha = 0.5;

	this.instance_37 = new lib.pic_shadow_occlusionRound();
	this.instance_37.parent = this;
	this.instance_37.setTransform(249.2,458.5,3.523,0.47,0,0,0,0.1,0.3);
	this.instance_37.alpha = 0.5;

	this.instance_38 = new lib.pic_shadow_occlusionRound();
	this.instance_38.parent = this;
	this.instance_38.setTransform(200.4,428.5,3.523,0.47,0,0,0,0.1,0.3);
	this.instance_38.alpha = 0.5;

	this.instance_39 = new lib.pic_shadow_occlusionRound();
	this.instance_39.parent = this;
	this.instance_39.setTransform(139.8,428.5,3.523,0.47,0,0,0,0.1,0.3);
	this.instance_39.alpha = 0.5;

	this.instance_40 = new lib.pic_shadow_occlusionRound();
	this.instance_40.parent = this;
	this.instance_40.setTransform(200.4,428.5,3.523,0.47,0,0,0,0.1,0.3);
	this.instance_40.alpha = 0.5;

	this.instance_41 = new lib.pic_shadow_occlusionRound();
	this.instance_41.parent = this;
	this.instance_41.setTransform(162,434.2,3.523,0.47,0,0,0,0.1,0.3);
	this.instance_41.alpha = 0.5;

	this.instance_42 = new lib.pic_shadow_occlusionRound();
	this.instance_42.parent = this;
	this.instance_42.setTransform(200.4,481.1,3.523,0.47,0,0,0,0.1,0.3);
	this.instance_42.alpha = 0.5;

	this.instance_43 = new lib.pic_shadow_occlusionRound();
	this.instance_43.parent = this;
	this.instance_43.setTransform(221.8,465.7,3.523,0.47,0,0,0,0.1,0.3);
	this.instance_43.alpha = 0.5;

	this.instance_44 = new lib.pic_shadow_occlusionRound();
	this.instance_44.parent = this;
	this.instance_44.setTransform(448.4,518.1,3.523,0.47,0,0,0,0.1,0.3);
	this.instance_44.alpha = 0.5;

	this.instance_45 = new lib.pic_shadow_occlusionRound();
	this.instance_45.parent = this;
	this.instance_45.setTransform(405.2,524.5,3.523,0.47,0,0,0,0.1,0.3);
	this.instance_45.alpha = 0.5;

	this.instance_46 = new lib.pic_shadow_occlusionRound();
	this.instance_46.parent = this;
	this.instance_46.setTransform(382.8,492.7,3.523,0.47,0,0,0,0.1,0.3);
	this.instance_46.alpha = 0.5;

	this.instance_47 = new lib.pic_shadow_occlusionRound();
	this.instance_47.parent = this;
	this.instance_47.setTransform(667.3,465.7,3.523,0.47,0,0,0,0.1,0.3);
	this.instance_47.alpha = 0.5;

	this.instance_48 = new lib.pic_shadow_occlusionRound();
	this.instance_48.parent = this;
	this.instance_48.setTransform(362.3,524.5,3.523,0.47,0,0,0,0.1,0.3);
	this.instance_48.alpha = 0.5;

	this.instance_49 = new lib.pic_shadow_occlusionRound();
	this.instance_49.parent = this;
	this.instance_49.setTransform(533,481.1,3.523,0.47,0,0,0,0.1,0.3);
	this.instance_49.alpha = 0.5;

	this.instance_50 = new lib.pic_shadow_occlusionRound();
	this.instance_50.parent = this;
	this.instance_50.setTransform(649.1,458.5,3.523,0.47,0,0,0,0.1,0.3);
	this.instance_50.alpha = 0.5;

	this.instance_51 = new lib.pic_shadow_occlusionRound();
	this.instance_51.parent = this;
	this.instance_51.setTransform(593.1,481.1,3.523,0.47,0,0,0,0.1,0.3);
	this.instance_51.alpha = 0.5;

	this.instance_52 = new lib.pic_shadow_occlusionRound();
	this.instance_52.parent = this;
	this.instance_52.setTransform(533,506.1,3.523,0.47,0,0,0,0.1,0.3);
	this.instance_52.alpha = 0.5;

	this.instance_53 = new lib.pic_shadow_occlusionRound();
	this.instance_53.parent = this;
	this.instance_53.setTransform(622,481.1,3.523,0.47,0,0,0,0.1,0.3);
	this.instance_53.alpha = 0.5;

	this.instance_54 = new lib.pic_shadow_occlusionRound();
	this.instance_54.parent = this;
	this.instance_54.setTransform(708.3,456.7,2.004,0.267,0,0,0,0.1,0.2);
	this.instance_54.alpha = 0.5;

	this.instance_55 = new lib.pic_shadow_occlusionRound();
	this.instance_55.parent = this;
	this.instance_55.setTransform(845.4,481.1,2.004,0.267,0,0,0,0.1,0.2);
	this.instance_55.alpha = 0.5;

	this.instance_56 = new lib.pic_shadow_occlusionRound();
	this.instance_56.parent = this;
	this.instance_56.setTransform(369.7,540.7,2.004,0.267,0,0,0,0.1,0.2);
	this.instance_56.alpha = 0.5;

	this.instance_57 = new lib.pic_shadow_occlusionRound();
	this.instance_57.parent = this;
	this.instance_57.setTransform(249.3,456.7,2.004,0.267,0,0,0,0.1,0.2);
	this.instance_57.alpha = 0.5;

	this.instance_58 = new lib.pic_shadow_occlusionRound();
	this.instance_58.parent = this;
	this.instance_58.setTransform(164,397.1,2.004,0.267,0,0,0,0.1,0.2);
	this.instance_58.alpha = 0.5;

	this.instance_59 = new lib.pic_shadow_occlusionRound();
	this.instance_59.parent = this;
	this.instance_59.setTransform(59.1,423.7,2.004,0.267,0,0,0,0.1,0.2);
	this.instance_59.alpha = 0.5;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_25}]}).to({state:[]},1).to({state:[{t:this.instance_26}]},1).to({state:[{t:this.instance_27}]},1).to({state:[{t:this.instance_28}]},1).to({state:[{t:this.instance_59},{t:this.instance_58},{t:this.instance_57},{t:this.instance_56},{t:this.instance_55},{t:this.instance_54},{t:this.instance_53},{t:this.instance_52},{t:this.instance_51},{t:this.instance_50},{t:this.instance_49},{t:this.instance_48},{t:this.instance_47},{t:this.instance_46},{t:this.instance_45},{t:this.instance_44},{t:this.instance_43},{t:this.instance_42},{t:this.instance_41},{t:this.instance_40},{t:this.instance_39},{t:this.instance_38},{t:this.instance_37},{t:this.instance_36},{t:this.instance_35},{t:this.instance_34},{t:this.instance_33},{t:this.instance_32},{t:this.instance_31},{t:this.instance_30},{t:this.instance_29}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-284.2,-72.4,2284.3,1168.4);


(lib.btn_infos = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{on:0,off:5});

	// Ebene 4
	this.instance = new lib.btn_blind();
	this.instance.parent = this;
	this.instance.setTransform(0,0,4.199,0.6,0,0,0,0,-0.1);
	new cjs.ButtonHelper(this.instance, 0, 1, 2, false, new lib.btn_blind(), 3);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(5).to({y:30},0).wait(5));

	// Ebene 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D5001C").s().p("AAAgoIh9BrIgBgBIAAgZIB+hrIB/BrIAAAZIgBABg");
	this.shape.setTransform(196.8,13.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#D5001C").s().p("Ah+goIAAgZIABgBIB9BrIB+hrIABABIAAAZIh/Brg");
	this.shape_1.setTransform(196.8,43.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},5).wait(5));

	// Ebene 2
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#D5001C").s().p("A0WAYIAAgvMAotAAAIAAAvg");
	this.shape_2.setTransform(105,27.5,0.806,1);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(5).to({y:57.5},0).wait(5));

	// container_text
	this.instance_1 = new lib.container_text("single",1);
	this.instance_1.parent = this;
	this.instance_1.setTransform(139.5,30,1,1,0,0,0,119.5,30);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(5).to({y:60},0).wait(5));

	// Ebene 3
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AwZCWIAAkrMAgyAAAIAAErg");
	this.shape_3.setTransform(105,45);
	this.shape_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_3).wait(5).to({_off:false},0).wait(5));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,210,30);


(lib.ani_pic05 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.instance = new lib.container_pics_intro("single",4);
	this.instance.parent = this;
	this.instance.setTransform(706.7,497.9,0.648,0.648,0,0,0,1090.8,768.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({scaleX:1,scaleY:1},999).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,1498.1,1192.5);


(lib.ani_pic04 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.instance = new lib.container_pics_intro("single",3);
	this.instance.parent = this;
	this.instance.setTransform(706.7,497.9,0.648,0.648,0,0,0,1090.8,768.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({scaleX:1,scaleY:1},999).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,1295.8,1030.7);


(lib.ani_pic03 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.instance = new lib.container_pics_intro("single",2);
	this.instance.parent = this;
	this.instance.setTransform(706.7,497.9,0.648,0.648,0,0,0,1090.8,768.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({scaleX:1,scaleY:1},999).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,1295.8,970.5);


(lib.ani_pic01 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.instance = new lib.container_pics_intro("single",0);
	this.instance.parent = this;
	this.instance.setTransform(706.7,497.9,0.648,0.648,0,0,0,1090.8,768.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({scaleX:1,scaleY:1},999).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-129.1,-46.9,1424.9,756.9);


(lib.ani_intro = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{start:0});

	// timeline functions:
	this.frame_0 = function() {
		this.loop=true;
	}
	this.frame_774 = function() {
		this.gotoAndPlay("start")
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(774).call(this.frame_774).wait(1));

	// safeFrame
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#D5001C").ss(0.1,1,1).p("EhfJg26MC+TAAAMAAABt1Mi+TAAAg");
	this.shape.setTransform(609,351.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(775));

	// Ebene 23
	this.instance = new lib.ani_pic05("synched",26,false);
	this.instance.parent = this;
	this.instance.setTransform(601.2,182,0.953,0.952,0,0,0,647.9,354.9);
	this.instance._off = true;

	this.instance_1 = new lib.container_pics_intro("single",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(666.7,495.9,0.648,0.648,0,0,0,1090.8,768.5);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(566).to({_off:false},0).wait(78).to({startPosition:104},0).to({regX:647.6,regY:354.8,scaleX:2.64,scaleY:2.64,x:-143.8,y:-202,alpha:0,startPosition:223},22).to({_off:true},1).wait(108));
	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(763).to({_off:false},0).to({alpha:1},11).wait(1));

	// Ebene 24
	this.instance_2 = new lib.ani_pic01("synched",0,false);
	this.instance_2.parent = this;
	this.instance_2.setTransform(607.9,353,1,1,0,0,0,647.9,355);

	this.instance_3 = new lib.ani_pic03("synched",56,false);
	this.instance_3.parent = this;
	this.instance_3.setTransform(617.2,158,0.953,0.952,0,0,0,647.9,354.9);
	this.instance_3._off = true;

	this.instance_4 = new lib.ani_pic04("synched",54,false);
	this.instance_4.parent = this;
	this.instance_4.setTransform(617.2,100,0.953,0.952,0,0,0,647.9,354.9);
	this.instance_4._off = true;

	this.instance_5 = new lib.container_pics_intro("single",5);
	this.instance_5.parent = this;
	this.instance_5.setTransform(310,160,0.645,0.645,0,0,0,0.1,0.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2}]}).to({state:[{t:this.instance_2}]},293).to({state:[{t:this.instance_2}]},25).to({state:[]},1).to({state:[{t:this.instance_3}]},3).to({state:[{t:this.instance_3}]},113).to({state:[{t:this.instance_3}]},22).to({state:[]},1).to({state:[{t:this.instance_4}]},2).to({state:[{t:this.instance_4}]},80).to({state:[{t:this.instance_4}]},23).to({state:[]},1).to({state:[{t:this.instance_5}]},80).wait(131));
	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(293).to({startPosition:293},0).to({regX:647.7,regY:354.9,scaleX:3.02,scaleY:3.02,x:893.5,y:468.8,alpha:0,startPosition:322},25,cjs.Ease.get(1)).to({_off:true},1).wait(456));
	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(322).to({_off:false},0).wait(113).to({startPosition:169},0).to({alpha:0,startPosition:191},22).to({_off:true},1).wait(317));
	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(460).to({_off:false},0).wait(80).to({startPosition:134},0).to({regX:647.8,regY:354.8,scaleX:2.28,scaleY:2.28,x:124.8,y:-268.4,alpha:0,startPosition:297},23).to({_off:true},1).wait(211));

	// Ebene 2
	this.instance_6 = new lib.ani_pic03("synched",27,false);
	this.instance_6.parent = this;
	this.instance_6.setTransform(617.2,158,0.953,0.952,0,0,0,647.9,354.9);

	this.instance_7 = new lib.ani_pic04("synched",27,false);
	this.instance_7.parent = this;
	this.instance_7.setTransform(617.2,99.9,0.953,0.952,0,0,0,647.9,354.9);

	this.instance_8 = new lib.ani_pic05("synched",0,false);
	this.instance_8.parent = this;
	this.instance_8.setTransform(601.2,182,0.953,0.952,0,0,0,647.9,354.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_6}]},293).to({state:[]},29).to({state:[{t:this.instance_7}]},113).to({state:[]},25).to({state:[{t:this.instance_8}]},80).to({state:[]},26).wait(209));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-169.1,-48.9,1424.9,756.9);


(lib.allSeenMessage = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// ExitBtn
	this.noBtn = new lib.btn_blind();
	this.noBtn.parent = this;
	this.noBtn.setTransform(944,590,2.3,0.549,0,0,0,0.1,0);
	new cjs.ButtonHelper(this.noBtn, 0, 1, 2, false, new lib.btn_blind(), 3);

	this.instance = new lib.container_text("single",11);
	this.instance.parent = this;
	this.instance.setTransform(1506.7,1295.5,1,1,0,0,0,563,705.5);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D5001C").s().p("AgtBZIgBgBIBKhYIhKhXIABgBIARAAIBLBYIhLBZg");
	this.shape.setTransform(969,603.7);

	this.yesBtn = new lib.btn_blind();
	this.yesBtn.parent = this;
	this.yesBtn.setTransform(782.3,590,2.3,0.549,0,0,0,0.1,0);
	new cjs.ButtonHelper(this.yesBtn, 0, 1, 2, false, new lib.btn_blind(), 3);

	this.instance_1 = new lib.container_text("single",12);
	this.instance_1.parent = this;
	this.instance_1.setTransform(1345,1295.5,1,1,0,0,0,563,705.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#D5001C").s().p("AgtBZIgBgBIBKhYIhKhXIABgBIARAAIBLBYIhLBZg");
	this.shape_1.setTransform(807.3,603.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.instance_1},{t:this.yesBtn},{t:this.shape},{t:this.instance},{t:this.noBtn}]}).wait(1));

	// text
	this.instance_2 = new lib.container_text("single",16);
	this.instance_2.parent = this;
	this.instance_2.setTransform(1242,1229.7,1,1,0,0,0,563,705.5);

	this.instance_3 = new lib.container_text("single",10);
	this.instance_3.parent = this;
	this.instance_3.setTransform(1242,795.5,1,1,0,0,0,563,705.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_3},{t:this.instance_2}]}).wait(1));

	// bg
	this.instance_4 = new lib.pic_plane_white();
	this.instance_4.parent = this;
	this.instance_4.setTransform(920.6,365.2,0.9,1.073,0,0,0,289.8,275.2);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(1));

	// blocker
	this.instance_5 = new lib.pic_plane_black();
	this.instance_5.parent = this;
	this.instance_5.setTransform(609,351.5,2.104,1.278,0,0,0,289.5,275);
	this.instance_5.alpha = 0.801;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,1218,703);


(lib.NavigationMediator = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// stepBtn
	this.stepBtn = new lib.stepBtn();
	this.stepBtn.parent = this;
	this.stepBtn.setTransform(608.5,678);

	this.timeline.addTween(cjs.Tween.get(this.stepBtn).wait(1));

	// nextBtn
	this.nextBtn = new lib.NextBtnMediator();
	this.nextBtn.parent = this;
	this.nextBtn.setTransform(1193,678);

	this.timeline.addTween(cjs.Tween.get(this.nextBtn).wait(1));

	// prevBtn
	this.prevBtn = new lib.NextBtnMediator();
	this.prevBtn.parent = this;
	this.prevBtn.setTransform(25,678,1,1,0,0,180);

	this.timeline.addTween(cjs.Tween.get(this.prevBtn).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(17.3,653,1183.5,40.5);


(lib.sitemapMediator = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// scroller
	this.scrollerItem = new lib.scroller();
	this.scrollerItem.parent = this;
	this.scrollerItem.setTransform(637,225);

	this.timeline.addTween(cjs.Tween.get(this.scrollerItem).wait(1));

	// Ebene 2
	this.instance = new lib.container_text("single",0);
	this.instance.parent = this;
	this.instance.setTransform(583,928.9,1,1,0,0,0,563,818.9);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// chapterItem_c1
	this.sitemapContent = new lib.sitemapContent();
	this.sitemapContent.parent = this;
	this.sitemapContent.setTransform(20,225);

	this.timeline.addTween(cjs.Tween.get(this.sitemapContent).wait(1));

	// Ebene 7
	this.instance_1 = new lib.container_text("single",30);
	this.instance_1.parent = this;
	this.instance_1.setTransform(892,1512.9,1,1,0,0,0,563,818.9);

	this.instance_2 = new lib.container_text("single",31);
	this.instance_2.parent = this;
	this.instance_2.setTransform(892,1543.9,1,1,0,0,0,563,818.9);

	this.instance_3 = new lib.container_text("single",29);
	this.instance_3.parent = this;
	this.instance_3.setTransform(892,1481.9,1,1,0,0,0,563,818.9);

	this.instance_4 = new lib.overview_state("single",17);
	this.instance_4.parent = this;
	this.instance_4.setTransform(613,738.7,1,1,0,0,0,7,7);

	this.instance_5 = new lib.overview_state("single",9);
	this.instance_5.parent = this;
	this.instance_5.setTransform(613,707.9,1,1,0,0,0,7,7);

	this.instance_6 = new lib.overview_state("single",0);
	this.instance_6.parent = this;
	this.instance_6.setTransform(613,677,1,1,0,0,0,7,7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1}]}).wait(1));

	// background
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Eg0VA+uMAAAh9cMBoqAAAMAAAB9cg");
	this.shape.setTransform(335,401.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Ebene 3
	this.instance_7 = new lib.pic_cover_fullscreen();
	this.instance_7.parent = this;
	this.instance_7.setTransform(609,401.5,1,1.142,0,0,0,609,351.5);
	this.instance_7.alpha = 0.199;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,1218,803);


(lib.chapterItem07 = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// button
	this.clickButton = new lib.btn_blind_circle();
	this.clickButton.parent = this;
	this.clickButton.setTransform(22.5,25.1,0.408,0.455,0,0,0,55.1,55.1);
	new cjs.ButtonHelper(this.clickButton, 0, 1, 2, false, new lib.btn_blind_circle(), 3);

	this.timeline.addTween(cjs.Tween.get(this.clickButton).wait(1));

	// chapterDuration
	this.chapterDuration = new lib.chapterDuration();
	this.chapterDuration.parent = this;
	this.chapterDuration.setTransform(242,20.9,1,1,0,0,0,32,17.4);
	this.chapterDuration.visible = false;

	this.timeline.addTween(cjs.Tween.get(this.chapterDuration).wait(1));

	// chapterIcon
	this.chapterIcon = new lib.chapterIcon();
	this.chapterIcon.parent = this;
	this.chapterIcon.setTransform(0,0,0.9,1);

	this.timeline.addTween(cjs.Tween.get(this.chapterIcon).wait(1));

	// chapterItemThumbnail
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D5001C").s().p("AgtBZIgBgBIBKhYIhKhXIABgBIARAAIBLBYIhLBZg");
	this.shape.setTransform(14.7,120);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// chapterItemThumbnail
	this.chapterTitleFixed = new lib.Chaptertitle();
	this.chapterTitleFixed.parent = this;
	this.chapterTitleFixed.setTransform(163.5,143.4,1,1,0,0,0,133.5,37.1);

	this.timeline.addTween(cjs.Tween.get(this.chapterTitleFixed).wait(1));

	// chapterItemThumbnail
	this.chapterItemThumbnail = new lib.chapterItemThumbnail();
	this.chapterItemThumbnail.parent = this;
	this.chapterItemThumbnail.setTransform(244,18.7,0.175,0.175,0,0,0,144.1,78.6);
	this.chapterItemThumbnail.visible = false;

	this.timeline.addTween(cjs.Tween.get(this.chapterItemThumbnail).wait(1));

	// background
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["rgba(0,0,0,0.498)","rgba(0,0,0,0)"],[0.502,1],3.9,31.1,3.9,-36.3).s().p("A1EFCIAAqDMAqJAAAIAAKDg");
	this.shape_1.setTransform(135,117.7);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

	// Ebene 3
	this.instance = new lib.container_pics("single",6);
	this.instance.parent = this;
	this.instance.setTransform(150,73.5,1,1,0,0,0,150,73.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,270,150);


(lib.chapterItem06 = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// button
	this.clickButton = new lib.btn_blind_circle();
	this.clickButton.parent = this;
	this.clickButton.setTransform(22.5,25.1,0.408,0.455,0,0,0,55.1,55.1);
	new cjs.ButtonHelper(this.clickButton, 0, 1, 2, false, new lib.btn_blind_circle(), 3);

	this.timeline.addTween(cjs.Tween.get(this.clickButton).wait(1));

	// chapterDuration
	this.chapterDuration = new lib.chapterDuration();
	this.chapterDuration.parent = this;
	this.chapterDuration.setTransform(242,20.9,1,1,0,0,0,32,17.4);
	this.chapterDuration.visible = false;

	this.timeline.addTween(cjs.Tween.get(this.chapterDuration).wait(1));

	// chapterIcon
	this.chapterIcon = new lib.chapterIcon();
	this.chapterIcon.parent = this;
	this.chapterIcon.setTransform(0,0,0.9,1);

	this.timeline.addTween(cjs.Tween.get(this.chapterIcon).wait(1));

	// chapterItemThumbnail
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D5001C").s().p("AgtBZIgBgBIBKhYIhKhXIABgBIARAAIBLBYIhLBZg");
	this.shape.setTransform(14.7,120);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// chapterItemThumbnail
	this.chapterTitleFixed = new lib.Chaptertitle();
	this.chapterTitleFixed.parent = this;
	this.chapterTitleFixed.setTransform(163.5,143.4,1,1,0,0,0,133.5,37.1);

	this.timeline.addTween(cjs.Tween.get(this.chapterTitleFixed).wait(1));

	// chapterItemThumbnail
	this.chapterItemThumbnail = new lib.chapterItemThumbnail();
	this.chapterItemThumbnail.parent = this;
	this.chapterItemThumbnail.setTransform(244,18.7,0.175,0.175,0,0,0,144.1,78.6);
	this.chapterItemThumbnail.visible = false;

	this.timeline.addTween(cjs.Tween.get(this.chapterItemThumbnail).wait(1));

	// background
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["rgba(0,0,0,0.498)","rgba(0,0,0,0)"],[0.502,1],3.9,31.1,3.9,-36.3).s().p("A1EFCIAAqDMAqJAAAIAAKDg");
	this.shape_1.setTransform(135,117.7);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

	// Ebene 3
	this.instance = new lib.container_pics("single",5);
	this.instance.parent = this;
	this.instance.setTransform(150,73.5,1,1,0,0,0,150,73.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,270,150);


(lib.chapterItem05 = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// button
	this.clickButton = new lib.btn_blind_circle();
	this.clickButton.parent = this;
	this.clickButton.setTransform(22.5,25.1,0.408,0.455,0,0,0,55.1,55.1);
	new cjs.ButtonHelper(this.clickButton, 0, 1, 2, false, new lib.btn_blind_circle(), 3);

	this.timeline.addTween(cjs.Tween.get(this.clickButton).wait(1));

	// chapterDuration
	this.chapterDuration = new lib.chapterDuration();
	this.chapterDuration.parent = this;
	this.chapterDuration.setTransform(242,20.9,1,1,0,0,0,32,17.4);
	this.chapterDuration.visible = false;

	this.timeline.addTween(cjs.Tween.get(this.chapterDuration).wait(1));

	// chapterIcon
	this.chapterIcon = new lib.chapterIcon();
	this.chapterIcon.parent = this;
	this.chapterIcon.setTransform(0,0,0.9,1);

	this.timeline.addTween(cjs.Tween.get(this.chapterIcon).wait(1));

	// chapterItemThumbnail
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D5001C").s().p("AgtBZIgBgBIBKhYIhKhXIABgBIARAAIBLBYIhLBZg");
	this.shape.setTransform(14.7,120);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// chapterItemThumbnail
	this.chapterTitleFixed = new lib.Chaptertitle();
	this.chapterTitleFixed.parent = this;
	this.chapterTitleFixed.setTransform(163.5,143.4,1,1,0,0,0,133.5,37.1);

	this.timeline.addTween(cjs.Tween.get(this.chapterTitleFixed).wait(1));

	// chapterItemThumbnail
	this.chapterItemThumbnail = new lib.chapterItemThumbnail();
	this.chapterItemThumbnail.parent = this;
	this.chapterItemThumbnail.setTransform(244,18.7,0.175,0.175,0,0,0,144.1,78.6);
	this.chapterItemThumbnail.visible = false;

	this.timeline.addTween(cjs.Tween.get(this.chapterItemThumbnail).wait(1));

	// background
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["rgba(0,0,0,0.498)","rgba(0,0,0,0)"],[0.502,1],3.9,31.1,3.9,-36.3).s().p("A1EFCIAAqDMAqJAAAIAAKDg");
	this.shape_1.setTransform(135,117.7);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

	// Ebene 3
	this.instance = new lib.container_pics("single",4);
	this.instance.parent = this;
	this.instance.setTransform(150,73.5,1,1,0,0,0,150,73.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,270,150);


(lib.chapterItem04 = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// button
	this.clickButton = new lib.btn_blind_circle();
	this.clickButton.parent = this;
	this.clickButton.setTransform(22.5,25.1,0.408,0.455,0,0,0,55.1,55.1);
	new cjs.ButtonHelper(this.clickButton, 0, 1, 2, false, new lib.btn_blind_circle(), 3);

	this.timeline.addTween(cjs.Tween.get(this.clickButton).wait(1));

	// chapterDuration
	this.chapterDuration = new lib.chapterDuration();
	this.chapterDuration.parent = this;
	this.chapterDuration.setTransform(242,20.9,1,1,0,0,0,32,17.4);
	this.chapterDuration.visible = false;

	this.timeline.addTween(cjs.Tween.get(this.chapterDuration).wait(1));

	// chapterIcon
	this.chapterIcon = new lib.chapterIcon();
	this.chapterIcon.parent = this;
	this.chapterIcon.setTransform(0,0,0.9,1);

	this.timeline.addTween(cjs.Tween.get(this.chapterIcon).wait(1));

	// chapterItemThumbnail
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D5001C").s().p("AgtBZIgBgBIBKhYIhKhXIABgBIARAAIBLBYIhLBZg");
	this.shape.setTransform(14.7,120);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// chapterItemThumbnail
	this.chapterTitleFixed = new lib.Chaptertitle();
	this.chapterTitleFixed.parent = this;
	this.chapterTitleFixed.setTransform(163.5,143.4,1,1,0,0,0,133.5,37.1);

	this.timeline.addTween(cjs.Tween.get(this.chapterTitleFixed).wait(1));

	// chapterItemThumbnail
	this.chapterItemThumbnail = new lib.chapterItemThumbnail();
	this.chapterItemThumbnail.parent = this;
	this.chapterItemThumbnail.setTransform(244,18.7,0.175,0.175,0,0,0,144.1,78.6);
	this.chapterItemThumbnail.visible = false;

	this.timeline.addTween(cjs.Tween.get(this.chapterItemThumbnail).wait(1));

	// background
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["rgba(0,0,0,0.498)","rgba(0,0,0,0)"],[0.502,1],3.9,31.1,3.9,-36.3).s().p("A1EFCIAAqDMAqJAAAIAAKDg");
	this.shape_1.setTransform(135,117.7);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

	// Ebene 3
	this.instance = new lib.container_pics("single",3);
	this.instance.parent = this;
	this.instance.setTransform(150,73.5,1,1,0,0,0,150,73.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,270,150);


(lib.chapterItem03 = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// button
	this.clickButton = new lib.btn_blind_circle();
	this.clickButton.parent = this;
	this.clickButton.setTransform(22.5,25.1,0.408,0.455,0,0,0,55.1,55.1);
	new cjs.ButtonHelper(this.clickButton, 0, 1, 2, false, new lib.btn_blind_circle(), 3);

	this.timeline.addTween(cjs.Tween.get(this.clickButton).wait(1));

	// chapterDuration
	this.chapterDuration = new lib.chapterDuration();
	this.chapterDuration.parent = this;
	this.chapterDuration.setTransform(242,20.9,1,1,0,0,0,32,17.4);
	this.chapterDuration.visible = false;

	this.timeline.addTween(cjs.Tween.get(this.chapterDuration).wait(1));

	// chapterIcon
	this.chapterIcon = new lib.chapterIcon();
	this.chapterIcon.parent = this;
	this.chapterIcon.setTransform(0,0,0.9,1);

	this.timeline.addTween(cjs.Tween.get(this.chapterIcon).wait(1));

	// chapterItemThumbnail
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D5001C").s().p("AgtBZIgBgBIBKhYIhKhXIABgBIARAAIBLBYIhLBZg");
	this.shape.setTransform(14.7,120);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// chapterItemThumbnail
	this.chapterTitleFixed = new lib.Chaptertitle();
	this.chapterTitleFixed.parent = this;
	this.chapterTitleFixed.setTransform(163.5,143.4,1,1,0,0,0,133.5,37.1);

	this.timeline.addTween(cjs.Tween.get(this.chapterTitleFixed).wait(1));

	// chapterItemThumbnail
	this.chapterItemThumbnail = new lib.chapterItemThumbnail();
	this.chapterItemThumbnail.parent = this;
	this.chapterItemThumbnail.setTransform(244,18.7,0.175,0.175,0,0,0,144.1,78.6);
	this.chapterItemThumbnail.visible = false;

	this.timeline.addTween(cjs.Tween.get(this.chapterItemThumbnail).wait(1));

	// background
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["rgba(0,0,0,0.498)","rgba(0,0,0,0)"],[0.502,1],3.9,31.1,3.9,-36.3).s().p("A1EFCIAAqDMAqJAAAIAAKDg");
	this.shape_1.setTransform(135,117.7);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

	// Ebene 3
	this.instance = new lib.container_pics("single",2);
	this.instance.parent = this;
	this.instance.setTransform(150,73.5,1,1,0,0,0,150,73.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,270,150);


(lib.chapterItem02 = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// button
	this.clickButton = new lib.btn_blind_circle();
	this.clickButton.parent = this;
	this.clickButton.setTransform(22.5,25.1,0.408,0.455,0,0,0,55.1,55.1);
	new cjs.ButtonHelper(this.clickButton, 0, 1, 2, false, new lib.btn_blind_circle(), 3);

	this.timeline.addTween(cjs.Tween.get(this.clickButton).wait(1));

	// chapterDuration
	this.chapterDuration = new lib.chapterDuration();
	this.chapterDuration.parent = this;
	this.chapterDuration.setTransform(242,20.9,1,1,0,0,0,32,17.4);
	this.chapterDuration.visible = false;

	this.timeline.addTween(cjs.Tween.get(this.chapterDuration).wait(1));

	// chapterIcon
	this.chapterIcon = new lib.chapterIcon();
	this.chapterIcon.parent = this;
	this.chapterIcon.setTransform(0,0,0.9,1);

	this.timeline.addTween(cjs.Tween.get(this.chapterIcon).wait(1));

	// Ebene 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D5001C").s().p("AgtBZIgBgBIBKhYIhKhXIABgBIARAAIBLBYIhLBZg");
	this.shape.setTransform(14.7,120);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// chapterItemThumbnail
	this.chapterTitleFixed = new lib.Chaptertitle();
	this.chapterTitleFixed.parent = this;
	this.chapterTitleFixed.setTransform(163.5,143.4,1,1,0,0,0,133.5,37.1);

	this.timeline.addTween(cjs.Tween.get(this.chapterTitleFixed).wait(1));

	// chapterItemThumbnail
	this.chapterItemThumbnail = new lib.chapterItemThumbnail();
	this.chapterItemThumbnail.parent = this;
	this.chapterItemThumbnail.setTransform(244,18.7,0.175,0.175,0,0,0,144.1,78.6);
	this.chapterItemThumbnail.visible = false;

	this.timeline.addTween(cjs.Tween.get(this.chapterItemThumbnail).wait(1));

	// background
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["rgba(0,0,0,0.498)","rgba(0,0,0,0)"],[0.502,1],3.9,31.1,3.9,-36.3).s().p("A1EFCIAAqDMAqJAAAIAAKDg");
	this.shape_1.setTransform(135,117.7);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

	// Ebene 3
	this.instance = new lib.container_pics("single",1);
	this.instance.parent = this;
	this.instance.setTransform(150,73.5,1,1,0,0,0,150,73.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,270,150);


(lib.chapterItem01 = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// button
	this.clickButton = new lib.btn_blind_circle();
	this.clickButton.parent = this;
	this.clickButton.setTransform(22.5,25.1,0.408,0.455,0,0,0,55.1,55.1);
	new cjs.ButtonHelper(this.clickButton, 0, 1, 2, false, new lib.btn_blind_circle(), 3);

	this.timeline.addTween(cjs.Tween.get(this.clickButton).wait(1));

	// chapterDuration
	this.chapterDuration = new lib.chapterDuration();
	this.chapterDuration.parent = this;
	this.chapterDuration.setTransform(242,20.9,1,1,0,0,0,32,17.4);
	this.chapterDuration.visible = false;

	this.timeline.addTween(cjs.Tween.get(this.chapterDuration).wait(1));

	// chapterIcon
	this.chapterIcon = new lib.chapterIcon();
	this.chapterIcon.parent = this;
	this.chapterIcon.setTransform(0,0,0.9,1);

	this.timeline.addTween(cjs.Tween.get(this.chapterIcon).wait(1));

	// Ebene 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D5001C").s().p("AgtBZIgBgBIBKhYIhKhXIABgBIARAAIBLBYIhLBZg");
	this.shape.setTransform(14.7,120);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// chapterItemThumbnail
	this.chapterTitleFixed = new lib.Chaptertitle();
	this.chapterTitleFixed.parent = this;
	this.chapterTitleFixed.setTransform(163.5,143.4,1,1,0,0,0,133.5,37.1);

	this.timeline.addTween(cjs.Tween.get(this.chapterTitleFixed).wait(1));

	// chapterItemThumbnail
	this.chapterItemThumbnail = new lib.chapterItemThumbnail();
	this.chapterItemThumbnail.parent = this;
	this.chapterItemThumbnail.setTransform(244,18.7,0.175,0.175,0,0,0,144.1,78.6);
	this.chapterItemThumbnail.visible = false;

	this.timeline.addTween(cjs.Tween.get(this.chapterItemThumbnail).wait(1));

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("A1FLuIAA3bMAqLAAAIAAXbg");
	mask.setTransform(135,75);

	// Ebene 4
	this.instance = new lib.pic_shadow_occlusionRound();
	this.instance.parent = this;
	this.instance.setTransform(100.9,117.4,1,0.206);
	this.instance.alpha = 0.5;

	this.instance_1 = new lib.pic_shadow_occlusionRound();
	this.instance_1.parent = this;
	this.instance_1.setTransform(26.3,111.4,1,0.206);
	this.instance_1.alpha = 0.5;

	this.instance_2 = new lib.pic_shadow_occlusionRound();
	this.instance_2.parent = this;
	this.instance_2.setTransform(81,103.1,1,0.206);
	this.instance_2.alpha = 0.5;

	this.instance.mask = this.instance_1.mask = this.instance_2.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	// Ebene 3
	this.instance_3 = new lib.ani_intro();
	this.instance_3.parent = this;
	this.instance_3.setTransform(-1,-1,0.223,0.223);

	this.instance_3.mask = mask;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,270,150);


(lib.ImprintMediator = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.closeBtn = new lib.btn_blind();
	this.closeBtn.parent = this;
	this.closeBtn.setTransform(940.8,-67,5.139,0.8);
	new cjs.ButtonHelper(this.closeBtn, 0, 1, 2, false, new lib.btn_blind(), 3);

	this.imprintContent = new lib.imrint_content();
	this.imprintContent.parent = this;
	this.imprintContent.setTransform(70,89);

	this.instance = new lib.container_text("single",70);
	this.instance.parent = this;
	this.instance.setTransform(1250.4,-15,1,1,0,0,0,462.4,45);

	this.instance_1 = new lib.container_text("single",69);
	this.instance_1.parent = this;
	this.instance_1.setTransform(566.4,81,1,1,0,0,0,462.4,45);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance},{t:this.imprintContent},{t:this.closeBtn}]}).wait(1));

	// Ebene 2
	this.instance_2 = new lib.pics_icons("single",1);
	this.instance_2.parent = this;
	this.instance_2.setTransform(1178,-47,1,1,0,0,0,12,11.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

	// Ebene 4
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EgigAEEIAAoGMBFBAAAIAAIGg");
	this.shape.setTransform(984,-51);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Ebene 5
	this.scrollerItem = new lib.scroller_imprint_help();
	this.scrollerItem.parent = this;
	this.scrollerItem.setTransform(1180,90);

	this.timeline.addTween(cjs.Tween.get(this.scrollerItem).wait(1));

	// Ebene 3
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("EhfJA3nMAAAhvOMC+SAAAMAAABvOg");
	this.shape_1.setTransform(609,356);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,-77,1218,1954.4);


(lib.HelpMediator = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// closeBtn
	this.closeBtn = new lib.btn_blind();
	this.closeBtn.parent = this;
	this.closeBtn.setTransform(788.7,-67.1,8.201,0.8,0,0,0,0.1,-0.1);
	new cjs.ButtonHelper(this.closeBtn, 0, 1, 2, false, new lib.btn_blind(), 3);

	this.timeline.addTween(cjs.Tween.get(this.closeBtn).wait(1));

	// container_text
	this.instance = new lib.container_text("single",5);
	this.instance.parent = this;
	this.instance.setTransform(788.1,-60);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// container_text
	this.instance_1 = new lib.container_text("single",4);
	this.instance_1.parent = this;
	this.instance_1.setTransform(894.4,81.1,1,1,0,0,0,462.4,45);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	// Ebene 6
	this.instance_2 = new lib.pics_icons("single",1);
	this.instance_2.parent = this;
	this.instance_2.setTransform(1178,-47,1,1,0,0,0,12,11.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

	// Ebene 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EgigAEEIAAoGMBFBAAAIAAIGg");
	this.shape.setTransform(984,-51);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Ebene 4
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#333333").ss(1,1,1).p("EBUOAAAMiobAAA");
	this.shape_1.setTransform(609,89.1);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

	// Ebene 5
	this.scrollerItem = new lib.scroller_imprint_help();
	this.scrollerItem.parent = this;
	this.scrollerItem.setTransform(1181.5,89.1);

	this.timeline.addTween(cjs.Tween.get(this.scrollerItem).wait(1));

	// Ebene 7
	this.helpContent = new lib.help_content();
	this.helpContent.parent = this;
	this.helpContent.setTransform(0,89.1);

	this.timeline.addTween(cjs.Tween.get(this.helpContent).wait(1));

	// Ebene 3
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("EhfJA3nMAAAhvOMC+SAAAMAAABvOg");
	this.shape_2.setTransform(609,356);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,-77,1218,1527);


(lib.ContentMediator = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// NavigationMediator
	this.NavigationMediator = new lib.NavigationMediator();
	this.NavigationMediator.parent = this;
	this.NavigationMediator.setTransform(70.5,71,1,1,0,0,0,70.5,71);

	this.timeline.addTween(cjs.Tween.get(this.NavigationMediator).wait(1));

	// background
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,255,255,0)").s().p("EhfJA26MAAAht0MC+SAAAMAAABt0g");
	this.shape.setTransform(609,351.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,1218,703);


(lib.button_back = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// Ebene 2
	this.instance = new lib.container_text("single",51);
	this.instance.parent = this;
	this.instance.setTransform(563,832.9,1,1,0,0,0,563,818.9);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// background
	this.instance_1 = new lib.btn_blind();
	this.instance_1.parent = this;
	this.instance_1.setTransform(281.4,27,5.973,0.8,0,0,0,25,25);
	new cjs.ButtonHelper(this.instance_1, 0, 1, 2, false, new lib.btn_blind(), 3);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	// Ebene 1
	this.instance_2 = new lib.pics_icons("single",11);
	this.instance_2.parent = this;
	this.instance_2.setTransform(417,27,1,1,0,0,0,12,11.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,7,430.7,40);


(lib.toggleInfoMenu = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#B5B3B9").ss(1,0,0,3).p("EhfJAAAMC+TAAA");
	this.shape.setTransform(609,0);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// infoMenuBtn
	this.infoMenuBtn = new lib.btn_infos();
	this.infoMenuBtn.parent = this;
	this.infoMenuBtn.setTransform(589,-14.5,1,1,0,0,0,85,15.5);

	this.timeline.addTween(cjs.Tween.get(this.infoMenuBtn).wait(1));

	// infoMenuContent
	this.infoMenuContent = new lib.infoMenuContent();
	this.infoMenuContent.parent = this;
	this.infoMenuContent.setTransform(609,19.9,1,1,0,0,0,609,49.9);

	this.timeline.addTween(cjs.Tween.get(this.infoMenuContent).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-30,1220,140);


(lib.sitemapOffBtn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// btn_blind
	this.instance = new lib.btn_blind();
	this.instance.parent = this;
	this.instance.setTransform(102.6,7.2,8.202,0.8,0,0,0,12.5,9);
	new cjs.ButtonHelper(this.instance, 0, 1, 2, false, new lib.btn_blind(), 3);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// icon
	this.instance_1 = new lib.pics_icons("single",1);
	this.instance_1.parent = this;
	this.instance_1.setTransform(19.5,18.8,1,1,0,0,0,12,11.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	// container_text
	this.instance_2 = new lib.container_text("single",52);
	this.instance_2.parent = this;
	this.instance_2.setTransform(613,826.2,1,1,0,0,0,563,818.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,410.1,40);


(lib.button_sitemap = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// sitemapOnBtn
	this.sitemapOnBtn = new lib.sitemapOnBtn();
	this.sitemapOnBtn.parent = this;
	this.sitemapOnBtn.setTransform(306.5,412.9,1,1,0,0,0,306.5,412.9);

	this.timeline.addTween(cjs.Tween.get(this.sitemapOnBtn).wait(1));

	// sitemapOffBtn
	this.sitemapOffBtn = new lib.sitemapOffBtn();
	this.sitemapOffBtn.parent = this;
	this.sitemapOffBtn.setTransform(306.5,412.9,1,1,0,0,0,306.5,412.9);

	this.timeline.addTween(cjs.Tween.get(this.sitemapOffBtn).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,430,39.5);


(lib.MenuMediator = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// Ebene 3
	this.allSeenMessageWindow = new lib.allSeenMessage();
	this.allSeenMessageWindow.parent = this;
	this.allSeenMessageWindow.setTransform(192.5,109,1,1,0,0,0,192.5,109);

	this.timeline.addTween(cjs.Tween.get(this.allSeenMessageWindow).wait(1));

	// cover
	this.instance = new lib.pic_plane_white();
	this.instance.parent = this;
	this.instance.setTransform(608.8,758,2.104,0.2,0,0,0,289.4,275.3);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// infoMenu
	this.infoMenu = new lib.toggleInfoMenu();
	this.infoMenu.parent = this;
	this.infoMenu.setTransform(609,753,1,1,0,0,0,609,50);

	this.timeline.addTween(cjs.Tween.get(this.infoMenu).wait(1));

	// title
	this.instance_1 = new lib.container_text("single",2);
	this.instance_1.parent = this;
	this.instance_1.setTransform(609,828.9,1,1,0,0,0,563,818.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	// Ebene 2
	this.instance_2 = new lib.container_text("single",9);
	this.instance_2.parent = this;
	this.instance_2.setTransform(1317,1225.5,1,1,0,0,0,563,705.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

	// chapters
	this.chapterItem_c5 = new lib.chapterItem05();
	this.chapterItem_c5.parent = this;
	this.chapterItem_c5.setTransform(194,360);

	this.chapterItem_c7 = new lib.chapterItem07();
	this.chapterItem_c7.parent = this;
	this.chapterItem_c7.setTransform(754,360);

	this.chapterItem_c6 = new lib.chapterItem06();
	this.chapterItem_c6.parent = this;
	this.chapterItem_c6.setTransform(474,360);

	this.chapterItem_c4 = new lib.chapterItem04();
	this.chapterItem_c4.parent = this;
	this.chapterItem_c4.setTransform(894,200);

	this.chapterItem_c2 = new lib.chapterItem02();
	this.chapterItem_c2.parent = this;
	this.chapterItem_c2.setTransform(334,200);

	this.chapterItem_c3 = new lib.chapterItem03();
	this.chapterItem_c3.parent = this;
	this.chapterItem_c3.setTransform(614,200);

	this.chapterItem_c1 = new lib.chapterItem01();
	this.chapterItem_c1.parent = this;
	this.chapterItem_c1.setTransform(54,200);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.chapterItem_c1},{t:this.chapterItem_c3},{t:this.chapterItem_c2},{t:this.chapterItem_c4},{t:this.chapterItem_c6},{t:this.chapterItem_c7},{t:this.chapterItem_c5}]}).wait(1));

	// background
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EhfJA26MAAAht0MC+SAAAMAAABt0g");
	this.shape.setTransform(609,351.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-31.2,0,1249.8,813);


(lib.WrapperMediator = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// SitemapBtnMediator
	this.SitemapBtnMediator = new lib.button_sitemap();
	this.SitemapBtnMediator.parent = this;
	this.SitemapBtnMediator.setTransform(326.5,445.9,1,1,0,0,0,306.5,412.9);

	this.timeline.addTween(cjs.Tween.get(this.SitemapBtnMediator).wait(1));

	// sitemapMediator
	this.SitemapMediator = new lib.sitemapMediator();
	this.SitemapMediator.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.SitemapMediator).wait(1));

	// MobileStartMediator
	this.StartMobileBtnMediator = new lib.MobileStartMediator();
	this.StartMobileBtnMediator.parent = this;
	this.StartMobileBtnMediator.setTransform(623,464,1,1,0,0,0,114,137.5);

	this.timeline.addTween(cjs.Tween.get(this.StartMobileBtnMediator).wait(1));

	// ImprintMediator
	this.ImprintMediator = new lib.ImprintMediator();
	this.ImprintMediator.parent = this;
	this.ImprintMediator.setTransform(445.9,401.9,1,1,0,0,0,445.9,301.9);

	this.timeline.addTween(cjs.Tween.get(this.ImprintMediator).wait(1));

	// HelpMediator
	this.HelpMediator = new lib.HelpMediator();
	this.HelpMediator.parent = this;
	this.HelpMediator.setTransform(445.9,401.9,1,1,0,0,0,445.9,301.9);

	this.timeline.addTween(cjs.Tween.get(this.HelpMediator).wait(1));

	// ExitBtnMediator
	this.ExitBtnMediator = new lib.button_back();
	this.ExitBtnMediator.parent = this;
	this.ExitBtnMediator.setTransform(796.8,53.9,1,1,0,0,0,29.8,27.9);

	this.timeline.addTween(cjs.Tween.get(this.ExitBtnMediator).wait(1));

	// LogoMediator
	this.LogoMediator = new lib.LogoMediator();
	this.LogoMediator.parent = this;
	this.LogoMediator.setTransform(504.6,42.6,1,1,0,0,0,504.6,42.6);

	this.timeline.addTween(cjs.Tween.get(this.LogoMediator).wait(1));

	// MenuMediator
	this.MenuMediator = new lib.MenuMediator();
	this.MenuMediator.parent = this;
	this.MenuMediator.setTransform(0,100);

	this.timeline.addTween(cjs.Tween.get(this.MenuMediator).wait(1));

	// cover
	this.instance = new lib.pic_MarginCover();
	this.instance.parent = this;
	this.instance.setTransform(609,401.5,1,1,0,0,0,609,401.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// ContentMediator
	this.ContentMediator = new lib.ContentMediator();
	this.ContentMediator.parent = this;
	this.ContentMediator.setTransform(0,100);

	this.timeline.addTween(cjs.Tween.get(this.ContentMediator).wait(1));

	// wrapperBackground
	this.wrapperBackground = new lib.wrapperBackground();
	this.wrapperBackground.parent = this;
	this.wrapperBackground.setTransform(505,337.5,1,1,0,0,0,505,337.5);

	this.timeline.addTween(cjs.Tween.get(this.wrapperBackground).wait(1));

	// IndexMediator
	this.IndexMediator = new lib.ProgressMediator();
	this.IndexMediator.parent = this;
	this.IndexMediator.setTransform(158.2,776.7,0.552,0.552,0,0,0,286.5,14.5);
	this.IndexMediator.visible = false;

	this.timeline.addTween(cjs.Tween.get(this.IndexMediator).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-128.1,-67.6,1474.4,2044.9);


// stage content:
(lib.frameContent = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// WrapperMediator
	this.WrapperMediator = new lib.WrapperMediator();
	this.WrapperMediator.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.WrapperMediator).wait(1));

	// BackgroundMediator
	this.BackgroundMediator = new lib.BackgroundMediator();
	this.BackgroundMediator.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.BackgroundMediator).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(480.9,333.9,1474.4,2044.9);

})(lib = lib||{}, images = images||{}, createjs = createjs||{}, ss = ss||{});
var lib, images, createjs, ss;