(function (lib, img, cjs, ss) {

var p; // shortcut to reference prototypes
lib.webFontTxtFilters = {}; 

// library properties:
lib.properties = {
	width: 50,
	height: 50,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	webfonts: {},
	manifest: []
};



lib.ssMetadata = [];


lib.webfontAvailable = function(family) { 
	lib.properties.webfonts[family] = true;
	var txtFilters = lib.webFontTxtFilters && lib.webFontTxtFilters[family] || [];
	for(var f = 0; f < txtFilters.length; ++f) {
		txtFilters[f].updateCache();
	}
};
// symbols:



(lib.pic_element_ = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D5001C").s().p("AAABGQgQAAgSACIAAhsQAAgPALgLQAKgKANAAQAOAAALAKQAJAMABAOIAABsQgRgCgSAAg");
	this.shape.setTransform(3.5,7.3);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,7,14.6);


(lib.pic_preloader = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 2
	this.instance = new lib.pic_element_();
	this.instance.setTransform(0,0,1,1,30,0,0,3.6,44.9);
	this.instance.alpha = 0.102;

	this.instance_1 = new lib.pic_element_();
	this.instance_1.setTransform(0,0.1,0.999,0.999,60.1,0,0,3.6,45);
	this.instance_1.alpha = 0.18;

	this.instance_2 = new lib.pic_element_();
	this.instance_2.setTransform(0,0.1,1,1,90,0,0,3.6,45);
	this.instance_2.alpha = 0.27;

	this.instance_3 = new lib.pic_element_();
	this.instance_3.setTransform(0,0.1,0.999,0.999,119.9,0,0,3.6,44.9);
	this.instance_3.alpha = 0.352;

	this.instance_4 = new lib.pic_element_();
	this.instance_4.setTransform(0,0.1,0.999,0.999,150,0,0,3.6,44.9);
	this.instance_4.alpha = 0.43;

	this.instance_5 = new lib.pic_element_();
	this.instance_5.setTransform(0,0,1,1,180,0,0,3.6,45);
	this.instance_5.alpha = 0.512;

	this.instance_6 = new lib.pic_element_();
	this.instance_6.setTransform(0,0,0.999,0.999,-150,0,0,3.6,44.9);
	this.instance_6.alpha = 0.59;

	this.instance_7 = new lib.pic_element_();
	this.instance_7.setTransform(0,0,0.999,0.999,-119.9,0,0,3.6,45);
	this.instance_7.alpha = 0.672;

	this.instance_8 = new lib.pic_element_();
	this.instance_8.setTransform(0.1,0,1,1,-90,0,0,3.5,45);
	this.instance_8.alpha = 0.75;

	this.instance_9 = new lib.pic_element_();
	this.instance_9.setTransform(0.1,0,0.999,0.999,-60.1,0,0,3.6,44.9);
	this.instance_9.alpha = 0.84;

	this.instance_10 = new lib.pic_element_();
	this.instance_10.setTransform(0.1,0,0.999,0.999,-30,0,0,3.6,44.9);
	this.instance_10.alpha = 0.922;

	this.instance_11 = new lib.pic_element_();
	this.instance_11.setTransform(0.1,0.1,1,1,0,0,0,3.6,45);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-44.9,-44.9,89.9,89.9);


(lib.ani_preloader = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.pic_preloader();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(3).to({rotation:30},0).wait(3).to({rotation:60},0).wait(3).to({rotation:90},0).wait(3).to({rotation:120},0).wait(3).to({rotation:150},0).wait(3).to({rotation:180},0).wait(3).to({rotation:210},0).wait(3).to({rotation:240},0).wait(3).to({rotation:270},0).wait(3).to({rotation:300},0).wait(3).to({rotation:330},0).wait(3));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-44.9,-44.9,89.9,89.9);


// stage content:



(lib.preloader = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// loader
	this.instance = new lib.ani_preloader();
	this.instance.setTransform(25,25,0.5,0.5,0,0,0,0.1,0.1);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(12.9,14.4,67.9,71.2);

})(lib = lib||{}, images = images||{}, createjs = createjs||{}, ss = ss||{});
var lib, images, createjs, ss;