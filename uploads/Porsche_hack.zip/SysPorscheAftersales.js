"Version: PorscheAftersales (pub 190211 133216; pro 700101 010000, ; sys 700101 010000, )";
"© Fischer, Knoblauch & Co. Medienproduktionsges. mbH";

//- - - - - - - - - - - - - - - - - - - - - - 1 - - - - - - - - - - - - - - - - - - - - - -
//lib/extend.min.js
'ExtendJS 0.2.3 More info at http://extendjs.org  Copyright (c) 2013+ ChrisBenjaminsen.com  Distributed under the terms of the MIT license. http://extendjs.org/licence.txt  This notice shall be included in all copies or substantial portions of the Software.';

!function(a){"use strict";function b(a){a.parent instanceof Function&&(b.apply(this,[a.parent]),this.super=c(this,d(this,this.constructor))),a.apply(this,arguments)}function c(a,b){for(var c in a)"super"!==c&&a[c]instanceof Function&&!(a[c].prototype instanceof Class)&&(b[c]=a[c].super||d(a,a[c]));return b}function d(a,b){var c=a.super;return b.super=function(){return a.super=c,b.apply(a,arguments)}}a.Class=function(){},a.Class.extend=function e(a){function d(){b!==arguments[0]&&(b.apply(this,[a]),c(this,this),this.initializer instanceof Function&&this.initializer.apply(this),this.constructor.apply(this,arguments))}return d.prototype=new this(b),d.prototype.constructor=d,d.toString=function(){return a.toString()},d.extend=function(b){return b.parent=a,e.apply(d,arguments)},d},a.Class=a.Class.extend(function(){this.constructor=function(){}})}(this);

//- - - - - - - - - - - - - - - - - - - - - - 2 - - - - - - - - - - - - - - - - - - - - - -
//lib/createjs-2015.11.26.min.js
"Visit http://createjs.com/ for documentation, updates and examples. Copyright (c) 2011-2015 gskinner.com, inc. Distributed under the terms of the MIT license. http://www.opensource.org/licenses/mit-license.html This notice shall be included in all copies or substantial portions of the Software.";

this.createjs=this.createjs||{},createjs.extend=function(a,b){"use strict";function c(){this.constructor=a}return c.prototype=b.prototype,a.prototype=new c},this.createjs=this.createjs||{},createjs.promote=function(a,b){"use strict";var c=a.prototype,d=Object.getPrototypeOf&&Object.getPrototypeOf(c)||c.__proto__;if(d){c[(b+="_")+"constructor"]=d.constructor;for(var e in d)c.hasOwnProperty(e)&&"function"==typeof d[e]&&(c[b+e]=d[e])}return a},this.createjs=this.createjs||{},createjs.indexOf=function(a,b){"use strict";for(var c=0,d=a.length;d>c;c++)if(b===a[c])return c;return-1},this.createjs=this.createjs||{},function(){"use strict";function a(a,b,c){this.type=a,this.target=null,this.currentTarget=null,this.eventPhase=0,this.bubbles=!!b,this.cancelable=!!c,this.timeStamp=(new Date).getTime(),this.defaultPrevented=!1,this.propagationStopped=!1,this.immediatePropagationStopped=!1,this.removed=!1}var b=a.prototype;b.preventDefault=function(){this.defaultPrevented=this.cancelable&&!0},b.stopPropagation=function(){this.propagationStopped=!0},b.stopImmediatePropagation=function(){this.immediatePropagationStopped=this.propagationStopped=!0},b.remove=function(){this.removed=!0},b.clone=function(){return new a(this.type,this.bubbles,this.cancelable)},b.set=function(a){for(var b in a)this[b]=a[b];return this},b.toString=function(){return"[Event (type="+this.type+")]"},createjs.Event=a}(),this.createjs=this.createjs||{},function(){"use strict";function a(){this._listeners=null,this._captureListeners=null}var b=a.prototype;a.initialize=function(a){a.addEventListener=b.addEventListener,a.on=b.on,a.removeEventListener=a.off=b.removeEventListener,a.removeAllEventListeners=b.removeAllEventListeners,a.hasEventListener=b.hasEventListener,a.dispatchEvent=b.dispatchEvent,a._dispatchEvent=b._dispatchEvent,a.willTrigger=b.willTrigger},b.addEventListener=function(a,b,c){var d;d=c?this._captureListeners=this._captureListeners||{}:this._listeners=this._listeners||{};var e=d[a];return e&&this.removeEventListener(a,b,c),e=d[a],e?e.push(b):d[a]=[b],b},b.on=function(a,b,c,d,e,f){return b.handleEvent&&(c=c||b,b=b.handleEvent),c=c||this,this.addEventListener(a,function(a){b.call(c,a,e),d&&a.remove()},f)},b.removeEventListener=function(a,b,c){var d=c?this._captureListeners:this._listeners;if(d){var e=d[a];if(e)for(var f=0,g=e.length;g>f;f++)if(e[f]==b){1==g?delete d[a]:e.splice(f,1);break}}},b.off=b.removeEventListener,b.removeAllEventListeners=function(a){a?(this._listeners&&delete this._listeners[a],this._captureListeners&&delete this._captureListeners[a]):this._listeners=this._captureListeners=null},b.dispatchEvent=function(a,b,c){if("string"==typeof a){var d=this._listeners;if(!(b||d&&d[a]))return!0;a=new createjs.Event(a,b,c)}else a.target&&a.clone&&(a=a.clone());try{a.target=this}catch(e){}if(a.bubbles&&this.parent){for(var f=this,g=[f];f.parent;)g.push(f=f.parent);var h,i=g.length;for(h=i-1;h>=0&&!a.propagationStopped;h--)g[h]._dispatchEvent(a,1+(0==h));for(h=1;i>h&&!a.propagationStopped;h++)g[h]._dispatchEvent(a,3)}else this._dispatchEvent(a,2);return!a.defaultPrevented},b.hasEventListener=function(a){var b=this._listeners,c=this._captureListeners;return!!(b&&b[a]||c&&c[a])},b.willTrigger=function(a){for(var b=this;b;){if(b.hasEventListener(a))return!0;b=b.parent}return!1},b.toString=function(){return"[EventDispatcher]"},b._dispatchEvent=function(a,b){var c,d=1==b?this._captureListeners:this._listeners;if(a&&d){var e=d[a.type];if(!e||!(c=e.length))return;try{a.currentTarget=this}catch(f){}try{a.eventPhase=b}catch(f){}a.removed=!1,e=e.slice();for(var g=0;c>g&&!a.immediatePropagationStopped;g++){var h=e[g];h.handleEvent?h.handleEvent(a):h(a),a.removed&&(this.off(a.type,h,1==b),a.removed=!1)}}},createjs.EventDispatcher=a}(),this.createjs=this.createjs||{},function(){"use strict";function a(){throw"Ticker cannot be instantiated."}a.RAF_SYNCHED="synched",a.RAF="raf",a.TIMEOUT="timeout",a.useRAF=!1,a.timingMode=null,a.maxDelta=0,a.paused=!1,a.removeEventListener=null,a.removeAllEventListeners=null,a.dispatchEvent=null,a.hasEventListener=null,a._listeners=null,createjs.EventDispatcher.initialize(a),a._addEventListener=a.addEventListener,a.addEventListener=function(){return!a._inited&&a.init(),a._addEventListener.apply(a,arguments)},a._inited=!1,a._startTime=0,a._pausedTime=0,a._ticks=0,a._pausedTicks=0,a._interval=50,a._lastTime=0,a._times=null,a._tickTimes=null,a._timerId=null,a._raf=!0,a.setInterval=function(b){a._interval=b,a._inited&&a._setupTick()},a.getInterval=function(){return a._interval},a.setFPS=function(b){a.setInterval(1e3/b)},a.getFPS=function(){return 1e3/a._interval};try{Object.defineProperties(a,{interval:{get:a.getInterval,set:a.setInterval},framerate:{get:a.getFPS,set:a.setFPS}})}catch(b){console.log(b)}a.init=function(){a._inited||(a._inited=!0,a._times=[],a._tickTimes=[],a._startTime=a._getTime(),a._times.push(a._lastTime=0),a.interval=a._interval)},a.reset=function(){if(a._raf){var b=window.cancelAnimationFrame||window.webkitCancelAnimationFrame||window.mozCancelAnimationFrame||window.oCancelAnimationFrame||window.msCancelAnimationFrame;b&&b(a._timerId)}else clearTimeout(a._timerId);a.removeAllEventListeners("tick"),a._timerId=a._times=a._tickTimes=null,a._startTime=a._lastTime=a._ticks=0,a._inited=!1},a.getMeasuredTickTime=function(b){var c=0,d=a._tickTimes;if(!d||d.length<1)return-1;b=Math.min(d.length,b||0|a.getFPS());for(var e=0;b>e;e++)c+=d[e];return c/b},a.getMeasuredFPS=function(b){var c=a._times;return!c||c.length<2?-1:(b=Math.min(c.length-1,b||0|a.getFPS()),1e3/((c[0]-c[b])/b))},a.setPaused=function(b){a.paused=b},a.getPaused=function(){return a.paused},a.getTime=function(b){return a._startTime?a._getTime()-(b?a._pausedTime:0):-1},a.getEventTime=function(b){return a._startTime?(a._lastTime||a._startTime)-(b?a._pausedTime:0):-1},a.getTicks=function(b){return a._ticks-(b?a._pausedTicks:0)},a._handleSynch=function(){a._timerId=null,a._setupTick(),a._getTime()-a._lastTime>=.97*(a._interval-1)&&a._tick()},a._handleRAF=function(){a._timerId=null,a._setupTick(),a._tick()},a._handleTimeout=function(){a._timerId=null,a._setupTick(),a._tick()},a._setupTick=function(){if(null==a._timerId){var b=a.timingMode||a.useRAF&&a.RAF_SYNCHED;if(b==a.RAF_SYNCHED||b==a.RAF){var c=window.requestAnimationFrame||window.webkitRequestAnimationFrame||window.mozRequestAnimationFrame||window.oRequestAnimationFrame||window.msRequestAnimationFrame;if(c)return a._timerId=c(b==a.RAF?a._handleRAF:a._handleSynch),void(a._raf=!0)}a._raf=!1,a._timerId=setTimeout(a._handleTimeout,a._interval)}},a._tick=function(){var b=a.paused,c=a._getTime(),d=c-a._lastTime;if(a._lastTime=c,a._ticks++,b&&(a._pausedTicks++,a._pausedTime+=d),a.hasEventListener("tick")){var e=new createjs.Event("tick"),f=a.maxDelta;e.delta=f&&d>f?f:d,e.paused=b,e.time=c,e.runTime=c-a._pausedTime,a.dispatchEvent(e)}for(a._tickTimes.unshift(a._getTime()-c);a._tickTimes.length>100;)a._tickTimes.pop();for(a._times.unshift(c);a._times.length>100;)a._times.pop()};var c=window.performance&&(performance.now||performance.mozNow||performance.msNow||performance.oNow||performance.webkitNow);a._getTime=function(){return(c&&c.call(performance)||(new Date).getTime())-a._startTime},createjs.Ticker=a}(),this.createjs=this.createjs||{},function(){"use strict";function a(){throw"UID cannot be instantiated"}a._nextID=0,a.get=function(){return a._nextID++},createjs.UID=a}(),this.createjs=this.createjs||{},function(){"use strict";function a(a,b,c,d,e,f,g,h,i,j,k){this.Event_constructor(a,b,c),this.stageX=d,this.stageY=e,this.rawX=null==i?d:i,this.rawY=null==j?e:j,this.nativeEvent=f,this.pointerID=g,this.primary=!!h,this.relatedTarget=k}var b=createjs.extend(a,createjs.Event);b._get_localX=function(){return this.currentTarget.globalToLocal(this.rawX,this.rawY).x},b._get_localY=function(){return this.currentTarget.globalToLocal(this.rawX,this.rawY).y},b._get_isTouch=function(){return-1!==this.pointerID};try{Object.defineProperties(b,{localX:{get:b._get_localX},localY:{get:b._get_localY},isTouch:{get:b._get_isTouch}})}catch(c){}b.clone=function(){return new a(this.type,this.bubbles,this.cancelable,this.stageX,this.stageY,this.nativeEvent,this.pointerID,this.primary,this.rawX,this.rawY)},b.toString=function(){return"[MouseEvent (type="+this.type+" stageX="+this.stageX+" stageY="+this.stageY+")]"},createjs.MouseEvent=createjs.promote(a,"Event")}(),this.createjs=this.createjs||{},function(){"use strict";function a(a,b,c,d,e,f){this.setValues(a,b,c,d,e,f)}var b=a.prototype;a.DEG_TO_RAD=Math.PI/180,a.identity=null,b.setValues=function(a,b,c,d,e,f){return this.a=null==a?1:a,this.b=b||0,this.c=c||0,this.d=null==d?1:d,this.tx=e||0,this.ty=f||0,this},b.append=function(a,b,c,d,e,f){var g=this.a,h=this.b,i=this.c,j=this.d;return(1!=a||0!=b||0!=c||1!=d)&&(this.a=g*a+i*b,this.b=h*a+j*b,this.c=g*c+i*d,this.d=h*c+j*d),this.tx=g*e+i*f+this.tx,this.ty=h*e+j*f+this.ty,this},b.prepend=function(a,b,c,d,e,f){var g=this.a,h=this.c,i=this.tx;return this.a=a*g+c*this.b,this.b=b*g+d*this.b,this.c=a*h+c*this.d,this.d=b*h+d*this.d,this.tx=a*i+c*this.ty+e,this.ty=b*i+d*this.ty+f,this},b.appendMatrix=function(a){return this.append(a.a,a.b,a.c,a.d,a.tx,a.ty)},b.prependMatrix=function(a){return this.prepend(a.a,a.b,a.c,a.d,a.tx,a.ty)},b.appendTransform=function(b,c,d,e,f,g,h,i,j){if(f%360)var k=f*a.DEG_TO_RAD,l=Math.cos(k),m=Math.sin(k);else l=1,m=0;return g||h?(g*=a.DEG_TO_RAD,h*=a.DEG_TO_RAD,this.append(Math.cos(h),Math.sin(h),-Math.sin(g),Math.cos(g),b,c),this.append(l*d,m*d,-m*e,l*e,0,0)):this.append(l*d,m*d,-m*e,l*e,b,c),(i||j)&&(this.tx-=i*this.a+j*this.c,this.ty-=i*this.b+j*this.d),this},b.prependTransform=function(b,c,d,e,f,g,h,i,j){if(f%360)var k=f*a.DEG_TO_RAD,l=Math.cos(k),m=Math.sin(k);else l=1,m=0;return(i||j)&&(this.tx-=i,this.ty-=j),g||h?(g*=a.DEG_TO_RAD,h*=a.DEG_TO_RAD,this.prepend(l*d,m*d,-m*e,l*e,0,0),this.prepend(Math.cos(h),Math.sin(h),-Math.sin(g),Math.cos(g),b,c)):this.prepend(l*d,m*d,-m*e,l*e,b,c),this},b.rotate=function(b){b*=a.DEG_TO_RAD;var c=Math.cos(b),d=Math.sin(b),e=this.a,f=this.b;return this.a=e*c+this.c*d,this.b=f*c+this.d*d,this.c=-e*d+this.c*c,this.d=-f*d+this.d*c,this},b.skew=function(b,c){return b*=a.DEG_TO_RAD,c*=a.DEG_TO_RAD,this.append(Math.cos(c),Math.sin(c),-Math.sin(b),Math.cos(b),0,0),this},b.scale=function(a,b){return this.a*=a,this.b*=a,this.c*=b,this.d*=b,this},b.translate=function(a,b){return this.tx+=this.a*a+this.c*b,this.ty+=this.b*a+this.d*b,this},b.identity=function(){return this.a=this.d=1,this.b=this.c=this.tx=this.ty=0,this},b.invert=function(){var a=this.a,b=this.b,c=this.c,d=this.d,e=this.tx,f=a*d-b*c;return this.a=d/f,this.b=-b/f,this.c=-c/f,this.d=a/f,this.tx=(c*this.ty-d*e)/f,this.ty=-(a*this.ty-b*e)/f,this},b.isIdentity=function(){return 0===this.tx&&0===this.ty&&1===this.a&&0===this.b&&0===this.c&&1===this.d},b.equals=function(a){return this.tx===a.tx&&this.ty===a.ty&&this.a===a.a&&this.b===a.b&&this.c===a.c&&this.d===a.d},b.transformPoint=function(a,b,c){return c=c||{},c.x=a*this.a+b*this.c+this.tx,c.y=a*this.b+b*this.d+this.ty,c},b.decompose=function(b){null==b&&(b={}),b.x=this.tx,b.y=this.ty,b.scaleX=Math.sqrt(this.a*this.a+this.b*this.b),b.scaleY=Math.sqrt(this.c*this.c+this.d*this.d);var c=Math.atan2(-this.c,this.d),d=Math.atan2(this.b,this.a),e=Math.abs(1-c/d);return 1e-5>e?(b.rotation=d/a.DEG_TO_RAD,this.a<0&&this.d>=0&&(b.rotation+=b.rotation<=0?180:-180),b.skewX=b.skewY=0):(b.skewX=c/a.DEG_TO_RAD,b.skewY=d/a.DEG_TO_RAD),b},b.copy=function(a){return this.setValues(a.a,a.b,a.c,a.d,a.tx,a.ty)},b.clone=function(){return new a(this.a,this.b,this.c,this.d,this.tx,this.ty)},b.toString=function(){return"[Matrix2D (a="+this.a+" b="+this.b+" c="+this.c+" d="+this.d+" tx="+this.tx+" ty="+this.ty+")]"},a.identity=new a,createjs.Matrix2D=a}(),this.createjs=this.createjs||{},function(){"use strict";function a(a,b,c,d,e){this.setValues(a,b,c,d,e)}var b=a.prototype;b.setValues=function(a,b,c,d,e){return this.visible=null==a?!0:!!a,this.alpha=null==b?1:b,this.shadow=c,this.compositeOperation=d,this.matrix=e||this.matrix&&this.matrix.identity()||new createjs.Matrix2D,this},b.append=function(a,b,c,d,e){return this.alpha*=b,this.shadow=c||this.shadow,this.compositeOperation=d||this.compositeOperation,this.visible=this.visible&&a,e&&this.matrix.appendMatrix(e),this},b.prepend=function(a,b,c,d,e){return this.alpha*=b,this.shadow=this.shadow||c,this.compositeOperation=this.compositeOperation||d,this.visible=this.visible&&a,e&&this.matrix.prependMatrix(e),this},b.identity=function(){return this.visible=!0,this.alpha=1,this.shadow=this.compositeOperation=null,this.matrix.identity(),this},b.clone=function(){return new a(this.alpha,this.shadow,this.compositeOperation,this.visible,this.matrix.clone())},createjs.DisplayProps=a}(),this.createjs=this.createjs||{},function(){"use strict";function a(a,b){this.setValues(a,b)}var b=a.prototype;b.setValues=function(a,b){return this.x=a||0,this.y=b||0,this},b.copy=function(a){return this.x=a.x,this.y=a.y,this},b.clone=function(){return new a(this.x,this.y)},b.toString=function(){return"[Point (x="+this.x+" y="+this.y+")]"},createjs.Point=a}(),this.createjs=this.createjs||{},function(){"use strict";function a(a,b,c,d){this.setValues(a,b,c,d)}var b=a.prototype;b.setValues=function(a,b,c,d){return this.x=a||0,this.y=b||0,this.width=c||0,this.height=d||0,this},b.extend=function(a,b,c,d){return c=c||0,d=d||0,a+c>this.x+this.width&&(this.width=a+c-this.x),b+d>this.y+this.height&&(this.height=b+d-this.y),a<this.x&&(this.width+=this.x-a,this.x=a),b<this.y&&(this.height+=this.y-b,this.y=b),this},b.pad=function(a,b,c,d){return this.x-=b,this.y-=a,this.width+=b+d,this.height+=a+c,this},b.copy=function(a){return this.setValues(a.x,a.y,a.width,a.height)},b.contains=function(a,b,c,d){return c=c||0,d=d||0,a>=this.x&&a+c<=this.x+this.width&&b>=this.y&&b+d<=this.y+this.height},b.union=function(a){return this.clone().extend(a.x,a.y,a.width,a.height)},b.intersection=function(b){var c=b.x,d=b.y,e=c+b.width,f=d+b.height;return this.x>c&&(c=this.x),this.y>d&&(d=this.y),this.x+this.width<e&&(e=this.x+this.width),this.y+this.height<f&&(f=this.y+this.height),c>=e||d>=f?null:new a(c,d,e-c,f-d)},b.intersects=function(a){return a.x<=this.x+this.width&&this.x<=a.x+a.width&&a.y<=this.y+this.height&&this.y<=a.y+a.height},b.isEmpty=function(){return this.width<=0||this.height<=0},b.clone=function(){return new a(this.x,this.y,this.width,this.height)},b.toString=function(){return"[Rectangle (x="+this.x+" y="+this.y+" width="+this.width+" height="+this.height+")]"},createjs.Rectangle=a}(),this.createjs=this.createjs||{},function(){"use strict";function a(a,b,c,d,e,f,g){a.addEventListener&&(this.target=a,this.overLabel=null==c?"over":c,this.outLabel=null==b?"out":b,this.downLabel=null==d?"down":d,this.play=e,this._isPressed=!1,this._isOver=!1,this._enabled=!1,a.mouseChildren=!1,this.enabled=!0,this.handleEvent({}),f&&(g&&(f.actionsEnabled=!1,f.gotoAndStop&&f.gotoAndStop(g)),a.hitArea=f))}var b=a.prototype;b.setEnabled=function(a){if(a!=this._enabled){var b=this.target;this._enabled=a,a?(b.cursor="pointer",b.addEventListener("rollover",this),b.addEventListener("rollout",this),b.addEventListener("mousedown",this),b.addEventListener("pressup",this),b._reset&&(b.__reset=b._reset,b._reset=this._reset)):(b.cursor=null,b.removeEventListener("rollover",this),b.removeEventListener("rollout",this),b.removeEventListener("mousedown",this),b.removeEventListener("pressup",this),b.__reset&&(b._reset=b.__reset,delete b.__reset))}},b.getEnabled=function(){return this._enabled};try{Object.defineProperties(b,{enabled:{get:b.getEnabled,set:b.setEnabled}})}catch(c){}b.toString=function(){return"[ButtonHelper]"},b.handleEvent=function(a){var b,c=this.target,d=a.type;"mousedown"==d?(this._isPressed=!0,b=this.downLabel):"pressup"==d?(this._isPressed=!1,b=this._isOver?this.overLabel:this.outLabel):"rollover"==d?(this._isOver=!0,b=this._isPressed?this.downLabel:this.overLabel):(this._isOver=!1,b=this._isPressed?this.overLabel:this.outLabel),this.play?c.gotoAndPlay&&c.gotoAndPlay(b):c.gotoAndStop&&c.gotoAndStop(b)},b._reset=function(){var a=this.paused;this.__reset(),this.paused=a},createjs.ButtonHelper=a}(),this.createjs=this.createjs||{},function(){"use strict";function a(a,b,c,d){this.color=a||"black",this.offsetX=b||0,this.offsetY=c||0,this.blur=d||0}var b=a.prototype;a.identity=new a("transparent",0,0,0),b.toString=function(){return"[Shadow]"},b.clone=function(){return new a(this.color,this.offsetX,this.offsetY,this.blur)},createjs.Shadow=a}(),this.createjs=this.createjs||{},function(){"use strict";function a(a){this.EventDispatcher_constructor(),this.complete=!0,this.framerate=0,this._animations=null,this._frames=null,this._images=null,this._data=null,this._loadCount=0,this._frameHeight=0,this._frameWidth=0,this._numFrames=0,this._regX=0,this._regY=0,this._spacing=0,this._margin=0,this._parseData(a)}var b=createjs.extend(a,createjs.EventDispatcher);b.getAnimations=function(){return this._animations.slice()};try{Object.defineProperties(b,{animations:{get:b.getAnimations}})}catch(c){}b.getNumFrames=function(a){if(null==a)return this._frames?this._frames.length:this._numFrames||0;var b=this._data[a];return null==b?0:b.frames.length},b.getAnimation=function(a){return this._data[a]},b.getFrame=function(a){var b;return this._frames&&(b=this._frames[a])?b:null},b.getFrameBounds=function(a,b){var c=this.getFrame(a);return c?(b||new createjs.Rectangle).setValues(-c.regX,-c.regY,c.rect.width,c.rect.height):null},b.toString=function(){return"[SpriteSheet]"},b.clone=function(){throw"SpriteSheet cannot be cloned."},b._parseData=function(a){var b,c,d,e;if(null!=a){if(this.framerate=a.framerate||0,a.images&&(c=a.images.length)>0)for(e=this._images=[],b=0;c>b;b++){var f=a.images[b];if("string"==typeof f){var g=f;f=document.createElement("img"),f.src=g}e.push(f),f.getContext||f.naturalWidth||(this._loadCount++,this.complete=!1,function(a,b){f.onload=function(){a._handleImageLoad(b)}}(this,g),function(a,b){f.onerror=function(){a._handleImageError(b)}}(this,g))}if(null==a.frames);else if(Array.isArray(a.frames))for(this._frames=[],e=a.frames,b=0,c=e.length;c>b;b++){var h=e[b];this._frames.push({image:this._images[h[4]?h[4]:0],rect:new createjs.Rectangle(h[0],h[1],h[2],h[3]),regX:h[5]||0,regY:h[6]||0})}else d=a.frames,this._frameWidth=d.width,this._frameHeight=d.height,this._regX=d.regX||0,this._regY=d.regY||0,this._spacing=d.spacing||0,this._margin=d.margin||0,this._numFrames=d.count,0==this._loadCount&&this._calculateFrames();if(this._animations=[],null!=(d=a.animations)){this._data={};var i;for(i in d){var j={name:i},k=d[i];if("number"==typeof k)e=j.frames=[k];else if(Array.isArray(k))if(1==k.length)j.frames=[k[0]];else for(j.speed=k[3],j.next=k[2],e=j.frames=[],b=k[0];b<=k[1];b++)e.push(b);else{j.speed=k.speed,j.next=k.next;var l=k.frames;e=j.frames="number"==typeof l?[l]:l.slice(0)}(j.next===!0||void 0===j.next)&&(j.next=i),(j.next===!1||e.length<2&&j.next==i)&&(j.next=null),j.speed||(j.speed=1),this._animations.push(i),this._data[i]=j}}}},b._handleImageLoad=function(a){0==--this._loadCount&&(this._calculateFrames(),this.complete=!0,this.dispatchEvent("complete"))},b._handleImageError=function(a){var b=new createjs.Event("error");b.src=a,this.dispatchEvent(b),0==--this._loadCount&&this.dispatchEvent("complete")},b._calculateFrames=function(){if(!this._frames&&0!=this._frameWidth){this._frames=[];var a=this._numFrames||1e5,b=0,c=this._frameWidth,d=this._frameHeight,e=this._spacing,f=this._margin;a:for(var g=0,h=this._images;g<h.length;g++)for(var i=h[g],j=i.width,k=i.height,l=f;k-f-d>=l;){for(var m=f;j-f-c>=m;){if(b>=a)break a;b++,this._frames.push({image:i,rect:new createjs.Rectangle(m,l,c,d),regX:this._regX,regY:this._regY}),m+=c+e}l+=d+e}this._numFrames=b}},createjs.SpriteSheet=createjs.promote(a,"EventDispatcher")}(),this.createjs=this.createjs||{},function(){"use strict";function a(){this.command=null,this._stroke=null,this._strokeStyle=null,this._oldStrokeStyle=null,this._strokeDash=null,this._oldStrokeDash=null,this._strokeIgnoreScale=!1,this._fill=null,this._instructions=[],this._commitIndex=0,this._activeInstructions=[],this._dirty=!1,this._storeIndex=0,this.clear()}var b=a.prototype,c=a;a.getRGB=function(a,b,c,d){return null!=a&&null==c&&(d=b,c=255&a,b=a>>8&255,a=a>>16&255),null==d?"rgb("+a+","+b+","+c+")":"rgba("+a+","+b+","+c+","+d+")"},a.getHSL=function(a,b,c,d){return null==d?"hsl("+a%360+","+b+"%,"+c+"%)":"hsla("+a%360+","+b+"%,"+c+"%,"+d+")"},a.BASE_64={A:0,B:1,C:2,D:3,E:4,F:5,G:6,H:7,I:8,J:9,K:10,L:11,M:12,N:13,O:14,P:15,Q:16,R:17,S:18,T:19,U:20,V:21,W:22,X:23,Y:24,Z:25,a:26,b:27,c:28,d:29,e:30,f:31,g:32,h:33,i:34,j:35,k:36,l:37,m:38,n:39,o:40,p:41,q:42,r:43,s:44,t:45,u:46,v:47,w:48,x:49,y:50,z:51,0:52,1:53,2:54,3:55,4:56,5:57,6:58,7:59,8:60,9:61,"+":62,"/":63},a.STROKE_CAPS_MAP=["butt","round","square"],a.STROKE_JOINTS_MAP=["miter","round","bevel"];var d=createjs.createCanvas?createjs.createCanvas():document.createElement("canvas");d.getContext&&(a._ctx=d.getContext("2d"),d.width=d.height=1),b.getInstructions=function(){return this._updateInstructions(),this._instructions};try{Object.defineProperties(b,{instructions:{get:b.getInstructions}})}catch(e){}b.isEmpty=function(){return!(this._instructions.length||this._activeInstructions.length)},b.draw=function(a,b){this._updateInstructions();for(var c=this._instructions,d=this._storeIndex,e=c.length;e>d;d++)c[d].exec(a,b)},b.drawAsPath=function(a){this._updateInstructions();for(var b,c=this._instructions,d=this._storeIndex,e=c.length;e>d;d++)(b=c[d]).path!==!1&&b.exec(a)},b.moveTo=function(a,b){return this.append(new c.MoveTo(a,b),!0)},b.lineTo=function(a,b){return this.append(new c.LineTo(a,b))},b.arcTo=function(a,b,d,e,f){return this.append(new c.ArcTo(a,b,d,e,f))},b.arc=function(a,b,d,e,f,g){return this.append(new c.Arc(a,b,d,e,f,g))},b.quadraticCurveTo=function(a,b,d,e){return this.append(new c.QuadraticCurveTo(a,b,d,e))},b.bezierCurveTo=function(a,b,d,e,f,g){return this.append(new c.BezierCurveTo(a,b,d,e,f,g))},b.rect=function(a,b,d,e){return this.append(new c.Rect(a,b,d,e))},b.closePath=function(){return this._activeInstructions.length?this.append(new c.ClosePath):this},b.clear=function(){return this._instructions.length=this._activeInstructions.length=this._commitIndex=0,this._strokeStyle=this._oldStrokeStyle=this._stroke=this._fill=this._strokeDash=this._oldStrokeDash=null,this._dirty=this._strokeIgnoreScale=!1,this},b.beginFill=function(a){return this._setFill(a?new c.Fill(a):null)},b.beginLinearGradientFill=function(a,b,d,e,f,g){return this._setFill((new c.Fill).linearGradient(a,b,d,e,f,g))},b.beginRadialGradientFill=function(a,b,d,e,f,g,h,i){return this._setFill((new c.Fill).radialGradient(a,b,d,e,f,g,h,i))},b.beginBitmapFill=function(a,b,d){return this._setFill(new c.Fill(null,d).bitmap(a,b))},b.endFill=function(){return this.beginFill()},b.setStrokeStyle=function(a,b,d,e,f){return this._updateInstructions(!0),this._strokeStyle=this.command=new c.StrokeStyle(a,b,d,e,f),this._stroke&&(this._stroke.ignoreScale=f),this._strokeIgnoreScale=f,this},b.setStrokeDash=function(a,b){return this._updateInstructions(!0),this._strokeDash=this.command=new c.StrokeDash(a,b),this},b.beginStroke=function(a){return this._setStroke(a?new c.Stroke(a):null)},b.beginLinearGradientStroke=function(a,b,d,e,f,g){return this._setStroke((new c.Stroke).linearGradient(a,b,d,e,f,g))},b.beginRadialGradientStroke=function(a,b,d,e,f,g,h,i){return this._setStroke((new c.Stroke).radialGradient(a,b,d,e,f,g,h,i))},b.beginBitmapStroke=function(a,b){return this._setStroke((new c.Stroke).bitmap(a,b))},b.endStroke=function(){return this.beginStroke()},b.curveTo=b.quadraticCurveTo,b.drawRect=b.rect,b.drawRoundRect=function(a,b,c,d,e){return this.drawRoundRectComplex(a,b,c,d,e,e,e,e)},b.drawRoundRectComplex=function(a,b,d,e,f,g,h,i){return this.append(new c.RoundRect(a,b,d,e,f,g,h,i))},b.drawCircle=function(a,b,d){return this.append(new c.Circle(a,b,d))},b.drawEllipse=function(a,b,d,e){return this.append(new c.Ellipse(a,b,d,e))},b.drawPolyStar=function(a,b,d,e,f,g){return this.append(new c.PolyStar(a,b,d,e,f,g))},b.append=function(a,b){return this._activeInstructions.push(a),this.command=a,b||(this._dirty=!0),this},b.decodePath=function(b){for(var c=[this.moveTo,this.lineTo,this.quadraticCurveTo,this.bezierCurveTo,this.closePath],d=[2,2,4,6,0],e=0,f=b.length,g=[],h=0,i=0,j=a.BASE_64;f>e;){var k=b.charAt(e),l=j[k],m=l>>3,n=c[m];if(!n||3&l)throw"bad path data (@"+e+"): "+k;var o=d[m];m||(h=i=0),g.length=0,e++;for(var p=(l>>2&1)+2,q=0;o>q;q++){var r=j[b.charAt(e)],s=r>>5?-1:1;r=(31&r)<<6|j[b.charAt(e+1)],3==p&&(r=r<<6|j[b.charAt(e+2)]),r=s*r/10,q%2?h=r+=h:i=r+=i,g[q]=r,e+=p}n.apply(this,g)}return this},b.store=function(){return this._updateInstructions(!0),this._storeIndex=this._instructions.length,this},b.unstore=function(){return this._storeIndex=0,this},b.clone=function(){var b=new a;return b.command=this.command,b._stroke=this._stroke,b._strokeStyle=this._strokeStyle,b._strokeDash=this._strokeDash,b._strokeIgnoreScale=this._strokeIgnoreScale,b._fill=this._fill,b._instructions=this._instructions.slice(),b._commitIndex=this._commitIndex,b._activeInstructions=this._activeInstructions.slice(),b._dirty=this._dirty,b._storeIndex=this._storeIndex,b},b.toString=function(){return"[Graphics]"},b.mt=b.moveTo,b.lt=b.lineTo,b.at=b.arcTo,b.bt=b.bezierCurveTo,b.qt=b.quadraticCurveTo,b.a=b.arc,b.r=b.rect,b.cp=b.closePath,b.c=b.clear,b.f=b.beginFill,b.lf=b.beginLinearGradientFill,b.rf=b.beginRadialGradientFill,b.bf=b.beginBitmapFill,b.ef=b.endFill,b.ss=b.setStrokeStyle,b.sd=b.setStrokeDash,b.s=b.beginStroke,b.ls=b.beginLinearGradientStroke,b.rs=b.beginRadialGradientStroke,b.bs=b.beginBitmapStroke,b.es=b.endStroke,b.dr=b.drawRect,b.rr=b.drawRoundRect,b.rc=b.drawRoundRectComplex,b.dc=b.drawCircle,b.de=b.drawEllipse,b.dp=b.drawPolyStar,b.p=b.decodePath,b._updateInstructions=function(b){var c=this._instructions,d=this._activeInstructions,e=this._commitIndex;if(this._dirty&&d.length){c.length=e,c.push(a.beginCmd);var f=d.length,g=c.length;c.length=g+f;for(var h=0;f>h;h++)c[h+g]=d[h];this._fill&&c.push(this._fill),this._stroke&&(this._strokeDash!==this._oldStrokeDash&&(this._oldStrokeDash=this._strokeDash,c.push(this._strokeDash)),this._strokeStyle!==this._oldStrokeStyle&&(this._oldStrokeStyle=this._strokeStyle,c.push(this._strokeStyle)),c.push(this._stroke)),this._dirty=!1}b&&(d.length=0,this._commitIndex=c.length)},b._setFill=function(a){return this._updateInstructions(!0),this.command=this._fill=a,this},b._setStroke=function(a){return this._updateInstructions(!0),(this.command=this._stroke=a)&&(a.ignoreScale=this._strokeIgnoreScale),this},(c.LineTo=function(a,b){this.x=a,this.y=b}).prototype.exec=function(a){a.lineTo(this.x,this.y)},(c.MoveTo=function(a,b){this.x=a,this.y=b}).prototype.exec=function(a){a.moveTo(this.x,this.y)},(c.ArcTo=function(a,b,c,d,e){this.x1=a,this.y1=b,this.x2=c,this.y2=d,this.radius=e}).prototype.exec=function(a){a.arcTo(this.x1,this.y1,this.x2,this.y2,this.radius)},(c.Arc=function(a,b,c,d,e,f){this.x=a,this.y=b,this.radius=c,this.startAngle=d,this.endAngle=e,this.anticlockwise=!!f}).prototype.exec=function(a){a.arc(this.x,this.y,this.radius,this.startAngle,this.endAngle,this.anticlockwise)},(c.QuadraticCurveTo=function(a,b,c,d){this.cpx=a,this.cpy=b,this.x=c,this.y=d}).prototype.exec=function(a){a.quadraticCurveTo(this.cpx,this.cpy,this.x,this.y)},(c.BezierCurveTo=function(a,b,c,d,e,f){this.cp1x=a,this.cp1y=b,this.cp2x=c,this.cp2y=d,this.x=e,this.y=f}).prototype.exec=function(a){a.bezierCurveTo(this.cp1x,this.cp1y,this.cp2x,this.cp2y,this.x,this.y)},(c.Rect=function(a,b,c,d){this.x=a,this.y=b,this.w=c,this.h=d}).prototype.exec=function(a){a.rect(this.x,this.y,this.w,this.h)},(c.ClosePath=function(){}).prototype.exec=function(a){a.closePath()},(c.BeginPath=function(){}).prototype.exec=function(a){a.beginPath()},b=(c.Fill=function(a,b){this.style=a,this.matrix=b}).prototype,b.exec=function(a){if(this.style){a.fillStyle=this.style;var b=this.matrix;b&&(a.save(),a.transform(b.a,b.b,b.c,b.d,b.tx,b.ty)),a.fill(),b&&a.restore()}},b.linearGradient=function(b,c,d,e,f,g){for(var h=this.style=a._ctx.createLinearGradient(d,e,f,g),i=0,j=b.length;j>i;i++)h.addColorStop(c[i],b[i]);return h.props={colors:b,ratios:c,x0:d,y0:e,x1:f,y1:g,type:"linear"},this},b.radialGradient=function(b,c,d,e,f,g,h,i){for(var j=this.style=a._ctx.createRadialGradient(d,e,f,g,h,i),k=0,l=b.length;l>k;k++)j.addColorStop(c[k],b[k]);return j.props={colors:b,ratios:c,x0:d,y0:e,r0:f,x1:g,y1:h,r1:i,type:"radial"},this},b.bitmap=function(b,c){if(b.naturalWidth||b.getContext||b.readyState>=2){var d=this.style=a._ctx.createPattern(b,c||"");d.props={image:b,repetition:c,type:"bitmap"}}return this},b.path=!1,b=(c.Stroke=function(a,b){this.style=a,this.ignoreScale=b}).prototype,b.exec=function(a){this.style&&(a.strokeStyle=this.style,this.ignoreScale&&(a.save(),a.setTransform(1,0,0,1,0,0)),a.stroke(),this.ignoreScale&&a.restore())},b.linearGradient=c.Fill.prototype.linearGradient,b.radialGradient=c.Fill.prototype.radialGradient,b.bitmap=c.Fill.prototype.bitmap,b.path=!1,b=(c.StrokeStyle=function(a,b,c,d,e){this.width=a,this.caps=b,this.joints=c,this.miterLimit=d,this.ignoreScale=e}).prototype,b.exec=function(b){b.lineWidth=null==this.width?"1":this.width,b.lineCap=null==this.caps?"butt":isNaN(this.caps)?this.caps:a.STROKE_CAPS_MAP[this.caps],b.lineJoin=null==this.joints?"miter":isNaN(this.joints)?this.joints:a.STROKE_JOINTS_MAP[this.joints],b.miterLimit=null==this.miterLimit?"10":this.miterLimit,b.ignoreScale=null==this.ignoreScale?!1:this.ignoreScale},b.path=!1,(c.StrokeDash=function(a,b){this.segments=a,this.offset=b||0}).prototype.exec=function(a){a.setLineDash&&(a.setLineDash(this.segments||c.StrokeDash.EMPTY_SEGMENTS),a.lineDashOffset=this.offset||0)},c.StrokeDash.EMPTY_SEGMENTS=[],(c.RoundRect=function(a,b,c,d,e,f,g,h){this.x=a,this.y=b,this.w=c,this.h=d,this.radiusTL=e,this.radiusTR=f,this.radiusBR=g,this.radiusBL=h}).prototype.exec=function(a){var b=(j>i?i:j)/2,c=0,d=0,e=0,f=0,g=this.x,h=this.y,i=this.w,j=this.h,k=this.radiusTL,l=this.radiusTR,m=this.radiusBR,n=this.radiusBL;0>k&&(k*=c=-1),k>b&&(k=b),0>l&&(l*=d=-1),l>b&&(l=b),0>m&&(m*=e=-1),m>b&&(m=b),0>n&&(n*=f=-1),n>b&&(n=b),a.moveTo(g+i-l,h),a.arcTo(g+i+l*d,h-l*d,g+i,h+l,l),a.lineTo(g+i,h+j-m),a.arcTo(g+i+m*e,h+j+m*e,g+i-m,h+j,m),a.lineTo(g+n,h+j),a.arcTo(g-n*f,h+j+n*f,g,h+j-n,n),a.lineTo(g,h+k),a.arcTo(g-k*c,h-k*c,g+k,h,k),a.closePath()},(c.Circle=function(a,b,c){this.x=a,this.y=b,this.radius=c}).prototype.exec=function(a){a.arc(this.x,this.y,this.radius,0,2*Math.PI)},(c.Ellipse=function(a,b,c,d){this.x=a,this.y=b,this.w=c,this.h=d}).prototype.exec=function(a){var b=this.x,c=this.y,d=this.w,e=this.h,f=.5522848,g=d/2*f,h=e/2*f,i=b+d,j=c+e,k=b+d/2,l=c+e/2;a.moveTo(b,l),a.bezierCurveTo(b,l-h,k-g,c,k,c),a.bezierCurveTo(k+g,c,i,l-h,i,l),a.bezierCurveTo(i,l+h,k+g,j,k,j),a.bezierCurveTo(k-g,j,b,l+h,b,l)},(c.PolyStar=function(a,b,c,d,e,f){this.x=a,this.y=b,this.radius=c,this.sides=d,this.pointSize=e,this.angle=f}).prototype.exec=function(a){var b=this.x,c=this.y,d=this.radius,e=(this.angle||0)/180*Math.PI,f=this.sides,g=1-(this.pointSize||0),h=Math.PI/f;a.moveTo(b+Math.cos(e)*d,c+Math.sin(e)*d);for(var i=0;f>i;i++)e+=h,1!=g&&a.lineTo(b+Math.cos(e)*d*g,c+Math.sin(e)*d*g),e+=h,a.lineTo(b+Math.cos(e)*d,c+Math.sin(e)*d);a.closePath()},a.beginCmd=new c.BeginPath,createjs.Graphics=a}(),this.createjs=this.createjs||{},function(){"use strict";function a(){this.EventDispatcher_constructor(),this.alpha=1,this.cacheCanvas=null,this.cacheID=0,this.id=createjs.UID.get(),this.mouseEnabled=!0,this.tickEnabled=!0,this.name=null,this.parent=null,this.regX=0,this.regY=0,this.rotation=0,this.scaleX=1,this.scaleY=1,this.skewX=0,this.skewY=0,this.shadow=null,this.visible=!0,this.x=0,this.y=0,this.transformMatrix=null,this.compositeOperation=null,this.snapToPixel=!0,this.filters=null,
this.mask=null,this.hitArea=null,this.cursor=null,this._cacheOffsetX=0,this._cacheOffsetY=0,this._filterOffsetX=0,this._filterOffsetY=0,this._cacheScale=1,this._cacheDataURLID=0,this._cacheDataURL=null,this._props=new createjs.DisplayProps,this._rectangle=new createjs.Rectangle,this._bounds=null}var b=createjs.extend(a,createjs.EventDispatcher);a._MOUSE_EVENTS=["click","dblclick","mousedown","mouseout","mouseover","pressmove","pressup","rollout","rollover"],a.suppressCrossDomainErrors=!1,a._snapToPixelEnabled=!1;var c=createjs.createCanvas?createjs.createCanvas():document.createElement("canvas");c.getContext&&(a._hitTestCanvas=c,a._hitTestContext=c.getContext("2d"),c.width=c.height=1),a._nextCacheID=1,b.getStage=function(){for(var a=this,b=createjs.Stage;a.parent;)a=a.parent;return a instanceof b?a:null};try{Object.defineProperties(b,{stage:{get:b.getStage}})}catch(d){}b.isVisible=function(){return!!(this.visible&&this.alpha>0&&0!=this.scaleX&&0!=this.scaleY)},b.draw=function(a,b){var c=this.cacheCanvas;if(b||!c)return!1;var d=this._cacheScale;return a.drawImage(c,this._cacheOffsetX+this._filterOffsetX,this._cacheOffsetY+this._filterOffsetY,c.width/d,c.height/d),!0},b.updateContext=function(b){var c=this,d=c.mask,e=c._props.matrix;d&&d.graphics&&!d.graphics.isEmpty()&&(d.getMatrix(e),b.transform(e.a,e.b,e.c,e.d,e.tx,e.ty),d.graphics.drawAsPath(b),b.clip(),e.invert(),b.transform(e.a,e.b,e.c,e.d,e.tx,e.ty)),this.getMatrix(e);var f=e.tx,g=e.ty;a._snapToPixelEnabled&&c.snapToPixel&&(f=f+(0>f?-.5:.5)|0,g=g+(0>g?-.5:.5)|0),b.transform(e.a,e.b,e.c,e.d,f,g),b.globalAlpha*=c.alpha,c.compositeOperation&&(b.globalCompositeOperation=c.compositeOperation),c.shadow&&this._applyShadow(b,c.shadow)},b.cache=function(a,b,c,d,e){e=e||1,this.cacheCanvas||(this.cacheCanvas=createjs.createCanvas?createjs.createCanvas():document.createElement("canvas")),this._cacheWidth=c,this._cacheHeight=d,this._cacheOffsetX=a,this._cacheOffsetY=b,this._cacheScale=e,this.updateCache()},b.updateCache=function(b){var c=this.cacheCanvas;if(!c)throw"cache() must be called before updateCache()";var d=this._cacheScale,e=this._cacheOffsetX*d,f=this._cacheOffsetY*d,g=this._cacheWidth,h=this._cacheHeight,i=c.getContext("2d"),j=this._getFilterBounds();e+=this._filterOffsetX=j.x,f+=this._filterOffsetY=j.y,g=Math.ceil(g*d)+j.width,h=Math.ceil(h*d)+j.height,g!=c.width||h!=c.height?(c.width=g,c.height=h):b||i.clearRect(0,0,g+1,h+1),i.save(),i.globalCompositeOperation=b,i.setTransform(d,0,0,d,-e,-f),this.draw(i,!0),this._applyFilters(),i.restore(),this.cacheID=a._nextCacheID++},b.uncache=function(){this._cacheDataURL=this.cacheCanvas=null,this.cacheID=this._cacheOffsetX=this._cacheOffsetY=this._filterOffsetX=this._filterOffsetY=0,this._cacheScale=1},b.getCacheDataURL=function(){return this.cacheCanvas?(this.cacheID!=this._cacheDataURLID&&(this._cacheDataURL=this.cacheCanvas.toDataURL()),this._cacheDataURL):null},b.localToGlobal=function(a,b,c){return this.getConcatenatedMatrix(this._props.matrix).transformPoint(a,b,c||new createjs.Point)},b.globalToLocal=function(a,b,c){return this.getConcatenatedMatrix(this._props.matrix).invert().transformPoint(a,b,c||new createjs.Point)},b.localToLocal=function(a,b,c,d){return d=this.localToGlobal(a,b,d),c.globalToLocal(d.x,d.y,d)},b.setTransform=function(a,b,c,d,e,f,g,h,i){return this.x=a||0,this.y=b||0,this.scaleX=null==c?1:c,this.scaleY=null==d?1:d,this.rotation=e||0,this.skewX=f||0,this.skewY=g||0,this.regX=h||0,this.regY=i||0,this},b.getMatrix=function(a){var b=this,c=a&&a.identity()||new createjs.Matrix2D;return b.transformMatrix?c.copy(b.transformMatrix):c.appendTransform(b.x,b.y,b.scaleX,b.scaleY,b.rotation,b.skewX,b.skewY,b.regX,b.regY)},b.getConcatenatedMatrix=function(a){for(var b=this,c=this.getMatrix(a);b=b.parent;)c.prependMatrix(b.getMatrix(b._props.matrix));return c},b.getConcatenatedDisplayProps=function(a){a=a?a.identity():new createjs.DisplayProps;var b=this,c=b.getMatrix(a.matrix);do a.prepend(b.visible,b.alpha,b.shadow,b.compositeOperation),b!=this&&c.prependMatrix(b.getMatrix(b._props.matrix));while(b=b.parent);return a},b.hitTest=function(b,c){var d=a._hitTestContext;d.setTransform(1,0,0,1,-b,-c),this.draw(d);var e=this._testHit(d);return d.setTransform(1,0,0,1,0,0),d.clearRect(0,0,2,2),e},b.set=function(a){for(var b in a)this[b]=a[b];return this},b.getBounds=function(){if(this._bounds)return this._rectangle.copy(this._bounds);var a=this.cacheCanvas;if(a){var b=this._cacheScale;return this._rectangle.setValues(this._cacheOffsetX,this._cacheOffsetY,a.width/b,a.height/b)}return null},b.getTransformedBounds=function(){return this._getBounds()},b.setBounds=function(a,b,c,d){null==a&&(this._bounds=a),this._bounds=(this._bounds||new createjs.Rectangle).setValues(a,b,c,d)},b.clone=function(){return this._cloneProps(new a)},b.toString=function(){return"[DisplayObject (name="+this.name+")]"},b._cloneProps=function(a){return a.alpha=this.alpha,a.mouseEnabled=this.mouseEnabled,a.tickEnabled=this.tickEnabled,a.name=this.name,a.regX=this.regX,a.regY=this.regY,a.rotation=this.rotation,a.scaleX=this.scaleX,a.scaleY=this.scaleY,a.shadow=this.shadow,a.skewX=this.skewX,a.skewY=this.skewY,a.visible=this.visible,a.x=this.x,a.y=this.y,a.compositeOperation=this.compositeOperation,a.snapToPixel=this.snapToPixel,a.filters=null==this.filters?null:this.filters.slice(0),a.mask=this.mask,a.hitArea=this.hitArea,a.cursor=this.cursor,a._bounds=this._bounds,a},b._applyShadow=function(a,b){b=b||Shadow.identity,a.shadowColor=b.color,a.shadowOffsetX=b.offsetX,a.shadowOffsetY=b.offsetY,a.shadowBlur=b.blur},b._tick=function(a){var b=this._listeners;b&&b.tick&&(a.target=null,a.propagationStopped=a.immediatePropagationStopped=!1,this.dispatchEvent(a))},b._testHit=function(b){try{var c=b.getImageData(0,0,1,1).data[3]>1}catch(d){if(!a.suppressCrossDomainErrors)throw"An error has occurred. This is most likely due to security restrictions on reading canvas pixel data with local or cross-domain images."}return c},b._applyFilters=function(){if(this.filters&&0!=this.filters.length&&this.cacheCanvas)for(var a=this.filters.length,b=this.cacheCanvas.getContext("2d"),c=this.cacheCanvas.width,d=this.cacheCanvas.height,e=0;a>e;e++)this.filters[e].applyFilter(b,0,0,c,d)},b._getFilterBounds=function(a){var b,c=this.filters,d=this._rectangle.setValues(0,0,0,0);if(!c||!(b=c.length))return d;for(var e=0;b>e;e++){var f=this.filters[e];f.getBounds&&f.getBounds(d)}return d},b._getBounds=function(a,b){return this._transformBounds(this.getBounds(),a,b)},b._transformBounds=function(a,b,c){if(!a)return a;var d=a.x,e=a.y,f=a.width,g=a.height,h=this._props.matrix;h=c?h.identity():this.getMatrix(h),(d||e)&&h.appendTransform(0,0,1,1,0,0,0,-d,-e),b&&h.prependMatrix(b);var i=f*h.a,j=f*h.b,k=g*h.c,l=g*h.d,m=h.tx,n=h.ty,o=m,p=m,q=n,r=n;return(d=i+m)<o?o=d:d>p&&(p=d),(d=i+k+m)<o?o=d:d>p&&(p=d),(d=k+m)<o?o=d:d>p&&(p=d),(e=j+n)<q?q=e:e>r&&(r=e),(e=j+l+n)<q?q=e:e>r&&(r=e),(e=l+n)<q?q=e:e>r&&(r=e),a.setValues(o,q,p-o,r-q)},b._hasMouseEventListener=function(){for(var b=a._MOUSE_EVENTS,c=0,d=b.length;d>c;c++)if(this.hasEventListener(b[c]))return!0;return!!this.cursor},createjs.DisplayObject=createjs.promote(a,"EventDispatcher")}(),this.createjs=this.createjs||{},function(){"use strict";function a(){this.DisplayObject_constructor(),this.children=[],this.mouseChildren=!0,this.tickChildren=!0}var b=createjs.extend(a,createjs.DisplayObject);b.getNumChildren=function(){return this.children.length};try{Object.defineProperties(b,{numChildren:{get:b.getNumChildren}})}catch(c){}b.initialize=a,b.isVisible=function(){var a=this.cacheCanvas||this.children.length;return!!(this.visible&&this.alpha>0&&0!=this.scaleX&&0!=this.scaleY&&a)},b.draw=function(a,b){if(this.DisplayObject_draw(a,b))return!0;for(var c=this.children.slice(),d=0,e=c.length;e>d;d++){var f=c[d];f.isVisible()&&(a.save(),f.updateContext(a),f.draw(a),a.restore())}return!0},b.addChild=function(a){if(null==a)return a;var b=arguments.length;if(b>1){for(var c=0;b>c;c++)this.addChild(arguments[c]);return arguments[b-1]}return a.parent&&a.parent.removeChild(a),a.parent=this,this.children.push(a),a.dispatchEvent("added"),a},b.addChildAt=function(a,b){var c=arguments.length,d=arguments[c-1];if(0>d||d>this.children.length)return arguments[c-2];if(c>2){for(var e=0;c-1>e;e++)this.addChildAt(arguments[e],d+e);return arguments[c-2]}return a.parent&&a.parent.removeChild(a),a.parent=this,this.children.splice(b,0,a),a.dispatchEvent("added"),a},b.removeChild=function(a){var b=arguments.length;if(b>1){for(var c=!0,d=0;b>d;d++)c=c&&this.removeChild(arguments[d]);return c}return this.removeChildAt(createjs.indexOf(this.children,a))},b.removeChildAt=function(a){var b=arguments.length;if(b>1){for(var c=[],d=0;b>d;d++)c[d]=arguments[d];c.sort(function(a,b){return b-a});for(var e=!0,d=0;b>d;d++)e=e&&this.removeChildAt(c[d]);return e}if(0>a||a>this.children.length-1)return!1;var f=this.children[a];return f&&(f.parent=null),this.children.splice(a,1),f.dispatchEvent("removed"),!0},b.removeAllChildren=function(){for(var a=this.children;a.length;)this.removeChildAt(0)},b.getChildAt=function(a){return this.children[a]},b.getChildByName=function(a){for(var b=this.children,c=0,d=b.length;d>c;c++)if(b[c].name==a)return b[c];return null},b.sortChildren=function(a){this.children.sort(a)},b.getChildIndex=function(a){return createjs.indexOf(this.children,a)},b.swapChildrenAt=function(a,b){var c=this.children,d=c[a],e=c[b];d&&e&&(c[a]=e,c[b]=d)},b.swapChildren=function(a,b){for(var c,d,e=this.children,f=0,g=e.length;g>f&&(e[f]==a&&(c=f),e[f]==b&&(d=f),null==c||null==d);f++);f!=g&&(e[c]=b,e[d]=a)},b.setChildIndex=function(a,b){var c=this.children,d=c.length;if(!(a.parent!=this||0>b||b>=d)){for(var e=0;d>e&&c[e]!=a;e++);e!=d&&e!=b&&(c.splice(e,1),c.splice(b,0,a))}},b.contains=function(a){for(;a;){if(a==this)return!0;a=a.parent}return!1},b.hitTest=function(a,b){return null!=this.getObjectUnderPoint(a,b)},b.getObjectsUnderPoint=function(a,b,c){var d=[],e=this.localToGlobal(a,b);return this._getObjectsUnderPoint(e.x,e.y,d,c>0,1==c),d},b.getObjectUnderPoint=function(a,b,c){var d=this.localToGlobal(a,b);return this._getObjectsUnderPoint(d.x,d.y,null,c>0,1==c)},b.getBounds=function(){return this._getBounds(null,!0)},b.getTransformedBounds=function(){return this._getBounds()},b.clone=function(b){var c=this._cloneProps(new a);return b&&this._cloneChildren(c),c},b.toString=function(){return"[Container (name="+this.name+")]"},b._tick=function(a){if(this.tickChildren)for(var b=this.children.length-1;b>=0;b--){var c=this.children[b];c.tickEnabled&&c._tick&&c._tick(a)}this.DisplayObject__tick(a)},b._cloneChildren=function(a){a.children.length&&a.removeAllChildren();for(var b=a.children,c=0,d=this.children.length;d>c;c++){var e=this.children[c].clone(!0);e.parent=a,b.push(e)}},b._getObjectsUnderPoint=function(b,c,d,e,f,g){if(g=g||0,!g&&!this._testMask(this,b,c))return null;var h,i=createjs.DisplayObject._hitTestContext;f=f||e&&this._hasMouseEventListener();for(var j=this.children,k=j.length,l=k-1;l>=0;l--){var m=j[l],n=m.hitArea;if(m.visible&&(n||m.isVisible())&&(!e||m.mouseEnabled)&&(n||this._testMask(m,b,c)))if(!n&&m instanceof a){var o=m._getObjectsUnderPoint(b,c,d,e,f,g+1);if(!d&&o)return e&&!this.mouseChildren?this:o}else{if(e&&!f&&!m._hasMouseEventListener())continue;var p=m.getConcatenatedDisplayProps(m._props);if(h=p.matrix,n&&(h.appendMatrix(n.getMatrix(n._props.matrix)),p.alpha=n.alpha),i.globalAlpha=p.alpha,i.setTransform(h.a,h.b,h.c,h.d,h.tx-b,h.ty-c),(n||m).draw(i),!this._testHit(i))continue;if(i.setTransform(1,0,0,1,0,0),i.clearRect(0,0,2,2),!d)return e&&!this.mouseChildren?this:m;d.push(m)}}return null},b._testMask=function(a,b,c){var d=a.mask;if(!d||!d.graphics||d.graphics.isEmpty())return!0;var e=this._props.matrix,f=a.parent;e=f?f.getConcatenatedMatrix(e):e.identity(),e=d.getMatrix(d._props.matrix).prependMatrix(e);var g=createjs.DisplayObject._hitTestContext;return g.setTransform(e.a,e.b,e.c,e.d,e.tx-b,e.ty-c),d.graphics.drawAsPath(g),g.fillStyle="#000",g.fill(),this._testHit(g)?(g.setTransform(1,0,0,1,0,0),g.clearRect(0,0,2,2),!0):!1},b._getBounds=function(a,b){var c=this.DisplayObject_getBounds();if(c)return this._transformBounds(c,a,b);var d=this._props.matrix;d=b?d.identity():this.getMatrix(d),a&&d.prependMatrix(a);for(var e=this.children.length,f=null,g=0;e>g;g++){var h=this.children[g];h.visible&&(c=h._getBounds(d))&&(f?f.extend(c.x,c.y,c.width,c.height):f=c.clone())}return f},createjs.Container=createjs.promote(a,"DisplayObject")}(),this.createjs=this.createjs||{},function(){"use strict";function a(a){this.Container_constructor(),this.autoClear=!0,this.canvas="string"==typeof a?document.getElementById(a):a,this.mouseX=0,this.mouseY=0,this.drawRect=null,this.snapToPixelEnabled=!1,this.mouseInBounds=!1,this.tickOnUpdate=!0,this.mouseMoveOutside=!1,this.preventSelection=!0,this._pointerData={},this._pointerCount=0,this._primaryPointerID=null,this._mouseOverIntervalID=null,this._nextStage=null,this._prevStage=null,this.enableDOMEvents(!0)}var b=createjs.extend(a,createjs.Container);b._get_nextStage=function(){return this._nextStage},b._set_nextStage=function(a){this._nextStage&&(this._nextStage._prevStage=null),a&&(a._prevStage=this),this._nextStage=a};try{Object.defineProperties(b,{nextStage:{get:b._get_nextStage,set:b._set_nextStage}})}catch(c){}b.update=function(a){if(this.canvas&&(this.tickOnUpdate&&this.tick(a),this.dispatchEvent("drawstart",!1,!0)!==!1)){createjs.DisplayObject._snapToPixelEnabled=this.snapToPixelEnabled;var b=this.drawRect,c=this.canvas.getContext("2d");c.setTransform(1,0,0,1,0,0),this.autoClear&&(b?c.clearRect(b.x,b.y,b.width,b.height):c.clearRect(0,0,this.canvas.width+1,this.canvas.height+1)),c.save(),this.drawRect&&(c.beginPath(),c.rect(b.x,b.y,b.width,b.height),c.clip()),this.updateContext(c),this.draw(c,!1),c.restore(),this.dispatchEvent("drawend")}},b.tick=function(a){if(this.tickEnabled&&this.dispatchEvent("tickstart",!1,!0)!==!1){var b=new createjs.Event("tick");if(a)for(var c in a)a.hasOwnProperty(c)&&(b[c]=a[c]);this._tick(b),this.dispatchEvent("tickend")}},b.handleEvent=function(a){"tick"==a.type&&this.update(a)},b.clear=function(){if(this.canvas){var a=this.canvas.getContext("2d");a.setTransform(1,0,0,1,0,0),a.clearRect(0,0,this.canvas.width+1,this.canvas.height+1)}},b.toDataURL=function(a,b){var c,d=this.canvas.getContext("2d"),e=this.canvas.width,f=this.canvas.height;if(a){c=d.getImageData(0,0,e,f);var g=d.globalCompositeOperation;d.globalCompositeOperation="destination-over",d.fillStyle=a,d.fillRect(0,0,e,f)}var h=this.canvas.toDataURL(b||"image/png");return a&&(d.putImageData(c,0,0),d.globalCompositeOperation=g),h},b.enableMouseOver=function(a){if(this._mouseOverIntervalID&&(clearInterval(this._mouseOverIntervalID),this._mouseOverIntervalID=null,0==a&&this._testMouseOver(!0)),null==a)a=20;else if(0>=a)return;var b=this;this._mouseOverIntervalID=setInterval(function(){b._testMouseOver()},1e3/Math.min(50,a))},b.enableDOMEvents=function(a){null==a&&(a=!0);var b,c,d=this._eventListeners;if(!a&&d){for(b in d)c=d[b],c.t.removeEventListener(b,c.f,!1);this._eventListeners=null}else if(a&&!d&&this.canvas){var e=window.addEventListener?window:document,f=this;d=this._eventListeners={},d.mouseup={t:e,f:function(a){f._handleMouseUp(a)}},d.mousemove={t:e,f:function(a){f._handleMouseMove(a)}},d.dblclick={t:this.canvas,f:function(a){f._handleDoubleClick(a)}},d.mousedown={t:this.canvas,f:function(a){f._handleMouseDown(a)}};for(b in d)c=d[b],c.t.addEventListener(b,c.f,!1)}},b.clone=function(){throw"Stage cannot be cloned."},b.toString=function(){return"[Stage (name="+this.name+")]"},b._getElementRect=function(a){var b;try{b=a.getBoundingClientRect()}catch(c){b={top:a.offsetTop,left:a.offsetLeft,width:a.offsetWidth,height:a.offsetHeight}}var d=(window.pageXOffset||document.scrollLeft||0)-(document.clientLeft||document.body.clientLeft||0),e=(window.pageYOffset||document.scrollTop||0)-(document.clientTop||document.body.clientTop||0),f=window.getComputedStyle?getComputedStyle(a,null):a.currentStyle,g=parseInt(f.paddingLeft)+parseInt(f.borderLeftWidth),h=parseInt(f.paddingTop)+parseInt(f.borderTopWidth),i=parseInt(f.paddingRight)+parseInt(f.borderRightWidth),j=parseInt(f.paddingBottom)+parseInt(f.borderBottomWidth);return{left:b.left+d+g,right:b.right+d-i,top:b.top+e+h,bottom:b.bottom+e-j}},b._getPointerData=function(a){var b=this._pointerData[a];return b||(b=this._pointerData[a]={x:0,y:0}),b},b._handleMouseMove=function(a){a||(a=window.event),this._handlePointerMove(-1,a,a.pageX,a.pageY)},b._handlePointerMove=function(a,b,c,d,e){if((!this._prevStage||void 0!==e)&&this.canvas){var f=this._nextStage,g=this._getPointerData(a),h=g.inBounds;this._updatePointerPosition(a,b,c,d),(h||g.inBounds||this.mouseMoveOutside)&&(-1===a&&g.inBounds==!h&&this._dispatchMouseEvent(this,h?"mouseleave":"mouseenter",!1,a,g,b),this._dispatchMouseEvent(this,"stagemousemove",!1,a,g,b),this._dispatchMouseEvent(g.target,"pressmove",!0,a,g,b)),f&&f._handlePointerMove(a,b,c,d,null)}},b._updatePointerPosition=function(a,b,c,d){var e=this._getElementRect(this.canvas);c-=e.left,d-=e.top;var f=this.canvas.width,g=this.canvas.height;c/=(e.right-e.left)/f,d/=(e.bottom-e.top)/g;var h=this._getPointerData(a);(h.inBounds=c>=0&&d>=0&&f-1>=c&&g-1>=d)?(h.x=c,h.y=d):this.mouseMoveOutside&&(h.x=0>c?0:c>f-1?f-1:c,h.y=0>d?0:d>g-1?g-1:d),h.posEvtObj=b,h.rawX=c,h.rawY=d,(a===this._primaryPointerID||-1===a)&&(this.mouseX=h.x,this.mouseY=h.y,this.mouseInBounds=h.inBounds)},b._handleMouseUp=function(a){this._handlePointerUp(-1,a,!1)},b._handlePointerUp=function(a,b,c,d){var e=this._nextStage,f=this._getPointerData(a);if(!this._prevStage||void 0!==d){var g=null,h=f.target;d||!h&&!e||(g=this._getObjectsUnderPoint(f.x,f.y,null,!0)),f.down&&(this._dispatchMouseEvent(this,"stagemouseup",!1,a,f,b,g),f.down=!1),g==h&&this._dispatchMouseEvent(h,"click",!0,a,f,b),this._dispatchMouseEvent(h,"pressup",!0,a,f,b),c?(a==this._primaryPointerID&&(this._primaryPointerID=null),delete this._pointerData[a]):f.target=null,e&&e._handlePointerUp(a,b,c,d||g&&this)}},b._handleMouseDown=function(a){this._handlePointerDown(-1,a,a.pageX,a.pageY)},b._handlePointerDown=function(a,b,c,d,e){this.preventSelection&&b.preventDefault(),(null==this._primaryPointerID||-1===a)&&(this._primaryPointerID=a),null!=d&&this._updatePointerPosition(a,b,c,d);var f=null,g=this._nextStage,h=this._getPointerData(a);e||(f=h.target=this._getObjectsUnderPoint(h.x,h.y,null,!0)),h.inBounds&&(this._dispatchMouseEvent(this,"stagemousedown",!1,a,h,b,f),h.down=!0),this._dispatchMouseEvent(f,"mousedown",!0,a,h,b),g&&g._handlePointerDown(a,b,c,d,e||f&&this)},b._testMouseOver=function(a,b,c){if(!this._prevStage||void 0!==b){var d=this._nextStage;if(!this._mouseOverIntervalID)return void(d&&d._testMouseOver(a,b,c));var e=this._getPointerData(-1);if(e&&(a||this.mouseX!=this._mouseOverX||this.mouseY!=this._mouseOverY||!this.mouseInBounds)){var f,g,h,i=e.posEvtObj,j=c||i&&i.target==this.canvas,k=null,l=-1,m="";!b&&(a||this.mouseInBounds&&j)&&(k=this._getObjectsUnderPoint(this.mouseX,this.mouseY,null,!0),this._mouseOverX=this.mouseX,this._mouseOverY=this.mouseY);var n=this._mouseOverTarget||[],o=n[n.length-1],p=this._mouseOverTarget=[];for(f=k;f;)p.unshift(f),m||(m=f.cursor),f=f.parent;for(this.canvas.style.cursor=m,!b&&c&&(c.canvas.style.cursor=m),g=0,h=p.length;h>g&&p[g]==n[g];g++)l=g;for(o!=k&&this._dispatchMouseEvent(o,"mouseout",!0,-1,e,i,k),g=n.length-1;g>l;g--)this._dispatchMouseEvent(n[g],"rollout",!1,-1,e,i,k);for(g=p.length-1;g>l;g--)this._dispatchMouseEvent(p[g],"rollover",!1,-1,e,i,o);o!=k&&this._dispatchMouseEvent(k,"mouseover",!0,-1,e,i,o),d&&d._testMouseOver(a,b||k&&this,c||j&&this)}}},b._handleDoubleClick=function(a,b){var c=null,d=this._nextStage,e=this._getPointerData(-1);b||(c=this._getObjectsUnderPoint(e.x,e.y,null,!0),this._dispatchMouseEvent(c,"dblclick",!0,-1,e,a)),d&&d._handleDoubleClick(a,b||c&&this)},b._dispatchMouseEvent=function(a,b,c,d,e,f,g){if(a&&(c||a.hasEventListener(b))){var h=new createjs.MouseEvent(b,c,!1,e.x,e.y,f,d,d===this._primaryPointerID||-1===d,e.rawX,e.rawY,g);a.dispatchEvent(h)}},createjs.Stage=createjs.promote(a,"Container")}(),this.createjs=this.createjs||{},function(){function a(a){this.DisplayObject_constructor(),"string"==typeof a?(this.image=document.createElement("img"),this.image.src=a):this.image=a,this.sourceRect=null}var b=createjs.extend(a,createjs.DisplayObject);b.initialize=a,b.isVisible=function(){var a=this.image,b=this.cacheCanvas||a&&(a.naturalWidth||a.getContext||a.readyState>=2);return!!(this.visible&&this.alpha>0&&0!=this.scaleX&&0!=this.scaleY&&b)},b.draw=function(a,b){if(this.DisplayObject_draw(a,b)||!this.image)return!0;var c=this.image,d=this.sourceRect;if(d){var e=d.x,f=d.y,g=e+d.width,h=f+d.height,i=0,j=0,k=c.width,l=c.height;0>e&&(i-=e,e=0),g>k&&(g=k),0>f&&(j-=f,f=0),h>l&&(h=l),a.drawImage(c,e,f,g-e,h-f,i,j,g-e,h-f)}else a.drawImage(c,0,0);return!0},b.getBounds=function(){var a=this.DisplayObject_getBounds();if(a)return a;var b=this.image,c=this.sourceRect||b,d=b&&(b.naturalWidth||b.getContext||b.readyState>=2);return d?this._rectangle.setValues(0,0,c.width,c.height):null},b.clone=function(){var b=new a(this.image);return this.sourceRect&&(b.sourceRect=this.sourceRect.clone()),this._cloneProps(b),b},b.toString=function(){return"[Bitmap (name="+this.name+")]"},createjs.Bitmap=createjs.promote(a,"DisplayObject")}(),this.createjs=this.createjs||{},function(){"use strict";function a(a,b){this.DisplayObject_constructor(),this.currentFrame=0,this.currentAnimation=null,this.paused=!0,this.spriteSheet=a,this.currentAnimationFrame=0,this.framerate=0,this._animation=null,this._currentFrame=null,this._skipAdvance=!1,null!=b&&this.gotoAndPlay(b)}var b=createjs.extend(a,createjs.DisplayObject);b.initialize=a,b.isVisible=function(){var a=this.cacheCanvas||this.spriteSheet.complete;return!!(this.visible&&this.alpha>0&&0!=this.scaleX&&0!=this.scaleY&&a)},b.draw=function(a,b){if(this.DisplayObject_draw(a,b))return!0;this._normalizeFrame();var c=this.spriteSheet.getFrame(0|this._currentFrame);if(!c)return!1;var d=c.rect;return d.width&&d.height&&a.drawImage(c.image,d.x,d.y,d.width,d.height,-c.regX,-c.regY,d.width,d.height),!0},b.play=function(){this.paused=!1},b.stop=function(){this.paused=!0},b.gotoAndPlay=function(a){this.paused=!1,this._skipAdvance=!0,this._goto(a)},b.gotoAndStop=function(a){this.paused=!0,this._goto(a)},b.advance=function(a){var b=this.framerate||this.spriteSheet.framerate,c=b&&null!=a?a/(1e3/b):1;this._normalizeFrame(c)},b.getBounds=function(){return this.DisplayObject_getBounds()||this.spriteSheet.getFrameBounds(this.currentFrame,this._rectangle)},b.clone=function(){return this._cloneProps(new a(this.spriteSheet))},b.toString=function(){return"[Sprite (name="+this.name+")]"},b._cloneProps=function(a){return this.DisplayObject__cloneProps(a),a.currentFrame=this.currentFrame,a.currentAnimation=this.currentAnimation,a.paused=this.paused,a.currentAnimationFrame=this.currentAnimationFrame,a.framerate=this.framerate,a._animation=this._animation,a._currentFrame=this._currentFrame,a._skipAdvance=this._skipAdvance,a},b._tick=function(a){this.paused||(this._skipAdvance||this.advance(a&&a.delta),this._skipAdvance=!1),this.DisplayObject__tick(a)},b._normalizeFrame=function(a){a=a||0;var b,c=this._animation,d=this.paused,e=this._currentFrame;if(c){var f=c.speed||1,g=this.currentAnimationFrame;if(b=c.frames.length,g+a*f>=b){var h=c.next;if(this._dispatchAnimationEnd(c,e,d,h,b-1))return;if(h)return this._goto(h,a-(b-g)/f);this.paused=!0,g=c.frames.length-1}else g+=a*f;this.currentAnimationFrame=g,this._currentFrame=c.frames[0|g]}else if(e=this._currentFrame+=a,b=this.spriteSheet.getNumFrames(),e>=b&&b>0&&!this._dispatchAnimationEnd(c,e,d,b-1)&&(this._currentFrame-=b)>=b)return this._normalizeFrame();e=0|this._currentFrame,this.currentFrame!=e&&(this.currentFrame=e,this.dispatchEvent("change"))},b._dispatchAnimationEnd=function(a,b,c,d,e){var f=a?a.name:null;if(this.hasEventListener("animationend")){var g=new createjs.Event("animationend");g.name=f,g.next=d,this.dispatchEvent(g)}var h=this._animation!=a||this._currentFrame!=b;return h||c||!this.paused||(this.currentAnimationFrame=e,h=!0),h},b._goto=function(a,b){if(this.currentAnimationFrame=0,isNaN(a)){var c=this.spriteSheet.getAnimation(a);c&&(this._animation=c,this.currentAnimation=a,this._normalizeFrame(b))}else this.currentAnimation=this._animation=null,this._currentFrame=a,this._normalizeFrame()},createjs.Sprite=createjs.promote(a,"DisplayObject")}(),this.createjs=this.createjs||{},function(){"use strict";function a(a){this.DisplayObject_constructor(),this.graphics=a?a:new createjs.Graphics}var b=createjs.extend(a,createjs.DisplayObject);b.isVisible=function(){var a=this.cacheCanvas||this.graphics&&!this.graphics.isEmpty();return!!(this.visible&&this.alpha>0&&0!=this.scaleX&&0!=this.scaleY&&a)},b.draw=function(a,b){return this.DisplayObject_draw(a,b)?!0:(this.graphics.draw(a,this),!0)},b.clone=function(b){var c=b&&this.graphics?this.graphics.clone():this.graphics;return this._cloneProps(new a(c))},b.toString=function(){return"[Shape (name="+this.name+")]"},createjs.Shape=createjs.promote(a,"DisplayObject")}(),this.createjs=this.createjs||{},function(){"use strict";function a(a,b,c){this.DisplayObject_constructor(),this.text=a,this.font=b,this.color=c,this.textAlign="left",this.textBaseline="top",this.maxWidth=null,this.outline=0,this.lineHeight=0,this.lineWidth=null}var b=createjs.extend(a,createjs.DisplayObject),c=createjs.createCanvas?createjs.createCanvas():document.createElement("canvas");c.getContext&&(a._workingContext=c.getContext("2d"),c.width=c.height=1),a.H_OFFSETS={start:0,left:0,center:-.5,end:-1,right:-1},a.V_OFFSETS={top:0,hanging:-.01,middle:-.4,alphabetic:-.8,ideographic:-.85,bottom:-1},b.isVisible=function(){var a=this.cacheCanvas||null!=this.text&&""!==this.text;return!!(this.visible&&this.alpha>0&&0!=this.scaleX&&0!=this.scaleY&&a)},b.draw=function(a,b){if(this.DisplayObject_draw(a,b))return!0;var c=this.color||"#000";return this.outline?(a.strokeStyle=c,a.lineWidth=1*this.outline):a.fillStyle=c,this._drawText(this._prepContext(a)),!0},b.getMeasuredWidth=function(){return this._getMeasuredWidth(this.text)},b.getMeasuredLineHeight=function(){return 1.2*this._getMeasuredWidth("M")},b.getMeasuredHeight=function(){return this._drawText(null,{}).height},b.getBounds=function(){var b=this.DisplayObject_getBounds();if(b)return b;if(null==this.text||""===this.text)return null;var c=this._drawText(null,{}),d=this.maxWidth&&this.maxWidth<c.width?this.maxWidth:c.width,e=d*a.H_OFFSETS[this.textAlign||"left"],f=this.lineHeight||this.getMeasuredLineHeight(),g=f*a.V_OFFSETS[this.textBaseline||"top"];return this._rectangle.setValues(e,g,d,c.height)},b.getMetrics=function(){var b={lines:[]};return b.lineHeight=this.lineHeight||this.getMeasuredLineHeight(),b.vOffset=b.lineHeight*a.V_OFFSETS[this.textBaseline||"top"],this._drawText(null,b,b.lines)},b.clone=function(){return this._cloneProps(new a(this.text,this.font,this.color))},b.toString=function(){return"[Text (text="+(this.text.length>20?this.text.substr(0,17)+"...":this.text)+")]"},b._cloneProps=function(a){return this.DisplayObject__cloneProps(a),a.textAlign=this.textAlign,a.textBaseline=this.textBaseline,a.maxWidth=this.maxWidth,a.outline=this.outline,a.lineHeight=this.lineHeight,a.lineWidth=this.lineWidth,a},b._prepContext=function(a){return a.font=this.font||"10px sans-serif",a.textAlign=this.textAlign||"left",a.textBaseline=this.textBaseline||"top",a},b._drawText=function(b,c,d){var e=!!b;e||(b=a._workingContext,b.save(),this._prepContext(b));for(var f=this.lineHeight||this.getMeasuredLineHeight(),g=0,h=0,i=String(this.text).split(/(?:\r\n|\r|\n)/),j=0,k=i.length;k>j;j++){var l=i[j],m=null;if(null!=this.lineWidth&&(m=b.measureText(l).width)>this.lineWidth){var n=l.split(/(\s)/);l=n[0],m=b.measureText(l).width;for(var o=1,p=n.length;p>o;o+=2){var q=b.measureText(n[o]+n[o+1]).width;m+q>this.lineWidth?(e&&this._drawTextLine(b,l,h*f),d&&d.push(l),m>g&&(g=m),l=n[o+1],m=b.measureText(l).width,h++):(l+=n[o]+n[o+1],m+=q)}}e&&this._drawTextLine(b,l,h*f),d&&d.push(l),c&&null==m&&(m=b.measureText(l).width),m>g&&(g=m),h++}return c&&(c.width=g,c.height=h*f),e||b.restore(),c},b._drawTextLine=function(a,b,c){this.outline?a.strokeText(b,0,c,this.maxWidth||65535):a.fillText(b,0,c,this.maxWidth||65535)},b._getMeasuredWidth=function(b){var c=a._workingContext;c.save();var d=this._prepContext(c).measureText(b).width;return c.restore(),d},createjs.Text=createjs.promote(a,"DisplayObject")}(),this.createjs=this.createjs||{},function(){"use strict";function a(a,b){this.Container_constructor(),this.text=a||"",this.spriteSheet=b,this.lineHeight=0,this.letterSpacing=0,this.spaceWidth=0,this._oldProps={text:0,spriteSheet:0,lineHeight:0,letterSpacing:0,spaceWidth:0}}var b=createjs.extend(a,createjs.Container);a.maxPoolSize=100,a._spritePool=[],b.draw=function(a,b){this.DisplayObject_draw(a,b)||(this._updateText(),this.Container_draw(a,b))},b.getBounds=function(){return this._updateText(),this.Container_getBounds()},b.isVisible=function(){var a=this.cacheCanvas||this.spriteSheet&&this.spriteSheet.complete&&this.text;return!!(this.visible&&this.alpha>0&&0!==this.scaleX&&0!==this.scaleY&&a)},b.clone=function(){return this._cloneProps(new a(this.text,this.spriteSheet))},b.addChild=b.addChildAt=b.removeChild=b.removeChildAt=b.removeAllChildren=function(){},b._cloneProps=function(a){return this.Container__cloneProps(a),a.lineHeight=this.lineHeight,a.letterSpacing=this.letterSpacing,a.spaceWidth=this.spaceWidth,a},b._getFrameIndex=function(a,b){var c,d=b.getAnimation(a);return d||(a!=(c=a.toUpperCase())||a!=(c=a.toLowerCase())||(c=null),c&&(d=b.getAnimation(c))),d&&d.frames[0]},b._getFrame=function(a,b){var c=this._getFrameIndex(a,b);return null==c?c:b.getFrame(c)},b._getLineHeight=function(a){var b=this._getFrame("1",a)||this._getFrame("T",a)||this._getFrame("L",a)||a.getFrame(0);return b?b.rect.height:1},b._getSpaceWidth=function(a){var b=this._getFrame("1",a)||this._getFrame("l",a)||this._getFrame("e",a)||this._getFrame("a",a)||a.getFrame(0);return b?b.rect.width:1},b._updateText=function(){var b,c=0,d=0,e=this._oldProps,f=!1,g=this.spaceWidth,h=this.lineHeight,i=this.spriteSheet,j=a._spritePool,k=this.children,l=0,m=k.length;for(var n in e)e[n]!=this[n]&&(e[n]=this[n],f=!0);if(f){var o=!!this._getFrame(" ",i);o||g||(g=this._getSpaceWidth(i)),h||(h=this._getLineHeight(i));for(var p=0,q=this.text.length;q>p;p++){var r=this.text.charAt(p);if(" "!=r||o)if("\n"!=r&&"\r"!=r){var s=this._getFrameIndex(r,i);null!=s&&(m>l?b=k[l]:(k.push(b=j.length?j.pop():new createjs.Sprite),b.parent=this,m++),b.spriteSheet=i,b.gotoAndStop(s),b.x=c,b.y=d,l++,c+=b.getBounds().width+this.letterSpacing)}else"\r"==r&&"\n"==this.text.charAt(p+1)&&p++,c=0,d+=h;else c+=g}for(;m>l;)j.push(b=k.pop()),b.parent=null,m--;j.length>a.maxPoolSize&&(j.length=a.maxPoolSize)}},createjs.BitmapText=createjs.promote(a,"Container")}(),this.createjs=this.createjs||{},function(){"use strict";function a(b,c,d,e){this.Container_constructor(),!a.inited&&a.init(),this.mode=b||a.INDEPENDENT,this.startPosition=c||0,this.loop=d,this.currentFrame=0,this.timeline=new createjs.Timeline(null,e,{paused:!0,position:c,useTicks:!0}),this.paused=!1,this.actionsEnabled=!0,this.autoReset=!0,this.frameBounds=this.frameBounds||null,this.framerate=null,this._synchOffset=0,this._prevPos=-1,this._prevPosition=0,this._t=0,this._managed={}}function b(){throw"MovieClipPlugin cannot be instantiated."}var c=createjs.extend(a,createjs.Container);a.INDEPENDENT="independent",a.SINGLE_FRAME="single",a.SYNCHED="synched",a.inited=!1,a.init=function(){a.inited||(b.install(),a.inited=!0)},c.getLabels=function(){return this.timeline.getLabels()},c.getCurrentLabel=function(){return this._updateTimeline(),this.timeline.getCurrentLabel()},c.getDuration=function(){return this.timeline.duration;
};try{Object.defineProperties(c,{labels:{get:c.getLabels},currentLabel:{get:c.getCurrentLabel},totalFrames:{get:c.getDuration},duration:{get:c.getDuration}})}catch(d){}c.initialize=a,c.isVisible=function(){return!!(this.visible&&this.alpha>0&&0!=this.scaleX&&0!=this.scaleY)},c.draw=function(a,b){return this.DisplayObject_draw(a,b)?!0:(this._updateTimeline(),this.Container_draw(a,b),!0)},c.play=function(){this.paused=!1},c.stop=function(){this.paused=!0},c.gotoAndPlay=function(a){this.paused=!1,this._goto(a)},c.gotoAndStop=function(a){this.paused=!0,this._goto(a)},c.advance=function(b){var c=a.INDEPENDENT;if(this.mode==c){for(var d=this,e=d.framerate;(d=d.parent)&&null==e;)d.mode==c&&(e=d._framerate);this._framerate=e;var f=null!=e&&-1!=e&&null!=b?b/(1e3/e)+this._t:1,g=0|f;for(this._t=f-g;!this.paused&&g--;)this._prevPosition=this._prevPos<0?0:this._prevPosition+1,this._updateTimeline()}},c.clone=function(){throw"MovieClip cannot be cloned."},c.toString=function(){return"[MovieClip (name="+this.name+")]"},c._tick=function(a){this.advance(a&&a.delta),this.Container__tick(a)},c._goto=function(a){var b=this.timeline.resolve(a);null!=b&&(-1==this._prevPos&&(this._prevPos=NaN),this._prevPosition=b,this._t=0,this._updateTimeline())},c._reset=function(){this._prevPos=-1,this._t=this.currentFrame=0,this.paused=!1},c._updateTimeline=function(){var b=this.timeline,c=this.mode!=a.INDEPENDENT;b.loop=null==this.loop?!0:this.loop;var d=c?this.startPosition+(this.mode==a.SINGLE_FRAME?0:this._synchOffset):this._prevPos<0?0:this._prevPosition,e=c||!this.actionsEnabled?createjs.Tween.NONE:null;if(this.currentFrame=b._calcPosition(d),b.setPosition(d,e),this._prevPosition=b._prevPosition,this._prevPos!=b._prevPos){this.currentFrame=this._prevPos=b._prevPos;for(var f in this._managed)this._managed[f]=1;for(var g=b._tweens,h=0,i=g.length;i>h;h++){var j=g[h],k=j._target;if(k!=this&&!j.passive){var l=j._stepPosition;k instanceof createjs.DisplayObject?this._addManagedChild(k,l):this._setState(k.state,l)}}var m=this.children;for(h=m.length-1;h>=0;h--){var n=m[h].id;1==this._managed[n]&&(this.removeChildAt(h),delete this._managed[n])}}},c._setState=function(a,b){if(a)for(var c=a.length-1;c>=0;c--){var d=a[c],e=d.t,f=d.p;for(var g in f)e[g]=f[g];this._addManagedChild(e,b)}},c._addManagedChild=function(b,c){b._off||(this.addChildAt(b,0),b instanceof a&&(b._synchOffset=c,b.mode==a.INDEPENDENT&&b.autoReset&&!this._managed[b.id]&&b._reset()),this._managed[b.id]=2)},c._getBounds=function(a,b){var c=this.DisplayObject_getBounds();return c||(this._updateTimeline(),this.frameBounds&&(c=this._rectangle.copy(this.frameBounds[this.currentFrame]))),c?this._transformBounds(c,a,b):this.Container__getBounds(a,b)},createjs.MovieClip=createjs.promote(a,"Container"),b.priority=100,b.install=function(){createjs.Tween.installPlugin(b,["startPosition"])},b.init=function(a,b,c){return c},b.step=function(){},b.tween=function(b,c,d,e,f,g,h,i){return b.target instanceof a?1==g?f[c]:e[c]:d}}(),this.createjs=this.createjs||{},function(){"use strict";function a(){throw"SpriteSheetUtils cannot be instantiated"}var b=createjs.createCanvas?createjs.createCanvas():document.createElement("canvas");b.getContext&&(a._workingCanvas=b,a._workingContext=b.getContext("2d"),b.width=b.height=1),a.addFlippedFrames=function(b,c,d,e){if(c||d||e){var f=0;c&&a._flip(b,++f,!0,!1),d&&a._flip(b,++f,!1,!0),e&&a._flip(b,++f,!0,!0)}},a.extractFrame=function(b,c){isNaN(c)&&(c=b.getAnimation(c).frames[0]);var d=b.getFrame(c);if(!d)return null;var e=d.rect,f=a._workingCanvas;f.width=e.width,f.height=e.height,a._workingContext.drawImage(d.image,e.x,e.y,e.width,e.height,0,0,e.width,e.height);var g=document.createElement("img");return g.src=f.toDataURL("image/png"),g},a.mergeAlpha=function(a,b,c){c||(c=createjs.createCanvas?createjs.createCanvas():document.createElement("canvas")),c.width=Math.max(b.width,a.width),c.height=Math.max(b.height,a.height);var d=c.getContext("2d");return d.save(),d.drawImage(a,0,0),d.globalCompositeOperation="destination-in",d.drawImage(b,0,0),d.restore(),c},a._flip=function(b,c,d,e){for(var f=b._images,g=a._workingCanvas,h=a._workingContext,i=f.length/c,j=0;i>j;j++){var k=f[j];k.__tmp=j,h.setTransform(1,0,0,1,0,0),h.clearRect(0,0,g.width+1,g.height+1),g.width=k.width,g.height=k.height,h.setTransform(d?-1:1,0,0,e?-1:1,d?k.width:0,e?k.height:0),h.drawImage(k,0,0);var l=document.createElement("img");l.src=g.toDataURL("image/png"),l.width=k.width,l.height=k.height,f.push(l)}var m=b._frames,n=m.length/c;for(j=0;n>j;j++){k=m[j];var o=k.rect.clone();l=f[k.image.__tmp+i*c];var p={image:l,rect:o,regX:k.regX,regY:k.regY};d&&(o.x=l.width-o.x-o.width,p.regX=o.width-k.regX),e&&(o.y=l.height-o.y-o.height,p.regY=o.height-k.regY),m.push(p)}var q="_"+(d?"h":"")+(e?"v":""),r=b._animations,s=b._data,t=r.length/c;for(j=0;t>j;j++){var u=r[j];k=s[u];var v={name:u+q,speed:k.speed,next:k.next,frames:[]};k.next&&(v.next+=q),m=k.frames;for(var w=0,x=m.length;x>w;w++)v.frames.push(m[w]+n*c);s[v.name]=v,r.push(v.name)}},createjs.SpriteSheetUtils=a}(),this.createjs=this.createjs||{},function(){"use strict";function a(a){this.EventDispatcher_constructor(),this.maxWidth=2048,this.maxHeight=2048,this.spriteSheet=null,this.scale=1,this.padding=1,this.timeSlice=.3,this.progress=-1,this.framerate=a||0,this._frames=[],this._animations={},this._data=null,this._nextFrameIndex=0,this._index=0,this._timerID=null,this._scale=1}var b=createjs.extend(a,createjs.EventDispatcher);a.ERR_DIMENSIONS="frame dimensions exceed max spritesheet dimensions",a.ERR_RUNNING="a build is already running",b.addFrame=function(b,c,d,e,f){if(this._data)throw a.ERR_RUNNING;var g=c||b.bounds||b.nominalBounds;return!g&&b.getBounds&&(g=b.getBounds()),g?(d=d||1,this._frames.push({source:b,sourceRect:g,scale:d,funct:e,data:f,index:this._frames.length,height:g.height*d})-1):null},b.addAnimation=function(b,c,d,e){if(this._data)throw a.ERR_RUNNING;this._animations[b]={frames:c,next:d,speed:e}},b.addMovieClip=function(b,c,d,e,f,g){if(this._data)throw a.ERR_RUNNING;var h=b.frameBounds,i=c||b.bounds||b.nominalBounds;if(!i&&b.getBounds&&(i=b.getBounds()),i||h){var j,k,l=this._frames.length,m=b.timeline.duration;for(j=0;m>j;j++){var n=h&&h[j]?h[j]:i;this.addFrame(b,n,d,this._setupMovieClipFrame,{i:j,f:e,d:f})}var o=b.timeline._labels,p=[];for(var q in o)p.push({index:o[q],label:q});if(p.length)for(p.sort(function(a,b){return a.index-b.index}),j=0,k=p.length;k>j;j++){for(var r=p[j].label,s=l+p[j].index,t=l+(j==k-1?m:p[j+1].index),u=[],v=s;t>v;v++)u.push(v);(!g||(r=g(r,b,s,t)))&&this.addAnimation(r,u,!0)}}},b.build=function(){if(this._data)throw a.ERR_RUNNING;for(this._startBuild();this._drawNext(););return this._endBuild(),this.spriteSheet},b.buildAsync=function(b){if(this._data)throw a.ERR_RUNNING;this.timeSlice=b,this._startBuild();var c=this;this._timerID=setTimeout(function(){c._run()},50-50*Math.max(.01,Math.min(.99,this.timeSlice||.3)))},b.stopAsync=function(){clearTimeout(this._timerID),this._data=null},b.clone=function(){throw"SpriteSheetBuilder cannot be cloned."},b.toString=function(){return"[SpriteSheetBuilder]"},b._startBuild=function(){var b=this.padding||0;this.progress=0,this.spriteSheet=null,this._index=0,this._scale=this.scale;var c=[];this._data={images:[],frames:c,framerate:this.framerate,animations:this._animations};var d=this._frames.slice();if(d.sort(function(a,b){return a.height<=b.height?-1:1}),d[d.length-1].height+2*b>this.maxHeight)throw a.ERR_DIMENSIONS;for(var e=0,f=0,g=0;d.length;){var h=this._fillRow(d,e,g,c,b);if(h.w>f&&(f=h.w),e+=h.h,!h.h||!d.length){var i=createjs.createCanvas?createjs.createCanvas():document.createElement("canvas");i.width=this._getSize(f,this.maxWidth),i.height=this._getSize(e,this.maxHeight),this._data.images[g]=i,h.h||(f=e=0,g++)}}},b._setupMovieClipFrame=function(a,b){var c=a.actionsEnabled;a.actionsEnabled=!1,a.gotoAndStop(b.i),a.actionsEnabled=c,b.f&&b.f(a,b.d,b.i)},b._getSize=function(a,b){for(var c=4;Math.pow(2,++c)<a;);return Math.min(b,Math.pow(2,c))},b._fillRow=function(b,c,d,e,f){var g=this.maxWidth,h=this.maxHeight;c+=f;for(var i=h-c,j=f,k=0,l=b.length-1;l>=0;l--){var m=b[l],n=this._scale*m.scale,o=m.sourceRect,p=m.source,q=Math.floor(n*o.x-f),r=Math.floor(n*o.y-f),s=Math.ceil(n*o.height+2*f),t=Math.ceil(n*o.width+2*f);if(t>g)throw a.ERR_DIMENSIONS;s>i||j+t>g||(m.img=d,m.rect=new createjs.Rectangle(j,c,t,s),k=k||s,b.splice(l,1),e[m.index]=[j,c,t,s,d,Math.round(-q+n*p.regX-f),Math.round(-r+n*p.regY-f)],j+=t)}return{w:j,h:k}},b._endBuild=function(){this.spriteSheet=new createjs.SpriteSheet(this._data),this._data=null,this.progress=1,this.dispatchEvent("complete")},b._run=function(){for(var a=50*Math.max(.01,Math.min(.99,this.timeSlice||.3)),b=(new Date).getTime()+a,c=!1;b>(new Date).getTime();)if(!this._drawNext()){c=!0;break}if(c)this._endBuild();else{var d=this;this._timerID=setTimeout(function(){d._run()},50-a)}var e=this.progress=this._index/this._frames.length;if(this.hasEventListener("progress")){var f=new createjs.Event("progress");f.progress=e,this.dispatchEvent(f)}},b._drawNext=function(){var a=this._frames[this._index],b=a.scale*this._scale,c=a.rect,d=a.sourceRect,e=this._data.images[a.img],f=e.getContext("2d");return a.funct&&a.funct(a.source,a.data),f.save(),f.beginPath(),f.rect(c.x,c.y,c.width,c.height),f.clip(),f.translate(Math.ceil(c.x-d.x*b),Math.ceil(c.y-d.y*b)),f.scale(b,b),a.source.draw(f),f.restore(),++this._index<this._frames.length},createjs.SpriteSheetBuilder=createjs.promote(a,"EventDispatcher")}(),this.createjs=this.createjs||{},function(){"use strict";function a(a){this.DisplayObject_constructor(),"string"==typeof a&&(a=document.getElementById(a)),this.mouseEnabled=!1;var b=a.style;b.position="absolute",b.transformOrigin=b.WebkitTransformOrigin=b.msTransformOrigin=b.MozTransformOrigin=b.OTransformOrigin="0% 0%",this.htmlElement=a,this._oldProps=null}var b=createjs.extend(a,createjs.DisplayObject);b.isVisible=function(){return null!=this.htmlElement},b.draw=function(a,b){return!0},b.cache=function(){},b.uncache=function(){},b.updateCache=function(){},b.hitTest=function(){},b.localToGlobal=function(){},b.globalToLocal=function(){},b.localToLocal=function(){},b.clone=function(){throw"DOMElement cannot be cloned."},b.toString=function(){return"[DOMElement (name="+this.name+")]"},b._tick=function(a){var b=this.getStage();b&&b.on("drawend",this._handleDrawEnd,this,!0),this.DisplayObject__tick(a)},b._handleDrawEnd=function(a){var b=this.htmlElement;if(b){var c=b.style,d=this.getConcatenatedDisplayProps(this._props),e=d.matrix,f=d.visible?"visible":"hidden";if(f!=c.visibility&&(c.visibility=f),d.visible){var g=this._oldProps,h=g&&g.matrix,i=1e4;if(!h||!h.equals(e)){var j="matrix("+(e.a*i|0)/i+","+(e.b*i|0)/i+","+(e.c*i|0)/i+","+(e.d*i|0)/i+","+(e.tx+.5|0);c.transform=c.WebkitTransform=c.OTransform=c.msTransform=j+","+(e.ty+.5|0)+")",c.MozTransform=j+"px,"+(e.ty+.5|0)+"px)",g||(g=this._oldProps=new createjs.DisplayProps(!0,NaN)),g.matrix.copy(e)}g.alpha!=d.alpha&&(c.opacity=""+(d.alpha*i|0)/i,g.alpha=d.alpha)}}},createjs.DOMElement=createjs.promote(a,"DisplayObject")}(),this.createjs=this.createjs||{},function(){"use strict";function a(){}var b=a.prototype;b.getBounds=function(a){return a},b.applyFilter=function(a,b,c,d,e,f,g,h){f=f||a,null==g&&(g=b),null==h&&(h=c);try{var i=a.getImageData(b,c,d,e)}catch(j){return!1}return this._applyFilter(i)?(f.putImageData(i,g,h),!0):!1},b.toString=function(){return"[Filter]"},b.clone=function(){return new a},b._applyFilter=function(a){return!0},createjs.Filter=a}(),this.createjs=this.createjs||{},function(){"use strict";function a(a,b,c){(isNaN(a)||0>a)&&(a=0),(isNaN(b)||0>b)&&(b=0),(isNaN(c)||1>c)&&(c=1),this.blurX=0|a,this.blurY=0|b,this.quality=0|c}var b=createjs.extend(a,createjs.Filter);a.MUL_TABLE=[1,171,205,293,57,373,79,137,241,27,391,357,41,19,283,265,497,469,443,421,25,191,365,349,335,161,155,149,9,278,269,261,505,245,475,231,449,437,213,415,405,395,193,377,369,361,353,345,169,331,325,319,313,307,301,37,145,285,281,69,271,267,263,259,509,501,493,243,479,118,465,459,113,446,55,435,429,423,209,413,51,403,199,393,97,3,379,375,371,367,363,359,355,351,347,43,85,337,333,165,327,323,5,317,157,311,77,305,303,75,297,294,73,289,287,71,141,279,277,275,68,135,67,133,33,262,260,129,511,507,503,499,495,491,61,121,481,477,237,235,467,232,115,457,227,451,7,445,221,439,218,433,215,427,425,211,419,417,207,411,409,203,202,401,399,396,197,49,389,387,385,383,95,189,47,187,93,185,23,183,91,181,45,179,89,177,11,175,87,173,345,343,341,339,337,21,167,83,331,329,327,163,81,323,321,319,159,79,315,313,39,155,309,307,153,305,303,151,75,299,149,37,295,147,73,291,145,289,287,143,285,71,141,281,35,279,139,69,275,137,273,17,271,135,269,267,133,265,33,263,131,261,130,259,129,257,1],a.SHG_TABLE=[0,9,10,11,9,12,10,11,12,9,13,13,10,9,13,13,14,14,14,14,10,13,14,14,14,13,13,13,9,14,14,14,15,14,15,14,15,15,14,15,15,15,14,15,15,15,15,15,14,15,15,15,15,15,15,12,14,15,15,13,15,15,15,15,16,16,16,15,16,14,16,16,14,16,13,16,16,16,15,16,13,16,15,16,14,9,16,16,16,16,16,16,16,16,16,13,14,16,16,15,16,16,10,16,15,16,14,16,16,14,16,16,14,16,16,14,15,16,16,16,14,15,14,15,13,16,16,15,17,17,17,17,17,17,14,15,17,17,16,16,17,16,15,17,16,17,11,17,16,17,16,17,16,17,17,16,17,17,16,17,17,16,16,17,17,17,16,14,17,17,17,17,15,16,14,16,15,16,13,16,15,16,14,16,15,16,12,16,15,16,17,17,17,17,17,13,16,15,17,17,17,16,15,17,17,17,16,15,17,17,14,16,17,17,16,17,17,16,15,17,16,14,17,16,15,17,16,17,17,16,17,15,16,17,14,17,16,15,17,16,17,13,17,16,17,17,16,17,14,17,16,17,16,17,16,17,9],b.getBounds=function(a){var b=0|this.blurX,c=0|this.blurY;if(0>=b&&0>=c)return a;var d=Math.pow(this.quality,.2);return(a||new createjs.Rectangle).pad(b*d+1,c*d+1,b*d+1,c*d+1)},b.clone=function(){return new a(this.blurX,this.blurY,this.quality)},b.toString=function(){return"[BlurFilter]"},b._applyFilter=function(b){var c=this.blurX>>1;if(isNaN(c)||0>c)return!1;var d=this.blurY>>1;if(isNaN(d)||0>d)return!1;if(0==c&&0==d)return!1;var e=this.quality;(isNaN(e)||1>e)&&(e=1),e|=0,e>3&&(e=3),1>e&&(e=1);var f=b.data,g=0,h=0,i=0,j=0,k=0,l=0,m=0,n=0,o=0,p=0,q=0,r=0,s=0,t=0,u=0,v=c+c+1|0,w=d+d+1|0,x=0|b.width,y=0|b.height,z=x-1|0,A=y-1|0,B=c+1|0,C=d+1|0,D={r:0,b:0,g:0,a:0},E=D;for(i=1;v>i;i++)E=E.n={r:0,b:0,g:0,a:0};E.n=D;var F={r:0,b:0,g:0,a:0},G=F;for(i=1;w>i;i++)G=G.n={r:0,b:0,g:0,a:0};G.n=F;for(var H=null,I=0|a.MUL_TABLE[c],J=0|a.SHG_TABLE[c],K=0|a.MUL_TABLE[d],L=0|a.SHG_TABLE[d];e-->0;){m=l=0;var M=I,N=J;for(h=y;--h>-1;){for(n=B*(r=f[0|l]),o=B*(s=f[l+1|0]),p=B*(t=f[l+2|0]),q=B*(u=f[l+3|0]),E=D,i=B;--i>-1;)E.r=r,E.g=s,E.b=t,E.a=u,E=E.n;for(i=1;B>i;i++)j=l+((i>z?z:i)<<2)|0,n+=E.r=f[j],o+=E.g=f[j+1],p+=E.b=f[j+2],q+=E.a=f[j+3],E=E.n;for(H=D,g=0;x>g;g++)f[l++]=n*M>>>N,f[l++]=o*M>>>N,f[l++]=p*M>>>N,f[l++]=q*M>>>N,j=m+((j=g+c+1)<z?j:z)<<2,n-=H.r-(H.r=f[j]),o-=H.g-(H.g=f[j+1]),p-=H.b-(H.b=f[j+2]),q-=H.a-(H.a=f[j+3]),H=H.n;m+=x}for(M=K,N=L,g=0;x>g;g++){for(l=g<<2|0,n=C*(r=f[l])|0,o=C*(s=f[l+1|0])|0,p=C*(t=f[l+2|0])|0,q=C*(u=f[l+3|0])|0,G=F,i=0;C>i;i++)G.r=r,G.g=s,G.b=t,G.a=u,G=G.n;for(k=x,i=1;d>=i;i++)l=k+g<<2,n+=G.r=f[l],o+=G.g=f[l+1],p+=G.b=f[l+2],q+=G.a=f[l+3],G=G.n,A>i&&(k+=x);if(l=g,H=F,e>0)for(h=0;y>h;h++)j=l<<2,f[j+3]=u=q*M>>>N,u>0?(f[j]=n*M>>>N,f[j+1]=o*M>>>N,f[j+2]=p*M>>>N):f[j]=f[j+1]=f[j+2]=0,j=g+((j=h+C)<A?j:A)*x<<2,n-=H.r-(H.r=f[j]),o-=H.g-(H.g=f[j+1]),p-=H.b-(H.b=f[j+2]),q-=H.a-(H.a=f[j+3]),H=H.n,l+=x;else for(h=0;y>h;h++)j=l<<2,f[j+3]=u=q*M>>>N,u>0?(u=255/u,f[j]=(n*M>>>N)*u,f[j+1]=(o*M>>>N)*u,f[j+2]=(p*M>>>N)*u):f[j]=f[j+1]=f[j+2]=0,j=g+((j=h+C)<A?j:A)*x<<2,n-=H.r-(H.r=f[j]),o-=H.g-(H.g=f[j+1]),p-=H.b-(H.b=f[j+2]),q-=H.a-(H.a=f[j+3]),H=H.n,l+=x}}return!0},createjs.BlurFilter=createjs.promote(a,"Filter")}(),this.createjs=this.createjs||{},function(){"use strict";function a(a){this.alphaMap=a,this._alphaMap=null,this._mapData=null}var b=createjs.extend(a,createjs.Filter);b.clone=function(){var b=new a(this.alphaMap);return b._alphaMap=this._alphaMap,b._mapData=this._mapData,b},b.toString=function(){return"[AlphaMapFilter]"},b._applyFilter=function(a){if(!this.alphaMap)return!0;if(!this._prepAlphaMap())return!1;for(var b=a.data,c=this._mapData,d=0,e=b.length;e>d;d+=4)b[d+3]=c[d]||0;return!0},b._prepAlphaMap=function(){if(!this.alphaMap)return!1;if(this.alphaMap==this._alphaMap&&this._mapData)return!0;this._mapData=null;var a,b=this._alphaMap=this.alphaMap,c=b;b instanceof HTMLCanvasElement?a=c.getContext("2d"):(c=createjs.createCanvas?createjs.createCanvas():document.createElement("canvas"),c.width=b.width,c.height=b.height,a=c.getContext("2d"),a.drawImage(b,0,0));try{var d=a.getImageData(0,0,b.width,b.height)}catch(e){return!1}return this._mapData=d.data,!0},createjs.AlphaMapFilter=createjs.promote(a,"Filter")}(),this.createjs=this.createjs||{},function(){"use strict";function a(a){this.mask=a}var b=createjs.extend(a,createjs.Filter);b.applyFilter=function(a,b,c,d,e,f,g,h){return this.mask?(f=f||a,null==g&&(g=b),null==h&&(h=c),f.save(),a!=f?!1:(f.globalCompositeOperation="destination-in",f.drawImage(this.mask,g,h),f.restore(),!0)):!0},b.clone=function(){return new a(this.mask)},b.toString=function(){return"[AlphaMaskFilter]"},createjs.AlphaMaskFilter=createjs.promote(a,"Filter")}(),this.createjs=this.createjs||{},function(){"use strict";function a(a,b,c,d,e,f,g,h){this.redMultiplier=null!=a?a:1,this.greenMultiplier=null!=b?b:1,this.blueMultiplier=null!=c?c:1,this.alphaMultiplier=null!=d?d:1,this.redOffset=e||0,this.greenOffset=f||0,this.blueOffset=g||0,this.alphaOffset=h||0}var b=createjs.extend(a,createjs.Filter);b.toString=function(){return"[ColorFilter]"},b.clone=function(){return new a(this.redMultiplier,this.greenMultiplier,this.blueMultiplier,this.alphaMultiplier,this.redOffset,this.greenOffset,this.blueOffset,this.alphaOffset)},b._applyFilter=function(a){for(var b=a.data,c=b.length,d=0;c>d;d+=4)b[d]=b[d]*this.redMultiplier+this.redOffset,b[d+1]=b[d+1]*this.greenMultiplier+this.greenOffset,b[d+2]=b[d+2]*this.blueMultiplier+this.blueOffset,b[d+3]=b[d+3]*this.alphaMultiplier+this.alphaOffset;return!0},createjs.ColorFilter=createjs.promote(a,"Filter")}(),this.createjs=this.createjs||{},function(){"use strict";function a(a,b,c,d){this.setColor(a,b,c,d)}var b=a.prototype;a.DELTA_INDEX=[0,.01,.02,.04,.05,.06,.07,.08,.1,.11,.12,.14,.15,.16,.17,.18,.2,.21,.22,.24,.25,.27,.28,.3,.32,.34,.36,.38,.4,.42,.44,.46,.48,.5,.53,.56,.59,.62,.65,.68,.71,.74,.77,.8,.83,.86,.89,.92,.95,.98,1,1.06,1.12,1.18,1.24,1.3,1.36,1.42,1.48,1.54,1.6,1.66,1.72,1.78,1.84,1.9,1.96,2,2.12,2.25,2.37,2.5,2.62,2.75,2.87,3,3.2,3.4,3.6,3.8,4,4.3,4.7,4.9,5,5.5,6,6.5,6.8,7,7.3,7.5,7.8,8,8.4,8.7,9,9.4,9.6,9.8,10],a.IDENTITY_MATRIX=[1,0,0,0,0,0,1,0,0,0,0,0,1,0,0,0,0,0,1,0,0,0,0,0,1],a.LENGTH=a.IDENTITY_MATRIX.length,b.setColor=function(a,b,c,d){return this.reset().adjustColor(a,b,c,d)},b.reset=function(){return this.copy(a.IDENTITY_MATRIX)},b.adjustColor=function(a,b,c,d){return this.adjustHue(d),this.adjustContrast(b),this.adjustBrightness(a),this.adjustSaturation(c)},b.adjustBrightness=function(a){return 0==a||isNaN(a)?this:(a=this._cleanValue(a,255),this._multiplyMatrix([1,0,0,0,a,0,1,0,0,a,0,0,1,0,a,0,0,0,1,0,0,0,0,0,1]),this)},b.adjustContrast=function(b){if(0==b||isNaN(b))return this;b=this._cleanValue(b,100);var c;return 0>b?c=127+b/100*127:(c=b%1,c=0==c?a.DELTA_INDEX[b]:a.DELTA_INDEX[b<<0]*(1-c)+a.DELTA_INDEX[(b<<0)+1]*c,c=127*c+127),this._multiplyMatrix([c/127,0,0,0,.5*(127-c),0,c/127,0,0,.5*(127-c),0,0,c/127,0,.5*(127-c),0,0,0,1,0,0,0,0,0,1]),this},b.adjustSaturation=function(a){if(0==a||isNaN(a))return this;a=this._cleanValue(a,100);var b=1+(a>0?3*a/100:a/100),c=.3086,d=.6094,e=.082;return this._multiplyMatrix([c*(1-b)+b,d*(1-b),e*(1-b),0,0,c*(1-b),d*(1-b)+b,e*(1-b),0,0,c*(1-b),d*(1-b),e*(1-b)+b,0,0,0,0,0,1,0,0,0,0,0,1]),this},b.adjustHue=function(a){if(0==a||isNaN(a))return this;a=this._cleanValue(a,180)/180*Math.PI;var b=Math.cos(a),c=Math.sin(a),d=.213,e=.715,f=.072;return this._multiplyMatrix([d+b*(1-d)+c*-d,e+b*-e+c*-e,f+b*-f+c*(1-f),0,0,d+b*-d+.143*c,e+b*(1-e)+.14*c,f+b*-f+c*-.283,0,0,d+b*-d+c*-(1-d),e+b*-e+c*e,f+b*(1-f)+c*f,0,0,0,0,0,1,0,0,0,0,0,1]),this},b.concat=function(b){return b=this._fixMatrix(b),b.length!=a.LENGTH?this:(this._multiplyMatrix(b),this)},b.clone=function(){return(new a).copy(this)},b.toArray=function(){for(var b=[],c=0,d=a.LENGTH;d>c;c++)b[c]=this[c];return b},b.copy=function(b){for(var c=a.LENGTH,d=0;c>d;d++)this[d]=b[d];return this},b.toString=function(){return"[ColorMatrix]"},b._multiplyMatrix=function(a){var b,c,d,e=[];for(b=0;5>b;b++){for(c=0;5>c;c++)e[c]=this[c+5*b];for(c=0;5>c;c++){var f=0;for(d=0;5>d;d++)f+=a[c+5*d]*e[d];this[c+5*b]=f}}},b._cleanValue=function(a,b){return Math.min(b,Math.max(-b,a))},b._fixMatrix=function(b){return b instanceof a&&(b=b.toArray()),b.length<a.LENGTH?b=b.slice(0,b.length).concat(a.IDENTITY_MATRIX.slice(b.length,a.LENGTH)):b.length>a.LENGTH&&(b=b.slice(0,a.LENGTH)),b},createjs.ColorMatrix=a}(),this.createjs=this.createjs||{},function(){"use strict";function a(a){this.matrix=a}var b=createjs.extend(a,createjs.Filter);b.toString=function(){return"[ColorMatrixFilter]"},b.clone=function(){return new a(this.matrix)},b._applyFilter=function(a){for(var b,c,d,e,f=a.data,g=f.length,h=this.matrix,i=h[0],j=h[1],k=h[2],l=h[3],m=h[4],n=h[5],o=h[6],p=h[7],q=h[8],r=h[9],s=h[10],t=h[11],u=h[12],v=h[13],w=h[14],x=h[15],y=h[16],z=h[17],A=h[18],B=h[19],C=0;g>C;C+=4)b=f[C],c=f[C+1],d=f[C+2],e=f[C+3],f[C]=b*i+c*j+d*k+e*l+m,f[C+1]=b*n+c*o+d*p+e*q+r,f[C+2]=b*s+c*t+d*u+e*v+w,f[C+3]=b*x+c*y+d*z+e*A+B;return!0},createjs.ColorMatrixFilter=createjs.promote(a,"Filter")}(),this.createjs=this.createjs||{},function(){"use strict";function a(){throw"Touch cannot be instantiated"}a.isSupported=function(){return!!("ontouchstart"in window||window.navigator.msPointerEnabled&&window.navigator.msMaxTouchPoints>0||window.navigator.pointerEnabled&&window.navigator.maxTouchPoints>0)},a.enable=function(b,c,d){return b&&b.canvas&&a.isSupported()?b.__touch?!0:(b.__touch={pointers:{},multitouch:!c,preventDefault:!d,count:0},"ontouchstart"in window?a._IOS_enable(b):(window.navigator.msPointerEnabled||window.navigator.pointerEnabled)&&a._IE_enable(b),!0):!1},a.disable=function(b){b&&("ontouchstart"in window?a._IOS_disable(b):(window.navigator.msPointerEnabled||window.navigator.pointerEnabled)&&a._IE_disable(b),delete b.__touch)},a._IOS_enable=function(b){var c=b.canvas,d=b.__touch.f=function(c){a._IOS_handleEvent(b,c)};c.addEventListener("touchstart",d,!1),c.addEventListener("touchmove",d,!1),c.addEventListener("touchend",d,!1),c.addEventListener("touchcancel",d,!1)},a._IOS_disable=function(a){var b=a.canvas;if(b){var c=a.__touch.f;b.removeEventListener("touchstart",c,!1),b.removeEventListener("touchmove",c,!1),b.removeEventListener("touchend",c,!1),b.removeEventListener("touchcancel",c,!1)}},a._IOS_handleEvent=function(a,b){if(a){a.__touch.preventDefault&&b.preventDefault&&b.preventDefault();for(var c=b.changedTouches,d=b.type,e=0,f=c.length;f>e;e++){var g=c[e],h=g.identifier;g.target==a.canvas&&("touchstart"==d?this._handleStart(a,h,b,g.pageX,g.pageY):"touchmove"==d?this._handleMove(a,h,b,g.pageX,g.pageY):("touchend"==d||"touchcancel"==d)&&this._handleEnd(a,h,b))}}},a._IE_enable=function(b){var c=b.canvas,d=b.__touch.f=function(c){a._IE_handleEvent(b,c)};void 0===window.navigator.pointerEnabled?(c.addEventListener("MSPointerDown",d,!1),window.addEventListener("MSPointerMove",d,!1),window.addEventListener("MSPointerUp",d,!1),window.addEventListener("MSPointerCancel",d,!1),b.__touch.preventDefault&&(c.style.msTouchAction="none")):(c.addEventListener("pointerdown",d,!1),window.addEventListener("pointermove",d,!1),window.addEventListener("pointerup",d,!1),window.addEventListener("pointercancel",d,!1),b.__touch.preventDefault&&(c.style.touchAction="none")),b.__touch.activeIDs={}},a._IE_disable=function(a){var b=a.__touch.f;void 0===window.navigator.pointerEnabled?(window.removeEventListener("MSPointerMove",b,!1),window.removeEventListener("MSPointerUp",b,!1),window.removeEventListener("MSPointerCancel",b,!1),a.canvas&&a.canvas.removeEventListener("MSPointerDown",b,!1)):(window.removeEventListener("pointermove",b,!1),window.removeEventListener("pointerup",b,!1),window.removeEventListener("pointercancel",b,!1),a.canvas&&a.canvas.removeEventListener("pointerdown",b,!1))},a._IE_handleEvent=function(a,b){if(a){a.__touch.preventDefault&&b.preventDefault&&b.preventDefault();var c=b.type,d=b.pointerId,e=a.__touch.activeIDs;if("MSPointerDown"==c||"pointerdown"==c){if(b.srcElement!=a.canvas)return;e[d]=!0,this._handleStart(a,d,b,b.pageX,b.pageY)}else e[d]&&("MSPointerMove"==c||"pointermove"==c?this._handleMove(a,d,b,b.pageX,b.pageY):("MSPointerUp"==c||"MSPointerCancel"==c||"pointerup"==c||"pointercancel"==c)&&(delete e[d],this._handleEnd(a,d,b)))}},a._handleStart=function(a,b,c,d,e){var f=a.__touch;if(f.multitouch||!f.count){var g=f.pointers;g[b]||(g[b]=!0,f.count++,a._handlePointerDown(b,c,d,e))}},a._handleMove=function(a,b,c,d,e){a.__touch.pointers[b]&&a._handlePointerMove(b,c,d,e)},a._handleEnd=function(a,b,c){var d=a.__touch,e=d.pointers;e[b]&&(d.count--,a._handlePointerUp(b,c,!0),delete e[b])},createjs.Touch=a}(),this.createjs=this.createjs||{},function(){"use strict";var a=createjs.EaselJS=createjs.EaselJS||{};a.version="0.8.2",a.buildDate="Thu, 26 Nov 2015 20:44:34 GMT"}(),this.createjs=this.createjs||{},function(){"use strict";var a=createjs.PreloadJS=createjs.PreloadJS||{};a.version="0.6.2",a.buildDate="Thu, 26 Nov 2015 20:44:31 GMT"}(),this.createjs=this.createjs||{},function(){"use strict";createjs.proxy=function(a,b){var c=Array.prototype.slice.call(arguments,2);return function(){return a.apply(b,Array.prototype.slice.call(arguments,0).concat(c))}}}(),this.createjs=this.createjs||{},function(){"use strict";function a(a,b,c){this.Event_constructor("error"),this.title=a,this.message=b,this.data=c}var b=createjs.extend(a,createjs.Event);b.clone=function(){return new createjs.ErrorEvent(this.title,this.message,this.data)},createjs.ErrorEvent=createjs.promote(a,"Event")}(),this.createjs=this.createjs||{},function(a){"use strict";function b(a,b){this.Event_constructor("progress"),this.loaded=a,this.total=null==b?1:b,this.progress=0==b?0:this.loaded/this.total}var c=createjs.extend(b,createjs.Event);c.clone=function(){return new createjs.ProgressEvent(this.loaded,this.total)},createjs.ProgressEvent=createjs.promote(b,"Event")}(window),function(){function a(b,d){function f(a){if(f[a]!==q)return f[a];var b;if("bug-string-char-index"==a)b="a"!="a"[0];else if("json"==a)b=f("json-stringify")&&f("json-parse");else{var c,e='{"a":[1,true,false,null,"\\u0000\\b\\n\\f\\r\\t"]}';if("json-stringify"==a){var i=d.stringify,k="function"==typeof i&&t;if(k){(c=function(){return 1}).toJSON=c;try{k="0"===i(0)&&"0"===i(new g)&&'""'==i(new h)&&i(s)===q&&i(q)===q&&i()===q&&"1"===i(c)&&"[1]"==i([c])&&"[null]"==i([q])&&"null"==i(null)&&"[null,null,null]"==i([q,s,null])&&i({a:[c,!0,!1,null,"\x00\b\n\f\r	"]})==e&&"1"===i(null,c)&&"[\n 1,\n 2\n]"==i([1,2],null,1)&&'"-271821-04-20T00:00:00.000Z"'==i(new j(-864e13))&&'"+275760-09-13T00:00:00.000Z"'==i(new j(864e13))&&'"-000001-01-01T00:00:00.000Z"'==i(new j(-621987552e5))&&'"1969-12-31T23:59:59.999Z"'==i(new j(-1))}catch(l){k=!1}}b=k}if("json-parse"==a){var m=d.parse;if("function"==typeof m)try{if(0===m("0")&&!m(!1)){c=m(e);var n=5==c.a.length&&1===c.a[0];if(n){try{n=!m('"	"')}catch(l){}if(n)try{n=1!==m("01")}catch(l){}if(n)try{n=1!==m("1.")}catch(l){}}}}catch(l){n=!1}b=n}}return f[a]=!!b}b||(b=e.Object()),d||(d=e.Object());var g=b.Number||e.Number,h=b.String||e.String,i=b.Object||e.Object,j=b.Date||e.Date,k=b.SyntaxError||e.SyntaxError,l=b.TypeError||e.TypeError,m=b.Math||e.Math,n=b.JSON||e.JSON;"object"==typeof n&&n&&(d.stringify=n.stringify,d.parse=n.parse);var o,p,q,r=i.prototype,s=r.toString,t=new j(-0xc782b5b800cec);try{t=-109252==t.getUTCFullYear()&&0===t.getUTCMonth()&&1===t.getUTCDate()&&10==t.getUTCHours()&&37==t.getUTCMinutes()&&6==t.getUTCSeconds()&&708==t.getUTCMilliseconds()}catch(u){}if(!f("json")){var v="[object Function]",w="[object Date]",x="[object Number]",y="[object String]",z="[object Array]",A="[object Boolean]",B=f("bug-string-char-index");if(!t)var C=m.floor,D=[0,31,59,90,120,151,181,212,243,273,304,334],E=function(a,b){return D[b]+365*(a-1970)+C((a-1969+(b=+(b>1)))/4)-C((a-1901+b)/100)+C((a-1601+b)/400)};if((o=r.hasOwnProperty)||(o=function(a){var b,c={};return(c.__proto__=null,c.__proto__={toString:1},c).toString!=s?o=function(a){var b=this.__proto__,c=a in(this.__proto__=null,this);return this.__proto__=b,c}:(b=c.constructor,o=function(a){var c=(this.constructor||b).prototype;return a in this&&!(a in c&&this[a]===c[a])}),c=null,o.call(this,a)}),p=function(a,b){var d,e,f,g=0;(d=function(){this.valueOf=0}).prototype.valueOf=0,e=new d;for(f in e)o.call(e,f)&&g++;return d=e=null,g?p=2==g?function(a,b){var c,d={},e=s.call(a)==v;for(c in a)e&&"prototype"==c||o.call(d,c)||!(d[c]=1)||!o.call(a,c)||b(c)}:function(a,b){var c,d,e=s.call(a)==v;for(c in a)e&&"prototype"==c||!o.call(a,c)||(d="constructor"===c)||b(c);(d||o.call(a,c="constructor"))&&b(c)}:(e=["valueOf","toString","toLocaleString","propertyIsEnumerable","isPrototypeOf","hasOwnProperty","constructor"],p=function(a,b){var d,f,g=s.call(a)==v,h=!g&&"function"!=typeof a.constructor&&c[typeof a.hasOwnProperty]&&a.hasOwnProperty||o;for(d in a)g&&"prototype"==d||!h.call(a,d)||b(d);for(f=e.length;d=e[--f];h.call(a,d)&&b(d));}),p(a,b)},!f("json-stringify")){var F={92:"\\\\",34:'\\"',8:"\\b",12:"\\f",10:"\\n",13:"\\r",9:"\\t"},G="000000",H=function(a,b){return(G+(b||0)).slice(-a)},I="\\u00",J=function(a){for(var b='"',c=0,d=a.length,e=!B||d>10,f=e&&(B?a.split(""):a);d>c;c++){var g=a.charCodeAt(c);switch(g){case 8:case 9:case 10:case 12:case 13:case 34:case 92:b+=F[g];break;default:if(32>g){b+=I+H(2,g.toString(16));break}b+=e?f[c]:a.charAt(c)}}return b+'"'},K=function(a,b,c,d,e,f,g){var h,i,j,k,m,n,r,t,u,v,B,D,F,G,I,L;try{h=b[a]}catch(M){}if("object"==typeof h&&h)if(i=s.call(h),i!=w||o.call(h,"toJSON"))"function"==typeof h.toJSON&&(i!=x&&i!=y&&i!=z||o.call(h,"toJSON"))&&(h=h.toJSON(a));else if(h>-1/0&&1/0>h){if(E){for(m=C(h/864e5),j=C(m/365.2425)+1970-1;E(j+1,0)<=m;j++);for(k=C((m-E(j,0))/30.42);E(j,k+1)<=m;k++);m=1+m-E(j,k),n=(h%864e5+864e5)%864e5,r=C(n/36e5)%24,t=C(n/6e4)%60,u=C(n/1e3)%60,v=n%1e3}else j=h.getUTCFullYear(),k=h.getUTCMonth(),m=h.getUTCDate(),r=h.getUTCHours(),t=h.getUTCMinutes(),u=h.getUTCSeconds(),v=h.getUTCMilliseconds();h=(0>=j||j>=1e4?(0>j?"-":"+")+H(6,0>j?-j:j):H(4,j))+"-"+H(2,k+1)+"-"+H(2,m)+"T"+H(2,r)+":"+H(2,t)+":"+H(2,u)+"."+H(3,v)+"Z"}else h=null;if(c&&(h=c.call(b,a,h)),null===h)return"null";if(i=s.call(h),i==A)return""+h;if(i==x)return h>-1/0&&1/0>h?""+h:"null";if(i==y)return J(""+h);if("object"==typeof h){for(G=g.length;G--;)if(g[G]===h)throw l();if(g.push(h),B=[],I=f,f+=e,i==z){for(F=0,G=h.length;G>F;F++)D=K(F,h,c,d,e,f,g),B.push(D===q?"null":D);L=B.length?e?"[\n"+f+B.join(",\n"+f)+"\n"+I+"]":"["+B.join(",")+"]":"[]"}else p(d||h,function(a){var b=K(a,h,c,d,e,f,g);b!==q&&B.push(J(a)+":"+(e?" ":"")+b)}),L=B.length?e?"{\n"+f+B.join(",\n"+f)+"\n"+I+"}":"{"+B.join(",")+"}":"{}";return g.pop(),L}};d.stringify=function(a,b,d){var e,f,g,h;if(c[typeof b]&&b)if((h=s.call(b))==v)f=b;else if(h==z){g={};for(var i,j=0,k=b.length;k>j;i=b[j++],h=s.call(i),(h==y||h==x)&&(g[i]=1));}if(d)if((h=s.call(d))==x){if((d-=d%1)>0)for(e="",d>10&&(d=10);e.length<d;e+=" ");}else h==y&&(e=d.length<=10?d:d.slice(0,10));return K("",(i={},i[""]=a,i),f,g,e,"",[])}}if(!f("json-parse")){var L,M,N=h.fromCharCode,O={92:"\\",34:'"',47:"/",98:"\b",116:"	",110:"\n",102:"\f",114:"\r"},P=function(){throw L=M=null,k()},Q=function(){for(var a,b,c,d,e,f=M,g=f.length;g>L;)switch(e=f.charCodeAt(L)){case 9:case 10:case 13:case 32:L++;break;case 123:case 125:case 91:case 93:case 58:case 44:return a=B?f.charAt(L):f[L],L++,a;case 34:for(a="@",L++;g>L;)if(e=f.charCodeAt(L),32>e)P();else if(92==e)switch(e=f.charCodeAt(++L)){case 92:case 34:
case 47:case 98:case 116:case 110:case 102:case 114:a+=O[e],L++;break;case 117:for(b=++L,c=L+4;c>L;L++)e=f.charCodeAt(L),e>=48&&57>=e||e>=97&&102>=e||e>=65&&70>=e||P();a+=N("0x"+f.slice(b,L));break;default:P()}else{if(34==e)break;for(e=f.charCodeAt(L),b=L;e>=32&&92!=e&&34!=e;)e=f.charCodeAt(++L);a+=f.slice(b,L)}if(34==f.charCodeAt(L))return L++,a;P();default:if(b=L,45==e&&(d=!0,e=f.charCodeAt(++L)),e>=48&&57>=e){for(48==e&&(e=f.charCodeAt(L+1),e>=48&&57>=e)&&P(),d=!1;g>L&&(e=f.charCodeAt(L),e>=48&&57>=e);L++);if(46==f.charCodeAt(L)){for(c=++L;g>c&&(e=f.charCodeAt(c),e>=48&&57>=e);c++);c==L&&P(),L=c}if(e=f.charCodeAt(L),101==e||69==e){for(e=f.charCodeAt(++L),(43==e||45==e)&&L++,c=L;g>c&&(e=f.charCodeAt(c),e>=48&&57>=e);c++);c==L&&P(),L=c}return+f.slice(b,L)}if(d&&P(),"true"==f.slice(L,L+4))return L+=4,!0;if("false"==f.slice(L,L+5))return L+=5,!1;if("null"==f.slice(L,L+4))return L+=4,null;P()}return"$"},R=function(a){var b,c;if("$"==a&&P(),"string"==typeof a){if("@"==(B?a.charAt(0):a[0]))return a.slice(1);if("["==a){for(b=[];a=Q(),"]"!=a;c||(c=!0))c&&(","==a?(a=Q(),"]"==a&&P()):P()),","==a&&P(),b.push(R(a));return b}if("{"==a){for(b={};a=Q(),"}"!=a;c||(c=!0))c&&(","==a?(a=Q(),"}"==a&&P()):P()),(","==a||"string"!=typeof a||"@"!=(B?a.charAt(0):a[0])||":"!=Q())&&P(),b[a.slice(1)]=R(Q());return b}P()}return a},S=function(a,b,c){var d=T(a,b,c);d===q?delete a[b]:a[b]=d},T=function(a,b,c){var d,e=a[b];if("object"==typeof e&&e)if(s.call(e)==z)for(d=e.length;d--;)S(e,d,c);else p(e,function(a){S(e,a,c)});return c.call(a,b,e)};d.parse=function(a,b){var c,d;return L=0,M=""+a,c=R(Q()),"$"!=Q()&&P(),L=M=null,b&&s.call(b)==v?T((d={},d[""]=c,d),"",b):c}}}return d.runInContext=a,d}var b="function"==typeof define&&define.amd,c={"function":!0,object:!0},d=c[typeof exports]&&exports&&!exports.nodeType&&exports,e=c[typeof window]&&window||this,f=d&&c[typeof module]&&module&&!module.nodeType&&"object"==typeof global&&global;if(!f||f.global!==f&&f.window!==f&&f.self!==f||(e=f),d&&!b)a(e,d);else{var g=e.JSON,h=e.JSON3,i=!1,j=a(e,e.JSON3={noConflict:function(){return i||(i=!0,e.JSON=g,e.JSON3=h,g=h=null),j}});e.JSON={parse:j.parse,stringify:j.stringify}}b&&define(function(){return j})}.call(this),function(){var a={};a.appendToHead=function(b){a.getHead().appendChild(b)},a.getHead=function(){return document.head||document.getElementsByTagName("head")[0]},a.getBody=function(){return document.body||document.getElementsByTagName("body")[0]},createjs.DomUtils=a}(),function(){var a={};a.parseXML=function(a,b){var c=null;try{if(window.DOMParser){var d=new DOMParser;c=d.parseFromString(a,b)}}catch(e){}if(!c)try{c=new ActiveXObject("Microsoft.XMLDOM"),c.async=!1,c.loadXML(a)}catch(e){c=null}return c},a.parseJSON=function(a){if(null==a)return null;try{return JSON.parse(a)}catch(b){throw b}},createjs.DataUtils=a}(),this.createjs=this.createjs||{},function(){"use strict";function a(){this.src=null,this.type=null,this.id=null,this.maintainOrder=!1,this.callback=null,this.data=null,this.method=createjs.LoadItem.GET,this.values=null,this.headers=null,this.withCredentials=!1,this.mimeType=null,this.crossOrigin=null,this.loadTimeout=c.LOAD_TIMEOUT_DEFAULT}var b=a.prototype={},c=a;c.LOAD_TIMEOUT_DEFAULT=8e3,c.create=function(b){if("string"==typeof b){var d=new a;return d.src=b,d}if(b instanceof c)return b;if(b instanceof Object&&b.src)return null==b.loadTimeout&&(b.loadTimeout=c.LOAD_TIMEOUT_DEFAULT),b;throw new Error("Type not recognized.")},b.set=function(a){for(var b in a)this[b]=a[b];return this},createjs.LoadItem=c}(),function(){var a={};a.ABSOLUTE_PATT=/^(?:\w+:)?\/{2}/i,a.RELATIVE_PATT=/^[.\/]*?\//i,a.EXTENSION_PATT=/\/?[^\/]+\.(\w{1,5})$/i,a.parseURI=function(b){var c={absolute:!1,relative:!1};if(null==b)return c;var d=b.indexOf("?");d>-1&&(b=b.substr(0,d));var e;return a.ABSOLUTE_PATT.test(b)?c.absolute=!0:a.RELATIVE_PATT.test(b)&&(c.relative=!0),(e=b.match(a.EXTENSION_PATT))&&(c.extension=e[1].toLowerCase()),c},a.formatQueryString=function(a,b){if(null==a)throw new Error("You must specify data.");var c=[];for(var d in a)c.push(d+"="+escape(a[d]));return b&&(c=c.concat(b)),c.join("&")},a.buildPath=function(a,b){if(null==b)return a;var c=[],d=a.indexOf("?");if(-1!=d){var e=a.slice(d+1);c=c.concat(e.split("&"))}return-1!=d?a.slice(0,d)+"?"+this.formatQueryString(b,c):a+"?"+this.formatQueryString(b,c)},a.isCrossDomain=function(a){var b=document.createElement("a");b.href=a.src;var c=document.createElement("a");c.href=location.href;var d=""!=b.hostname&&(b.port!=c.port||b.protocol!=c.protocol||b.hostname!=c.hostname);return d},a.isLocal=function(a){var b=document.createElement("a");return b.href=a.src,""==b.hostname&&"file:"==b.protocol},a.isBinary=function(a){switch(a){case createjs.AbstractLoader.IMAGE:case createjs.AbstractLoader.BINARY:return!0;default:return!1}},a.isImageTag=function(a){return a instanceof HTMLImageElement},a.isAudioTag=function(a){return window.HTMLAudioElement?a instanceof HTMLAudioElement:!1},a.isVideoTag=function(a){return window.HTMLVideoElement?a instanceof HTMLVideoElement:!1},a.isText=function(a){switch(a){case createjs.AbstractLoader.TEXT:case createjs.AbstractLoader.JSON:case createjs.AbstractLoader.MANIFEST:case createjs.AbstractLoader.XML:case createjs.AbstractLoader.CSS:case createjs.AbstractLoader.SVG:case createjs.AbstractLoader.JAVASCRIPT:case createjs.AbstractLoader.SPRITESHEET:return!0;default:return!1}},a.getTypeByExtension=function(a){if(null==a)return createjs.AbstractLoader.TEXT;switch(a.toLowerCase()){case"jpeg":case"jpg":case"gif":case"png":case"webp":case"bmp":return createjs.AbstractLoader.IMAGE;case"ogg":case"mp3":case"webm":return createjs.AbstractLoader.SOUND;case"mp4":case"webm":case"ts":return createjs.AbstractLoader.VIDEO;case"json":return createjs.AbstractLoader.JSON;case"xml":return createjs.AbstractLoader.XML;case"css":return createjs.AbstractLoader.CSS;case"js":return createjs.AbstractLoader.JAVASCRIPT;case"svg":return createjs.AbstractLoader.SVG;default:return createjs.AbstractLoader.TEXT}},createjs.RequestUtils=a}(),this.createjs=this.createjs||{},function(){"use strict";function a(a,b,c){this.EventDispatcher_constructor(),this.loaded=!1,this.canceled=!1,this.progress=0,this.type=c,this.resultFormatter=null,a?this._item=createjs.LoadItem.create(a):this._item=null,this._preferXHR=b,this._result=null,this._rawResult=null,this._loadedItems=null,this._tagSrcAttribute=null,this._tag=null}var b=createjs.extend(a,createjs.EventDispatcher),c=a;c.POST="POST",c.GET="GET",c.BINARY="binary",c.CSS="css",c.IMAGE="image",c.JAVASCRIPT="javascript",c.JSON="json",c.JSONP="jsonp",c.MANIFEST="manifest",c.SOUND="sound",c.VIDEO="video",c.SPRITESHEET="spritesheet",c.SVG="svg",c.TEXT="text",c.XML="xml",b.getItem=function(){return this._item},b.getResult=function(a){return a?this._rawResult:this._result},b.getTag=function(){return this._tag},b.setTag=function(a){this._tag=a},b.load=function(){this._createRequest(),this._request.on("complete",this,this),this._request.on("progress",this,this),this._request.on("loadStart",this,this),this._request.on("abort",this,this),this._request.on("timeout",this,this),this._request.on("error",this,this);var a=new createjs.Event("initialize");a.loader=this._request,this.dispatchEvent(a),this._request.load()},b.cancel=function(){this.canceled=!0,this.destroy()},b.destroy=function(){this._request&&(this._request.removeAllEventListeners(),this._request.destroy()),this._request=null,this._item=null,this._rawResult=null,this._result=null,this._loadItems=null,this.removeAllEventListeners()},b.getLoadedItems=function(){return this._loadedItems},b._createRequest=function(){this._preferXHR?this._request=new createjs.XHRRequest(this._item):this._request=new createjs.TagRequest(this._item,this._tag||this._createTag(),this._tagSrcAttribute)},b._createTag=function(a){return null},b._sendLoadStart=function(){this._isCanceled()||this.dispatchEvent("loadstart")},b._sendProgress=function(a){if(!this._isCanceled()){var b=null;"number"==typeof a?(this.progress=a,b=new createjs.ProgressEvent(this.progress)):(b=a,this.progress=a.loaded/a.total,b.progress=this.progress,(isNaN(this.progress)||this.progress==1/0)&&(this.progress=0)),this.hasEventListener("progress")&&this.dispatchEvent(b)}},b._sendComplete=function(){if(!this._isCanceled()){this.loaded=!0;var a=new createjs.Event("complete");a.rawResult=this._rawResult,null!=this._result&&(a.result=this._result),this.dispatchEvent(a)}},b._sendError=function(a){!this._isCanceled()&&this.hasEventListener("error")&&(null==a&&(a=new createjs.ErrorEvent("PRELOAD_ERROR_EMPTY")),this.dispatchEvent(a))},b._isCanceled=function(){return null==window.createjs||this.canceled?!0:!1},b.resultFormatter=null,b.handleEvent=function(a){switch(a.type){case"complete":this._rawResult=a.target._response;var b=this.resultFormatter&&this.resultFormatter(this);b instanceof Function?b.call(this,createjs.proxy(this._resultFormatSuccess,this),createjs.proxy(this._resultFormatFailed,this)):(this._result=b||this._rawResult,this._sendComplete());break;case"progress":this._sendProgress(a);break;case"error":this._sendError(a);break;case"loadstart":this._sendLoadStart();break;case"abort":case"timeout":this._isCanceled()||this.dispatchEvent(new createjs.ErrorEvent("PRELOAD_"+a.type.toUpperCase()+"_ERROR"))}},b._resultFormatSuccess=function(a){this._result=a,this._sendComplete()},b._resultFormatFailed=function(a){this._sendError(a)},b.buildPath=function(a,b){return createjs.RequestUtils.buildPath(a,b)},b.toString=function(){return"[PreloadJS AbstractLoader]"},createjs.AbstractLoader=createjs.promote(a,"EventDispatcher")}(),this.createjs=this.createjs||{},function(){"use strict";function a(a,b,c){this.AbstractLoader_constructor(a,b,c),this.resultFormatter=this._formatResult,this._tagSrcAttribute="src",this.on("initialize",this._updateXHR,this)}var b=createjs.extend(a,createjs.AbstractLoader);b.load=function(){this._tag||(this._tag=this._createTag(this._item.src)),this._tag.preload="auto",this._tag.load(),this.AbstractLoader_load()},b._createTag=function(){},b._createRequest=function(){this._preferXHR?this._request=new createjs.XHRRequest(this._item):this._request=new createjs.MediaTagRequest(this._item,this._tag||this._createTag(),this._tagSrcAttribute)},b._updateXHR=function(a){a.loader.setResponseType&&a.loader.setResponseType("blob")},b._formatResult=function(a){if(this._tag.removeEventListener&&this._tag.removeEventListener("canplaythrough",this._loadedHandler),this._tag.onstalled=null,this._preferXHR){var b=window.URL||window.webkitURL,c=a.getResult(!0);a.getTag().src=b.createObjectURL(c)}return a.getTag()},createjs.AbstractMediaLoader=createjs.promote(a,"AbstractLoader")}(),this.createjs=this.createjs||{},function(){"use strict";var a=function(a){this._item=a},b=createjs.extend(a,createjs.EventDispatcher);b.load=function(){},b.destroy=function(){},b.cancel=function(){},createjs.AbstractRequest=createjs.promote(a,"EventDispatcher")}(),this.createjs=this.createjs||{},function(){"use strict";function a(a,b,c){this.AbstractRequest_constructor(a),this._tag=b,this._tagSrcAttribute=c,this._loadedHandler=createjs.proxy(this._handleTagComplete,this),this._addedToDOM=!1,this._startTagVisibility=null}var b=createjs.extend(a,createjs.AbstractRequest);b.load=function(){this._tag.onload=createjs.proxy(this._handleTagComplete,this),this._tag.onreadystatechange=createjs.proxy(this._handleReadyStateChange,this),this._tag.onerror=createjs.proxy(this._handleError,this);var a=new createjs.Event("initialize");a.loader=this._tag,this.dispatchEvent(a),this._hideTag(),this._loadTimeout=setTimeout(createjs.proxy(this._handleTimeout,this),this._item.loadTimeout),this._tag[this._tagSrcAttribute]=this._item.src,null==this._tag.parentNode&&(window.document.body.appendChild(this._tag),this._addedToDOM=!0)},b.destroy=function(){this._clean(),this._tag=null,this.AbstractRequest_destroy()},b._handleReadyStateChange=function(){clearTimeout(this._loadTimeout);var a=this._tag;("loaded"==a.readyState||"complete"==a.readyState)&&this._handleTagComplete()},b._handleError=function(){this._clean(),this.dispatchEvent("error")},b._handleTagComplete=function(){this._rawResult=this._tag,this._result=this.resultFormatter&&this.resultFormatter(this)||this._rawResult,this._clean(),this._showTag(),this.dispatchEvent("complete")},b._handleTimeout=function(){this._clean(),this.dispatchEvent(new createjs.Event("timeout"))},b._clean=function(){this._tag.onload=null,this._tag.onreadystatechange=null,this._tag.onerror=null,this._addedToDOM&&null!=this._tag.parentNode&&this._tag.parentNode.removeChild(this._tag),clearTimeout(this._loadTimeout)},b._hideTag=function(){this._startTagVisibility=this._tag.style.visibility,this._tag.style.visibility="hidden"},b._showTag=function(){this._tag.style.visibility=this._startTagVisibility},b._handleStalled=function(){},createjs.TagRequest=createjs.promote(a,"AbstractRequest")}(),this.createjs=this.createjs||{},function(){"use strict";function a(a,b,c){this.AbstractRequest_constructor(a),this._tag=b,this._tagSrcAttribute=c,this._loadedHandler=createjs.proxy(this._handleTagComplete,this)}var b=createjs.extend(a,createjs.TagRequest);b.load=function(){var a=createjs.proxy(this._handleStalled,this);this._stalledCallback=a;var b=createjs.proxy(this._handleProgress,this);this._handleProgress=b,this._tag.addEventListener("stalled",a),this._tag.addEventListener("progress",b),this._tag.addEventListener&&this._tag.addEventListener("canplaythrough",this._loadedHandler,!1),this.TagRequest_load()},b._handleReadyStateChange=function(){clearTimeout(this._loadTimeout);var a=this._tag;("loaded"==a.readyState||"complete"==a.readyState)&&this._handleTagComplete()},b._handleStalled=function(){},b._handleProgress=function(a){if(a&&!(a.loaded>0&&0==a.total)){var b=new createjs.ProgressEvent(a.loaded,a.total);this.dispatchEvent(b)}},b._clean=function(){this._tag.removeEventListener&&this._tag.removeEventListener("canplaythrough",this._loadedHandler),this._tag.removeEventListener("stalled",this._stalledCallback),this._tag.removeEventListener("progress",this._progressCallback),this.TagRequest__clean()},createjs.MediaTagRequest=createjs.promote(a,"TagRequest")}(),this.createjs=this.createjs||{},function(){"use strict";function a(a){this.AbstractRequest_constructor(a),this._request=null,this._loadTimeout=null,this._xhrLevel=1,this._response=null,this._rawResponse=null,this._canceled=!1,this._handleLoadStartProxy=createjs.proxy(this._handleLoadStart,this),this._handleProgressProxy=createjs.proxy(this._handleProgress,this),this._handleAbortProxy=createjs.proxy(this._handleAbort,this),this._handleErrorProxy=createjs.proxy(this._handleError,this),this._handleTimeoutProxy=createjs.proxy(this._handleTimeout,this),this._handleLoadProxy=createjs.proxy(this._handleLoad,this),this._handleReadyStateChangeProxy=createjs.proxy(this._handleReadyStateChange,this),!this._createXHR(a)}var b=createjs.extend(a,createjs.AbstractRequest);a.ACTIVEX_VERSIONS=["Msxml2.XMLHTTP.6.0","Msxml2.XMLHTTP.5.0","Msxml2.XMLHTTP.4.0","MSXML2.XMLHTTP.3.0","MSXML2.XMLHTTP","Microsoft.XMLHTTP"],b.getResult=function(a){return a&&this._rawResponse?this._rawResponse:this._response},b.cancel=function(){this.canceled=!0,this._clean(),this._request.abort()},b.load=function(){if(null==this._request)return void this._handleError();null!=this._request.addEventListener?(this._request.addEventListener("loadstart",this._handleLoadStartProxy,!1),this._request.addEventListener("progress",this._handleProgressProxy,!1),this._request.addEventListener("abort",this._handleAbortProxy,!1),this._request.addEventListener("error",this._handleErrorProxy,!1),this._request.addEventListener("timeout",this._handleTimeoutProxy,!1),this._request.addEventListener("load",this._handleLoadProxy,!1),this._request.addEventListener("readystatechange",this._handleReadyStateChangeProxy,!1)):(this._request.onloadstart=this._handleLoadStartProxy,this._request.onprogress=this._handleProgressProxy,this._request.onabort=this._handleAbortProxy,this._request.onerror=this._handleErrorProxy,this._request.ontimeout=this._handleTimeoutProxy,this._request.onload=this._handleLoadProxy,this._request.onreadystatechange=this._handleReadyStateChangeProxy),1==this._xhrLevel&&(this._loadTimeout=setTimeout(createjs.proxy(this._handleTimeout,this),this._item.loadTimeout));try{this._item.values&&this._item.method!=createjs.AbstractLoader.GET?this._item.method==createjs.AbstractLoader.POST&&this._request.send(createjs.RequestUtils.formatQueryString(this._item.values)):this._request.send()}catch(a){this.dispatchEvent(new createjs.ErrorEvent("XHR_SEND",null,a))}},b.setResponseType=function(a){"blob"===a&&(a=window.URL?"blob":"arraybuffer",this._responseType=a),this._request.responseType=a},b.getAllResponseHeaders=function(){return this._request.getAllResponseHeaders instanceof Function?this._request.getAllResponseHeaders():null},b.getResponseHeader=function(a){return this._request.getResponseHeader instanceof Function?this._request.getResponseHeader(a):null},b._handleProgress=function(a){if(a&&!(a.loaded>0&&0==a.total)){var b=new createjs.ProgressEvent(a.loaded,a.total);this.dispatchEvent(b)}},b._handleLoadStart=function(a){clearTimeout(this._loadTimeout),this.dispatchEvent("loadstart")},b._handleAbort=function(a){this._clean(),this.dispatchEvent(new createjs.ErrorEvent("XHR_ABORTED",null,a))},b._handleError=function(a){this._clean(),this.dispatchEvent(new createjs.ErrorEvent(a.message))},b._handleReadyStateChange=function(a){4==this._request.readyState&&this._handleLoad()},b._handleLoad=function(a){if(!this.loaded){this.loaded=!0;var b=this._checkError();if(b)return void this._handleError(b);if(this._response=this._getResponse(),"arraybuffer"===this._responseType)try{this._response=new Blob([this._response])}catch(c){if(window.BlobBuilder=window.BlobBuilder||window.WebKitBlobBuilder||window.MozBlobBuilder||window.MSBlobBuilder,"TypeError"===c.name&&window.BlobBuilder){var d=new BlobBuilder;d.append(this._response),this._response=d.getBlob()}}this._clean(),this.dispatchEvent(new createjs.Event("complete"))}},b._handleTimeout=function(a){this._clean(),this.dispatchEvent(new createjs.ErrorEvent("PRELOAD_TIMEOUT",null,a))},b._checkError=function(){var a=parseInt(this._request.status);switch(a){case 404:case 0:return new Error(a)}return null},b._getResponse=function(){if(null!=this._response)return this._response;if(null!=this._request.response)return this._request.response;try{if(null!=this._request.responseText)return this._request.responseText}catch(a){}try{if(null!=this._request.responseXML)return this._request.responseXML}catch(a){}return null},b._createXHR=function(a){var b=createjs.RequestUtils.isCrossDomain(a),c={},d=null;if(window.XMLHttpRequest)d=new XMLHttpRequest,b&&void 0===d.withCredentials&&window.XDomainRequest&&(d=new XDomainRequest);else{for(var e=0,f=s.ACTIVEX_VERSIONS.length;f>e;e++){var g=s.ACTIVEX_VERSIONS[e];try{d=new ActiveXObject(g);break}catch(h){}}if(null==d)return!1}null==a.mimeType&&createjs.RequestUtils.isText(a.type)&&(a.mimeType="text/plain; charset=utf-8"),a.mimeType&&d.overrideMimeType&&d.overrideMimeType(a.mimeType),this._xhrLevel="string"==typeof d.responseType?2:1;var i=null;if(i=a.method==createjs.AbstractLoader.GET?createjs.RequestUtils.buildPath(a.src,a.values):a.src,d.open(a.method||createjs.AbstractLoader.GET,i,!0),b&&d instanceof XMLHttpRequest&&1==this._xhrLevel&&(c.Origin=location.origin),a.values&&a.method==createjs.AbstractLoader.POST&&(c["Content-Type"]="application/x-www-form-urlencoded"),b||c["X-Requested-With"]||(c["X-Requested-With"]="XMLHttpRequest"),a.headers)for(var j in a.headers)c[j]=a.headers[j];for(j in c)d.setRequestHeader(j,c[j]);return d instanceof XMLHttpRequest&&void 0!==a.withCredentials&&(d.withCredentials=a.withCredentials),this._request=d,!0},b._clean=function(){clearTimeout(this._loadTimeout),null!=this._request.removeEventListener?(this._request.removeEventListener("loadstart",this._handleLoadStartProxy),this._request.removeEventListener("progress",this._handleProgressProxy),this._request.removeEventListener("abort",this._handleAbortProxy),this._request.removeEventListener("error",this._handleErrorProxy),this._request.removeEventListener("timeout",this._handleTimeoutProxy),this._request.removeEventListener("load",this._handleLoadProxy),this._request.removeEventListener("readystatechange",this._handleReadyStateChangeProxy)):(this._request.onloadstart=null,this._request.onprogress=null,this._request.onabort=null,this._request.onerror=null,this._request.ontimeout=null,this._request.onload=null,this._request.onreadystatechange=null)},b.toString=function(){return"[PreloadJS XHRRequest]"},createjs.XHRRequest=createjs.promote(a,"AbstractRequest")}(),this.createjs=this.createjs||{},function(){"use strict";function a(a,b,c){this.AbstractLoader_constructor(),this._plugins=[],this._typeCallbacks={},this._extensionCallbacks={},this.next=null,this.maintainScriptOrder=!0,this.stopOnError=!1,this._maxConnections=1,this._availableLoaders=[createjs.ImageLoader,createjs.JavaScriptLoader,createjs.CSSLoader,createjs.JSONLoader,createjs.JSONPLoader,createjs.SoundLoader,createjs.ManifestLoader,createjs.SpriteSheetLoader,createjs.XMLLoader,createjs.SVGLoader,createjs.BinaryLoader,createjs.VideoLoader,createjs.TextLoader],this._defaultLoaderLength=this._availableLoaders.length,this.init(a,b,c)}var b=createjs.extend(a,createjs.AbstractLoader),c=a;b.init=function(a,b,c){this.useXHR=!0,this.preferXHR=!0,this._preferXHR=!0,this.setPreferXHR(a),this._paused=!1,this._basePath=b,this._crossOrigin=c,this._loadStartWasDispatched=!1,this._currentlyLoadingScript=null,this._currentLoads=[],this._loadQueue=[],this._loadQueueBackup=[],this._loadItemsById={},this._loadItemsBySrc={},this._loadedResults={},this._loadedRawResults={},this._numItems=0,this._numItemsLoaded=0,this._scriptOrder=[],this._loadedScripts=[],this._lastProgress=NaN},c.loadTimeout=8e3,c.LOAD_TIMEOUT=0,c.BINARY=createjs.AbstractLoader.BINARY,c.CSS=createjs.AbstractLoader.CSS,c.IMAGE=createjs.AbstractLoader.IMAGE,c.JAVASCRIPT=createjs.AbstractLoader.JAVASCRIPT,c.JSON=createjs.AbstractLoader.JSON,c.JSONP=createjs.AbstractLoader.JSONP,c.MANIFEST=createjs.AbstractLoader.MANIFEST,c.SOUND=createjs.AbstractLoader.SOUND,c.VIDEO=createjs.AbstractLoader.VIDEO,c.SVG=createjs.AbstractLoader.SVG,c.TEXT=createjs.AbstractLoader.TEXT,c.XML=createjs.AbstractLoader.XML,c.POST=createjs.AbstractLoader.POST,c.GET=createjs.AbstractLoader.GET,b.registerLoader=function(a){if(!a||!a.canLoadItem)throw new Error("loader is of an incorrect type.");if(-1!=this._availableLoaders.indexOf(a))throw new Error("loader already exists.");this._availableLoaders.unshift(a)},b.unregisterLoader=function(a){var b=this._availableLoaders.indexOf(a);-1!=b&&b<this._defaultLoaderLength-1&&this._availableLoaders.splice(b,1)},b.setUseXHR=function(a){return this.setPreferXHR(a)},b.setPreferXHR=function(a){return this.preferXHR=0!=a&&null!=window.XMLHttpRequest,this.preferXHR},b.removeAll=function(){this.remove()},b.remove=function(a){var b=null;if(a&&!Array.isArray(a))b=[a];else if(a)b=a;else if(arguments.length>0)return;var c=!1;if(b){for(;b.length;){var d=b.pop(),e=this.getResult(d);for(f=this._loadQueue.length-1;f>=0;f--)if(g=this._loadQueue[f].getItem(),g.id==d||g.src==d){this._loadQueue.splice(f,1)[0].cancel();break}for(f=this._loadQueueBackup.length-1;f>=0;f--)if(g=this._loadQueueBackup[f].getItem(),g.id==d||g.src==d){this._loadQueueBackup.splice(f,1)[0].cancel();break}if(e)this._disposeItem(this.getItem(d));else for(var f=this._currentLoads.length-1;f>=0;f--){var g=this._currentLoads[f].getItem();if(g.id==d||g.src==d){this._currentLoads.splice(f,1)[0].cancel(),c=!0;break}}}c&&this._loadNext()}else{this.close();for(var h in this._loadItemsById)this._disposeItem(this._loadItemsById[h]);this.init(this.preferXHR,this._basePath)}},b.reset=function(){this.close();for(var a in this._loadItemsById)this._disposeItem(this._loadItemsById[a]);for(var b=[],c=0,d=this._loadQueueBackup.length;d>c;c++)b.push(this._loadQueueBackup[c].getItem());this.loadManifest(b,!1)},b.installPlugin=function(a){if(null!=a&&null!=a.getPreloadHandlers){this._plugins.push(a);var b=a.getPreloadHandlers();if(b.scope=a,null!=b.types)for(var c=0,d=b.types.length;d>c;c++)this._typeCallbacks[b.types[c]]=b;if(null!=b.extensions)for(c=0,d=b.extensions.length;d>c;c++)this._extensionCallbacks[b.extensions[c]]=b}},b.setMaxConnections=function(a){this._maxConnections=a,!this._paused&&this._loadQueue.length>0&&this._loadNext()},b.loadFile=function(a,b,c){if(null==a){var d=new createjs.ErrorEvent("PRELOAD_NO_FILE");return void this._sendError(d)}this._addItem(a,null,c),b!==!1?this.setPaused(!1):this.setPaused(!0)},b.loadManifest=function(a,b,d){var e=null,f=null;if(Array.isArray(a)){if(0==a.length){var g=new createjs.ErrorEvent("PRELOAD_MANIFEST_EMPTY");return void this._sendError(g)}e=a}else if("string"==typeof a)e=[{src:a,type:c.MANIFEST}];else{if("object"!=typeof a){var g=new createjs.ErrorEvent("PRELOAD_MANIFEST_NULL");return void this._sendError(g)}if(void 0!==a.src){if(null==a.type)a.type=c.MANIFEST;else if(a.type!=c.MANIFEST){var g=new createjs.ErrorEvent("PRELOAD_MANIFEST_TYPE");this._sendError(g)}e=[a]}else void 0!==a.manifest&&(e=a.manifest,f=a.path)}for(var h=0,i=e.length;i>h;h++)this._addItem(e[h],f,d);b!==!1?this.setPaused(!1):this.setPaused(!0)},b.load=function(){this.setPaused(!1)},b.getItem=function(a){return this._loadItemsById[a]||this._loadItemsBySrc[a]},b.getResult=function(a,b){var c=this._loadItemsById[a]||this._loadItemsBySrc[a];if(null==c)return null;var d=c.id;return b&&this._loadedRawResults[d]?this._loadedRawResults[d]:this._loadedResults[d]},b.getItems=function(a){var b=[];for(var c in this._loadItemsById){var d=this._loadItemsById[c],e=this.getResult(c);(a!==!0||null!=e)&&b.push({item:d,result:e,rawResult:this.getResult(c,!0)})}return b},b.setPaused=function(a){this._paused=a,this._paused||this._loadNext()},b.close=function(){for(;this._currentLoads.length;)this._currentLoads.pop().cancel();this._scriptOrder.length=0,this._loadedScripts.length=0,this.loadStartWasDispatched=!1,this._itemCount=0,this._lastProgress=NaN},b._addItem=function(a,b,c){var d=this._createLoadItem(a,b,c);if(null!=d){var e=this._createLoader(d);null!=e&&("plugins"in e&&(e.plugins=this._plugins),d._loader=e,this._loadQueue.push(e),this._loadQueueBackup.push(e),this._numItems++,this._updateProgress(),(this.maintainScriptOrder&&d.type==createjs.LoadQueue.JAVASCRIPT||d.maintainOrder===!0)&&(this._scriptOrder.push(d),this._loadedScripts.push(null)))}},b._createLoadItem=function(a,b,c){var d=createjs.LoadItem.create(a);if(null==d)return null;var e="",f=c||this._basePath;if(d.src instanceof Object){if(!d.type)return null;if(b){e=b;var g=createjs.RequestUtils.parseURI(b);null==f||g.absolute||g.relative||(e=f+e)}else null!=f&&(e=f)}else{var h=createjs.RequestUtils.parseURI(d.src);h.extension&&(d.ext=h.extension),null==d.type&&(d.type=createjs.RequestUtils.getTypeByExtension(d.ext));var i=d.src;if(!h.absolute&&!h.relative)if(b){e=b;var g=createjs.RequestUtils.parseURI(b);i=b+i,null==f||g.absolute||g.relative||(e=f+e)}else null!=f&&(e=f);d.src=e+d.src}d.path=e,(void 0===d.id||null===d.id||""===d.id)&&(d.id=i);var j=this._typeCallbacks[d.type]||this._extensionCallbacks[d.ext];if(j){var k=j.callback.call(j.scope,d,this);if(k===!1)return null;k===!0||null!=k&&(d._loader=k),h=createjs.RequestUtils.parseURI(d.src),null!=h.extension&&(d.ext=h.extension)}return this._loadItemsById[d.id]=d,this._loadItemsBySrc[d.src]=d,null==d.crossOrigin&&(d.crossOrigin=this._crossOrigin),d},b._createLoader=function(a){if(null!=a._loader)return a._loader;for(var b=this.preferXHR,c=0;c<this._availableLoaders.length;c++){var d=this._availableLoaders[c];if(d&&d.canLoadItem(a))return new d(a,b)}return null},b._loadNext=function(){if(!this._paused){this._loadStartWasDispatched||(this._sendLoadStart(),this._loadStartWasDispatched=!0),this._numItems==this._numItemsLoaded?(this.loaded=!0,this._sendComplete(),this.next&&this.next.load&&this.next.load()):this.loaded=!1;for(var a=0;a<this._loadQueue.length&&!(this._currentLoads.length>=this._maxConnections);a++){var b=this._loadQueue[a];this._canStartLoad(b)&&(this._loadQueue.splice(a,1),a--,this._loadItem(b))}}},b._loadItem=function(a){a.on("fileload",this._handleFileLoad,this),a.on("progress",this._handleProgress,this),a.on("complete",this._handleFileComplete,this),a.on("error",this._handleError,this),a.on("fileerror",this._handleFileError,this),this._currentLoads.push(a),this._sendFileStart(a.getItem()),a.load()},b._handleFileLoad=function(a){a.target=null,this.dispatchEvent(a)},b._handleFileError=function(a){var b=new createjs.ErrorEvent("FILE_LOAD_ERROR",null,a.item);this._sendError(b)},b._handleError=function(a){var b=a.target;this._numItemsLoaded++,this._finishOrderedItem(b,!0),this._updateProgress();var c=new createjs.ErrorEvent("FILE_LOAD_ERROR",null,b.getItem());this._sendError(c),this.stopOnError?this.setPaused(!0):(this._removeLoadItem(b),this._cleanLoadItem(b),this._loadNext())},b._handleFileComplete=function(a){var b=a.target,c=b.getItem(),d=b.getResult();this._loadedResults[c.id]=d;var e=b.getResult(!0);null!=e&&e!==d&&(this._loadedRawResults[c.id]=e),this._saveLoadedItems(b),this._removeLoadItem(b),this._finishOrderedItem(b)||this._processFinishedLoad(c,b),this._cleanLoadItem(b)},b._saveLoadedItems=function(a){var b=a.getLoadedItems();if(null!==b)for(var c=0;c<b.length;c++){var d=b[c].item;this._loadItemsBySrc[d.src]=d,this._loadItemsById[d.id]=d,this._loadedResults[d.id]=b[c].result,this._loadedRawResults[d.id]=b[c].rawResult}},b._finishOrderedItem=function(a,b){var c=a.getItem();if(this.maintainScriptOrder&&c.type==createjs.LoadQueue.JAVASCRIPT||c.maintainOrder){a instanceof createjs.JavaScriptLoader&&(this._currentlyLoadingScript=!1);var d=createjs.indexOf(this._scriptOrder,c);return-1==d?!1:(this._loadedScripts[d]=b===!0?!0:c,this._checkScriptLoadOrder(),!0)}return!1},b._checkScriptLoadOrder=function(){for(var a=this._loadedScripts.length,b=0;a>b;b++){var c=this._loadedScripts[b];if(null===c)break;if(c!==!0){var d=this._loadedResults[c.id];c.type==createjs.LoadQueue.JAVASCRIPT&&createjs.DomUtils.appendToHead(d);var e=c._loader;this._processFinishedLoad(c,e),this._loadedScripts[b]=!0}}},b._processFinishedLoad=function(a,b){if(this._numItemsLoaded++,!this.maintainScriptOrder&&a.type==createjs.LoadQueue.JAVASCRIPT){var c=b.getTag();createjs.DomUtils.appendToHead(c)}this._updateProgress(),this._sendFileComplete(a,b),this._loadNext()},b._canStartLoad=function(a){if(!this.maintainScriptOrder||a.preferXHR)return!0;var b=a.getItem();if(b.type!=createjs.LoadQueue.JAVASCRIPT)return!0;if(this._currentlyLoadingScript)return!1;for(var c=this._scriptOrder.indexOf(b),d=0;c>d;){var e=this._loadedScripts[d];if(null==e)return!1;d++}return this._currentlyLoadingScript=!0,!0},b._removeLoadItem=function(a){for(var b=this._currentLoads.length,c=0;b>c;c++)if(this._currentLoads[c]==a){this._currentLoads.splice(c,1);break}},b._cleanLoadItem=function(a){var b=a.getItem();b&&delete b._loader},b._handleProgress=function(a){var b=a.target;this._sendFileProgress(b.getItem(),b.progress),this._updateProgress()},b._updateProgress=function(){var a=this._numItemsLoaded/this._numItems,b=this._numItems-this._numItemsLoaded;if(b>0){for(var c=0,d=0,e=this._currentLoads.length;e>d;d++)c+=this._currentLoads[d].progress;a+=c/b*(b/this._numItems)}this._lastProgress!=a&&(this._sendProgress(a),this._lastProgress=a)},b._disposeItem=function(a){delete this._loadedResults[a.id],delete this._loadedRawResults[a.id],delete this._loadItemsById[a.id],delete this._loadItemsBySrc[a.src]},b._sendFileProgress=function(a,b){if(!this._isCanceled()&&!this._paused&&this.hasEventListener("fileprogress")){var c=new createjs.Event("fileprogress");c.progress=b,c.loaded=b,c.total=1,c.item=a,this.dispatchEvent(c)}},b._sendFileComplete=function(a,b){
if(!this._isCanceled()&&!this._paused){var c=new createjs.Event("fileload");c.loader=b,c.item=a,c.result=this._loadedResults[a.id],c.rawResult=this._loadedRawResults[a.id],a.completeHandler&&a.completeHandler(c),this.hasEventListener("fileload")&&this.dispatchEvent(c)}},b._sendFileStart=function(a){var b=new createjs.Event("filestart");b.item=a,this.hasEventListener("filestart")&&this.dispatchEvent(b)},b.toString=function(){return"[PreloadJS LoadQueue]"},createjs.LoadQueue=createjs.promote(a,"AbstractLoader")}(),this.createjs=this.createjs||{},function(){"use strict";function a(a){this.AbstractLoader_constructor(a,!0,createjs.AbstractLoader.TEXT)}var b=(createjs.extend(a,createjs.AbstractLoader),a);b.canLoadItem=function(a){return a.type==createjs.AbstractLoader.TEXT},createjs.TextLoader=createjs.promote(a,"AbstractLoader")}(),this.createjs=this.createjs||{},function(){"use strict";function a(a){this.AbstractLoader_constructor(a,!0,createjs.AbstractLoader.BINARY),this.on("initialize",this._updateXHR,this)}var b=createjs.extend(a,createjs.AbstractLoader),c=a;c.canLoadItem=function(a){return a.type==createjs.AbstractLoader.BINARY},b._updateXHR=function(a){a.loader.setResponseType("arraybuffer")},createjs.BinaryLoader=createjs.promote(a,"AbstractLoader")}(),this.createjs=this.createjs||{},function(){"use strict";function a(a,b){this.AbstractLoader_constructor(a,b,createjs.AbstractLoader.CSS),this.resultFormatter=this._formatResult,this._tagSrcAttribute="href",b?this._tag=document.createElement("style"):this._tag=document.createElement("link"),this._tag.rel="stylesheet",this._tag.type="text/css"}var b=createjs.extend(a,createjs.AbstractLoader),c=a;c.canLoadItem=function(a){return a.type==createjs.AbstractLoader.CSS},b._formatResult=function(a){if(this._preferXHR){var b=a.getTag();if(b.styleSheet)b.styleSheet.cssText=a.getResult(!0);else{var c=document.createTextNode(a.getResult(!0));b.appendChild(c)}}else b=this._tag;return createjs.DomUtils.appendToHead(b),b},createjs.CSSLoader=createjs.promote(a,"AbstractLoader")}(),this.createjs=this.createjs||{},function(){"use strict";function a(a,b){this.AbstractLoader_constructor(a,b,createjs.AbstractLoader.IMAGE),this.resultFormatter=this._formatResult,this._tagSrcAttribute="src",createjs.RequestUtils.isImageTag(a)?this._tag=a:createjs.RequestUtils.isImageTag(a.src)?this._tag=a.src:createjs.RequestUtils.isImageTag(a.tag)&&(this._tag=a.tag),null!=this._tag?this._preferXHR=!1:this._tag=document.createElement("img"),this.on("initialize",this._updateXHR,this)}var b=createjs.extend(a,createjs.AbstractLoader),c=a;c.canLoadItem=function(a){return a.type==createjs.AbstractLoader.IMAGE},b.load=function(){if(""!=this._tag.src&&this._tag.complete)return void this._sendComplete();var a=this._item.crossOrigin;1==a&&(a="Anonymous"),null==a||createjs.RequestUtils.isLocal(this._item.src)||(this._tag.crossOrigin=a),this.AbstractLoader_load()},b._updateXHR=function(a){a.loader.mimeType="text/plain; charset=x-user-defined-binary",a.loader.setResponseType&&a.loader.setResponseType("blob")},b._formatResult=function(a){return this._formatImage},b._formatImage=function(a,b){var c=this._tag,d=window.URL||window.webkitURL;if(this._preferXHR)if(d){var e=d.createObjectURL(this.getResult(!0));c.src=e,c.addEventListener("load",this._cleanUpURL,!1),c.addEventListener("error",this._cleanUpURL,!1)}else c.src=this._item.src;else;c.complete?a(c):(c.onload=createjs.proxy(function(){a(this._tag)},this),c.onerror=createjs.proxy(function(){b(_this._tag)},this))},b._cleanUpURL=function(a){var b=window.URL||window.webkitURL;b.revokeObjectURL(a.target.src)},createjs.ImageLoader=createjs.promote(a,"AbstractLoader")}(),this.createjs=this.createjs||{},function(){"use strict";function a(a,b){this.AbstractLoader_constructor(a,b,createjs.AbstractLoader.JAVASCRIPT),this.resultFormatter=this._formatResult,this._tagSrcAttribute="src",this.setTag(document.createElement("script"))}var b=createjs.extend(a,createjs.AbstractLoader),c=a;c.canLoadItem=function(a){return a.type==createjs.AbstractLoader.JAVASCRIPT},b._formatResult=function(a){var b=a.getTag();return this._preferXHR&&(b.text=a.getResult(!0)),b},createjs.JavaScriptLoader=createjs.promote(a,"AbstractLoader")}(),this.createjs=this.createjs||{},function(){"use strict";function a(a){this.AbstractLoader_constructor(a,!0,createjs.AbstractLoader.JSON),this.resultFormatter=this._formatResult}var b=createjs.extend(a,createjs.AbstractLoader),c=a;c.canLoadItem=function(a){return a.type==createjs.AbstractLoader.JSON},b._formatResult=function(a){var b=null;try{b=createjs.DataUtils.parseJSON(a.getResult(!0))}catch(c){var d=new createjs.ErrorEvent("JSON_FORMAT",null,c);return this._sendError(d),c}return b},createjs.JSONLoader=createjs.promote(a,"AbstractLoader")}(),this.createjs=this.createjs||{},function(){"use strict";function a(a){this.AbstractLoader_constructor(a,!1,createjs.AbstractLoader.JSONP),this.setTag(document.createElement("script")),this.getTag().type="text/javascript"}var b=createjs.extend(a,createjs.AbstractLoader),c=a;c.canLoadItem=function(a){return a.type==createjs.AbstractLoader.JSONP},b.cancel=function(){this.AbstractLoader_cancel(),this._dispose()},b.load=function(){if(null==this._item.callback)throw new Error("callback is required for loading JSONP requests.");if(null!=window[this._item.callback])throw new Error("JSONP callback '"+this._item.callback+"' already exists on window. You need to specify a different callback or re-name the current one.");window[this._item.callback]=createjs.proxy(this._handleLoad,this),window.document.body.appendChild(this._tag),this._loadTimeout=setTimeout(createjs.proxy(this._handleTimeout,this),this._item.loadTimeout),this._tag.src=this._item.src},b._handleLoad=function(a){this._result=this._rawResult=a,this._sendComplete(),this._dispose()},b._handleTimeout=function(){this._dispose(),this.dispatchEvent(new createjs.ErrorEvent("timeout"))},b._dispose=function(){window.document.body.removeChild(this._tag),delete window[this._item.callback],clearTimeout(this._loadTimeout)},createjs.JSONPLoader=createjs.promote(a,"AbstractLoader")}(),this.createjs=this.createjs||{},function(){"use strict";function a(a){this.AbstractLoader_constructor(a,null,createjs.AbstractLoader.MANIFEST),this.plugins=null,this._manifestQueue=null}var b=createjs.extend(a,createjs.AbstractLoader),c=a;c.MANIFEST_PROGRESS=.25,c.canLoadItem=function(a){return a.type==createjs.AbstractLoader.MANIFEST},b.load=function(){this.AbstractLoader_load()},b._createRequest=function(){var a=this._item.callback;null!=a?this._request=new createjs.JSONPLoader(this._item):this._request=new createjs.JSONLoader(this._item)},b.handleEvent=function(a){switch(a.type){case"complete":return this._rawResult=a.target.getResult(!0),this._result=a.target.getResult(),this._sendProgress(c.MANIFEST_PROGRESS),void this._loadManifest(this._result);case"progress":return a.loaded*=c.MANIFEST_PROGRESS,this.progress=a.loaded/a.total,(isNaN(this.progress)||this.progress==1/0)&&(this.progress=0),void this._sendProgress(a)}this.AbstractLoader_handleEvent(a)},b.destroy=function(){this.AbstractLoader_destroy(),this._manifestQueue.close()},b._loadManifest=function(a){if(a&&a.manifest){var b=this._manifestQueue=new createjs.LoadQueue;b.on("fileload",this._handleManifestFileLoad,this),b.on("progress",this._handleManifestProgress,this),b.on("complete",this._handleManifestComplete,this,!0),b.on("error",this._handleManifestError,this,!0);for(var c=0,d=this.plugins.length;d>c;c++)b.installPlugin(this.plugins[c]);b.loadManifest(a)}else this._sendComplete()},b._handleManifestFileLoad=function(a){a.target=null,this.dispatchEvent(a)},b._handleManifestComplete=function(a){this._loadedItems=this._manifestQueue.getItems(!0),this._sendComplete()},b._handleManifestProgress=function(a){this.progress=a.progress*(1-c.MANIFEST_PROGRESS)+c.MANIFEST_PROGRESS,this._sendProgress(this.progress)},b._handleManifestError=function(a){var b=new createjs.Event("fileerror");b.item=a.data,this.dispatchEvent(b)},createjs.ManifestLoader=createjs.promote(a,"AbstractLoader")}(),this.createjs=this.createjs||{},function(){"use strict";function a(a,b){this.AbstractMediaLoader_constructor(a,b,createjs.AbstractLoader.SOUND),createjs.RequestUtils.isAudioTag(a)?this._tag=a:createjs.RequestUtils.isAudioTag(a.src)?this._tag=a:createjs.RequestUtils.isAudioTag(a.tag)&&(this._tag=createjs.RequestUtils.isAudioTag(a)?a:a.src),null!=this._tag&&(this._preferXHR=!1)}var b=createjs.extend(a,createjs.AbstractMediaLoader),c=a;c.canLoadItem=function(a){return a.type==createjs.AbstractLoader.SOUND},b._createTag=function(a){var b=document.createElement("audio");return b.autoplay=!1,b.preload="none",b.src=a,b},createjs.SoundLoader=createjs.promote(a,"AbstractMediaLoader")}(),this.createjs=this.createjs||{},function(){"use strict";function a(a,b){this.AbstractMediaLoader_constructor(a,b,createjs.AbstractLoader.VIDEO),createjs.RequestUtils.isVideoTag(a)||createjs.RequestUtils.isVideoTag(a.src)?(this.setTag(createjs.RequestUtils.isVideoTag(a)?a:a.src),this._preferXHR=!1):this.setTag(this._createTag())}var b=createjs.extend(a,createjs.AbstractMediaLoader),c=a;b._createTag=function(){return document.createElement("video")},c.canLoadItem=function(a){return a.type==createjs.AbstractLoader.VIDEO},createjs.VideoLoader=createjs.promote(a,"AbstractMediaLoader")}(),this.createjs=this.createjs||{},function(){"use strict";function a(a,b){this.AbstractLoader_constructor(a,b,createjs.AbstractLoader.SPRITESHEET),this._manifestQueue=null}var b=createjs.extend(a,createjs.AbstractLoader),c=a;c.SPRITESHEET_PROGRESS=.25,c.canLoadItem=function(a){return a.type==createjs.AbstractLoader.SPRITESHEET},b.destroy=function(){this.AbstractLoader_destroy,this._manifestQueue.close()},b._createRequest=function(){var a=this._item.callback;null!=a?this._request=new createjs.JSONPLoader(this._item):this._request=new createjs.JSONLoader(this._item)},b.handleEvent=function(a){switch(a.type){case"complete":return this._rawResult=a.target.getResult(!0),this._result=a.target.getResult(),this._sendProgress(c.SPRITESHEET_PROGRESS),void this._loadManifest(this._result);case"progress":return a.loaded*=c.SPRITESHEET_PROGRESS,this.progress=a.loaded/a.total,(isNaN(this.progress)||this.progress==1/0)&&(this.progress=0),void this._sendProgress(a)}this.AbstractLoader_handleEvent(a)},b._loadManifest=function(a){if(a&&a.images){var b=this._manifestQueue=new createjs.LoadQueue(this._preferXHR,this._item.path,this._item.crossOrigin);b.on("complete",this._handleManifestComplete,this,!0),b.on("fileload",this._handleManifestFileLoad,this),b.on("progress",this._handleManifestProgress,this),b.on("error",this._handleManifestError,this,!0),b.loadManifest(a.images)}},b._handleManifestFileLoad=function(a){var b=a.result;if(null!=b){var c=this.getResult().images,d=c.indexOf(a.item.src);c[d]=b}},b._handleManifestComplete=function(a){this._result=new createjs.SpriteSheet(this._result),this._loadedItems=this._manifestQueue.getItems(!0),this._sendComplete()},b._handleManifestProgress=function(a){this.progress=a.progress*(1-c.SPRITESHEET_PROGRESS)+c.SPRITESHEET_PROGRESS,this._sendProgress(this.progress)},b._handleManifestError=function(a){var b=new createjs.Event("fileerror");b.item=a.data,this.dispatchEvent(b)},createjs.SpriteSheetLoader=createjs.promote(a,"AbstractLoader")}(),this.createjs=this.createjs||{},function(){"use strict";function a(a,b){this.AbstractLoader_constructor(a,b,createjs.AbstractLoader.SVG),this.resultFormatter=this._formatResult,this._tagSrcAttribute="data",b?this.setTag(document.createElement("svg")):(this.setTag(document.createElement("object")),this.getTag().type="image/svg+xml")}var b=createjs.extend(a,createjs.AbstractLoader),c=a;c.canLoadItem=function(a){return a.type==createjs.AbstractLoader.SVG},b._formatResult=function(a){var b=createjs.DataUtils.parseXML(a.getResult(!0),"text/xml"),c=a.getTag();return!this._preferXHR&&document.body.contains(c)&&document.body.removeChild(c),null!=b.documentElement?(c.appendChild(b.documentElement),c.style.visibility="visible",c):b},createjs.SVGLoader=createjs.promote(a,"AbstractLoader")}(),this.createjs=this.createjs||{},function(){"use strict";function a(a){this.AbstractLoader_constructor(a,!0,createjs.AbstractLoader.XML),this.resultFormatter=this._formatResult}var b=createjs.extend(a,createjs.AbstractLoader),c=a;c.canLoadItem=function(a){return a.type==createjs.AbstractLoader.XML},b._formatResult=function(a){return createjs.DataUtils.parseXML(a.getResult(!0),"text/xml")},createjs.XMLLoader=createjs.promote(a,"AbstractLoader")}(),this.createjs=this.createjs||{},function(){var a=createjs.SoundJS=createjs.SoundJS||{};a.version="0.6.2",a.buildDate="Thu, 26 Nov 2015 20:44:31 GMT"}(),this.createjs=this.createjs||{},createjs.indexOf=function(a,b){"use strict";for(var c=0,d=a.length;d>c;c++)if(b===a[c])return c;return-1},this.createjs=this.createjs||{},function(){"use strict";createjs.proxy=function(a,b){var c=Array.prototype.slice.call(arguments,2);return function(){return a.apply(b,Array.prototype.slice.call(arguments,0).concat(c))}}}(),this.createjs=this.createjs||{},function(){"use strict";function a(){throw"BrowserDetect cannot be instantiated"}var b=a.agent=window.navigator.userAgent;a.isWindowPhone=b.indexOf("IEMobile")>-1||b.indexOf("Windows Phone")>-1,a.isFirefox=b.indexOf("Firefox")>-1,a.isOpera=null!=window.opera,a.isChrome=b.indexOf("Chrome")>-1,a.isIOS=(b.indexOf("iPod")>-1||b.indexOf("iPhone")>-1||b.indexOf("iPad")>-1)&&!a.isWindowPhone,a.isAndroid=b.indexOf("Android")>-1&&!a.isWindowPhone,a.isBlackberry=b.indexOf("Blackberry")>-1,createjs.BrowserDetect=a}(),this.createjs=this.createjs||{},function(){"use strict";var a=function(){this.interrupt=null,this.delay=null,this.offset=null,this.loop=null,this.volume=null,this.pan=null,this.startTime=null,this.duration=null},b=a.prototype={},c=a;c.create=function(a){if(a instanceof c||a instanceof Object){var b=new createjs.PlayPropsConfig;return b.set(a),b}throw new Error("Type not recognized.")},b.set=function(a){for(var b in a)this[b]=a[b];return this},b.toString=function(){return"[PlayPropsConfig]"},createjs.PlayPropsConfig=c}(),this.createjs=this.createjs||{},function(){"use strict";function a(){throw"Sound cannot be instantiated"}function b(a,b){this.init(a,b)}var c=a;c.INTERRUPT_ANY="any",c.INTERRUPT_EARLY="early",c.INTERRUPT_LATE="late",c.INTERRUPT_NONE="none",c.PLAY_INITED="playInited",c.PLAY_SUCCEEDED="playSucceeded",c.PLAY_INTERRUPTED="playInterrupted",c.PLAY_FINISHED="playFinished",c.PLAY_FAILED="playFailed",c.SUPPORTED_EXTENSIONS=["mp3","ogg","opus","mpeg","wav","m4a","mp4","aiff","wma","mid"],c.EXTENSION_MAP={m4a:"mp4"},c.FILE_PATTERN=/^(?:(\w+:)\/{2}(\w+(?:\.\w+)*\/?))?([\/.]*?(?:[^?]+)?\/)?((?:[^\/?]+)\.(\w+))(?:\?(\S+)?)?$/,c.defaultInterruptBehavior=c.INTERRUPT_NONE,c.alternateExtensions=[],c.activePlugin=null,c._masterVolume=1,Object.defineProperty(c,"volume",{get:function(){return this._masterVolume},set:function(a){if(null==Number(a))return!1;if(a=Math.max(0,Math.min(1,a)),c._masterVolume=a,!this.activePlugin||!this.activePlugin.setVolume||!this.activePlugin.setVolume(a))for(var b=this._instances,d=0,e=b.length;e>d;d++)b[d].setMasterVolume(a)}}),c._masterMute=!1,Object.defineProperty(c,"muted",{get:function(){return this._masterMute},set:function(a){if(null==a)return!1;if(this._masterMute=a,!this.activePlugin||!this.activePlugin.setMute||!this.activePlugin.setMute(a))for(var b=this._instances,c=0,d=b.length;d>c;c++)b[c].setMasterMute(a);return!0}}),Object.defineProperty(c,"capabilities",{get:function(){return null==c.activePlugin?null:c.activePlugin._capabilities},set:function(a){return!1}}),c._pluginsRegistered=!1,c._lastID=0,c._instances=[],c._idHash={},c._preloadHash={},c._defaultPlayPropsHash={},c.addEventListener=null,c.removeEventListener=null,c.removeAllEventListeners=null,c.dispatchEvent=null,c.hasEventListener=null,c._listeners=null,createjs.EventDispatcher.initialize(c),c.getPreloadHandlers=function(){return{callback:createjs.proxy(c.initLoad,c),types:["sound"],extensions:c.SUPPORTED_EXTENSIONS}},c._handleLoadComplete=function(a){var b=a.target.getItem().src;if(c._preloadHash[b])for(var d=0,e=c._preloadHash[b].length;e>d;d++){var f=c._preloadHash[b][d];if(c._preloadHash[b][d]=!0,c.hasEventListener("fileload")){var a=new createjs.Event("fileload");a.src=f.src,a.id=f.id,a.data=f.data,a.sprite=f.sprite,c.dispatchEvent(a)}}},c._handleLoadError=function(a){var b=a.target.getItem().src;if(c._preloadHash[b])for(var d=0,e=c._preloadHash[b].length;e>d;d++){var f=c._preloadHash[b][d];if(c._preloadHash[b][d]=!1,c.hasEventListener("fileerror")){var a=new createjs.Event("fileerror");a.src=f.src,a.id=f.id,a.data=f.data,a.sprite=f.sprite,c.dispatchEvent(a)}}},c._registerPlugin=function(a){return a.isSupported()?(c.activePlugin=new a,!0):!1},c.registerPlugins=function(a){c._pluginsRegistered=!0;for(var b=0,d=a.length;d>b;b++)if(c._registerPlugin(a[b]))return!0;return!1},c.initializeDefaultPlugins=function(){return null!=c.activePlugin?!0:c._pluginsRegistered?!1:c.registerPlugins([createjs.WebAudioPlugin,createjs.HTMLAudioPlugin])?!0:!1},c.isReady=function(){return null!=c.activePlugin},c.getCapabilities=function(){return null==c.activePlugin?null:c.activePlugin._capabilities},c.getCapability=function(a){return null==c.activePlugin?null:c.activePlugin._capabilities[a]},c.initLoad=function(a){return c._registerSound(a)},c._registerSound=function(a){if(!c.initializeDefaultPlugins())return!1;var d;if(a.src instanceof Object?(d=c._parseSrc(a.src),d.src=a.path+d.src):d=c._parsePath(a.src),null==d)return!1;a.src=d.src,a.type="sound";var e=a.data,f=null;if(null!=e&&(isNaN(e.channels)?isNaN(e)||(f=parseInt(e)):f=parseInt(e.channels),e.audioSprite))for(var g,h=e.audioSprite.length;h--;)g=e.audioSprite[h],c._idHash[g.id]={src:a.src,startTime:parseInt(g.startTime),duration:parseInt(g.duration)},g.defaultPlayProps&&(c._defaultPlayPropsHash[g.id]=createjs.PlayPropsConfig.create(g.defaultPlayProps));null!=a.id&&(c._idHash[a.id]={src:a.src});var i=c.activePlugin.register(a);return b.create(a.src,f),null!=e&&isNaN(e)?a.data.channels=f||b.maxPerChannel():a.data=f||b.maxPerChannel(),i.type&&(a.type=i.type),a.defaultPlayProps&&(c._defaultPlayPropsHash[a.src]=createjs.PlayPropsConfig.create(a.defaultPlayProps)),i},c.registerSound=function(a,b,d,e,f){var g={src:a,id:b,data:d,defaultPlayProps:f};a instanceof Object&&a.src&&(e=b,g=a),g=createjs.LoadItem.create(g),g.path=e,null==e||g.src instanceof Object||(g.src=e+a);var h=c._registerSound(g);if(!h)return!1;if(c._preloadHash[g.src]||(c._preloadHash[g.src]=[]),c._preloadHash[g.src].push(g),1==c._preloadHash[g.src].length)h.on("complete",createjs.proxy(this._handleLoadComplete,this)),h.on("error",createjs.proxy(this._handleLoadError,this)),c.activePlugin.preload(h);else if(1==c._preloadHash[g.src][0])return!0;return g},c.registerSounds=function(a,b){var c=[];a.path&&(b?b+=a.path:b=a.path,a=a.manifest);for(var d=0,e=a.length;e>d;d++)c[d]=createjs.Sound.registerSound(a[d].src,a[d].id,a[d].data,b,a[d].defaultPlayProps);return c},c.removeSound=function(a,d){if(null==c.activePlugin)return!1;a instanceof Object&&a.src&&(a=a.src);var e;if(a instanceof Object?e=c._parseSrc(a):(a=c._getSrcById(a).src,e=c._parsePath(a)),null==e)return!1;a=e.src,null!=d&&(a=d+a);for(var f in c._idHash)c._idHash[f].src==a&&delete c._idHash[f];return b.removeSrc(a),delete c._preloadHash[a],c.activePlugin.removeSound(a),!0},c.removeSounds=function(a,b){var c=[];a.path&&(b?b+=a.path:b=a.path,a=a.manifest);for(var d=0,e=a.length;e>d;d++)c[d]=createjs.Sound.removeSound(a[d].src,b);return c},c.removeAllSounds=function(){c._idHash={},c._preloadHash={},b.removeAll(),c.activePlugin&&c.activePlugin.removeAllSounds()},c.loadComplete=function(a){if(!c.isReady())return!1;var b=c._parsePath(a);return a=b?c._getSrcById(b.src).src:c._getSrcById(a).src,void 0==c._preloadHash[a]?!1:1==c._preloadHash[a][0]},c._parsePath=function(a){"string"!=typeof a&&(a=a.toString());var b=a.match(c.FILE_PATTERN);if(null==b)return!1;for(var d=b[4],e=b[5],f=c.capabilities,g=0;!f[e];)if(e=c.alternateExtensions[g++],g>c.alternateExtensions.length)return null;a=a.replace("."+b[5],"."+e);var h={name:d,src:a,extension:e};return h},c._parseSrc=function(a){var b={name:void 0,src:void 0,extension:void 0},d=c.capabilities;for(var e in a)if(a.hasOwnProperty(e)&&d[e]){b.src=a[e],b.extension=e;break}if(!b.src)return!1;var f=b.src.lastIndexOf("/");return-1!=f?b.name=b.src.slice(f+1):b.name=b.src,b},c.play=function(a,b,d,e,f,g,h,i,j){var k;k=b instanceof Object||b instanceof createjs.PlayPropsConfig?createjs.PlayPropsConfig.create(b):createjs.PlayPropsConfig.create({interrupt:b,delay:d,offset:e,loop:f,volume:g,pan:h,startTime:i,duration:j});var l=c.createInstance(a,k.startTime,k.duration),m=c._playInstance(l,k);return m||l._playFailed(),l},c.createInstance=function(a,d,e){if(!c.initializeDefaultPlugins())return new createjs.DefaultSoundInstance(a,d,e);var f=c._defaultPlayPropsHash[a];a=c._getSrcById(a);var g=c._parsePath(a.src),h=null;return null!=g&&null!=g.src?(b.create(g.src),null==d&&(d=a.startTime),h=c.activePlugin.create(g.src,d,e||a.duration),f=f||c._defaultPlayPropsHash[g.src],f&&h.applyPlayProps(f)):h=new createjs.DefaultSoundInstance(a,d,e),h.uniqueId=c._lastID++,h},c.stop=function(){for(var a=this._instances,b=a.length;b--;)a[b].stop()},c.setVolume=function(a){if(null==Number(a))return!1;if(a=Math.max(0,Math.min(1,a)),c._masterVolume=a,!this.activePlugin||!this.activePlugin.setVolume||!this.activePlugin.setVolume(a))for(var b=this._instances,d=0,e=b.length;e>d;d++)b[d].setMasterVolume(a)},c.getVolume=function(){return this._masterVolume},c.setMute=function(a){if(null==a)return!1;if(this._masterMute=a,!this.activePlugin||!this.activePlugin.setMute||!this.activePlugin.setMute(a))for(var b=this._instances,c=0,d=b.length;d>c;c++)b[c].setMasterMute(a);return!0},c.getMute=function(){return this._masterMute},c.setDefaultPlayProps=function(a,b){a=c._getSrcById(a),c._defaultPlayPropsHash[c._parsePath(a.src).src]=createjs.PlayPropsConfig.create(b)},c.getDefaultPlayProps=function(a){return a=c._getSrcById(a),c._defaultPlayPropsHash[c._parsePath(a.src).src]},c._playInstance=function(a,b){var d=c._defaultPlayPropsHash[a.src]||{};if(null==b.interrupt&&(b.interrupt=d.interrupt||c.defaultInterruptBehavior),null==b.delay&&(b.delay=d.delay||0),null==b.offset&&(b.offset=a.getPosition()),null==b.loop&&(b.loop=a.loop),null==b.volume&&(b.volume=a.volume),null==b.pan&&(b.pan=a.pan),0==b.delay){var e=c._beginPlaying(a,b);if(!e)return!1}else{var f=setTimeout(function(){c._beginPlaying(a,b)},b.delay);a.delayTimeoutId=f}return this._instances.push(a),!0},c._beginPlaying=function(a,c){if(!b.add(a,c.interrupt))return!1;var d=a._beginPlaying(c);if(!d){var e=createjs.indexOf(this._instances,a);return e>-1&&this._instances.splice(e,1),!1}return!0},c._getSrcById=function(a){return c._idHash[a]||{src:a}},c._playFinished=function(a){b.remove(a);var c=createjs.indexOf(this._instances,a);c>-1&&this._instances.splice(c,1)},createjs.Sound=a,b.channels={},b.create=function(a,c){var d=b.get(a);return null==d?(b.channels[a]=new b(a,c),!0):!1},b.removeSrc=function(a){var c=b.get(a);return null==c?!1:(c._removeAll(),delete b.channels[a],!0)},b.removeAll=function(){for(var a in b.channels)b.channels[a]._removeAll();b.channels={}},b.add=function(a,c){var d=b.get(a.src);return null==d?!1:d._add(a,c)},b.remove=function(a){var c=b.get(a.src);return null==c?!1:(c._remove(a),!0)},b.maxPerChannel=function(){return d.maxDefault},b.get=function(a){return b.channels[a]};var d=b.prototype;d.constructor=b,d.src=null,d.max=null,d.maxDefault=100,d.length=0,d.init=function(a,b){this.src=a,this.max=b||this.maxDefault,-1==this.max&&(this.max=this.maxDefault),this._instances=[]},d._get=function(a){return this._instances[a]},d._add=function(a,b){return this._getSlot(b,a)?(this._instances.push(a),this.length++,!0):!1},d._remove=function(a){var b=createjs.indexOf(this._instances,a);return-1==b?!1:(this._instances.splice(b,1),this.length--,!0)},d._removeAll=function(){for(var a=this.length-1;a>=0;a--)this._instances[a].stop()},d._getSlot=function(b,c){var d,e;if(b!=a.INTERRUPT_NONE&&(e=this._get(0),null==e))return!0;for(var f=0,g=this.max;g>f;f++){if(d=this._get(f),null==d)return!0;if(d.playState==a.PLAY_FINISHED||d.playState==a.PLAY_INTERRUPTED||d.playState==a.PLAY_FAILED){e=d;break}b!=a.INTERRUPT_NONE&&(b==a.INTERRUPT_EARLY&&d.getPosition()<e.getPosition()||b==a.INTERRUPT_LATE&&d.getPosition()>e.getPosition())&&(e=d)}return null!=e?(e._interrupt(),this._remove(e),!0):!1},d.toString=function(){return"[Sound SoundChannel]"}}(),this.createjs=this.createjs||{},function(){"use strict";var a=function(a,b,c,d){this.EventDispatcher_constructor(),this.src=a,this.uniqueId=-1,this.playState=null,this.delayTimeoutId=null,this._volume=1,Object.defineProperty(this,"volume",{get:this.getVolume,set:this.setVolume}),this._pan=0,Object.defineProperty(this,"pan",{get:this.getPan,set:this.setPan}),this._startTime=Math.max(0,b||0),Object.defineProperty(this,"startTime",{get:this.getStartTime,set:this.setStartTime}),this._duration=Math.max(0,c||0),Object.defineProperty(this,"duration",{get:this.getDuration,set:this.setDuration}),this._playbackResource=null,Object.defineProperty(this,"playbackResource",{get:this.getPlaybackResource,set:this.setPlaybackResource}),d!==!1&&d!==!0&&this.setPlaybackResource(d),this._position=0,Object.defineProperty(this,"position",{get:this.getPosition,set:this.setPosition}),this._loop=0,Object.defineProperty(this,"loop",{get:this.getLoop,set:this.setLoop}),this._muted=!1,Object.defineProperty(this,"muted",{get:this.getMuted,set:this.setMuted}),this._paused=!1,Object.defineProperty(this,"paused",{get:this.getPaused,set:this.setPaused})},b=createjs.extend(a,createjs.EventDispatcher);b.play=function(a,b,c,d,e,f){var g;return g=a instanceof Object||a instanceof createjs.PlayPropsConfig?createjs.PlayPropsConfig.create(a):createjs.PlayPropsConfig.create({interrupt:a,delay:b,offset:c,loop:d,volume:e,pan:f}),this.playState==createjs.Sound.PLAY_SUCCEEDED?(this.applyPlayProps(g),void(this._paused&&this.setPaused(!1))):(this._cleanUp(),createjs.Sound._playInstance(this,g),this)},b.stop=function(){return this._position=0,this._paused=!1,this._handleStop(),this._cleanUp(),this.playState=createjs.Sound.PLAY_FINISHED,this},b.destroy=function(){this._cleanUp(),this.src=null,this.playbackResource=null,this.removeAllEventListeners()},b.applyPlayProps=function(a){return null!=a.offset&&this.setPosition(a.offset),null!=a.loop&&this.setLoop(a.loop),null!=a.volume&&this.setVolume(a.volume),null!=a.pan&&this.setPan(a.pan),null!=a.startTime&&(this.setStartTime(a.startTime),this.setDuration(a.duration)),this},b.toString=function(){return"[AbstractSoundInstance]"},b.getPaused=function(){return this._paused},b.setPaused=function(a){return a!==!0&&a!==!1||this._paused==a||1==a&&this.playState!=createjs.Sound.PLAY_SUCCEEDED?void 0:(this._paused=a,a?this._pause():this._resume(),clearTimeout(this.delayTimeoutId),this)},b.setVolume=function(a){return a==this._volume?this:(this._volume=Math.max(0,Math.min(1,a)),this._muted||this._updateVolume(),this)},b.getVolume=function(){return this._volume},b.setMuted=function(a){return a===!0||a===!1?(this._muted=a,this._updateVolume(),this):void 0},b.getMuted=function(){return this._muted},b.setPan=function(a){return a==this._pan?this:(this._pan=Math.max(-1,Math.min(1,a)),this._updatePan(),this)},b.getPan=function(){return this._pan},b.getPosition=function(){return this._paused||this.playState!=createjs.Sound.PLAY_SUCCEEDED||(this._position=this._calculateCurrentPosition()),this._position},b.setPosition=function(a){return this._position=Math.max(0,a),this.playState==createjs.Sound.PLAY_SUCCEEDED&&this._updatePosition(),this},b.getStartTime=function(){return this._startTime},b.setStartTime=function(a){return a==this._startTime?this:(this._startTime=Math.max(0,a||0),this._updateStartTime(),this)},b.getDuration=function(){return this._duration},b.setDuration=function(a){return a==this._duration?this:(this._duration=Math.max(0,a||0),this._updateDuration(),this)},b.setPlaybackResource=function(a){return this._playbackResource=a,0==this._duration&&this._setDurationFromSource(),this},b.getPlaybackResource=function(){return this._playbackResource},b.getLoop=function(){return this._loop},b.setLoop=function(a){null!=this._playbackResource&&(0!=this._loop&&0==a?this._removeLooping(a):0==this._loop&&0!=a&&this._addLooping(a)),this._loop=a},b._sendEvent=function(a){var b=new createjs.Event(a);this.dispatchEvent(b)},b._cleanUp=function(){clearTimeout(this.delayTimeoutId),this._handleCleanUp(),this._paused=!1,createjs.Sound._playFinished(this)},b._interrupt=function(){this._cleanUp(),this.playState=createjs.Sound.PLAY_INTERRUPTED,this._sendEvent("interrupted")},b._beginPlaying=function(a){return this.setPosition(a.offset),this.setLoop(a.loop),this.setVolume(a.volume),this.setPan(a.pan),null!=a.startTime&&(this.setStartTime(a.startTime),this.setDuration(a.duration)),null!=this._playbackResource&&this._position<this._duration?(this._paused=!1,this._handleSoundReady(),this.playState=createjs.Sound.PLAY_SUCCEEDED,this._sendEvent("succeeded"),!0):(this._playFailed(),!1)},b._playFailed=function(){this._cleanUp(),this.playState=createjs.Sound.PLAY_FAILED,this._sendEvent("failed")},b._handleSoundComplete=function(a){return this._position=0,0!=this._loop?(this._loop--,this._handleLoop(),void this._sendEvent("loop")):(this._cleanUp(),this.playState=createjs.Sound.PLAY_FINISHED,void this._sendEvent("complete"))},b._handleSoundReady=function(){},b._updateVolume=function(){},b._updatePan=function(){},b._updateStartTime=function(){},b._updateDuration=function(){},b._setDurationFromSource=function(){},b._calculateCurrentPosition=function(){},b._updatePosition=function(){},b._removeLooping=function(a){},b._addLooping=function(a){},b._pause=function(){},b._resume=function(){},b._handleStop=function(){},b._handleCleanUp=function(){},b._handleLoop=function(){},createjs.AbstractSoundInstance=createjs.promote(a,"EventDispatcher"),createjs.DefaultSoundInstance=createjs.AbstractSoundInstance}(),this.createjs=this.createjs||{},function(){"use strict";var a=function(){this._capabilities=null,this._loaders={},this._audioSources={},this._soundInstances={},this._volume=1,this._loaderClass,this._soundInstanceClass},b=a.prototype;a._capabilities=null,a.isSupported=function(){return!0},b.register=function(a){var b=this._loaders[a.src];return b&&!b.canceled?this._loaders[a.src]:(this._audioSources[a.src]=!0,this._soundInstances[a.src]=[],b=new this._loaderClass(a),b.on("complete",this._handlePreloadComplete,this),this._loaders[a.src]=b,b)},b.preload=function(a){a.on("error",this._handlePreloadError,this),a.load()},b.isPreloadStarted=function(a){return null!=this._audioSources[a]},b.isPreloadComplete=function(a){return!(null==this._audioSources[a]||1==this._audioSources[a])},b.removeSound=function(a){if(this._soundInstances[a]){for(var b=this._soundInstances[a].length;b--;){var c=this._soundInstances[a][b];c.destroy()}delete this._soundInstances[a],delete this._audioSources[a],this._loaders[a]&&this._loaders[a].destroy(),delete this._loaders[a]}},b.removeAllSounds=function(){for(var a in this._audioSources)this.removeSound(a)},b.create=function(a,b,c){this.isPreloadStarted(a)||this.preload(this.register(a));var d=new this._soundInstanceClass(a,b,c,this._audioSources[a]);return this._soundInstances[a].push(d),d},b.setVolume=function(a){return this._volume=a,this._updateVolume(),!0},b.getVolume=function(){return this._volume},b.setMute=function(a){return this._updateVolume(),!0},b.toString=function(){return"[AbstractPlugin]"},b._handlePreloadComplete=function(a){var b=a.target.getItem().src;this._audioSources[b]=a.result;for(var c=0,d=this._soundInstances[b].length;d>c;c++){var e=this._soundInstances[b][c];e.setPlaybackResource(this._audioSources[b]);
}},b._handlePreloadError=function(a){},b._updateVolume=function(){},createjs.AbstractPlugin=a}(),this.createjs=this.createjs||{},function(){"use strict";function a(a){this.AbstractLoader_constructor(a,!0,createjs.AbstractLoader.SOUND)}var b=createjs.extend(a,createjs.AbstractLoader);a.context=null,b.toString=function(){return"[WebAudioLoader]"},b._createRequest=function(){this._request=new createjs.XHRRequest(this._item,!1),this._request.setResponseType("arraybuffer")},b._sendComplete=function(b){a.context.decodeAudioData(this._rawResult,createjs.proxy(this._handleAudioDecoded,this),createjs.proxy(this._sendError,this))},b._handleAudioDecoded=function(a){this._result=a,this.AbstractLoader__sendComplete()},createjs.WebAudioLoader=createjs.promote(a,"AbstractLoader")}(),this.createjs=this.createjs||{},function(){"use strict";function a(a,b,d,e){this.AbstractSoundInstance_constructor(a,b,d,e),this.gainNode=c.context.createGain(),this.panNode=c.context.createPanner(),this.panNode.panningModel=c._panningModel,this.panNode.connect(this.gainNode),this._updatePan(),this.sourceNode=null,this._soundCompleteTimeout=null,this._sourceNodeNext=null,this._playbackStartTime=0,this._endedHandler=createjs.proxy(this._handleSoundComplete,this)}var b=createjs.extend(a,createjs.AbstractSoundInstance),c=a;c.context=null,c._scratchBuffer=null,c.destinationNode=null,c._panningModel="equalpower",b.destroy=function(){this.AbstractSoundInstance_destroy(),this.panNode.disconnect(0),this.panNode=null,this.gainNode.disconnect(0),this.gainNode=null},b.toString=function(){return"[WebAudioSoundInstance]"},b._updatePan=function(){this.panNode.setPosition(this._pan,0,-.5)},b._removeLooping=function(a){this._sourceNodeNext=this._cleanUpAudioNode(this._sourceNodeNext)},b._addLooping=function(a){this.playState==createjs.Sound.PLAY_SUCCEEDED&&(this._sourceNodeNext=this._createAndPlayAudioNode(this._playbackStartTime,0))},b._setDurationFromSource=function(){this._duration=1e3*this.playbackResource.duration},b._handleCleanUp=function(){this.sourceNode&&this.playState==createjs.Sound.PLAY_SUCCEEDED&&(this.sourceNode=this._cleanUpAudioNode(this.sourceNode),this._sourceNodeNext=this._cleanUpAudioNode(this._sourceNodeNext)),0!=this.gainNode.numberOfOutputs&&this.gainNode.disconnect(0),clearTimeout(this._soundCompleteTimeout),this._playbackStartTime=0},b._cleanUpAudioNode=function(a){if(a){a.stop(0),a.disconnect(0);try{a.buffer=c._scratchBuffer}catch(b){}a=null}return a},b._handleSoundReady=function(a){this.gainNode.connect(c.destinationNode);var b=.001*this._duration,d=.001*this._position;d>b&&(d=b),this.sourceNode=this._createAndPlayAudioNode(c.context.currentTime-b,d),this._playbackStartTime=this.sourceNode.startTime-d,this._soundCompleteTimeout=setTimeout(this._endedHandler,1e3*(b-d)),0!=this._loop&&(this._sourceNodeNext=this._createAndPlayAudioNode(this._playbackStartTime,0))},b._createAndPlayAudioNode=function(a,b){var d=c.context.createBufferSource();d.buffer=this.playbackResource,d.connect(this.panNode);var e=.001*this._duration;return d.startTime=a+e,d.start(d.startTime,b+.001*this._startTime,e-b),d},b._pause=function(){this._position=1e3*(c.context.currentTime-this._playbackStartTime),this.sourceNode=this._cleanUpAudioNode(this.sourceNode),this._sourceNodeNext=this._cleanUpAudioNode(this._sourceNodeNext),0!=this.gainNode.numberOfOutputs&&this.gainNode.disconnect(0),clearTimeout(this._soundCompleteTimeout)},b._resume=function(){this._handleSoundReady()},b._updateVolume=function(){var a=this._muted?0:this._volume;a!=this.gainNode.gain.value&&(this.gainNode.gain.value=a)},b._calculateCurrentPosition=function(){return 1e3*(c.context.currentTime-this._playbackStartTime)},b._updatePosition=function(){this.sourceNode=this._cleanUpAudioNode(this.sourceNode),this._sourceNodeNext=this._cleanUpAudioNode(this._sourceNodeNext),clearTimeout(this._soundCompleteTimeout),this._paused||this._handleSoundReady()},b._handleLoop=function(){this._cleanUpAudioNode(this.sourceNode),this.sourceNode=this._sourceNodeNext,this._playbackStartTime=this.sourceNode.startTime,this._sourceNodeNext=this._createAndPlayAudioNode(this._playbackStartTime,0),this._soundCompleteTimeout=setTimeout(this._endedHandler,this._duration)},b._updateDuration=function(){this.playState==createjs.Sound.PLAY_SUCCEEDED&&(this._pause(),this._resume())},createjs.WebAudioSoundInstance=createjs.promote(a,"AbstractSoundInstance")}(),this.createjs=this.createjs||{},function(){"use strict";function a(){this.AbstractPlugin_constructor(),this._panningModel=c._panningModel,this.context=c.context,this.dynamicsCompressorNode=this.context.createDynamicsCompressor(),this.dynamicsCompressorNode.connect(this.context.destination),this.gainNode=this.context.createGain(),this.gainNode.connect(this.dynamicsCompressorNode),createjs.WebAudioSoundInstance.destinationNode=this.gainNode,this._capabilities=c._capabilities,this._loaderClass=createjs.WebAudioLoader,this._soundInstanceClass=createjs.WebAudioSoundInstance,this._addPropsToClasses()}var b=createjs.extend(a,createjs.AbstractPlugin),c=a;c._capabilities=null,c._panningModel="equalpower",c.context=null,c._scratchBuffer=null,c._unlocked=!1,c.isSupported=function(){var a=createjs.BrowserDetect.isIOS||createjs.BrowserDetect.isAndroid||createjs.BrowserDetect.isBlackberry;return"file:"!=location.protocol||a||this._isFileXHRSupported()?(c._generateCapabilities(),null==c.context?!1:!0):!1},c.playEmptySound=function(){if(null!=c.context){var a=c.context.createBufferSource();a.buffer=c._scratchBuffer,a.connect(c.context.destination),a.start(0,0,0)}},c._isFileXHRSupported=function(){var a=!0,b=new XMLHttpRequest;try{b.open("GET","WebAudioPluginTest.fail",!1)}catch(c){return a=!1}b.onerror=function(){a=!1},b.onload=function(){a=404==this.status||200==this.status||0==this.status&&""!=this.response};try{b.send()}catch(c){a=!1}return a},c._generateCapabilities=function(){if(null==c._capabilities){var a=document.createElement("audio");if(null==a.canPlayType)return null;if(null==c.context)if(window.AudioContext)c.context=new AudioContext;else{if(!window.webkitAudioContext)return null;c.context=new webkitAudioContext}null==c._scratchBuffer&&(c._scratchBuffer=c.context.createBuffer(1,1,22050)),c._compatibilitySetUp(),"ontouchstart"in window&&"running"!=c.context.state&&(c._unlock(),document.addEventListener("mousedown",c._unlock,!0),document.addEventListener("touchend",c._unlock,!0)),c._capabilities={panning:!0,volume:!0,tracks:-1};for(var b=createjs.Sound.SUPPORTED_EXTENSIONS,d=createjs.Sound.EXTENSION_MAP,e=0,f=b.length;f>e;e++){var g=b[e],h=d[g]||g;c._capabilities[g]="no"!=a.canPlayType("audio/"+g)&&""!=a.canPlayType("audio/"+g)||"no"!=a.canPlayType("audio/"+h)&&""!=a.canPlayType("audio/"+h)}c.context.destination.numberOfChannels<2&&(c._capabilities.panning=!1)}},c._compatibilitySetUp=function(){if(c._panningModel="equalpower",!c.context.createGain){c.context.createGain=c.context.createGainNode;var a=c.context.createBufferSource();a.__proto__.start=a.__proto__.noteGrainOn,a.__proto__.stop=a.__proto__.noteOff,c._panningModel=0}},c._unlock=function(){c._unlocked||(c.playEmptySound(),"running"==c.context.state&&(document.removeEventListener("mousedown",c._unlock,!0),document.removeEventListener("touchend",c._unlock,!0),c._unlocked=!0))},b.toString=function(){return"[WebAudioPlugin]"},b._addPropsToClasses=function(){var a=this._soundInstanceClass;a.context=this.context,a._scratchBuffer=c._scratchBuffer,a.destinationNode=this.gainNode,a._panningModel=this._panningModel,this._loaderClass.context=this.context},b._updateVolume=function(){var a=createjs.Sound._masterMute?0:this._volume;a!=this.gainNode.gain.value&&(this.gainNode.gain.value=a)},createjs.WebAudioPlugin=createjs.promote(a,"AbstractPlugin")}(),this.createjs=this.createjs||{},function(){"use strict";function a(){throw"HTMLAudioTagPool cannot be instantiated"}function b(a){this._tags=[]}var c=a;c._tags={},c._tagPool=new b,c._tagUsed={},c.get=function(a){var b=c._tags[a];return null==b?(b=c._tags[a]=c._tagPool.get(),b.src=a):c._tagUsed[a]?(b=c._tagPool.get(),b.src=a):c._tagUsed[a]=!0,b},c.set=function(a,b){b==c._tags[a]?c._tagUsed[a]=!1:c._tagPool.set(b)},c.remove=function(a){var b=c._tags[a];return null==b?!1:(c._tagPool.set(b),delete c._tags[a],delete c._tagUsed[a],!0)},c.getDuration=function(a){var b=c._tags[a];return null!=b&&b.duration?1e3*b.duration:0},createjs.HTMLAudioTagPool=a;var d=b.prototype;d.constructor=b,d.get=function(){var a;return a=0==this._tags.length?this._createTag():this._tags.pop(),null==a.parentNode&&document.body.appendChild(a),a},d.set=function(a){var b=createjs.indexOf(this._tags,a);-1==b&&(this._tags.src=null,this._tags.push(a))},d.toString=function(){return"[TagPool]"},d._createTag=function(){var a=document.createElement("audio");return a.autoplay=!1,a.preload="none",a}}(),this.createjs=this.createjs||{},function(){"use strict";function a(a,b,c,d){this.AbstractSoundInstance_constructor(a,b,c,d),this._audioSpriteStopTime=null,this._delayTimeoutId=null,this._endedHandler=createjs.proxy(this._handleSoundComplete,this),this._readyHandler=createjs.proxy(this._handleTagReady,this),this._stalledHandler=createjs.proxy(this._playFailed,this),this._audioSpriteEndHandler=createjs.proxy(this._handleAudioSpriteLoop,this),this._loopHandler=createjs.proxy(this._handleSoundComplete,this),c?this._audioSpriteStopTime=.001*(b+c):this._duration=createjs.HTMLAudioTagPool.getDuration(this.src)}var b=createjs.extend(a,createjs.AbstractSoundInstance);b.setMasterVolume=function(a){this._updateVolume()},b.setMasterMute=function(a){this._updateVolume()},b.toString=function(){return"[HTMLAudioSoundInstance]"},b._removeLooping=function(){null!=this._playbackResource&&(this._playbackResource.loop=!1,this._playbackResource.removeEventListener(createjs.HTMLAudioPlugin._AUDIO_SEEKED,this._loopHandler,!1))},b._addLooping=function(){null==this._playbackResource||this._audioSpriteStopTime||(this._playbackResource.addEventListener(createjs.HTMLAudioPlugin._AUDIO_SEEKED,this._loopHandler,!1),this._playbackResource.loop=!0)},b._handleCleanUp=function(){var a=this._playbackResource;if(null!=a){a.pause(),a.loop=!1,a.removeEventListener(createjs.HTMLAudioPlugin._AUDIO_ENDED,this._endedHandler,!1),a.removeEventListener(createjs.HTMLAudioPlugin._AUDIO_READY,this._readyHandler,!1),a.removeEventListener(createjs.HTMLAudioPlugin._AUDIO_STALLED,this._stalledHandler,!1),a.removeEventListener(createjs.HTMLAudioPlugin._AUDIO_SEEKED,this._loopHandler,!1),a.removeEventListener(createjs.HTMLAudioPlugin._TIME_UPDATE,this._audioSpriteEndHandler,!1);try{a.currentTime=this._startTime}catch(b){}createjs.HTMLAudioTagPool.set(this.src,a),this._playbackResource=null}},b._beginPlaying=function(a){return this._playbackResource=createjs.HTMLAudioTagPool.get(this.src),this.AbstractSoundInstance__beginPlaying(a)},b._handleSoundReady=function(a){if(4!==this._playbackResource.readyState){var b=this._playbackResource;return b.addEventListener(createjs.HTMLAudioPlugin._AUDIO_READY,this._readyHandler,!1),b.addEventListener(createjs.HTMLAudioPlugin._AUDIO_STALLED,this._stalledHandler,!1),b.preload="auto",void b.load()}this._updateVolume(),this._playbackResource.currentTime=.001*(this._startTime+this._position),this._audioSpriteStopTime?this._playbackResource.addEventListener(createjs.HTMLAudioPlugin._TIME_UPDATE,this._audioSpriteEndHandler,!1):(this._playbackResource.addEventListener(createjs.HTMLAudioPlugin._AUDIO_ENDED,this._endedHandler,!1),0!=this._loop&&(this._playbackResource.addEventListener(createjs.HTMLAudioPlugin._AUDIO_SEEKED,this._loopHandler,!1),this._playbackResource.loop=!0)),this._playbackResource.play()},b._handleTagReady=function(a){this._playbackResource.removeEventListener(createjs.HTMLAudioPlugin._AUDIO_READY,this._readyHandler,!1),this._playbackResource.removeEventListener(createjs.HTMLAudioPlugin._AUDIO_STALLED,this._stalledHandler,!1),this._handleSoundReady()},b._pause=function(){this._playbackResource.pause()},b._resume=function(){this._playbackResource.play()},b._updateVolume=function(){if(null!=this._playbackResource){var a=this._muted||createjs.Sound._masterMute?0:this._volume*createjs.Sound._masterVolume;a!=this._playbackResource.volume&&(this._playbackResource.volume=a)}},b._calculateCurrentPosition=function(){return 1e3*this._playbackResource.currentTime-this._startTime},b._updatePosition=function(){this._playbackResource.removeEventListener(createjs.HTMLAudioPlugin._AUDIO_SEEKED,this._loopHandler,!1),this._playbackResource.addEventListener(createjs.HTMLAudioPlugin._AUDIO_SEEKED,this._handleSetPositionSeek,!1);try{this._playbackResource.currentTime=.001*(this._position+this._startTime)}catch(a){this._handleSetPositionSeek(null)}},b._handleSetPositionSeek=function(a){null!=this._playbackResource&&(this._playbackResource.removeEventListener(createjs.HTMLAudioPlugin._AUDIO_SEEKED,this._handleSetPositionSeek,!1),this._playbackResource.addEventListener(createjs.HTMLAudioPlugin._AUDIO_SEEKED,this._loopHandler,!1))},b._handleAudioSpriteLoop=function(a){this._playbackResource.currentTime<=this._audioSpriteStopTime||(this._playbackResource.pause(),0==this._loop?this._handleSoundComplete(null):(this._position=0,this._loop--,this._playbackResource.currentTime=.001*this._startTime,this._paused||this._playbackResource.play(),this._sendEvent("loop")))},b._handleLoop=function(a){0==this._loop&&(this._playbackResource.loop=!1,this._playbackResource.removeEventListener(createjs.HTMLAudioPlugin._AUDIO_SEEKED,this._loopHandler,!1))},b._updateStartTime=function(){this._audioSpriteStopTime=.001*(this._startTime+this._duration),this.playState==createjs.Sound.PLAY_SUCCEEDED&&(this._playbackResource.removeEventListener(createjs.HTMLAudioPlugin._AUDIO_ENDED,this._endedHandler,!1),this._playbackResource.addEventListener(createjs.HTMLAudioPlugin._TIME_UPDATE,this._audioSpriteEndHandler,!1))},b._updateDuration=function(){this._audioSpriteStopTime=.001*(this._startTime+this._duration),this.playState==createjs.Sound.PLAY_SUCCEEDED&&(this._playbackResource.removeEventListener(createjs.HTMLAudioPlugin._AUDIO_ENDED,this._endedHandler,!1),this._playbackResource.addEventListener(createjs.HTMLAudioPlugin._TIME_UPDATE,this._audioSpriteEndHandler,!1))},b._setDurationFromSource=function(){this._duration=createjs.HTMLAudioTagPool.getDuration(this.src),this._playbackResource=null},createjs.HTMLAudioSoundInstance=createjs.promote(a,"AbstractSoundInstance")}(),this.createjs=this.createjs||{},function(){"use strict";function a(){this.AbstractPlugin_constructor(),this.defaultNumChannels=2,this._capabilities=c._capabilities,this._loaderClass=createjs.SoundLoader,this._soundInstanceClass=createjs.HTMLAudioSoundInstance}var b=createjs.extend(a,createjs.AbstractPlugin),c=a;c.MAX_INSTANCES=30,c._AUDIO_READY="canplaythrough",c._AUDIO_ENDED="ended",c._AUDIO_SEEKED="seeked",c._AUDIO_STALLED="stalled",c._TIME_UPDATE="timeupdate",c._capabilities=null,c.isSupported=function(){return c._generateCapabilities(),null!=c._capabilities},c._generateCapabilities=function(){if(null==c._capabilities){var a=document.createElement("audio");if(null==a.canPlayType)return null;c._capabilities={panning:!1,volume:!0,tracks:-1};for(var b=createjs.Sound.SUPPORTED_EXTENSIONS,d=createjs.Sound.EXTENSION_MAP,e=0,f=b.length;f>e;e++){var g=b[e],h=d[g]||g;c._capabilities[g]="no"!=a.canPlayType("audio/"+g)&&""!=a.canPlayType("audio/"+g)||"no"!=a.canPlayType("audio/"+h)&&""!=a.canPlayType("audio/"+h)}}},b.register=function(a){var b=createjs.HTMLAudioTagPool.get(a.src),c=this.AbstractPlugin_register(a);return c.setTag(b),c},b.removeSound=function(a){this.AbstractPlugin_removeSound(a),createjs.HTMLAudioTagPool.remove(a)},b.create=function(a,b,c){var d=this.AbstractPlugin_create(a,b,c);return d.setPlaybackResource(null),d},b.toString=function(){return"[HTMLAudioPlugin]"},b.setVolume=b.getVolume=b.setMute=null,createjs.HTMLAudioPlugin=createjs.promote(a,"AbstractPlugin")}(),this.createjs=this.createjs||{},function(){"use strict";function a(b,c,d){this.ignoreGlobalPause=!1,this.loop=!1,this.duration=0,this.pluginData=d||{},this.target=b,this.position=null,this.passive=!1,this._paused=!1,this._curQueueProps={},this._initQueueProps={},this._steps=[],this._actions=[],this._prevPosition=0,this._stepPosition=0,this._prevPos=-1,this._target=b,this._useTicks=!1,this._inited=!1,this._registered=!1,c&&(this._useTicks=c.useTicks,this.ignoreGlobalPause=c.ignoreGlobalPause,this.loop=c.loop,c.onChange&&this.addEventListener("change",c.onChange),c.override&&a.removeTweens(b)),c&&c.paused?this._paused=!0:createjs.Tween._register(this,!0),c&&null!=c.position&&this.setPosition(c.position,a.NONE)}var b=createjs.extend(a,createjs.EventDispatcher);a.NONE=0,a.LOOP=1,a.REVERSE=2,a.IGNORE={},a._tweens=[],a._plugins={},a.get=function(b,c,d,e){return e&&a.removeTweens(b),new a(b,c,d)},a.tick=function(b,c){for(var d=a._tweens.slice(),e=d.length-1;e>=0;e--){var f=d[e];c&&!f.ignoreGlobalPause||f._paused||f.tick(f._useTicks?1:b)}},a.handleEvent=function(a){"tick"==a.type&&this.tick(a.delta,a.paused)},a.removeTweens=function(b){if(b.tweenjs_count){for(var c=a._tweens,d=c.length-1;d>=0;d--){var e=c[d];e._target==b&&(e._paused=!0,c.splice(d,1))}b.tweenjs_count=0}},a.removeAllTweens=function(){for(var b=a._tweens,c=0,d=b.length;d>c;c++){var e=b[c];e._paused=!0,e.target&&(e.target.tweenjs_count=0)}b.length=0},a.hasActiveTweens=function(b){return b?null!=b.tweenjs_count&&!!b.tweenjs_count:a._tweens&&!!a._tweens.length},a.installPlugin=function(b,c){var d=b.priority;null==d&&(b.priority=d=0);for(var e=0,f=c.length,g=a._plugins;f>e;e++){var h=c[e];if(g[h]){for(var i=g[h],j=0,k=i.length;k>j&&!(d<i[j].priority);j++);g[h].splice(j,0,b)}else g[h]=[b]}},a._register=function(b,c){var d=b._target,e=a._tweens;if(c&&!b._registered)d&&(d.tweenjs_count=d.tweenjs_count?d.tweenjs_count+1:1),e.push(b),!a._inited&&createjs.Ticker&&(createjs.Ticker.addEventListener("tick",a),a._inited=!0);else if(!c&&b._registered){d&&d.tweenjs_count--;for(var f=e.length;f--;)if(e[f]==b){e.splice(f,1);break}}b._registered=c},b.wait=function(a,b){if(null==a||0>=a)return this;var c=this._cloneProps(this._curQueueProps);return this._addStep({d:a,p0:c,e:this._linearEase,p1:c,v:b})},b.to=function(a,b,c){return(isNaN(b)||0>b)&&(b=0),this._addStep({d:b||0,p0:this._cloneProps(this._curQueueProps),e:c,p1:this._cloneProps(this._appendQueueProps(a))})},b.call=function(a,b,c){return this._addAction({f:a,p:b?b:[this],o:c?c:this._target})},b.set=function(a,b){return this._addAction({f:this._set,o:this,p:[a,b?b:this._target]})},b.play=function(a){return a||(a=this),this.call(a.setPaused,[!1],a)},b.pause=function(a){return a||(a=this),this.call(a.setPaused,[!0],a)},b.setPosition=function(a,b){0>a&&(a=0),null==b&&(b=1);var c=a,d=!1;if(c>=this.duration&&(this.loop?c%=this.duration:(c=this.duration,d=!0)),c==this._prevPos)return d;var e=this._prevPos;if(this.position=this._prevPos=c,this._prevPosition=a,this._target)if(d)this._updateTargetProps(null,1);else if(this._steps.length>0){for(var f=0,g=this._steps.length;g>f&&!(this._steps[f].t>c);f++);var h=this._steps[f-1];this._updateTargetProps(h,(this._stepPosition=c-h.t)/h.d)}return 0!=b&&this._actions.length>0&&(this._useTicks?this._runActions(c,c):1==b&&e>c?(e!=this.duration&&this._runActions(e,this.duration),this._runActions(0,c,!0)):this._runActions(e,c)),d&&this.setPaused(!0),this.dispatchEvent("change"),d},b.tick=function(a){this._paused||this.setPosition(this._prevPosition+a)},b.setPaused=function(b){return this._paused===!!b?this:(this._paused=!!b,a._register(this,!b),this)},b.w=b.wait,b.t=b.to,b.c=b.call,b.s=b.set,b.toString=function(){return"[Tween]"},b.clone=function(){throw"Tween can not be cloned."},b._updateTargetProps=function(b,c){var d,e,f,g,h,i;if(b||1!=c){if(this.passive=!!b.v,this.passive)return;b.e&&(c=b.e(c,0,1,1)),d=b.p0,e=b.p1}else this.passive=!1,d=e=this._curQueueProps;for(var j in this._initQueueProps){null==(g=d[j])&&(d[j]=g=this._initQueueProps[j]),null==(h=e[j])&&(e[j]=h=g),f=g==h||0==c||1==c||"number"!=typeof g?1==c?h:g:g+(h-g)*c;var k=!1;if(i=a._plugins[j])for(var l=0,m=i.length;m>l;l++){var n=i[l].tween(this,j,f,d,e,c,!!b&&d==e,!b);n==a.IGNORE?k=!0:f=n}k||(this._target[j]=f)}},b._runActions=function(a,b,c){var d=a,e=b,f=-1,g=this._actions.length,h=1;for(a>b&&(d=b,e=a,f=g,g=h=-1);(f+=h)!=g;){var i=this._actions[f],j=i.t;(j==e||j>d&&e>j||c&&j==a)&&i.f.apply(i.o,i.p)}},b._appendQueueProps=function(b){var c,d,e,f,g;for(var h in b)if(void 0===this._initQueueProps[h]){if(d=this._target[h],c=a._plugins[h])for(e=0,f=c.length;f>e;e++)d=c[e].init(this,h,d);this._initQueueProps[h]=this._curQueueProps[h]=void 0===d?null:d}else d=this._curQueueProps[h];for(var h in b){if(d=this._curQueueProps[h],c=a._plugins[h])for(g=g||{},e=0,f=c.length;f>e;e++)c[e].step&&c[e].step(this,h,d,b[h],g);this._curQueueProps[h]=b[h]}return g&&this._appendQueueProps(g),this._curQueueProps},b._cloneProps=function(a){var b={};for(var c in a)b[c]=a[c];return b},b._addStep=function(a){return a.d>0&&(this._steps.push(a),a.t=this.duration,this.duration+=a.d),this},b._addAction=function(a){return a.t=this.duration,this._actions.push(a),this},b._set=function(a,b){for(var c in a)b[c]=a[c]},createjs.Tween=createjs.promote(a,"EventDispatcher")}(),this.createjs=this.createjs||{},function(){"use strict";function a(a,b,c){this.EventDispatcher_constructor(),this.ignoreGlobalPause=!1,this.duration=0,this.loop=!1,this.position=null,this._paused=!1,this._tweens=[],this._labels=null,this._labelList=null,this._prevPosition=0,this._prevPos=-1,this._useTicks=!1,this._registered=!1,c&&(this._useTicks=c.useTicks,this.loop=c.loop,this.ignoreGlobalPause=c.ignoreGlobalPause,c.onChange&&this.addEventListener("change",c.onChange)),a&&this.addTween.apply(this,a),this.setLabels(b),c&&c.paused?this._paused=!0:createjs.Tween._register(this,!0),c&&null!=c.position&&this.setPosition(c.position,createjs.Tween.NONE)}var b=createjs.extend(a,createjs.EventDispatcher);b.addTween=function(a){var b=arguments.length;if(b>1){for(var c=0;b>c;c++)this.addTween(arguments[c]);return arguments[0]}return 0==b?null:(this.removeTween(a),this._tweens.push(a),a.setPaused(!0),a._paused=!1,a._useTicks=this._useTicks,a.duration>this.duration&&(this.duration=a.duration),this._prevPos>=0&&a.setPosition(this._prevPos,createjs.Tween.NONE),a)},b.removeTween=function(a){var b=arguments.length;if(b>1){for(var c=!0,d=0;b>d;d++)c=c&&this.removeTween(arguments[d]);return c}if(0==b)return!1;for(var e=this._tweens,d=e.length;d--;)if(e[d]==a)return e.splice(d,1),a.duration>=this.duration&&this.updateDuration(),!0;return!1},b.addLabel=function(a,b){this._labels[a]=b;var c=this._labelList;if(c){for(var d=0,e=c.length;e>d&&!(b<c[d].position);d++);c.splice(d,0,{label:a,position:b})}},b.setLabels=function(a){this._labels=a?a:{}},b.getLabels=function(){var a=this._labelList;if(!a){a=this._labelList=[];var b=this._labels;for(var c in b)a.push({label:c,position:b[c]});a.sort(function(a,b){return a.position-b.position})}return a},b.getCurrentLabel=function(){var a=this.getLabels(),b=this.position,c=a.length;if(c){for(var d=0;c>d&&!(b<a[d].position);d++);return 0==d?null:a[d-1].label}return null},b.gotoAndPlay=function(a){this.setPaused(!1),this._goto(a)},b.gotoAndStop=function(a){this.setPaused(!0),this._goto(a)},b.setPosition=function(a,b){var c=this._calcPosition(a),d=!this.loop&&a>=this.duration;if(c==this._prevPos)return d;this._prevPosition=a,this.position=this._prevPos=c;for(var e=0,f=this._tweens.length;f>e;e++)if(this._tweens[e].setPosition(c,b),c!=this._prevPos)return!1;return d&&this.setPaused(!0),this.dispatchEvent("change"),d},b.setPaused=function(a){this._paused=!!a,createjs.Tween._register(this,!a)},b.updateDuration=function(){this.duration=0;for(var a=0,b=this._tweens.length;b>a;a++){var c=this._tweens[a];c.duration>this.duration&&(this.duration=c.duration)}},b.tick=function(a){this.setPosition(this._prevPosition+a)},b.resolve=function(a){var b=Number(a);return isNaN(b)&&(b=this._labels[a]),b},b.toString=function(){return"[Timeline]"},b.clone=function(){throw"Timeline can not be cloned."},b._goto=function(a){var b=this.resolve(a);null!=b&&this.setPosition(b)},b._calcPosition=function(a){return 0>a?0:a<this.duration?a:this.loop?a%this.duration:this.duration},createjs.Timeline=createjs.promote(a,"EventDispatcher")}(),this.createjs=this.createjs||{},function(){"use strict";function a(){throw"Ease cannot be instantiated."}a.linear=function(a){return a},a.none=a.linear,a.get=function(a){return-1>a&&(a=-1),a>1&&(a=1),function(b){return 0==a?b:0>a?b*(b*-a+1+a):b*((2-b)*a+(1-a))}},a.getPowIn=function(a){return function(b){return Math.pow(b,a)}},a.getPowOut=function(a){return function(b){return 1-Math.pow(1-b,a)}},a.getPowInOut=function(a){return function(b){return(b*=2)<1?.5*Math.pow(b,a):1-.5*Math.abs(Math.pow(2-b,a))}},a.quadIn=a.getPowIn(2),a.quadOut=a.getPowOut(2),a.quadInOut=a.getPowInOut(2),a.cubicIn=a.getPowIn(3),a.cubicOut=a.getPowOut(3),a.cubicInOut=a.getPowInOut(3),a.quartIn=a.getPowIn(4),a.quartOut=a.getPowOut(4),a.quartInOut=a.getPowInOut(4),a.quintIn=a.getPowIn(5),a.quintOut=a.getPowOut(5),a.quintInOut=a.getPowInOut(5),a.sineIn=function(a){return 1-Math.cos(a*Math.PI/2)},a.sineOut=function(a){return Math.sin(a*Math.PI/2)},a.sineInOut=function(a){return-.5*(Math.cos(Math.PI*a)-1)},a.getBackIn=function(a){return function(b){return b*b*((a+1)*b-a)}},a.backIn=a.getBackIn(1.7),a.getBackOut=function(a){return function(b){return--b*b*((a+1)*b+a)+1}},a.backOut=a.getBackOut(1.7),a.getBackInOut=function(a){return a*=1.525,function(b){return(b*=2)<1?.5*(b*b*((a+1)*b-a)):.5*((b-=2)*b*((a+1)*b+a)+2)}},a.backInOut=a.getBackInOut(1.7),a.circIn=function(a){return-(Math.sqrt(1-a*a)-1)},a.circOut=function(a){return Math.sqrt(1- --a*a)},a.circInOut=function(a){return(a*=2)<1?-.5*(Math.sqrt(1-a*a)-1):.5*(Math.sqrt(1-(a-=2)*a)+1)},a.bounceIn=function(b){return 1-a.bounceOut(1-b)},a.bounceOut=function(a){return 1/2.75>a?7.5625*a*a:2/2.75>a?7.5625*(a-=1.5/2.75)*a+.75:2.5/2.75>a?7.5625*(a-=2.25/2.75)*a+.9375:7.5625*(a-=2.625/2.75)*a+.984375},a.bounceInOut=function(b){return.5>b?.5*a.bounceIn(2*b):.5*a.bounceOut(2*b-1)+.5},a.getElasticIn=function(a,b){var c=2*Math.PI;return function(d){if(0==d||1==d)return d;var e=b/c*Math.asin(1/a);return-(a*Math.pow(2,10*(d-=1))*Math.sin((d-e)*c/b))}},a.elasticIn=a.getElasticIn(1,.3),a.getElasticOut=function(a,b){var c=2*Math.PI;return function(d){if(0==d||1==d)return d;var e=b/c*Math.asin(1/a);return a*Math.pow(2,-10*d)*Math.sin((d-e)*c/b)+1}},a.elasticOut=a.getElasticOut(1,.3),a.getElasticInOut=function(a,b){var c=2*Math.PI;return function(d){var e=b/c*Math.asin(1/a);return(d*=2)<1?-.5*(a*Math.pow(2,10*(d-=1))*Math.sin((d-e)*c/b)):a*Math.pow(2,-10*(d-=1))*Math.sin((d-e)*c/b)*.5+1}},a.elasticInOut=a.getElasticInOut(1,.3*1.5),createjs.Ease=a}(),this.createjs=this.createjs||{},function(){"use strict";function a(){throw"MotionGuidePlugin cannot be instantiated."}a.priority=0,a._rotOffS,a._rotOffE,a._rotNormS,a._rotNormE,a.install=function(){return createjs.Tween.installPlugin(a,["guide","x","y","rotation"]),createjs.Tween.IGNORE},a.init=function(a,b,c){var d=a.target;return d.hasOwnProperty("x")||(d.x=0),d.hasOwnProperty("y")||(d.y=0),d.hasOwnProperty("rotation")||(d.rotation=0),"rotation"==b&&(a.__needsRot=!0),"guide"==b?null:c},a.step=function(b,c,d,e,f){if("rotation"==c&&(b.__rotGlobalS=d,b.__rotGlobalE=e,a.testRotData(b,f)),"guide"!=c)return e;var g,h=e;h.hasOwnProperty("path")||(h.path=[]);var i=h.path;if(h.hasOwnProperty("end")||(h.end=1),h.hasOwnProperty("start")||(h.start=d&&d.hasOwnProperty("end")&&d.path===i?d.end:0),h.hasOwnProperty("_segments")&&h._length)return e;var j=i.length,k=10;if(!(j>=6&&(j-2)%4==0))throw"invalid 'path' data, please see documentation for valid paths";h._segments=[],h._length=0;for(var l=2;j>l;l+=4){for(var m,n,o=i[l-2],p=i[l-1],q=i[l+0],r=i[l+1],s=i[l+2],t=i[l+3],u=o,v=p,w=0,x=[],y=1;k>=y;y++){var z=y/k,A=1-z;m=A*A*o+2*A*z*q+z*z*s,n=A*A*p+2*A*z*r+z*z*t,w+=x[x.push(Math.sqrt((g=m-u)*g+(g=n-v)*g))-1],u=m,v=n}h._segments.push(w),h._segments.push(x),h._length+=w}g=h.orient,h.orient=!0;var B={};return a.calc(h,h.start,B),b.__rotPathS=Number(B.rotation.toFixed(5)),a.calc(h,h.end,B),b.__rotPathE=Number(B.rotation.toFixed(5)),h.orient=!1,a.calc(h,h.end,f),h.orient=g,h.orient?(b.__guideData=h,a.testRotData(b,f),e):e},a.testRotData=function(a,b){if(void 0===a.__rotGlobalS||void 0===a.__rotGlobalE){if(a.__needsRot)return;void 0!==a._curQueueProps.rotation?a.__rotGlobalS=a.__rotGlobalE=a._curQueueProps.rotation:a.__rotGlobalS=a.__rotGlobalE=b.rotation=a.target.rotation||0}if(void 0!==a.__guideData){var c=a.__guideData,d=a.__rotGlobalE-a.__rotGlobalS,e=a.__rotPathE-a.__rotPathS,f=d-e;if("auto"==c.orient)f>180?f-=360:-180>f&&(f+=360);else if("cw"==c.orient){for(;0>f;)f+=360;0==f&&d>0&&180!=d&&(f+=360)}else if("ccw"==c.orient){for(f=d-(e>180?360-e:e);f>0;)f-=360;0==f&&0>d&&-180!=d&&(f-=360)}c.rotDelta=f,c.rotOffS=a.__rotGlobalS-a.__rotPathS,a.__rotGlobalS=a.__rotGlobalE=a.__guideData=a.__needsRot=void 0}},a.tween=function(b,c,d,e,f,g,h,i){var j=f.guide;if(void 0==j||j===e.guide)return d;if(j.lastRatio!=g){var k=(j.end-j.start)*(h?j.end:g)+j.start;switch(a.calc(j,k,b.target),j.orient){case"cw":case"ccw":case"auto":b.target.rotation+=j.rotOffS+j.rotDelta*g;break;case"fixed":default:b.target.rotation+=j.rotOffS}j.lastRatio=g}return"rotation"!=c||j.orient&&"false"!=j.orient?b.target[c]:d},a.calc=function(a,b,c){if(void 0==a._segments)throw"Missing critical pre-calculated information, please file a bug";void 0==c&&(c={x:0,y:0,rotation:0});for(var d=a._segments,e=a.path,f=a._length*b,g=d.length-2,h=0;f>d[h]&&g>h;)f-=d[h],h+=2;var i=d[h+1],j=0;for(g=i.length-1;f>i[j]&&g>j;)f-=i[j],j++;var k=j/++g+f/(g*i[j]);h=2*h+2;var l=1-k;return c.x=l*l*e[h-2]+2*l*k*e[h+0]+k*k*e[h+2],c.y=l*l*e[h-1]+2*l*k*e[h+1]+k*k*e[h+3],a.orient&&(c.rotation=57.2957795*Math.atan2((e[h+1]-e[h-1])*l+(e[h+3]-e[h+1])*k,(e[h+0]-e[h-2])*l+(e[h+2]-e[h+0])*k)),c},createjs.MotionGuidePlugin=a}(),this.createjs=this.createjs||{},function(){"use strict";var a=createjs.TweenJS=createjs.TweenJS||{};a.version="0.6.2",a.buildDate="Thu, 26 Nov 2015 20:44:31 GMT"}();

//- - - - - - - - - - - - - - - - - - - - - - 3 - - - - - - - - - - - - - - - - - - - - - -
//lib/monster.cjs.ext.js
/*
    author: tilo hauke 1/2017
    version 2
 */
createjs.Container.prototype.STAGED_TIMEOUT = 40;
createjs.Container.prototype.default_addChild =  createjs.Container.prototype.addChild;
createjs.Container.prototype.addChild = function(child){
    if(!child) return;
    if(child instanceof createjs.MovieClip){
        this.setNames(child);
    }
    if(!child._isStaged  && child.name && createjs.isObjectOfInterest(child, child.name)){
        this.dispatchStaged(child);
    };
    return this.default_addChild(child);
};

createjs.Container.prototype.setNames = function(container){
    if(container._isNamed) return;
    container._isNamed = true;
    for(var key in container){
        if(createjs.isObjectOfInterest(container[key],key)){
            container[key].name = key;
            if(container[key] instanceof createjs.MovieClip){
                this.setNames(container[key]);
            }
        }
    }
};

createjs.Container.prototype.default_addChildAt =  createjs.Container.prototype.addChildAt;
createjs.Container.prototype.addChildAt = function(child, index){
    if(child instanceof createjs.MovieClip){
        this.setNames(child);
    }
    if(child instanceof createjs.Text && !child._textReady){
       this.dispatchEvent({type:'newText',item:child,bubbles:true});
       child._textReady = true;
    }

    if(createjs.isObjectOfInterest(child, child.name) && this._managed[child.id] == undefined){
        this.dispatchStaged(child);
    };

    return this.default_addChildAt(child,index);
};

createjs.Container.prototype.dispatchStaged = function (clip){
    clip._isStaged = true;
    setTimeout(function(){
        clip.dispatchEvent('staged',true);
    },this.STAGED_TIMEOUT);
}

createjs.isObjectOfInterest = function (obj,key){
    if(key && key.match(/^instance|^parent$/)) return false;
    return (obj instanceof createjs.MovieClip) || (obj instanceof createjs.Text);
};

createjs.Container.prototype.findObjectsByName = function(name, type, recursive){
   var found = [];
   for (var i = 0; i < this.numChildren; i++) {
       var child = this.getChildAt(i);
       if(child.name && child.name.match(name)){
            if(!type || (child instanceof type)) {
                found.push(child);
            }
       }
       if(recursive != false && child.numChildren) {
           found = found.concat(child.findObjectsByName(name, type, recursive));
       }
   }
   return found;
};

createjs.Container.prototype.findObjectsByKey = function(name, type, recursive){
    var found = [];
    for(var key in this){
        if(createjs.isObjectOfInterest(this[key],key) && key.match(name)){
            if(!type || (this[key] instanceof type)) {
                found.push(this[key]);
            }
            if(recursive != false && this[key] instanceof createjs.MovieClip){
                found = found.concat(this[key].findObjectsByKey(name, type, recursive));
            }
        }
    }
   return found;
};


//- - - - - - - - - - - - - - - - - - - - - - 4 - - - - - - - - - - - - - - - - - - - - - -
//lib/monster.text.v5.ext.js
/*
    author: tilo hauke (Julian Fibich) 2/2017 Christian Duerbeck/Ingo Klemm 23.01.2019
    version 5.1
    extends createjs.Text,
    - implements bold and italic-tags in text-fields
    - computes formatting only if text is changed
    - computes list-indent
    - implements line-break of CJK ideographs by considering them as word-units
        (see https://en.wikipedia.org/wiki/Han_unification)
        CJK Unified Ideographs              (4E00-9FFF)
        CJK Unified Ideographs Extension A  (3400-4DBF)
        Hiragana (japanese) 3040-309f
        Katakana(japanese) 30a0-30ff
        not CJK Unified Ideographs Extension B  (20000-2A6DF)
        not CJK Unified Ideographs Extension C  (2A700-2B73F)
        not CJK Unified Ideographs Extension D  (2B740-2B81F)
        not CJK Unified Ideographs Extension E  (2B820-2CEAF)
        see https://en.wikipedia.org/wiki/CJK_Symbols_and_Punctuation
        CJK Symbols and Punctuation (="Japanese-style punctuation") \u3000-\u303F
     - correcture for browsers if text is placed to high in _drawFormatted
 */

createjs.Text.prototype.formatted = null;
var formattings=0;
createjs.Text.prototype._getFormatting = function(ctx,o,lines){
    //console.log('formatting',++formattings,this.name);
    var MATCH_FORMAT = /(<)(.*\w+)(>)/;
    var MATCH_SPACE = /^\s+$/;
    var MATCH_UNIT_SPLIT = /(\s+|<\w+>|<\/\w+>|^[•▪▫►○●◦∙→]\s*|[\u3000-\u303F]*[\u4E00-\u9FFF\u3400-\u4DBF\u3040-\u309f\u30a0-\u30ff][\u3000-\u303F]*)/;
    var MATCH_LINE_SPLIT = /(?:\r\n|\r|\n)/;
    var MATCH_LIST = /[•▪▫►○●◦∙→]/;

    var defaultFont = this.font;
    var unitFont = this.font;
    var lineHeight = this.lineHeight||this.getMeasuredLineHeight();
    var lineIndex = 0;
    var lineTop = 0;
    var hardLines = String(this.text).split(MATCH_LINE_SPLIT);
    var italic = "";
    var bold = "";
    var formatted = {text:this.text, rows:[], width:0, height:0, cfw:0};

    for (var i=0; i < hardLines.length; i++) {
        var line = hardLines[i];
        var rowWidth = null;
        var indentWidth=0;
        var space = "";

        if (this.lineWidth != null) {
            var boxWidth = this.lineWidth-4;// for measureText is not precise
            var units = line.split(MATCH_UNIT_SPLIT).filter(Boolean);
            line = ""; rowWidth = 0;
            if(lineIndex) lineTop+=lineHeight;//+lineHeight/4;
            formatted.rows[lineIndex]={u:[],w:0,x:0,y:lineTop};

            for (var j=0; j<units.length; j++) {
                var unitWidth, unitString = units[j];

                if(unitString.match(MATCH_SPACE)) {
                    space = unitString;
                    continue;
                }

                if(unitString.match(MATCH_FORMAT)){
                    switch(unitString.replace(MATCH_FORMAT, "$2")){
                        case "/b": bold = ""; break;
                        case "/i": italic = ""; break;
                        case "b": bold = "bold "; break;
                        case "i": italic = "italic "; break;
                    }
                    unitFont= italic + bold + defaultFont;
                    ctx.font = unitFont;
                    continue;
                } else {
                    unitWidth = ctx.measureText(unitString).width;
                    if (rowWidth != 0 && rowWidth + unitWidth > boxWidth) {
                        //create new line...
                        if (lines) { lines.push(line);}
                        lineIndex ++;
                        lineTop += lineHeight;
                        formatted.rows[lineIndex]= {u:[],w:0,x:0,y:lineTop};
                        if(indentWidth!=0) {
                            formatted.rows[lineIndex].u.push({s:'', f:ctx.font, w:indentWidth});
                        }
                        line = unitString;
                        rowWidth = indentWidth+ctx.measureText(unitString).width;
                        formatted.rows[lineIndex].w = rowWidth;
                    } else {
                        unitString = space+unitString;
                        unitWidth = ctx.measureText(unitString).width;
                        if(rowWidth==0){
                            var bullet = unitString.match(MATCH_LIST)
                            if (bullet){
                                indentWidth = unitWidth; //ctx.measureText(bullet.toString()).width;
                            }
                        }
                        line += unitString;
                        space="";
                        rowWidth += unitWidth;
                        formatted.rows[lineIndex].w = rowWidth;
                    }
                    formatted.rows[lineIndex].u.push({s:unitString, f:unitFont, w:unitWidth})
                }
            }
            ctx.font = defaultFont;
        }

        if (lines) { lines.push(line);}
        if (o && rowWidth == null) { rowWidth = ctx.measureText(line).width;}
        lineIndex++;
    }

    for(var i =0; i < formatted.rows.length; i++) {
        var row = formatted.rows[i];
        switch (ctx.textAlign){
            case "center":
                row.x = - this.lineWidth/2 + (this.lineWidth-row.w)/2
                break;
            case "right":
                 row.x = -row.w;
                break;
        }

        if (row.w > formatted.width) { formatted.width = row.w;}
    }
    formatted.height = lineTop+lineHeight;
    return formatted;
};

createjs.Text.prototype._drawText = function(ctx, o, lines) {

    var paint = !!ctx;
    if (!paint) {
        ctx = createjs.Text._workingContext;
        ctx.save();
        this._prepContext(ctx);
    }
    var checkFontWidth = ctx.measureText("abcedefghjiklmnopqrstuvwxyz").width; // for checking css-fonts not yet ready to draw
    if(!this.formatted || this.formatted.lineWidth != this.lineWidth || this.formatted.cfw != checkFontWidth || this.formatted.text!=this.text){
        this.formatted = this._getFormatting(ctx,o, lines);
        this.formatted.cfw = checkFontWidth;
        this.formatted.lineWidth = this.lineWidth;
    }

    if (o) { o.width = this.formatted.width; o.height = this.formatted.height}
    if (paint) {
        this._drawFormatted(ctx,this.formatted.rows);
    } else {
        ctx.restore();
    }
    return o;
};

//var numDraw=0;

createjs.Text.prototype._drawFormatted = function(ctx, rows) {

    var align = ctx.textAlign;
    ctx.textAlign = "left";

    for(var i =0; i < rows.length; i++) {
        var line = rows[i];
        var x = line.x;
        for (var j = 0; j < line.u.length; j++){
            var unit = line.u[j];
            ctx.font = unit.f;

            var fontSize = Number(ctx.font.match(/(\d+)/)[0]);
            var corrY =  (!isNaN(fontSize)) ?  Math.round(fontSize) : 0;


            ctx.textBaseline = "alphabetic";
            ctx.fillText(unit.s, x, line.y + corrY, this.maxWidth||0xFFFF);


            x += unit.w;
        }
    }
    ctx.font = this.font;
    ctx.textAlign = align;
}




//- - - - - - - - - - - - - - - - - - - - - - 5 - - - - - - - - - - - - - - - - - - - - - -
//lib/tw.js
'Copyright (c) 2013 Ivan Kuckir ( ivan@kuckir.com ) Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions: The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software. THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.';

var Tweener =
{
	twns    : [],		// all tweens for object
	looping : false,	// if Tweener is looping
	_ptime  : 0,		// previous time
	def     : {			// default values
		time: 1,
		transition: "easeOutExpo",
		delay: 0,
		onStart: null,
		onStartParams: null,
		onUpdate: null,
		onUpdateParams: null,
		onComplete: null,
		onCompleteParams: null
	}
};


Tweener.addTween = function(o, ps)
{
	var T = Tweener;

	var tp = {}, prms = [], tgts = [];
	for(var p in T.def)  tp[p] = ps[p] ? ps[p] : T.def[p];

	for(var p in ps)
	{
		if(T.def[p]) continue;
		prms.push(p);
		tgts.push(ps[p]);
		//bgns.push(o[p]);
		//cngs.push(ps[p]-o[p]);

	}
	if(tp.onStart) if(tp.onStartParams) tp.onStart.apply(null, tp.onStartParams);  else tp.onStart();

	T.twns.push(new T.Tween(o, tp, prms, tgts));
	T.loop();
}

Tweener.loop = function()
{
	var T = Tweener;
	if(!T.looping)
	{
		T._ptime = new Date().getTime();
		requestAnimFrame(T.step);
	}
	T.looping = true;
}

Tweener.step = function()
{
	var T = Tweener;
	var ptime = T._ptime;
	T._ptime = new Date().getTime();
	var step = (T._ptime - ptime)*0.001;

	for(var i=0; i<T.twns.length; i++)
	{
		var t = T.twns[i];

		if(t.tp.delay > 0) t.tp.delay -= step;
		else
		{
			if(t.bgns.length==0)
				for(var j=0; j<t.prms.length; j++)
				{
					t.bgns.push(t.obj[t.prms[j]]);
					t.cngs.push(t.tgts[j]-t.bgns[j]);
				}

			t.t += step;
			var dur = t.tp.time;
			for(var j=0; j<t.prms.length; j++)
			{
				if(t.t > dur) t.obj[t.prms[j]] = t.bgns[j]+t.cngs[j];
				else t.obj[t.prms[j]] = Tweener.easingFunctions[t.tp.transition] (t.t, t.bgns[j], t.cngs[j], dur);
			}
			if(t.tp.onUpdate) if(t.tp.onUpdateParams) t.tp.onUpdate.apply(null, t.tp.onUpdateParams);  else t.tp.onUpdate();
			if(t.t > dur)
			{
				T.twns.splice(i--, 1);
				if(t.tp.onComplete) if(t.tp.onCompleteParams) t.tp.onComplete.apply(null, t.tp.onCompleteParams);  else t.tp.onComplete();
			}
		}
	}
	if(T.twns.length>0) requestAnimFrame(T.step);
	else T.looping = false;
}

/*
	Animation Frame
*/
if(window.requestAnimFrame == null) window.requestAnimFrame = (function() {
  return window.requestAnimationFrame ||
	 window.webkitRequestAnimationFrame ||
	 window.mozRequestAnimationFrame ||
	 window.oRequestAnimationFrame ||
	 window.msRequestAnimationFrame ||
	 function(/* function FrameRequestCallback */ callback, /* DOMElement Element */ element) {
	   window.setTimeout(callback, 1000/60);
	 };
})();


/*
	Tween class
*/
Tweener.Tween = function(obj, tp, prms, tgts)
{
	this.t   = 0;		// current time of tween (0 .. dur)
	this.obj = obj;		// object
	this.tp  = tp;		// tweening parameters

	this.prms = prms;	// parameter (string)
	this.tgts = tgts;
	this.bgns = [];	// starting value
	this.cngs = [];	// change (total during the whole tween)
}


Tweener.easingFunctions =
{
	/*
		t - current time of tween
		b - starting value of property
		c - change needed in value
		d - total duration of tween
	*/
    easeNone: function(t, b, c, d) {
        return c*t/d + b;
    },
    easeInQuad: function(t, b, c, d) {
        return c*(t/=d)*t + b;
    },
    easeOutQuad: function(t, b, c, d) {
        return -c *(t/=d)*(t-2) + b;
    },
    easeInOutQuad: function(t, b, c, d) {
        if((t/=d/2) < 1) return c/2*t*t + b;
        return -c/2 *((--t)*(t-2) - 1) + b;
    },
    easeInCubic: function(t, b, c, d) {
        return c*(t/=d)*t*t + b;
    },
    easeOutCubic: function(t, b, c, d) {
        return c*((t=t/d-1)*t*t + 1) + b;
    },
    easeInOutCubic: function(t, b, c, d) {
        if((t/=d/2) < 1) return c/2*t*t*t + b;
        return c/2*((t-=2)*t*t + 2) + b;
    },
    easeOutInCubic: function(t, b, c, d) {
        if(t < d/2) return Tweener.easingFunctions.easeOutCubic(t*2, b, c/2, d);
        return Tweener.easingFunctions.easeInCubic((t*2)-d, b+c/2, c/2, d);
    },
    easeInQuart: function(t, b, c, d) {
        return c*(t/=d)*t*t*t + b;
    },
    easeOutQuart: function(t, b, c, d) {
        return -c *((t=t/d-1)*t*t*t - 1) + b;
    },
    easeInOutQuart: function(t, b, c, d) {
        if((t/=d/2) < 1) return c/2*t*t*t*t + b;
        return -c/2 *((t-=2)*t*t*t - 2) + b;
    },
    easeOutInQuart: function(t, b, c, d) {
        if(t < d/2) return Tweener.easingFunctions.easeOutQuart(t*2, b, c/2, d);
        return Tweener.easingFunctions.easeInQuart((t*2)-d, b+c/2, c/2, d);
    },
    easeInQuint: function(t, b, c, d) {
        return c*(t/=d)*t*t*t*t + b;
    },
    easeOutQuint: function(t, b, c, d) {
        return c*((t=t/d-1)*t*t*t*t + 1) + b;
    },
    easeInOutQuint: function(t, b, c, d) {
        if((t/=d/2) < 1) return c/2*t*t*t*t*t + b;
        return c/2*((t-=2)*t*t*t*t + 2) + b;
    },
    easeOutInQuint: function(t, b, c, d) {
        if(t < d/2) return Tweener.easingFunctions.easeOutQuint(t*2, b, c/2, d);
        return Tweener.easingFunctions.easeInQuint((t*2)-d, b+c/2, c/2, d);
    },
    easeInSine: function(t, b, c, d) {
        return -c * Math.cos(t/d *(Math.PI/2)) + c + b;
    },
    easeOutSine: function(t, b, c, d) {
        return c * Math.sin(t/d *(Math.PI/2)) + b;
    },
    easeInOutSine: function(t, b, c, d) {
        return -c/2 *(Math.cos(Math.PI*t/d) - 1) + b;
    },
    easeOutInSine: function(t, b, c, d) {
        if(t < d/2) return Tweener.easingFunctions.easeOutSine(t*2, b, c/2, d);
        return Tweener.easingFunctions.easeInSine((t*2)-d, b+c/2, c/2, d);
    },
    easeInExpo: function(t, b, c, d) {
        return(t==0) ? b : c * Math.pow(2, 10 *(t/d - 1)) + b - c * 0.001;
    },
    easeOutExpo: function(t, b, c, d) {
        return(t==d) ? b+c : c * 1.001 *(-Math.pow(2, -10 * t/d) + 1) + b;
    },
    easeInOutExpo: function(t, b, c, d) {
        if(t==0) return b;
        if(t==d) return b+c;
        if((t/=d/2) < 1) return c/2 * Math.pow(2, 10 *(t - 1)) + b - c * 0.0005;
        return c/2 * 1.0005 *(-Math.pow(2, -10 * --t) + 2) + b;
    },
    easeOutInExpo: function(t, b, c, d) {
        if(t < d/2) return Tweener.easingFunctions.easeOutExpo(t*2, b, c/2, d);
        return Tweener.easingFunctions.easeInExpo((t*2)-d, b+c/2, c/2, d);
    },
    easeInCirc: function(t, b, c, d) {
        return -c *(Math.sqrt(1 -(t/=d)*t) - 1) + b;
    },
    easeOutCirc: function(t, b, c, d) {
        return c * Math.sqrt(1 -(t=t/d-1)*t) + b;
    },
    easeInOutCirc: function(t, b, c, d) {
        if((t/=d/2) < 1) return -c/2 *(Math.sqrt(1 - t*t) - 1) + b;
        return c/2 *(Math.sqrt(1 -(t-=2)*t) + 1) + b;
    },
    easeOutInCirc: function(t, b, c, d) {
        if(t < d/2) return Tweener.easingFunctions.easeOutCirc(t*2, b, c/2, d);
        return Tweener.easingFunctions.easeInCirc((t*2)-d, b+c/2, c/2, d);
    },
    easeInElastic: function(t, b, c, d, a, p) {
        var s;
        if(t==0) return b;  if((t/=d)==1) return b+c;  if(!p) p=d*.3;
        if(!a || a < Math.abs(c)) { a=c; s=p/4; } else s = p/(2*Math.PI) * Math.asin(c/a);
        return -(a*Math.pow(2,10*(t-=1)) * Math.sin((t*d-s)*(2*Math.PI)/p )) + b;
    },
    easeOutElastic: function(t, b, c, d, a, p) {
        var s;
        if(t==0) return b;  if((t/=d)==1) return b+c;  if(!p) p=d*.3;
        if(!a || a < Math.abs(c)) { a=c; s=p/4; } else s = p/(2*Math.PI) * Math.asin(c/a);
        return(a*Math.pow(2,-10*t) * Math.sin((t*d-s)*(2*Math.PI)/p ) + c + b);
    },
    easeInOutElastic: function(t, b, c, d, a, p) {
        var s;
        if(t==0) return b;  if((t/=d/2)==2) return b+c;  if(!p) p=d*(.3*1.5);
        if(!a || a < Math.abs(c)) { a=c; s=p/4; }       else s = p/(2*Math.PI) * Math.asin(c/a);
        if(t < 1) return -.5*(a*Math.pow(2,10*(t-=1)) * Math.sin((t*d-s)*(2*Math.PI)/p )) + b;
        return a*Math.pow(2,-10*(t-=1)) * Math.sin((t*d-s)*(2*Math.PI)/p )*.5 + c + b;
    },
    easeOutInElastic: function(t, b, c, d, a, p) {
        if(t < d/2) return Tweener.easingFunctions.easeOutElastic(t*2, b, c/2, d, a, p);
        return Tweener.easingFunctions.easeInElastic((t*2)-d, b+c/2, c/2, d, a, p);
    },
    easeInBack: function(t, b, c, d, s) {
        if(s == undefined) s = 1.70158;
        return c*(t/=d)*t*((s+1)*t - s) + b;
    },
    easeOutBack: function(t, b, c, d, s) {
        if(s == undefined) s = 1.70158;
        return c*((t=t/d-1)*t*((s+1)*t + s) + 1) + b;
    },
    easeInOutBack: function(t, b, c, d, s) {
        if(s == undefined) s = 1.70158;
        if((t/=d/2) < 1) return c/2*(t*t*(((s*=(1.525))+1)*t - s)) + b;
        return c/2*((t-=2)*t*(((s*=(1.525))+1)*t + s) + 2) + b;
    },
    easeOutInBack: function(t, b, c, d, s) {
        if(t < d/2) return Tweener.easingFunctions.easeOutBack(t*2, b, c/2, d, s);
        return Tweener.easingFunctions.easeInBack((t*2)-d, b+c/2, c/2, d, s);
    },
    easeInBounce: function(t, b, c, d) {
        return c - Tweener.easingFunctions.easeOutBounce(d-t, 0, c, d) + b;
    },
    easeOutBounce: function(t, b, c, d) {
        if((t/=d) <(1/2.75)) {
            return c*(7.5625*t*t) + b;
        } else if(t <(2/2.75)) {
            return c*(7.5625*(t-=(1.5/2.75))*t + .75) + b;
        } else if(t <(2.5/2.75)) {
            return c*(7.5625*(t-=(2.25/2.75))*t + .9375) + b;
        } else {
            return c*(7.5625*(t-=(2.625/2.75))*t + .984375) + b;
        }
    },
    easeInOutBounce: function(t, b, c, d) {
        if(t < d/2) return Tweener.easingFunctions.easeInBounce(t*2, 0, c, d) * .5 + b;
        else return Tweener.easingFunctions.easeOutBounce(t*2-d, 0, c, d) * .5 + c*.5 + b;
    },
    easeOutInBounce: function(t, b, c, d) {
        if(t < d/2) return Tweener.easingFunctions.easeOutBounce(t*2, b, c/2, d);
        return Tweener.easingFunctions.easeInBounce((t*2)-d, b+c/2, c/2, d);
    }
};
Tweener.easingFunctions.linear = Tweener.easingFunctions.easeNone;



//- - - - - - - - - - - - - - - - - - - - - - 6 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/utils/behavior/behaviorDraggable.js
/*
 author : tilo hauke 7/2016
 */
var behavior = behavior || {};

(function (behavior) {

    behavior.draggable = function (clip, grip) {
        if(clip.draggable) {
            //console.log('destroy draggable of', clip.name)
            clip.draggable.destroy()
        }
        new Draggable(clip, grip);

        function  Draggable(clip, grip) {

            var _draggable = this;
            clip.draggable = _draggable;
            //Object.defineProperty(clip, "draggable", { get: function () {return _draggable} });
            var _clip = clip;
            var _grip = grip || _clip; // has to be a child of clip
            var _constraints = {};
            var _pos = {};
            var _values = {};
            var _lock = false;

            this.update = function(){
                updateRatios();
            }
            Object.defineProperty(this, "constraints", {set: function (obj) {
                    _constraints = obj;
                    updateRatios();
                }});

            Object.defineProperty(this, "hRatio", {get: function () {
                    return _values.hRatio
                }});
            Object.defineProperty(this, "vRatio", {get: function () {
                    return _values.vRatio
                }});
            Object.defineProperty(this, "hSnap", {get: function () {
                    return _values.hSnap
                }});
            Object.defineProperty(this, "vSnap", {get: function () {
                    return _values.vSnap
                }});

            Object.defineProperty(this, "lock", {
                get: function () {
                    return _lock
                },
                set: function (bool) {
                    _lock = bool;
                    _grip.mouseEnabled = !_lock;
                    if (_lock) {
                        removeListener();
                    } else {
                        init();
                    }
                }
            });

            init();


            function init() {
                _grip.addEventListener("mousedown", onPress);
            }

            _draggable.destroy = function () {
                removeListener();
                delete(_clip.draggable);
            }

            function removeListener() {
                _grip.removeEventListener("mousedown", onPress);
                _clip.stage.removeEventListener("pressmove", onMove);
                _clip.stage.removeEventListener("pressup", onPressUp);
            }

            function onPress(e) {
                e.stopPropagation();
                e.stopImmediatePropagation();
                _clip.parent.addChild(_clip);
                var localPos = _clip.parent.globalToLocal(_clip.stage.mouseX, _clip.stage.mouseY);
                _pos.x0 = _pos.x1 = _clip.x; //if not moving before pressUp, the target x1 equals the initial x0
                _pos.y0 = _pos.y1 = _clip.y;
                _pos.x0m = localPos.x;
                _pos.y0m = localPos.y;
                _clip.stage.addEventListener("pressmove", onMove);
                _clip.stage.addEventListener("pressup", onPressUp);
                _clip.dispatchEvent('dragstart');
            }

            function onPressUp(e) {
                e.stopPropagation();
                e.stopImmediatePropagation();
                _clip.stage.removeEventListener("pressmove", onMove);
                _clip.stage.removeEventListener("pressup", onPressUp);
                if (_constraints.grid && !_constraints.grid.onMove)
                    adjustGrid();
                if (_constraints.snap && !_constraints.snap.onMove)
                    adjustSnap();
                setPosition(_pos.x1, _pos.y1);
                _clip.dispatchEvent('dragstop');
            }

            function onMove(e) {
                e.stopPropagation();
                e.stopImmediatePropagation();
                var localPos = _clip.parent.globalToLocal(_clip.stage.mouseX, _clip.stage.mouseY);
                _pos.x1 = _pos.x0 + localPos.x - _pos.x0m;
                _pos.y1 = _pos.y0 + localPos.y - _pos.y0m;
                setConstraints();
                setPosition(_pos.x1, _pos.y1);
            }

            function updateRatios(){
                _values.hRatio = _values.vRatio = 1;// assume zero degree of freedom
                if (_constraints.x != undefined && _constraints.width) {
                    _values.hRatio = (_clip.x - _constraints.x) / _constraints.width;
                }
                if (_constraints.y != undefined && _constraints.height) {
                    _values.vRatio = (_clip.y - _constraints.y) / _constraints.height;
                }
            }

            function setPosition(x, y) {
                _clip.x = x;
                _clip.y = y;
                updateRatios();
                _clip.dispatchEvent('drag');
            }

            function setConstraints() {
                if (_pos.x1 < _constraints.x)
                    _pos.x1 = _constraints.x;
                if (_pos.x1 > _constraints.x + _constraints.width)
                    _pos.x1 = _constraints.x + _constraints.width;
                if (_pos.y1 < _constraints.y)
                    _pos.y1 = _constraints.y;
                if (_pos.y1 > _constraints.y + _constraints.height)
                    _pos.y1 = _constraints.y + _constraints.height
                if (_constraints.grid && _constraints.grid.onMove)
                    adjustGrid();
                if (_constraints.snap && _constraints.snap.onMove)
                    adjustSnap();
            }

            function adjustGrid() {
                if (_constraints.grid.h) {
                    _pos.x1 = Math.round(_pos.x1 / _constraints.grid.h) * _constraints.grid.h;
                }
                if (_constraints.grid.v) {
                    _pos.y1 = Math.round(_pos.y1 / _constraints.grid.v) * _constraints.grid.v;
                }
            }

            function adjustSnap() {
                var dif, i, snap, pos, dist;
                delete _values.hSnap;
                if (_constraints.snap.h) {
                    dif = 0x1000000;
                    pos = _pos.x1;
                    for (i = 0; i < _constraints.snap.h.length; i++) {
                        snap = _constraints.snap.h[i];
                        dist = Math.abs(snap - _pos.x1);
                        if (dist < dif) {
                            //console.log(dist+' '+dif+' #'+i)
                            pos = snap;
                            dif = dist;
                            _values.hSnap = i;
                        }
                    }
                    _pos.x1 = pos;
                }
                delete _values.vSnap;
                if (_constraints.snap.v) {
                    dif = 0x1000;
                    pos = _pos.y1;
                    for (i = 0; i < _constraints.snap.v.length; i++) {
                        snap = _constraints.snap.v[i];
                        dist = Math.abs(snap - _pos.y1);
                        if (dist < dif) {
                            pos = snap;
                            dif = dist;
                            _values.vSnap = i;
                        }
                    }
                    _pos.y1 = pos;
                }
            }
        }
    }
})(behavior);




//- - - - - - - - - - - - - - - - - - - - - - 7 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/utils/behavior/behaviorLayout.js
var behavior = behavior || {};
(function (behavior) {

    behavior.layout = function (clip, options) {

        new Layout(clip, options);

        function Layout(_clip, options) {
            var _this = this;
            var _layoutBounds = new createjs.Rectangle(0,0,0,0);

            Object.defineProperty(clip, "layoutBounds", {
                get: function () {
                    return _layoutBounds;
                }
            });

            Object.defineProperty(clip, "layout", {
                get: function () {
                    return _this;
                }
            });

            Object.defineProperty(_this, "options", {
                get: function () {
                    var clone = {};
                    for (var prop in _options) {
                        clone[prop] = _options[prop];
                    }
                    return clone;
                }
            });

            var _options = {
                direction: 'VERTICAL', // VERTICAL|HORIZONTAL
                vAlign: 'TOP', // TOP|CENTER|BOTTOM|NONE
                hAlign: 'LEFT', // LEFT|CENTER|RIGHT|NONE -> NONE bedeutet, die Position wird beibehalten und das Element wird nicht aligned.
                gap: 0,
                overflow: 'VISIBLE', // VISIBLE|HIDDEN|FLOAT -> visible bedeutet autosize, float bedeutet kein autosize in <direction> sondern "umbruch"
            };


            _this.setOptions = function (obj) {
                for (var name in obj) {
                    _options[name] = obj[name];
                }
            };
            if (options) {
                _this.setOptions(options);
            }

            _this.toString = function () {
                var str = '';
                for (key in _options) {
                    str += key + ' : ' + _options[key] + '\n';
                }
                return str;
            }

            _this.update = function () {
                /* nur childs, die sinnvolle bounds zurück geben */
                var childs = getChildsByLevel(_clip).filter(isPlacable);
                if (childs.length) {
                    setMask();
                    alignChildren(childs);
                    childs.forEach(registerLayoutChilds);
                }

                var width = 0, height = 0;
                for (var i = 0; i < childs.length; i++) {
                    var child = childs[i];
                    var childBounds = getLayoutBounds(child)
                    width = Math.max(width, child.x + childBounds.width);
                    height = Math.max(height, child.y + childBounds.height);
                }
                _layoutBounds.width = width;
                _layoutBounds.height = height;
                _clip.dispatchEvent('boundsChanged');

            };

            function registerLayoutChilds(child){
                if(child.layoutBounds && !child.hasEventListener('boundsChanged')){
                    child.addEventListener('boundsChanged',onChildBoundsChanged)
                }
            }

            function onChildBoundsChanged(e){
                e.stopPropagation();
                _this.update();
            }

            function getLayoutBounds(displayObj) {
                return displayObj.layoutBounds || displayObj.nominalBounds || displayObj.getBounds() || null;
            }

            function isPlacable(item) {
                var bounds = getLayoutBounds(item);
                return bounds ? ( item.visible && bounds.height > 0 ) : false;
            }

            function setMask() {
                if (_options.overflow === 'HIDDEN') {
                    var mask = new createjs.Shape();
                    var bounds = getLayoutBounds(_clip);
                    mask.graphics.dr(bounds.x, bounds.y, bounds.width, bounds.height);
                    _clip.mask = mask;
                }
            }

            function alignChildren(childs) {
                _options.direction === 'VERTICAL' ? verticalAlign(childs) : horizontalAlign(childs);
            }

            function horizontalAlign(childs) {
                function createRows(childs) {
                    var prevChild = null;
                    var rows = [];
                    var currentRow = [];
                    rows.push(currentRow);
                    childs.forEach(function (child) {
                        child.x = (prevChild === null) ? 0 : prevChild.x + getLayoutBounds(prevChild).width + _options.gap;
                        if (child.x === 0) currentRow.rowHeight = getLayoutBounds(child).height;
                        if (_options.overflow === 'FLOAT') {
                            var bounds = getLayoutBounds(_clip);
                            if (child.x + getLayoutBounds(child).width > bounds.width) {
                                child.x = 0;
                                currentRow = [];
                                currentRow.rowHeight = getLayoutBounds(child).height;
                                rows.push(currentRow);
                            }
                        }
                        currentRow.push(child);
                        currentRow.rowHeight = Math.max(currentRow.rowHeight, getLayoutBounds(child).height);
                        prevChild = child;
                    });
                    return rows;
                }

                function leftAlign(childs) {
                    return createRows(childs);
                }

                function rightAlign(childs) {
                    var rows = createRows(childs);
                    rows.forEach(function (row) {
                            // move rows to the right
                            var deltaX = getLayoutBounds(_clip).width - ( row[row.length - 1].x + getLayoutBounds(row[row.length - 1]).width );
                            row.forEach(function (child) {
                                    child.x = child.x + deltaX;
                                }
                            )
                        }
                    )
                    return rows;
                }

                function centerChilds(childs) {
                    var rows = createRows(childs);
                    rows.forEach(function (row) {
                        var bounds = getLayoutBounds(row[row.length - 1]);
                        var rowWidth = row[row.length - 1].x + bounds.width;
                        var blockCorrection = ( getLayoutBounds(_clip).width - rowWidth ) / 2;
                        row.forEach(function (child) {
                                child.x = child.x + blockCorrection;
                            }
                        )
                    });
                    return rows;
                }

                function vAlignH(rows) {
                    var prevRow = null, prevY = 0;
                    if (rows) {
                        switch (_options.vAlign) {
                            case 'TOP' :
                                prevY = 0;
                                rows.forEach(function (row) {
                                        if (prevRow) {
                                            prevY = prevY + prevRow.rowHeight + _options.gap;
                                        }
                                        row.forEach(function (child) {
                                                child.y = prevY;
                                            }
                                        )
                                        prevRow = row;
                                    }
                                )
                                break;
                            case 'CENTER' :
                                var totalHeight = rows.reduce(function (height, row) {
                                    return height + row.rowHeight + _options.gap;
                                }, -_options.gap);
                                prevY = getLayoutBounds(_clip).height / 2 - totalHeight / 2;
                                rows.forEach(function (row) {
                                        if (prevRow) {
                                            prevY = prevY + prevRow.rowHeight + _options.gap;
                                        }
                                        row.forEach(function (child) {
                                                child.y = prevY;
                                            }
                                        )
                                        prevRow = row;
                                    }
                                )
                                break;
                            case 'BOTTOM' :
                                rows = rows.reverse();
                                prevY = getLayoutBounds(_clip).height - rows[0].rowHeight;
                                rows.forEach(function (row) {
                                    if (prevRow) {
                                        prevY = prevY - row.rowHeight - _options.gap;
                                    }
                                    row.forEach(function (child) {
                                            child.y = prevY;
                                        }
                                    )
                                    prevRow = row;
                                })
                        }
                    }
                }

                switch (_options.hAlign) {
                    case 'LEFT' :
                        vAlignH(leftAlign(childs));
                        break;
                    case 'CENTER' :
                        vAlignH(centerChilds(childs));
                        break;
                    case 'RIGHT' :
                        vAlignH(rightAlign(childs));
                }
            }

            function verticalAlign(childs) {

                function createCols(childs) {
                    var prevChild = null;
                    var cols = [];
                    var currentCol = [];
                    cols.push(currentCol);

                    childs.forEach(function (child) {
                        child.y = (prevChild === null) ? 0 : prevChild.y + getLayoutBounds(prevChild).height + _options.gap;
                        if (child.y === 0) currentCol.colWidth = getLayoutBounds(child).width;
                        if (_options.overflow === 'FLOAT') {
                            var bounds = getLayoutBounds(_clip);
                            if (child.y + getLayoutBounds(child).height > bounds.height) {
                                child.y = 0;
                                currentCol = [];
                                currentCol.colWidth = getLayoutBounds(child).width;
                                cols.push(currentCol);
                            }
                        }
                        currentCol.push(child);
                        currentCol.colWidth = Math.max(currentCol.colWidth, getLayoutBounds(child).width);
                        prevChild = child;
                    });
                    return cols;
                }

                function topAlign(childs) {
                    return createCols(childs);
                };

                function bottomAlign(childs) {
                    var cols = createCols(childs);
                    cols.forEach(function (col) {
                            var delta = getLayoutBounds(_clip).height - ( col[col.length - 1].y + getLayoutBounds(col[col.length - 1]).height );
                            col.forEach(function (child) {
                                    child.y += delta;
                                }
                            )
                        }
                    )
                    return cols;
                };

                function centerChilds(childs) {

                    var cols = createCols(childs);
                    cols.forEach(function (col) {
                            var delta = ( getLayoutBounds(_clip).height - ( col[col.length - 1].y + getLayoutBounds(col[col.length - 1]).height ) ) / 2;
                            col.forEach(function (child) {
                                    child.y += delta;
                                }
                            )
                        }
                    )
                    return cols;
                }

                function hAlignV(cols) {
                    var prevCol = null, prevX = 0;
                    switch (_options.hAlign) {
                        case 'LEFT' :
                            cols.forEach(function (col) {
                                    if (prevCol) {
                                        prevX = prevX + prevCol.colWidth + _options.gap;
                                    }
                                    col.forEach(function (child) {
                                            child.x = prevX;
                                        }
                                    )
                                    prevCol = col;
                                }
                            )
                            break;
                        case 'CENTER' :
                            var totalWidth = cols.reduce(function (width, col) {
                                return width + col.colWidth + _options.gap;
                            }, -_options.gap);
                            prevX = getLayoutBounds(_clip).width / 2 - totalWidth / 2;

                            cols.forEach(function (col) {
                                    if (prevCol) {
                                        prevX = prevX + prevCol.colWidth + _options.gap;
                                    }
                                    col.forEach(function (child) {
                                            child.x = prevX;
                                        }
                                    )
                                    prevCol = col;
                                }
                            )
                            break;
                        case 'RIGHT' :
                            cols = cols.reverse();
                            prevX = getLayoutBounds(_clip).width - cols[0].colWidth;
                            cols.forEach(function (col) {
                                if (prevCol) {
                                    prevX = prevX - col.colWidth - _options.gap;
                                }
                                col.forEach(function (child) {
                                        child.x = prevX;
                                    }
                                )
                                prevCol = col;
                            })
                    }
                }

                switch (_options.vAlign) {
                    case 'TOP' :
                        hAlignV(topAlign(childs));
                        break;
                    case 'CENTER' :
                        hAlignV(centerChilds(childs));
                        break;
                    case 'BOTTOM' :
                        hAlignV(bottomAlign(childs));
                }
            }

            function getChildsByLevel(container) {
                var childs = [];
                for (var i = 0; i < container.numChildren; i++) {
                    childs.push(container.getChildAt(i));
                }
                return childs;
            }


        }
    }


})(behavior);


//- - - - - - - - - - - - - - - - - - - - - - 8 - - - - - - - - - - - - - - - - - - - - - -
//lib/cjs.ext.timeline.js
/*
 *
 * author: ingo
 */
/**
 * Extends createjs MovieClip with method toggle to switch the timeline play and stop
 *
 */
createjs.MovieClip.prototype.toggle = function () {
    this.paused ? this.play() : this.stop();
};


/**
 * Extends createjs MovieClip with method to which makes a timeline play until label "labelName" is reached.
 * @param {string} labelName
 */
createjs.MovieClip.prototype.to = function (labelName) {
    if (this.currentLabel !== labelName && this.labels.map(function (label) {
            return label.label
        }).indexOf(labelName) > -1) {
        var onChange = function () {
            if (this.currentLabel === labelName) {
                this.stop();
                this.timeline.removeEventListener('change', onChange);
            }
        }.bind(this);
        this.timeline.addEventListener('change', onChange);
        this.play();
    }
};


/**
 * Make the timeline run backwards down to first frame and stop.
 */
createjs.MovieClip.prototype.back = function () {
    var onChange = function () {
        this.gotoAndStop(this.currentFrame - 1);
        if (this.currentFrame <= 1) {
            this.removeEventListener('tick', onChange);
            return;
        } else {
            this.gotoAndStop(this.currentFrame - 1);
        }
        ;

    }.bind(this);
    this.addEventListener('tick', onChange);
    if (this.currentFrame > 1) {
        this.gotoAndStop(this.currentFrame - 1);
    }
};

/**
 * Jump to labelName and make timeline run backwards until first frame is reached
 * @param labelName
 */
createjs.MovieClip.prototype.gotoAndBack = function (labelName) {
    this.gotoAndStop(labelName);
    this.back();
};

/**
 * return Array of Labels which contain 'step' in their label-name
 * @returns {Array.<T>|*}
 */
createjs.MovieClip.prototype.stepLabels = function () {
    return this.labels.filter(function (label) {
        return label.label.indexOf('step') > -1;
    });
};

/**
 * return positon of first stepLabel with higher position as currentFrame or MovieClip duration
 * @returns {number}
 */
createjs.MovieClip.prototype.nextStepPosition = function () {
    var steps = this.stepLabels();
    for (var i = 0; i < steps.length; i++) {
        if (steps[i].position > this.currentFrame) {
            return steps[i].position;
        }
    }
    return this.duration - 1;
};

/**
 * return positon of first stepLabel with lower position as currentFrame or 0 (firstframe)
 * @returns {number}
 */
createjs.MovieClip.prototype.prevStepPosition = function () {
    var steps = this.stepLabels();
    for (var i = steps.length - 1; i >= 0; i--) {
        if (steps[i].position <= this.currentFrame) { //statt <
            if( i-1 < 0 ) return 0;
            return steps[i-1].position;
        }
    }
    return 0;
};

/**
 * gotoAndPlay to the next Label with 'step' in its name or end of movieclip
 */
createjs.MovieClip.prototype.playNextStepLabel = function () {
    this.gotoAndPlay(this.nextStepPosition());
};

/**
 * gotoAndStop to the next Label with 'step' in its name or end of movieclip
 */
createjs.MovieClip.prototype.stopNextStepLabel = function () {
    this.gotoAndStop(this.nextStepPosition());
};

/**
 * gotoAndPlay to the previous Label with 'step' in its name or firstframe
 */
createjs.MovieClip.prototype.playPrevStepLabel = function () {
    this.gotoAndPlay(this.prevStepPosition());
};

/**
 * gotoAndStop to the previous Label with 'step' in its name or firstframe
 */
createjs.MovieClip.prototype.stopPrevStepLabel = function () {
    this.gotoAndStop(this.prevStepPosition());
};




//- - - - - - - - - - - - - - - - - - - - - - 9 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/utils/fontloader/FontLoader.js
/*
author: tilo hauke 2016
*/
var FontLoader = Class.extend(function() {
    var _onDone;
    var _cssPath;
    var _fontPath;

    this.constructor = function(onDone) {
       //onDone();return;
      _onDone = onDone;
      var fontlink = document.getElementById('fonts');
      if(fontlink) {
        _cssPath = fontlink.getAttribute('href');
        _fontPath = _cssPath.replace(/[^\/]+$/,'');
        loadCss();
      } else {
          // no fonts to load
         _onDone();
      }
    };

    function loadCss(){
        var loader = new createjs.LoadQueue(true);
        loader.on("complete", onCssComplete);
        loader.loadFile({id:"css", src:_cssPath, type:"text"});
    }

    function onCssComplete(e){
        var css = this.getResult('css');
        if(css){
            loadFonts(scanCssFileNames(css))
        } else {
            _onDone();
        }
    }

    function loadFonts(list){
        if(list.length){
            var loader = new createjs.LoadQueue(true);
            var manifest=[]
            list.forEach(function (url){
                manifest.push({id:url, src:_fontPath+url})
            })
            loader.on("complete", onFontsComplete);
            loader.loadManifest(manifest);
        } else {
            _onDone();
        }
    }

    function onFontsComplete(e){
       _onDone();
    }

    function scanCssFileNames(css){
        var fileNameList = [];
        var urls = css.match(/url*\([^)]+\)/g);
        if(urls){
            urls.forEach(function(url){
                var fileName = url.match(/"[^?#"]+/).toString().replace(/"/g,'');
                if(fileNameList.indexOf(fileName)== -1) fileNameList.push(fileName);
            });
        }
        return fileNameList;
    }

});

//- - - - - - - - - - - - - - - - - - - - - - 10 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/utils/event/EventDispatcher.js
/**
 * Created by tnguyen on 18.04.2016.
 */
var EventDispatcher = Class.extend(function(){
    var _eventDict = {};

    this.dispatchEvent = function(type,data){
        if(_eventDict[type]){
            _eventDict[type](data);
        }
    };

    this.addEvent = function(type,callBack){
        _eventDict[type] = callBack;
    };

    this.removeEvent = function(type){
        if(_eventDict[type]){
            delete _eventDict[type];
        }
    };

    this.hasEvent = function(type){
        if(_eventDict[type]){
            return true;
        }
        return false;
    }
});



//- - - - - - - - - - - - - - - - - - - - - - 11 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/utils/classmanager/ClassLoader.js
/**
 * Created by tnguyen on 18.04.2016.
 */
var ClassLoader = EventDispatcher.extend(function(){
    var _data;
    var pub = this;

    this.load = function(obj){
        _data = obj;
        if(_data.path.match(/^de\/fkc\//)){
            _data.path= Main.SYS_PATH+_data.path;
        }

        var type = getType(obj.path);
        obj.type = type;
        switch(type){
            case "js":
                loadJs();
                break;
            case "xml":
                loadXML();
                break;
            case "jpg":
            case "jpeg":
            case "png":
            case "gif":
            case "mp3":
            case "mp4":
                loadFile();
                break;
        }
    };

    function loadJs(){
        var className =_data.path.replace(/\.js$/,"").match(/\w+$/);
        //do not load an already exsiting class:
        if(className && window[className.toString()]){
             if(!_data.name)_data.name = className.toString();
             pub.dispatchEvent("COMPLETE",{data:_data, name:_data.name});
             return;
        }
        var node = document.createElement('script');
        node.setAttribute('type','text/javascript');
        node.setAttribute('src', _data.path);
        node.onerror = onError;
        node.onload = onComplete;
        document.getElementsByTagName('head')[0].appendChild(node);
    }


    function loadXML(){
        var connect = new XMLHttpRequest();
        connect.open("GET",_data.path);
        connect.setRequestHeader("Content-Type","text/xml");
        connect.onerror = onError;
        connect.onload = onComplete;
        connect.send();
    }

    function loadFile(){
        var loader = new createjs.LoadQueue(true);
        loader.on("error", onError);
        loader.on("fileload", onComplete);
        loader.loadFile({ src:_data.path, type:"text"});
    }

    function getType(path){
        var firstIndex;
        var lastIndex = path.lastIndexOf(".");
        return path.substr(lastIndex+1);
    }

    function onError(e){
        if(!_data.name){
            _data.name = ClassManager.getNameByPath(_data.path);
        }
        e.name = _data.name;
        e.data = _data;
        pub.dispatchEvent("ERROR",e);
    }

    function onComplete(e){
        if(!_data.name){
            _data.name = ClassManager.getNameByPath(_data.path);
        }
        e.name = _data.name;
        e.data = _data;
        switch(_data.type){
            case "js":
                pub.dispatchEvent("COMPLETE",e);
                break;
            case "xml":
                if(e.currentTarget.responseXML){
                    _data.data = e.currentTarget.responseXML.childNodes[0];
                    pub.dispatchEvent("COMPLETE",e);
                }
                else{
                    pub.dispatchEvent("ERROR",e);
                }
                break;
            case "jpg":
            case "jpeg":
            case "png":
            case "gif":
            case "mp3":
            case "mp4":
                if(e.item){
                    _data.data = e.item;
                    pub.dispatchEvent("COMPLETE",e);
                }
                break;
        }
    }
});

//- - - - - - - - - - - - - - - - - - - - - - 12 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/utils/classmanager/ClassListLoader.js
/**
 * Created by tnguyen on 18.04.2016.
 */
var ClassListLoader = Class.extend(function(){
    var _listCnt;
    var _classList;
    var _classLoaderList;
    var _classLoaderListenerList;
    var _name;
    var _classLoader;
    var _ignoreError = true;

    this.constructor = function(name){
        _listCnt = 0;
        _classLoaderList = [];
        _classLoaderListenerList = [];
        _name = name;
    };

    this.loadList = function(classList,ignoreError){
        _classList = classList;
        _ignoreError = (ignoreError == undefined)?true:false;
        loadClass();
    };

    function loadClass(){
        if(_listCnt < _classList.length){
            var classLoader = _classLoaderList[_listCnt];
            var classPath;
            classPath = _classList[_listCnt].path;
            if(classLoader && classLoader.path == classPath){
                _listCnt++;
                loadClass();
            }
            else{
                _classLoader = new ClassLoader();

                _classLoader.addEvent("COMPLETE",onComplete);
                _classLoader.addEvent("ERROR",onError);
                _classLoaderListenerList[_listCnt] = _classLoader;
                _classLoader.load(_classList[_listCnt]);

            }
        }
        else{
            //var event = new CustomEvent("COMPLETE_LIST");
            var event = new createjs.Event("COMPLETE_LIST");
            event.name = _name;
            ClassManager.checkCompleteList(event);
        }
    }

    function onComplete(e){
        _classLoaderList[_listCnt] = _classLoader;
        _listCnt++;
        _classLoader = null;
        e.listName = _name;
        //console.log(e)
        ClassManager.checkComplete(e);
        loadClass();
    }

    function onError(e){
        e.listName = _name;
        ClassManager.checkError(e);
        if(_ignoreError){
            _listCnt++;
            loadClass();
        }
    }

});

//- - - - - - - - - - - - - - - - - - - - - - 13 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/utils/classmanager/ClassManager.js
/**
 * Created by tnguyen on 18.04.2016.
 */
var ClassManager = Class.extend(function(){

});

ClassManager._addCompleteList = [];
ClassManager._addCompleteSequenceList = [];
ClassManager._addCompleteListList = [];
ClassManager._addErrorList = [];
ClassManager._addErrorListList = [];

ClassManager.load = function(path,name){
    ClassManager.loadList([{path:path,name:name}]);
};

ClassManager.loadList = function(list,name,ignoreError){
    var classListLoader = new ClassListLoader(name);
    classListLoader.loadList(list,ignoreError);
};

ClassManager.addComplete = function(name,callback){
    ClassManager._addCompleteList[name] = callback;
};

ClassManager.addCompleteSequence = function(name,callback){
    ClassManager._addCompleteSequenceList[name] = callback;
};

ClassManager.addCompleteList = function(name,callback){
    ClassManager._addCompleteListList[name] = callback;
};

ClassManager.addError = function(name,callback){
    ClassManager._addErrorList[name] = callback;
};

ClassManager.addErrorList = function(name,callback){
    ClassManager._addErrorListList[name] = callback;
};

ClassManager.checkError = function(e){
    if(ClassManager._addErrorList[e.name]){
        ClassManager._addErrorList[e.name](e);
    }
    if(e.listName && ClassManager._addErrorListList[e.listName]){
        ClassManager._addErrorListList[e.listName](e);
    }
};

ClassManager.checkComplete = function(e){
    if(ClassManager._addCompleteList[e.name]){
        ClassManager._addCompleteList[e.name](e);
    }
    if(e.listName && ClassManager._addCompleteSequenceList[e.listName]){
        ClassManager._addCompleteSequenceList[e.listName](e);
    }
};

ClassManager.checkCompleteList = function(e){
    if(ClassManager._addCompleteListList[e.name]){
        ClassManager._addCompleteListList[e.name](e);
    }
};

ClassManager.getNameByPath = function(path){
    if(path){
        var firstIndex;
        var lastIndex = path.lastIndexOf(".");
        if(path.lastIndexOf("/") > -1){
            firstIndex = path.lastIndexOf("/")+1;
        }
        else{
            firstIndex = 0;
        }
        return path.slice(firstIndex,lastIndex);
    }
};






//- - - - - - - - - - - - - - - - - - - - - - 14 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/utils/soundmanager/porschee3/SoundManager.js
/**
 * author: tilo hauke 01/2017 v2.
 */
var SoundManager = (function () {
    var _instance;
    function createInstance() {

        var _soundDict = {};
        var _currentSound;
        var _prevSound;
        var _audio;
        var _paused= true;
        var _instance = new Object("Instance");
        _audio = window['globalAudio'];
        if(!_audio) {
            _audio = new Audio();
        }

      /*  if(_audio.muted){
            if( window.AUDIO_WARNING ){
               setTimeout(function() { parent.alert(window.AUDIO_WARNING); }, 10);
            }
        }*/

        _audio.autoplay = false;
        _audio.addEventListener('ended', onEvent);
        _audio.addEventListener('error', onEvent);
        _audio.addEventListener('playing', onEvent);
        _audio.addEventListener('waiting', onEvent);
        _audio.addEventListener('canplay', onEvent);

        function logEvent(e){
            return; // mute
            var sound = _currentSound?_currentSound:_prevSound;
            if(sound) {
                console.log('~', e.type, sound.name);
            } else {
                console.log('~', e.type);
            }
        }

        function logFunction(txt){
            //console.log('♫ ', txt);
        }

        function onEvent(e){
            if(!_currentSound) return;
            logEvent(e);
            switch (e.type){
                case "ended":
                     completeCurrent();
                    break;
                case "error":
                    _currentSound.errors++;
                     completeCurrent();
                    break;
                case "canplay":
                    if(_paused) {
                        _audio.pause();
                    } else {
                        tryCurrentSoundEvent("onCanplay");
                    }
                    break;
                case "waiting":
                    if(_audio.muted){
                        completeCurrent();
                    }
                    tryCurrentSoundEvent("onWaiting");
                    break;
            }
        }

        function tryCurrentSoundEvent(on, sound){
            if(!sound) sound = _currentSound;
            if(sound && sound[on]){
                sound[on](sound.name);
            }
        }

        _instance.register = function(name,src){
            if(!_soundDict[name]){
                logFunction('* register '+name)
                _soundDict[name] = {
                    name:name,
                    isPlayedComplete: false,
                    src: src,
                    errors:0
                }
            }
        };

        _instance.addComplete = function (name,listener){
            if(_soundDict[name]){
                logFunction('addComplete', name)
                _soundDict[name].onComplete = listener;
            }
        };

        _instance.removeComplete = function(name){
            if(_soundDict[name]){
                 logFunction('removeComplete '+name)
                _soundDict[name].onComplete = null;
            }
        };

        _instance.addCanplay = function (name,listener){
            if(_soundDict[name]){
                _soundDict[name].onCanplay = listener;
            }
        };

        _instance.addWaiting = function (name,listener){
            if(_soundDict[name]){
                _soundDict[name].onWaiting = listener;
            }
        };

        _instance.removeListners = function(name, caller){

            if(_soundDict[name]){
                logFunction('removeListners '+name+' '+(caller||'#'))
                _soundDict[name]['onComplete'] = null;
                _soundDict[name]['onCanplay'] = null;
                _soundDict[name]['onWaiting'] = null;
            }
        };

        _instance.removeAllListeners = function (){
            for(var name in _soundDict){
                this.removeListners(name,'s');
            }
        };

        function  completeCurrent(){
            if(_currentSound){
                logFunction('completeCurrent '+_currentSound.name);
                _currentSound.isPlayedComplete = true;
                _audio.pause();
                var sound = _currentSound;
                _currentSound = null;
                tryCurrentSoundEvent('onComplete',sound);
            }
        }

        _instance.play = function (name){
            logFunction('play '+name);
            completeCurrent();
            _paused = false;
            if(_soundDict[name]) {
                _currentSound = _soundDict[name];
                if (_currentSound.errors < SoundManager.MAX_LOAD_TRIALS) {
                    _audio.src = _currentSound.src;
                    _audio.play();
                } else  completeCurrent();
            }
        };

        _instance.resume = function (name){

            var sound = _soundDict[name];
            if(sound == _currentSound && _audio.paused){
                 logFunction('resume '+name)
                _paused = false;
                _audio.play();
            }
        };

        _instance.pause = function (name){

            if(_currentSound && _soundDict[name] == _currentSound  && !_audio.paused){
                logFunction('pause '+name);
                _prevSound = _currentSound;
                _paused = true;
                _audio.pause();
            }
        };

        _instance.stop = function (name){
            if(_soundDict[name]){
                if(_soundDict[name] == _currentSound){
                    logFunction('stop '+name)
                    _instance.pause(name);
                    completeCurrent();
                }
            }
        };

        _instance.resumeAll = function (){
           if(_currentSound && _audio.paused){
               logFunction('resumeAll')
               _paused = false;
               _audio.play();
           }
        };


        _instance.pauseAll = function(){
            if(_currentSound && !_audio.paused) {
                logFunction('pauseAll')
                _paused = true;
                _audio.pause();
            }
        };

        _instance.stopAll = function (){
             logFunction('stopAll')
            for(var key in _soundDict) _instance.stop(key);
        };

        _instance.setVolume = function(value){
            _audio.volume = value;
        };

        _instance.getVolume = function(){
            return _audio.volume;
        };

        _instance.isSoundPlaying = function (name){
            if(_currentSound == _soundDict[name]){
                return !(_audio.paused || _audio.ended);
            }
            return false;
        };

        _instance.isSoundPlayedComplete = function (name){
            if(_soundDict[name]){
                return _soundDict[name].isPlayedComplete;
            }
            return true;
        };

        _instance.removeAllSounds = function(){
             logFunction('removeAllSounds')
             _instance.stopAll();
            _currentSound = null;
            _soundDict = {};
        };

        _instance.removeAllComplete = function (){
            for(var key in _soundDict){
                _soundDict[key].onComplete = null;
            }
        };

        _instance.soundExists = function(name){
            logFunction('soundExists ' + name)
            return _soundDict[name] != null;
        };

        return _instance;
    }

    return {
        getInstance: function () {
            if (!_instance) {
                _instance = createInstance();
            }
            return _instance;
        }
    };

})();

SoundManager.MAX_LOAD_TRIALS = 1;



//- - - - - - - - - - - - - - - - - - - - - - 15 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/utils/objectservice/ObjectService.js
/**
 * Created by tnguyen on 18.03.2016.
 */

/**
 * ObjectService provides helper methods to find and handle DisplayObjects.
 * @constructor
 */

function ObjectService(){
}


ObjectService.getObjectFromClip = function(clip,callBack,type,name,namePartly){
    var clipType = ObjectService.getType(clip);
    if(clipType == type){
        if(name){
            if(name == clip.name){
                callBack(clip);
            }
            else if(namePartly && clip.name && clip.name.indexOf(name) != -1){
                callBack(clip);
            }
            else{
                if(ObjectService.getType(clip) == "MovieClip"){
                    var length = clip.getNumChildren();
                    for(var i=0;i<length;i++){
                        if(i < clip.getNumChildren()){
                            ObjectService.getObjectFromClip(clip.getChildAt(i),callBack,type,name,namePartly);
                        }
                    }
                }
            }
        }
        else{
            if(name == null || name == undefined){
                if(ObjectService.getType(clip) == "MovieClip"){
                    var length = clip.getNumChildren();
                    for(var i=0;i<length;i++){
                        if(i < clip.getNumChildren()){
                            if(ObjectService.getType(clip.getChildAt(i)) == type){
                                callBack(clip.getChildAt(i));
                            }
                            ObjectService.getObjectFromClip(clip.getChildAt(i),callBack,type,name,namePartly);
                        }
                    }
                }
                else{
                    if(type == type){
                        callBack(clip);
                    }
                }
            }
        }
    }
    else if(clipType == "MovieClip" || clipType == "Stage"){
        var length_ = clip.getNumChildren();
        for(var j=0;j<length_;j++){
            ObjectService.getObjectFromClip(clip.getChildAt(j),callBack,type,name,namePartly);
        }
    }
};

/**
 * Find all children of clip with name matching regExp
 * @param clip
 * @param regExp
 * @param callBack
 * @param type
 * @param recursive
 * @returns {Array}
 */
ObjectService.getObjectFromClipByRegExp = function(clip, regExp, callBack, type, recursive) {
    var basket = [];
    if(recursive == undefined){
        recursive = true;
    }
    for(var i=0; i<clip.numChildren; i++) {
        var item = clip.getChildAt(i);
        if(item && item.name && item.name.match(regExp)){
            if (type == null || ObjectService.getType(item) == type) {
                if(callBack !== null) callBack(item);
                basket.push(item);
            }
        }
        var itemType = ObjectService.getType(item);
        if(recursive && item && (itemType == "MovieClip" || itemType == "Stage")) basket = basket.concat(ObjectService.getObjectFromClipByRegExp(item,regExp,callBack,type,recursive));
    }
    return basket;
};
/**
 *
 * @param {object} obj - The object to get the type from
 * @returns {string} - Type of obj
 */
ObjectService.getType = function(obj){
    var name = obj.toString();
    var list = name.split(" ");
    return list[0].substr(1);
};

ObjectService.setObjectProperty = function(obj,property,value){
    if(obj && obj.hasOwnProperty(property)){
        obj[property] = value;
    }
};

//- - - - - - - - - - - - - - - - - - - - - - 16 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/utils/checkmanager/CheckManager.js
/**
 * Created by tnguyen on 23.03.2016.
 */
var CheckManager = function(){

};

CheckManager.tweenToFrame = function(clip,frame,time,onComplete,parameter){
    if(clip.currentFrame != frame && frame <= clip.totalFrames){
        if(!time){
            time = CheckManager.getTimeByFrames(clip.currentFrame,frame);
        }

        var obj = {frame:clip.currentFrame, client:clip};

        function onUpdate(){
            var targetFrame = Math.round(obj.frame);
            clip.gotoAndStop(targetFrame);
        }

        function removeTween(){
            for (var i=0; i <Tweener.twns.length; i++){
                var tween = Tweener.twns[i];
                if(tween.obj.client == clip && tween.prms.indexOf('frame')!= -1) {
                    Tweener.twns.splice(i,1);
                    return;
                }
            }
        }

        removeTween();
        Tweener.addTween(obj, {frame:frame, time:time,onComplete:onComplete, onCompleteParams:[parameter],transition:"easeNone",onUpdate:onUpdate});
    }
};






CheckManager.getTimeByFrames = function(currentFrame, targetFrame){
    var deltaFrame = targetFrame - currentFrame;
    var time = Math.sqrt(deltaFrame*deltaFrame)/lib.properties.fps;
    return time;
};

CheckManager.getFrameByLabel = function(clip,label){
    var labels = clip.labels;
    for (var key in labels){
        if(labels[key].label == label){
            return labels[key].position;
        }
    }
    return null;
};

CheckManager.getLabelByFrame = function(clip,frame){
    var labels = clip.labels;
    for (var key in labels){
        if(labels[key].position == frame){
            return labels[key].label;
        }
    }
    return null;
};

CheckManager.getLastFrameOfLabel = function(clip,label){
    var frame;
    var labels = clip.labels;
    var length = labels.length;

    for(var i=0;i<length;i++){
        if(labels[i].label == label){
            if(i < length-1){
                //console.log("found label: "+labels[i].label,labels[i+1].position);
                frame = labels[i+1].position-1;
            }
            else{
                frame = clip.totalFrames-1;
            }
        }
    }
    return frame;
};

CheckManager.checkAmount = function(list,amount){
    var cnt=0;
    for(var key in list){
        cnt++;
    }
    if(cnt == amount){
        return true;
    }
    return false;
};

CheckManager.getAmount = function(list){
    var cnt=0;
    for(var key in list){
        cnt++;
    }
    return cnt;
};

CheckManager.shuffleList = function(list){
    var n = list.length;
    while (n > 1) {
        var r = Math.floor(Math.random()*(n));
        n--;
        var tmp = list[r];
        list[r] = list[n];
        list[n] = tmp;
    }
    return list;
};

CheckManager.getLocalPoint = function(display,display2){
    var globalPoint = display.parent.localToGlobal(display.x,display.y);
    var point = display2.parent.globalToLocal(globalPoint.x,globalPoint.y);
    return point;
};

/**
 * Set the position of the displayObject depending of columns and rows
 * optional:offsetX
 * optional:offsetY
 */
CheckManager.setGridAlign = function(list,column,row,offsetX,offsetY,startPosX,startPosY){
    offsetX = (offsetX == undefined)?0:offsetX;
    offsetY = (offsetY == undefined)?0:offsetY;
    var length = list.length;
    var columnCnt = 0;
    var posX = (startPosX == undefined)?0:startPosX;
    var posY = (startPosY == undefined)?0:startPosY;
    var maxHeight = 0;
    for(var i=0;i<length;i++){

        var clip = list[i];
        clip.x = posX;
        clip.y = posY;
        if(maxHeight < clip.nominalBounds.height){
            maxHeight = clip.nominalBounds.height;
        }
        columnCnt++;
        posX += clip.nominalBounds.width + offsetX;

        if(columnCnt%column == 0){
            columnCnt = 0;
            posX = (startPosX == undefined)?0:startPosX;
            posY += maxHeight + offsetY;
            maxHeight = 0;
        }
    }
};

CheckManager.setAutoGridAlign = function(list,width,height){
    var length = list.length;
    for(var i=0;i<length;i++){
        var clip = list[i];
        var row = Math.ceil(Math.sqrt(length));
        var column = (parseInt(Math.sqrt(length))*row) < length?parseInt(Math.sqrt(length))+1:parseInt(Math.sqrt(length));
        var offsetX = (width -(row*clip.nominalBounds.width))/row;
        var offsetY = (height - (column*clip.nominalBounds.height))/column;

        clip.x = ((i%row)*clip.nominalBounds.width+(i%row)*offsetX);
        clip.y = parseInt(i/row)*clip.nominalBounds.height + parseInt(i/row)*offsetY;
    }
};

/**
 * scale comp proportional until it fill completely the target size. Comp could be sliced.
 * comp.startWidth and comp.startHeight have to be set before call the scaleFull function.
 * example: comp.startWidth = comp.nominalBounds.width, comp.startHeight = comp.nominalBounds.height
 * @param comp
 * @param targetWidth
 * @param targetHeight
 */
CheckManager.scaleFull = function(comp,targetWidth,targetHeight){
    var screenRatio = targetWidth/targetHeight;
    var compRatio = comp.startWidth/ comp.startHeight;
    if(screenRatio > compRatio){
        var ratioX = targetWidth/comp.startWidth;
        comp.scaleX = ratioX;
        comp.scaleY = ratioX;
        comp.nominalBounds.width = comp.startWidth*ratioX;
        comp.nominalBounds.height = comp.startHeight*ratioX;
    }
    else{
        var ratioY = targetHeight/comp.startHeight;
        comp.scaleX = ratioY;
        comp.scaleY = ratioY;
        comp.nominalBounds.width = comp.startWidth*ratioY;
        comp.nominalBounds.height = comp.startHeight*ratioY;
    }
    comp.x = targetWidth/2 - comp.nominalBounds.width/2;
    comp.y = targetHeight/2 - comp.nominalBounds.height/2;
};

/**
 * scale comp proportionally until it fit completely the target size. Comp will be seen completely
 * @param comp
 * @param targetWidth
 * @param targetHeight
 */
CheckManager.scaleFit = function(comp,targetWidth,targetHeight){
    var screenRatio = targetWidth/targetHeight;
    var compRatio = comp.startWidth/ comp.startHeight;
    if(screenRatio < compRatio){
        var ratioX = targetWidth/comp.startWidth;
        comp.scaleX = ratioX;
        comp.scaleY = ratioX;
        comp.nominalBounds.width = comp.startWidth*ratioX;
        comp.nominalBounds.height = comp.startHeight*ratioX;
    }
    else{
        var ratioY = targetHeight/comp.startHeight;
        comp.scaleX = ratioY;
        comp.scaleY = ratioY;
        comp.nominalBounds.width = comp.startWidth*ratioY;
        comp.nominalBounds.height = comp.startHeight*ratioY;
    }
    comp.x = targetWidth/2 - comp.nominalBounds.width/2;
    comp.y = targetHeight/2 - comp.nominalBounds.height/2;
};

/**
 * stretch comp until it fit comletely
 * startWidth and startHeight of comp have to been set before hand over as parameter
 * @param comp
 * @param targetWidth
 * @param targetHeight
 */
CheckManager.scaleStretch = function(comp,targetWidth,targetHeight){
    var ratioX = targetWidth/comp.startWidth;
    var ratioY = targetHeight/comp.startHeight;
    comp.scaleX = ratioX;
    comp.scaleY = ratioY;
    comp.nominalBounds.width = comp.startWidth*ratioX;
    comp.nominalBounds.height = comp.startHeight*ratioY;
    comp.x = targetWidth/2 - comp.nominalBounds.width/2;
    comp.y = targetHeight/2 - comp.nominalBounds.height/2;
};

CheckManager.sortListByProperty = function(list,property){
    list.sort(function(a,b){
        if (a[property] < b[property])
            return -1;
        if (a[property] > b[property])
            return 1;
        return 0;
    });
};

CheckManager.isMobile = function(){
    var mobiles = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i;
    var mobileUserAgent = navigator.userAgent.match(mobiles);
    //Check if we use Safari-Browser
    var safari = /Apple/i;
    var safariUserAgent = navigator.vendor.match(safari);
    var chromeUserAgent = navigator.vendor.match(/google/i);
    return (safariUserAgent || mobileUserAgent || chromeUserAgent);
};


CheckManager.getRoot = function(clip){
    if(clip.name == "root"){
        return clip;
    }
    else if(clip.parent){
        return CheckManager.getRoot(clip.parent);
    }
    else{
        return null;
    }
};


//- - - - - - - - - - - - - - - - - - - - - - 17 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/main/simple/AssetManager.js
/**
 * @class
 * @classdesc Provides a service to load assets and invoke callbacks.
 *
 * Usage: Add listeners "ASSET_READY" or "COMPLETE" to AssetManager before calling loadAssets(list)
 *
 */
var AssetManager = EventDispatcher.extend(function(){
    var _list;
    var _assetList;
    var _assetDict;
    var _assetCnt;
    var pub = this;

    this.constructor = function(){
        _assetCnt = 0;
        _assetDict = {};
    };

    /**
     * Load Assets contained in list array and store them in an internal repository.
     * @param {array} list - a list of asset files
     */
    this.loadAssets = function(list){
        _list = list;
        _assetList = [];
        ClassManager.addCompleteSequence("assetList",onAssetCompleteSequence);
        ClassManager.addCompleteList("assetList",onAssetCompleteList);
        ClassManager.loadList(_list,"assetList");
    };

    /**
     * Retrieve an Asset by its name.
     * @param {string} name
     * @returns {*}
     */
    this.getAssetByName = function(name){
        for(var i=0;i<_assetList.length;i++){
            if(_assetList[i].name == name){
                return _assetList[i];
            }
        }
        return ;
    };

    /**
     * Add ab asset to the internal asset repository
     * @param {string} name
     * @param {object} data
     */
    this.addAssetByName = function(name,data){
        for(var i=0;i<_assetList.length;i++){
            if(_assetList[i].name == name){
                _assetList[i].data = data;
            }
        }
    }

    /**
     * @property {Array}
     * @name AssetManager#assetList
     */
    Object.defineProperty(this,"assetList",{
        get: function(){
            return _assetList;
        }
    });

    var  onAssetCompleteSequence = function (e){
        var asset = e.data;
        _assetList.push(asset);
        if(e.data.instant == true){
            pub.dispatchEvent("ASSET_READY",asset);
        }
    }

    var onAssetCompleteList =  function (){
        pub.dispatchEvent("COMPLETE");
    }


});

//- - - - - - - - - - - - - - - - - - - - - - 18 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/simplemvc/Facade.js
/**
 * Created by tnguyen on 25.04.2016.
 */
var Facade = Class.extend(function(){
    this._instance;
    var pub=this;
    var _commandDict;
    var _mediatorDict;
    var _proxyDict;

    function createInstance() {
        var instance = new Facade("Instance");
        return instance;
    }

    this.constructor = function(){
        _commandDict = {};
        _mediatorDict = {};
        _proxyDict = {};
    };

    this.registerProxy = function(name,proxy){
        _proxyDict[name] = proxy;
    };

    this.registerMediator = function(name,mediator){
        _mediatorDict[name] = mediator;
    };

    this.registerCommand = function(name,commandClass){
        _commandDict[name] = {class:commandClass,instance:undefined};
    };

    this.removeMediator = function(name){
        if(_mediatorDict[name]){
            delete _mediatorDict[name];
        }
    };

    this.retrieveProxy = function(name){
        if(_proxyDict[name]){
            return _proxyDict[name];
        }
        return null;
    };

    this.retrieveMediator = function(name){
        if(_mediatorDict[name]){
            return _mediatorDict[name];
        }
        return null;
    };

    this.sendNotification = function(name,body,type,callback,data){
        var notification = new Notification(name,body,type,callback,data);
        sendCommand(notification);
        sendMediator(notification);
    };

    function sendCommand(notification){
        var name = notification.getName();
        if(_commandDict[name]){
            if(_commandDict[name].instance){
                _commandDict[name].instance.execute(notification);
            }
            else{
                var instance = new _commandDict[name].class();
                _commandDict[name].instance = instance;
                _commandDict[name].instance.execute(notification);
            }
        }

    }

    function sendMediator(notification){
        var name = notification.getName();
        for(var key in _mediatorDict){
            var mediator = _mediatorDict[key];
            if(mediator.listNotifications().indexOf(name) != -1){
                mediator.handleNotification(notification);
            }
        }
    }

    this.startup = function(config){
        this.registerCommand("startup",StartupCommand);
        this.sendNotification("startup",config);
    };


    return {
        getInstance: function () {
            if (!_instance) {
                _instance = createInstance();
            }
            return _instance;
        }
    };
});

Facade.getInstance = function(){
    if (!Facade._instance) {
        Facade._instance = new Facade();
    }
    return Facade._instance;
};

//- - - - - - - - - - - - - - - - - - - - - - 19 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/simplemvc/Proxy.js
/**
 * Created by tnguyen on 25.04.2016.
 */
var Proxy = EventDispatcher.extend(function(){
    var pub = this;
    var _data;

    this.constructor = function(data){
        _data = data;
    };

    this.setData = function(data){
        _data = data;
    };

    this.getData = function(){
        return _data;
    };

    this.sendNotification = function(name,body,type,callback){
        Facade.getInstance().sendNotification(name,body,type,callback);
    };

});

//- - - - - - - - - - - - - - - - - - - - - - 20 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/simplemvc/Mediator.js
/**
 * Created by tnguyen on 25.04.2016.
 */
var Mediator = EventDispatcher.extend(function(){
    var _viewComponent;
    var _name;
    this.constructor = function(viewComponent){
        _viewComponent = viewComponent;
    };

    this.listNotifications = function(){
        return [];
    };

    this.handleNotification = function(notification){

    };

    this.sendNotification = function(name,body,type,callback){
        Facade.getInstance().sendNotification(name,body,type,callback);
    };

    this.setViewComponent = function(viewComponent){
        _viewComponent = viewComponent;
    };

    this.getViewComponent = function(){
        return _viewComponent;
    }

    Object.defineProperty(this,"name",{
        get: function(){
            return _name;
        },
        set: function(value){
            _name = value;
        }
    });
});

//- - - - - - - - - - - - - - - - - - - - - - 21 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/simplemvc/Command.js
/**
 * Created by tnguyen on 25.04.2016.
 */
var Command = EventDispatcher.extend(function(){
    var pub = this;
    var _commandList;
    var _notificationCnt;
    var _notification;

    this.constructor = function(){
        this._commandList = [];
    };

    this.execute = function(notification){
        _notification = notification;
    };

    this.executeNotificationList = function(notificationList,callback){
        var cnt = 0;
        executeNotification(notificationList,cnt,callback);
    };

    function executeNotification(notificationList,cnt,callback){
        if(cnt < notificationList.length){
            var notification = notificationList[cnt];
            cnt++;
            Facade.getInstance().sendNotification(notification.name,notification.body,notification.type,executeComplete,{notificationList:notificationList,cnt:cnt,callback:callback});
        }
        else{
            if(callback){
                callback();
            }
        }
    }

    function executeComplete(data){
        executeNotification(data.notificationList,data.cnt,data.callback);
    }

    this.sendNotification = function(name,body,type,callback,data){
        Facade.getInstance().sendNotification(name,body,type,callback,data);
    };

    this.complete = function(){
        if(_notification.getCallback()){
            _notification.getCallback()(_notification.getData());
        }
    }
});

//- - - - - - - - - - - - - - - - - - - - - - 22 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/simplemvc/Notification.js
/**
 * Created by tnguyen on 25.04.2016.
 */
var Notification = Class.extend(function(){
    var _name;
    var _body;
    var _type;
    var _callback;
    var _data;

    this.constructor = function(name,body,type,callback,data){
        _name = name;
        _body = body;
        _type = type;
        _callback = callback;
        _data = data;
    };

    this.getName = function(){
        return _name;
    };

    this.getBody = function(){
        return _body;
    };

    this.getType = function(){
        return _type;
    };

    this.getCallback = function(){
        return _callback;
    };

    this.getData = function(){
        return _data;
    };
});

//- - - - - - - - - - - - - - - - - - - - - - 23 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/command/simple/StartupCommand.js
/**
 * Created by tnguyen on 25.04.2016.
 */
var StartupCommand = Command.extend(function(){
    var pub = this;
    var _config;

    this.execute = function(notification){
        pub._config = notification.getBody();
        loadClass(pub._config.sysDict,null,onCompleteSysList);
    };

    function onCompleteSysList(e){
        loadClass(pub._config.commandDict,onCompleteCommandSequence,onCompleteCommandList);
    }

    function onCompleteCommandSequence(e){
        Facade.getInstance().registerCommand(e.data.id,window[e.data.name]);
    }

    function onCompleteCommandList(e){
        var dict = {};
        for(var key in pub._config.proxyDict){
            if(typeof(pub._config.proxyDict[key]) == "string"){
                dict["StartupCommand"+key] = pub._config.proxyDict[key];
            }
            else{
                var obj = pub._config.proxyDict[key];
                dict["StartupCommand"+key+"proxy"] = obj.proxy;
                if(obj.data){
                    dict["StartupCommand"+key+"data"] = obj.data;
                }
                if(obj.params){
                    for(var i=0;i<obj.params.length;i++){
                        dict["StartupCommand"+key+"data"+"params"+i] = obj.params[i];
                    }
                }
            }
        }
        loadClass(dict,null,onCompleteProxyList);
    }

    function onCompleteProxyList(e){
        loadClass(pub._config.mediatorDict,null,onCompleteMediatorList);
    }

    function onCompleteMediatorList(e){
        loadClass(pub._config.contentDict,null,onCompleteContentList);
    }

    function onCompleteContentList(e){
        loadClass(pub._config.exerciseDict,null,onCompleteExerciseList);
    }

    function onCompleteExerciseList(e){
        pub.sendNotification("INIT_COMMAND",pub._config);
    }

    function loadClass(dict,onCompleteSequence,onCompleteList){
        var classList = [];
        for(var key in dict){
            var obj = {id:key,path:dict[key]};
            classList.push(obj);
        }
        ClassManager.addCompleteSequence("configList",onCompleteSequence);
        ClassManager.addCompleteList("configList",onCompleteList);
        ClassManager.loadList(classList,"configList");
    }
});

//- - - - - - - - - - - - - - - - - - - - - - 24 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/config/simple/Config.js
/**
 * Created by tnguyen on 14.04.2016.
 */
var Config = Class.extend(function(){
    var pub = this;
    var _stage;
    var _sysDict;
    var _proxyDict;
    var _mediatorDict;
    var _commandDict;
    var _contentDict;
    var _exerciseDict;
    var _assetManager;

    this.constructor = function(stage,assetManager){
        _stage = stage;
        _assetManager = assetManager;
        pub.init();
    };

    this.init = function(sysDict,proxyDict,mediatorDict,commandDict,contentDict,exerciseDict){
        _sysDict = sysDict || new Object();
        _proxyDict = proxyDict || new Object();
        _mediatorDict = mediatorDict || new Object();
        _commandDict = commandDict || new Object();
        _contentDict = contentDict || new Object();
        _exerciseDict = exerciseDict || new Object();
    };

    this.cleanExerciseDict = function(value){
        if(value){
            for (var key in _exerciseDict){
                if(key.toString() == value){
                    delete _exerciseDict[key];
                }
            }
        }
        else{
            var tempDict = new Object();
            var foundDict = new Object();
            for (var key2 in _exerciseDict){
                if(tempDict[key2.toString()]){
                    foundDict[key2] = true;
                }
                tempDict[key2.toString()] = true;
            }
            for (var foundKey in foundDict){
                delete _exerciseDict[foundKey];
            }
        }
    };


    Object.defineProperty(this,"stage",{
        get: function(){
            return _stage;
        }
    });

    Object.defineProperty(this,"sysDict",{
        get: function(){
            return _sysDict;
        }
    });

    Object.defineProperty(this,"proxyDict",{
        get: function(){
            return _proxyDict;
        }
    });

    Object.defineProperty(this,"mediatorDict",{
        get: function(){
            return _mediatorDict;
        }
    });

    Object.defineProperty(this,"commandDict",{
        get: function(){
            return _commandDict;
        }
    });

    Object.defineProperty(this,"contentDict",{
        get: function(){
            return _contentDict;
        }
    });

    Object.defineProperty(this,"exerciseDict",{
        get: function(){
            return _exerciseDict;
        }
    });

    Object.defineProperty(this,"assetManager",{
        get: function(){
            return _assetManager;
        }
    });

});

//- - - - - - - - - - - - - - - - - - - - - - 25 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/proxy/structure/simple/Data.js
/**
 * Created by tnguyen on 04.05.2016.
 */
var Data = EventDispatcher.extend(function() {
    var pub = this;

    var _id;
    var _name;
    var _parentData;
    var _state;
    var _lock;
    var _type;
    var _xml;
    var _num;
    var _cat;
    var _hide;

    this.getIndex = function(){
        if(_parentData){
           for(var i=0; i < _parentData.dataList.length;i++){
               if(_parentData.dataList[i] === pub) return i;
           }
        }
    }

    this.isHidden = function(){
        if (_hide == "true") return true;
        if(_parentData) return _parentData.isHidden();
        return false;
    }

    Object.defineProperty(this,"id",{
        get: function(){
            return _id;
        },
        set: function(value){
            _id = value;
        }
    });

    Object.defineProperty(this,"name",{
        get: function(){
            return _name;

        },
        set: function(value){
            _name = value;
        }
    });

    Object.defineProperty(this,"type",{
        get: function(){
            return _type;
        },
        set: function(value){
            _type = value;
        }
    });

    Object.defineProperty(this,"state",{
       get: function(){
           return _state;
       },
       set: function(value){
           if(_state != value){
               _state = value;
               pub.dispatchEvent(StructureEvent.DATA_STATE_CHANGED,{type:StructureEvent.DATA_STATE_CHANGED,data:pub});
               pub.dispatchEvent(StructureEvent.STATE_CHANGED);
           }
       }
    });

    Object.defineProperty(this,"parentData",{
        get: function(){
            return _parentData;
        },
        set: function(value){
            _parentData = value;
        }
    });

    Object.defineProperty(this,"lock",{
        get: function(){
            return _lock;
        },
        set: function(value){
            _lock = value;
        }
    });

    Object.defineProperty(this,"xml",{
        get: function(){
            return _xml;
        },
        set: function(value){
            _xml = value;
        }
    });

    Object.defineProperty(this,"num",{
        get: function(){
            if(!_num) _num = _xml.getAttribute('num')||'';
            return _num;
        }
    });

    Object.defineProperty(this,"category",{
        get: function(){
            if(!_cat) _cat = _xml.getAttribute('category')||'';
            return _cat;
        }
    });
    Object.defineProperty(this,"hide",{
        get: function(){
            if(!_hide) _hide = _xml.getAttribute('hide')||'';
            return _hide;
        }
    });

});

//- - - - - - - - - - - - - - - - - - - - - - 26 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/proxy/structure/simple/StructureEvent.js
/**
 * Created by tnguyen on 03.05.2016.
 */
var StructureEvent = Class.extend(function() {

});

StructureEvent.STATE_CHANGED = "STATE_CHANGED";
StructureEvent.DATA_STATE_CHANGED = "DATA_STATE_CHANGED";

//- - - - - - - - - - - - - - - - - - - - - - 27 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/mediator/simple/SimpleMediator.js
/**
 * Created by tnguyen on 25.04.2016.
 */
var SimpleMediator = Mediator.extend(function(){
    var pub = this;
    var _clip;
    var _config;
    var _isActivated;
    var _isLocked;
    var _onList;
    var _orList;
    var _offList;
    var _ACTIVATE_COMMAND;
    var _DEACTIVATE_COMMAND;
    var _LOCK_COMMAND;

    this.constructor = function(viewComponent){
        this.super.constructor(viewComponent);
        if(viewComponent){
            _clip = viewComponent;
            _clip.gotoAndStop(0);
        }
        _onList = [];
        _orList = [];
        _offList = [];
    };

    this.init = function(){
        if(_clip){

            _clip.visible = false;
            checkCloseBtn();
            _config = Facade.getInstance().retrieveProxy("ConfigProxy").getData();
            for(var i=0;i<_clip.numChildren;i++){
                if(ObjectService.getType(_clip.getChildAt(i)) == "MovieClip"){
                    checkWidget(_clip.getChildAt(i));
                }
            }
            _clip.cursor = "default";
        }
    };

    function checkWidget(clip){
        if(clip.name){
            for(var key in _config.exerciseDict){
                var flags = key.replace(/.*\/([gimy]*)$/, '$1');
                var pattern = key.replace(new RegExp('^/(.*?)/'+flags+'$'), '$1');
                var regex = new RegExp(pattern, flags);
                if(clip.name.match(regex)){
                    var className = ClassManager.getNameByPath(_config.exerciseDict[key]);
                    var exercise = new window[className]();
                    exercise.init(clip);
                }
            }
        }
    }

    function checkCloseBtn(){
        var closeBtn = _clip.getChildByName("closeBtn");
        if(closeBtn){
            closeBtn.addEventListener("click",pub.onCloseClick);
        }
    }

    this.onCloseClick = function(e){
        pub.sendNotification("SET_VIEW_COMMAND",ViewData.INIT);
    };


    this.listNotifications = function(){
        var list = this.super.listNotifications();
        list.push(_ACTIVATE_COMMAND);
        list.push(_DEACTIVATE_COMMAND);
        list.push(_LOCK_COMMAND);
        list.push("VIEW_CHANGED_COMMAND");
        return list;
    };

    this.handleNotification = function(notification){
        this.super.handleNotification(notification);
        switch(notification.getName()){
            case _ACTIVATE_COMMAND:
                pub.activate();
                break;
            case _DEACTIVATE_COMMAND:
                pub.deactivate();
                break;
            case _LOCK_COMMAND:
                pub.lock(Boolean(notification.getBody()));
                break;
            case "VIEW_CHANGED_COMMAND":
                pub.viewChanged(notification.getBody());
                break;
        }
    };

    this.lock = function(value){
        _isLocked = value;
        pub.clip.mouseEnabled = !value;
    };

    this.viewChanged = function(view){
        if(_onList.indexOf(view) != -1){
            pub.activate();
        }
        else{
            if(_offList.length > 0){
                if(_offList.indexOf(view) != -1){
                    pub.deactivate();
                }
                else{
                    pub.activate();
                }
            }
            else{
                if(_orList.length > 0){
                    if(_orList.indexOf(view) == -1){
                        pub.deactivate();
                    }
                }
                else{
                    if(_onList.length > 0){
                        pub.deactivate();
                    }
                }
            }
        }
    };

    this.activate = function(){
        _clip.visible = true;
        _isActivated = true;
    };

    this.deactivate = function(){
        _clip.visible = false;
        _isActivated = false;
    };

    Object.defineProperty(this,"isActivated",{
        get: function(){
            return _isActivated;
        },
        set: function(value){
            if(value) {
                pub.sendNotification(_ACTIVATE_COMMAND);
            } else {
                pub.sendNotification(_DEACTIVATE_COMMAND);
            }
        }
    });

    Object.defineProperty(this,"ACTIVATE_COMMAND",{
        get: function(){
            return _ACTIVATE_COMMAND;
        },
        set: function(value){
            _ACTIVATE_COMMAND = value;
        }
    });

    Object.defineProperty(this,"DEACTIVATE_COMMAND",{
        get: function(){
            return _DEACTIVATE_COMMAND;
        },
        set: function(value){
            _DEACTIVATE_COMMAND = value;
        }
    });

    Object.defineProperty(this,"LOCK_COMMAND",{
        get: function(){
            return _LOCK_COMMAND;
        },
        set: function(value){
            _LOCK_COMMAND = value;
        }
    });

    Object.defineProperty(this,"onList",{
        get: function(){
            return _onList;
        }
    });

    Object.defineProperty(this,"orList",{
        get: function(){
            return _orList;
        }
    });

    Object.defineProperty(this,"offList",{
        get: function(){
            return _offList;
        }
    });

    Object.defineProperty(this,"clip",{
        get: function(){
            return _clip;
        }
    });

    Object.defineProperty(this,"config",{
        get: function(){
            return _config;
        }
    });
});

//- - - - - - - - - - - - - - - - - - - - - - 28 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/mediator/simple/SimpleBtnMediator.js
/**
 * Created by tnguyen on 19.05.2016.
 */
var SimpleBtnMediator = SimpleMediator.extend(function() {
    var pub = this;
    var _ON_VIEW;
    var _OFF_VIEW;
    var _mediatorConnector;
    var _mediatorConnectorName;
    var _onName;
    var _offName;
    var _onClick;
    var _offClick;
    var _defaultClick;

    this.constructor = function(viewComponent){
        this.super.constructor(viewComponent);
    };

    this.init = function(){
        this.super.init();
        if(pub.clip){
            ObjectService.getObjectFromClip(pub.clip,getBtn,"MovieClip",_onName);
            ObjectService.getObjectFromClip(pub.clip,getBtn,"MovieClip",_offName);
            if(!_onClick && !_offClick){
                _defaultClick = new SimpleClick(pub.clip);
                _defaultClick.addEvent("click",pub.eventHandler);
            }
        }
    };

    function getBtn(clip){
        switch(clip.name){
        case _onName:
            _onClick = new SimpleClick(clip);
            _onClick.addEvent("click",pub.eventHandler);
            break;
        case _offName:
            _offClick = new SimpleClick(clip);
            _offClick.addEvent("click",pub.eventHandler);
            clip.visible = false;
            break;
        }
    }

    this.eventHandler = function(e){
        var click = e.currentTarget;
        switch(click.comp.name){
            case _onName:
                pub.sendNotification("SET_VIEW_COMMAND",_ON_VIEW);
                break;
            case _offName:
                pub.sendNotification("SET_VIEW_COMMAND",_OFF_VIEW);
                break;
            default:
                pub.sendNotification("SET_VIEW_COMMAND",_ON_VIEW);
                break;
        }
    };

    this.viewChanged = function(view){
        if(!_mediatorConnector){
            _mediatorConnector = Facade.getInstance().retrieveMediator(_mediatorConnectorName);
        }
        if(_mediatorConnector){
            if(isMediatorActivated(view)){
                if(_onClick && _offClick){_onClick.comp.visible = false;}
                if(_onClick && _offClick){_offClick.comp.visible = true;}
            }
            else{
                if(_onClick && _offClick){_onClick.comp.visible = true;}
                if(_onClick && _offClick){_offClick.comp.visible = false;}
            }
        }
        this.super.viewChanged(view);
    };

    function isMediatorActivated(view){
        if(_mediatorConnector.onList.indexOf(view) != -1){
            return true;
        }
        else{
            if(_mediatorConnector.offList.length > 0){
                if(_mediatorConnector.offList.indexOf(view) != -1){
                    return false;
                }
                else{
                    if(_mediatorConnector.isActivated){
                        return true;
                    }
                }
            }
            else{
                if(_mediatorConnector.orList.length > 0){
                    if(_mediatorConnector.orList.indexOf(view) != -1){
                        if(_mediatorConnector.isActivated){
                            return true;
                        }
                    }
                    else{
                        return false;
                    }
                }
                else{
                    return false;
                }
            }
        }
    }

    this.lock = function(value){
        pub.isLocked = value;
        if(_defaultClick){
            _defaultClick.lock = value;
        }
        else{
            if(_onClick){
                _onClick.lock = value;
            }
            if(_offClick){
                _offClick.lock = value;
            }
        }
    };


    Object.defineProperty(this,"ON_VIEW",{
        get: function(){
            return _ON_VIEW;
        },
        set: function(value){
            _ON_VIEW = value;
        }
    });

    Object.defineProperty(this,"OFF_VIEW",{
        get: function(){
            return _OFF_VIEW;
        },
        set: function(value){
            _OFF_VIEW = value;
        }
    });

    Object.defineProperty(this,"onName",{
        get: function(){
            return _onName;
        },
        set: function(value){
            _onName = value;
        }
    });

    Object.defineProperty(this,"offName",{
        get: function(){
            return _offName;
        },
        set: function(value){
            _offName = value;
        }
    });

    Object.defineProperty(this,"onClick",{
        get: function(){
            return _onClick;
        },
        set: function(value){
            _onClick = value;
        }
    });

    Object.defineProperty(this,"offClick",{
        get: function(){
            return _offClick;
        },
        set: function(value){
            _offClick = value;
        }
    });

    Object.defineProperty(this,"defaultClick",{
        get: function(){
            return _defaultClick;
        },
        set: function(value){
            _defaultClick = value;
        }
    });

    Object.defineProperty(this,"mediatorConnectorName",{
        get: function(){
            return _mediatorConnectorName;
        },
        set: function(value){
            _mediatorConnectorName = value
        }
    });

});

//- - - - - - - - - - - - - - - - - - - - - - 29 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/mediator/page/exercise/simple/SimpleExercise.js
var SimpleExercise = Class.extend(function(){

    var pub = this;

    var _exerciseResultData;
    var _lock = false;
    var _currentTry = 0;
    var _maxTry= 0;
    var _wrongList;
    var _partlyCorrectList;
    var _correctList;
    var _solutionList;
    var _solutionBtn = undefined;
    var _checkBtn = undefined;
    var _selectionBtn = undefined;
    var _correctSoundName;
    var _wrongSoundName;
    var _solutionSoundName;
    var _currentContentName;
    var _clip;
    var _input = {};

    this.init = function(clip){
        var contentPath = Facade.getInstance().retrieveProxy("StructureProxy").getData().currentPageData.contentPath;
        _currentContentName = ClassManager.getNameByPath(contentPath);
        _clip = clip;
        _clip.addEventListener("RESET", this.onReset);
        _clip.gotoAndStop(1);
        _wrongList = getList("wrong");
        _partlyCorrectList = getList("partly_correct");
        _correctList = getList("correct");
        _solutionList = getList("solution");
        ObjectService.getObjectFromClip(_clip,getCheckBtn,"MovieClip","checkBtn",true);
        ObjectService.getObjectFromClip(_clip,getSolutionBtn,"MovieClip","solutionBtn",true);
        ObjectService.getObjectFromClip(_clip,getSelectionBtn,"MovieClip","selectionBtn",true);
    };

    this.showCorrect = function(){
        this.showLabel(_correctList);
    };

    this.showPartlyCorrect = function(){
        pub.showLabel(_partlyCorrectList);
    };

    this.showWrong = function(){
        pub.showLabel(_wrongList);
    };

    this.showSolution = function(){
        _lock = true;
        pub.showLabel(_solutionList);
    };

    this.showLabel = function(list){
        if(list){
            for(var i=_currentTry;i>-1;i--){
                if(list[i]){
                    pub.playSound(list[i]);
                    _clip.gotoAndStop(list[i]);
                    CheckManager.tweenToFrame(_clip,CheckManager.getLastFrameOfLabel(_clip,list[i]),NaN,pub.onShowLabelComplete,list[i]);
                    return;
                }
            }
        }
    };

    this.check = function(){
        return "0";
    };

    this.preventGestureEvents = function(clip){
         clip.addEventListener('mousedown',stopEvent);
         clip.addEventListener('pressup',stopEvent);
    }

    function stopEvent(e){
        e.stopPropagation();
    }

    function getCheckBtn(clip){
        _checkBtn = clip;
        _checkBtn.visible = false;
        addClickListener(clip,pub.checkHandler);
    }

    function addClickListener(clip,callBack){
        pub.preventGestureEvents(clip)
        clip.addEventListener("click",callBack);
    }

    this.checkHandler = function(e){
        var state = pub.check();
        switch(state){
            case "2":
                pub.showCorrect();
                _lock = true;
                _exerciseResultData.addTry(state,pub.getInput());
                break;
            case "1":
                if(_partlyCorrectList.length){
                    pub.showPartlyCorrect();
                }
                else{
                    pub.showWrong();
                }
                _exerciseResultData.addTry(state,pub.getInput());
                break;
            case "0":
                pub.showWrong();
                _exerciseResultData.addTry(state,pub.getInput());
                break;
        }
        var event = new createjs.Event("EXERCISE_RESULT");
        event.detail = _exerciseResultData;
        _clip.dispatchEvent({type:SimpleContentEvent.EXERCISE_RESULT,detail:_exerciseResultData, bubbles:true});
    };

    function getSolutionBtn(clip){
        _solutionBtn = clip;
        _solutionBtn.visible = false;
        addClickListener(clip,solutionHandler);
    }

    function solutionHandler(e){
        pub.showSolution();
        _solutionBtn.visible = false;
        if(_selectionBtn){
            _selectionBtn.visible = true;
        }
    }

    function getSelectionBtn(clip){
        _selectionBtn = clip;
        _selectionBtn.visible = false;
        addClickListener(clip,pub.selectionHandler);
    }

    this.selectionHandler = function(e){
        var list = _exerciseResultData.resultList;
        pub.setInput(list[list.length-1].input);
        _selectionBtn.visible = false;
        if(_solutionBtn){
            _solutionBtn.visible = true;
        }
        _lock = true;
    };

    function getList(label){
        var list = [];
        var length = _clip.labels.length;
        for(var i=0;i<length;i++){
            var frameLabel = _clip.labels[i];
            if(frameLabel.label.indexOf(label) != -1){
                list.push(frameLabel.label);
            }
        }
        return list;
    }

    this.onShowLabelComplete = function(label){
        var soundName = _currentContentName+"_"+label;
        if(label.indexOf("correct") != -1){
            if(!SoundManager.getInstance().isSoundPlaying(soundName)){
                _clip.dispatchEvent({type:SimpleContentEvent.EXERCISE_COMPLETE,detail:_currentContentName, bubbles:true});
            }
            else{
                SoundManager.getInstance().addComplete(soundName,onSoundComplete);
            }
        }
        else if(label.indexOf("wrong") != -1){

            if(!_solutionBtn){
                if(_currentTry == _maxTry){
                    if(!SoundManager.getInstance().isSoundPlaying(soundName)){
                        if(_solutionList.length) {
                            pub.showSolution();
                        } else {
                            _clip.dispatchEvent({type:SimpleContentEvent.EXERCISE_COMPLETE,detail:_currentContentName, bubbles:true});
                        }
                    }
                    else{
                        SoundManager.getInstance().addComplete(soundName,onSoundComplete);
                    }
                }
            }
        }
        else if(label.indexOf("solution") != -1){
            if(!SoundManager.getInstance().isSoundPlaying(soundName)){
                _clip.dispatchEvent({type:SimpleContentEvent.EXERCISE_COMPLETE,detail:_currentContentName, bubbles:true});
            }
            else{
                SoundManager.getInstance().addComplete(soundName,onSoundComplete);
            }
        }
    };

    function onSoundComplete(name){
        if(name.indexOf("correct") != -1 || name.indexOf("solution") != -1){
            if(SoundManager.getInstance().isSoundPlayedComplete(name)){
                _clip.dispatchEvent({type:SimpleContentEvent.EXERCISE_COMPLETE,detail:_currentContentName, bubbles:true});
            }
        }
        else if(name.indexOf("wrong") != -1){
            //console.log("onSoundComplete wrong: "+name);
            if(_solutionList.length) {
                pub.showSolution();
            } else {
                _clip.dispatchEvent({type:SimpleContentEvent.EXERCISE_COMPLETE,detail:_currentContentName, bubbles:true});
            }
        }
        SoundManager.getInstance().removeComplete(name);
    }

    this.playSound = function (soundName){
        if(_clip.currentLabel != soundName){
            _clip.dispatchEvent({type:SimpleContentEvent.PLAY_SOUND,detail:soundName, bubbles:true});
        }
    };

    this.onReset = function (e){
        //console.log("!!!onReset hast to be extended by special Exercises");
    };


    this.reset = function(){
        _correctSoundName = null;
        _wrongSoundName = null;
        _solutionSoundName = null;

        if(_checkBtn){
            _checkBtn.visible = false;
        }
        if(_solutionBtn){
            _solutionBtn.visible = false;
        }
        _currentTry = 0;
        _lock = false;
    };

    Object.defineProperty(this,"exerciseResultData",{
        get: function(){
            return _exerciseResultData;
        },
        set: function(value){
            _exerciseResultData = value;
        }
    });

    Object.defineProperty(this,"lock",{
        get: function(){
            return _lock;
        },
        set: function(value){
            _lock = value;
        }
    });

    Object.defineProperty(this,"currentTry",{
        get: function(){
            return _currentTry;
        },
        set: function(value){
            _currentTry = value;
        }
    });

    Object.defineProperty(this,"maxTry",{
        get: function(){
            return _maxTry;
        },
        set: function(value){
            _maxTry = value;
        }
    });

    Object.defineProperty(this,"solutionBtn",{
        get: function(){
            return _solutionBtn;
        }
    });

    Object.defineProperty(this,"checkBtn",{
        get: function(){
            return _checkBtn;
        }
    });

    Object.defineProperty(this,"selectionBtn",{
        get: function(){
            return _selectionBtn;
        }
    });

    Object.defineProperty(this,"currentContentName",{
        get: function(){
            return _currentContentName;
        }
    });

    Object.defineProperty(this,"wrongList",{
        get: function(){
            return _wrongList;
        }
    });

    Object.defineProperty(this,"clip",{
        get: function(){
            return _clip;
        }
    });

    Object.defineProperty(this,"input",{
        get: function(){
            return _input;
        },
        set: function(value){
            _input = value;
        }
    });

    Object.defineProperty(this,"partlyCorrectList",{
        get: function(){
            return _partlyCorrectList;
        }
    });

});

//- - - - - - - - - - - - - - - - - - - - - - 30 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/mediator/page/exercise/simple/SimpleExerciseResultData.js
/**
 * Created by tnguyen on 23.03.2016.
 */
var SimpleExerciseResultData = function(_name,_type){

    var _resultList = [];

    this.addTry = function (state,input){
        var obj = {state:state,input:input};
        _resultList.push(obj);
    };

    this.reset = function(){
        _resultList = [];
    };

    this.getResult = function(){
        var input = _resultList[_resultList.length-1].input;
        var correct = 0, total = 0, selected=0, right=0;
        for(var key in input){
            total++;
            if(input[key].selection == true) selected++
            if( input [key].isCorrect){
                correct++;
                if(input[key].selection == true){
                    right ++;
                }
            }
        }
        return {total:total,correct:correct,selected:selected,right:right};
    }

    Object.defineProperty(this,"current",{
        get: function(){
            return _resultList[_resultList.length-1];
        }
    });

    Object.defineProperty(this,"resultList",{
        get: function(){
            return _resultList;
        }
    });

    Object.defineProperty(this,"type",{
        get: function(){
            return _type;
        }
    });

    Object.defineProperty(this,"name",{
        get: function(){
            return _name;
        }
    });
}

SimpleExerciseResultData.MC = "MC";
SimpleExerciseResultData.SC = "SC";
SimpleExerciseResultData.DD = "DD";
SimpleExerciseResultData.TE = "TE";

// TI : TextInput
SimpleExerciseResultData.TI = "TI";

// SD : Slider
SimpleExerciseResultData.SD = "SD";

// RT : Rating
SimpleExerciseResultData.RT = "RT";

// FS : Frame Stepper
SimpleExerciseResultData.FS = "FS";




//- - - - - - - - - - - - - - - - - - - - - - 31 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/utils/simple/SimpleClick.js
/**
 * Created by tnguyen on 19.05.2016.
 */
var SimpleClick = EventDispatcher.extend(function() {
    var pub = this;

    var _comp;
    var _lock;
    var _startTime;
    var _startPoint;
    var _longPressTimeOut;
    var _stage;


    this.constructor = function(comp){
        _comp = comp;
        init();
    };

    function init(){
        _comp.gotoAndStop(1);
        this.lock = false;
        configureListener();
    }

    function configureListener(){
        var clip = (_comp.area)?_comp.area:_comp;
        clip.cursor = "pointer";
        clip.mouseChildren = false;
        clip.addEventListener("mouseover",eventHandLer);
        clip.addEventListener("mouseout",eventHandLer);
        clip.addEventListener("mousedown",eventHandLer);
        clip.addEventListener("click",eventHandLer);
        clip.addEventListener("pressup",eventHandLer);
    }

    function eventHandLer(e){
        e.stopPropagation();
        if(!_lock){
            e.currentTarget = pub;
            switch(e.type){
                case "mouseover":
                    if(_comp.currentLabel == "out"){
                        pub.showLabel("over");
                    }
                    pub.dispatchEvent(e.type,e);
                    break;
                case "mouseout":
                    if(_comp.currentLabel == "over" || _comp.currentLabel == "down"){
                        pub.showLabel("out");
                    }
                    pub.dispatchEvent(e.type,e);
                    break;
                case "mousedown":
                    if(_comp.currentLabel == "over" || _comp.currentLabel == "down"){
                        pub.showLabel("down");
                    }
                    _startTime = getTime();
                    _startPoint = {x:e.stageX, y:e.stageY};
                    _stage = _stage || _comp.stage;
                    _stage.addEventListener("pressup",eventHandLer);
                    pub.dispatchEvent(e.type,e);
                    _longPressTimeOut = setTimeout(function(){checkLongPress(e)},1250);
                    break;
                case "pressup":
                    _stage.removeEventListener("pressup",eventHandLer);
                    if(e.target == _comp){
                        if(isMobile()){
                            pub.showLabel("out");
                        }
                        else{
                            if(_comp.currentLabel == "over"){
                                pub.showLabel("over");
                            }
                        }
                    }
                    else{
                        pub.showLabel("out");
                    }
                    clearTimeout(_longPressTimeOut);
                    pub.dispatchEvent(e.type,e);

                    var diffPoint = getMouseDiffPoint(e);
                    var duration = getTime() - _startTime;
                    if(duration <= 1 && diffPoint.x < 10 && diffPoint.y < 10){
                        var data = {};
                        pub.dispatchEvent("click",{type:"click",currentTarget:pub});
                    }
                    break;
            }
        }
    }

    function checkLongPress(e){
        var diffPoint = getMouseDiffPoint(e);
        if(diffPoint.x < 10 && diffPoint.y < 10){
            pub.dispatchEvent("longpress",{type:"longpress",currentTarget:pub});
        }
    }

    function getMouseDiffPoint(e){
        var diffX = Math.sqrt((e.stageX - _startPoint.x)*(e.stageX - _startPoint.x));
        var diffY = Math.sqrt((e.stageY - _startPoint.y)*(e.stageY - _startPoint.y));
        return {x:diffX,y:diffY};
    }

    function getTime(){
        var date = new Date();
        return date.getSeconds();
    }

    this.showLabel = function(label){
        if(CheckManager.getFrameByLabel(_comp,label) != null){
            _comp.gotoAndStop(label);
        }
    };

    function isMobile(){
        var mobiles = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i;
        return navigator.userAgent.match(mobiles) != null;
    }

    Object.defineProperty(this,"comp",{
        get: function(){
            return _comp;
        }
    });

    Object.defineProperty(this,"lock",{
        get: function(){
            return _lock;
        },
        set: function(value){
            _lock = value;
            _comp.mouseEnabled = !value;
            if(_lock){
                _comp.cursor = "default";
                if(CheckManager.getFrameByLabel(_comp,"lock") != null){
                    _comp.gotoAndStop("lock");
                }
                else{
                    pub.showLabel("out");
                }
            }
            else{
                _comp.cursor = "pointer";
                pub.showLabel("out");
            }
        }
    });
});


//- - - - - - - - - - - - - - - - - - - - - - 32 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/proxy/view/simple/ViewData.js
/**
 * Created by tnguyen on 19.05.2016.
 */
var ViewData = EventDispatcher.extend(function() {
    var pub = this;

    var _viewList;

    this.constructor = function(){
        _viewList = [];
    };

    Object.defineProperty(this,"currentView",{
        get: function(){
            if(_viewList.length > 0){
                return _viewList[_viewList.length-1];
            }
            return null;
        },
        set: function(value){
            if(_viewList.length > 0){
                if(_viewList[_viewList.length-1] != value){
                    _viewList.push(value);
                    pub.dispatchEvent("VIEW_CHANGED",pub);
                }
            }
            else{
                _viewList.push(value);
                pub.dispatchEvent("VIEW_CHANGED",pub);
            }
            if(_viewList.length > 10){
                _viewList.shift();
            }
        }
    });
});

ViewData.INIT = "INIT";


//- - - - - - - - - - - - - - - - - - - - - - 33 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/mediator/page/simple/AnimationController.js
/**
 * Created by tnguyen on 23.05.2016.
 */
var AnimationController = Class.extend(function() {
    var pub = this;
    var _pageClipService;
    var _clip;
    var _data;
    var _textService;

    this.constructor = function(){
        _pageClipService = new SimplePageClipService();
    };

    this.init = function(clip,data){
        _clip = clip;
        _data = data;
        var autoPart = true;
        if(data){
            autoPart = (data.autoPart == "true")?true:false;
        }
        clip.visible = true;
        configureListener();
        _pageClipService.initService(_clip,data.contentName,autoPart);
        _clip.gotoAndStop(0);
    };

    this.initText = function(textXML){
        if(!_textService){
            _textService = new TextService();
        }
        _textService.init(_clip,textXML);
    };

    this.runContent = function(){
        _pageClipService.initCheck();
        _pageClipService.checkPlay();
        _pageClipService.play();
    };

    function configureListener(){}

    this.pause = function(){
        _pageClipService.checkPause();
    };

    this.pauseContent = function(){
        _pageClipService.pauseContent();
    };

    this.resume = function(){
        _pageClipService.checkPlay();
    };

    this.resumeContent = function(){
        _pageClipService.checkPlayContent();
    };

    this.play = function(){
        if(_clip.currentFrame < _clip.totalFrames-1){
            _pageClipService.checkListState = true;
            _pageClipService.partState = false;
            _pageClipService.play();
        }
    };

    this.lastPart = function(){
        var lastPart = _pageClipService.currentPartList[_pageClipService.currentPartList.length-1].name;
        if(lastPart){
            _clip.gotoAndPlay(lastPart);
            _pageClipService.resetState();
        }
    };


    this.nextPart = function(){
        var nextPart = _pageClipService.getNextPartLabel();
        if(nextPart){
            _clip.gotoAndPlay(nextPart);
            _pageClipService.resetState();
        }
        else{
            _clip.dispatchEvent(new createjs.Event(SimpleContentEvent.NEXT_PAGE));
            //_clip.dispatchEvent(new CustomEvent(SimpleContentEvent.NEXT_PAGE));
        }
    };

    this.previousPart = function(){
        var previousPart = _pageClipService.getPreviousPartLabel();
        if(previousPart){
            _clip.gotoAndPlay(previousPart);
            _pageClipService.resetState();
        }
        else{
            _clip.gotoAndPlay(1);
            _pageClipService.resetState();
        }
    };

    this.restartPart = function(){
        var currentPart = _pageClipService.getCurrentPartLabel();
        _clip.gotoAndPlay(currentPart);
        _pageClipService.resetState();
    };

    this.setPart = function(part){
        if(CheckManager.getFrameByLabel(_clip,part)){
            _clip.gotoAndPlay(part);
            _pageClipService.resetState();
        }
        else{
            _clip.gotoAndPlay(1);
            _pageClipService.resetState();
        }
    };

    this.setVolume = function(volume){
        if(_clip){
            _clip.dispatchEvent({type:SimpleContentEvent.VOLUME,detail:volume});
        }
    };

    this.activateSoundClipService = function(){
        _pageClipService.checkListState = true;
        _pageClipService.partState = false;
    };

    this.remove = function(){
        if(_clip){
            _clip.stop();
        }
        if(_pageClipService){
            _pageClipService.removeListener();
        }
    };

    Object.defineProperty(this,"pageClipService",{
        get: function(){
            return _pageClipService;
        }
    });

    Object.defineProperty(this,"clip",{
        get: function(){
            return _clip;
        }
    });

    Object.defineProperty(this,"textService",{
        get: function(){
            return _textService;
        }
    });
});

//- - - - - - - - - - - - - - - - - - - - - - 34 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/mediator/page/simple/SimplePageController.js
/**
 * Created by tnguyen on 23.05.2016.
 */
var SimplePageController = AnimationController.extend(function() {
    var pub = this;

    var _exerciseDict;
    var _exerciseList;
    var _bubble;

    this.constructor = function(){
        this.super.constructor();
    };

    this.init = function(clip, data){
        clip.name = "root";
        clip.stage.update();
        this.super.init(clip,data);
        clip.addEventListener('staged', onElementStaged);
        checkExerciseInFirstFrame(clip);
    };

    function checkExerciseInFirstFrame(container){
        for (var i=0; i<container.numChildren;i++){
            var child = container.getChildAt(i);
            if(child instanceof createjs.MovieClip){
                checkExercise(child);
                checkExerciseInFirstFrame(child);
            }
        }
    }


    function onElementStaged(e){
        //console.log('staged '+e.target.name);
        e.stopPropagation();
        checkExercise(e.target);
    }
    /**
     * check if movieclip is registered and initialize the proper exercise
     */
    function checkExercise(target){
        if(_exerciseDict){
            if(target instanceof createjs.MovieClip){
                if(target.name){
                    for(var key in _exerciseDict){
                        var flags = key.replace(/.*\/([gimy]*)$/, '$1');
                        var pattern = key.replace(new RegExp('^/(.*?)/'+flags+'$'), '$1');
                        var regex = new RegExp(pattern, flags);
                        if(target.name.match(regex)){
                            var className = ClassManager.getNameByPath(_exerciseDict[key]);
                            if(!target._info) target._info = {controllerDict:{}};
                            if(!target._info.controllerDict[className]){
                                //console.log('init '+target.name+' as '+className);
                                var exercise = new window[className]();
                                target._info.controllerDict[className]= exercise;
                                exercise.init(target);
                                _exerciseList.push(exercise);
                            } else {
                                //console.log('!!! catch double init of '+target.name+' as '+className);
                            }
                        }
                    }
                }
            }
        }
    }

    this.remove = function(){
        this.super.remove();
        removeExercise();
    };

    /**
     * call the remove function of all founded exercises and reset the exerciseList
     */
    function removeExercise(){
        if(_exerciseList && _exerciseList.length){
            var length = _exerciseList.length;
            while(_exerciseList.length > 0){
                if(_exerciseList[0].hasOwnProperty("remove")){
                    _exerciseList[0]["remove"]();
                }
                _exerciseList.shift();
            }
        }
    }


    Object.defineProperty(this,"exerciseDict",{
        set: function(value){
            _exerciseDict = value;
            _exerciseList = [];
        }
    });

    Object.defineProperty(this,"bubble",{
        get: function(){
            return _bubble;
        },
        set: function(value){
            _bubble = value;
        }
    });
});

//- - - - - - - - - - - - - - - - - - - - - - 35 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/utils/simple/v2/SimplePageClipService.js
/**
 * Created by tnguyen on 23.05.2016.
 */

var SimplePageClipService = Class.extend(function() {
    var pub = this;

    var _clip;
    var _soundDict;
    var _currentPartList;
    var _currentInteractionList;
    var _currentCheckPartList;
    var _currentClip;
    var _currentCheckList;
    var _currentSoundList;
    var _checkListState = true;
    var _partState;
    var _currentContentName;
    var _currentPartFrame;
    var _autoPart;
    var _completed;

    var _currentSoundId;

    this.initService = function(clip,contentName,autoPart){
        _clip = clip;
        _soundDict = {};
        _currentCheckList = null;
        _currentSoundList = null;
        _currentContentName = contentName;
        _currentPartFrame = 0;
        _autoPart = autoPart;
        _completed = false;
        configureListener();
        registerClip();
        ObjectService.getObjectFromClip(_clip,init,"MovieClip");
    };

    function configureListener(){
        _clip.addEventListener(SimpleContentEvent.STOP_SOUND,onStopSound);
    }

    function onStopSound(e){
        _currentClip = _clip;
    }

    this.removeListener = function(){
        _clip.removeEventListener(SimpleContentEvent.STOP_SOUND,onStopSound);
         SoundManager.getInstance().removeAllListeners();
         SoundManager.getInstance().removeAllSounds();
        _currentSoundId = null;
    };

    function registerClip(){
        init(_clip);
        initPart(_clip);
        initInteraction(_clip);
        _currentClip = _clip;
        if(_soundDict[_currentClip.name] != undefined){
            _currentCheckList = _soundDict[_currentClip.name].checkList;
            _currentSoundList = _soundDict[_currentClip.name].soundList;
        }
    }

    /**
     * init part and save all necessarry data
     */
    function initPart(clip){
        _currentPartList = [];
        _currentCheckPartList = [];
        var labelList = clip.labels;
        var length = labelList.length;
        for(var i=0;i<length;i++){
            var labelType = labelList[i].label.substr(0,1).toUpperCase();
            if(labelType == "P"){
                _currentPartList.push(labelList[i]);
                var frame = labelList[i].position-1;
                if(frame > 0 && _currentCheckPartList.indexOf(frame) == -1){
                    _currentCheckPartList.push(frame);
                }
            }
        }
    }

    function initInteraction(clip){
        _currentInteractionList = [];
        var labelList = clip.labels;
        var length = labelList.length;
        for(var i=0;i<length;i++){
            var labelType = labelList[i].label.substr(0,1).toUpperCase();
            if(labelType == "I"){
                _currentInteractionList.push(labelList[i]);
            }
        }
    }

    function isOnILabel(frame){
        var length = _currentInteractionList.length;
        for(var i=0;i<length;i++){
            if(_currentInteractionList[i].position == frame){
                return true;
            }
        }
        return false;
    }

    /**
     * init sound and save all necessarry data
     */
    function init(clip){
        initSoundByClip(clip);
    }

    function initSoundByClip(clip){
        var labelList = clip.labels;
        var length = labelList.length;
        var soundList = [];
        var checkList = [];
        var soundNameList = [];
        for(var i=0;i<length;i++){
            var labelType = labelList[i].label.substr(0,1);
            if(labelType == "S" || labelType == "P"){
                if(labelType == "S"){
                    soundNameList.push(labelList[i].label.substr(1));
                    soundList.push(labelList[i]);
                }
                var frame = labelList[i].position-1;
                if(frame > 0 && checkList.indexOf(frame) == -1){
                    checkList.push(frame);
                }
            }
        }
        //_soundDict[clip.name]= undefined;
        if(soundList.length || checkList.length){
            checkList.push((clip.totalFrames-1));
            _soundDict[clip.name] = {soundList:soundList,checkList:checkList,clip:clip};
        }
        if(soundNameList.length){
            var event = new createjs.Event(SimpleContentEvent.ADD_SOUND_LIST);
            event.detail = {list:soundNameList,contentName:_currentContentName};
            event.bubbles=true;
            _clip.dispatchEvent(event);
        }
    }

    /**
     * framework start here
     */
    this.initCheck = function(){
        stopCheck();
        _clip.addEventListener("tick",checkFrame);
    };


    /**
     * CheckRenderer
     */
    function checkFrame(e){
        checkSound();
        checkList();
    }

    /**
     *
     * @return timeline progress as part of 1
     *
     */
    Object.defineProperty(this,"percent",{
        get: function(){
            return _clip.currentFrame / (_clip.totalFrames-1);
        }
    });

    /**
     * Ergänzung IK:
     * Gibt an wieviel % ( als Bruchteil von 1 ) ein Part abgespielt wurde. Die Angabe bezieht sich nur auf die Zeitleiste
     * und berücksichtigt nicht den Sound oder I-Labels. Die Methode hat keine Seiteneffekte und verändert keine Member der Klasse.
     *
     */
    Object.defineProperty(this,"partPercent",{
        get: function(){
            if( !_currentCheckPartList.length ){
                return _clip.currentFrame / (_clip.totalFrames-1);
            }
            var myParts = _currentCheckPartList.slice();
            myParts.unshift( 0 );
            myParts.push( (_clip.totalFrames-1) );

            for ( var i = 0; i < myParts.length-1; i ++ )
            {
                if( myParts[i] <= _clip.currentFrame &&  myParts[i +  1 ] > _clip.currentFrame)
                {
                    return ( _clip.currentFrame - myParts[i]) / (myParts[i+1] - myParts[i]);
                }
            }
            return 0;
        }
    });

    /**
     * play sound label.
     */

    function checkSound(){
        for (var key in _soundDict){
            var clip = _soundDict[key].clip;
            var soundList = _soundDict[key].soundList;
            var label = getFrameLabelByFrame(soundList,clip.currentFrame,soundList);
            if(label && clip.stage){
                var soundName = label.substr(1);
                var soundId = _currentContentName+"_"+soundName;
                if(_currentSoundId!=soundId) {
                    _currentSoundId = soundId;
                    _currentCheckList = _soundDict[key].checkList;
                    _currentSoundList = soundList;
                    if(clip != _currentClip && clip != _clip){
                        _currentClip = clip;
                    }
                    if(soundName.match(/^wait\d*/)) {
                        //console.log("- - - - wait");
                        onSoundComplete();
                    } else {
                        //console.log("- - - - play");
                        SoundManager.getInstance().addComplete(soundId,onSoundComplete);
                        SoundManager.getInstance().addWaiting(soundId,onSoundWaiting);
                        SoundManager.getInstance().addCanplay(soundId,onSoundCanplay);

                        var event = new createjs.Event(SimpleContentEvent.PLAY_SOUND);
                        event.detail = soundName;
                        event.bubbles=true;
                        _clip.dispatchEvent(event);
                    }

                }
                if(isOnILabel(_clip.currentFrame)){
                    _checkListState = true;
                }
            }
        }
    }

    function onSoundWaiting(name){
        _currentClip.stop();
    }


    function onSoundCanplay(name){
        _currentClip.play();
    }

    /**
     * check clip after sound is completed
     */
    function onSoundComplete(){
         SoundManager.getInstance().removeListners(_currentSoundId);
        _currentSoundId = null;
        if(_clip.parent && _clip.currentFrame == (_clip.totalFrames-1)){
            _clip.dispatchEvent(new createjs.Event(SimpleContentEvent.PAGE_COMPLETE));
        } else {
            _checkListState = true;
            _currentClip.play();
            checkList();
        }
    }

    /**
     * check if clip is on checkframe. play or stop depend on sound is completed or not
     * importan: to avoid multiple sounds with the same soundname, Soundmanager should clear all Sounds -> SoundManager.getInstance().removeAllSounds()
     */
    function checkList(){
        if(_checkListState){
            var soundName;
            //console.log("checkList: "+_clip.currentFrame,(_clip.totalFrames-1));
            if(_clip.currentFrame == (_clip.totalFrames-1)){
                _clip.gotoAndStop((_clip.totalFrames-1));
                _checkListState = false;
                var clipCurrentFrameLabel = CheckManager.getLabelByFrame(_clip,_clip.currentFrame);
                if(clipCurrentFrameLabel == "E" && !_completed){ // reached E Label
                    _completed = true;
                    _clip.dispatchEvent(SimpleContentEvent.PAGE_COMPLETE);
                    return false;
                }
                if(_clip.currentLabel && _clip.currentLabel.substr(0,1) == "S"){
                    soundName = _clip.currentLabel.substr(1);
                    if((soundName.match(/^wait/) || SoundManager.getInstance().isSoundPlayedComplete(_currentContentName+"_"+soundName)) && !_completed){ //timeline longer than sound
                        _completed = true;
                        _clip.dispatchEvent(SimpleContentEvent.PAGE_COMPLETE);
                    }
                }
                else if(!_completed){ // no sound found
                    _completed = true;
                    _clip.dispatchEvent(SimpleContentEvent.PAGE_COMPLETE);
                }
                return false;
            }
            if(isOnILabel(_clip.currentFrame)){
                _clip.stop();
                return true;
            }
            checkClipList(_clip);
            checkPartList(_clip);
            if(_currentCheckList && _currentCheckList.indexOf(_currentClip.currentFrame) != -1){
                if(!_partState){
                    _currentClip.stop();
                    var currentClipCurrentFrameLabel = CheckManager.getLabelByFrame(_clip,_clip.currentFrame);
                    var soundLabel = getLabelByFrame(_currentSoundList,_currentClip.currentFrame);
                    if(soundLabel){
                        soundName = soundLabel.substr(1);
                        if(! SoundManager.getInstance().isSoundPlaying(_currentContentName+"_"+soundName)){
                            if(_currentClip.currentFrame < (_currentClip.totalFrames-1)){
                                if(currentClipCurrentFrameLabel == null || (currentClipCurrentFrameLabel && currentClipCurrentFrameLabel.substr(0,1).toUpperCase() != "I" && _checkListState)){ //new
                                    _currentClip.play();
                                }
                            }
                        }
                    }
                    else{
                        if(_currentClip.currentFrame < (_currentClip.totalFrames-1)){
                            if(currentClipCurrentFrameLabel == null || (currentClipCurrentFrameLabel && currentClipCurrentFrameLabel.substr(0,1).toUpperCase() != "I" && _checkListState)){ //new
                                _currentClip.play();
                            }
                        }
                    }
                }
                return true;
            }
        }
        return false;
    }

    function checkPartList(clip){
        var checkList = _currentCheckPartList;
        if(checkList.indexOf(clip.currentFrame) != -1){
            if(!_autoPart){
                pub.checkPause();
                _partState = true;
            }
            if(clip.currentFrame != _currentPartFrame){
                clip.stop();
                pub.pause();
                var event = new createjs.Event(SimpleContentEvent.PART_COMPLETE);
                event.detail = clip.currentFrame;
                _clip.dispatchEvent(event);
                _currentPartFrame = clip.currentFrame;
            }
        }
    }

    function checkCurrentClip(){
        if(_currentClip != _clip && _currentClip.currentFrame == (_currentClip.totalFrames-1)){
            _currentClip.gotoAndStop((_currentClip.totalFrames-1));
        }
    }



    function checkClipList(clip){
        if(_soundDict[clip.name]){
            var checkList = _soundDict[clip.name].checkList;
            if(checkList.indexOf(clip.currentFrame) != -1){
                clip.stop();
                var soundList = _soundDict[clip.name].soundList;
                var soundLabel = getLabelByFrame(soundList,clip.currentFrame);
                if(!_partState && !isOnILabel(clip.currentFrame)){
                    if(soundLabel){
                        var soundName = soundLabel.substr(1);
                        var isClipSoundPlaying =  SoundManager.getInstance().isSoundPlaying(_currentContentName+"_"+soundName);
                        checkCurrentClip();
                        if(!isClipSoundPlaying){
                            if(clip.currentFrame < (clip.totalFrames-1)){
                                clip.play();
                                checkListState = true;
                            }
                        }
                    }
                    else{
                        if(clip.currentFrame < (clip.totalFrames-1)){
                            clip.play();
                        }
                    }
                }
            }
        }
    }

    /**
     * Check if current frame is on an I label or not. I label ? dont play
     * If it is not an I label ? check if current frame is on a check frame. check frame ? detect if the current sound is completed. completed ? continue play : stop on current frame
     * If it is not a check frame ? continue play.
     */
    this.checkPlay = function(){
        pub.checkPlayContent();
        _clip.dispatchEvent(SimpleContentEvent.RESUME);
    };

    this.checkPlayContent = function(){
        _checkListState = true;
        _partState = false;
        var currentFrameLabel = CheckManager.getLabelByFrame(_clip,_clip.currentFrame);
        if(!checkList() && _currentClip.currentFrame < (_currentClip.totalFrames-1) && _currentClip != _clip){
            _currentClip.play();
        }
        if(_soundDict[_clip.name]){
            var soundList = _soundDict[_clip.name].soundList;
            var soundLabel = getLabelByFrame(soundList,_clip.currentFrame);
            if(soundLabel){
                var soundName = soundLabel.substr(1);
                var isSoundPlaying =  SoundManager.getInstance().isSoundPlaying(_currentContentName+"_"+soundName);
                var checkListClip = _soundDict[_clip.name].checkList;
                if((checkListClip.indexOf(_clip.currentFrame) == -1 && (!currentFrameLabel || (currentFrameLabel && currentFrameLabel.substr(0,1).toUpperCase() != "I")) && _clip.currentFrame < (_clip.totalFrames-1)) || currentFrameLabel && currentFrameLabel.substr(0,1).toUpperCase() != "I" && _clip.currentFrame < (_clip.totalFrames-1)){
                    _clip.play();
                }
            }
            else{
                if(((currentFrameLabel == null && (getFrameLabelByFrame(_currentPartList,_clip.currentFrame+1) == null || _autoPart)) || (currentFrameLabel && currentFrameLabel.substr(0,1).toUpperCase() != "I")) && _clip.currentFrame < (_clip.totalFrames-1)){
                    var checkList_ = _soundDict[_clip.name].checkList;
                    if(checkList_.indexOf(_clip.currentFrame) == -1){
                        _clip.play();
                    }
                    else{
                        checkFrame();
                    }
                }
            }
        } else if(((currentFrameLabel == null && (getFrameLabelByFrame(_currentPartList,_clip.currentFrame+1) == null || _autoPart)) || (currentFrameLabel && currentFrameLabel.substr(0,1).toUpperCase() != "I")) && _clip.currentFrame < (_clip.totalFrames-1)){
            if(_clip.currentFrame < (_clip.totalFrames-1)) {
                _clip.play();
            }
        }
    };

    this.play = function(){
        if(_clip.currentFrame < _clip.totalFrames-1){
            _clip.gotoAndPlay(_clip.currentFrame+1);
        }
    };

    this.checkPause = function(){
        _checkListState = false;
        this.pause();
    };

    this.pause = function(){
        pauseContent();
        _clip.dispatchEvent(SimpleContentEvent.PAUSE);
    };

    function pauseContent() {
        _currentClip.stop();
        if(_currentClip != _clip){
            _clip.stop();
        }
    }

    function stopCheck(){
        if(_clip && _clip.hasEventListener("tick")){
            _clip.removeEventListener("tick",checkFrame);
        }
    }

    function getFrameLabelByFrame(labelList,frame){
        var currentLabel;
        for(var i=0;i<labelList.length;i++){
            if(frame == labelList[i].position){
                currentLabel = labelList[i].label;
            }
        }
        //if(currentLabel) console.log('currentLabel',currentLabel)
        return currentLabel;
    }

    function getLabelByFrame(labelList,frame){
        var currentLabel;
        for(var i=0;i<labelList.length;i++){
            if(frame >= labelList[i].position){
                currentLabel = labelList[i].label;
            }
        }
        return currentLabel;
    }

    this.getNextPartLabel = function(){
        var labelList = _currentPartList;
        var currentLabel;
        for(var i=0;i<labelList.length;i++){
            if(_clip.currentFrame >= labelList[i].position){
                if(labelList[i+1]){
                    currentLabel = labelList[i+1].label;
                }
                else if(currentLabel == labelList[labelList.length-1].label){
                    return null;
                }
            }
            else{
                return currentLabel = labelList[i].label;
            }
        }
        return currentLabel;
    };

    this.getPreviousPartLabel = function(){
        var labelList = _currentPartList;
        var length = labelList.length;
        for(var i=length-1;i>=0;i--){
            if(labelList[i].position <= _clip.currentFrame){
                if(i-1 >= 0){
                    return labelList[i-1].label;
                }
            }
        }
        return null;
    };

    this.getCurrentPartLabel = function(){
        var labelList = _currentPartList;
        var length = labelList.length;
        for(var i=length-1;i>=0;i--){
            if(labelList[i].position <= _clip.currentFrame){
                return labelList[i].label;
            }
        }
        return null;
    };

    function getCurrentSLabel(){
        var labelList = _currentSoundList;
        var length = labelList.length;
        for(var i=length-1;i>=0;i--){
            if(labelList[i].position <= _clip.currentFrame){
                return labelList[i].label;
            }
        }
        return null;
    }

    this.resetState = function(){
        //alert (_currentSoundId);
        _currentSoundId = null
        _currentPartFrame = 0;
        _checkListState = true;
        _partState = false;
        _completed = false;
    };

    Object.defineProperty(this,"checkListState",{
        set: function(value){
            _checkListState = value;
        }
    });

    Object.defineProperty(this,"partState",{
        set: function(value){
            _partState = value;
        }
    });

    Object.defineProperty(this,"currentPartList",{
        get: function(){
            return _currentPartList;
        }
    });

    Object.defineProperty(this,"autoPart",{
        set: function(value){
            _autoPart = value;
        }
    });
});

//- - - - - - - - - - - - - - - - - - - - - - 36 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/mediator/page/simple/SimpleContentEvent.js
/**
 * Created by tnguyen on 23.05.2016.
 */
var SimpleContentEvent = Class.extend(function() {
    var pub = this;
});

/**
 * Application
 */
SimpleContentEvent.NEXT_PAGE = "NEXT_PAGE";
/**
 * Content
 */
SimpleContentEvent.PAUSE = "PAUSE";
SimpleContentEvent.RESUME = "RESUME";
SimpleContentEvent.VOLUME = "VOLUME";

SimpleContentEvent.PART_COMPLETE = "PART_COMPLETE";
SimpleContentEvent.PAGE_COMPLETE = "PAGE_COMPLETE";
SimpleContentEvent.PAGE_CONTINUE = "PAGE_CONTINUE";
/**
 * Exercise
 */
SimpleContentEvent.EXERCISE_CORRECT = "EXERCISE_CORRECT";
SimpleContentEvent.EXERCISE_WRONG = "EXERCISE_WRONG";
SimpleContentEvent.EXERCISE_PARTLY_CORRECT = "EXERCISE_PARTLY_CORRECT";
SimpleContentEvent.EXERCISE_RESULT = "EXERCISE_RESULT";
SimpleContentEvent.EXERCISE_COMPLETE = "EXERCISE_COMPLETE";
SimpleContentEvent.EXERCISE_NOTIFICATION = "EXERCISE_NOTIFICATION";

/**
 * Sound
 */
SimpleContentEvent.LOOP_SOUND = "LOOP_SOUND";
SimpleContentEvent.PLAY_SOUND = "PLAY_SOUND";
SimpleContentEvent.PLAY_EXTRA_SOUND = "PLAY_EXTRA_SOUND";
SimpleContentEvent.STOP_SOUND = "STOP_SOUND";
SimpleContentEvent.PAUSE_SOUND = "PAUSE_SOUND";
SimpleContentEvent.RESUME_SOUND = "RESUME_SOUND";
SimpleContentEvent.ADD_SOUND_LIST = "ADD_SOUND_LIST";

/**
 * Proxy
 */
SimpleContentEvent.GET_PROXY = "GET_PROXY";
SimpleContentEvent.FOUND_PROXY = "FOUND_PROXY";

//- - - - - - - - - - - - - - - - - - - - - - 37 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/utils/textservice/TextService.js
/**
 * Created by tnguyen on 23.05.2016.
 */
var TextService = EventDispatcher.extend(function(){
    var pub = this;
    var _xml;
    var _clip;

    this.init = function(clip,xml){
        _clip = clip;
        _xml = xml;
        clip.findObjectsByName(/.*/,createjs.Text).forEach(getTextField);
        clip.addEventListener("newText",onNewTextField);
    };

    function onNewTextField(e){
        var text = getText(e.item.name);
        if(text){
            e.item.mouseEnabled = false;
            e.item.text= text;
        }
    }

    function getTextField(textField){
        var text = getText(textField.name);
        if(text){
            textField.text = text;
        }
    }

    function getText(name){
        var xmlList = _xml.childNodes;
        var length = xmlList.length;
        for(var i=0;i<length;i++){
            var node = xmlList[i];
            if(node.nodeName == "item") {
                var nodeId = node.attributes["id"].value;
                if (name == nodeId) {
                    return node.textContent;
                }
            }
        }
    }
});

//- - - - - - - - - - - - - - - - - - - - - - 38 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/proxy/user/simple/PipwerksAdapter.js
var PipwerksAdapter = Class.extend(function() {
    var pipwerks = getPipwerks();
    var connectionActive = false;
    pipwerks.debug.isActive = false;

    this.connect = connect;
    this.disconnect = disconnect;
    this.get = get;
    this.set = set;
    this.save = save;

    function connect(version) {
        pipwerks.SCORM.version = version;
        var result = false;
        if (!connectionActive) {
            var eiCall = String(pipwerks.SCORM.init());
            result = stringToBoolean(eiCall);

            if (result) {
                connectionActive = true;
            } else {
                var errorCode = getDebugCode();
                if (errorCode) {
                    var debugInfo = getDebugInfo(errorCode);
                    debugLog("pipwerks.SCORM.init() failed. \n"
                            + "Error code: " + errorCode + "\n"
                            + "Error info: " + debugInfo);
                } else {
                    debugLog("pipwerks.SCORM.init failed: no response from server.");
                }
            }
        } else {
            debugLog("pipwerks.SCORM.init aborted: connection already active.");
        }

        debugLog("connectionActive: " + connectionActive);
        return result;
    }

    function disconnect() {
        var result = false;
        if (connectionActive) {
            var eiCall = String(pipwerks.SCORM.quit());
            result = stringToBoolean(eiCall);
            if (result) {
                connectionActive = false;
            } else {
                var errorCode = getDebugCode();
                var debugInfo = getDebugInfo(errorCode);
                debugLog("pipwerks.SCORM.quit() failed. \n"
                        + "Error code: " + errorCode + "\n"
                        + "Error info: " + debugInfo);
            }
        } else {
            debugLog("pipwerks.SCORM.quit aborted: connection already inactive.");
        }
        return result;
    }

    function get(parameter) {
        var returnedValue = "";
        if (connectionActive) {
            returnedValue = String(pipwerks.SCORM.get(parameter));
            var errorCode = getDebugCode();
            if (returnedValue === "" && errorCode !== 0) {
                var debugInfo = getDebugInfo(errorCode);
                debugLog("pipwerks.SCORM.get(" + parameter + ") failed. \n"
                        + "Error code: " + errorCode + "\n"
                        + "Error info: " + debugInfo);
            }
        } else {
            debugLog("pipwerks.SCORM.get(" + parameter + ") failed: connection is inactive.");
        }
        return returnedValue;
    }

    function set(parameter, value) {
        var result = false;
        if (connectionActive) {
            var eiCall = String(pipwerks.SCORM.set(parameter, value));
            result = stringToBoolean(eiCall);
            if (!result) {
                var errorCode = getDebugCode();
                var debugInfo = getDebugInfo(errorCode);
                debugLog("pipwerks.SCORM.set(" + parameter + ") failed. \n"
                        + "Error code: " + errorCode + "\n"
                        + "Error info: " + debugInfo);
            }
        } else {
            debugLog("pipwerks.SCORM.set(" + parameter + ") failed: connection is inactive.");
        }
        return result;
    }

    function save() {
        var result = false;
        if (connectionActive) {
            var eiCall = String(pipwerks.SCORM.save());
            result = stringToBoolean(eiCall);
            if (!result) {
                var errorCode = getDebugCode();
                var debugInfo = getDebugInfo(errorCode);
                debugLog("pipwerks.SCORM.save() failed. \n"
                        + "Error code: " + errorCode + "\n"
                        + "Error info: " + debugInfo);
            }
        } else {
            debugLog("pipwerks.SCORM.save() failed: API connection is inactive.");
        }
        return result;
    }

    function stringToBoolean(string) {
        if (string !== null) {
            switch (string.toLowerCase()) {
                case "true":
                case "yes":
                case "1":
                    return true;

                case "false":
                case "no":
                case "0":
                    return false;
            }
        }
        return false;
    }

    function getDebugCode() {
        return parseInt(pipwerks.SCORM.debug.getCode());
    }

    function getDebugInfo(errorCode) {
        var result = String(pipwerks.SCORM.debug.getInfo(errorCode));
        return result;
    }

    function debugLog(msg) {
        if (pipwerks.debug.isActive) {
            console.log(msg);
        }
    }

    function getPipwerks() {
        /* =====================================================================================
         SCORM wrapper v1.1.7 by Philip Hutchison, May 2008 (http://pipwerks.com).

         Copyright (c) 2008 Philip Hutchison
         MIT-style license. Full license text can be found at
         http://www.opensource.org/licenses/mit-license.php

         This wrapper is designed to work with both SCORM 1.2 and SCORM 2004.

         Based on APIWrapper.js, created by the ADL and Concurrent Technologies
         Corporation, distributed by the ADL (http://www.adlnet.gov/scorm).

         SCORM.API.find() and SCORM.API.get() functions based on ADL code,
         modified by Mike Rustici (http://www.scorm.com/resources/apifinder/SCORMAPIFinder.htm),
         further modified by Philip Hutchison

         Adapted for nomofive by t.hauke 2014. See the original code for Hutchison's comments.
         ======================================================================================== */

        var pipwerks = {};
        pipwerks.UTILS = {};
        pipwerks.debug = {isActive: true};

        pipwerks.SCORM = {
            version: "2004",
            handleCompletionStatus: true,
            handleExitMode: true,
            API: {handle: null,
                isFound: false},
            connection: {isActive: false},
            data: {completionStatus: null,
                exitStatus: null},
            debug: {}
        };


        pipwerks.SCORM.isAvailable = function() {
            return true;
        };

        pipwerks.SCORM.API.find = function(win) {

            var API = null,
                    findAttempts = 0,
                    findAttemptLimit = 500,
                    traceMsgPrefix = "SCORM.API.find",
                    trace = pipwerks.UTILS.trace,
                    scorm = pipwerks.SCORM;

            while ((!win.API && !win.API_1484_11) &&
                    (win.parent) &&
                    (win.parent !== win) &&
                    (findAttempts <= findAttemptLimit)) {

                findAttempts++;
                win = win.parent;

            }

            if (scorm.version) {
                switch (scorm.version) {
                    case "2004" :
                        if (win.API_1484_11) {
                            API = win.API_1484_11;
                            trace("IK: SCORM version 2004 gefunden");
                        } else {
                            trace(traceMsgPrefix + ": SCORM version 2004 was specified by user, but API_1484_11 cannot be found.");
                        }
                        break;
                    case "1.2" :
                        if (win.API) {
                            API = win.API;
                        } else {
                            trace(traceMsgPrefix + ": SCORM version 1.2 was specified by user, but API cannot be found.");
                        }
                        break;
                }
            } else {
                if (win.API_1484_11) {
                    scorm.version = "2004";
                    API = win.API_1484_11;
                } else if (win.API) {
                    scorm.version = "1.2";
                    API = win.API;
                }
            }

            if (API) {
                trace(traceMsgPrefix + ": API found. Version: " + scorm.version);
                trace("API: " + API);
            } else {
                trace(traceMsgPrefix + ": Error finding API. \nFind attempts: " + findAttempts + ". \nFind attempt limit: " + findAttemptLimit);
            }
            return API;
        };

        pipwerks.SCORM.API.get = function() {
            var API = null,
                    win = window,
                    find = pipwerks.SCORM.API.find,
                    trace = pipwerks.UTILS.trace;


            API = find(win);


            if (!API && win.top.opener) {
                API = find(win.top.opener);
            }

            if (API) {
                pipwerks.SCORM.API.isFound = true;
            } else {
                trace("API.get failed: Can't find the API!");
            }
            return API;
        };

        pipwerks.SCORM.API.getHandle = function() {
            var API = pipwerks.SCORM.API;
            if (!API.handle && !API.isFound) {
                API.handle = API.get();
            }
            return API.handle;
        };

        pipwerks.SCORM.connection.initialize = function() {
            var success = false,
                    scorm = pipwerks.SCORM,
                    completionStatus = pipwerks.SCORM.data.completionStatus,
                    trace = pipwerks.UTILS.trace,
                    makeBoolean = pipwerks.UTILS.StringToBoolean,
                    debug = pipwerks.SCORM.debug,
                    traceMsgPrefix = "SCORM.connection.initialize ";

            trace("connection.initialize called.");
            if (!scorm.connection.isActive) {
                var API = scorm.API.getHandle(),
                        errorCode = 0;
                if (API) {
                    switch (scorm.version) {
                        case "1.2" :
                            success = makeBoolean(API.LMSInitialize(""));
                            break;
                        case "2004":
                            success = makeBoolean(API.Initialize(""));
                            break;
                    }
                    if (success) {
                        errorCode = debug.getCode();
                        if (errorCode !== null && errorCode === 0) {
                            scorm.connection.isActive = true;
                            if (scorm.handleCompletionStatus) {
                                completionStatus = pipwerks.SCORM.status("get");
                                if (completionStatus) {
                                    switch (completionStatus) {
                                        case "not attempted":
                                            pipwerks.SCORM.status("set", "incomplete");
                                            break;
                                        case "unknown" :
                                            pipwerks.SCORM.status("set", "incomplete");
                                            break;
                                    }
                                }
                            }
                        } else {
                            success = false;
                            trace(traceMsgPrefix + "failed. \nError code: " + errorCode + " \nError info: " + debug.getInfo(errorCode));
                        }
                    } else {
                        errorCode = debug.getCode();
                        if (errorCode !== null && errorCode !== 0) {
                            trace(traceMsgPrefix + "failed. \nError code: " + errorCode + " \nError info: " + debug.getInfo(errorCode));
                        } else {
                            trace(traceMsgPrefix + "failed: No response from server.");
                        }
                    }

                } else {
                    trace(traceMsgPrefix + "failed: API is null.");
                }
            } else {
                trace(traceMsgPrefix + "aborted: Connection already active.");
            }
            return success;
        };

        pipwerks.SCORM.connection.terminate = function() {

            var success = false,
                    scorm = pipwerks.SCORM,
                    exitStatus = pipwerks.SCORM.data.exitStatus,
                    completionStatus = pipwerks.SCORM.data.completionStatus,
                    trace = pipwerks.UTILS.trace,
                    makeBoolean = pipwerks.UTILS.StringToBoolean,
                    debug = pipwerks.SCORM.debug,
                    traceMsgPrefix = "SCORM.connection.terminate ";


            if (scorm.connection.isActive) {
                var API = scorm.API.getHandle(),
                        errorCode = 0;
                if (API) {
                    if (scorm.handleExitMode && !exitStatus) {
                        if (completionStatus !== "completed" && completionStatus !== "passed") {
                            switch (scorm.version) {
                                case "1.2" :
                                    success = scorm.set("cmi.core.exit", "suspend");
                                    break;
                                case "2004":
                                    success = scorm.set("cmi.exit", "suspend");
                                    break;
                            }
                        } else {
                            switch (scorm.version) {
                                case "1.2" :
                                    success = scorm.set("cmi.core.exit", "logout");
                                    break;
                                case "2004":
                                    success = scorm.set("cmi.exit", "normal");
                                    break;
                            }
                        }

                    }

                    switch (scorm.version) {
                        case "1.2" :
                            success = makeBoolean(API.LMSFinish(""));
                            break;
                        case "2004":
                            success = makeBoolean(API.Terminate(""));
                            break;
                    }

                    if (success) {
                        scorm.connection.isActive = false;
                    } else {
                        errorCode = debug.getCode();
                        trace(traceMsgPrefix + "failed. \nError code: " + errorCode + " \nError info: " + debug.getInfo(errorCode));
                    }

                } else {
                    trace(traceMsgPrefix + "failed: API is null.");
                }

            } else {
                trace(traceMsgPrefix + "aborted: Connection already terminated.");
            }
            return success;
        };

        pipwerks.SCORM.data.get = function(parameter) {
            var value = null,
                    scorm = pipwerks.SCORM,
                    trace = pipwerks.UTILS.trace,
                    debug = pipwerks.SCORM.debug,
                    traceMsgPrefix = "SCORM.data.get(" + parameter + ") ";

            if (scorm.connection.isActive) {

                var API = scorm.API.getHandle(),
                        errorCode = 0;
                if (API) {
                    switch (scorm.version) {
                        case "1.2" :
                            value = API.LMSGetValue(parameter);
                            break;
                        case "2004":
                            value = API.GetValue(parameter);
                            break;
                    }

                    errorCode = debug.getCode();
                    if (value !== "" && errorCode === 0) {
                        switch (parameter) {
                            case "cmi.core.lesson_status":
                            case "cmi.completion_status" :
                                scorm.data.completionStatus = value;
                                break;
                            case "cmi.core.exit":
                            case "cmi.exit" 	:
                                scorm.data.exitStatus = value;
                                break;
                        }
                    } else {
                        trace(traceMsgPrefix + "failed. \nError code: " + errorCode + "\nError info: " + debug.getInfo(errorCode));
                    }
                } else {
                    trace(traceMsgPrefix + "failed: API is null.");
                }
            } else {
                trace(traceMsgPrefix + "failed: API connection is inactive.");
            }
            trace(traceMsgPrefix + " value: " + value);
            return String(value);
        };


        pipwerks.SCORM.data.set = function(parameter, value) {
            var success = false,
                    scorm = pipwerks.SCORM,
                    trace = pipwerks.UTILS.trace,
                    makeBoolean = pipwerks.UTILS.StringToBoolean,
                    debug = pipwerks.SCORM.debug,
                    traceMsgPrefix = "SCORM.data.set(" + parameter + ") ";

            if (scorm.connection.isActive) {
                var API = scorm.API.getHandle(),
                        errorCode = 0;
                if (API) {
                    switch (scorm.version) {
                        case "1.2" :
                            success = makeBoolean(API.LMSSetValue(parameter, value));
                            break;
                        case "2004":
                            success = makeBoolean(API.SetValue(parameter, value));
                            break;
                    }
                    if (success) {
                        if (parameter === "cmi.core.lesson_status" || parameter === "cmi.completion_status") {
                            scorm.data.completionStatus = value;
                        }
                    } else {
                        trace(traceMsgPrefix + "failed. \nError code: " + errorCode + ". \nError info: " + debug.getInfo(errorCode));
                    }

                } else {
                    trace(traceMsgPrefix + "failed: API is null.");
                }

            } else {
                trace(traceMsgPrefix + "failed: API connection is inactive.");
            }

            return success;
        };

        pipwerks.SCORM.data.save = function() {
            var success = false,
                    scorm = pipwerks.SCORM,
                    trace = pipwerks.UTILS.trace,
                    makeBoolean = pipwerks.UTILS.StringToBoolean,
                    traceMsgPrefix = "SCORM.data.save failed";

            if (scorm.connection.isActive) {

                var API = scorm.API.getHandle();
                if (API) {
                    switch (scorm.version) {
                        case "1.2" :
                            success = makeBoolean(API.LMSCommit(""));
                            break;
                        case "2004":
                            success = makeBoolean(API.Commit(""));
                            break;
                    }
                } else {
                    trace(traceMsgPrefix + ": API is null.");
                }
            } else {
                trace(traceMsgPrefix + ": API connection is inactive.");
            }
            return success;
        };


        pipwerks.SCORM.status = function(action, status) {

            var success = false,
                    scorm = pipwerks.SCORM,
                    trace = pipwerks.UTILS.trace,
                    traceMsgPrefix = "SCORM.getStatus failed",
                    cmi = "";

            if (action !== null) {
                switch (scorm.version) {
                    case "1.2" :
                        cmi = "cmi.core.lesson_status";
                        break;
                    case "2004":
                        cmi = "cmi.completion_status";
                        break;
                }

                switch (action) {
                    case "get":
                        success = pipwerks.SCORM.data.get(cmi);
                        break;
                    case "set":
                        if (status !== null) {
                            success = pipwerks.SCORM.data.set(cmi, status);
                        } else {
                            success = false;
                            trace(traceMsgPrefix + ": status was not specified.");
                        }
                        break;
                    default	  :
                        success = false;
                        trace(traceMsgPrefix + ": no valid action was specified.");
                }
            } else {
                trace(traceMsgPrefix + ": action was not specified.");
            }
            return success;
        };

        pipwerks.SCORM.debug.getCode = function() {
            var API = pipwerks.SCORM.API.getHandle(),
                    scorm = pipwerks.SCORM,
                    trace = pipwerks.UTILS.trace,
                    code = 0;
            if (API) {
                switch (scorm.version) {
                    case "1.2" :
                        code = parseInt(API.LMSGetLastError(), 10);
                        break;
                    case "2004":
                        code = parseInt(API.GetLastError(), 10);
                        break;
                }
            } else {
                trace("SCORM.debug.getCode failed: API is null.");
            }
            return code;
        };

        pipwerks.SCORM.debug.getInfo = function(errorCode) {

            var API = pipwerks.SCORM.API.getHandle(),
                    scorm = pipwerks.SCORM,
                    trace = pipwerks.UTILS.trace,
                    result = "";

            if (API) {
                switch (scorm.version) {
                    case "1.2" :
                        result = API.LMSGetErrorString(errorCode.toString());
                        break;
                    case "2004":
                        result = API.GetErrorString(errorCode.toString());
                        break;
                }
            } else {
                trace("SCORM.debug.getInfo failed: API is null.");
            }
            return String(result);
        };

        pipwerks.SCORM.debug.getDiagnosticInfo = function(errorCode) {

            var API = pipwerks.SCORM.API.getHandle(),
                    scorm = pipwerks.SCORM,
                    trace = pipwerks.UTILS.trace,
                    result = "";

            if (API) {
                switch (scorm.version) {
                    case "1.2" :
                        result = API.LMSGetDiagnostic(errorCode);
                        break;
                    case "2004":
                        result = API.GetDiagnostic(errorCode);
                        break;
                }
            } else {
                trace("SCORM.debug.getDiagnosticInfo failed: API is null.");
            }
            return String(result);
        };

        pipwerks.SCORM.init = pipwerks.SCORM.connection.initialize;
        pipwerks.SCORM.get = pipwerks.SCORM.data.get;
        pipwerks.SCORM.set = pipwerks.SCORM.data.set;
        pipwerks.SCORM.save = pipwerks.SCORM.data.save;
        pipwerks.SCORM.quit = pipwerks.SCORM.connection.terminate;

        pipwerks.UTILS.StringToBoolean = function(string) {
            switch (string.toLowerCase()) {
                case "true":
                case "yes":
                case "1":
                    return true;
                case "false":
                case "no":
                case "0":
                case null:
                    return false;
                default:
                    return Boolean(string);
            }
        };

        pipwerks.UTILS.trace = function(msg) {
            if (pipwerks.debug.isActive) {
                if (window.console !== undefined)
                    console.log(msg);
            }
        };

        return pipwerks;
    }
});

//- - - - - - - - - - - - - - - - - - - - - - 39 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/widget/scroller/simple/SimpleScroller.js
/**
 * Created by tnguyen on 30.05.2016.
 */
var SimpleScroller = Class.extend(function(){
    var pub = this;
    var _mask;
    var _scrollerItems;
    var _scrollerControl;
    var _cont;

    this.constructor = function(area,cont,width,height,scrollerItems,dragable){
        _cont = cont;
        if(!cont.parent.getChildByName("mask")){
            _mask = new createjs.Shape();
            _mask.graphics.beginFill("#ff0000");
            _mask.name = "mask";
            _mask.graphics.drawRect(0,0,width,height);
            _mask.width = width;
            _mask.height = height;
            _mask.graphics.endFill();
            _mask.alpha = 0;
            _mask.x = cont.x;
            _mask.y = cont.y;
        }
        else{
            _mask = cont.parent.getChildByName("mask");
        }

        dragable = (dragable==undefined)?true:dragable;
        cont.mask = _mask;
        cont.parent.addChild(_mask);
        _scrollerItems = scrollerItems;
        _scrollerControl = new SimpleScrollerControl();
        pub.resetScrollerControl = _scrollerControl.reset;
        _scrollerItems.getChildByName("slider").height = _scrollerItems.getChildByName("slider").nominalBounds.height;
        _scrollerItems.getChildByName("slider").startHeight = _scrollerItems.getChildByName("slider").height;
        _scrollerItems.getChildByName("bg").height = _scrollerItems.getChildByName("bg").nominalBounds.height;
        _scrollerControl.init(area,cont,_mask,_scrollerItems.getChildByName("bg"),_scrollerItems.getChildByName("slider"),dragable);
        pub.updateByHeight(cont.height);
    };

    this.updateByHeight = function(height){
        if(height > _mask.height){
            _scrollerItems.visible = true;
            updateScrollerItems(height);
            _scrollerControl.setScrollClipHeight(height);
            _scrollerControl.update(_scrollerItems.getChildByName("bg").nominalBounds.height);
        }
        else{
            updateScrollerItems(height);
            _scrollerControl.setScrollClipHeight(height);
            _scrollerControl.update(_scrollerItems.getChildByName("bg").nominalBounds.height);

            _scrollerItems.visible = false;
            _scrollerControl.reset();
        }
    };

    function updateScrollerItems(height){
        var sliderHeight = (_mask.height/height) * _mask.height;
        var sliderHeight_ = Math.sqrt(sliderHeight*sliderHeight);
        _scrollerItems.getChildByName("slider").scaleY = (sliderHeight_/_scrollerItems.getChildByName("slider").startHeight);
        _scrollerItems.getChildByName("slider").height = sliderHeight_;
    }

    function resetPosition(){
        _scrollerControl.reset();
    }

    /**
     * set the new height of the content and scroll to 0 Position. Detect if the scroller is needed or not.
     * @param height
     */
    this.update = function(height){
        _scrollerControl.setScrollClipHeight(-1);
        pub.updateByHeight(height);
        resetPosition();
    };

    this.scrollContentTo = function(y){
        _scrollerControl.scrollContentTo(y);
    };

    function hideScroller(){
        _scrollerItems.visible = false;
    }

    function showScroller(){
        _scrollerItems.visible = true;
    }

    function remove(){
        _scrollerControl.remove();
    }
});

//- - - - - - - - - - - - - - - - - - - - - - 40 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/widget/scroller/simple/SimpleScrollerControl.js
/**
 * Created by tnguyen on 31.05.2016.
 */
var SimpleScrollerControl = Class.extend(function(){
    var pub = this;
    var _area;
    var _scrollClip;
    var _mask;
    var _bg;
    var _slider;
    var _maxHeight;
    var _minHeight;
    var _sliderY;
    var _scrollClipY;
    var _mouseState = true;
    var _dragable;
    var _startDragY;
    var _scrollClipBg;
    var _scrollClipHeight = -1;

    this.init = function(area,scrollClip,mask,bg,slider,dragable){
        _area=area;
        _scrollClip=scrollClip;
        _scrollClipY=scrollClip.y;
        _mask=mask;
        _bg=bg;
        _slider=slider;
        _sliderY=slider.y;
        _dragable = dragable;

        start();
        configureListener();
    };

    function start() {
        _maxHeight = _bg.height -_slider.height;
        _minHeight = Math.floor((_bg.y+_slider.y));

        _scrollClipBg = _mask.parent.getChildByName("scrollClipBg");
        if(_scrollClipBg){
            _scrollClipBg.scaleX = _mask.width / _scrollClipBg.nominalBounds.width;
            _scrollClipBg.scaleY = _mask.height / _scrollClipBg.nominalBounds.height;
            _scrollClipBg.alpha = 0.01;
            _scrollClipBg.x = _mask.x;
            _scrollClipBg.y = _mask.y;

        }else{
            _scrollClipBg = new createjs.Shape();
            _scrollClipBg.graphics.beginFill("#ffffff");
            _scrollClipBg.name = "scrollClipBg";
            _scrollClipBg.graphics.drawRect(0,0,_mask.width,_mask.height);
            _scrollClipBg.graphics.endFill();
            _scrollClipBg.width = _mask.width;
            _scrollClipBg.height = _mask.height;
            _scrollClipBg.nominalBounds = {};
            _scrollClipBg.nominalBounds.width = _scrollClipBg.width;
            _scrollClipBg.nominalBounds.height = _scrollClipBg.height;
            _scrollClipBg.alpha = 0.01;
            _scrollClipBg.x = _mask.x;
            _scrollClipBg.y = _mask.y;
            _scrollClipBg.graphics.endFill();
            var index = _mask.parent.getChildIndex(_scrollClip);
            _mask.parent.addChildAt(_scrollClipBg,index-1);
        }


    }

    function configureListener() {
        pub.reset();
        _slider.addEventListener("mousedown",onMouseDown);
        if(_area){
            _area.addEventListener("pressup",onMouseUp);
        }
        var canvas = document.getElementById("canvas");
        canvas.addEventListener("wheel",onMouseWheel);
        _scrollClip.addEventListener("wheel",onMouseWheel);
        _scrollClipBg.addEventListener("wheel",onMouseWheel);
        _slider.parent.addEventListener("wheel",onMouseWheel);
        _bg.addEventListener("mousedown",onBgClick);
        if(_dragable){
            _scrollClip.addEventListener("mousedown",onScrollClipDown);
            _scrollClipBg.addEventListener("mousedown",onScrollClipDown);
        }
    }

    function isMouseHit(){
        if(!_mask.stage) return false;
        var localPos = _mask.globalToLocal(_mask.stage.mouseX, _mask.stage.mouseY);
        if(_mask.hitTest(localPos.x,localPos.y)){
            return true;
        }
    }


    function onScrollClipDown(e){
        if(_slider.parent.visible){
            _startDragY = e.localY;
            if(_scrollClip.stage){
                var localPos = _scrollClip.parent.globalToLocal(_scrollClip.stage.mouseX, _scrollClip.stage.mouseY);
                var deltaX = localPos.x - _scrollClip.x;
                var deltaY = localPos.y - _scrollClip.y;
                _scrollClip.deltaPosition = {x:deltaX,y:deltaY};
                _area.addEventListener("pressmove",onScrollClipMove);
                _area.addEventListener("pressup",onScrollClipUp);
            }
        }
    }

    function onScrollClipMove(e){
        if(_scrollClip.stage){
            var localPos = _scrollClip.parent.globalToLocal(_scrollClip.stage.mouseX, _scrollClip.stage.mouseY);
            var targetY = localPos.y - _scrollClip.deltaPosition.y;
            setScrollClipY(targetY);
        }
    }

    function setScrollClipY(targetY){
        if(_scrollClipHeight > _mask.height){
            var targetSliderY = -((targetY - _scrollClipY)/_scrollClipHeight)*_bg.height;
            if(targetY > (_mask.height-_scrollClipHeight+_scrollClipY) && targetY < _mask.y){ // between up and down
                _scrollClip.y = targetY;
                _slider.y = targetSliderY;
            }
            else if(targetY >= _mask.y){ // max down
                _scrollClip.y = _mask.y;
                targetSliderY = -((_scrollClip.y - _scrollClipY)/_scrollClipHeight)*_bg.height;
                _slider.y = targetSliderY;
            }
            else if(targetY <= (_mask.height-_scrollClipHeight+_scrollClipY)){ // max up
                _scrollClip.y = (_mask.height-_scrollClipHeight+_scrollClipY);
                targetSliderY = -((_scrollClip.y - _scrollClipY)/_scrollClipHeight)*_bg.height;
                _slider.y = targetSliderY;
            }
        }
        else{
            _scrollClip.y = _mask.y;
            targetSliderY = -((_scrollClip.y - _scrollClipY)/_scrollClipHeight)*_bg.height;
            _slider.y = targetSliderY;
        }
    }

    function onScrollClipUp(e) {
        _area.removeEventListener("pressmove",onScrollClipMove);
        _area.removeEventListener("pressup",onScrollClipUp);
    }

    function onBgClick(e) {
        var scrollClipHeight = (_scrollClipHeight != -1)?_scrollClipHeight:_scrollClip.height;
        var time = 0.3;
        var newY;
        newY = Math.floor(e.localY - (_slider.height/2));
        var newScrollY = Math.floor(-((newY/_bg.height)*scrollClipHeight)+_scrollClipY);
        if(e.localY>_slider.y){
            if(newY>=_maxHeight){
                Tweener.addTween(_slider,{y:_maxHeight,time:time,overwrite:true});
                Tweener.addTween(_scrollClip,{y:(_mask.y+_mask.height)-scrollClipHeight,time:time,overwrite:true});
            }
            else{
                Tweener.addTween(_slider,{y:newY,time:time,overwrite:true});
                Tweener.addTween(_scrollClip,{y:newScrollY,time:time,overwrite:true});
            }
        }
        else{
            if(newY <=_minHeight){
                Tweener.addTween(_slider,{y:_minHeight,time:time,overwrite:true});
                Tweener.addTween(_scrollClip,{y:_scrollClipY,time:time,overwrite:true});
            }
            else{
                Tweener.addTween(_slider,{y:newY,time:time,overwrite:true});
                Tweener.addTween(_scrollClip,{y:newScrollY,time:time,overwrite:true});
            }
        }
    }

    this.updateScrollerByContTarget = function(targetY,time){
        if(time == undefined){
            time = 0.3;
        }
        var scrollClipHeight = (_scrollClipHeight != -1)?_scrollClipHeight:_scrollClip.height;
        var time = time;
        var targetSliderY = -((targetY - _scrollClipY)/scrollClipHeight)*_bg.height;
        if(targetSliderY <= _maxHeight && targetSliderY >= 0){
            Tweener.addTween(_slider,{y:targetSliderY,time:time});
            Tweener.addTween(_scrollClip,{y:targetY,time:time});
        }
        else if(targetSliderY > _maxHeight){
            Tweener.addTween(_slider,{y:_maxHeight,time:time});
            Tweener.addTween(_scrollClip,{y:(_mask.y+_mask.height)-scrollClipHeight,time:time});
        }
    };

    function setSlider(e){
        if(_slider.stage){
            var localPos = _slider.parent.globalToLocal(_slider.stage.mouseX, _slider.stage.mouseY);
            var targetY = localPos.y - _slider.deltaPosition.y;
            if(targetY <= (_maxHeight+0.85) && targetY >= 0){
                _slider.y = targetY;
            }
            else if(targetY < 0){
                _slider.y = 0;
            }
            else if(targetY > (_maxHeight+0.85)){
                _slider.y = (_maxHeight+0.85);
            }
        }
    }

    function setScrollClip(){
        var scrollClipHeight = (_scrollClipHeight != -1)?_scrollClipHeight:_scrollClip.height;
        if(scrollClipHeight > _mask.height) {
            var slide = (_slider.y/_bg.height)*(scrollClipHeight);
            _scrollClip.y = Math.floor(-slide+_scrollClipY);//Math.round(-slide);
        }
        else if(scrollClipHeight <= _mask.height && _scrollClip.getBounds(_scrollClip).y <0){
            var scrollClipY_ = _scrollClip.getBounds(_scrollClip).y;
            var slide_ = (_slider.y/_mask.height)*(scrollClipHeight-_mask.height) - scrollClipY_;
            _scrollClip.y = Math.floor(slide_);
        }
        if(_slider.y >= _maxHeight){
            _scrollClip.y = _mask.y - scrollClipHeight + _mask.height;
        }
    }
    function onMouseWheel(e) {
        if(isMouseHit()){
            var scrollClipHeight = (_scrollClipHeight != -1)?_scrollClipHeight:_scrollClip.height;
            if(_slider.parent.visible){
                _mouseState = true;
                var newY;
                var newScrollY;
                if (e.deltaY>0) {
                    newY = Math.round(_slider.y+12);
                    newScrollY = Math.floor(-((newY/_bg.height)*scrollClipHeight)+_scrollClipY);
                    if (newY<_maxHeight) {
                        _slider.y = newY;
                        _scrollClip.y = newScrollY;
                    } else {
                        _slider.y = _maxHeight;
                        _scrollClip.y = Math.floor((_mask.y+_mask.height)-scrollClipHeight);
                    }

                } else if (e.deltaY<0) {
                    newY = Math.round(_slider.y-12);
                    newScrollY = Math.floor(-((newY/_bg.height)*scrollClipHeight)+_scrollClipY);
                    if (newY>_minHeight) {
                        _slider.y = newY;
                        _scrollClip.y = newScrollY;
                    } else {
                        _slider.y = _sliderY;
                        _scrollClip.y = _scrollClipY;
                    }
                }
            }
        }
    }
    function onMouseDown(e) {
        var scrollClipHeight = (_scrollClipHeight != -1)?_scrollClipHeight:_scrollClip.height;
        _scrollClip.mouseEnabled = false;
        if(_slider.height != _bg.height){
            _maxHeight = _bg.height-_slider.height;
            if(_slider.stage){
                var localPos = _slider.parent.globalToLocal(_slider.stage.mouseX, _slider.stage.mouseY);
                var deltaX = localPos.x - _slider.x;
                var deltaY = localPos.y - _slider.y;
                _slider.deltaPosition = {x:deltaX,y:deltaY};

                _area.addEventListener("pressmove",onMouseMove);
                _area.addEventListener("pressup",onMouseUp);
                _mouseState = true;
            }

        }
        if(_slider.y >= _maxHeight){
            _scrollClip.y = _mask.y - scrollClipHeight + _mask.height;
        }
    }

    function onMouseMove(e) {
        // prevent scrolling if no mousebutton is down...
       if(e.nativeEvent.buttons != undefined && e.nativeEvent.buttons === 0){
           onMouseUp();
       }
        if(_mouseState == true){
            setSlider(e);
            setScrollClip();
        }
    }

    function onMouseUp(e) {
        _area.removeEventListener("pressmove",onMouseMove);
        _area.removeEventListener("pressup",onMouseUp);
        _mouseState = false;
        _scrollClip.mouseEnabled = true;
    }

    this.update = function(height){
        _bg.height = height;
        _maxHeight = _bg.height-_slider.height ;
        pub.scrollContentTo(_scrollClip.y);
    };

    this.scrollContentTo = function(posY){
        posY = posY + _scrollClipY;
        setScrollClipY(posY);
    };

    this.setScrollClipHeight = function(value){
        _scrollClipHeight = value;
    };

    this.reset = function(){
        _scrollClip.y = _scrollClipY;
        _slider.y = 0
    };

    function remove(){
        pub.reset();
        removeListener();
    }

    function removeListener(){
        if(_slider.hasEventListener("mousedown")){
            _slider.removeEventListener("mousedown",onMouseDown);
        }
        if(_area.hasEventListener("pressup")){
            _area.removeEventListener("pressup",onMouseUp);
        }
        if(_scrollClip.hasEventListener("wheel")){
            _scrollClip.removeEventListener("wheel",onMouseWheel);
        }
        if(_scrollClipBg.hasEventListener("wheel")){
            _scrollClipBg.removeEventListener("wheel",onMouseWheel);
        }
        if(_slider.parent.hasEventListener("wheel")){
            _slider.parent.removeEventListener("wheel",onMouseWheel);
        }
        if(_bg.hasEventListener("mousedown")){
            _bg.removeEventListener("mousedown",onBgClick);
        }
        if(_scrollClip.hasEventListener("mousedown")){
            _scrollClip.removeEventListener("mousedown",onScrollClipDown);
        }
        if(_scrollClipBg.hasEventListener("mousedown")){
            _scrollClipBg.removeEventListener("mousedown",onScrollClipDown);
        }
    }
});

//- - - - - - - - - - - - - - - - - - - - - - 41 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/proxy/user/simple/UserData.js
/**
 * Created by tnguyen on 22.05.2016.
 */

var UserData = EventDispatcher.extend(function() {
    var pub = this;
    var _adapter;
    var _userId;
    var _userName;
    var _completed = 'incomplete';
    var _success;
    var _score;
    var _data;
    var _progressMeasure = 0;
    var _unloaded;
    var _connected;
    var _params;

    this.constructor = function(configParams){
        _params = configParams || {};
        this.init();
    };

    this.init = function(){
        _data = {data:{}};

        _adapter = new PipwerksAdapter();
        _connected = _adapter.connect("2004");

        if(_connected){
            _userId = _adapter.get("cmi.learner_id");
            _userName = _adapter.get("cmi.learner_name");
            _completed = _adapter.get("cmi.completion_status");
            _success = _adapter.get("cmi.success_status");
            _progressMeasure = _adapter.get("cmi.progress_measure");
            var suspendData = _adapter.get("cmi.suspend_data");

            if(suspendData && suspendData != ""){
                _data = JSON.parse(suspendData);
            }
            window.addEventListener('beforeunload',unloadHandler);
            window.addEventListener('unload',unloadHandler);
        }
    };

    function unloadHandler(){
        if(!_unloaded){
            _unloaded = true;
            _adapter.save(); //save all data that has already been sent
            _adapter.disconnect(); //close the SCORM API connection properly
        }
    }

    this.saveData = function(data){
        //prevent downgrading
        if(_data.data[data.id] == undefined || Number(_data.data[data.id])< Number(data.state)){
            _data.data[data.id] = data.state;
        }
    };

    this.saveFile = function(){
        if(_connected){
            _adapter.set("cmi.suspend_data", JSON.stringify(_data));
            if(_completed){
                _adapter.set("cmi.completion_status",_completed);
            }
            if(_success){
                _adapter.set("cmi.success_status",_success);
            }
            if(_progressMeasure){
                _adapter.set("cmi.progress_measure",_progressMeasure);
            }
        }
    };

    Object.defineProperty(this,"adapter",{
        get: function(){
            return _adapter;
        },
        set: function(value){
            _adapter = value;
        }
    });

    Object.defineProperty(this,"connected",{
        get: function(){
            return _connected;
        },
        set: function(value){
            _connected = value;
        }
    });

    Object.defineProperty(this,"unloaded",{
        get: function(){
            return _unloaded;
        },
        set: function(value){
            _unloaded = value;
        }
    });

    Object.defineProperty(this,"data",{
        get: function(){
            return _data;
        },
        set: function(value){
            _data = value;
        }
    });

    Object.defineProperty(this,"currentDataId",{
        get: function(){
            return _data.currentDataId;
        },
        set: function(value){
            _data.currentDataId = value;
        }
    });

    Object.defineProperty(this,"userId",{
        get: function(){
            return _userId;
        },
        set: function(value){
            _userId = value;
        }
    });

    Object.defineProperty(this,"userName",{
        get: function(){
            return _userName;
        },
        set: function(value){
            _userName = value;
        }
    });

    Object.defineProperty(this,"success",{
        get: function(){
            return _success;
        },
        set: function(value){
            //do not reduce _success
            if(_success != "passed") _success = value;
        }
    });

    Object.defineProperty(this,"score",{
        get: function(){
            return _score;
        },
        set: function(value){
            if(_score){
                //do not reduce _score
                if(Number(value)>Number(_score)) _score = value;
            } else _score = value;
        }
    });

    Object.defineProperty(this,"progressMeasure",{
        get: function(){
            return _progressMeasure;
        },
        set: function(value){
            _progressMeasure = value;
        }
    });

    Object.defineProperty(this,"completed",{
        get: function(){
            return _completed;
        },
        set: function(value){
            if(_completed != value){
               _completed = value;
            }
        }
    });

    Object.defineProperty(this,"params",{
        get: function(){
            return _params;
        }
    });


});

//- - - - - - - - - - - - - - - - - - - - - - 42 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/utils/components/FrameStepper.js
/**
 * Created by cduerbeck on 13.07.16.
 */

var FrameStepper = EventDispatcher.extend(function(){

    var pub = this;
    var _clip;
    var _steppedMc;
    var _previousBtn;
    var _nextBtn;
    var _lock = false;

    var _steppedMcName, _nextBtnName, _previousBtnName;


    this.init = function(clip, steppedMcName, nextBtnName, previousBtnName){
        _clip = clip;
        _steppedMcName = steppedMcName;
        _nextBtnName = nextBtnName;
        _previousBtnName = previousBtnName;
        setTimeout(init,0);
    }


    function init() {
        findObjectByName(_clip,_steppedMcName,getSteppedMc);
        findObjectByName(_clip,_nextBtnName,getNextBtn);
        findObjectByName(_clip,_previousBtnName,getPreviousBtn);
    }

    function findObjectByName(container,name,callBack){
        for(var i= 0; i<container.numChildren; i++){
            var child = container.getChildAt(i);

            if(child.name && child.name.match(name)){
                callBack(child);
            }
            if(child instanceof createjs.MovieClip){
                findObjectByName(child,name,callBack);
            }
        }
    }


    function getSteppedMc(clip){
        _steppedMc = clip;
        _steppedMc.gotoAndStop(0);
    }

    function getNextBtn(clip){
        _nextBtn = clip;
        _nextBtn.addEventListener("click", onNext)
    }


    function getPreviousBtn(clip){
        _previousBtn = clip;
        _previousBtn.addEventListener("click", onPrevious)
    }

    function onNext(event){
        if(_lock == false){
            if(_steppedMc.currentFrame < _steppedMc.totalFrames - 1){
                _steppedMc.gotoAndStop(_steppedMc.currentFrame + 1)
                pub.dispatchEvent("changed", _steppedMc.currentFrame);
            }
        }
    }

    function onPrevious(event){
        if(_lock == false){
            if(_steppedMc.currentFrame > 0){
                _steppedMc.gotoAndStop(_steppedMc.currentFrame - 1)
                pub.dispatchEvent("changed", _steppedMc.currentFrame);
            }
        }
    }

    Object.defineProperty(this,"clip",{
        get: function(){
            return _clip;
        }
    });

    Object.defineProperty(this,"lock",{
        set: function(value){
            _lock = value;
        }
    });

});

//- - - - - - - - - - - - - - - - - - - - - - 43 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/utils/components/RatingBox.js
/**
 * Created by cduerbeck on 14.07.16.
 */

var RatingBox = EventDispatcher.extend(function(){

    var _clip;
    var pub = this;
    var _lock = false;

    this.constructor = function(clip){
        _clip = clip;
        clip.gotoAndStop(0);
        clip.addEventListener("click", onRated);
    };

    function onRated(event){
        if(_lock == false){
            var mouseX = event.localX;
            var percent = mouseX /_clip.nominalBounds.width;
            var frameNum = Math.ceil((_clip.totalFrames - 1) * percent);
            _clip.gotoAndStop(frameNum);
            pub.dispatchEvent("changed", _clip.currentFrame);
        }
    }

    Object.defineProperty(this,"clip",{
        get: function(){
            return _clip;
        }
    });


    Object.defineProperty(this,"lock",{
        set: function(value){
            _lock = value;
        }
    });

});

//- - - - - - - - - - - - - - - - - - - - - - 44 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/utils/components/StopWatch.js
/**
 * Created by cduerbeck on 02.08.16.
 */

var StopWatch = EventDispatcher.extend(function(){

    var pub = this;
    var _clip;
    var _watch;
    var _feedback;
    var _repeatBtn;

    this.init = function(clip){
        _clip = clip;
        _clip.findObjectsByKey(/^repeatBtn$/).forEach(getObject);
        _clip.findObjectsByKey(/^clock$/).forEach(getObject);
        _clip.findObjectsByKey(/^feedback$/).forEach(getObject);
    }


    function getObject(clip){
        switch(clip.name){
            case "clock":
                _watch = clip;
                _watch.gotoAndStop(0);
                break;
            case "feedback":
                _feedback = clip;
                _feedback.visible = false;
                break;
            case "repeatBtn":
                _repeatBtn = clip;
                _repeatBtn.visible = false;
                _repeatBtn.addEventListener("click", onRepeat);
                break;
        }
    };

    function checkWatch(e) {
        // Actions carried out each tick (aka frame)
        if (!e.paused) {
            if(_watch.currentFrame == _watch.totalFrames - 1){
                onTimeElapsed(e);
            }
        }
    }

    function onTimeElapsed(e){
        _feedback.visible = true;
        _repeatBtn.visible = true;
        _watch.gotoAndStop(_watch.totalFrames - 1);

        if(createjs.Ticker.hasEventListener("tick")){
            createjs.Ticker.removeEventListener("tick", checkWatch);
        }
        pub.dispatchEvent("timeOver");
    }

    function onRepeat(){
        _repeatBtn.visible = false;
        _feedback.visible = false;
        pub.run();
        pub.dispatchEvent("repeat");
    }

    this.run = function(){
        createjs.Ticker.addEventListener("tick", checkWatch);
        _watch.gotoAndPlay(0);
    }

    this.exerciseFinished = function(){
        _watch.stop();
        if(createjs.Ticker.hasEventListener("tick")){
            createjs.Ticker.removeEventListener("tick", checkWatch);
        }
    }

});




//- - - - - - - - - - - - - - - - - - - - - - 45 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/mediator/content/simple/SimpleContentMediator.js
/**
 * Created by tnguyen on 22.05.2016.
 */
var SimpleContentMediator = SimpleMediator.extend(function(){
    var pub = this;

    this.init = function(){
        pub.ACTIVATE_COMMAND = "ACTIVATE_CONTENT_COMMAND";
        pub.DEACTIVATE_COMMAND = "DEACTIVATE_CONTENT_COMMAND";
        pub.LOCK_COMMAND = "LOCK_CONTENT_COMMAND";
        this.super.init();
        buildMask();
    };

    function buildMask(){
        var mask = new createjs.Shape();
        mask.graphics.beginFill("#ff0000");
        mask.graphics.drawRect(0,0,pub.clip.nominalBounds.width,pub.clip.nominalBounds.height);
        mask.graphics.endFill();
        pub.clip.parent.addChild(mask);
        mask.x = pub.clip.x;
        mask.y = pub.clip.y;
        mask.alpha = 0;
        pub.clip.mask = mask;
    }

    this.listNotifications = function(){
        var list = this.super.listNotifications();
        list.push("PAUSE_COMMAND");
        list.push("RESUME_COMMAND");
        list.push("LOAD_CONTENT_COMMAND");
        return list;
    };

    this.handleNotification = function(notification) {
        this.super.handleNotification(notification);
        switch (notification.getName()) {
        case "PAUSE_COMMAND":
            pub.sendNotification(pub.LOCK_COMMAND, true);
            pub.clip.tickEnabled = false;
            break;
        case "RESUME_COMMAND":
            pub.sendNotification(pub.LOCK_COMMAND, false);
            pub.clip.tickEnabled = true;
            break;
        case "LOAD_CONTENT_COMMAND":
            pub.clip.tickEnabled = true;
            break
        }
    }


});

//- - - - - - - - - - - - - - - - - - - - - - 46 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/mediator/view/simple/SimpleViewMediator.js
/**
 * Created by tnguyen on 27.05.2016.
 */
var SimpleViewMediator = Mediator.extend(function(){
    var pub = this;
    this.constructor = function(){};

    this.init = function(){
        initView();
        window.addEventListener("resize", onResize);
        document.addEventListener('orientationchange', onOrientationChange);
        onResize();
        //window.dispatchEvent(new CustomEvent("resize"));
    };

    function onOrientationChange(e){
        onResize(e);
    }

    function initView(){
        var backgroundMediator = Facade.getInstance().retrieveMediator("BackgroundMediator");
        if(backgroundMediator){
            backgroundMediator.getViewComponent().startWidth = backgroundMediator.getViewComponent().nominalBounds.width;
            backgroundMediator.getViewComponent().startHeight = backgroundMediator.getViewComponent().nominalBounds.height;
        }

        var wrapperMediator = Facade.getInstance().retrieveMediator("WrapperMediator");
        if(wrapperMediator){
            wrapperMediator.getViewComponent().startWidth = wrapperMediator.getViewComponent().wrapperBackground.nominalBounds.width;
            wrapperMediator.getViewComponent().startHeight = wrapperMediator.getViewComponent().wrapperBackground.nominalBounds.height;
        }
        var configProxy = Facade.getInstance().retrieveProxy("ConfigProxy");
    }

    function onTouchMove(e){
        e.preventDefault();
    }

    function onResize(e){
        var screenRatio = window.innerWidth / window.innerHeight;
        setStage();
        setBackGround();
        pub.setWrapper();
    }

    function setStage(){
        var wrapperMediator = Facade.getInstance().retrieveMediator("WrapperMediator");
        if(wrapperMediator){
            wrapperMediator.getViewComponent().stage.canvas.width = window.innerWidth;
            wrapperMediator.getViewComponent().stage.canvas.height = window.innerHeight;
        }
    }

    function setBackGround(){
        var mediator = Facade.getInstance().retrieveMediator("BackgroundMediator");
        if(mediator){
            setProportional(mediator.getViewComponent(),window.innerWidth,window.innerHeight);
        }
    }

    this.setWrapper = function(){
        var mediator = Facade.getInstance().retrieveMediator("WrapperMediator");
        if(mediator){
            var comp = mediator.getViewComponent();
            var scaleX = 1;
            var scaleY = 1;
            if(window.innerWidth < comp.startWidth || window.innerHeight < comp.startHeight){
                var screenRatio = window.innerWidth / window.innerHeight;
                var compRatio = comp.startWidth/comp.startHeight;
                if(compRatio >= screenRatio){
                    var ratioX = window.innerWidth/comp.startWidth;
                    comp.scaleX = ratioX;
                    comp.scaleY = ratioX;
                }
                else{
                    var ratioY = window.innerHeight/comp.startHeight;
                    comp.scaleY = ratioY;
                    comp.scaleX = ratioY;
                }
                scaleX = comp.scaleX;
                scaleY = comp.scaleY;
            }

            comp.scaleX = scaleX;
            comp.scaleY = scaleY;
            comp.x = window.innerWidth/2 - (comp.startWidth*scaleX)/2;
            comp.y = window.innerHeight/2 - (comp.startHeight*scaleY)/2;
        }
    }

    function setProportional(comp,screenWidth,screenHeight){
        screenWidth += 4;
        screenHeight += 4;
        var screenRatio = screenWidth/screenHeight;
        var compRatio = comp.startWidth/ comp.startHeight;
        if(screenRatio > compRatio){
            var ratioX = screenWidth/comp.startWidth;
            comp.scaleX = ratioX;
            comp.scaleY = ratioX;
            comp.width = comp.startWidth*ratioX;
            comp.height = comp.startHeight*ratioX;
        }
        else{
            var ratioY = screenHeight/comp.startHeight;
            comp.scaleX = ratioY;
            comp.scaleY = ratioY;
            comp.width = comp.startWidth*ratioY;
            comp.height = comp.startHeight*ratioY;
        }
        comp.x = screenWidth/2 - comp.width/2;
        comp.y = screenHeight/2 - comp.height/2;
    }

    this.listNotifications = function(){
        var list = this.super.listNotifications();
        list.push("VIEW_CHANGED_COMMAND");
        return list;
    };

    this.handleNotification = function(notification){
        switch(notification.getName()){
            case "VIEW_CHANGED_COMMAND":
                if(notification.getBody()) {
                    pub.viewChanged(notification.getBody().toString());
                }
                break;
        }
    };

    this.viewChanged = function(view){
        switch(view){
            case ViewData.INIT:
                pub.sendNotification("RESUME_COMMAND");
                break;
            default:
                pub.sendNotification("PAUSE_COMMAND");
                break;
        }
    };
});

//- - - - - - - - - - - - - - - - - - - - - - 47 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/widget/slide/simple/SimpleSlideWidget.js
/*
 tilo 7/2016
 */

var SimpleSlideWidget = Class.extend(function(){
    var _widget = this;
    var _clip;
    var _root;
    var _currentSoundName;
    var _constraint;
    var _frameSlaveDict;
    var _fillDict;
    var _sliderDict;
    var _rangeList;
    var _snaps;
    var _inRangeClip;

    this.beforeInit = function(clip){
        clip.visible = false;
    };

    this.init = function(clip){
         //console.log('SimpleSlideWidget:'+clip.name + ' #'+ clip.numChildren)
        _clip = clip;
        //_clip.addEventListener('changed', function(){console.log('onChanged')});
        _root = CheckManager.getRoot(_clip);
        _constraint = {};
        initWidget();
        clip.visible = true;
    };


    function initWidget(){
        _currentSoundName = _constraint = _frameSlaveDict = _fillDict = _sliderDict = _rangeList = _snaps =_inRangeClip = null;
        _clip.findObjectsByName(/constraint/,null, true).forEach(initConstraint);
        _clip.findObjectsByName(/(\b|_)frameSlave\d*_/,null, true).forEach(initFrameSlave);
        _clip.findObjectsByName(/(\b|_)range\d*/,null, true).forEach(initRange);
        _clip.findObjectsByName(/(\b|_)snap\d*/,null, true).forEach(initSnaps);
        _clip.findObjectsByName(/(\b|_)fill\d*/,null, true).forEach(initFill);
        _clip.findObjectsByName(/(\b|_)slider\d+/,null, true).forEach(initSlider);

        if(_rangeList) checkRanges();

        for(var id in _sliderDict) updateFills(_sliderDict[id]);

        function initConstraint(clip){
            var  bounds = getClipBounds(clip);
            _constraint = {
                x: bounds.x,
                y: bounds.y,
                width:bounds.width-1, // minus 1 weil ein constraint von 1 pixel = 0 Freiheitsgrad bedeutet
                height:bounds.height-1
            };
            //console.log(_constraint);
        }

        function initFrameSlave(clip){
            //console.log('- initFrameSlave');
            clip.gotoAndStop(0);
            _frameSlaveDict = _frameSlaveDict||{}
            var sliderId = String(clip.name.match(/\d+$/));
            _frameSlaveDict[sliderId] = _frameSlaveDict[sliderId]||[];
            _frameSlaveDict[sliderId].push(clip);
        }

        function initFill(clip){
            //console.log('- initFill');
            _fillDict = _fillDict||{}
            var sliderIds = String(clip.name.replace(/^[^_]*_/,'')).split('_');

            _fillDict[sliderIds[0]] = {fill:clip, ids:sliderIds};
            _fillDict[sliderIds[1]] = {fill:clip, ids:sliderIds};
        }

        function initSlider(clip){
             //console.log('- initSlider');
            _sliderDict = _sliderDict||{};
            clip.sliderId = String(clip.name.match(/slider\d+/)).replace(/\D+/,'');
            _sliderDict[clip.sliderId] = clip;
            var grip = clip.findObjectsByName(/^grip/)[0];
            clip.findObjectsByName(/correct|wrong/).forEach(function(clip){clip.visible= false; });
            behavior.draggable(clip,grip);

            _constraint.grid = {h:1, onMove:true};
            if(_snaps){
                _constraint.snap = {h:_snaps.h, v:_snaps.v, onMove:false};
            }

            if (_fillDict && _fillDict[clip.sliderId]){
                 clip.draggable.constraints = new DynamicConstraint(clip, _constraint);
            } else {
                clip.draggable.constraints = _constraint;
            }

            clip.addEventListener('dragstop', onDragStop);
            if((_frameSlaveDict && _frameSlaveDict[clip.sliderId])  || (_fillDict && _fillDict[clip.sliderId])) {
                clip.addEventListener('drag', onDrag);
            }
            updateSlaves(clip);

        }

        function DynamicConstraint(clip,_constraint){
            var fillObj = _fillDict[clip.sliderId];
            var buddy, buddyID = fillObj.ids[0] == clip.sliderId ? fillObj.ids[1]:fillObj.ids[0];
            //var isRight = clip.x > buddy.x;
            //console.log(clip.sliderId, buddyID);
            //copy global constraints:
            for (var name in _constraint) this[name]= _constraint[name];
            //override by getters:

            Object.defineProperty(this, "x", {get: function () {
                return   _constraint.x;
            }});

            Object.defineProperty(this, "width", {get: function () {
                return _constraint.width
            }});

        }

        function initRange(clip){
             //console.log('- initRange');
            _rangeList = _rangeList||[];
            clip._bounds = getClipBounds(clip);
            _rangeList.push(clip);
        }

        function initSnaps(clip){
            //console.log('- initSnaps');
            _snaps = _snaps||{name:[], h:[],v:[],done:[]};
            _snaps.name.push(clip.name);
            _snaps.v.push(clip.y);
            _snaps.h.push(clip.x);
            _snaps.done.push(false);
        }
    }


    function getClipBounds(clip){
        var bounds = {
            x:parseInt(clip.x,10),
            y:parseInt(clip.y,10),
            width:parseInt(clip.nominalBounds.width*clip.scaleX,10),
            height:parseInt(clip.nominalBounds.height*clip.scaleY,10)
        } ;

        return bounds;
    }

    function onDrag(e){
        updateSlaves(e.target);
        updateFills(e.target);
    }


    function onDragStop(e){
       _clip.dispatchEvent(new createjs.Event("slide", false));
       if(_rangeList) checkRanges();
        evaluate();
        //_widget.showEvaluation();
        if(_snaps) checkSnap(e.target);
    }


    function checkRanges(){
        for (var id in _sliderDict) {
            var slider = _sliderDict[id]
            slider.inRange = null;
            _rangeList.forEach(function(range){
                if(slider.x >= range._bounds.x &&
                    slider.x <= range._bounds.x+range._bounds.width &&
                    slider.y >= range._bounds.y &&
                    slider.y <= range._bounds.y+range._bounds.height
                    ) {slider.inRange = range}
            });
        }
    }

    function checkSnap(slider){
        var snapIndex =  slider.draggable.hSnap;
        //console.log('snapIndex '+snapIndex)
        var soundString = _snaps.name[snapIndex].match(/sound_[^_]+/);
        if(soundString) playSound(String(soundString).replace('sound_',''));
        var done = _snaps.done[snapIndex];
        _snaps.done[snapIndex] = true;

        if(_clip.name.match(/(_|\b)continueOnSnap(_|\b)/)){
            _snaps.done[snapIndex] = true;
            checkContinue();
        }
    }

    function checkContinue(){
        var total = _snaps.done.length;
        var seen = 0;
        for (var key in _snaps.done) {
            var done = _snaps.done[key];
            if(done){
                seen++;
            }
        }

        if(total == seen){
            _root.dispatchEvent(SimpleContentEvent.PAGE_CONTINUE);
        }
    }

    function updateSlaves(slider) {
        if(_frameSlaveDict && _frameSlaveDict[slider.sliderId]) {
            for (var i in _frameSlaveDict[slider.sliderId]){
                var slave = _frameSlaveDict[slider.sliderId][i];
                var frame = Math.round(slave.totalFrames*(slider.draggable.hRatio*slider.draggable.vRatio));
                if(frame > slave.totalFrames-1){
                    frame = slave.totalFrames-1;
                }
                slave.gotoAndStop(frame);
            }
        }
    }


    function updateFills(slider) {
        if(_fillDict && _fillDict[slider.sliderId]) {
            var btw = _fillDict[slider.sliderId];
            var slider1 = _sliderDict[btw.ids[0]];
            var slider2 = _sliderDict[btw.ids[1]];
            /*if(slider1.x > slider2.x){
                slider2 = _sliderDict[btw.ids[0]];
                slider1 = _sliderDict[btw.ids[1]];
            }*/
            var diff = slider2.x-slider1.x;
            var scaleX = diff/(btw.fill.nominalBounds.width+1*btw.fill.nominalBounds.x);
            btw.fill.setTransform(slider1.x, btw.fill.y, scaleX);
        }
    }


    function playSound(name){
        stopSound();
        var event = new createjs.Event(SimpleContentEvent.PLAY_SOUND);
        event.detail = name;
        _currentSoundName = name;
        _root.dispatchEvent(event);
    }

    function stopSound(){
        if(_currentSoundName) {
            var event = new createjs.Event(SimpleContentEvent.STOP_SOUND);
            event.detail = _currentSoundName;
            _currentSoundName = null;
            _root.dispatchEvent(event);
        }
    }

    function evaluate(){
        for (var id in _sliderDict) {
            var slider = _sliderDict[id]
            slider.isCorrect = false;
            if(slider.inRange){
                var correct = slider.inRange.name.match(/_[\d_]+/);
                if(correct) {
                    var correctValues = correct.toString().split('_');
                    slider.isCorrect =(correctValues.indexOf(slider.sliderId) > -1);
                }
            }
        };
    }

    this.showSolution = function(){
        for (var id in _sliderDict) {
            var slider = _sliderDict[id];
            var sliderId = slider.name.match(/slider_?(\d+)/)[1];
            _rangeList.forEach(function(range){
                if( range.name.match(new RegExp('range_?\\d+_' + sliderId))){
                    slider.x = range.x + range._bounds.width/2;
                    slider.y = range.y + range._bounds.height/2;
                }
            });
            slider.draggable.update();
            updateSlaves(slider);
        }
    }


    this.hideEvaluation = function(){
        for (var id in _sliderDict) {
            var slider = _sliderDict[id];
            slider.findObjectsByName(/correct/).forEach(function(clip){clip.visible= false; });
            slider.findObjectsByName(/wrong/).forEach(function(clip){clip.visible= false; });
        }
    }

    this.showEvaluation = function (){
        for (var id in _sliderDict) {
            var slider = _sliderDict[id];
            slider.findObjectsByName(/correct/).forEach(function(clip){clip.visible= slider.isCorrect; });
            slider.findObjectsByName(/wrong/).forEach(function(clip){clip.visible= !slider.isCorrect; });
        }
    }

    Object.defineProperty(this,"sliderDict",{
        get: function(){return _sliderDict;}
    });


    Object.defineProperty(this,"lock",{
        set: function(value){_clip.mouseEnabled  = !value;}
    });

    Object.defineProperty(this,"clip",{
        get: function(){return _clip;}
    });

});

//- - - - - - - - - - - - - - - - - - - - - - 48 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/mediator/menu/porschepanamerast/PorschePanameraStInfoMenu.js
/**
 * Created by fseng on 21.12.2016.
 */
var PorschePanameraStInfoMenu = Class.extend(function(){

    var pub = this;
    var _clip;
    var _startY;
    var _targetY;
    var _infoMenuBtn;

    this.constructor = function(clip) {
        _clip = clip;
        init();
    }

    function init() {
        _infoMenuBtn = _clip.findObjectsByName("infoMenuBtn", createjs.MovieClip, false)[0];
        var infoMenuContent = _clip.findObjectsByName("infoMenuContent", createjs.MovieClip, false)[0];
        _startY = _clip.y;
        _targetY = _startY - infoMenuContent.nominalBounds.height;
        _infoMenuBtn.addEventListener("click", onClick);
        _infoMenuBtn.gotoAndStop("on");
    }


    function onClick(e) {

        if(_clip.y < _startY) {
            _infoMenuBtn.gotoAndStop("on");
            Tweener.addTween(_clip, {y:_startY, time:0.5});
        } else {
            _infoMenuBtn.gotoAndStop("off");
            Tweener.addTween(_clip, {y:_targetY, time:0.5});
        }
    }

});

//- - - - - - - - - - - - - - - - - - - - - - 49 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/widget/popup/simple/SimplePopupWidget.js
/**
 * Created by tnguyen on 25.05.2016.
 */
/**
 * @class
 * @classdesc SimplePopupWidget represents a popup-window - style container with timeline, closeButton and further functionality
 *
 * Usage: Use following naming conventions for further functionality:
 *
 *  Extensions: _closeOnSeen : automatically closes the popup on the end of its timeline.
 *  _stay : will stay open when others popups are opened.
 *  _continueOnSeen : stays open at the end of the timeline, will close when other popups are opend.
 *  _wait: stops the parent timeline while it is opened. But it will jump to the next soundLabel if the sound is larger then the frames of the soundLabel.
 *
 */
var SimplePopupWidget = Class.extend(function(){
    var _root;
    var _clip;
    var _animationController;
    var _timeout;
    var _isBusy;

    this.init = function(clip){
        _clip = clip;
        var currentPageData = Facade.getInstance().retrieveProxy("StructureProxy").getData().currentPageData;
        var contentName = (currentPageData)?ClassManager.getNameByPath(currentPageData.contentPath):"frameContent";
        _root = CheckManager.getRoot(_clip);
        configureListener();
        _animationController = new AnimationController();
        _animationController.init(_clip,{autoPart:false,contentName:contentName});
        _animationController.pause();
       _clip.gotoAndStop(0);
       _clip.visible = false;
        _clip.close = close;
        _clip.open = open;
        checkIfOpenOnInit();
        //console.log(_clip.name);
    };

    function configureListener(){
        var closeBtn = _clip.closeBtn;
        if (closeBtn) {
            new SimpleClick(closeBtn).addEvent("click", close);
        }
        _clip.addEventListener("click", eventHandler);// sonst kann man durch das popup "durchklicken"
        _root.addEventListener(SimpleContentEvent.PAUSE,eventHandler);
        _root.addEventListener(SimpleContentEvent.RESUME,eventHandler);
        _clip.addEventListener(SimpleContentEvent.PAGE_COMPLETE,eventHandler);
        _clip.addEventListener(SimpleContentEvent.PAGE_CONTINUE, eventHandler);
        _clip.addEventListener(SimpleContentEvent.PLAY_SOUND, eventHandler);

    }

    function eventHandler(e){
        switch(e.type) {
            case SimpleContentEvent.PAUSE:
                if (_isBusy) {
                    _animationController.pause();
                    pauseSound();
                }
                break;
            case SimpleContentEvent.RESUME:
                if (_isBusy) {
                    if(_clip.name.match(/(_|\b)wait(_|\b)/)) waitPopupOnOpen();
                    var currentSoundName = getCurrentSoundName();
                    if (currentSoundName) _clip.dispatchEvent(new SimpleContentEvent(SimpleContentEvent.RESUME_SOUND, currentSoundName, true));
                    _animationController.resume();
                }
                break;
            case SimpleContentEvent.PAGE_COMPLETE:
                _clip.seen = true;
                if(_clip.name.match(/(_|\b)closeOnSeen(_|\b)/)) close();
                if(_clip.name.match(/(_|\b)continueOnSeen(_|\b)/)) checkContinue();
                    break;
            case SimpleContentEvent.PAGE_CONTINUE:
                _animationController.play();
                break;
            case SimpleContentEvent.PLAY_SOUND:
                try{
                    e.stopPropagation();
                }
                catch(error){}

                var event = new createjs.Event(SimpleContentEvent.PLAY_SOUND);
                event.detail = e.detail;
                _root.dispatchEvent(event);
                break;
        }
    }

    function pauseSound(){
        var currentSoundName = getCurrentSoundName();
        if(currentSoundName)_clip.dispatchEvent(new SimpleContentEvent(SimpleContentEvent.PAUSE_SOUND,currentSoundName,true));
    }

    function open(){
        _animationController.pageClipService.resetState();
        _clip.gotoAndStop(0);
        clearTimeout(_timeout);
        closeOtherPopups();
        openNow();
    }

    function closeOtherPopups(){
        if(_clip.parent) {
            var arr = ObjectService.getObjectFromClipByRegExp(_clip.parent, /(_|\b)popup_/, null, "MovieClip");
            for (var key in arr) {
                var popup = arr[key];
                if (popup != _clip && popup.visible && !popup.name.match(/(_|\b)stay(_|\b)/)) popup.close();
            }
        }
    }

    function openNow(){
        if(_clip.name.match(/(_|\b)wait(_|\b)/)) waitPopupOnOpen();
        _clip.dispatchEvent("ACTIVATE");
        _clip.visible= true;
        play();
    }

    function play() {
        _isBusy = true;
        _animationController.runContent();
    }

    function close(){
        stopSound();
        clearTimeout(_timeout);
        if(_clip.name.match(/(_|\b)continueOnClose(_|\b)/)){
            _clip._close = true;
        }
        stop();
        onCompleteClose();
        _clip.dispatchEvent("DEACTIVATE");
        closeOtherPopups();
    }

    function stopSound(){
        var label = _clip.currentLabel;
        if(label && label.substr(0,1) == "S"){
            var soundName = label.substr(1);
            var event = new createjs.Event(SimpleContentEvent.STOP_SOUND);
            event.detail = soundName;
            _root.dispatchEvent(event);
        }
    }

    function onCompleteClose(){
        _clip.visible= false;
        if(_clip.name.match(/(_|\b)wait(_|\b)/)) waitPopupOnClose();
        if(_clip.name.match(/(_|\b)(continueOnSeen|continueOnClose)(_|\b)/) ) checkContinue();
        _clip.gotoAndStop(0);
    }

    function stop(){
        _isBusy = false;
        _animationController.pause();
        _clip.gotoAndStop(0);
        stopSounds();
    }

    function getCurrentSoundName() {
        var currentSoundName = _clip.currentLabel;
        if(_clip.currentLabel && _clip.currentLabel.substr(0,1) == "S"){
            return _clip.currentLabel.substr(1);
        }
        return null;
    }

    function stopSounds() {
        for (var key in _clip.labels) {
            var label = _clip.labels[key];
            if(label.label.substr(0,1) == "S"){
                var soundName =  label.label.substr(1);
                var event = new createjs.Event(SimpleContentEvent.STOP_SOUND);
                event.detail = soundName;
                _clip.dispatchEvent(event,true);
            }
        }
    }

    function checkContinue(){
        //console.log('checkContinue')
        var numSeen=0;
        var numContinueSeen=0;
        var numClose=0;
        var numContinueClose=0;
        var arr = ObjectService.getObjectFromClipByRegExp(_root,/(_|\b)popup_/,null,"MovieClip");
        for (var key in arr) {
            var popup = arr[key];
            if(popup.name.match(/(_|\b)continueOnSeen(_|\b)/)) {
                numContinueSeen++;
                if(popup.seen) numSeen++;
            }
          if(popup.name.match(/(_|\b)continueOnClose(_|\b)/)) {
                numContinueClose++;

                if(popup._close){
                    numClose++;
                    //console.log(popup._close,numClose,numContinueClose,popup.name)
                }
            }
        }
        if((numContinueSeen && numSeen===numContinueSeen) || (numContinueClose && numClose===numContinueClose)){
            _root.dispatchEvent(SimpleContentEvent.PAGE_CONTINUE);
        }
    }


    function waitPopupOnClose(){
        _clip.parent.play();
        resumeParentSound();
    }

    function waitPopupOnOpen(){
        _clip.parent.stop();
        pauseParentSound();

    }

    function resumeParentSound(){
        var parent = _clip.parent;
        if(parent.currentLabel && parent.currentLabel.substr(0,1) == "S"){
            var parentSoundName = parent.currentLabel.substr(1);
            var event = new createjs.Event(SimpleContentEvent.RESUME_SOUND);
            event.detail = parentSoundName;
            parent.dispatchEvent(event,true);
        }
    }

    function pauseParentSound(){
        var parent = _clip.parent;
        if(parent.currentLabel && parent.currentLabel.substr(0,1) == "S"){
            var parentSoundName = parent.currentLabel.substr(1);
            var event = new createjs.Event(SimpleContentEvent.PAUSE_SOUND);
            event.detail = parentSoundName;
            parent.dispatchEvent(event,true);
        }
    }

    function checkIfOpenOnInit(){
        if(_clip.name.match(/(_|\b)open(_|\b)/)) open();
    }

});

//- - - - - - - - - - - - - - - - - - - - - - 50 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/widget/popup/simple/SimpleClickPopupWidget.js
/**
 * Created by tnguyen on 25.05.2016.
 */
/**
 * @class
 * @classdesc SimpleClickPopupWidget represents a button that opens a pupup.
 *
 * Usage: Reference the associated popup by using the same name-ending after "_" in its name
 *
 */
var SimpleClickPopupWidget = Class.extend(function(){
    var _clip;
    var _state;
    var _visited;
    var _popupExp;
    var _popup;
    var _root;

    this.init = function(clip){
        _clip = clip;
        _clip.gotoAndStop("out");
        _state = "out";
        configureListener();
    };

    function configureListener(){
        _clip.cursor = 'pointer';
        _clip.mouseChildren = false;
        _clip.addEventListener("mouseout",onOut);
        _clip.addEventListener("mouseover",onOver);
        _clip.addEventListener("mousedown",onDown);
        _clip.addEventListener("pressup",function(e){e.stopPropagation()});
        _clip.addEventListener("click",onClick);
        _clip.addEventListener("RESET", onReset);

        var popupName = 'popup_'+_clip.name.match(/clickPopup_[^_]+/).toString().replace("clickPopup_","");
        _popupExp = new RegExp('(_|\\b)'+popupName+'(_|\\b)');
        _root = CheckManager.getRoot(_clip);
        if(_root){
            var arr = ObjectService.getObjectFromClipByRegExp(_root,_popupExp,null,"MovieClip");
            if(arr.length){
                _popup = arr[0];
                _popup.addEventListener("DEACTIVATE",onClosePopup);

                _popup.addEventListener(SimpleContentEvent.PAGE_COMPLETE,onClipComplete);
            }
            else{
                setTimeout(onDelay,100);
            }
        }
    }

    function onDelay(){
        var popupName = 'popup_'+_clip.name.match(/clickPopup_[^_]+/).toString().replace("clickPopup_","");
        _popupExp = new RegExp('(_|\\b)'+popupName+'(_|\\b)');
        var arr = ObjectService.getObjectFromClipByRegExp(_root,_popupExp,null,"MovieClip");
        if(arr.length){
            _popup = arr[0];
            _popup.addEventListener("DEACTIVATE",onClosePopup);
            _popup.addEventListener(SimpleContentEvent.PAGE_COMPLETE,onClipComplete);
        }
    }

    function onOut(e){
        e.stopPropagation();
        if(_state == "over" || _state == "down"){
            _clip.gotoAndStop("out");
            _state = "out";
        }
    }

    function onOver(e){
        e.stopPropagation();
        if(_state == "out"){
            _clip.gotoAndStop("over");
            _state = "over";
        }
    }

    function onDown(e){
        e.stopPropagation();
        if(_state == "over"){
            _clip.gotoAndStop("down");
            _state = "down";
        }
    }

    function onClick(e){
        if(_visited){
            if(_popup.visible){
                if(_popup.close){
                    _popup.close();
                }
                else _popup.visible= false;
            }
            else{
                if(_popup.open){
                    _popup.open();
                }
                else{
                    _popup.visible = true;
                }
                if(_state == "down"){
                    tweenLabel("selected");
                }
            }
        }
        else{
            if(_state == "selected"){
                if(_popup.close){
                    _popup.close();
                }
                else{
                    _popup.visible= false;
                }
                _clip.gotoAndStop("over");
                _state = "over";
            }
            else{
                if(_popup.open){
                    _popup.open();
                }
                else{
                    _popup.visible = true;
                }
                if(CheckManager.getFrameByLabel(_clip,"selected")  && _state != "visited"){
                    tweenLabel("selected");
                }
            }
        }
    }

    function onClipComplete(e){
        _visited = true;
        tweenLabel("visited");
    }

    function tweenLabel(label){
        if(CheckManager.getFrameByLabel(_clip,label)){
            _state = label;
            if(_clip.currentLabel != label){
                _clip.gotoAndStop(label);
            }
        }
    }

    function onClosePopup(e) {
        if(!_visited){
            _clip.gotoAndStop("out");
            _state = "out";
        }
        else{
            if(!CheckManager.getFrameByLabel(_clip,"visited")){
                _clip.gotoAndStop("out");
                _state = "out";
            }
        }
    }

    function addEventListener(){
        if(_popup && !_popup.hasEventListener("DEACTIVATE")){
            _popup.addEventListener("DEACTIVATE",onClosePopup);
        }
    }

    function removeEventListener(){
        if(_popup && _popup.hasEventListener("DEACTIVATE")){
            _popup.removeEventListener("DEACTIVATE",onClosePopup);
        }
    }

    function onReset(e){
        _clip.gotoAndStop("out");
        _state = "out";
    };


});

//- - - - - - - - - - - - - - - - - - - - - - 51 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/mediator/page/exercise/simple/SimpleMCExercise.js
/**
 * Created by tnguyen on 21.03.2016.
 */
var SimpleMCExercise = SimpleExercise.extend(function(){
    var pub = this;
    var _choiceDict;
    var _choicePositionList;
    var _keepSelectionInSolution = false;


    this.init = function(clip){
        this.super.init(clip);
        pub.maxTry = pub.wrongList.length;
        pub.exerciseResultData = new SimpleExerciseResultData(pub.currentContentName+"."+clip.name,SimpleExerciseResultData.MC);

        _choiceDict = {};
        _choicePositionList = [];
        ObjectService.getObjectFromClip(clip,getChoice,"MovieClip","choice_",true);
        if(clip.name && clip.name.match(/(_|\b)(random)(_|\b)/)){
            shuffleChoice();
        }
    };

    function shuffleChoice(){
        CheckManager.shuffleList(_choicePositionList);
        var cnt=0;
        for(var key in _choiceDict){
            var clip = _choiceDict[key];
            clip.x = _choicePositionList[cnt].x;
            clip.y = _choicePositionList[cnt].y;
            cnt++;
        }
    }


    function getChoice(clip){
        if(!_choiceDict[clip.name]){
            _choicePositionList.push({x:clip.x,y:clip.y});
        }
        clip.selection.visible = false;
        clip.correct.visible = false;
        clip.wrong.visible = false;
        clip.buttonMode = true;
        clip.mouseChildren = false;

        clip.addEventListener("click",pub.choiceHandler);
        pub.preventGestureEvents(clip)
        _choiceDict[clip.name] = clip;
        if(clip.name.indexOf("correct") != -1){
            clip.state = true;
        }
        else{
            clip.state = false;
        }
    }


    this.choiceHandler = function(e){
        var clip = e.currentTarget;
        if(!pub.lock){
            if(!clip.selection.visible){
                var alt = clip.name.match(/alt_\d+/);
                if(alt){
                    for (var key in _choiceDict) {
                         if(_choiceDict[key].name.match(String(alt))) {
                            _choiceDict[key].selection.visible = false;
                         }
                    }
                }
            }
            clip.selection.visible = !clip.selection.visible;
            pub.checkVisibleCheckBtn();
        }
    };

    this.checkVisibleCheckBtn = function(){
        for(var key in _choiceDict){
            var clip = _choiceDict[key];
            if(clip.selection.visible){
                pub.checkBtn.visible = true;
                return;
            }
        }
        pub.checkBtn.visible = false;
    };

    this.showCorrect = function(){
        showFeedbackIcon();
        pub.checkBtn.visible = false;
        this.super.showCorrect();
    };

    this.showPartlyCorrect = function(){
        this.super.showPartlyCorrect();
        pub.currentTry++;
        if(pub.currentTry == pub.maxTry){
            showFeedbackIcon();
            pub.checkBtn.visible = false;
            pub.lock = true;
            if(pub.solutionBtn){
                pub.solutionBtn.visible = true;
            }
        }
    };

    this.showWrong = function(){
        this.super.showWrong();
        pub.currentTry++;
        if(pub.currentTry == pub.maxTry){
            showFeedbackIcon();
            pub.checkBtn.visible = false;
            pub.lock = true;
            if(pub.solutionBtn){
                pub.solutionBtn.visible = true;
            }
        }
    };

    this.showSolution = function(){
        showSolutionFeedbackIcon();
        this.super.showSolution();
    };

    function showSolutionFeedbackIcon(){
         for(var key in _choiceDict){
             var clip = _choiceDict[key];
             if(clip.state){
                 clip.correct.visible = true;
                 clip.wrong.visible = false;
             }
             else{
                 clip.correct.visible = false;
                 clip.wrong.visible = false;
             }
             if(!_keepSelectionInSolution) clip.selection.visible = false;
        }
    }

    function setChoice(clip,name){
        resetChoice(clip);
        ObjectService.setObjectProperty(clip.getChildByName(name),"visible",true);
    }

    this.check = function(){
        var cnt = 0;
        var totalCnt = 0;
        var resultState = "0";
        for(var key in _choiceDict){
            var clip = _choiceDict[key];
            totalCnt++;
            if(clip.selection.visible == clip.state){
                clip.isCorrect = true;
                cnt++;
            }
            else{
                clip.isCorrect = false;
            }
        }
        if(cnt == totalCnt){
            resultState = "2";
        }
        else if(cnt > 0){
            resultState = "1";
        }
        return resultState;
    };

    function showFeedbackIcon(){
        for(var key in _choiceDict){
            var clip = _choiceDict[key];
            if(clip.selection.visible){
                if(clip.isCorrect){
                    clip.correct.visible = true;
                    clip.wrong.visible = false;
                }
                else{
                    clip.correct.visible = false;
                    clip.wrong.visible = true;
                }
            }
        }
    }

    this.selectionHandler = function(e){
        this.super.selectionHandler(e);
        pub.currentTry = pub.maxTry;
        pub.check();
        showFeedbackIcon();
    };

    this.onReset = function (e){
        pub.clip.gotoAndStop(1);
        pub.reset();
    };

    this.reset = function(){
        this.super.reset();
        pub.resetChoices();
    };

    this.resetChoices = function(){
        for(var key in _choiceDict){
            var clip = _choiceDict[key];
            resetChoice(clip);
        }
    };

    function resetChoice(clip){
        clip.isCorrect = false;
        if(clip.selection){
            clip.selection.visible = false;
        }
        if(clip.correct){
            clip.correct.visible = false;
        }
        if(clip.wrong){
            clip.wrong.visible = false;
        }
    }

    this.getInput = function(){
        var inputObj = {};
        for(var key in _choiceDict){
            var clip = _choiceDict[key];
            inputObj[key] = {selection:clip.selection.visible,isCorrect:clip.isCorrect};
        }
        return inputObj;
    };

    this.setInput = function(data){
        pub.reset();
        for(var key in _choiceDict){
            var clip = _choiceDict[key];
            clip.selection.visible = data[key].selection;
        }
    };

    Object.defineProperty(this,"choiceDict",{
        get: function(){
            return _choiceDict;
        }
    });


    Object.defineProperty(this,"showFeedbackIcon",{
        get: function(){
            return showFeedbackIcon;
        }
    });

    Object.defineProperty(this,"keepSelectionInSolution",{
        set: function (value){
            _keepSelectionInSolution = value;
        }
    });


});

//- - - - - - - - - - - - - - - - - - - - - - 52 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/mediator/page/exercise/simple/SimpleSCExercise.js
/**
 * Created by tnguyen on 21.03.2016.
 */
var SimpleSCExercise = SimpleMCExercise.extend(function(){
    var pub = this;

    this.init = function(clip){
        this.super.init(clip);
        pub.exerciseResultData = new SimpleExerciseResultData(pub.currentContentName+clip.name,SimpleExerciseResultData.SC);
    };

    this.choiceHandler = function(e) {
        var clip = e.currentTarget;
        if (!pub.lock) {
            this.resetChoices();
            clip.selection.visible = true;
            this.checkVisibleCheckBtn();
        }
        this.check();
    }
});

//- - - - - - - - - - - - - - - - - - - - - - 53 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/mediator/page/exercise/simple/SimpleDDExercise.js
/**
 * Created by tnguyen on 11.04.2016.
 */
var SimpleDDExercise = SimpleExercise.extend(function() {
    var pub = this;
    var _dragDict;
    var _dropDict;
    var _currentDrag;

    this.init = function(clip){
        this.super.init(clip);
        pub.maxTry = pub.wrongList.length;
        pub.exerciseResultData = new SimpleExerciseResultData(pub.currentContentName+clip.name,SimpleExerciseResultData.DD);

        _dragDict = new Object();
        _dropDict = new Object();
        ObjectService.getObjectFromClip(pub.clip,getDrag,"MovieClip","drag_",true);
        ObjectService.getObjectFromClip(pub.clip,getDrop,"MovieClip","drop_",true);
    };


    this.showCorrect = function(){
        showFeedbackIcon();
        this.super.showCorrect();
        pub.checkBtn.visible = false;
    };

    this.showPartlyCorrect = function(){
        showFeedbackIcon();
        this.super.showPartlyCorrect();
    };

    this.showWrong = function(){
        this.super.showWrong();
        pub.currentTry++;
        showFeedbackIcon();
        if(pub.currentTry == pub.maxTry){
            pub.checkBtn.visible = false;
            pub.lock = true;
            if(pub.solutionBtn){
                pub.solutionBtn.visible = true;
            }
        }
    };

    this.showSolution = function(){
        resetDrags();
        resetDrops();
        this.super.showSolution();
        var time = 1;
        for(var key in _dragDict){
            var drag = _dragDict[key];
            if(!isDragInLastInputCorrect(drag.id)){
                var drop = getEmptyDrop(drag);
                if(drop){
                    drop.currentDrag = drag;
                    var dropPoint = CheckManager.getLocalPoint(drop,drag);
                    Tweener.addTween(drag,{x:dropPoint.x,y:dropPoint.y,time:time,overwrite:true});
                }
                else{
                    Tweener.addTween(drag,{x:drag.startPoint.x,y:drag.startPoint.y,time:time,overwrite:true});
                }
            }
            drag.isCorrect = true;
        }
    };

    this.showLabel = function(list){
        if(list){
            var length = pub.currentTry;
            for(var i=pub.currentTry;i>-1;i--){
                if(list[i]){
                    if(pub.clip.currentLabel != list[i]){
                        pub.playSound(list[i]);
                        pub.clip.gotoAndStop(list[i]);
                        CheckManager.tweenToFrame(pub.clip,CheckManager.getLastFrameOfLabel(pub.clip,list[i]),NaN,pub.onShowLabelComplete,list[i]);
                        return;
                    }
                }
            }
        }
    };

    function getEmptyDrop(drag){
        var list = drag.dropIdList;
        if(list){
            var length = list.length;
            for(var i=0;i<length;i++){
                if(_dropDict[list[i]].currentDrag == null && !isDropInLastInputCorrect(list[i])){
                    return _dropDict[list[i]];
                }
            }
        }
        return null;
    }

    function isDropInLastInputCorrect(dropId){
        if(pub.exerciseResultData.resultList.length){
            var inputObj = pub.exerciseResultData.resultList[pub.exerciseResultData.resultList.length-1].input;
            for(var key in inputObj){
                var obj = inputObj[key];
                if(obj.currentDropId == dropId && obj.isCorrect){
                    return true;
                }
            }
        }
        return false;
    }


    function showFeedbackIcon(){
        for(var key in _dragDict){
            var drag = _dragDict[key];
            if(getCurrentDrop(drag)){
                if(drag.isCorrect){
                    drag.correct.visible = true;
                    drag.wrong.visible = false;
                }
                else{
                    if(pub.currentTry == pub.maxTry){
                        drag.correct.visible = false;
                        drag.wrong.visible = true;
                    }
                }
            }
            else{
                drag.correct.visible = false;
                drag.wrong.visible = false;
            }
        }
    }

    this.check = function(){
        var cnt = 0;
        var totalCnt = 0;
        var resultState = "0";
        for(var key in _dragDict){
            var drag = _dragDict[key];
            totalCnt++;
            if(pub.isDragCorrect(drag)){
                cnt++;
                drag.isCorrect = true;
            }
            else{
                drag.isCorrect = false;
            }
        }
        if(cnt == totalCnt){
            resultState = "2";
        }
        else if(cnt > 0){
            resultState = "1";
        }
        return resultState;
    };

    this.isDragCorrect = function(drag){
        for(var key in _dropDict){
            var drop = _dropDict[key];
            if(drop.currentDrag == drag){
                if(drag.dropIdList && drag.dropIdList.indexOf(drop.id) != -1){
                    return true;
                }
                else{
                    return false;
                }
            }
        }
        if(drag.dropIdList == null){
            return true;
        }
        return false;
    };

    function isDragInLastInputCorrect(dragId){
        if(pub.exerciseResultData.resultList.length){
            var inputObj = pub.exerciseResultData.resultList[pub.exerciseResultData.resultList.length-1].input;
            for (var key in inputObj){
                if(key == dragId && inputObj[key].isCorrect){
                    return true;
                }
            }
        }
        return false;
    }

    function getDrag(clip){
        clip.id = getId(clip.name);
        _dragDict[clip.id] = clip;
        clip.correct.visible = false;
        clip.wrong.visible = false;
        clip.dropIdList = getDropIdList(clip.name);
        clip.startPoint = {x:clip.x,y:clip.y};
        clip.addEventListener("mousedown",onDown);
    }

    function getDrop(clip){
        clip.id = getId(clip.name);
        _dropDict[clip.id] = clip;
    }

    function getId(name){
        var parts = name.split('_');
        return parts[1] || name;
    }

    function getDropIdList(name){
        var list = name.split("_");
        if(list.length > 2){
            return list.slice(2);
        }
        return null;
    }

    function onDown(e){
        e.stopPropagation();
        if(!pub.lock){
            _currentDrag = e.currentTarget;
            if(!_currentDrag.isCorrect || (_currentDrag.isCorrect && isDragOnStartPoint(_currentDrag))){
                var localPos = _currentDrag.parent.globalToLocal(_currentDrag.stage.mouseX, _currentDrag.stage.mouseY);
                var deltaX = localPos.x - _currentDrag.x;
                var deltaY = localPos.y - _currentDrag.y;
                _currentDrag.deltaPosition = {x:deltaX,y:deltaY};
                _currentDrag.stage.addEventListener("pressmove",onMove);
                _currentDrag.parent.setChildIndex(_currentDrag,_currentDrag.parent.numChildren-1);
                _currentDrag.stage.addEventListener("pressup",onUp);
            }
        }
    }

    function onMove(e){
        var localPos = _currentDrag.parent.globalToLocal(_currentDrag.stage.mouseX, _currentDrag.stage.mouseY);
        _currentDrag.x = localPos.x - _currentDrag.deltaPosition.x;
        _currentDrag.y = localPos.y - _currentDrag.deltaPosition.y;
    }

    function isDragOnStartPoint(drag){
        if(drag.x != drag.startPoint.x || drag.y != drag.startPoint.y){
            return false;
        }
        else{
            return true;
        }
    }

    function onUp(e){
        _currentDrag.stage.removeEventListener("pressmove",onMove);
        _currentDrag.stage.removeEventListener("pressup",onUp);
        checkDragDrop();
    }

    function checkDragDrop(){
        for(var key in _dropDict){
            var drop = _dropDict[key];
            var localPos = drop.globalToLocal(drop.stage.mouseX, drop.stage.mouseY);
            if(drop.hitTest(localPos.x,localPos.y)){
                if(drop.currentDrag){
                    moveBack(drop.currentDrag);
                }
                cleanDrag(_currentDrag);
                var dropPoint = CheckManager.getLocalPoint(drop,_currentDrag);
                Tweener.addTween(_currentDrag,{x:dropPoint.x,y:dropPoint.y,time:0.5,overwrite:true});
                drop.currentDrag = _currentDrag;
                checkVisibleCheckBtn();
                return;
            }
        }

        moveBack(_currentDrag);
        cleanDrag(_currentDrag);
        checkVisibleCheckBtn();
    }

    function moveBack(drag){
        Tweener.addTween(drag,{x:drag.startPoint.x,y:drag.startPoint.y,time:0.5,overwrite:true});
    }

    function cleanDrag(drag){
        for(var key in _dropDict){
            var drop = _dropDict[key];
            if(drop.currentDrag == drag){
                drop.currentDrag = null;
            }
        }
    }

    function checkVisibleCheckBtn(){
        for(var key in _dropDict){
            var drop = _dropDict[key];
            if(drop.currentDrag){
                pub.checkBtn.visible = true;
                return;
            }
        }
        pub.checkBtn.visible = false;
    }

    this.selectionHandler = function(e){
        //console.log("selectionHandler");
        this.super.selectionHandler(e);
        pub.currentTry = pub.maxTry;
        showFeedbackIcon();
    };

    this.getInput = function(){
        var inputObj = {};
        for(var key in _dragDict){
            var drag = _dragDict[key];
            var currentDrop = getCurrentDrop(drag);
            var currentDropId = currentDrop?currentDrop.id:null;
            inputObj[key] = {currentDropId:currentDropId,isCorrect:drag.isCorrect};
        }
        return inputObj;
    };

    this.setInput = function(data){
        pub.reset();
        var time = 1;
        for(var key in data){
            var drag = _dragDict[key];
            if(data[key].currentDropId){
                var drop = _dropDict[data[key].currentDropId];
                drop.currentDrag = drag;
                drag.isCorrect = data[key].isCorrect;
                var dropPoint = CheckManager.getLocalPoint(drop,drag);
                Tweener.addTween(drag,{x:dropPoint.x,y:dropPoint.y,time:time,overwrite:true});
            }
            else{
                Tweener.addTween(drag,{x:drag.startPoint.x,y:drag.startPoint.y,time:time,overwrite:true});
            }
        }
    };

    this.onReset = function (e){
        pub.clip.gotoAndStop(1);
        pub.reset();
        this.super.reset();
        pub.moveDragsBack();
    };

    this.reset = function(){
        resetDrags();
        resetDrops();
        pub.currentTry = 0;
    };

    function resetDrags(){
        for(var key in _dragDict){
            var drag = _dragDict[key];
            drag.isCorrect = null;
            drag.correct.visible = false;
            drag.wrong.visible = false;
        }
    }

    function resetDrops(){
        for(var key in _dropDict){
            var drop = _dropDict[key];
            drop.currentDrag = null;
        }
    }

    this.moveDragsBack = function() {
        for(var key in _dragDict){
            var drag = _dragDict[key];
            moveBack(drag);
        }
    };

    function getCurrentDrop(drag){
        for(var key in _dropDict){
            var drop = _dropDict[key];
            if(drop.currentDrag == drag){
                return drop;
            }
        }
        return null;
    }

    Object.defineProperty(this,"dragDict",{
        get: function(){
            return _dragDict;
        },
        set: function(value){
            _dragDict = value;
        }
    });

    Object.defineProperty(this,"dropDict",{
        get: function(){
            return _dropDict;
        },
        set: function(value){
            _dropDict = value;
        }
    });


});

//- - - - - - - - - - - - - - - - - - - - - - 54 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/config/porscheaftersales/PorscheAftersalesGlobalConfig.js
/**
 * Created by cduerbeck on 24.09.18.
 */

var GLOBAL_CONFIG = {sysDict:{},proxyDict:{}, mediatorDict:{}, commandDict:{}, exerciseDict:{},contentDict:{}};

GLOBAL_CONFIG.assetList = [
    {name:"StructureProxy",path:"assets/xml/structure.xml"},
    {name:"frameText",path:"assets/xml/frameText.xml"},
    {name:"frameContent",path:"assets/content/frameContent.js"}
]

GLOBAL_CONFIG.startList = [
    "lib/extend.min.js"
]

GLOBAL_CONFIG.coreList = [
    "lib/createjs-2015.11.26.min.js",
    "lib/monster.cjs.ext.js",
    "lib/monster.text.v5.ext.js",
    "lib/tw.js",
    "de/fkc/utils/behavior/behaviorDraggable.js",
    "de/fkc/utils/behavior/behaviorLayout.js",
    "lib/cjs.ext.timeline.js",
    "de/fkc/utils/fontloader/FontLoader.js",
    "de/fkc/utils/event/EventDispatcher.js",
    "de/fkc/utils/classmanager/ClassLoader.js",
    "de/fkc/utils/classmanager/ClassListLoader.js",
    "de/fkc/utils/classmanager/ClassManager.js",
    "de/fkc/utils/soundmanager/porschee3/SoundManager.js",
    "de/fkc/utils/objectservice/ObjectService.js",
    "de/fkc/utils/checkmanager/CheckManager.js",
    "de/fkc/main/simple/AssetManager.js",
    "de/fkc/simplemvc/Facade.js",
    "de/fkc/simplemvc/Proxy.js",
    "de/fkc/simplemvc/Mediator.js",
    "de/fkc/simplemvc/Command.js",
    "de/fkc/simplemvc/Notification.js",
    "de/fkc/command/simple/StartupCommand.js",
    "de/fkc/config/simple/Config.js",
    "de/fkc/proxy/structure/simple/Data.js",
    "de/fkc/proxy/structure/simple/StructureEvent.js",
    "de/fkc/mediator/simple/SimpleMediator.js",
    "de/fkc/mediator/simple/SimpleBtnMediator.js",
    "de/fkc/mediator/page/exercise/simple/SimpleExercise.js",
    "de/fkc/mediator/page/exercise/simple/SimpleExerciseResultData.js",
    "de/fkc/utils/simple/SimpleClick.js",
    "de/fkc/proxy/view/simple/ViewData.js",
    "de/fkc/mediator/page/simple/AnimationController.js",
    "de/fkc/mediator/page/simple/SimplePageController.js",
    "de/fkc/utils/simple/v2/SimplePageClipService.js",
    "de/fkc/mediator/page/simple/SimpleContentEvent.js",
    "de/fkc/utils/textservice/TextService.js",
    "de/fkc/proxy/user/simple/PipwerksAdapter.js",
    "de/fkc/widget/scroller/simple/SimpleScroller.js",
    "de/fkc/widget/scroller/simple/SimpleScrollerControl.js",
    "de/fkc/proxy/user/simple/UserData.js",
    "de/fkc/utils/components/FrameStepper.js",
    "de/fkc/utils/components/RatingBox.js",
    "de/fkc/utils/components/StopWatch.js",
    "de/fkc/utils/components/FrameStepper.js",
    "de/fkc/utils/components/StopWatch.js",
    "de/fkc/mediator/content/simple/SimpleContentMediator.js",
    "de/fkc/mediator/view/simple/SimpleViewMediator.js",
    "de/fkc/widget/slide/simple/SimpleSlideWidget.js",
    "de/fkc/mediator/menu/porschepanamerast/PorschePanameraStInfoMenu.js",
    "de/fkc/widget/popup/simple/SimplePopupWidget.js",
    "de/fkc/widget/popup/simple/SimpleClickPopupWidget.js",

    "de/fkc/mediator/page/exercise/simple/SimpleMCExercise.js",
    "de/fkc/mediator/page/exercise/simple/SimpleSCExercise.js",
    "de/fkc/mediator/page/exercise/simple/SimpleDDExercise.js"

]


GLOBAL_CONFIG.startList.push("de/fkc/config/porscheaftersales/PorscheAftersalesGlobalConfig.js");
GLOBAL_CONFIG.startList.push("de/fkc/main/simple/v2/Main.js");

GLOBAL_CONFIG.proxyDict["ConfigProxy"] = {proxy:"de/fkc/proxy/config/simple/ConfigProxy.js"};
GLOBAL_CONFIG.proxyDict["UserProxy"] = {proxy:"de/fkc/proxy/user/simple/UserProxy.js",data:"de/fkc/proxy/user/simple/UserData.js"};
GLOBAL_CONFIG.proxyDict["StructureProxy"] = {proxy:"de/fkc/proxy/structure/simple/StructureProxy.js",data:"de/fkc/proxy/structure/simple/v2/StructureData.js",params:["de/fkc/proxy/structure/simple/v2/ChapterData.js","de/fkc/proxy/structure/simple/v2/PageData.js"]};
GLOBAL_CONFIG.proxyDict["ViewProxy"] = {proxy:"de/fkc/proxy/view/simple/ViewProxy.js",data:"de/fkc/proxy/view/simple/ViewData.js"};
GLOBAL_CONFIG.proxyDict["ContentProxy"] = {proxy:"de/fkc/proxy/content/simple/ContentProxy.js"};
GLOBAL_CONFIG.proxyDict["GlossaryProxy"] = {proxy:"de/fkc/proxy/xml/simple/XMLProxy.js"};

GLOBAL_CONFIG.mediatorDict["ExitBtnMediator"] = "de/fkc/mediator/exit/porscheaftersales/PorscheAftersalesExitBtnMediator.js";
GLOBAL_CONFIG.mediatorDict["ExitDialogMediator"] = "de/fkc/mediator/exit/simple/SimpleExitDialogMediator.js";
GLOBAL_CONFIG.mediatorDict["ImprintBtnMediator"] = "de/fkc/mediator/imprint/simple/SimpleImprintBtnMediator.js";
GLOBAL_CONFIG.mediatorDict["ImprintMediator"] = "de/fkc/mediator/imprint/porschepanamerast/PorschePanameraStImprintMediator.js";
GLOBAL_CONFIG.mediatorDict["HelpBtnMediator"] = "de/fkc/mediator/help/simple/SimpleHelpBtnMediator.js";
GLOBAL_CONFIG.mediatorDict["HelpMediator"] = "de/fkc/mediator/help/porschepanamerast/PorschePanameraStHelpMediator.js";
GLOBAL_CONFIG.mediatorDict["PreviousBtnMediator"] = "de/fkc/mediator/previous/simple/SimplePreviousBtnMediator.js";
GLOBAL_CONFIG.mediatorDict["NextBtnMediator"] = "de/fkc/mediator/next/simple/SimpleNextBtnMediator.js";
GLOBAL_CONFIG.mediatorDict["PauseResumeBtnMediator"] = "de/fkc/mediator/pauseresume/simple/SimplePauseResumeBtnMediator.js";
GLOBAL_CONFIG.mediatorDict["ReloadBtnMediator"] = "de/fkc/mediator/reload/simple/SimpleReloadBtnMediator.js";
GLOBAL_CONFIG.mediatorDict["SoundBtnMediator"] = "de/fkc/mediator/sound/simple/SimpleSoundBtnMediator.js";
GLOBAL_CONFIG.mediatorDict["SubtitleBtnMediator"] = "de/fkc/mediator/subtitle/simple/SimpleSubtitleBtnMediator.js";
GLOBAL_CONFIG.mediatorDict["SubtitleMediator"] = "de/fkc/mediator/subtitle/simple/SimpleSubtitleMediator.js";
GLOBAL_CONFIG.mediatorDict["MenuBtnMediator"] = "de/fkc/mediator/menu/simple/SimpleMenuBtnMediator.js";
GLOBAL_CONFIG.mediatorDict["MenuMediator"] = "de/fkc/mediator/menu/porscheserviceberater/PorscheServiceberaterMenuMediator.js";
GLOBAL_CONFIG.mediatorDict["InfopoolBtnMediator"] = "de/fkc/mediator/infopool/simple/SimpleInfopoolBtnMediator.js";
GLOBAL_CONFIG.mediatorDict["InfopoolMediator"] = "de/fkc/mediator/infopool/porschepanamerast/PorschePanameraStInfopoolMediator.js";
GLOBAL_CONFIG.mediatorDict["GlossaryBtnMediator"] = "de/fkc/mediator/glossary/simple/SimpleGlossaryBtnMediator.js";
GLOBAL_CONFIG.mediatorDict["GlossaryMediator"] = "de/fkc/mediator/glossary/simple/SimpleGlossaryMediator.js";
GLOBAL_CONFIG.mediatorDict["ContentMediator"] = "de/fkc/mediator/content/porscheaftersales/PorscheAftersalesContentMediator.js";
GLOBAL_CONFIG.mediatorDict["IndexMediator"] = "de/fkc/mediator/index/simple/SimpleIndexMediator.js";
GLOBAL_CONFIG.mediatorDict["HeaderMediator"] = "de/fkc/mediator/header/simple/SimpleHeaderMediator.js";
GLOBAL_CONFIG.mediatorDict["BackgroundMediator"] = "de/fkc/mediator/background/simple/SimpleBackgroundMediator.js";
GLOBAL_CONFIG.mediatorDict["WrapperMediator"] = "de/fkc/mediator/wrapper/simple/SimpleWrapperMediator.js";
GLOBAL_CONFIG.mediatorDict["StartMobileBtnMediator"] = "de/fkc/mediator/startmobile/simple/SimpleStartMobileBtnMediator.js";
GLOBAL_CONFIG.mediatorDict["NavigationMediator"] = "de/fkc/mediator/navigation/porscheserviceberater/PorscheServiceberaterNavigationMediator.js";
GLOBAL_CONFIG.mediatorDict["_PreloaderMediator"] = "de/fkc/mediator/preloader/simple/SimplePreloaderMediator.js";
GLOBAL_CONFIG.mediatorDict["_ViewMediator"] = "de/fkc/mediator/view/porschepanamerast/PorschePanameraStViewMediator.js";
GLOBAL_CONFIG.mediatorDict["VideoBtnMediator"] = "de/fkc/mediator/video/porschepanamerast/PorschePanameraStVideoBtnMediator.js";
GLOBAL_CONFIG.mediatorDict["VideoMediator"] = "de/fkc/mediator/video/porschepanamerast/PorschePanameraStVideoMediator.js";
GLOBAL_CONFIG.mediatorDict["ContinueBtnMediator"] = "de/fkc/mediator/continue/porschepanamerast/PorschePanameraStContinueBtnMediator.js";
GLOBAL_CONFIG.mediatorDict["SitemapBtnMediator"] = "de/fkc/mediator/sitemap/porscheaftersales/PorscheAfersalesSitemapBtnMediator.js";
GLOBAL_CONFIG.mediatorDict["SitemapMediator"] = "de/fkc/mediator/sitemap/porscheaftersales/PorscheAftersalesSitemapMediator.js";
GLOBAL_CONFIG.mediatorDict["BlankMediator_popup_100"] = "de/fkc/mediator/simple/SimpleMediator.js";
GLOBAL_CONFIG.mediatorDict["SlideshowBtnMediator"] = "de/fkc/mediator/slideshow/porschepanamerast/PorschePanameraStSlideshowBtnMediator.js";
GLOBAL_CONFIG.mediatorDict["SlideshowMediator"] = "de/fkc/mediator/slideshow/porschepanamerast/PorschePanameraStSlideshowMediator.js";

GLOBAL_CONFIG.commandDict["INIT_COMMAND"] = "de/fkc/command/simple/InitCommand.js";
GLOBAL_CONFIG.commandDict["IMPORT_DATA_COMMAND"] = "de/fkc/command/simple/ImportDataCommand.js";
GLOBAL_CONFIG.commandDict["INIT_PROXY_COMMAND"] = "de/fkc/command/simple/InitProxyCommand.js";
GLOBAL_CONFIG.commandDict["INIT_MEDIATOR_COMMAND"] = "de/fkc/command/simple/InitMediatorCommand.js";
GLOBAL_CONFIG.commandDict["INIT_START_COMMAND"] = "de/fkc/command/porscheaftersales/PorscheAftersalesInitStartCommand.js";
GLOBAL_CONFIG.commandDict["SETUP_CONTENT_COMMAND"] = "de/fkc/command/simple/SetupContentCommand.js";
GLOBAL_CONFIG.commandDict["UNLOAD_CONTENT_COMMAND"] = "de/fkc/command/simple/UnloadContentCommand.js";
GLOBAL_CONFIG.commandDict["LOAD_CONTENT_COMMAND"] = "de/fkc/command/simple/LoadContentCommand.js";
GLOBAL_CONFIG.commandDict["REGISTER_CONTENT_COMMAND"] = "de/fkc/command/simple/RegisterContentCommand.js";
GLOBAL_CONFIG.commandDict["INIT_CONTENT_COMMAND"] = "de/fkc/command/simple/InitContentCommand.js";
GLOBAL_CONFIG.commandDict["SET_VIEW_COMMAND"] = "de/fkc/command/simple/SetViewCommand.js";
GLOBAL_CONFIG.commandDict["NEXT_COMMAND"] = "de/fkc/command/simple/NextCommand.js";
GLOBAL_CONFIG.commandDict["NEXT_PAGE_COMMAND"] = "de/fkc/command/simple/NextPageCommand.js";
GLOBAL_CONFIG.commandDict["PREVIOUS_COMMAND"] = "de/fkc/command/simple/PreviousCommand.js";
GLOBAL_CONFIG.commandDict["PREVIOUS_PAGE_COMMAND"] = "de/fkc/command/simple/PreviousPageCommand.js";
GLOBAL_CONFIG.commandDict["SOUND_COMMAND"] = "de/fkc/command/simple/SoundCommand.js";
GLOBAL_CONFIG.commandDict["RELOAD_COMMAND"] = "de/fkc/command/simple/ReloadCommand.js";
GLOBAL_CONFIG.commandDict["PAUSE_COMMAND"] = "de/fkc/command/simple/PauseCommand.js";
GLOBAL_CONFIG.commandDict["RESUME_COMMAND"] = "de/fkc/command/simple/ResumeCommand.js";
GLOBAL_CONFIG.commandDict["STRUCTURE_DATA_COMMAND"] = "de/fkc/command/porscheaftersales/PorscheAftersalesStructurdataCommand.js";
GLOBAL_CONFIG.commandDict["USER_DATA_COMMAND"] = "de/fkc/command/simple/UserDataCommand.js";
GLOBAL_CONFIG.commandDict["PAGE_COMPLETE_COMMAND"] = "de/fkc/command/simple/PageCompleteCommand.js";
GLOBAL_CONFIG.commandDict["START_MOBILE_COMMAND"] = "de/fkc/command/porscheaftersales/PorscheAftersalesStartMobileCommand.js";
GLOBAL_CONFIG.commandDict["COMPLETED_COMMAND"] = "de/fkc/command/simple/CompletedCommand.js";
GLOBAL_CONFIG.commandDict["GOTO_PAGE_COMMAND"] = "de/fkc/command/simple/GoToPageCommand.js";


GLOBAL_CONFIG.exerciseDict[/(_|\b)(MCExercise)(_|\b)/] = "de/fkc/mediator/page/exercise/simple/SimpleMCExercise.js";
GLOBAL_CONFIG.exerciseDict[/(_|\b)(SCExercise)(_|\b)/] = "de/fkc/mediator/page/exercise/simple/SimpleSCExercise.js";
GLOBAL_CONFIG.exerciseDict[/(_|\b)(DDExercise)(_|\b)/] = "de/fkc/mediator/page/exercise/simple/SimpleDDExercise.js";
GLOBAL_CONFIG.exerciseDict[/(_|\b)(SpecificSCExercise)(_|\b)/] = "de/fkc/mediator/page/exercise/simple/SimpleSpecificSCExercise.js";
GLOBAL_CONFIG.exerciseDict[/(_|\b)(FrameStepperExercise)(_|\b)/] = "de/fkc/mediator/page/exercise/innocorp/FrameStepperExercise.js";
GLOBAL_CONFIG.exerciseDict[/(_|\b)SliderExercise(_|\b)/] = "de/fkc/mediator/page/exercise/porscheaftersales/PorscheAftersalesSliderExercise.js";
GLOBAL_CONFIG.exerciseDict[/(_|\b)DDCheckTargetsExercise(_|\b)/] = "de/fkc/mediator/page/exercise/porscheaftersales/PorscheAftersalesDDCheckTargetsExercise.js";


GLOBAL_CONFIG.exerciseDict[/(_|\b)clickPopup_[^_]+/] = "de/fkc/widget/popup/porschepanamerast/PorschePanameraStClickPopupWidget.js";
GLOBAL_CONFIG.exerciseDict[/(_|\b)popup_[^_]+/] = "de/fkc/widget/popup/porscheaftersales/PorscheAftersalesPopupWidget.js";
GLOBAL_CONFIG.exerciseDict[/(_|\b)scrollerWidget(_|\b)/] = "de/fkc/widget/scroller/simple/SimpleScrollerWidget.js";
GLOBAL_CONFIG.exerciseDict[/(_|\b)videoPlayer(_|\b)/] = "de/fkc/widget/videoplayer/porschepanamerast/PorschePanameraStVideoPlayerWidget.js";
GLOBAL_CONFIG.exerciseDict[/(_|\b)slideWidget\d*(_|\b)/] = "de/fkc/widget/slide/porschepanamerast/PorschePanameraStSlideWidget.js";
GLOBAL_CONFIG.exerciseDict[/(_|\b)slideShowWidget\d*(_|\b)/] = "de/fkc/widget/slide/porscheaftersales/PorscheAftersalesSlideShowWidget.js";
GLOBAL_CONFIG.exerciseDict[/(_|\b)linkWidget\d*(_|\b)/] = "de/fkc/widget/link/simple/SimpleLinkWidget.js";
GLOBAL_CONFIG.exerciseDict[/(_|\b)button\d*(_|\b)/] = "de/fkc/widget/button/simple/v2/SimpleButtonWidget.js";
GLOBAL_CONFIG.exerciseDict[/(_|\b)continueButtonWidget\d*(_|\b)/] = "de/fkc/widget/button/porschepanamerast/PorschePanameraStContinueButtonWidget.js";
GLOBAL_CONFIG.exerciseDict[/(_|\b)togglePlayButtonWidget\d*(_|\b)/] = "de/fkc/widget/button/porscheaftersales/PorscheAftersalesTogglePlayButtonWidget.js";
GLOBAL_CONFIG.exerciseDict[/(_|\b)slideURIWidget\d*(_|\b)/] = "de/fkc/widget/slide/porscheaftersales/PorscheAftersalesURISlideWidget.js";

GLOBAL_CONFIG.exerciseDict[/(_|\b)scrollToTopButtonWidget\d*(_|\b)/] = "de/fkc/widget/button/porscheserviceberater/PorscheServiceberaterScrollToTopButtonWidget.js";
GLOBAL_CONFIG.exerciseDict[/(_|\b)exitButtonWidget\d*(_|\b)/] = "de/fkc/widget/button/porschepanamerast/PorschePanameraStExitButtonWidget.js";
GLOBAL_CONFIG.exerciseDict[/(_|\b)toggleButtonWidget\d*(_|\b)/] = "de/fkc/widget/button/porschepanamerast/PorschePanameraStToggleButtonWidget.js";


GLOBAL_CONFIG.exerciseDict[/(_|\b)timelineJumpWidget\d*(_|\b)/] = "de/fkc/widget/slide/porscheserviceberater/PorscheServiceberaterTimelineJumpWidget.js";
GLOBAL_CONFIG.exerciseDict[/(_|\b)menuButtonWidget\d*(_|\b)/] = "de/fkc/widget/button/porschepanamerast/PorschePanameraStMenuButtonWidget.js";
GLOBAL_CONFIG.exerciseDict[/(_|\b)soundPlayWidget\d*(_|\b)/] = "de/fkc/widget/sound/porscheaftersales/PorscheAftersalesSoundPlayWidget.js";

GLOBAL_CONFIG.contentDict["standard"] = "de/fkc/mediator/page/simple/SimplePageMediator.js";



//- - - - - - - - - - - - - - - - - - - - - - 55 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/main/simple/v2/Main.js
/**
 * Created by tnguyen on 19.04.2016.
 * copied and modified for modernization by unlce tilo
 */
var Main = Class.extend(function () {
    var pub = this;
    var _cnt;
    var _classList;
    var _assetList;
    var _assetManager;
    var _stage;
    var _preloader;
    var _srcPath = '../_sys/';

    this.constructor = function () {
        window.addEventListener('load', initSys);
    };

    function initSys() {

        if (!document.getElementById('canvas')) {
            return;
        }

        _cnt = 0;
        _assetList = pub.initAsset();
        _classList = pub.initClass();

        if (window["createjs"]) {
            loadPreloader();
        } else {
            loadScript(_classList[_cnt]);
        }
    }

    function loadScript(path) {
        var node = document.createElement('script');
        node.setAttribute('type', 'text/javascript');
        node.setAttribute('src', _srcPath + path);
        node.onload = onLoad;
        document.getElementsByTagName('head')[0].appendChild(node);
    }

    function onLoad(e) {
        _cnt++;
        if (_classList.length == _cnt) {
            loadPreloader();
        }
        else {
            loadScript(_classList[_cnt]);
        }
    }

    function loadPreloader() {
        ClassManager.load("assets/content/preloader.js", "loadPreloader");
        ClassManager.addComplete("loadPreloader", onCompletePreloaderClass);
    }

    function onCompletePreloaderClass() {
        loadManifest(onCompletePreloader, onCompletePreloader);
    }

    function loadManifest(errorCallback, completeCallback) {
        var loader = new createjs.LoadQueue(false);
        loader.addEventListener("fileload", handleFileLoad);
        loader.addEventListener("error", errorCallback);
        loader.addEventListener("complete", completeCallback);
        loader.loadManifest(lib.properties.manifest);
    }

    function handleFileLoad(e) {
        if (e.item.type == "image") {
            images[e.item.id] = e.result;
        }
    }

    function onCompletePreloader(e) {
        initStage();
        initPreloader();
        new FontLoader(initApp);
    }

    function initApp() {
        configureListener();
        loadAsset();
    }

    function initStage() {
        var canvas = document.getElementById("canvas");
        canvas.addEventListener('click', function () {
            window.focus()
        });
        _stage = new createjs.Stage(canvas);
        _stage.enableMouseOver(10);
        createjs.Touch.enable(_stage);
        _stage.update();
    }

    function initPreloader() {
        _preloader = new lib["preloader"]();
        _preloader.name = "preloader";
        _stage.addChild(_preloader);
    }

    function configureListener() {
        createjs.Ticker.setFPS(lib.properties.fps);
        createjs.Ticker.addEventListener("tick", _stage);
        window.addEventListener("resize", onResize);
        onResize();
    }

    function onResize(e) {
        if (_preloader) {
            _preloader.x = window.innerWidth / 2 - _preloader.nominalBounds.width / 2;
            _preloader.y = window.innerHeight / 2 - _preloader.nominalBounds.height / 2;
        }
    }

    function loadAsset() {
        _assetManager = new AssetManager();
        _assetManager.addEvent("COMPLETE", onCompleteAsset);
        _assetManager.loadAssets(_assetList);
    };

    function onCompleteAsset(e) {
        loadManifest(assetManifestComplete, assetManifestComplete);
    }

    function assetManifestError(e) {
        console.log("manifestError");
    }

    function assetManifestComplete(e) {
        // make sure that frameContent ist staged completely on start:
        _stage.addEventListener('staged', onAssetsStaged);
        for (var i = 0; i < _assetManager.assetList.length; i++) {
            if (_assetManager.assetList[i].type == "js") {
                var data = new lib[_assetManager.assetList[i].name]();
                if (_assetManager.assetList[i].add != false) {
                    data.visible = false;
                    _stage.addChild(data);
                }
                _assetManager.assetList[i].data = data;
            }
        }
    }

    function onAssetsStaged(e) {
        _stage.removeEventListener('staged', onAssetsStaged);
        pub.start(_stage, _assetManager);
    }

    this.initAsset = function () {
        return GLOBAL_CONFIG.assetList;
    };

    this.initClass = function () {
        return GLOBAL_CONFIG.coreList;
    };

    this.start = function (stage, assetManager) {
        var config = new Config(stage, assetManager);
        config.init(
            {}, // sysdict is deprecated! use GLOBAL_CONFIG.coreList for file-paths
            GLOBAL_CONFIG.proxyDict,
            GLOBAL_CONFIG.mediatorDict,
            GLOBAL_CONFIG.commandDict,
            GLOBAL_CONFIG.contentDict,
            GLOBAL_CONFIG.exerciseDict
        );
        Facade.getInstance().startup(config);
    }
});

// run the application:
new Main();

//- - - - - - - - - - - - - - - - - - - - - - 56 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/proxy/config/simple/ConfigProxy.js
/**
 * Created by tnguyen on 23.05.2016.
 */
var ConfigProxy = Proxy.extend(function(){

    var pub = this;

    var _config;

    this.constructor = function(data){
        this.super.constructor(data);
    };
});

//- - - - - - - - - - - - - - - - - - - - - - 57 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/proxy/user/simple/UserProxy.js
/**
 * Created by tnguyen on 22.05.2016.
 */
var UserProxy = Proxy.extend(function() {
    var pub = this;

    this.constructor = function(data){
        this.super.constructor(data);
    };
});

//- - - - - - - - - - - - - - - - - - - - - - 58 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/proxy/structure/simple/StructureProxy.js
/**
 * Created by tnguyen on 03.05.2016.
 */
var StructureProxy = Proxy.extend(function() {
    var pub = this;

    this.init = function(xml){
        configureListener();
        pub.getData().init(xml);
        configureListener();
    };

    function configureListener(){
        var data = pub.getData();
        data.addEvent("CURRENT_PAGE_DATA_CHANGED_COMMAND",dataHandler);
        data.addEvent("CURRENT_CHAPTER_DATA_CHANGED_COMMAND",dataHandler);
        data.addEvent("STATE_CHANGED_COMMAND",dataHandler);
        data.addEvent("SAVE_STATE_COMMAND",dataHandler);
        data.addEvent(StructureEvent.DATA_STATE_CHANGED,structureHandler);
        data.addEvent("COMPLETED_COMMAND",dataHandler);
    }

    function structureHandler(e){
        switch(e.type){
        case StructureEvent.DATA_STATE_CHANGED:
            pub.sendNotification("USER_DATA_COMMAND",e.data,"DATA");
            pub.sendNotification("USER_DATA_COMMAND",pub.getData().progressMeasure,"PROGRESS_MEASURE");
            pub.sendNotification("USER_DATA_COMMAND",null,"FILE");
            pub.sendNotification("DATA_STATE_CHANGED_COMMAND");
            break;
        }
    }

    function dataHandler(e){
        switch(e.type){
            case "CURRENT_PAGE_DATA_CHANGED_COMMAND":
                pub.sendNotification("USER_DATA_COMMAND",e.data,"CURRENT_DATA");
                pub.sendNotification("USER_DATA_COMMAND",null,"FILE");
                break;
        }
        pub.sendNotification(e.type);
    }
});

//- - - - - - - - - - - - - - - - - - - - - - 59 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/proxy/structure/simple/v2/StructureData.js
/**
 * Created by tilo 10/2016
 */
var StructureData = EventDispatcher.extend(function() {
    var pub = this;
    var _rootChapter;
    var _xml;
    var _specialDict; // not impelmented yet
    var _globalPageDataList;
    var _currentPageData;
    var _chapterDataClassName;
    var _pageDataClassName;
    var _globalConfig = {autoPart:"",autoPage:"",baseXML:"",baseContent:"",baseAudio:"",baseVideo:"",appendSubtitle:""}

    this.constructor = function(parameter){
        var chapterDataClassName = ClassManager.getNameByPath(parameter[0]);
        var pageDataClassName = ClassManager.getNameByPath(parameter[1]);
        _chapterDataClassName = chapterDataClassName;
        _pageDataClassName = pageDataClassName;
    };

    this.init = function(xml){
        _xml = xml;
        _globalPageDataList = [];
         buildGlobalConfig();
        _rootChapter = new window[_chapterDataClassName](_xml,_chapterDataClassName,_pageDataClassName,_globalPageDataList)
        _rootChapter.addEvent(StructureEvent.STATE_CHANGED,onStateChanged);
        _rootChapter.addEvent(StructureEvent.DATA_STATE_CHANGED,onDataStateChanged);
        _rootChapter.id = _rootChapter.id || '_root_';
        setGlobalConfiguration();
    };

    function buildGlobalConfig(){
        for (var i=0;i<_xml.attributes.length;i++){
            var attr = _xml.attributes[i];
            if(_globalConfig.hasOwnProperty(attr.name)){
                _globalConfig[attr.name] = attr.value.toString();
            }
        }
    }

    function setGlobalConfiguration(){
        for(var i=0;i<_globalPageDataList.length;i++){
            var pageData = _globalPageDataList[i];
            if(pageData.autoPart == undefined){
                pageData.autoPart = _globalConfig.autoPart;
            }
            if(pageData.autoPage == undefined){
                pageData.autoPage = _globalConfig.autoPage;
            }
        }
    }

    function onDataStateChanged(e){
        pub.dispatchEvent(StructureEvent.DATA_STATE_CHANGED,e);
    }

    function onStateChanged(e){
        pub.dispatchEvent("STATE_CHANGED_COMMAND",{type:"STATE_CHANGED_COMMAND"});
    }


    this.getDataById = function(id,list){
        list = list || _rootChapter.dataList;
        for(var i=0;i<list.length;i++){
            var data = list[i];
            if(data.id == id){
                return data;
            } else{
                if(data.type == "chapter"){
                    var childData = pub.getDataById(id,data.dataList);
                    if(childData){
                        return childData;
                    }
                }
            }
        }
        return null;
    };

    this.getNextPageData = function(pageData){
        for(var i=0;i<_globalPageDataList.length;i++){
            if(pageData === _globalPageDataList[i]){
                var newPageData = _globalPageDataList[i+1];
                if(newPageData){
                    return newPageData;
                }
            }
        }
        return null;
    };

    this.getPreviousPageData = function(pageData){
        for(var i=0;i<_globalPageDataList.length;i++){
            if(pageData === _globalPageDataList[i]){
                if(i>0){
                    var newPageData = _globalPageDataList[i-1];
                    if(newPageData){
                        return newPageData;
                    }
                }
            }
        }
        return null;
    };

    Object.defineProperty(this,"currentPageData",{
        get: function(){
            return _currentPageData;
        },
        set: function(value){
            if(_currentPageData != value){
                if(_currentPageData) _currentPageData.current="false";
                _currentPageData = value;
                _currentPageData.current="true";
                //console.log('#curr', _currentPageData.id)
                pub.dispatchEvent("CURRENT_PAGE_DATA_CHANGED_COMMAND",{type:"CURRENT_PAGE_DATA_CHANGED_COMMAND",data:_currentPageData});
            }
        }
    });

    Object.defineProperty(this,"autoPart",{
        get: function(){ return _globalConfig.autoPart;}
    });

    Object.defineProperty(this,"autoPage",{
        get: function(){return _globalConfig.autoPage;}
    });

    Object.defineProperty(this,"appendSubtitle",{
        get: function(){ return _globalConfig.appendSubtitle;}
    });

    Object.defineProperty(this,"baseXML",{
        get: function(){return _globalConfig.baseXML;}
    });

    Object.defineProperty(this,"baseContent",{
        get: function(){ return _globalConfig.baseContent;}
    });

    Object.defineProperty(this,"baseAudio",{
        get: function(){ return _globalConfig.baseAudio;}
    });

    Object.defineProperty(this,"baseVideo",{
        get: function(){ return _globalConfig.baseVideo;}
    });

    Object.defineProperty(this,"globalPageDataList",{
        get: function(){ return _globalPageDataList;}
    });

    Object.defineProperty(this,"specialDict",{
        get: function(){ return _specialDict;}
    });

    Object.defineProperty(this,"xml",{
        get: function(){
            return _xml;
        }
    });



    Object.defineProperty(this,"rootChapter",{
        get: function(){ return _rootChapter;}
    });

    Object.defineProperty(this,"pageDataClass",{
        get: function(){ return window[_pageDataClassName]}
    });

    Object.defineProperty(this,"chapterDataClass",{
        get: function(){ return window[_chapterDataClassName]}
    });


    Object.defineProperty(this,"progressMeasure",{
        get: function(){
            var completed=0;
            for (var i=0;i<_globalPageDataList.length;i++){
                if(_globalPageDataList[i].state == "2"){
                    completed++;
                }
            }
            return (completed/_globalPageDataList.length);
        }
    });





    /* DEPRECATED, for compatibilty to StructurData only */
    this.getPageDataIndex = function(id){
        for(var i=0;i<_globalPageDataList.length;i++){
            if(id == _globalPageDataList[i].id){
                return i;
            }
        }
        return 0;
    };

    /* DEPRECATED, for compatibilty to StructurData only */
    Object.defineProperty(this,"chapterDataList",{
        get: function(){
            return _rootChapter.dataList.filter(function(data){return data.type="chapter"});
        }
    });




});

//- - - - - - - - - - - - - - - - - - - - - - 60 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/proxy/structure/simple/v2/ChapterData.js
var ChapterData = Data.extend(function() {
    var pub = this;
    var _current;
    var _dataList;
    var _globalExerciseDataList;
    var _path;
    var _textXMLPath;
    var _chapterDataClass;
    var _pageDataClass;

    this.constructor = function(xml,chapterDataClass,pageDataClass,globalPageDataList){
        pub.xml = xml;
        _globalExerciseDataList = globalPageDataList;
        _chapterDataClass = chapterDataClass;
        _pageDataClass = pageDataClass;
        init();
        buildDataList();
    };


    function init(){
        for(var i=0;i<pub.xml.attributes.length;i++){
            var attr = pub.xml.attributes[i];
            if(pub.hasOwnProperty(attr.name)){
                pub[attr.name] = attr.value;
            }
        }

        var length = pub.xml.childNodes.length;
        for(var j=0;j<length;j++){
            var name= pub.xml.childNodes[j].nodeName;
            if(pub.hasOwnProperty(name)){
                pub[name] = pub.xml.childNodes[j].textContent;
            }
        }
    }

    function buildDataList(){
        _dataList = [];
        var xmlList = pub.xml.childNodes;
        var length = xmlList.length;
        for(var i=0;i<length;i++){
            var xml = xmlList[i];
            if(xml.nodeName == "unit"){
                var type = xml.attributes["type"].value;
                if(type == "chapter"){
                    var chapterData = new window[_chapterDataClass](xml,_chapterDataClass,_pageDataClass,_globalExerciseDataList);
                    chapterData.parentData = pub;
                    chapterData.type = type;
                    _dataList.push(chapterData);
                    chapterData.addEvent(StructureEvent.STATE_CHANGED,onStateChanged);
                    chapterData.addEvent(StructureEvent.DATA_STATE_CHANGED,onDataStateChanged);
                }
                else if(type == "page"){
                    var pageData = new window[_pageDataClass](xml);
                    pageData.parentData = pub;
                    pageData.type = type;
                    _dataList.push(pageData);
                    if(_globalExerciseDataList){
                        _globalExerciseDataList.push(pageData);
                    }
                    pageData.addEvent(StructureEvent.STATE_CHANGED,onStateChanged);
                    pageData.addEvent(StructureEvent.DATA_STATE_CHANGED,onDataStateChanged);
                }
            }
        }
    }

    function onDataStateChanged(e){
        pub.dispatchEvent(StructureEvent.DATA_STATE_CHANGED,{type:StructureEvent.DATA_STATE_CHANGED,data: e.data});
    }

    function onStateChanged(e){
        var cnt=0, state;
        for(var i=0;i<_dataList.length;i++){
            if(_dataList[i].state == "1" || _dataList[i].state == "2"){
                state = "1";
            }
            if(_dataList[i].state == "2"){
                cnt++;
            }
        }

        if(cnt == _dataList.length){
            if(pub.state != "2"){
                pub.state = "2";
                pub.dispatchEvent(StructureEvent.STATE_CHANGED,{type:StructureEvent.STATE_CHANGED});
            }
        } else {
            if(pub.state != state){
                pub.state = state;
                if(state=="2"){
                    pub.dispatchEvent("COMPLETED_COMMAND",{type:"COMPLETED_COMMAND"});
                }
                pub.dispatchEvent(StructureEvent.STATE_CHANGED,{type:StructureEvent.STATE_CHANGED});
            }
        }
    }

    this.getCurrentPage = function(){
        if(this._current) {
           for(var i=0; i<_dataList.length; i++){
               if(_dataList[i].current){
                   if(_dataList[i].dataList) {
                       return _dataList[i].getCurrentPage();
                   } else {
                       return _dataList[i];
                   }
               }
           }
        }
        return null;
    }


    this.getPageDataList = function (depth){
        var list = [];
        _dataList.forEach(function(data){
            if(data.dataList == undefined) {
               list.push(data);
            } else if(depth){
               list = list.concat(data.getPageDataList(depth-1));
            }
        });
        return list;
   }

    Object.defineProperty(this,"path",{
        get: function(){
            return _path;

        },
        set: function(value){
            _path = value;
        }
    });

    Object.defineProperty(this,"textXMLPath",{
        get: function(){
            return _textXMLPath;

        },
        set: function(value){
            _textXMLPath = value;
        }
    });

    Object.defineProperty(this,"dataList",{
        get: function(){
            return _dataList;
        }
    });

    Object.defineProperty(this,"current",{
        get: function(){
            return _current;
        },
        set: function(value){
            _current = value;
            if(pub.parentData) pub.parentData.current = value;
        }
    });

    this.reset = function(){
        this.super.reset();
        _currentData = null;
        init();
    }
});

//- - - - - - - - - - - - - - - - - - - - - - 61 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/proxy/structure/simple/v2/PageData.js
var PageData = Data.extend(function() {
    var pub = this;

    var _textXML;
    var _currentFrame;
    var _group;
    var _xmlPath;
    var _contentPath;
    var _autoPart;
    var _autoPage;
    var _current;

    this.constructor = function(xml){
        pub.xml = xml;
        init();
    };

    function init(){
        for(var i=0;i<pub.xml.attributes.length;i++){
            var attr = pub.xml.attributes[i];
            if(pub.hasOwnProperty(attr.name)){
                pub[attr.name] = attr.value;
            }
        }
        var length = pub.xml.childNodes.length;
        for(var j=0;j<length;j++){
            var name= pub.xml.childNodes[j].nodeName;
            if(pub.hasOwnProperty(name)){
                pub[name] = pub.xml.childNodes[j].textContent;
            }
        }
    }

    this.getItemTextById = function(id){
        if(_textXML){
            var xmlList = _textXML.childNodes;
            var length = xmlList.length;
            for(var i=0;i<length;i++){
                var node = xmlList[i];
                if(node.nodeName == "item") {
                    var nodeId = node.attributes["id"].value;
                    if (id == nodeId) {
                        return node.textContent;
                    }
                }
            }
        }
        return "";
    }


    this.getSubtitleTextById = function(id){
        if(_textXML){
            var xmlList = _textXML.childNodes;
            var length = xmlList.length;
            for(var i=0;i<length;i++){
                var node = xmlList[i];
                if(node.nodeName == "subtitle") {
                    var nodeId = node.attributes["id"].value;
                    if (id == nodeId) {
                        return node.textContent;
                    }
                }
            }
        }
        return "";
    }

    this.reset = function(){
        this.super.reset();
        pub.init();
        pub._currentFrame = 0;
    };

    this.getBreadcrumb = function() {
        var breadcrumb = [];
        var data = this.parentData;
        while (data) {
            breadcrumb.unshift(data);
            data = data.parentData;
        }
        return breadcrumb;
    }

    Object.defineProperty(this,"textXML",{
        get: function(){
            return _textXML;
        },
        set: function(value){
            _textXML = value;
        }
    });

    Object.defineProperty(this,"currentFrame",{
        get: function(){
            return _currentFrame;
        },
        set: function(value){
            _currentFrame = value;
        }
    });

    Object.defineProperty(this,"group",{
        get: function(){
            return _group;
        },
        set: function(value){
            _group = value;
        }
    });

    Object.defineProperty(this,"xmlPath",{
        get: function(){
            return _xmlPath;
        },
        set: function(value){
            _xmlPath = value;
        }
    });

    Object.defineProperty(this,"contentPath",{
        get: function(){
            return _contentPath;
        },
        set: function(value){
            _contentPath = value;
        }
    });

    Object.defineProperty(this,"autoPart",{
        get: function(){
            return _autoPart;
        },
        set: function(value){
            _autoPart = value;
        }
    });

    Object.defineProperty(this,"autoPage",{
        get: function(){
            return _autoPage;
        },
        set: function(value){
            _autoPage = value;
        }
    });

    Object.defineProperty(this,"current",{
        get: function(){
            return _current;
        },
        set: function(value){
            if(String(value)=="true") {
                if(pub.state != "2") {
                    pub.state = "1";
                }
            }
            _current = value;
            if(pub.parentData) pub.parentData.current = value;
        }
    });
});



//- - - - - - - - - - - - - - - - - - - - - - 62 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/proxy/view/simple/ViewProxy.js
/**
 * Created by tnguyen on 19.05.2016.
 */
var ViewProxy = Proxy.extend(function() {
    var pub = this;

    this.constructor = function(data){
        this.super.constructor(data);
        data.addEvent("VIEW_CHANGED",eventHandler);
    };

    function eventHandler(e){
        pub.sendNotification("VIEW_CHANGED_COMMAND", e.currentView);
    }
});

//- - - - - - - - - - - - - - - - - - - - - - 63 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/proxy/content/simple/ContentProxy.js
/**
 * Created by tnguyen on 19.05.2016.
 */
var ContentProxy = Proxy.extend(function(){

    var pub = this;

    var _currentContent;
    var _contentMediatorDict;

    this.constructor = function(data){
        this.super.constructor(data);
        _contentMediatorDict = {};
    };

    Object.defineProperty(this,"contentMediatorDict",{
        get: function(){
            return _contentMediatorDict;
        }
    });

    Object.defineProperty(this,"currentContent",{
        get: function(){
            return _currentContent;
        },
        set: function(value){
            _currentContent = value;
        }
    });
});

//- - - - - - - - - - - - - - - - - - - - - - 64 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/proxy/xml/simple/XMLProxy.js
/**
 * Created by tnguyen on 03.06.2016.
 */
var XMLProxy = Proxy.extend(function(){
    var _xml;

    this.init = function(value){
        _xml = value;
    };

    Object.defineProperty(this,"xml",{
        get: function(){
            return _xml;
        }
    });
});

//- - - - - - - - - - - - - - - - - - - - - - 65 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/mediator/exit/porscheaftersales/PorscheAftersalesExitBtnMediator.js
/**
 * Created by cduerbeck on 22.10.18.
 */
var PorscheAftersalesExitBtnMediator = SimpleBtnMediator.extend(function(){
    var pub = this;
    var _content;
    var _structureData;

    this.init = function(){
        pub.ACTIVATE_COMMAND = "ACTIVATE_EXIT_BTN_COMMAND";
        pub.DEACTIVATE_COMMAND = "DEACTIVATE_EXIT_BTN_COMMAND";
        pub.LOCK_COMMAND = "LOCK_EXIT_BTN_COMMAND";
        pub.onList.push("CONTENT_VIEW");
        pub.offList.push(ViewData.INIT);
        pub.offList.push("VIDEO_VIEW");
        _content = Facade.getInstance().retrieveMediator("ContentMediator").getViewComponent();
        _structureData = Facade.getInstance().retrieveProxy("StructureProxy").getData();
        this.super.init();
    };

    this.eventHandler = function(e){
        _content.dispatchEvent("NO_STEP");
        pub.sendNotification("SET_VIEW_COMMAND",ViewData.INIT);
        pub.sendNotification("UNLOAD_CONTENT_COMMAND");
    };

    this.viewChanged = function(view){

        if(pub.onList.indexOf(view) != -1){
            if(_structureData.currentPageData.id != _structureData.globalPageDataList[0].id){
                pub.activate();
            }
        }
        else{
            if(pub.offList.length > 0){
                if(pub.offList.indexOf(view) != -1){
                    pub.deactivate();
                }
                else{
                    pub.activate();
                }
            }
            else{
                if(pub.orList.length > 0){
                    if(pub.orList.indexOf(view) == -1){
                        pub.deactivate();
                    }
                }
                else{
                    if(pub.onList.length > 0){
                        pub.deactivate();
                    }
                }
            }
        }
    };
});

//- - - - - - - - - - - - - - - - - - - - - - 66 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/mediator/exit/simple/SimpleExitDialogMediator.js
/**
 * Created by tilo on 7/2017.
 * provides on revisiting the wbt an option to resume on its last visited page or resart the wbt
 *
 */
var SimpleExitDialogMediator = SimpleMediator.extend(function(){
    var pub = this;
    this.init = function(){
        pub.ACTIVATE_COMMAND = "ACTIVATE_EXIT_COMMAND";
        pub.DEACTIVATE_COMMAND = "DEACTIVATE_EXIT_COMMAND";
        pub.onList.push("EXIT_VIEW");
        this.super.init();
        var yes =  pub.clip.yesBtn;
        if(yes) new SimpleClick(yes).addEvent("click",onClickYes);
    };

    function onClickYes(e){
        window.top.close();
    }
});

//- - - - - - - - - - - - - - - - - - - - - - 67 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/mediator/imprint/simple/SimpleImprintBtnMediator.js
/**
 * Created by tnguyen on 20.05.2016.
 */
var SimpleImprintBtnMediator = SimpleBtnMediator.extend(function(){
    var pub = this;

    this.init = function(){
        pub.ACTIVATE_COMMAND = "ACTIVATE_IMPRINT_BTN_COMMAND";
        pub.DEACTIVATE_COMMAND = "DEACTIVATE_IMPRINT_BTN_COMMAND";
        pub.LOCK_COMMAND = "LOCK_IMPRINT_BTN_COMMAND";
        pub.ON_VIEW = "IMPRINT_VIEW";
        pub.OFF_VIEW = ViewData.INIT;
        pub.onName = "imprintOnBtn";
        pub.offName = "imprintOffBtn";
        pub.mediatorConnectorName = "ImprintMediator";
        this.super.init();
    };
});

//- - - - - - - - - - - - - - - - - - - - - - 68 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/mediator/imprint/porschepanamerast/PorschePanameraStImprintMediator.js
/**
 * Created by fseng on 17.01.2017.
 */
var PorschePanameraStImprintMediator = SimpleMediator.extend(function(){
    var pub = this;
    var _scroller;
    var _imprintContent;

    this.init = function(){
        pub.ACTIVATE_COMMAND = "ACTIVATE_IMPRINT_COMMAND";
        pub.DEACTIVATE_COMMAND = "DEACTIVATE_IMPRINT_COMMAND";
        pub.onList.push("IMPRINT_VIEW");
        this.super.init();
        buildScroller();
    };

    function buildScroller() {
        var scrollerItem = pub.clip.findObjectsByName("scrollerItem",createjs.MovieClip)[0];
        _imprintContent = pub.clip.findObjectsByName("imprintContent",createjs.MovieClip)[0];

        _scroller = new SimpleScroller(
            pub.clip.stage,
            _imprintContent,
            _imprintContent.nominalBounds.width,
            scrollerItem.nominalBounds.height,
            scrollerItem,
            true // draggable
        );
        _scroller.updateByHeight(_imprintContent.nominalBounds.height);
    }

    this.activate = function(){
        this.super.activate();
        _scroller.update(_imprintContent.nominalBounds.height);
    };
});

//- - - - - - - - - - - - - - - - - - - - - - 69 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/mediator/help/simple/SimpleHelpBtnMediator.js
/**
 * Created by tnguyen on 20.05.2016.
 */
var SimpleHelpBtnMediator = SimpleBtnMediator.extend(function(){
    var pub = this;

    this.init = function(){
        pub.ACTIVATE_COMMAND = "ACTIVATE_HELP_BTN_COMMAND";
        pub.DEACTIVATE_COMMAND = "DEACTIVATE_HELP_BTN_COMMAND";
        pub.LOCK_COMMAND = "LOCK_HELP_BTN_COMMAND";
        pub.ON_VIEW = "HELP_VIEW";
        pub.OFF_VIEW = ViewData.INIT;
        pub.onName = "helpOnBtn";
        pub.offName = "helpOffBtn";
        pub.mediatorConnectorName = "HelpMediator";
        this.super.init();
    };
});

//- - - - - - - - - - - - - - - - - - - - - - 70 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/mediator/help/porschepanamerast/PorschePanameraStHelpMediator.js
/**
 * Created by fseng on 17.01.2017.
 */
var PorschePanameraStHelpMediator = SimpleMediator.extend(function(){
    var pub = this;
    var _scroller;
    var _helpContent;

    this.init = function(){
        pub.ACTIVATE_COMMAND = "ACTIVATE_HELP_COMMAND";
        pub.DEACTIVATE_COMMAND = "DEACTIVATE_HELP_COMMAND";
        pub.onList.push("HELP_VIEW");
        this.super.init();
        buildScroller();
        initWidget(pub.clip.helpContent);
    };

    function buildScroller() {

        setTimeout(function() {
            var scrollerItem = pub.clip.findObjectsByName("scrollerItem",createjs.MovieClip)[0];
            _helpContent = pub.clip.findObjectsByName("helpContent",createjs.MovieClip)[0];
            buildIt(scrollerItem);
        },0);
    }

    function buildIt(scrollerItem){
        _scroller = new SimpleScroller(
            pub.clip.stage,
            _helpContent,
            _helpContent.nominalBounds.width,
            scrollerItem.nominalBounds.height,
            scrollerItem,
            true // draggable
        );
        _scroller.updateByHeight(_helpContent.nominalBounds.height);

    }

    function initWidget(clip){
        for(var i=0;i<clip.numChildren;i++){
            if(ObjectService.getType(clip.getChildAt(i)) == "MovieClip"){
                checkWidget(clip.getChildAt(i));
            }
        }
    };

    function checkWidget(clip){
        if(clip.name){
            for(var key in pub.config.exerciseDict){
                var flags = key.replace(/.*\/([gimy]*)$/, '$1');
                var pattern = key.replace(new RegExp('^/(.*?)/'+flags+'$'), '$1');
                var regex = new RegExp(pattern, flags);
                if(clip.name.match(regex)){
                    var className = ClassManager.getNameByPath(pub.config.exerciseDict[key]);
                    var exercise = new window[className]();
                    exercise.init(clip);
                }
            }
        }
    }

    this.activate = function(){
        this.super.activate();
        _scroller.update(_helpContent.nominalBounds.height);
    };
});

//- - - - - - - - - - - - - - - - - - - - - - 71 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/mediator/previous/simple/SimplePreviousBtnMediator.js
/**
 * Created by tnguyen on 20.05.2016.
 */
var SimplePreviousBtnMediator = SimpleBtnMediator.extend(function(){
    var pub = this;
    var _structureData;

    this.init = function(){
        pub.ACTIVATE_COMMAND = "ACTIVATE_PREVIOUS_BTN_COMMAND";
        pub.DEACTIVATE_COMMAND = "DEACTIVATE_PREVIOUS_BTN_COMMAND";
        pub.LOCK_COMMAND = "LOCK_PREVIOUS_BTN_COMMAND";
        this.super.init();
        _structureData = Facade.getInstance().retrieveProxy("StructureProxy").getData();
    };

    this.eventHandler = function(e){
        pub.sendNotification("PREVIOUS_COMMAND");
    };

    this.listNotifications = function(){
        var list = this.super.listNotifications();
        list.push("SETUP_CONTENT_COMMAND");
        return list;
    };

    this.handleNotification = function(notification){
        this.super.handleNotification(notification);
        switch(notification.getName()){
            case "SETUP_CONTENT_COMMAND":
                checkLock();
                break;
        }
    };

    function checkLock(){
        if(_structureData.currentPageData == _structureData.globalPageDataList[0]){
            if(!pub.isLocked){
                pub.sendNotification(pub.LOCK_COMMAND,true);
            }
        }
        else{
            if(pub.isLocked){
                pub.sendNotification(pub.LOCK_COMMAND,false);
            }
        }
    }
});

//- - - - - - - - - - - - - - - - - - - - - - 72 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/mediator/next/simple/SimpleNextBtnMediator.js
/**
 * Created by tnguyen on 20.05.2016.
 */
var SimpleNextBtnMediator = SimpleBtnMediator.extend(function(){
    var pub = this;
    var _structureData;
    this.init = function() {
        pub.ACTIVATE_COMMAND = "ACTIVATE_NEXT_BTN_COMMAND";
        pub.DEACTIVATE_COMMAND = "DEACTIVATE_NEXT_BTN_COMMAND";
        pub.LOCK_COMMAND = "LOCK_NEXT_BTN_COMMAND";
        this.super.init();
        _structureData = Facade.getInstance().retrieveProxy("StructureProxy").getData();
    };

    this.eventHandler = function(e){
        pub.sendNotification(pub.LOCK_COMMAND);
        pub.sendNotification("NEXT_COMMAND");
    };

    this.listNotifications = function(){
        var list = this.super.listNotifications();
        list.push("PART_COMPLETE_COMMAND");
        list.push("PAGE_COMPLETE_EVENT");
        list.push("SETUP_CONTENT_COMMAND");
        return list;
    };

    this.handleNotification = function(notification){
        this.super.handleNotification(notification);
        pub.defaultClick.showLabel("out");
        switch(notification.getName()){
            case "PART_COMPLETE_COMMAND":
                if(_structureData.currentPageData.autoPart != "true"){
                    pub.defaultClick.showLabel("highlight");
                }
                break;
            case "PAGE_COMPLETE_EVENT":
                if(_structureData.currentPageData.autoPage != "true"){
                    pub.defaultClick.showLabel("highlight");
                }
                pub.checkLock();
                break;
            case "SETUP_CONTENT_COMMAND":
                pub.checkLock();
                break;
        }
    };

    this.checkLock = function(){
        if(_structureData.currentPageData == _structureData.globalPageDataList[_structureData.globalPageDataList.length-1]){
            pub.sendNotification(pub.LOCK_COMMAND,true);
        } else{
            if(pub.isLocked){
                pub.sendNotification(pub.LOCK_COMMAND,false);
            }
        }
    };

    Object.defineProperty(this,"structureData",{
        get: function(){
            return _structureData;
        }
    });
});

//- - - - - - - - - - - - - - - - - - - - - - 73 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/mediator/pauseresume/simple/SimplePauseResumeBtnMediator.js
/**
 * Created by tnguyen on 20.05.2016.
 */
var SimplePauseResumeBtnMediator = SimpleBtnMediator.extend(function(){
    var pub = this;

    this.init = function(){
        pub.ACTIVATE_COMMAND = "ACTIVATE_PAUSE_RESUME_BTN_COMMAND";
        pub.DEACTIVATE_COMMAND = "DEACTIVATE_PAUSE_RESUME_BTN_COMMAND";
        pub.LOCK_COMMAND = "LOCK_PAUSE_RESUME_BTN_COMMAND";
        pub.onName = "pauseBtn";
        pub.offName = "resumeBtn";
        this.super.init();
    };

    this.eventHandler = function(e){
        var click = e.currentTarget ;
        switch(click.comp.name){
            case pub.onName:
                pub.sendNotification("PAUSE_COMMAND");
                break;
            case pub.offName:
                pub.sendNotification("RESUME_COMMAND");
                break;
        }
    };

    this.listNotifications = function(){
        var list = this.super.listNotifications();
        list.push("PREVIOUS_COMMAND");
        list.push("NEXT_COMMAND");
        list.push("SETUP_CONTENT_COMMAND");
        list.push("PAUSE_COMMAND");
        list.push("RESUME_COMMAND");
        return list;
    };

    this.handleNotification = function(notification){
        this.super.handleNotification(notification);
        switch(notification.getName()){
            case "PREVIOUS_COMMAND":
            case "NEXT_COMMAND":
            case "SETUP_CONTENT_COMMAND":
            case "RESUME_COMMAND":
                pub.onClick.comp.visible = true;
                pub.offClick.comp.visible = false;
                break;
            case  "PAUSE_COMMAND":
                pub.onClick.comp.visible = false;
                pub.offClick.comp.visible = true;
        }
    }
});

//- - - - - - - - - - - - - - - - - - - - - - 74 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/mediator/reload/simple/SimpleReloadBtnMediator.js
/**
 * Created by tnguyen on 20.05.2016.
 */
var SimpleReloadBtnMediator = SimpleBtnMediator.extend(function(){
    var pub = this;

    this.init = function(){
        pub.ACTIVATE_COMMAND = "ACTIVATE_RELOAD_BTN_COMMAND";
        pub.DEACTIVATE_COMMAND = "DEACTIVATE_RELOAD_BTN_COMMAND";
        pub.LOCK_COMMAND = "LOCK_RELOAD_BTN_COMMAND";
        this.super.init();
    };

    this.eventHandler = function(e){
        pub.sendNotification("RELOAD_COMMAND");
    }
});

//- - - - - - - - - - - - - - - - - - - - - - 75 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/mediator/sound/simple/SimpleSoundBtnMediator.js
/**
 * Created by tnguyen on 20.05.2016.
 */
var SimpleSoundBtnMediator = SimpleBtnMediator.extend(function(){
    var pub = this;

    this.init = function(){
        pub.ACTIVATE_COMMAND = "ACTIVATE_SOUND_BTN_COMMAND";
        pub.DEACTIVATE_COMMAND = "DEACTIVATE_SOUND_BTN_COMMAND";
        pub.LOCK_COMMAND = "LOCK_SOUND_BTN_COMMAND";
        pub.onName = "soundOnBtn";
        pub.offName = "soundOffBtn";
        this.super.init();
        pub.onClick.comp.visible = false;
        pub.offClick.comp.visible = true;
    };

    this.eventHandler = function(e){
        var click = e.currentTarget;
        switch(click.comp.name){
            case pub.onName:
                pub.sendNotification("SOUND_COMMAND",1,"VOLUME");
                pub.sendNotification("DEACTIVATE_SUBTITLE_COMMAND");
                pub.onClick.comp.visible = false;
                pub.offClick.comp.visible = true;
                break;
            case pub.offName:
                pub.sendNotification("SOUND_COMMAND",0,"VOLUME");
                pub.sendNotification("ACTIVATE_SUBTITLE_COMMAND");
                pub.onClick.comp.visible = true;
                pub.offClick.comp.visible = false;
                break;
        }
    }
});

//- - - - - - - - - - - - - - - - - - - - - - 76 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/mediator/subtitle/simple/SimpleSubtitleBtnMediator.js
/**
 * Created by tnguyen on 20.05.2016.
 */
var SimpleSubtitleBtnMediator = SimpleBtnMediator.extend(function(){
    var pub = this;

    this.init = function(){
        pub.ACTIVATE_COMMAND = "ACTIVATE_SUBTITLE_BTN_COMMAND";
        pub.DEACTIVATE_COMMAND = "DEACTIVATE_SUBTITLE_BTN_COMMAND";
        pub.LOCK_COMMAND = "LOCK_SUBTITLE_BTN_COMMAND";
        pub.onName = "subtitleOnBtn";
        pub.offName = "subtitleOffBtn";
        this.super.init();
    };

    this.eventHandler = function(e){
        var click = e.currentTarget;
        switch(click.comp.name){
            case pub.onName:
                pub.sendNotification("ACTIVATE_SUBTITLE_COMMAND");
                break;
            case pub.offName:
                pub.sendNotification("DEACTIVATE_SUBTITLE_COMMAND");
                break;
        }
    };

    this.listNotifications = function(){
        return [pub.ACTIVATE_COMMAND,
            pub.DEACTIVATE_COMMAND,
            "ACTIVATE_SUBTITLE_COMMAND",
            "DEACTIVATE_SUBTITLE_COMMAND"
        ];
    };

    this.handleNotification = function(notification){
        switch(notification.getName()){
            case pub.ACTIVATE_COMMAND:
                this.super.activate();
                break;
            case pub.DEACTIVATE_COMMAND:
                this.super.deactivate();
                break;
            case "ACTIVATE_SUBTITLE_COMMAND":
                pub.onClick.comp.visible = false;
                pub.offClick.comp.visible = true;
                break;
            case "DEACTIVATE_SUBTITLE_COMMAND":
                pub.onClick.comp.visible = true;
                pub.offClick.comp.visible = false;
                break;
        }
    }
});

//- - - - - - - - - - - - - - - - - - - - - - 77 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/mediator/subtitle/simple/SimpleSubtitleMediator.js
/**
 * Created by tnguyen on 20.05.2016.
 */
var SimpleSubtitleMediator = SimpleMediator.extend(function(){
    var pub = this;

    var _assetDict;
    var _simpleScroller;
    var _scrollerItem;
    var _textField;
    var _subtitleBackground;
    var _autoHideState;
    var _initDone;
    var _startX;
    var _startY;
    var _structureData;
    var _backgroundClip;

    var _append = false;

    this.init = function(){
        pub.ACTIVATE_COMMAND = "ACTIVATE_SUBTITLE_COMMAND";
        pub.DEACTIVATE_COMMAND = "DEACTIVATE_SUBTITLE_COMMAND";
        this.super.init();
        _structureData = Facade.getInstance().retrieveProxy("StructureProxy").getData();
        _append = _structureData.appendSubtitle=="true";
        _startX = pub.clip.x;
        _startY = pub.clip.y;
        _assetDict = {};
        ObjectService.getObjectFromClip(pub.clip,getObj,"Text","textField");
        ObjectService.getObjectFromClip(pub.clip,getObj,"MovieClip","scrollerItem");
        ObjectService.getObjectFromClip(pub.clip,getObj,"MovieClip","subtitleBackground");

        if(Facade.getInstance().retrieveMediator("BackgroundMediator")){
            _backgroundClip = Facade.getInstance().retrieveMediator("BackgroundMediator").getViewComponent();
        }
    };

    this.listNotifications = function(){
        var list = this.super.listNotifications();
        list.push("SOUND_COMMAND");
        list.push("SETUP_CONTENT_COMMAND");
        list.push('HIDE_SUBTITLE');
        list.push('SHOW_SUBTITLE');
        return list;
    };

    this.handleNotification = function(notification){
        this.super.handleNotification(notification);

        switch(notification.getName()){
            case "SOUND_COMMAND":
                if(notification.getType() == "PLAY_SOUND"){
                    if(_structureData.currentPageData){
                        var subtitleID = notification.getBody().replace(/^[^_]+_/,''); //removes leading page-id
                        pub.update(_structureData.currentPageData.getSubtitleTextById(subtitleID));
                    }
                }
                if(!_append && notification.getType() == "STOP_SOUND"){
                    pub.clear();
                }
                break;
            case "SETUP_CONTENT_COMMAND":
                pub.clear();
                break;
            case 'HIDE_SUBTITLE' :
                pub.hide();
                break;
            case 'SHOW_SUBTITLE' :
                pub.show();
                break;
        }
    };

    function getObj(interactiveObject){
        switch(interactiveObject.name){
            case "textField":
                _textField = interactiveObject;
                break;
            case "scrollerItem":
                _scrollerItem = interactiveObject;
                break;
            case "subtitleBackground":
                _subtitleBackground = interactiveObject;
                break;
        }
        if(_textField && _scrollerItem && _subtitleBackground){
            initAsset();
        }
    }

    function initAsset(){
        if(!_initDone){
            _simpleScroller = new SimpleScroller(pub.clip.stage,_textField,_textField.lineWidth,_scrollerItem.bg.nominalBounds.height,_scrollerItem);
            _initDone = true;
            _subtitleBackground.addEventListener("mousedown",onDown);
            pub.clip.addEventListener("mousedown",onDown);
        }
    }

    function onDown(e){
        if(e.currentTarget.name == "subtitleBackground"){
            var localPos = pub.clip.parent.globalToLocal(pub.clip.stage.mouseX, pub.clip.stage.mouseY);
            var deltaX = localPos.x - pub.clip.x;
            var deltaY = localPos.y - pub.clip.y;
            pub.clip.deltaPosition = {x:deltaX,y:deltaY};
            pub.clip.stage.addEventListener("pressmove",onMove);
            pub.clip.stage.addEventListener("pressup",onUp);
        }
    }

    function onMove(e){
        var localPos = pub.clip.parent.globalToLocal(pub.clip.stage.mouseX, pub.clip.stage.mouseY);
        pub.clip.x = localPos.x - pub.clip.deltaPosition.x;
        pub.clip.y = localPos.y - pub.clip.deltaPosition.y;
    }

    function onUp(e) {
        pub.clip.stage.removeEventListener("pressmove", onMove);
        pub.clip.stage.removeEventListener("pressup", onUp);

        if(_backgroundClip){
            var posRight = pub.clip.x + pub.clip.nominalBounds.width;
            var posLeft = pub.clip.x;
            var posTop = pub.clip.y;
            var posBottom = pub.clip.y + pub.clip.nominalBounds.height;
            if(posRight > _backgroundClip.nominalBounds.width){
                pub.clip.x = _backgroundClip.nominalBounds.width - pub.clip.nominalBounds.width;
            }
            if(posLeft < 0){
                pub.clip.x = 0
            }
            if(posTop < 0){
                pub.clip.y = 0;
            }
            if(posBottom > _backgroundClip.nominalBounds.height){
                pub.clip.y = _backgroundClip.nominalBounds.height - pub.clip.nominalBounds.height;
            }
        }
    }

    this.onCloseClick = function(e){
        pub.sendNotification("DEACTIVATE_SUBTITLE_COMMAND");
    };

    /* hide and show are intended to be used for temporary hiding only */
    this.hide = function (){
        pub.clip.alpha = 0;
    }

    this.show = function(){
        pub.clip.alpha = 1;
    }

    function activate(){
        pub.clip.visible = true;
    }

    function deactivate(){
        pub.clip.visible = false;
    }

    function onCompleteDeactivate(){
        pub.clip.visible = false;
    }

    this.clear = function() {
        _textField.text=" ";
    };
    this.update = function(text){
        if(_textField.text != text){
            if(_append){
                text = _textField.text +'\n'+text;
            }
            _textField.text = text;
            if(_textField.getBounds()){
                _textField.width = _textField.getBounds().width;
                _textField.height = _textField.getBounds().height+5;
            }
            if(_simpleScroller){
                _simpleScroller.update(_textField.height);
            }
        }
        if(_autoHideState){
            if(text == ""){
                this.deactivate();
            }
            else{
                this.activate();
            }
        }
    };

    Object.defineProperty(this,"autoHideState",{
        get: function(){
            return _autoHideState;
        },
        set: function(value){
            _autoHideState = value;
        }
    });

    Object.defineProperty(this,"textField",{
        get: function(){
            return _textField;
        }
    });

    Object.defineProperty(this,"subtitleBackground",{
        get: function(){
            return _subtitleBackground;
        }
    });
});

//- - - - - - - - - - - - - - - - - - - - - - 78 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/mediator/menu/simple/SimpleMenuBtnMediator.js
/**
 * Created by tnguyen on 20.05.2016.
 */
var SimpleMenuBtnMediator = SimpleBtnMediator.extend(function(){
    var pub = this;

    this.init = function(){
        pub.ACTIVATE_COMMAND = "ACTIVATE_MENU_BTN_COMMAND";
        pub.DEACTIVATE_COMMAND = "DEACTIVATE_MENU_BTN_COMMAND";
        pub.LOCK_COMMAND = "LOCK_MENU_BTN_COMMAND";
        pub.ON_VIEW = "MENU_VIEW";
        pub.OFF_VIEW = ViewData.INIT;
        pub.onName = "menuOnBtn";
        pub.offName = "menuOffBtn";
        pub.mediatorConnectorName = "MenuMediator";
        this.super.init();
    };
});

//- - - - - - - - - - - - - - - - - - - - - - 79 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/mediator/menu/porscheserviceberater/PorscheServiceberaterMenuMediator.js
/**
 * Created by cduerbeck on 24.09.18.
 */

var PorscheServiceberaterMenuMediator = SimpleMediator.extend(function(){
    var pub = this;
    var _structureData;
    var _chapterList;
    var _allSeenMessage;
    var _allSeenFirst;

    this.init = function(){
        this.super.init();
        pub.ACTIVATE_COMMAND = "ACTIVATE_MENU_COMMAND";
        pub.DEACTIVATE_COMMAND = "DEACTIVATE_MENU_COMMAND";
        pub.onList.push(ViewData.INIT);
        pub.orList.push("SITEMAP_VIEW");
        _structureData = Facade.getInstance().retrieveProxy("StructureProxy").getData();
        var data = _structureData.rootChapter;
        build();
    };

    function build(){
        if(_allSeenMessage){
            _allSeenMessage.visible = false;
        }
        _chapterList = pub.clip.findObjectsByName(/^chapterItem_/,createjs.MovieClip,false);
        var infoMenu = pub.clip.findObjectsByName("infoMenu", createjs.MovieClip)[0];
        ObjectService.getObjectFromClip(pub.clip,getAllSeenMessage,"MovieClip","allSeenMessageWindow");
        var porschePanameraStInfoMenu = new PorschePanameraStInfoMenu(infoMenu);
        configureListener();
        initWidget(infoMenu.infoMenuContent);
    }


    function getAllSeenMessage(interactiveObject) {

        _allSeenMessage = interactiveObject;
        _allSeenMessage.visible = false;
        _allSeenMessage.noBtn.addEventListener("click", onCancelExit);
        _allSeenMessage.yesBtn.addEventListener("click", onExit);
        if(_allSeenMessage.allSeenBlocker){
            _allSeenMessage.allSeenBlocker.addEventListener("click", onBlocked);
        }
    }

    function onCancelExit(e) {
        _allSeenFirst = true;
        _allSeenMessage.visible=false;
    }
    function onExit(e) {
        _allSeenFirst = true;
        window.top.close();
    }

    function onBlocked(e) {
        //console.log("blocked");
    }



    function configureListener(){
        for(var i=0;i<_chapterList.length;i++){
            addListener(_chapterList[i]);
        }
    }

    function addListener(clip){
        var id = clip.name.substr(12);
        clip.data = _structureData.getDataById(id);


        if(clip.chapterItemThumbnail){
            clip.chapterItemThumbnail.gotoAndStop(clip.data.id);
        }

        if(clip.chapterTitle){
            clip.chapterTitle.visible=false;
            clip.chapterTitle.chapterTitleTextfield.text = clip.data.name;
            clip.clickButton.addEventListener('mouseover',onMouseover);
            clip.clickButton.addEventListener('mouseout',onMouseout);
            clip.clickButton.cursor='pointer';
        }
        if(clip.chapterTitleFixed){
            clip.chapterTitleFixed.visible=true;
            clip.chapterTitleFixed.chapterTitleTextfield.text = clip.data.name;
            if(clip.clickButton){
                clip.clickButton.cursor='pointer';
            }
        }

        var xmlList = clip.data.xml.childNodes;
        var length = xmlList.length;
        for(var i=0;i<length;i++) {
            var xml = xmlList[i];
            if (xml.nodeName == "duration" && clip.chapterDuration) {
                clip.chapterDuration.durationTextfield.text = xml.textContent;
            }
        }

        clip.addEventListener("click",onChapterClick);
        setState(clip);
    }

    function onMouseover(e){

        e.currentTarget.parent.chapterTitle.visible=true;
    }

    function onMouseout(e){
        e.currentTarget.parent.chapterTitle.visible=false;
    }

    function setState(clip){
        var label ="state"+clip.data.state;
        if(clip.data.state == undefined){
            label = "state0";
        }
        clip.chapterIcon.gotoAndStop(label);
    }

    function onChapterClick(e) {
        var clip = e.currentTarget;
        var pageData = clip.data.dataList[0];
        setPage(pageData);
    }

    function initWidget(clip){
        for(var i=0;i<clip.numChildren;i++){
            if(ObjectService.getType(clip.getChildAt(i)) == "MovieClip"){
                checkWidget(clip.getChildAt(i));
            }
        }
    };

    function checkWidget(clip){
        if(clip.name){
            for(var key in pub.config.exerciseDict){
                var flags = key.replace(/.*\/([gimy]*)$/, '$1');
                var pattern = key.replace(new RegExp('^/(.*?)/'+flags+'$'), '$1');
                var regex = new RegExp(pattern, flags);
                if(clip.name.match(regex)){
                    var className = ClassManager.getNameByPath(pub.config.exerciseDict[key]);
                    var exercise = new window[className]();
                    exercise.init(clip);
                }
            }
        }
    }

    /**
     * start loading an exercise
     */
    function setPage(pageData){
        pub.sendNotification("SETUP_CONTENT_COMMAND",pageData);
        pub.sendNotification("SET_VIEW_COMMAND","CONTENT_VIEW");
    }

    this.listNotifications = function(){
        var list = this.super.listNotifications();
        list.push("STATE_CHANGED_COMMAND");
        list.push("CURRENT_PAGE_DATA_CHANGED_COMMAND");
        list.push("PAGE_COMPLETE_EVENT");
        list.push("DATA_STATE_CHANGED_COMMAND");
        return list;
    };

    this.handleNotification = function(notification){
        this.super.handleNotification(notification);
        switch(notification.getName()){
            case "STATE_CHANGED_COMMAND":
            case "CURRENT_PAGE_DATA_CHANGED_COMMAND":
            case "PAGE_COMPLETE_EVENT":
            case "DATA_STATE_CHANGED_COMMAND":
                updateState();
                break;
        }
    };

    /**
     * update all menu items.
     */
    function updateState(){
        for(var i=0;i<_chapterList.length;i++){
            setState(_chapterList[i]);
        }
        checkAllSeen();
    }

    function checkAllSeen(){
        var allSeen = true;
        for(var i=0;i<_chapterList.length;i++){
            var clip = _chapterList[i];
            if(clip.data.state != "2"){
                allSeen = false;
            }
        }

        if(_allSeenFirst){
            if(_allSeenMessage){
                _allSeenMessage.visible = false;
            }

        }else{
            if(allSeen == true && _allSeenMessage){
                _allSeenMessage.visible = true;
            }
        }


    }

});

//- - - - - - - - - - - - - - - - - - - - - - 80 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/mediator/infopool/simple/SimpleInfopoolBtnMediator.js
/**
 * Created by tnguyen on 20.05.2016.
 */
var SimpleInfopoolBtnMediator = SimpleBtnMediator.extend(function(){
    var pub = this;

    this.init = function(){
        pub.ACTIVATE_COMMAND = "ACTIVATE_INFOPOOL_BTN_COMMAND";
        pub.DEACTIVATE_COMMAND = "DEACTIVATE_INFOPOOL_BTN_COMMAND";
        pub.LOCK_COMMAND = "LOCK_INFOPOOL_BTN_COMMAND";
        pub.ON_VIEW = "INFOPOOL_VIEW";
        pub.OFF_VIEW = ViewData.INIT;
        pub.onName = "infopoolOnBtn";
        pub.offName = "infopoolOffBtn";
        pub.mediatorConnectorName = "InfopoolMediator";
        this.super.init();
    };
});

//- - - - - - - - - - - - - - - - - - - - - - 81 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/mediator/infopool/porschepanamerast/PorschePanameraStInfopoolMediator.js
/**
 * Created by fseng on 17.01.2017.
 */
var PorschePanameraStInfopoolMediator = SimpleMediator.extend(function(){
    var pub = this;
    var _scroller;
    var _infopoolContent;

    this.init = function(){
        pub.ACTIVATE_COMMAND = "ACTIVATE_INFOPOOL_COMMAND";
        pub.DEACTIVATE_COMMAND = "DEACTIVATE_INFOPOOL_COMMAND";
        pub.onList.push("INFOPOOL_VIEW");
        this.super.init();
        buildScroller();
    };

    function buildScroller() {
        var scrollerItem = pub.clip.findObjectsByName("scrollerItem",createjs.MovieClip)[0];
        _infopoolContent = pub.clip.findObjectsByName("infopoolContent",createjs.MovieClip)[0];

        if(_infopoolContent) {
            _scroller = new SimpleScroller(
                pub.clip.stage,
                _infopoolContent,
                _infopoolContent.nominalBounds.width,
                scrollerItem.nominalBounds.height,
                scrollerItem,
                true // draggable
            );
            _scroller.updateByHeight(_infopoolContent.nominalBounds.height);
        }
    }

    this.activate = function(){
        this.super.activate();
        _scroller.update(_infopoolContent.nominalBounds.height);
    };
});

//- - - - - - - - - - - - - - - - - - - - - - 82 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/mediator/glossary/simple/SimpleGlossaryBtnMediator.js
/**
 * Created by tnguyen on 20.05.2016.
 */
var SimpleGlossaryBtnMediator = SimpleBtnMediator.extend(function(){
    var pub = this;

    this.init = function(){
        pub.ACTIVATE_COMMAND = "ACTIVATE_GLOSSARY_BTN_COMMAND";
        pub.DEACTIVATE_COMMAND = "DEACTIVATE_GLOSSARY_BTN_COMMAND";
        pub.LOCK_COMMAND = "LOCK_GLOSSARY_BTN_COMMAND";
        pub.ON_VIEW = "GLOSSARY_VIEW";
        pub.OFF_VIEW = ViewData.INIT;
        pub.onName = "glossaryOnBtn";
        pub.offName = "glossaryOffBtn";
        pub.mediatorConnectorName = "GlossaryMediator";
        this.super.init();
    };
});

//- - - - - - - - - - - - - - - - - - - - - - 83 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/mediator/glossary/simple/SimpleGlossaryMediator.js
/**
 * Created by tnguyen on 20.05.2016.
 */
var SimpleGlossaryMediator = SimpleMediator.extend(function(){
    var _this = this;
    var _nodes;
    var _description;
    var _title;
    var _keyContent;
    var _keyScroller;
    var _descrScroller;
    var _descriptionContent;

    this.init = function(){
        this.ACTIVATE_COMMAND = "ACTIVATE_GLOSSARY_COMMAND";
        this.DEACTIVATE_COMMAND = "DEACTIVATE_GLOSSARY_COMMAND";
        this.onList.push("GLOSSARY_VIEW");
        this.super.init();
        setTimeout(initGlossary,0);
    };

    function initGlossary(){
        var glossaryProxy = Facade.getInstance().retrieveProxy("GlossaryProxy");
        if(glossaryProxy) {
            var xml = glossaryProxy.xml;
            _nodes = xml.getElementsByTagName('item');
            _this.clip.findObjectsByName(/^glossaryKey$/).forEach(initGlossaryKey);
            _this.clip.findObjectsByName(/^glossaryDescription$/).forEach(initGlossaryDescription);
            _this.clip.findObjectsByName(/textInput/i).forEach(onTextInput)
        }
    }

    function initGlossaryDescription(glossaryDescription) {
        _descriptionContent = glossaryDescription.descriptionContent;
        _title = glossaryDescription.findObjectsByName(/titleTextField/)[0];
        _description = glossaryDescription.findObjectsByName(/descriptionTextField/)[0];
        _descrScroller = new SimpleScroller(glossaryDescription.stage,_descriptionContent,_descriptionContent.nominalBounds.width,glossaryDescription.scroller.bg.nominalBounds.height,glossaryDescription.scroller, false);
        showEntryByIndex(0);
    }

    function initGlossaryKey(glossaryKey){
        _keyContent = glossaryKey.keyContent;
        var item  = _keyContent.getChildByName('glossaryItem');
        if(item) _keyContent.removeChild(item);
        var ItemClipClass = getItemClipClass();
        for (var i=0; i< _nodes.length; i++){
            var key = _nodes[i].getElementsByTagName('key')[0];
            var clip = new ItemClipClass();
            _keyContent.addChild(clip);
            new MenuItem(clip).setTitle(key.textContent);
            clip._keyIndex = i;
            clip.addEventListener('click', onItemClick);
        }
        behavior.layout(_keyContent);
        _keyContent.layout.update();
        _keyScroller = new SimpleScroller(_keyContent.stage,_keyContent,_keyContent.layoutBounds.width,glossaryKey.scroller.bg.nominalBounds.height,glossaryKey.scroller, false);
        updateKeys();
    }

    function updateKeys(list){
        if(list){
            filterGlossary(list);
        }
        _keyContent.layout.update();
        _keyScroller.updateByHeight(_keyContent.layoutBounds.height);
    }

    function filterGlossary(list){
        var keys = _keyContent.children;
        for(var i=0; i<keys.length; i++){
            var glossarItem = keys[i];
            glossarItem.visible = false;
            for( var j=0; j<list.length; j++){
                if( glossarItem._keyIndex == list[j]){
                    glossarItem.visible = true;
                }
            }
        }
    }

    function searchGlossary(inputTextField){
        var list = [];
        var inputText = inputTextField.value.toLowerCase();

        for(var i=0; i < _keyContent.children.length; i++){
            var glossaryKeyText = _keyContent.children[i].textField.text.toLowerCase();
            if (glossaryKeyText.match(inputText)){
                list.push(_keyContent.children[i]._keyIndex);
            }
        }
        updateKeys(list);
    }


    function getItemClipClass() {
        if (lib['GlossaryItem']) return lib['GlossaryItem'];
    }

    function MenuItem(_clip){
        _clip.mouseChildren = false;
        _clip.cursor= "pointer";
        _clip.addEventListener('staged', onStaged);
        var _textField = _clip.textField;
        var _textInitialHeight = _textField.getBounds().height;
        var _bg = _clip.bg;
        if(_bg){
            _clip.addEventListener('mouseover', onMouseEvent);
            _clip.addEventListener('mouseout', onMouseEvent)
        }

        function onStaged(e){
            if(e.target.gotoAndStop) e.target.gotoAndStop(0);
        }

        function onMouseEvent(e){
           switch (e.type){
               case "mouseover":
                   _bg.gotoAndStop('over');
                   break;
               case "mouseout":
                    _bg.gotoAndStop('out');
                    break;
           }
        }

        this.setTitle = function (text) {
            _textField.text = text;
            var heightDifference =  _textField.getBounds().height - _textInitialHeight
            if(_bg){
                _bg.stop();
                _bg.scaleY = (_bg.nominalBounds.height+heightDifference)/_bg.nominalBounds.height;
            }
            _clip.nominalBounds = new createjs.Rectangle(_clip.nominalBounds.x,_clip.nominalBounds.y,_clip.nominalBounds.width, _clip.nominalBounds.height+heightDifference);
        }
    }

    function onItemClick(e){
        showEntryByIndex(e.currentTarget._keyIndex);
    }

    function showEntryByIndex(index){
        var key = _nodes[index].getElementsByTagName('key')[0];
        var description = _nodes[index].getElementsByTagName('description')[0];
        _title.text = key.textContent;
        _description.text = description.textContent;
        _descrScroller.updateByHeight(_description.getBounds().height+_description.y);
    }

    function onTextInput(e){
            var textInput = new TextInput(e);
            textInput.onKeyUp = searchGlossary;
    }

    function TextInput(_clip){
        var _this = this;
        var _textField = _clip.findObjectsByName(/./,createjs.Text)[0];
        var _bounds = {x:_textField.x, y:_textField.y, width:_clip.nominalBounds.width,height:_clip.nominalBounds.height};
        var _context = document.getElementsByTagName('body')[0];
        var _wrapperMediator = Facade.getInstance().retrieveMediator("WrapperMediator");
        var _input;
        var _scale;

        _clip.addEventListener('click', onClick);

        function onClick (){
            setTimeout(createInput,0);
        }

        function createInput(){
            var pos = _textField.localToGlobal(_bounds.x, _bounds.y);
            _textField.visible= false;
            _input = document.createElement("input");
            _input.setAttribute('type','text');
            _input.setAttribute('style','position:absolute;display:block;padding:0; border:0; vertical-align: top; background:transparent;font:'+_textField.font);
            _input.style.height = /*(2*_textField.lineHeight-_bounds.height)*/_bounds.height+'px';
            _input.style.width = _bounds.width+'px';
            _input.style.top = pos.y+"px";
            _input.style.left = pos.x+"px";
            _input.onkeyup = onKeyUp;
            getScale();
            scaleInput();
            _input.value= _textField.value || _textField.text;
            _context.addEventListener('click',onDone);
            window.addEventListener('resize', onDone);
            _context.appendChild(_input);
            _input.addEventListener('click',function(e){e.stopImmediatePropagation();}); //Bugfix for clickin again on input
            _input.focus();
        }

        function onKeyUp() {
            if(_this.onKeyUp) _this.onKeyUp(_input);
        }

        function onDone(e){
            _context.removeEventListener('click',onDone);
            window.removeEventListener('resize', onDone);
            if(_input && e.target!=_input){
                _context.removeChild(_input);
                var line = _input.value;
                _textField.value = _input.value;
                do {
                    _textField.text = line;
                    line = line.substring(0,line.length-1);
                } while (_textField.getMetrics().lines.length>1);
                _textField.visible= true;

            }
        }

        function getScale(){
            if(_wrapperMediator){
                var comp = _wrapperMediator.getViewComponent();
                _scale = 1;
                if(window.innerWidth < comp.startWidth || window.innerHeight < comp.startHeight){
                    var screenRatio = window.innerWidth / window.innerHeight;
                    var compRatio = comp.startWidth/comp.startHeight;
                    if(compRatio >= screenRatio){
                        _scale = window.innerWidth/comp.startWidth;
                    }
                    else{
                        _scale = window.innerHeight/comp.startHeight;
                    }
                }
            }
        }

        function scaleInput(){
            if(_scale === 1){
                _input.style.transform = "";
                _input.style.transformOrigin = "";
            }else{
                _input.style.transform = "scale("+_scale+")";
                _input.style.transformOrigin = "0 0";
            }
        }


    }






});

//- - - - - - - - - - - - - - - - - - - - - - 84 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/mediator/content/porscheaftersales/PorscheAftersalesContentMediator.js
/**
 * Created by cduerbeck on 03.12.2018.
 */

var PorscheAftersalesContentMediator = SimpleContentMediator.extend(function(){
    var pub = this;

    this.init = function(){
        this.super.init();
        pub.onList.push("CONTENT_VIEW");
        pub.orList.push("SITEMAP_VIEW");
    };

    this.onCloseClick = function(e){
        pub.sendNotification("SET_VIEW_COMMAND",ViewData.INIT);
        pub.sendNotification("UNLOAD_CONTENT_COMMAND");
    };

});


//- - - - - - - - - - - - - - - - - - - - - - 85 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/mediator/index/simple/SimpleIndexMediator.js
/**
 * Created by tnguyen on 24.05.2016.
 */
var SimpleIndexMediator = SimpleMediator.extend(function(){
    var pub = this;
    var _bar;
    var _barMode = 'position';
    var _indexTextField;
    var _structureData;

    this.init = function(){
        pub.ACTIVATE_COMMAND = "ACTIVATE_INDEX_COMMAND";
        pub.DEACTIVATE_COMMAND = "DEACTIVATE_INDEX_COMMAND";
        this.super.init();
        _structureData = Facade.getInstance().retrieveProxy("StructureProxy").getData();
        pub.clip.findObjectsByName(/^bar(\b|_)/).forEach(getBar)
        pub.clip.findObjectsByName(/indexTextField/).forEach(getTextField);
    };

    function getBar(clip){
        _bar = clip;
         var mode = clip.name.match(/^bar_(position|progress)/);
         if(mode) _barMode = mode[1]
        _bar.gotoAndStop(0);
        Object.defineProperty(_bar,"framePosition",{
            get: function(){return this.currentFrame;},
            set: function(value){this.gotoAndStop(value)}
        });
    }

    function getTextField(textField){
        _indexTextField = textField;
    }

    this.listNotifications = function(){
        var list = this.super.listNotifications();
        list.push("STATE_CHANGED_COMMAND");
        list.push("PAGE_COMPLETE_EVENT");
        list.push("CURRENT_PAGE_DATA_CHANGED_COMMAND");
        return list;
    };

    this.handleNotification = function(notification){
        this.super.handleNotification(notification);
        switch(notification.getName()){
            case "STATE_CHANGED_COMMAND":
            case "PAGE_COMPLETE_EVENT":
            case "CURRENT_PAGE_DATA_CHANGED_COMMAND":
                pub.update();
                break;
        }
    };

    this.update = function(){
        var currentIndex = _structureData.getPageDataIndex(_structureData.currentPageData.id)+1;
        if(_indexTextField){
            _indexTextField.text = currentIndex+"/"+_structureData.globalPageDataList.length;
        }
        if(_bar){
            var frame;
            switch (_barMode){
                case "progress":
                    frame = _structureData.progressMeasure*100;
                    break;
                default:
                    var percent = (currentIndex-1)/(_structureData.globalPageDataList.length-1);
                    frame = (percent*100);
            }
            tweenBar(frame);
        }
    };

    function tweenBar(to){
         createjs.Tween.removeTweens(_bar);
         createjs.Tween.get(_bar).to({framePosition:to},150);
     }

    Object.defineProperty(this,"structureData",{
        get: function(){
            return _structureData;
        }
    });

    Object.defineProperty(this,"indexTextField",{
        get: function(){
            return _indexTextField;
        }
    });
});

//- - - - - - - - - - - - - - - - - - - - - - 86 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/mediator/header/simple/SimpleHeaderMediator.js
/**
 * Created by tnguyen on 25.05.2016.
 */
var SimpleHeaderMediator = SimpleMediator.extend(function(){
    var pub = this;

    var _bar;
    var _chapterTextField;
    var _pageTextField;
    var _pageTextTemplate;
    var _structureData;

    this.init = function(){
        pub.ACTIVATE_COMMAND = "ACTIVATE_HEADER_COMMAND";
        pub.DEACTIVATE_COMMAND = "DEACTIVATE_HEADER_COMMAND";
        this.super.init();
        _structureData = Facade.getInstance().retrieveProxy("StructureProxy").getData();
        ObjectService.getObjectFromClip(pub.clip,getTextField,"Text","chapterTextField");
        ObjectService.getObjectFromClip(pub.clip,getTextField,"Text","pageTextField");
    };

    function getTextField(textField){
        switch(textField.name){
            case "chapterTextField":
                _chapterTextField = textField;
                break;
            case "pageTextField":
                _pageTextField = textField;
                if(_pageTextField.text.match(/#/)) _pageTextTemplate = _pageTextField.text;
                break;
        }
    }

    this.listNotifications = function(){
        var list = this.super.listNotifications();
        list.push("CURRENT_PAGE_DATA_CHANGED_COMMAND");
        return list;
    };

    this.handleNotification = function(notification){
        this.super.handleNotification(notification);
        switch(notification.getName()){
            case "CURRENT_PAGE_DATA_CHANGED_COMMAND":
                update();
                break;
        }
    };

    function update(){

        if(_chapterTextField){
            _chapterTextField.text = _structureData.currentPageData.parentData.name;
        }
        var parentData = _structureData.currentPageData.parentData;

        var topData = parentData;
        while (topData.parentData){
            topData = topData.parentData;
        }

        if(_pageTextField){
            if(_pageTextTemplate){
               var text = _pageTextTemplate;
               text = text.replace('#chapter',parentData.name || '');
               text = text.replace('#top', topData.name || '');
               text = text.replace('#page',_structureData.currentPageData.name || '');
               while (parentData.parentData && parentData.parentData != parentData){
                   parentData = parentData.parentData;
               }
               text = text.replace('#root',parentData.name || '');
               _pageTextField.text = text;
            } else {
               _pageTextField.text = _structureData.currentPageData.name;
            }

        }
    }
});

//- - - - - - - - - - - - - - - - - - - - - - 87 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/mediator/background/simple/SimpleBackgroundMediator.js
/**
 * Created by tnguyen on 01.06.2016.
 */
var SimpleBackgroundMediator = SimpleMediator.extend(function(){
    var pub = this;

    this.init = function(){
        pub.ACTIVATE_COMMAND = "ACTIVATE_BACKGROUND_COMMAND";
        pub.DEACTIVATE_COMMAND = "DEACTIVATE_BACKGROUND_COMMAND";
        this.super.init();
    };
});

//- - - - - - - - - - - - - - - - - - - - - - 88 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/mediator/wrapper/simple/SimpleWrapperMediator.js
/**
 * Created by tnguyen on 20.05.2016.
 */
var SimpleWrapperMediator = SimpleMediator.extend(function(){
    var pub = this;

    this.init = function(){
        pub.ACTIVATE_COMMAND = "ACTIVATE_WRAPPER_COMMAND";
        pub.DEACTIVATE_COMMAND = "DEACTIVATE_WRAPPER_COMMAND";
        this.super.init();
    };
});

//- - - - - - - - - - - - - - - - - - - - - - 89 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/mediator/startmobile/simple/SimpleStartMobileBtnMediator.js
/**
 * Created by tnguyen on 08.06.2016.
 */
var SimpleStartMobileBtnMediator = SimpleBtnMediator.extend(function(){
    var pub = this;

    this.init = function(){
        pub.ACTIVATE_COMMAND = "ACTIVATE_START_MOBILE_BTN_COMMAND";
        pub.DEACTIVATE_COMMAND = "DEACTIVATE_START_MOBILE_BTN_COMMAND";
        this.super.init();
    };

    this.eventHandler = function(e){
        pub.sendNotification("START_MOBILE_COMMAND");
    }
});

//- - - - - - - - - - - - - - - - - - - - - - 90 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/mediator/navigation/porscheserviceberater/PorscheServiceberaterNavigationMediator.js
/**
 * Created by cduerbeck on 24.09.18.
 */


var PorscheServiceberaterNavigationMediator = SimpleMediator.extend(function(){
    var pub = this;
    var _prevBtn;
    var _nextBtn;
    var _stepBtn;
    var _content;
    var _stepBtnList;
    var _stepscount;

    this.init = function(){
        pub.ACTIVATE_COMMAND = "ACTIVATE_NAVIGATION_COMMAND";
        pub.DEACTIVATE_COMMAND = "DEACTIVATE_NAVIGATION_COMMAND";
        this.super.init();
        // pub.onList.push("CONTENT_VIEW");
        _prevBtn = pub.clip.findObjectsByName("prevBtn",createjs.MovieClip)[0];
        _nextBtn = pub.clip.findObjectsByName("nextBtn",createjs.MovieClip)[0];
        _stepBtn = pub.clip.findObjectsByName("stepBtn",createjs.MovieClip)[0];
        _nextBtn.visible = false;
        _prevBtn.visible = false;
        _stepBtn.visible = false;
        _stepBtnList = [];
        configureListener();
    };

    function configureListener() {
        _content = Facade.getInstance().retrieveMediator("ContentMediator").getViewComponent();

        _prevBtn.addEventListener("click", onClickPrev);
        _nextBtn.addEventListener("click", onClickNext);
        _content.addEventListener("START", navigationHandler);
        _content.addEventListener("END", navigationHandler);
        _content.addEventListener("STEP", navigationHandler);
        _content.addEventListener("NO_STEP", navigationHandler);
        _content.addEventListener("STEPS_COUNT", navigationHandler);
        _content.addEventListener("STEPNUM", navigationHandler);
        _content.addEventListener("REMOVE_STEPBUTTONS", navigationHandler);

    function onClickPrev(e) {
        _content.dispatchEvent("PREV_STEP");
    }

    function onClickNext(e) {
        _content.dispatchEvent("NEXT_STEP");
    }

    function navigationHandler(e) {
        //if(CheckManager.isMobile()) {

        switch(e.type) {
            case "START":
                _nextBtn.visible = true;
                _prevBtn.visible = false;
                break;
            case "END":
                _nextBtn.visible = false;
                _prevBtn.visible = true;
                break;
            case "STEP":
                _nextBtn.visible = true;
                _prevBtn.visible = true;
                break;
            case "NO_STEP":
                _nextBtn.visible = false;
                _prevBtn.visible = false;
                break;
            case "STEPS_COUNT":
                _stepscount = e.detail;
                createStepButtons();
                break;
            case "STEPNUM":
                var stepnum = (e.detail + 1).toString();
                hiliteStepButton(stepnum);
                break;
            case "REMOVE_STEPBUTTONS":
                removeStepBtnChilds();
                _nextBtn.visible = false;
                _prevBtn.visible = false;
                break;
        }
        //}
    }

    function createStepButtons() {

        var contentComp = Facade.getInstance().retrieveMediator("ContentMediator").getViewComponent();
        var contentWidth = contentComp.nominalBounds.width;
        var prevBtnWidth = _prevBtn.nominalBounds.width;
        var stepwidth = 50;
        var startX = contentWidth/2 - (stepwidth/2*(_stepscount-1));


        var i=0;
        if(_stepscount>=2){
            _prevBtn.x = startX - stepwidth - prevBtnWidth;
            for(i=0;i<_stepscount; i++){
                var stepBtnClip = new lib["stepBtn"]();
                _content.addChild(stepBtnClip);
                stepBtnClip.gotoAndStop(0);
                stepBtnClip.y = _stepBtn.y;
                stepBtnClip.x = startX + (i * stepwidth);
                stepBtnClip.addEventListener("click",onStepClick);
                stepBtnClip.cursor='pointer';
                stepBtnClip.targetName = "step" + (i+1).toString();
                _stepBtnList.push(stepBtnClip);
            }
            _content.addChild(_nextBtn);
            _content.addChild(_prevBtn);
            _nextBtn.x = startX + ((i+1)* stepwidth);
        }else{
            _prevBtn.visible = false;
            _nextBtn.visible = false;
        }

    }

    function removeStepBtnChilds(){
        if(_stepBtnList){
            while(_stepBtnList.length > 0){
                var clip = _stepBtnList[0];
                if(clip.parent){
                    clip.parent.removeChild(clip);
                    clip = null;
                }
                _stepBtnList.shift();
            }
        }
    }

    function hiliteStepButton(stepnum) {
        for(var i=0;i<_stepBtnList.length; i++){
            if(_stepBtnList[i].targetName.substring(4) === stepnum){
                _stepBtnList[i].gotoAndStop(1);
            }else{
                _stepBtnList[i].gotoAndStop(0);
            }
        }
    }

        function onStepClick(e) {
            var stepClicked = e.currentTarget.targetName.substring(4);
            _content.dispatchEvent({type:"STEP_CLICKED",detail:stepClicked, bubbles:true});
        }

    }
});

//- - - - - - - - - - - - - - - - - - - - - - 91 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/mediator/preloader/simple/SimplePreloaderMediator.js
/*
 autor: tilo 8/2016
 */

var SimplePreloaderMediator = SimpleMediator.extend(function(){

    this.init = function(){
        this.super.init();
    };

    this.listNotifications = function(){
        var list = this.super.listNotifications().concat([
            "ACTIVATE_PRELOADER_COMMAND",
            "DEACTIVATE_PRELOADER_COMMAND",
        ]);
        return list;
    };

    this.handleNotification = function (notification){
            switch(notification.getName()){
                case "ACTIVATE_PRELOADER_COMMAND":
                        this.clip.parent.addChild(this.clip);
                        this.clip.gotoAndPlay(0);
                        this.activate();
                        break;
                case "DEACTIVATE_PRELOADER_COMMAND":
                        this.deactivate();
                        this.clip.stop();
                        break;
            }
    }


});

//- - - - - - - - - - - - - - - - - - - - - - 92 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/mediator/view/porschepanamerast/PorschePanameraStViewMediator.js
/**
 * Created by fseng on 18.11.2016.
 */
var PorschePanameraStViewMediator = SimpleViewMediator.extend(function() {

    var pub = this;

    this.viewChanged = function(view){
        //console.log("viewChanged: "+view);
        switch(view){
            case ViewData.INIT:
            case "CONTENT_VIEW":
                pub.sendNotification("RESUME_COMMAND");
                break;
            default:
                pub.sendNotification("PAUSE_COMMAND");
                break;
        }
    };

    this.setWrapper = function(){
        var mediator = Facade.getInstance().retrieveMediator("WrapperMediator");
        if(mediator){
            var comp = mediator.getViewComponent();
            var scaleX = 1;
            var scaleY = 1;
            var maxScale = 1.3;

            var ratioX = window.innerWidth/1218;
            var ratioY = window.innerHeight/808;// --> iframe in Porsche Academy cuts footer-Button with 803;

            if(ratioX < ratioY) {
                if(ratioX > maxScale) {
                    scaleX = maxScale;
                    scaleY = maxScale;
                } else {
                    scaleX = ratioX;
                    scaleY = ratioX;
                }
            } else {
                if(ratioY > maxScale) {
                    scaleX = maxScale;
                    scaleY = maxScale;
                } else {
                    scaleX = ratioY;
                    scaleY = ratioY;
                }
            }


            comp.scaleX = scaleX;
            comp.scaleY = scaleY;
            comp.x = window.innerWidth/2 - (comp.startWidth*scaleX)/2;
            comp.y = 0;
        }
    }

});

//- - - - - - - - - - - - - - - - - - - - - - 93 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/mediator/video/porschepanamerast/PorschePanameraStVideoBtnMediator.js
/**
 * Created by fseng on 15.11.2016.
 */
var PorschePanameraStVideoBtnMediator = SimpleBtnMediator.extend(function(){
    var pub = this;

    this.init = function(){
        pub.ACTIVATE_COMMAND = "ACTIVATE_VIDEO_BTN_COMMAND";
        pub.DEACTIVATE_COMMAND = "DEACTIVATE_VIDEO_BTN_COMMAND";
        pub.LOCK_COMMAND = "LOCK_VIDEO_BTN_COMMAND";
        pub.ON_VIEW = "VIDEO_VIEW";
        pub.mediatorConnectorName = "VideoMediator";
        this.super.init();
    };

});


//- - - - - - - - - - - - - - - - - - - - - - 94 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/mediator/video/porschepanamerast/PorschePanameraStVideoMediator.js
/**
 * Created by fseng on 15.11.2016.
 */
var PorschePanameraStVideoMediator = SimpleMediator.extend(function(){
    var pub = this;

    this.init = function(){
        pub.ACTIVATE_COMMAND = "ACTIVATE_VIDEO_COMMAND";
        pub.DEACTIVATE_COMMAND = "DEACTIVATE_VIDEO_COMMAND";
        pub.onList.push("VIDEO_VIEW");
        this.super.init();
    };

    this.viewChanged = function(view) {
        this.super.viewChanged(view);
        if(view == "VIDEO_VIEW") {
            pub.clip.dispatchEvent("ACTIVATE");
        }
    }

    this.onCloseClick = function() {
        this.super.onCloseClick();
        pub.clip.dispatchEvent("DEACTIVATE");
    }
});

//- - - - - - - - - - - - - - - - - - - - - - 95 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/mediator/continue/porschepanamerast/PorschePanameraStContinueBtnMediator.js
/**
 * Created by fseng on 18.11.2016.
 */
var PorschePanameraStContinueBtnMediator = SimpleBtnMediator.extend(function(){
    var pub = this;

    this.init = function(){
        pub.ACTIVATE_COMMAND = "ACTIVATE_CONTINUE_BTN_COMMAND";
        pub.DEACTIVATE_COMMAND = "DEACTIVATE_CONTINUE_BTN_COMMAND";
        pub.LOCK_COMMAND = "LOCK_CONTINUE_BTN_COMMAND";
        this.super.init();
    };

    this.eventHandler = function(e){
        var structureData = Facade.getInstance().retrieveProxy("StructureProxy").getData();
        var currentPageId = structureData.currentPageData.id;

        for(var i=0; i<structureData.globalPageDataList.length;i++) {
            if(structureData.globalPageDataList[i].id == currentPageId) {
                if(i == structureData.globalPageDataList.length - 1) {
                    var pageData = structureData.globalPageDataList[0];
                    pub.sendNotification("SETUP_CONTENT_COMMAND",pageData);
                    pub.sendNotification("SET_VIEW_COMMAND","CONTENT_VIEW");
                    return;
                } else {
                    var nextPage = i+1;
                    var pageData = structureData.globalPageDataList[nextPage];
                    pub.sendNotification("SETUP_CONTENT_COMMAND",pageData);
                    pub.sendNotification("SET_VIEW_COMMAND","CONTENT_VIEW");
                    return;
                }
            }
        }
    };
});

//- - - - - - - - - - - - - - - - - - - - - - 96 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/mediator/sitemap/porscheaftersales/PorscheAfersalesSitemapBtnMediator.js
/**
 * Created by cduerbeck on 03.12.2018.
 */

var PorscheAfersalesSitemapBtnMediator = SimpleBtnMediator.extend(function(){
    var pub = this;

    this.init = function(){
        pub.ACTIVATE_COMMAND = "ACTIVATE_SITEMAP_BTN_COMMAND";
        pub.DEACTIVATE_COMMAND = "DEACTIVATE_SITEMAP_BTN_COMMAND";
        pub.LOCK_COMMAND = "LOCK_SITEMAP_BTN_COMMAND";
        pub.ON_VIEW = "SITEMAP_VIEW";
        pub.OFF_VIEW = "CONTENT_VIEW";
        pub.onName = "sitemapOnBtn";
        pub.offName = "sitemapOffBtn";
        pub.mediatorConnectorName = "SitemapMediator";
        this.super.init();
    };

    this.eventHandler = function(e){
        var click = e.currentTarget;
        switch(click.comp.name){
            case pub.onName:
                pub.sendNotification("SET_VIEW_COMMAND",pub.ON_VIEW);
                break;
            case pub.offName:
                if(Facade.getInstance().retrieveMediator("MenuMediator").isActivated){
                    pub.sendNotification("SET_VIEW_COMMAND",ViewData.INIT);
                }else{
                    pub.sendNotification("SET_VIEW_COMMAND",pub.OFF_VIEW);
                }

                break;
            default:
                pub.sendNotification("SET_VIEW_COMMAND",pub.ON_VIEW);
                break;
        }
    };
});

//- - - - - - - - - - - - - - - - - - - - - - 97 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/mediator/sitemap/porscheaftersales/PorscheAftersalesSitemapMediator.js
/**
 * Created by cduerbeck on 07.11.18.
 */

var PorscheAftersalesSitemapMediator = SimpleMediator.extend(function() {
    var pub = this;
    var _structureProxy;
    var _chapterDataList;
    var _sitemapChapterItemList;
    var _sitemapContent;
    var _sitemapHeight;


    this.init = function () {
        this.super.init();
        pub.ACTIVATE_COMMAND = "ACTIVATE_SITEMAP_COMMAND";
        pub.DEACTIVATE_COMMAND = "DEACTIVATE_SITEMAP_COMMAND";
        pub.onList.push("SITEMAP_VIEW");
        _structureProxy = Facade.getInstance().retrieveProxy("StructureProxy");
        _chapterDataList = _structureProxy.getData().chapterDataList;
        build();
    };


    function build() {
        _sitemapChapterItemList = [];
        var sitemapChapterItemTemplate = pub.clip.findObjectsByName("sitemapChapterItem",createjs.MovieClip)[0];
        _sitemapContent = pub.clip.findObjectsByName("sitemapContent",createjs.MovieClip)[0];
        setTimeout(function(){sitemapChapterItemTemplate.parent.removeChild(sitemapChapterItemTemplate);},0);


        var posY = 0;
        for(var i = 0;i<_chapterDataList.length;i++) {
            if(_chapterDataList[i].category && _chapterDataList[i].category.match(/hideInMenu/)){
            }else{

                var sitemapChapterItem = new lib["sitemapChapterItem"]();
                _sitemapChapterItemList.push(sitemapChapterItem);
                sitemapChapterItem.chapterTitleTextfield.text = _chapterDataList[i].name;
                sitemapChapterItem.data = _chapterDataList[i];
                sitemapChapterItem.addEventListener("click",onChapterClick);
                _sitemapContent.addChild(sitemapChapterItem);

                //neu:
                var textHeight = sitemapChapterItem.chapterTitleTextfield.getBounds().height;
                sitemapChapterItem.nominalBounds.height = (sitemapChapterItem.chapterTitleTextfield.y*2) + textHeight;
                if(sitemapChapterItem.sitemapChapterItemline){
                    sitemapChapterItem.sitemapChapterItemline.y = sitemapChapterItem.nominalBounds.height;
                }

                sitemapChapterItem.y = posY;
                posY += sitemapChapterItem.nominalBounds.height;

                if(sitemapChapterItem.sitemapChapterItemBg){
                    var scaleFactor = sitemapChapterItem.nominalBounds.height/sitemapChapterItem.sitemapChapterItemBg.nominalBounds.height;
                    sitemapChapterItem.sitemapChapterItemBg.scaleY = scaleFactor;
                    sitemapChapterItem.sitemapChapterItemBg.cursor = "pointer";
                    sitemapChapterItem.sitemapChapterItemBg.mouseChildren = false;
                }
            }
        }

        _sitemapHeight = sitemapChapterItem.y + sitemapChapterItem.nominalBounds.height;

        setTimeout(updateStates,0);
        setTimeout(buildScroller,0);
        //CheckManager.setGridAlign(_sitemapChapterItemList,1,999);
    }

    function buildScroller() {
        var scrollerItem = pub.clip.findObjectsByName("scrollerItem",createjs.MovieClip)[0];

        _scroller = new SimpleScroller(
            pub.clip.stage,
            _sitemapContent,
            _sitemapContent.nominalBounds.width,
            scrollerItem.nominalBounds.height,
            scrollerItem,
            true // draggable
        );

        _scroller.updateByHeight(_sitemapHeight);
        //_scroller.updateByHeight(_sitemapChapterItemList[0].nominalBounds.height * _sitemapChapterItemList.length);
    }

    function updateStates() {
        for(var i = 0;i<_sitemapChapterItemList.length;i++) {
            var sitemapChapterItem = _sitemapChapterItemList[i];
            var label ="state"+sitemapChapterItem.data.state;
            if(sitemapChapterItem.data.state == undefined){
                label = "state0";
            }
            sitemapChapterItem.chapterIcon.gotoAndStop(label);
        }
    }

    function onChapterClick(e) {
        var clip = e.currentTarget;
        var pageData = clip.data.dataList[0];
        pub.sendNotification("DEACTIVATE_SITEMAP_COMMAND");
        setPage(pageData);
    }

    function setPage(pageData){
        pub.sendNotification("SETUP_CONTENT_COMMAND",pageData);
        pub.sendNotification("SET_VIEW_COMMAND","CONTENT_VIEW");
    }

    this.listNotifications = function(){
        var list = this.super.listNotifications();
        list.push("STATE_CHANGED_COMMAND");
        list.push("CURRENT_PAGE_DATA_CHANGED_COMMAND");
        list.push("PAGE_COMPLETE_EVENT");
        list.push("DATA_STATE_CHANGED_COMMAND");
        return list;
    };

    this.handleNotification = function(notification){
        this.super.handleNotification(notification);
        switch(notification.getName()){
            case "STATE_CHANGED_COMMAND":
            case "CURRENT_PAGE_DATA_CHANGED_COMMAND":
            case "PAGE_COMPLETE_EVENT":
            case "DATA_STATE_CHANGED_COMMAND":
                updateStates();
                break;
        }
    };

    this.onCloseClick = function(e){
        pub.sendNotification("DEACTIVATE_SITEMAP_COMMAND");
    };
});


//- - - - - - - - - - - - - - - - - - - - - - 98 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/mediator/slideshow/porschepanamerast/PorschePanameraStSlideshowBtnMediator.js
/**
 * Created by cduerbeck on 09.05.2017.
 */
var PorschePanameraStSlideshowBtnMediator = SimpleBtnMediator.extend(function(){
    var pub = this;

    this.init = function(){
        pub.ACTIVATE_COMMAND = "ACTIVATE_SLIDESHOW_BTN_COMMAND";
        pub.DEACTIVATE_COMMAND = "DEACTIVATE_SLIDESHOW_BTN_COMMAND";
        pub.LOCK_COMMAND = "LOCK_SLIDESHOW_BTN_COMMAND";
        pub.ON_VIEW = "SLIDESHOW_VIEW";
        pub.OFF_VIEW = ViewData.INIT;
        pub.onName = "slideshowOnBtn";
        pub.offName = "slideshowOffBtn";
        pub.mediatorConnectorName = "SlideshowMediator";
        this.super.init();
    };
});

//- - - - - - - - - - - - - - - - - - - - - - 99 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/mediator/slideshow/porschepanamerast/PorschePanameraStSlideshowMediator.js
/**
 * Created by cduerbedck on 09.05.2017.
 */
var PorschePanameraStSlideshowMediator = SimpleMediator.extend(function(){
    var pub = this;
    var _slideShowWidget;

    this.init = function(){
        pub.ACTIVATE_COMMAND = "ACTIVATE_SLIDESHOW_COMMAND";
        pub.DEACTIVATE_COMMAND = "DEACTIVATE_SLIDESHOW_COMMAND";
        pub.onList.push("SLIDESHOW_VIEW");
        this.super.init();
        startSlideShow();
    };

    function startSlideShow() {
        pub.clip.gotoAndPlay(0);
        _slideShowWidget = pub.clip.findObjectsByName("slideShowWidget",createjs.MovieClip)[0];
    }

    this.activate = function(){
        this.super.activate();
        _slideShowWidget.dispatchEvent("RESET");
    };

});

//- - - - - - - - - - - - - - - - - - - - - - 100 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/command/simple/InitCommand.js
/**
 * Created by tnguyen on 02.05.2016.
 */
var InitCommand = Command.extend(function(){
    var _this = this;
    var _notificationList = [];

    this.execute = function(notification){
        _notificationList.push({name:"INIT_PROXY_COMMAND",body:notification.getBody()});
        _notificationList.push({name:"IMPORT_DATA_COMMAND",body:notification.getBody()});
        _notificationList.push({name:"INIT_MEDIATOR_COMMAND",body:notification.getBody()});
        _notificationList.push({name:"INIT_START_COMMAND"});
        //
        setTimeout(run,0);
        //run()
    };

    function run(){
         _this.executeNotificationList(_notificationList);
    }
});


//- - - - - - - - - - - - - - - - - - - - - - 101 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/command/simple/ImportDataCommand.js
/**
 * Created by tilo hauke 14.7.2016
 */
var ImportDataCommand = Command.extend(function(){
    this.execute = function(notification){
        this.super.execute(notification);
        var structureData = Facade.getInstance().retrieveProxy("StructureProxy").getData();
        var userData = Facade.getInstance().retrieveProxy("UserProxy").getData();
        if(userData.data){
            var stateData = userData.data.data;
            updateStates(stateData,structureData);
        }
        this.sendNotification("UPDATE_LOCK_COMMAND");
        this.complete();
    };

    function updateStates(stateData,structureData){
        for(var key in stateData){
            var data = structureData.getDataById(key);
            if(data && data.id == key){
                data.state = stateData[key];
            }
        }
    }
});


//- - - - - - - - - - - - - - - - - - - - - - 102 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/command/simple/InitProxyCommand.js
/**
 * Created by tnguyen on 02.05.2016.
 */
var InitProxyCommand = Command.extend(function(){
    var pub = this;
    var _proxyDict;
    var _assetManager;
    var _config;

    this.execute = function(notification){
        this.super.execute(notification);
        _config = notification.getBody();
        _proxyDict = notification.getBody().proxyDict;
        _assetManager = notification.getBody().assetManager;
        register();
        initXMLProxy();
    };

    function register(){
        for(var key in _proxyDict){
            if(key == "ConfigProxy"){
                var configProxy = new ConfigProxy(_config);
                Facade.getInstance().registerProxy("ConfigProxy",configProxy);
            }
            else{
                if(typeof(_proxyDict[key]) == "object"){
                    var proxyName = ClassManager.getNameByPath(_proxyDict[key].proxy);
                    if(_proxyDict[key].data){
                        var dataName = ClassManager.getNameByPath(_proxyDict[key].data);
                        var proxy;
                        if(_proxyDict[key].params){
                            proxy = new window[proxyName](new window[dataName](_proxyDict[key].params));
                        }else{
                            proxy = new window[proxyName](new window[dataName]());
                        }
                    }
                    else{
                        proxy = new window[proxyName]();
                    }
                    Facade.getInstance().registerProxy(key,proxy);
                }
            }
        }
    }

    /**
     * call init method of all proxies and pass XML as parameter.
     */
    function initXMLProxy(){
        var assetList = _assetManager.assetList;
        for(var i=0;i<assetList.length;i++){
            var proxy = Facade.getInstance().retrieveProxy(assetList[i].name);
            if(proxy){
                proxy.init(assetList[i].data);
            }
        }
        pub.complete();
    }
});


//- - - - - - - - - - - - - - - - - - - - - - 103 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/command/simple/InitMediatorCommand.js
/**
 * Created by tnguyen on 22.04.2016.
 */
var InitMediatorCommand = Command.extend(function(){

    var pub = this;
    var _clip;
    var _list;
    var _mediatorDict;
    var _config;
    var _mediatorList;

    this.execute = function(notification){
        this.super.execute(notification);
        _list = [];
        _clip = notification.getBody().stage;
        _config = notification.getBody();
        _mediatorDict = notification.getBody().mediatorDict;
        _clip.name = "root";
        setFrameText(_clip);
        identifyMediator();
        register();
        init();
    };

    function setFrameText(clip){
        var textService = new TextService();
        textService.init(clip,_config.assetManager.getAssetByName("frameText").data);
    }

    function identifyMediator(){
        for(var key in _mediatorDict){
            ObjectService.getObjectFromClip(_clip,getClip,"MovieClip",key);
        }
    }

    function getClip(clip){
        var name = ClassManager.getNameByPath(_mediatorDict[clip.name]);
        _list.push({clipName:clip.name,className:name,path:_mediatorDict[clip.name],clip:clip});
    }

    function register(){
        _mediatorList = [];
        for(var key in _mediatorDict){
            var obj = getMediatorObj(key);
            var className;
            if(obj){
                className = obj.className;
                var clipName = obj.clipName;
                if(window[className]){
                    var mediator = new window[className](obj.clip);
                    _mediatorList.push(mediator);
                    Facade.getInstance().registerMediator(clipName,mediator);
                }
            }
            else{
                className = ClassManager.getNameByPath(_mediatorDict[key]);
                if(window[className] && key.substr(0,1) == "_"){
                    if (key == "_PreloaderMediator"){
                       var preloaderClip = _clip.getChildByName('preloader');
                       if (preloaderClip) {
                            var className = ClassManager.getNameByPath(_mediatorDict[key]);
                            var mediator = new window[className](preloaderClip);
                            _mediatorList.push(mediator);
                       }
                    } else {
                        var mediator = new window[className]();
                        _mediatorList.push(mediator);
                    }
                    Facade.getInstance().registerMediator(key,mediator);
                }
            }
        }
    }

    function init(){
        for(var i=0;i<_mediatorList.length;i++){
            if(_mediatorList[i].hasOwnProperty("init")){
                _mediatorList[i].init();
            }
        }
        pub.complete();
    }

    function getMediatorObj(key){
        for(var i=0;i<_list.length;i++){
            if(_list[i].clipName == key){
                return _list[i];
            }
        }
    }
});

//- - - - - - - - - - - - - - - - - - - - - - 104 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/command/porscheaftersales/PorscheAftersalesInitStartCommand.js
/**
 * Created by cduerbeck on 22.10.18.
 */

var PorscheAftersalesInitStartCommand = Command.extend(function() {
    var pub = this;

    this.execute = function(notification){
        this.super.execute(notification);
        var frameContent =  Facade.getInstance().retrieveProxy("ConfigProxy").getData().assetManager.getAssetByName("frameContent").data;
        frameContent.visible = true;
        if(CheckManager.isMobile()){
            pub.sendNotification("ACTIVATE_WRAPPER_COMMAND");
            pub.sendNotification("ACTIVATE_START_MOBILE_BTN_COMMAND");
        }
        else{
            pub.sendNotification("ACTIVATE_SITEMAP_BTN_COMMAND");
            pub.sendNotification("ACTIVATE_IMPRINT_BTN_COMMAND");
            pub.sendNotification("ACTIVATE_HELP_BTN_COMMAND");
            pub.sendNotification("ACTIVATE_VIDEO_BTN_COMMAND");
            pub.sendNotification("ACTIVATE_INFOPOOL_BTN_COMMAND");
            pub.sendNotification("ACTIVATE_BACKGROUND_COMMAND");
            pub.sendNotification("ACTIVATE_WRAPPER_COMMAND");
            pub.sendNotification("ACTIVATE_INDEX_COMMAND");
            pub.sendNotification("ACTIVATE_CONTENT_COMMAND");
            //pub.sendNotification("ACTIVATE_MENU_COMMAND");
            pub.sendNotification("ACTIVATE_CONTINUE_BTN_COMMAND");
            pub.sendNotification("ACTIVATE_SLIDESHOW_BTN_COMMAND");



            var structureProxy = Facade.getInstance().retrieveProxy("StructureProxy");
            var structureData = structureProxy.getData();
            var lastPageData;

            var userData = Facade.getInstance().retrieveProxy("UserProxy").getData();
            if(userData.currentDataId){
                lastPageData = structureData.getDataById(userData.currentDataId,structureProxy.getData().globalPageDataList);
                if(!lastPageData){
                    lastPageData = structureData.globalPageDataList[0];
                }
            }
            else {
                lastPageData = structureData.globalPageDataList[0];
            }
            pub.sendNotification("SETUP_CONTENT_COMMAND",lastPageData);
            pub.sendNotification("SET_VIEW_COMMAND","CONTENT_VIEW");
           // pub.sendNotification("SET_VIEW_COMMAND","MENU_VIEW");
        }
    };

});


//- - - - - - - - - - - - - - - - - - - - - - 105 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/command/simple/SetupContentCommand.js
/**
 * Created by tnguyen on 19.05.2016.
 */
var SetupContentCommand = Command.extend(function() {
    var pub = this;

    this.constructor = function(){
        this.super.constructor();
    };

    this.execute = function(notification){
        pub.sendNotification("LOCK_CONTENT_COMMAND",false);
        pub.sendNotification("SOUND_COMMAND",null,"REMOVE_SOUNDS");
        pub.sendNotification("SOUND_COMMAND",null,"STOP_SOUND");
        var notificationList = [];
        if(notification.getBody()){
            pub.sendNotification("STRUCTURE_DATA_COMMAND",notification.getBody(),"SET_CURRENT_PAGE_DATA");
        }
        notificationList.push({name:"UNLOAD_CONTENT_COMMAND"});
        notificationList.push({name:"LOAD_CONTENT_COMMAND"});
        notificationList.push({name:"REGISTER_CONTENT_COMMAND"});
        notificationList.push({name:"INIT_CONTENT_COMMAND"});
        this.executeNotificationList(notificationList);
    }
});

//- - - - - - - - - - - - - - - - - - - - - - 106 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/command/simple/UnloadContentCommand.js
/**
 * Created by tnguyen on 19.05.2016.
 */
var UnloadContentCommand = Command.extend(function() {
    var pub = this;

    this.execute = function(notification){
        this.super.execute(notification);
        var contentProxy = Facade.getInstance().retrieveProxy("ContentProxy");
        pub.sendNotification("SOUND_COMMAND",null,"STOP_SOUND");
        pub.sendNotification("SOUND_COMMAND",null,"REMOVE_SOUNDS");
        pub.sendNotification("DESTROY_CONTENT_COMMAND");

        if(contentProxy.currentContent){
            if(contentProxy.currentContent.parent){
                contentProxy.currentContent.parent.removeChild(contentProxy.currentContent);
                contentProxy.currentContent = null;
            }
        }
        pub.complete();
    }
});

//- - - - - - - - - - - - - - - - - - - - - - 107 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/command/simple/LoadContentCommand.js
/**
 * Created by tnguyen on 19.05.2016.
 */
var LoadContentCommand = Command.extend(function() {
    var pub = this;
    var _currentPageData;
    var _structureData;
    var _contentProxy;
    var _handleCompleted;

    this.execute = function(notification){
        this.super.execute(notification);
        _structureData = Facade.getInstance().retrieveProxy("StructureProxy").getData();
        _contentProxy = Facade.getInstance().retrieveProxy("ContentProxy");
        _currentPageData = _structureData.currentPageData;
        loadXML();
    };

    function loadXML(){
        pub.sendNotification("ACTIVATE_PRELOADER_COMMAND");
        if(!_currentPageData.textXML){
            var path = (_currentPageData.xmlPath)? _currentPageData.xmlPath:_structureData.baseXML+_currentPageData.id+".xml";
            ClassManager.addComplete("LoadContentCommandXML"+_currentPageData.id,onCompleteXML);
            ClassManager.addError("LoadContentCommandXML"+_currentPageData.id,onCompleteXML);
            ClassManager.load(path,"LoadContentCommandXML"+_currentPageData.id);
        }
        else{
            loadPage(_currentPageData);
        }
    }

    function onCompleteXML(e){
        if(e.data.data){
            _currentPageData.textXML = e.data.data;
        }
        loadPage(_currentPageData);
    }

    function loadPage(){
        createjs.LoadItem.LOAD_TIMEOUT_DEFAULT = 100000; //wait 100 seconds :-)))
        _handleCompleted = false;
         pub.sendNotification("ACTIVATE_PRELOADER_COMMAND");
        _currentPageData.contentPath = (_currentPageData.contentPath)?_currentPageData.contentPath:_structureData.baseContent+_currentPageData.id+".js";
        ClassManager.addComplete("LoadContentCommandSwf"+_currentPageData.id,onCompleteContent);
        ClassManager.load(_currentPageData.contentPath,"LoadContentCommandSwf"+_currentPageData.id);
    }

    function onCompleteContent(e){
        var loader = new createjs.LoadQueue(false);
        loader.addEventListener("fileload", handleFileLoad);
        loader.addEventListener("complete", handleComplete);
        loader.addEventListener("error", handleError);
        loader.loadManifest(lib.properties.manifest);
    };

    function handleError(e) {
        handleComplete();
    }

    function handleFileLoad(e) {
        if (e.item.type == "image") { images[e.item.id] = e.result; }
    }

    function handleComplete(e) {
        if(!_handleCompleted){
            _handleCompleted = true;
            var className = ClassManager.getNameByPath(_currentPageData.contentPath);
            var contentComp = Facade.getInstance().retrieveMediator("ContentMediator").getViewComponent();
            var content = new lib[className]();
            _contentProxy.currentContent = content;
            content.visible = false;
            content.name = "content-root";
            contentComp.addChildAt(content,0);
            content.gotoAndStop(0);
            pub.sendNotification("DEACTIVATE_PRELOADER_COMMAND");
            pub.complete();
        }
    }


});

//- - - - - - - - - - - - - - - - - - - - - - 108 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/command/simple/RegisterContentCommand.js
/**
 * Created by tnguyen on 19.05.2016.
 */
var RegisterContentCommand = Command.extend(function() {
    var pub = this;
    var _config;
    var _contentProxy;
    var _structureProxy;

    this.constructor = function(){
        _config = Facade.getInstance().retrieveProxy("ConfigProxy").getData();
        _contentProxy = Facade.getInstance().retrieveProxy("ContentProxy");
        _structureProxy = Facade.getInstance().retrieveProxy("StructureProxy");
    };

    this.execute = function(notification){
        this.super.execute(notification);
        var content = _contentProxy.currentContent;
        var group = _structureProxy.getData().currentPageData.group;
        if(_config.contentDict[group] != undefined){
            registerMediator(content,group);
        }
        else{
            registerMediator(content,"standard");
        }
    };

    function registerMediator(content,group){
        var mediator;
        if(_contentProxy.contentMediatorDict[group]){
            mediator = _contentProxy.contentMediatorDict[group];
            mediator.setViewComponent(content);
        }
        else{
            var className = ClassManager.getNameByPath(_config.contentDict[group]);
            mediator = new window[className](content);
            mediator.name = group;
            _contentProxy.contentMediatorDict[group] = mediator;
        }
        Facade.getInstance().registerMediator(group,mediator);
        pub.complete();
    }
});

//- - - - - - - - - - - - - - - - - - - - - - 109 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/command/simple/InitContentCommand.js
/**
 * Created by tnguyen on 19.05.2016.
 */
var InitContentCommand = Command.extend(function() {
    var pub = this;

    this.execute = function(notification){
        var structureData = Facade.getInstance().retrieveProxy("StructureProxy").getData();
        var textXML = structureData.currentPageData.textXML;
        var contentName = ClassManager.getNameByPath(structureData.currentPageData.contentPath);
        var autoPart;
        pub.sendNotification("START_CONTENT_COMMAND",{textXML:textXML,autoPart:structureData.currentPageData.autoPart,contentName:contentName});
        pub.sendNotification("UPDATE_LOCK_COMMAND");
        pub.sendNotification("CHECK_COMPLETION_COMMAND");
    }
});

//- - - - - - - - - - - - - - - - - - - - - - 110 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/command/simple/SetViewCommand.js
/**
 * Created by tnguyen on 20.05.2016.
 */
var SetViewCommand = Command.extend(function() {
    var pub = this;

    this.execute = function(notification){
        var viewData = Facade.getInstance().retrieveProxy("ViewProxy").getData();
        viewData.currentView = notification.getBody();
    }
});

//- - - - - - - - - - - - - - - - - - - - - - 111 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/command/simple/NextCommand.js
/**
 * Created by tnguyen on 23.05.2016.
 */
var NextCommand = Command.extend(function() {
    var pub = this;

    this.execute = function(notification){
        pub.sendNotification("LOCK_CONTENT_COMMAND",false);
        pub.sendNotification("SOUND_COMMAND",null,"STOP_SOUND");
        pub.sendNotification("NEXT_PART_COMMAND");
    }
});

//- - - - - - - - - - - - - - - - - - - - - - 112 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/command/simple/NextPageCommand.js
/**
 * Created by tnguyen on 23.05.2016.
 */
var NextPageCommand = Command.extend(function() {
    var pub = this;

    this.execute = function(notification){
        var structureProxy = Facade.getInstance().retrieveProxy("StructureProxy");
        var nextPageData = structureProxy.getData().getNextPageData(structureProxy.getData().currentPageData);
        if(nextPageData){
            pub.sendNotification("SETUP_CONTENT_COMMAND",nextPageData);
        }
    }
});

//- - - - - - - - - - - - - - - - - - - - - - 113 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/command/simple/PreviousCommand.js
/**
 * Created by tnguyen on 24.05.2016.
 */
var PreviousCommand = Command.extend(function() {
    var pub = this;

    this.execute = function(notification){
        pub.sendNotification("LOCK_CONTENT_COMMAND",false);
        pub.sendNotification("SOUND_COMMAND",null,"STOP_SOUND");

        var contentProxy = Facade.getInstance().retrieveProxy("ContentProxy");
        var structureData = Facade.getInstance().retrieveProxy("StructureProxy").getData();
        var pageMediator = Facade.getInstance().retrieveMediator("standard");
        var previousPart;
        var currentPart;
        if(pageMediator){
            previousPart = pageMediator.pageController.pageClipService.getPreviousPartLabel();
            currentPart = pageMediator.pageController.pageClipService.getCurrentPartLabel();
        }
        if(previousPart){
            pub.sendNotification("PREVIOUS_PART_COMMAND");
        }else{
            if(structureData.currentPageData == structureData.globalPageDataList[0]){
                pub.sendNotification("PREVIOUS_PART_COMMAND");
            }
            else{
                pub.sendNotification("PREVIOUS_PAGE_COMMAND");
            }
        }

    }
});

//- - - - - - - - - - - - - - - - - - - - - - 114 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/command/simple/PreviousPageCommand.js
/**
 * Created by tnguyen on 24.05.2016.
 */
var PreviousPageCommand = Command.extend(function() {
    var pub = this;

    this.execute = function(notification){
        var structureProxy = Facade.getInstance().retrieveProxy("StructureProxy");
        var previousPageData = structureProxy.getData().getPreviousPageData(structureProxy.getData().currentPageData);
        if(previousPageData){
            pub.sendNotification("SETUP_CONTENT_COMMAND",previousPageData);
        }
    }
});

//- - - - - - - - - - - - - - - - - - - - - - 115 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/command/simple/SoundCommand.js
/**
 * Created by tnguyen on 24.05.2016.
 */
var SoundCommand = Command.extend(function() {
    var pub = this;
    var _structureData;

    this.execute = function(notification){
        _structureData = Facade.getInstance().retrieveProxy("StructureProxy").getData();
        var obj = notification.getBody();
        switch(notification.getType()){
            case "REMOVE_SOUNDS":
                SoundManager.getInstance().pauseAll();
                SoundManager.getInstance().removeAllSounds();
                break;
            case "LOOP_SOUND":
                play(obj.toString(),99999,1);
                break;
            case "PLAY_SOUND":
                SoundManager.getInstance().stopAll();
                play(obj.toString());
                break;
            case "PLAY_EXTRA_SOUND":
                if(! SoundManager.getInstance().isSoundPlaying(obj.toString())) soundProxy.soundService.play(obj.toString());
                break;
            case "STOP_SOUND":
                if(obj){SoundManager.getInstance().stop(obj.toString());}
                else{SoundManager.getInstance().stopAll();}
                break;
            case "PAUSE_SOUND":
                if(obj){SoundManager.getInstance().pause(obj.toString());}
                else{SoundManager.getInstance().pauseAll();}
                break;
            case "RESUME_SOUND":
                if(obj){SoundManager.getInstance().resume(obj.toString());}
                else{SoundManager.getInstance().resumeAll();}
                break;
            case "ADD_SOUND_LIST":
                addSoundList(obj);
                break;
            case "SOUND_ON":
                SoundManager.getInstance().setVolume(1);
                break;
            case "SOUND_OFF":
                SoundManager.getInstance().setVolume(0);
                break;
            case "VOLUME":
                SoundManager.getInstance().setVolume(notification.getBody());
                break;
        }
    };

    function play(name,loop,volume){
        if(name.match(/^\w+_empty+$/)){
            name = "empty";
        }
        if(!SoundManager.getInstance().soundExists(name)){
            var path = _structureData.baseAudio+name+".mp3";
            SoundManager.getInstance().register(name,path);
        }
        SoundManager.getInstance().play(name,loop,volume);
    }

    function addSoundList(obj){
        for (var i=0;i<obj.list.length;i++){
            var name = obj.contentName+"_"+obj.list[i];
            var path = _structureData.baseAudio+name+".mp3";
            SoundManager.getInstance().register(name,path);
        }
    }
});


//- - - - - - - - - - - - - - - - - - - - - - 116 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/command/simple/ReloadCommand.js
/**
 * Created by tnguyen on 24.05.2016.
 */
var ReloadCommand = Command.extend(function() {
    var pub = this;

    this.execute = function(notification){
        pub.sendNotification("SETUP_CONTENT_COMMAND");
    }
});

//- - - - - - - - - - - - - - - - - - - - - - 117 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/command/simple/PauseCommand.js
/**
 * Created by tnguyen on 25.05.2016.
 */
var PauseCommand = Command.extend(function() {
    var pub = this;

    this.execute = function(notification){
        pub.sendNotification("SOUND_COMMAND",null,"PAUSE_SOUND");
        pub.sendNotification("PAUSE_CONTENT_COMMAND");
    }
});

//- - - - - - - - - - - - - - - - - - - - - - 118 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/command/simple/ResumeCommand.js
/**
 * Created by tnguyen on 25.05.2016.
 */
var ResumeCommand = Command.extend(function() {
    var pub = this;

    this.execute = function(notification){
        pub.sendNotification("SOUND_COMMAND",null,"RESUME_SOUND");
        pub.sendNotification("RESUME_CONTENT_COMMAND");
    }
});

//- - - - - - - - - - - - - - - - - - - - - - 119 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/command/porscheaftersales/PorscheAftersalesStructurdataCommand.js
/**
 * Created by cduerbeck on 23.10.18.
 */

var PorscheAftersalesStructurdataCommand = Command.extend(function(){
    var pub = this;
    var _structureData;

    this.constructor = function(){
        this.super.constructor();
        _structureData = Facade.getInstance().retrieveProxy("StructureProxy").getData();
    };

    this.execute = function(notification){
        this.super.execute(notification);
        switch(notification.getType()){
            case "SET_CURRENT_PAGE_DATA":
                _structureData.currentPageData = notification.getBody();

                if(_structureData.currentPageData.id == _structureData.globalPageDataList[0].id){
                    pub.sendNotification("DEACTIVATE_EXIT_BTN_COMMAND");//immediately activated in PorschePanameraStExitBtnMediator if not page 1!
                    pub.sendNotification("DEACTIVATE_SITEMAP_BTN_COMMAND");
                }
                break;
            case "SET_DATA_COMPLETE":
                notification.getBody().state = "2";
                pub.checkProgress();
                pub.sendNotification("ACTIVATE_EXIT_BTN_COMMAND");
                pub.sendNotification("ACTIVATE_SITEMAP_BTN_COMMAND");
                break;

        }
    };

    this.checkProgress = function(){
        if(_structureData.rootChapter.state=="2") {
            pub.sendNotification("USER_DATA_COMMAND",'completed',"COMPLETED");
            pub.sendNotification("USER_DATA_COMMAND",null,"FILE");
        }
    }
});



//- - - - - - - - - - - - - - - - - - - - - - 120 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/command/simple/UserDataCommand.js
/**
 * Created by tnguyen on 27.05.2016.
 */
var UserDataCommand = Command.extend(function(){
    var pub = this;
    var _userData;

    this.constructor = function(){
        this.super.constructor();
        _userData = Facade.getInstance().retrieveProxy("UserProxy").getData();
    };

    this.execute = function(notification){
        this.super.execute(notification);
        switch(notification.getType()){
            case "DATA":
                _userData.saveData(notification.getBody());
                break;
            case "CURRENT_DATA":
                _userData.currentDataId = notification.getBody().id;
                break;
            case "PROGRESS_MEASURE":
                _userData.progressMeasure = notification.getBody().toString();
                break;
            case "SUCCESS":
                _userData.success = notification.getBody().toString();
                break;
            case "SCORE":
                _userData.score = notification.getBody();
                break;
            case "COMPLETED":
                _userData.completed = notification.getBody().toString();
                break;
            case "FILE":
                _userData.saveFile();
                break;
        }
    };
});

//- - - - - - - - - - - - - - - - - - - - - - 121 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/command/simple/PageCompleteCommand.js
/**
 * Created by tnguyen on 30.05.2016.
 */
var PageCompleteCommand = Command.extend(function() {
    var pub = this;

    this.execute = function(notification){
        var structureData = Facade.getInstance().retrieveProxy("StructureProxy").getData();
        var pageData = structureData.currentPageData;
        var nextPageData = structureData.getNextPageData(pageData);

        if(pageData.group != "final") {
            pub.sendNotification("STRUCTURE_DATA_COMMAND", pageData, "SET_DATA_COMPLETE");
        }

        pub.sendNotification("UPDATE_LOCK_COMMAND");
        pub.sendNotification("PAGE_COMPLETE_EVENT");
        if (pageData.autoPage == "true") {
            if (nextPageData) {
                pub.sendNotification("SETUP_CONTENT_COMMAND", nextPageData);
            }
        }
    };
});

//- - - - - - - - - - - - - - - - - - - - - - 122 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/command/porscheaftersales/PorscheAftersalesStartMobileCommand.js
/**
 * Created by cduerbeck on 22.10.18.
 */

var PorscheAftersalesStartMobileCommand = Command.extend(function() {
    var pub = this;

    this.constructor = function(){
        this.super.constructor();
    };

    this.execute = function(notification){
        window.globalAudio = new Audio();
        window.globalAudio.play();
        start();
    };

    function start(){
        pub.sendNotification("DEACTIVATE_START_MOBILE_BTN_COMMAND");
        pub.sendNotification("ACTIVATE_SOUND_BTN_COMMAND");
        pub.sendNotification("ACTIVATE_BACKGROUND_COMMAND");
        pub.sendNotification("ACTIVATE_SITEMAP_BTN_COMMAND");
        pub.sendNotification("ACTIVATE_IMPRINT_BTN_COMMAND");
        pub.sendNotification("ACTIVATE_HELP_BTN_COMMAND");
        pub.sendNotification("ACTIVATE_VIDEO_BTN_COMMAND");
        pub.sendNotification("ACTIVATE_EXIT_BTN_COMMAND");
        pub.sendNotification("ACTIVATE_INFOPOOL_BTN_COMMAND");
        pub.sendNotification("ACTIVATE_BACKGROUND_COMMAND");
        pub.sendNotification("ACTIVATE_WRAPPER_COMMAND");
        pub.sendNotification("ACTIVATE_INDEX_COMMAND");
        pub.sendNotification("ACTIVATE_CONTENT_COMMAND");
        pub.sendNotification("ACTIVATE_CONTINUE_BTN_COMMAND");

        var frameContent =  Facade.getInstance().retrieveProxy("ConfigProxy").getData().assetManager.getAssetByName("frameContent").data;
        frameContent.visible = true;
        var structureProxy = Facade.getInstance().retrieveProxy("StructureProxy");
        var structureData = structureProxy.getData();
        var lastPageData;

        var userData = Facade.getInstance().retrieveProxy("UserProxy").getData();
        if(userData.currentDataId){
            lastPageData = structureData.getDataById(userData.currentDataId,structureProxy.getData().globalPageDataList);
            if(!lastPageData){
                lastPageData = structureData.globalPageDataList[0];
            }
        }
        else{
            lastPageData = structureData.globalPageDataList[0];
        }
        pub.sendNotification("SETUP_CONTENT_COMMAND",lastPageData);
        setTimeout(function(){update(frameContent.stage)},100)
    }


    function update(stage){
        stage.update();
    }
});


//- - - - - - - - - - - - - - - - - - - - - - 123 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/command/simple/CompletedCommand.js
/**
 * Created by mpham on 05.09.2016.
 */

var CompletedCommand = Command.extend(function() {
    this.execute = function(notification){
        var userProxy = Facade.getInstance().retrieveProxy("UserProxy");
        if(userProxy.getData().completed != "completed"){
            this.sendNotification("USER_DATA_COMMAND","completed","COMPLETED");
            this.sendNotification("USER_DATA_COMMAND",null,"FILE");
        }
    }
});

//- - - - - - - - - - - - - - - - - - - - - - 124 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/command/simple/GoToPageCommand.js
/**
 * Created by tilo 10/2016
 */

var GoToPageCommand = Command.extend(function() {
    var pub = this;
    this.execute = function(notification){
        var id = notification.getBody().id;
        var structureData = Facade.getInstance().retrieveProxy("StructureProxy").getData();
        var pageData = structureData.getDataById(id,structureData.globalPageDataList);
        if(pageData){
            //console.log('GoToExerciseCommand', id, pageData.id);
            pub.sendNotification("SETUP_CONTENT_COMMAND",pageData);
        }
    }
});


//- - - - - - - - - - - - - - - - - - - - - - 125 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/mediator/page/exercise/simple/SimpleSpecificSCExercise.js
var SimpleSpecificSCExercise = SimpleSCExercise.extend(function(){
    var pub = this;
    var _maxTry;

    this.init = function(clip){
        this.super.init(clip);
        _maxTry = getTry();
    };

    function getTry(){
        var lastName="";
        var cnt=0;
        var wrongList = pub.wrongList;
        for(var i =0;i < wrongList.length; i++){
            var name = wrongList[i].split("_")[0];
            if(name != lastName){
                lastName = name;
                cnt++;
            }
        }
        return cnt;
    }


    this.showWrong = function (){
            var label = getSpecialLabel("wrong"+(this.currentTry+1).toString());

            pub.playSound(label);
            pub.clip.gotoAndPlay(label);
            var lastFrameOfLabel = CheckManager.getLastFrameOfLabel(pub.clip,label);

            //console.log('label', label, lastFrameOfLabel);
            CheckManager.tweenToFrame(pub.clip,lastFrameOfLabel,NaN,pub.onShowLabelComplete,label);

            this.currentTry++;
            if(pub.currentTry == _maxTry){
                pub.showFeedbackIcon();
                pub.checkBtn.visible = false;
                pub.lock = true;
                if(pub.solutionBtn){
                    pub.solutionBtn.visible = true;
                }
            }
    }



    function getWrongSelectedChoiceId(){
        for (var n in pub.choiceDict){
            var clip =  pub.choiceDict[n];
            if(clip.selection.visible && clip.state == false){
                    return clip.name.substr(6);
            }
        }
    }

    function getSpecialLabel(label) {
        var wrongSelectedChoiceId = getWrongSelectedChoiceId();
        if(pub.clip.labels.filter(function(item){ return item.label==label+wrongSelectedChoiceId}).length) label+=wrongSelectedChoiceId;
        return label;

    }


});

//- - - - - - - - - - - - - - - - - - - - - - 126 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/mediator/page/exercise/innocorp/FrameStepperExercise.js
/**
 * Created by cduerbeck on 13.07.16.
 */
var FrameStepperExercise = SimpleExercise.extend(function() {

    var pub = this;
    var _clip;
    var _saveBtn;
    var _stopWatch;
    var _stepperList;
    var _frameStepperList;
    var _exerciseResultData;

    this.init = function(clip){
        this.super.init(clip);
        _clip = clip;

        var exerciseId = pub.currentContentName+String(clip.name.match(/EX\d+/));
        pub.exerciseResultData = new SimpleExerciseResultData(exerciseId,"FS");
        _exerciseResultData = pub.exerciseResultData;

        _frameStepperList = [];
        _stepperList = clip.findObjectsByName(/frameStepper/);  //e.g. [MovieClip (name=frameStepper_01)], [...]
        _stepperList.sort();//sorts also terms as "11" ok if we use "01" instead of "1"
        //console.log("_stepperList sorted:  " + _stepperList);
        _stepperList.forEach(getStepper);

        ObjectService.getObjectFromClip(pub.clip,getSaveBtn,"MovieClip","saveBtn",true);
        ObjectService.getObjectFromClip(pub.clip, getStopWatch,"MovieClip","stopWatch",true);
    }


    function getStepper(clip){
        var stepper = new FrameStepper();
        stepper.init(clip, "steppedMc", "nextBtn", "previousBtn");
        stepper.addEvent("changed",onChanged);
        _frameStepperList.push(stepper);
    }


    function getSaveBtn(clip){
        _saveBtn = clip;
        _saveBtn.visible = false;
        _saveBtn.addEventListener("click", onSave)
    }

    function getStopWatch(clip){
        _stopWatch = new StopWatch();
        _stopWatch.init(clip);
        _stopWatch.addEvent("timeOver",onTimeOver);
        _stopWatch.addEvent("repeat",onRepeat);
        _stopWatch.run();
    }

    function onSave(e){
        e.currentTarget.visible = false;
        if(_stopWatch){
            _stopWatch.exerciseFinished();
        }
        lockRating();
        saveValues();

        _clip.dispatchEvent({type:SimpleContentEvent.EXERCISE_RESULT,detail:pub.exerciseResultData, bubbles:true});
        _clip.dispatchEvent({type:SimpleContentEvent.EXERCISE_COMPLETE,detail:pub.currentContentName, bubbles:true});
      }

    function saveValues(){
        var valueList = [];
        for(var i=0;i<_stepperList.length;i++){
            //e.g. [MovieClip (name=frameStepper_01)]
            var frame = _stepperList[i].steppedMc.currentFrame;
            //console.log('---->', i , frame);
            var itemValue = (frame).toString();
            valueList.push(itemValue);
        }

        var state = 2;//we do not evaluate, so it is always seen as correct
        pub.exerciseResultData.addTry(state, valueList);//state,input
    }

    function onChanged(e){
        if(_saveBtn){
            _saveBtn.visible = true;
        }
    }

    function onTimeOver(e){
        //console.log("onTimeOver!!!");
        lockRating();
    }

    function onRepeat(e){
        //console.log("Repeat!!!");
        unlockRating();
    }

    function lockRating(){
        for(var i=0;i<_frameStepperList.length;i++){
            _frameStepperList[i].lock = true;
        }
    }

    function unlockRating(){
        for(var i=0;i<_frameStepperList.length;i++){
            _frameStepperList[i].lock = false;
        }
    }

});

//- - - - - - - - - - - - - - - - - - - - - - 127 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/mediator/page/exercise/porscheaftersales/PorscheAftersalesSliderExercise.js
/**
 * Created by cduerbeck on 30.10.18.
 */

var PorscheAftersalesSliderExercise = SimpleExercise.extend(function() {

    var _self = this;
    var _clip;
    var _slideWidgetList  = [];

    this.init = function(clip){
        this.super.init(clip);
        _self.maxTry = _self.wrongList.length;
        _self.exerciseResultData = new SimpleExerciseResultData(_self.currentContentName+"."+clip.name,"SL");
        _clip = clip;
        clip.findObjectsByName(/slideItem\d*/).forEach(initSlideWidget);
    }

    this.check = function(){
        var value = '2'
        _self.slideWidgetList.forEach(function(widget){
            for (var id in widget.sliderDict) {
                if(widget.sliderDict[id].isCorrect!== true) value = '0';
            }
        });
        return value;
    }


    this.showSolution = function(){
        _self.slideWidgetList.forEach(function(widget){
            widget.showSolution();
            widget.hideEvaluation();
        });
        this.super.showSolution();
    }

    this.showEvaluation = function (){
        for(var i=0;i<_slideWidgetList.length;i++){
            _slideWidgetList[i].showEvaluation();
        }
    }

    this.getInput = function(){
        var data = {list:[]};
        _self.slideWidgetList.forEach(function(widget){
            var widgetData = {};
            for (var id in widget.sliderDict) {
                var slider = widget.sliderDict[id];
                widgetData[id] ={x:slider.x,y:slider.y};
            }
            data.list.push(widgetData);
        });
        return data;
    };

    this.setInput = function(data){
        for (var i = 0; i < data.list.length; i++) {
            var widgetData  = data.list[i];
            var widget = _self.slideWidgetList[i];
            for (var id in widget.sliderDict) {
                var slider = widget.sliderDict[id];
                slider.x = widgetData[id].x;
                slider.y = widgetData[id].y;
            }
        }

        this.showEvaluation();
    };

    this.checkHandler = function(e){
        var state = _self.check();

        switch(state){
            case "2":
                _self.showCorrect();
                if(_self.checkBtn)  _self.checkBtn.visible= false;
                break;
            default:
                if (_self.currentTry == (_self.maxTry-1)) {
                    _self.showEvaluation();
                    if(_self.solutionBtn)  _self.solutionBtn.visible= true;
                    if(_self.checkBtn)  _self.checkBtn.visible= false;
                }
                _self.showWrong();
        }
        _self.currentTry ++
        _self.exerciseResultData.addTry(state,_self.getInput());
        _self.dispatchResult();
    };


    //this function has not yet been tested!
    this.dispatchResult = function () {
        var event = new createjs.Event("EXERCISE_RESULT");
        event.detail = _self.exerciseResultData;
        _clip.dispatchEvent({type:SimpleContentEvent.EXERCISE_RESULT,detail:_self.exerciseResultData, bubbles:true});
    }

    function initSlideWidget(clip){
        var slideWidget = new SimpleSlideWidget();
        slideWidget.init(clip);
        clip.addEventListener("slide",onSlide);
        _slideWidgetList.push(slideWidget);
    }

    function onSlide(){
        _self.checkBtn.visible = true;
    }

    this.onReset = function (e){
        _self.clip.gotoAndStop(1);
        _self.reset();
    };

    this.reset = function(){
        this.super.reset();
        _clip.stage.update();
        /*
         for(var i=0;i<_slideWidgetList.length;i++){
         _slideWidgetList[i].init(_self.clip);
         }*/
    };

    Object.defineProperty(this,"slideWidgetList",{
        get: function(){
            return _slideWidgetList;
        }
    });

});



//- - - - - - - - - - - - - - - - - - - - - - 128 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/mediator/page/exercise/porscheaftersales/PorscheAftersalesDDCheckTargetsExercise.js
/**
 * Created by cduerbeck on 08.01.2019.
 */

var PorscheAftersalesDDCheckTargetsExercise = SimpleExercise.extend(function() {
    var pub = this;
    var _dragDict;
    var _dropDict;
    var _currentDrag;

    this.init = function(clip){
        this.super.init(clip);
        pub.maxTry = pub.wrongList.length;
        pub.exerciseResultData = new SimpleExerciseResultData(pub.currentContentName+clip.name,SimpleExerciseResultData.DD);

        _dragDict = new Object();
        _dropDict = new Object();
        ObjectService.getObjectFromClip(pub.clip,getDrag,"MovieClip","drag_",true);
        ObjectService.getObjectFromClip(pub.clip,getDrop,"MovieClip","drop_",true);
    };


    this.showCorrect = function(){
        showFeedbackIcon();
        this.super.showCorrect();
        pub.checkBtn.visible = false;
    };

    this.showPartlyCorrect = function(){
        showFeedbackIcon();
        this.super.showPartlyCorrect();
    };

    this.showWrong = function(){
        this.super.showWrong();
        pub.currentTry++;
        showFeedbackIcon();
        if(pub.currentTry == pub.maxTry){
            pub.checkBtn.visible = false;
            pub.lock = true;
            if(pub.solutionBtn){
                pub.solutionBtn.visible = true;
            }
        }
    };

    this.showSolution = function(){
        resetDrags();
        resetDrops();
        this.super.showSolution();
        var time = 1;
        for(var key in _dragDict){
            var drag = _dragDict[key];
            if(!isDragInLastInputCorrect(drag.id)){
                var drop = getEmptyDrop(drag);
                if(drop){
                    drop.currentDrag = drag;
                    var dropPoint = CheckManager.getLocalPoint(drop,drag);
                    Tweener.addTween(drag,{x:dropPoint.x,y:dropPoint.y,time:time,overwrite:true});
                }
                else{
                    Tweener.addTween(drag,{x:drag.startPoint.x,y:drag.startPoint.y,time:time,overwrite:true});
                }
            }
            drag.isCorrect = true;
        }
    };

    this.showLabel = function(list){
        if(list){
            var length = pub.currentTry;
            for(var i=pub.currentTry;i>-1;i--){
                if(list[i]){
                    if(pub.clip.currentLabel != list[i]){
                        pub.playSound(list[i]);
                        pub.clip.gotoAndStop(list[i]);
                        CheckManager.tweenToFrame(pub.clip,CheckManager.getLastFrameOfLabel(pub.clip,list[i]),NaN,pub.onShowLabelComplete,list[i]);
                        return;
                    }
                }
            }
        }
    };

    function getEmptyDrop(drag){
        var list = drag.dropIdList;
        if(list){
            var length = list.length;
            for(var i=0;i<length;i++){
                if(_dropDict[list[i]].currentDrag == null && !isDropInLastInputCorrect(list[i])){
                    return _dropDict[list[i]];
                }
            }
        }
        return null;
    }

    function isDropInLastInputCorrect(dropId){
        if(pub.exerciseResultData.resultList.length){
            var inputObj = pub.exerciseResultData.resultList[pub.exerciseResultData.resultList.length-1].input;
            for(var key in inputObj){
                var obj = inputObj[key];
                if(obj.currentDropId == dropId && obj.isCorrect){
                    return true;
                }
            }
        }
        return false;
    }


    function showFeedbackIcon(){
        for(var key in _dragDict){
            var drag = _dragDict[key];
            if(getCurrentDrop(drag)){
                if(drag.isCorrect){
                    drag.correct.visible = true;
                    drag.wrong.visible = false;
                }
                else{
                    if(pub.currentTry == pub.maxTry){
                        drag.correct.visible = false;
                        drag.wrong.visible = true;
                    }
                }
            }
            else{
                drag.correct.visible = false;
                drag.wrong.visible = false;
            }
        }
    }

    this.check = function(){
        var cnt = 0;
        var totalCnt = 0;
        var resultState = "0";
        for(var key in _dropDict){
            var drop = _dropDict[key];
            totalCnt++;
            if(pub.isDropCorrect(drop)){
                cnt++;
                //drop.isCorrect = true;
            }
            else{
                //drop.isCorrect = false;
            }
        }
        if(cnt == totalCnt){
            resultState = "2";
        }
        else if(cnt > 0){
            resultState = "1";
        }
        return resultState;
    };

    this.isDropCorrect = function(drop){
        for(var key in _dragDict){
            var drag = _dragDict[key];
            if(drop.currentDrag == drag){
                if(drag.dropIdList && drag.dropIdList.indexOf(drop.id) != -1){
                    drag.isCorrect = true;
                    return true;
                }
                else{
                    drag.isCorrect = false;
                    return false;
                }
            }
        }
        /*if(drag.dropIdList == null){
            return true;
        }*/
        return false;
    };


    function isDragInLastInputCorrect(dragId){
        if(pub.exerciseResultData.resultList.length){
            var inputObj = pub.exerciseResultData.resultList[pub.exerciseResultData.resultList.length-1].input;
            for (var key in inputObj){
                if(key == dragId && inputObj[key].isCorrect){
                    return true;
                }
            }
        }
        return false;
    }

    function getDrag(clip){
        clip.id = getId(clip.name);
        _dragDict[clip.id] = clip;
        clip.correct.visible = false;
        clip.wrong.visible = false;
        clip.dropIdList = getDropIdList(clip.name);
        clip.startPoint = {x:clip.x,y:clip.y};
        clip.addEventListener("mousedown",onDown);
    }

    function getDrop(clip){
        clip.id = getId(clip.name);
        _dropDict[clip.id] = clip;
    }

    function getId(name){
        var parts = name.split('_');
        return parts[1] || name;
    }

    function getDropIdList(name){
        var list = name.split("_");
        if(list.length > 2){
            return list.slice(2);
        }
        return null;
    }

    function onDown(e){
        e.stopPropagation();
        if(!pub.lock){
            _currentDrag = e.currentTarget;
            if(!_currentDrag.isCorrect || (_currentDrag.isCorrect && isDragOnStartPoint(_currentDrag))){
                var localPos = _currentDrag.parent.globalToLocal(_currentDrag.stage.mouseX, _currentDrag.stage.mouseY);
                var deltaX = localPos.x - _currentDrag.x;
                var deltaY = localPos.y - _currentDrag.y;
                _currentDrag.deltaPosition = {x:deltaX,y:deltaY};
                _currentDrag.stage.addEventListener("pressmove",onMove);
                _currentDrag.parent.setChildIndex(_currentDrag,_currentDrag.parent.numChildren-1);
                _currentDrag.stage.addEventListener("pressup",onUp);
            }
        }
    }

    function onMove(e){
        var localPos = _currentDrag.parent.globalToLocal(_currentDrag.stage.mouseX, _currentDrag.stage.mouseY);
        _currentDrag.x = localPos.x - _currentDrag.deltaPosition.x;
        _currentDrag.y = localPos.y - _currentDrag.deltaPosition.y;
    }

    function isDragOnStartPoint(drag){
        if(drag.x != drag.startPoint.x || drag.y != drag.startPoint.y){
            return false;
        }
        else{
            return true;
        }
    }

    function onUp(e){
        _currentDrag.stage.removeEventListener("pressmove",onMove);
        _currentDrag.stage.removeEventListener("pressup",onUp);
        checkDragDrop();
    }

    function checkDragDrop(){
        for(var key in _dropDict){
            var drop = _dropDict[key];
            var localPos = drop.globalToLocal(drop.stage.mouseX, drop.stage.mouseY);
            if(drop.hitTest(localPos.x,localPos.y)){
                if(drop.currentDrag){
                    moveBack(drop.currentDrag);
                }
                cleanDrag(_currentDrag);
                var dropPoint = CheckManager.getLocalPoint(drop,_currentDrag);
                Tweener.addTween(_currentDrag,{x:dropPoint.x,y:dropPoint.y,time:0.5,overwrite:true});
                drop.currentDrag = _currentDrag;
                checkVisibleCheckBtn();
                return;
            }
        }

        moveBack(_currentDrag);
        cleanDrag(_currentDrag);
        checkVisibleCheckBtn();
    }

    function moveBack(drag){
        Tweener.addTween(drag,{x:drag.startPoint.x,y:drag.startPoint.y,time:0.5,overwrite:true});
    }

    function cleanDrag(drag){
        for(var key in _dropDict){
            var drop = _dropDict[key];
            if(drop.currentDrag == drag){
                drop.currentDrag = null;
            }
        }
    }

    function checkVisibleCheckBtn(){
        for(var key in _dropDict){
            var drop = _dropDict[key];
            if(drop.currentDrag){
                pub.checkBtn.visible = true;
                return;
            }
        }
        pub.checkBtn.visible = false;
    }

    this.selectionHandler = function(e){
        this.super.selectionHandler(e);
        pub.currentTry = pub.maxTry;
        showFeedbackIcon();
    };

    this.getInput = function(){
        var inputObj = {};
        for(var key in _dragDict){
            var drag = _dragDict[key];
            var currentDrop = getCurrentDrop(drag);
            var currentDropId = currentDrop?currentDrop.id:null;
            inputObj[key] = {currentDropId:currentDropId,isCorrect:drag.isCorrect};
        }
        return inputObj;
    };

    this.setInput = function(data){
        pub.reset();
        var time = 1;
        for(var key in data){
            var drag = _dragDict[key];
            if(data[key].currentDropId){
                var drop = _dropDict[data[key].currentDropId];
                drop.currentDrag = drag;
                drag.isCorrect = data[key].isCorrect;
                var dropPoint = CheckManager.getLocalPoint(drop,drag);
                Tweener.addTween(drag,{x:dropPoint.x,y:dropPoint.y,time:time,overwrite:true});
            }
            else{
                Tweener.addTween(drag,{x:drag.startPoint.x,y:drag.startPoint.y,time:time,overwrite:true});
            }
        }
    };

    this.onReset = function (e){
        pub.clip.gotoAndStop(1);
        pub.reset();
        this.super.reset();
        pub.moveDragsBack();
    };

    this.reset = function(){
        resetDrags();
        resetDrops();
        pub.currentTry = 0;
    };

    function resetDrags(){
        for(var key in _dragDict){
            var drag = _dragDict[key];
            drag.isCorrect = null;
            drag.correct.visible = false;
            drag.wrong.visible = false;
        }
    }

    function resetDrops(){
        for(var key in _dropDict){
            var drop = _dropDict[key];
            drop.currentDrag = null;
        }
    }

    this.moveDragsBack = function() {
        for(var key in _dragDict){
            var drag = _dragDict[key];
            moveBack(drag);
        }
    };

    function getCurrentDrop(drag){
        for(var key in _dropDict){
            var drop = _dropDict[key];
            if(drop.currentDrag == drag){
                return drop;
            }
        }
        return null;
    }

    Object.defineProperty(this,"dragDict",{
        get: function(){
            return _dragDict;
        },
        set: function(value){
            _dragDict = value;
        }
    });

    Object.defineProperty(this,"dropDict",{
        get: function(){
            return _dropDict;
        },
        set: function(value){
            _dropDict = value;
        }
    });


});


//- - - - - - - - - - - - - - - - - - - - - - 129 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/widget/popup/porschepanamerast/PorschePanameraStClickPopupWidget.js
/**
 * Created by cduerbeck on 08.02.2017.
 */
var PorschePanameraStClickPopupWidget = SimpleClickPopupWidget.extend(function() {

    this.init = function(clip){
        this.super.init(clip);

        if(clip.name.match(/_noCursor/)){
            //clip.mouseEnabled = false;
            clip.cursor = "default";
            clip.mouseChildren = true;
        }else{
            clip.mouseEnabled = true;
            clip.cursor = 'pointer';
            clip.mouseChildren = false;
        }

    };

});

//- - - - - - - - - - - - - - - - - - - - - - 130 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/widget/popup/porscheaftersales/PorscheAftersalesPopupWidget.js
/**
 * Created by cduerbeck on 18.12.2018.
 */

var PorscheAftersalesPopupWidget = Class.extend(function(){
    var _root;
    var _clip;
    var _animationController;
    var _timeout;
    var _isBusy;

    this.init = function(clip){
        _clip = clip;
        _clip.addEventListener("removed", popupRemoved);// das Popup soll geschlossen werden, wenn die Timeline weiterläuft
        var currentPageData = Facade.getInstance().retrieveProxy("StructureProxy").getData().currentPageData;
        var contentName = (currentPageData)?ClassManager.getNameByPath(currentPageData.contentPath):"frameContent";
        _root = CheckManager.getRoot(_clip);
        configureListener();
        _animationController = new AnimationController();
        _animationController.init(_clip,{autoPart:false,contentName:contentName});
        _animationController.pause();
        _clip.gotoAndStop(0);
        _clip.visible = false;
        _clip.close = close;
        _clip.open = open;
        checkIfOpenOnInit();
    };

    function configureListener(){
        var closeBtn = _clip.closeBtn;
        if (closeBtn) {
            new SimpleClick(closeBtn).addEvent("click", close);
        }
        _clip.addEventListener("click", eventHandler);// sonst kann man durch das popup "durchklicken"
        _root.addEventListener(SimpleContentEvent.PAUSE,eventHandler);
        _root.addEventListener(SimpleContentEvent.RESUME,eventHandler);
        _clip.addEventListener(SimpleContentEvent.PAGE_COMPLETE,eventHandler);
        _clip.addEventListener(SimpleContentEvent.PAGE_CONTINUE, eventHandler);
        _clip.addEventListener(SimpleContentEvent.PLAY_SOUND, eventHandler);

    }

    function eventHandler(e){
        switch(e.type) {
            case SimpleContentEvent.PAUSE:
                if (_isBusy) {
                    _animationController.pause();
                    pauseSound();
                }
                break;
            case SimpleContentEvent.RESUME:
                if (_isBusy) {
                    if(_clip.name.match(/(_|\b)wait(_|\b)/)) waitPopupOnOpen();
                    var currentSoundName = getCurrentSoundName();
                    if (currentSoundName) _clip.dispatchEvent(new SimpleContentEvent(SimpleContentEvent.RESUME_SOUND, currentSoundName, true));
                    _animationController.resume();
                }
                break;
            case SimpleContentEvent.PAGE_COMPLETE:
                _clip.seen = true;
                if(_clip.name.match(/(_|\b)closeOnSeen(_|\b)/)) close();
                if(_clip.name.match(/(_|\b)continueOnSeen(_|\b)/)) checkContinue();
                break;
            case SimpleContentEvent.PAGE_CONTINUE:
                _animationController.play();
                break;
            case SimpleContentEvent.PLAY_SOUND:
                try{
                    e.stopPropagation();
                }
                catch(error){}

                var event = new createjs.Event(SimpleContentEvent.PLAY_SOUND);
                event.detail = e.detail;
                _root.dispatchEvent(event);
                break;
        }
    }

    function pauseSound(){
        var currentSoundName = getCurrentSoundName();
        if(currentSoundName)_clip.dispatchEvent(new SimpleContentEvent(SimpleContentEvent.PAUSE_SOUND,currentSoundName,true));
    }

    function open(){
        _animationController.pageClipService.resetState();
        _clip.gotoAndStop(0);
        clearTimeout(_timeout);
        closeOtherPopups();
        openNow();
    }

    function closeOtherPopups(){
        if(_clip.parent) {
            var arr = ObjectService.getObjectFromClipByRegExp(_clip.parent, /(_|\b)popup_/, null, "MovieClip");
            for (var key in arr) {
                var popup = arr[key];
                if (popup != _clip && popup.visible && !popup.name.match(/(_|\b)stay(_|\b)/)) popup.close();
            }
        }
    }

    function openNow(){
        if(_clip.name.match(/(_|\b)wait(_|\b)/)) waitPopupOnOpen();
        _clip.dispatchEvent("ACTIVATE");
        _clip.visible= true;
        play();
    }

    function play() {
        _isBusy = true;
        _animationController.runContent();
    }

    function close(){
        stopSound();
        clearTimeout(_timeout);
        if(_clip.name.match(/(_|\b)continueOnClose(_|\b)/)){
            _clip._close = true;
        }
        stop();
        onCompleteClose();
        _clip.dispatchEvent("DEACTIVATE");
        closeOtherPopups();
    }

    function stopSound(){
        var label = _clip.currentLabel;
        if(label && label.substr(0,1) == "S"){
            var soundName = label.substr(1);
            var event = new createjs.Event(SimpleContentEvent.STOP_SOUND);
            event.detail = soundName;
            _root.dispatchEvent(event);
        }
    }

    function onCompleteClose(){
        _clip.visible= false;
        if(_clip.name.match(/(_|\b)wait(_|\b)/)) waitPopupOnClose();
        if(_clip.name.match(/(_|\b)(continueOnSeen|continueOnClose)(_|\b)/) ) checkContinue();
        _clip.gotoAndStop(0);
    }

    function stop(){
        _isBusy = false;
        _animationController.pause();
        _clip.gotoAndStop(0);
        stopSounds();
    }

    function getCurrentSoundName() {
        var currentSoundName = _clip.currentLabel;
        if(_clip.currentLabel && _clip.currentLabel.substr(0,1) == "S"){
            return _clip.currentLabel.substr(1);
        }
        return null;
    }

    function stopSounds() {
        for (var key in _clip.labels) {
            var label = _clip.labels[key];
            if(label.label.substr(0,1) == "S"){
                var soundName =  label.label.substr(1);
                var event = new createjs.Event(SimpleContentEvent.STOP_SOUND);
                event.detail = soundName;
                _clip.dispatchEvent(event,true);
            }
        }
    }

    function checkContinue(){
        var numSeen=0;
        var numContinueSeen=0;
        var numClose=0;
        var numContinueClose=0;
        var arr = ObjectService.getObjectFromClipByRegExp(_root,/(_|\b)popup_/,null,"MovieClip");
        for (var key in arr) {
            var popup = arr[key];
            if(popup.name.match(/(_|\b)continueOnSeen(_|\b)/)) {
                numContinueSeen++;
                if(popup.seen) numSeen++;
            }
            if(popup.name.match(/(_|\b)continueOnClose(_|\b)/)) {
                numContinueClose++;

                if(popup._close){
                    numClose++;
                    //console.log(popup._close,numClose,numContinueClose,popup.name)
                }
            }
        }
        if((numContinueSeen && numSeen===numContinueSeen) || (numContinueClose && numClose===numContinueClose)){
           // _root.dispatchEvent(SimpleContentEvent.PAGE_CONTINUE);--> simple
           // //no dispatch SimpleContentEvent.PAGE_CONTINUE because the root should not continue! We are in the PorscheServiceberaterTimelineJumpWidget !

            if(popup.name.match(/_parent/)) {
                //_root.parent.dispatchEvent("NEXT_STEP"); --> PorscheServiceberaterTimelineJumpWidget goes to next step. Not used
                if(popup.parent){
                    popup.parent.play();
                }
            }
        }
    }


    function waitPopupOnClose(){
        _clip.parent.play();
        resumeParentSound();
    }

    function waitPopupOnOpen(){
        _clip.parent.stop();
        pauseParentSound();

    }

    function resumeParentSound(){
        var parent = _clip.parent;
        if(parent.currentLabel && parent.currentLabel.substr(0,1) == "S"){
            var parentSoundName = parent.currentLabel.substr(1);
            var event = new createjs.Event(SimpleContentEvent.RESUME_SOUND);
            event.detail = parentSoundName;
            parent.dispatchEvent(event,true);
        }
    }

    function pauseParentSound(){
        var parent = _clip.parent;
        if(parent.currentLabel && parent.currentLabel.substr(0,1) == "S"){
            var parentSoundName = parent.currentLabel.substr(1);
            var event = new createjs.Event(SimpleContentEvent.PAUSE_SOUND);
            event.detail = parentSoundName;
            parent.dispatchEvent(event,true);
        }
    }

    function checkIfOpenOnInit(){
        if(_clip.name.match(/(_|\b)open(_|\b)/)) open();
    }

    function popupRemoved() {
        //_clip.close();
        stopSound();
        clearTimeout(_timeout);
        if(_clip.name.match(/(_|\b)continueOnClose(_|\b)/)){
            _clip._close = false;
        }
        stop();
        onCompleteClose();
        _clip.dispatchEvent("DEACTIVATE");
    }

});



//- - - - - - - - - - - - - - - - - - - - - - 131 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/widget/scroller/simple/SimpleScrollerWidget.js
/**
 * Created by cduerbeck on 30.11.2016.
 */
var SimpleScrollerWidget = Class.extend(function(){

    var pub = this;
    var _clip;
    var _scrollerItem;
    var _scrollerContent;
    var _textField;
    var _simpleScroller

    this.init = function(clip){
        _clip = clip;

       ObjectService.getObjectFromClip(clip,getObj,"MovieClip","scrollerContent");
       ObjectService.getObjectFromClip(clip,getObj,"MovieClip","scrollerItem");
    };

    function getObj(interactiveObject){
        switch(interactiveObject.name){

            case "scrollerContent":
                _scrollerContent = interactiveObject;
                _scrollerContent.height = _scrollerContent.nominalBounds.height;
                break;
            case "scrollerItem":
                _scrollerItem = interactiveObject;// => _scrollBar
                break;
        }

        if(_scrollerContent && _scrollerItem){
            if(!_simpleScroller){
                setTimeout(function(){initScrollerByTimeout()},50);
            }
        }
    }

    //we need timeout because external xml-Texts are not read to TextField immediately. Otherwise MCs that wrap the Textfields are not adapted to new size!
    function initScrollerByTimeout(){
        /*_textField = _scrollerContent.findObjectsByName(/./,createjs.Text)[0];
        if(_textField){
            if(_textField.getBounds()){
                _scrollerContent.height = _textField.getBounds().height;
            }
        }*/
        var textFieldList = _scrollerContent.findObjectsByName(/./,createjs.Text);
        var maxHeight = 0;
        for(var i=0;i<textFieldList.length;i++){
            var tempHeight = textFieldList[i].y + textFieldList[i].getBounds().height;
            if(maxHeight < tempHeight){
                maxHeight = tempHeight;
            }
        }
        if(maxHeight > _scrollerContent.nominalBounds.height){
            _scrollerContent.height = maxHeight;
        }
        else{
            _scrollerContent.height = _scrollerContent.nominalBounds.height;
        }
        initScroller();
    }


    function initScroller(){
       // console.log("_scrollerContent " + _scrollerContent.height, _scrollerContent.nominalBounds.height)
            _simpleScroller = new SimpleScroller(_clip.stage,_scrollerContent,_scrollerContent.nominalBounds.width,_scrollerItem.bg.nominalBounds.height,_scrollerItem);
    }
});

//- - - - - - - - - - - - - - - - - - - - - - 132 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/widget/videoplayer/porschepanamerast/PorschePanameraStVideoPlayerWidget.js

var PorschePanameraStVideoPlayerWidget = Class.extend(function() {
    var pub = this;
    var _clip;
    var _path;
    var _videoDOM;
    var _videoBitmap;
    var _isPlayingState;

    var _pauseResumeBtn;
    var _subtitleBtn;
    var _subtitleCont;
    var _seekbar;
    var _timeTextField;
    var _xml;
    var _durationList;
    var _duration;
    var _targetTime;
    var _autoStartTimeout;
    var _root;

    this.init = function(clip) {
        _clip = clip;
        _root = CheckManager.getRoot(_clip);
        clip.gotoAndStop(0);
        initNow();
        //setTimeout(initNow,20);
    };


    function initNow(){
        _clip.findObjectsByName(/^path\d*/).forEach(getTextField);
        _clip.findObjectsByName(/pauseResumeBtn|subtitleCont|subtitleBtn|seekbar|timeTextField/).forEach(getAsset);
        initVideo();
        checkAutoplay();
        configureListener();
    }

    function getTextField(textField){
        textField.visible = false;
        _path = textField.text;
    }

    function getAsset(obj){
        switch(obj.name){
            case "path":
                _path = obj.text;
                break;
            case "pauseResumeBtn":
                _pauseResumeBtn = obj;
                configurePauseResumeBtn();
                break;
            case "subtitleCont":
                _subtitleCont = obj;
                configureSubtitleCont();
                break;
            case "subtitleBtn":
                _subtitleBtn = obj;
                configureSubtitleBtn();
                break;
            case "seekbar":
                _seekbar = obj;
                configureSeekbar();
                break;
            case "timeTextField":
                _timeTextField = obj;
                _timeTextField.text = "00:00 / 00:00";
                break;
        }
    }

    function initVideo(){
        _videoDOM = document.createElement('video');
        _videoDOM.src = _path;
        _videoDOM.addEventListener('loadedmetadata', function() {
            _videoDOM.loaded = true;
        }, false);
        _videoDOM.load();
        _videoBitmap = new createjs.Bitmap(_videoDOM);

        _clip.video.addChild(_videoBitmap);
    }

    function checkAutoplay(){
        if(_clip.name.indexOf("autoplay") != -1){
            _autoStartTimeout = setTimeout(resume,500);
        }
    }

    function configureListener(){
        _clip.addEventListener("removed", removeFromStage);
        if(_root.parent) {
            _root.parent.addEventListener("TIMELINE_JUMP_WIDGET_CLICKED", removeFromStage);
        }

		var popup = findParentPopup(_clip);
        if(popup) {
            popup.addEventListener("ACTIVATE", onPopupActivate);
            popup.addEventListener("DEACTIVATE",onClosePopup);
        }
        var root = CheckManager.getRoot(_clip);
        root.addEventListener(SimpleContentEvent.PAUSE,onSystemEvent);

        _videoDOM.addEventListener("loadedmetadata",onMetaData);
        _videoDOM.addEventListener("timeupdate",update);
        _videoDOM.addEventListener("play",onStateChange);
        _videoDOM.addEventListener("pause",onStateChange);
        _videoDOM.addEventListener("ended",onStateChange);
    }

	function onPopupActivate() {
        _videoDOM.src = _path;
        tryVisible(_pauseResumeBtn.pauseBtn, false);
        tryVisible(_pauseResumeBtn.resumeBtn, true);
        stop();
        updateSeekbar();
    }


    function findParentPopup(clip) {
        if(clip.name && clip.name.match(/(_|\b)popup_[^_]+/) || clip.name && clip.name.match("VideoMediator")) {
            return clip;
        }
        else {
            if(clip.parent) {
                return findParentPopup(clip.parent);
            } else {
                return null;
            }
        }
    }


    function onStateChange (e){
        switch (e.type) {

            case "ended":
                onComplete();
                break;
            case "play":
                _root.dispatchEvent(SimpleContentEvent.STOP_SOUND);
                tryVisible(_pauseResumeBtn.pauseBtn, true);
                tryVisible(_pauseResumeBtn.resumeBtn, false);
                break;
            case "pause":
                tryVisible(_pauseResumeBtn.pauseBtn, false);
                tryVisible(_pauseResumeBtn.resumeBtn, true);
                break;
        }
    }


    function onMetaData(e){
        _duration = _videoDOM.duration;
         if(_timeTextField) _timeTextField.text = "00:00 / "+getTimeAsString(_duration);
        _videoBitmap.width  = _clip.video.width;
        _videoBitmap.height = _clip.video.height;
    }

    function configureSubtitleCont(){
        _subtitleCont.visible = false;
        _subtitleCont.subtitle.visible = false;
        _subtitleCont.subtitle.startY = _subtitleCont.subtitle.y + _subtitleCont.subtitle.nominalBounds.height;

        loadSubtitleXML();
    }

    function loadSubtitleXML(){
        var xmlPath = _path.replace(/.flv|.mp4/,".xml").replace("/video","/xml");
        ClassManager.load(xmlPath,xmlPath);
        ClassManager.addComplete(xmlPath,onCompleteXML);
        ClassManager.addError(xmlPath,onCompleteXML);
    }

    function onErrorXML(e){
        _subtitleBtn.visible = false;
        _subtitleCont.visible = false;
    }

    function onCompleteXML(e){
        if(e.data){
            _xml = e.data.data;
            _durationList = [];
            if(_xml){
                var xmlList = _xml.getElementsByTagName('p');//_xml.children;
                var length = xmlList.length;
                for(var i=0;i<length;i++){
                    var startTime = convertStringToTime(xmlList[i].attributes["begin"].value.toString());
                    var endTime = startTime+convertStringToTime(xmlList[i].attributes["dur"].value.toString());
                    var obj = {startTime:startTime,endTime:endTime,text:xmlList[i].textContent};
                    _durationList.push(obj);
                }
            }
        }
    }

    function convertStringToTime(text){
        var miliseconds = parseFloat(text.substr(9));
        var seconds = parseFloat(text.substr(6,2))*1000;
        var minutes = parseFloat(text.substr(3,2))*60*1000;
        var hours = parseFloat(text.substr(0,2))*60*60*1000;
        var time = (miliseconds+seconds+minutes+hours)/1000;
        return time;
    }

    function configurePauseResumeBtn(){
        tryVisible(_pauseResumeBtn.pauseBtn, false);
        tryVisible(_pauseResumeBtn.resumeBtn, true);
        configureBtn(_pauseResumeBtn.pauseBtn,pause);
        configureBtn(_pauseResumeBtn.resumeBtn,resume);
    }

    function tryVisible(obj, value){
        try {obj.visible= value;} catch(e){}
    }

    function pause(e){
        clearTimeout(_autoStartTimeout);
        if(_videoDOM){
            _videoDOM.pause();
        }
    }

    function resume(e){
        clearTimeout(_autoStartTimeout);
        if(_videoDOM){
            _videoDOM.play();
        }
    }

    function configureSubtitleBtn(){
        _subtitleBtn.subtitleOnBtn.visible = true;
        _subtitleBtn.subtitleOffBtn.visible = false;
        configureBtn(_subtitleBtn.subtitleOnBtn,showSubtitle);
        configureBtn(_subtitleBtn.subtitleOffBtn,hideSubtitle);
    }

    function showSubtitle(e){
        _subtitleCont.visible = true;
        _subtitleBtn.subtitleOnBtn.visible = false;
        _subtitleBtn.subtitleOffBtn.visible = true;
    }

    function hideSubtitle(e){
        _subtitleCont.visible = false;
        _subtitleBtn.subtitleOnBtn.visible = true;
        _subtitleBtn.subtitleOffBtn.visible = false;
    }

    function configureBtn(clip,callBack){
        var click= new SimpleClick(clip);
        click.addEvent("click",callBack);
    }

    function configureSeekbar(){
        _seekbar.bar.startWidth = _seekbar.bar.nominalBounds.width;
        _seekbar.bar.width = 0;
        _seekbar.bar.scaleX = 0;
        _seekbar.addEventListener("click",onSeekbarClick);
    }

    function onSeekbarClick(e){
        if(_videoDOM){
            _videoDOM.pause();
            var ratio = e.localX/_seekbar.background.nominalBounds.width;
            _targetTime = _duration*ratio;
            _videoDOM.src = _path;
            _videoDOM.load();
            _videoDOM.addEventListener("canplay",onCanPlay);
        }

    }

    function onCanPlay(e){
        _videoDOM.removeEventListener("canplay",onCanPlay);
        if(_videoDOM.loaded){
            _videoDOM.currentTime = _targetTime;
        }
        _videoDOM.play();
        updateSeekbar();
    }

    function update(){
        updateTime();
        updateSeekbar();
        if(_subtitleCont) updateSubtitle();
    }

    function updateSeekbar(){
        var targetWidth = _videoDOM.currentTime/_duration * _seekbar.bar.startWidth;
        var ratio = _videoDOM.currentTime/_duration;
        _seekbar.bar.scaleX = ratio;
        if(targetWidth > _seekbar.bar.startWidth){
            targetWidth = _seekbar.bar.startWidth;
        }
        if(targetWidth > 0){
            _seekbar.bar.width = targetWidth;
        }
        else{
            _seekbar.bar.width = 0;
        }
    }

    function updateTime(){
        var time = getTimeAsString(_videoDOM.currentTime)+" / "+getTimeAsString(_duration);
        _timeTextField.text = time;

    }

    function updateSubtitle(){
        if(_subtitleCont.visible){
            if(_durationList){
                var time = _videoDOM.currentTime;
                for(var key in _durationList){
                    var obj = _durationList[key];
                    if(time >= obj.startTime && time <= obj.endTime){
                        setSubtitle(obj.text);
                        return;
                    }
                }
            }
            setSubtitle("");
        }
    }

    function setSubtitle(text){
        var textField = _subtitleCont.subtitle.subtitleTextField;
        if(text == ""){
            _subtitleCont.subtitle.visible = false;
        }
        else{
            if(!_subtitleCont.subtitle.visible){
                _subtitleCont.subtitle.visible = true;
            }
            if(text != textField.text){
                textField.text = text;
                textField.height = textField.textHeight+5;
                _subtitleCont.subtitle.subtitleBg.height = textField.textHeight+5;
                _subtitleCont.subtitle.y = _subtitleCont.subtitle.startY - _subtitleCont.subtitle.height;
            }
        }
    }

    function onClosePopup(e){
        stop();
        hideSubtitle();
    }

    function onSystemEvent(e){
        switch(e.type){
        case SimpleContentEvent.PAUSE:
            _videoDOM.pause();
            break;
        }
    }

    this.remove = function(){
        stop();
    };

    function removeFromStage(e){
        stop();
    }

    function onComplete(){
        _videoDOM.pause();//necessary for IE11 to switch pauseResumeBtn from pause to play
        update();
        var root = CheckManager.getRoot(_clip);

        if(_clip.parent == root){
            root.dispatchEvent(SimpleContentEvent.PAGE_CONTINUE);
        }
        else{
            _clip.parent.dispatchEvent(SimpleContentEvent.PAGE_CONTINUE);
        }
    }

    function playVideo(path){
        if(_videoDOM){
            _videoDOM.src = path;
            _videoDOM.play();
        }
    }

    function stop(){
        if(_videoDOM){
            _videoDOM.pause();
            if(_videoDOM.loaded && _videoDOM.currentTime){
                _videoDOM.currentTime = 0;
            }
            if(_timeTextField){
                _timeTextField.text = "00:00"+" / "+getTimeAsString(_duration);
            }
            if(_seekbar && _seekbar.bar) _seekbar.bar.width = 0;
        }
    }

    function getTimeAsString(time){
        var date = new Date(time*1000);
        var minutes = date.getMinutes().toString();
        var seconds = date.getSeconds().toString();
        var  minutesString = (minutes < 10)? "0"+minutes.toString(): minutes.toString();
        var  secondsString = (seconds < 10)? "0"+seconds.toString(): seconds.toString();
        var timeString = minutesString+":"+secondsString;
        return timeString;
    }
});

//- - - - - - - - - - - - - - - - - - - - - - 133 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/widget/slide/porschepanamerast/PorschePanameraStSlideWidget.js
/**
 * Created by fseng on 09.12.2016.
 */

var PorschePanameraStSlideWidget = SimpleSlideWidget.extend(function() {

    var _clip;

    this.init = function(clip){
        _clip = clip;
        _clip.stage.update();
        this.super.init(clip);
    };

});

//- - - - - - - - - - - - - - - - - - - - - - 134 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/widget/slide/porscheaftersales/PorscheAftersalesSlideShowWidget.js
/**
 * Created by cduerbeck on 22.10.18.
 */

var PorscheAftersalesSlideShowWidget = Class.extend(function() {

    var _clip;
    var _slideLabels;
    var _currentLabelIndex;
    var _loop;

    this.init = function(clip){
        _clip = clip;
        _slideLabels = getSlideLabels();
        _clip.addEventListener("RESET", onReset);
        _clip.stage.update();
        if(_clip.name.match("_loop")){
            _loop = true;
        }
        reset();
        configureListener();
    };

    function reset(){
        _currentLabelIndex = 0;
        _clip.slideShowContent.gotoAndStop(0);
        if(_loop){
            _clip.prevBtn.visible = true;
            _clip.nextBtn.visible = true;
        }else{
            _clip.prevBtn.visible = false;
            _clip.nextBtn.visible = true;
        }

    };

    function configureListener() {
        _clip.prevBtn.addEventListener('click', onClickPrev);
        _clip.nextBtn.addEventListener('click', onClickNext);
        _clip.addEventListener("ACTION_BUTTON_CLICKED", updateNextPrevBtn);
    }

    function updateNextPrevBtn() {
         _currentLabelIndex = findCurrentLabel();

        if(_loop){
            _clip.prevBtn.visible = true;
            _clip.nextBtn.visible = true;
        }else{
            if(_currentLabelIndex >= _slideLabels.length-1) {
                _clip.nextBtn.visible = false;
                _clip.prevBtn.visible = true;
            } else {
                if(_currentLabelIndex <= 0) {
                    _clip.prevBtn.visible = false;
                    _clip.nextBtn.visible = true;
                }else{
                    _clip.prevBtn.visible = true;
                    _clip.nextBtn.visible = true;
                }
            }
        }
    }

    function onClickNext() {

        _currentLabelIndex = findCurrentLabel();
        _currentLabelIndex++;

        // for loop we also need labels on frame 0 and last frame!
        if(_loop){
            _clip.prevBtn.visible = true;
            _clip.nextBtn.visible = true;
            if(_currentLabelIndex >= _slideLabels.length) {
                _currentLabelIndex = 1;
                _clip.slideShowContent.gotoAndStop(0);
            }
        }else{
            if(_currentLabelIndex >= _slideLabels.length-1) {
                _clip.nextBtn.visible = false;
            } else {
                _clip.nextBtn.visible = true;
            }
            _clip.prevBtn.visible = true;
        }

        CheckManager.tweenToFrame(_clip.slideShowContent,_slideLabels[_currentLabelIndex].position);
    }

    function onClickPrev() {

        _currentLabelIndex = findCurrentLabel();
        _currentLabelIndex--;

        // for loop we also need labels on frame 0 and last frame!
        if(_loop){
            _clip.prevBtn.visible = true;
            _clip.nextBtn.visible = true;
            if(_currentLabelIndex < 0) {
                _currentLabelIndex = _slideLabels.length-2;
                var totalFrames = _clip.slideShowContent.totalFrames - 1;
                _clip.slideShowContent.gotoAndStop(totalFrames);
            }

        }else{
            if(_currentLabelIndex <= 0) {
                _clip.prevBtn.visible = false;
            } else {
                _clip.prevBtn.visible = true;
            }
            _clip.nextBtn.visible = true;
        }

        CheckManager.tweenToFrame(_clip.slideShowContent,_slideLabels[_currentLabelIndex].position);
    }


    function findCurrentLabel() {
        _currentLabelIndex= 0;

        for(var i=0;i<_slideLabels.length;i++) {
            if(_slideLabels[i].label.indexOf(_clip.slideShowContent.currentLabel)> -1) {
                _currentLabelIndex = i;
                break;
            }
        }
        return _currentLabelIndex;

    }


    function getSlideLabels() {
        var labels = _clip.slideShowContent.labels;
        var slideLabels = [];
        var j = 0;
        for(var i=0;i<labels.length;i++) {
            if(labels[i].label.match("slide")) {
                slideLabels[j] = labels[i];
                j++;
            }
        }
        return slideLabels;
    }


    function onReset(e){
        console.log("!!! onReset in PorscheAftersalesSlideShowWidget");
        reset();
    };



});

//- - - - - - - - - - - - - - - - - - - - - - 135 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/widget/link/simple/SimpleLinkWidget.js

var SimpleLinkWidget = Class.extend(function(){
    var _root;
    var _click;
    var _link;
    var _type;

    this.init = function(clip){
        //onsole.log('SimpleLinkWidget ' + clip.name);
        var _clip = clip;
        _root = CheckManager.getRoot(_clip);
        _clip.gotoAndStop("0");
        _link = getLinkByClip(_clip);
        _type = getTypeByLink(_link);
        _click = new SimpleClick(_clip);
        if(_clip.name && _clip.name.match(/nopointer/)){
            _clip.cursor = 'normal';
        }
        _click.addEvent("click", linkTo);
    };

    function linkTo(e){
        switch(_type){
            case "http":
                window.open(_link);
                break;
            case "mailto":
                window.location.href = _link;
                break;
            case "assets":
                window.open(_link);
                break;
            case "reload":
                var event = new createjs.Event(SimpleContentEvent.EXERCISE_NOTIFICATION);
                event.detail = { name: _link.toUpperCase()+"_COMMAND"};
                break;
            case "relative":
                setPageComplete();
                var event = new createjs.Event(SimpleContentEvent.EXERCISE_NOTIFICATION);
                event.detail = { name: _link.toUpperCase()+"_PAGE_COMMAND"};
                _root.dispatchEvent(event);
                break;
            case "id":
                setPageComplete();
                var event = new createjs.Event(SimpleContentEvent.EXERCISE_NOTIFICATION);
                event.detail = { name: "GOTO_PAGE_COMMAND", body:{id:_link}};
                _root.dispatchEvent(event);
                break;
            case "view":
                var event = new createjs.Event(SimpleContentEvent.EXERCISE_NOTIFICATION);
                var viewName =_link.replace(/^view/i,'').toUpperCase()+"_VIEW";
                event.detail = {name:"SET_VIEW_COMMAND",body:viewName};
                _root.dispatchEvent(event);
                break;
        }
    }

    /*
     * sets page complete when jumping out, otherwise its state would stay "1"
     */
    function setPageComplete(){
        var event = new createjs.Event(SimpleContentEvent.EXERCISE_NOTIFICATION);
        event.detail = { name: "PAGE_COMPLETE_COMMAND"};
        _root.dispatchEvent(event);
    }

    function getLinkByClip(clip){
        var _link = clip.name.match(/_to\w+/);
        if(_link){
            _link = String(_link).replace(/^_to/,'');
        } else {
            var toText = clip.findObjectsByKey(/^to/)[0];
            if (toText){
                toText.visible = false;
                if(toText) _link = toText.text;
            }
        }
        return _link;
    }

    function getTypeByLink(_link){
        if(_link.match(/^http:/)) return 'http';
        if(_link.match(/^https:/)) return 'http';
        if(_link.match(/^mailto:/)) return 'mailto';
        if(_link.match(/^assets\//)) return 'assets';
        if(_link.match(/^\.\./)) return 'assets';
        if(_link.match(/Previous|Next/i)) return 'relative';
        if(_link.match(/Reload/i)) return 'reload';
        if(_link.match(/^View\w+/i)) return 'view';
        return 'id';
    }

});

//- - - - - - - - - - - - - - - - - - - - - - 136 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/widget/button/simple/v2/SimpleButtonWidget.js
/**
 * @class
 * @classdesc Add button features to MovieClip
 *
 * Usage by nameing conventions:
 *
 */
var SimpleButtonWidget = Class.extend(function () {

    var actions;
    var _clip;
    /**
     * initialize this Widget on clip. Usually  called by a factory.
     * @param clip
     */
    this.init = function (clip) {
        _clip = clip;
        createButton(clip);
        actions = createActions(clip);
    }

     function createActions (button) {
       var commands = button.name.match(/((_|\b)(toggle|play|stop|back|playNextStepLabel|stopNextStepLabel|playPrevStepLabel|stopPrevStepLabel)_[^_]+)|((_|\b)(gotoAndPlay|gotoAndBack|gotoAndStop|to)_[^_]+_[^_]+)/g);
       var actions = [];
        commands.forEach(
            function (command) {
                var command_arr = command.split('_');
                var action = command_arr[1];
                var targetName = command_arr[2];
                var param = command_arr[3];
                var target;
                if (targetName === 'root'){
                    target = CheckManager.getRoot(button);
                } else if (targetName === 'parent'){
                    target = button.parent;
                } else {
                    target = ObjectService.getObjectFromClipByRegExp(CheckManager.getRoot(button), new RegExp( 'action_' + targetName), null )[0];
                }
                if(target){
                    actions.push({target: target, action: action, param: param});
                }
            }
        )
        return actions;
    }

    function onClick () {
        if(_clip.name.indexOf("_stopSound")>-1){
            var root = CheckManager.getRoot(_clip);
            root.dispatchEvent(new createjs.Event(SimpleContentEvent.STOP_SOUND));
        }

        // check if method is defined and call it if so
        actions.forEach(function (action) {
                if (action['action'] in action['target']) {
                    action['target'][action['action']].call(action['target'], action['param']);
                } else{
                    console.log( 'Die Methode ' + action['action'] + ' ist noch nicht implementiert.')
                }
            }
        )
        _clip.dispatchEvent("ACTION_BUTTON_CLICKED", true);
    }

    // add button features to movieclip
    function createButton (clip) {
        if(!clip.hasEventListener("RESET")){
            var click = new SimpleClick(clip);
            click.addEvent("click",onClick);
            clip.addEventListener("RESET", onReset);
        }
    }

    function onReset(e){
        if(CheckManager.getFrameByLabel( e.target,"out")){
            e.target.gotoAndStop("out");
        }
    };

});

//- - - - - - - - - - - - - - - - - - - - - - 137 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/widget/button/porschepanamerast/PorschePanameraStContinueButtonWidget.js
/**
 * Created by fseng on 30.11.2016.
 */

var PorschePanameraStContinueButtonWidget = Class.extend(function () {

    var _clip;

    this.init = function (clip) {
        _clip = clip;
        configureListener();
    };

    function configureListener() {
        _clip.addEventListener("click", onClick);
    }

    function onClick() {
        var structureData = Facade.getInstance().retrieveProxy("StructureProxy").getData();
        for(var i=0; i<structureData.globalPageDataList.length;i++) {
            var pageData = structureData.globalPageDataList[i];
            if(pageData.state != '2') {
                Facade.getInstance().sendNotification("SETUP_CONTENT_COMMAND",pageData);
                Facade.getInstance().sendNotification("SET_VIEW_COMMAND","CONTENT_VIEW");
                return;
            }
        }
    }
});

//- - - - - - - - - - - - - - - - - - - - - - 138 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/widget/button/porscheaftersales/PorscheAftersalesTogglePlayButtonWidget.js
/**
 * Created by cduerbeck on 19.11.2018.
 */

var PorscheAftersalesTogglePlayButtonWidget = Class.extend(function () {

    var pub = this;
    var _target;
    var _clip;
    var _root;

    this.init = function (clip) {
        _clip = clip;
        _root = CheckManager.getRoot(_clip);
        _root.stage.update();
        clip.gotoAndStop(0);
        getTarget(clip);
        configureListener(clip);
    };

    function getTarget(clip) {
        var targetName = clip.name.split('_')[1];
        if (targetName === "parent"){
            _target = clip.parent;
        }else{
            targetName = targetName + "_toggled";
            _target = ObjectService.getObjectFromClipByRegExp(clip.parent.parent.parent, new RegExp(targetName), null )[0];
        }
    }


    function configureListener(clip) {
        _clip.addEventListener("click", onClick);
        _root.addEventListener("RESET", onReset);
        _root.addEventListener("ENDED", onEnded);
    }


    function onClick() {
        if(_clip.currentFrame === 0){
            _clip.gotoAndStop(1);
            if(_target){
                if(_target.currentFrame >= _target.totalFrames - 1){
                    _target.gotoAndPlay(1);

                }else{
                    _target.play();
                }
            }

        }else{
            _clip.gotoAndStop(0);
            if(_target){
                _target.stop();
            }
        }
    }

    function onReset(e) {
        _clip.gotoAndStop(0);
    }

    function onEnded(e) {
        _clip.gotoAndStop(0);
    }

});




//- - - - - - - - - - - - - - - - - - - - - - 139 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/widget/slide/porscheaftersales/PorscheAftersalesURISlideWidget.js
/**
 * Created by cduerbeck on 05.02.2019.
 */


var PorscheAftersalesURISlideWidget = Class.extend(function(){

    var _pub = this;
    var _clip;
    var _root;
    var _slider1;
    var _slider2;
    var _constraint1;
    var _constraint2;
    var _frameSlave1;
    var _frameSlave2;
    var _frameSlave3;

    this.init = function(clip){
        _clip = clip;
        _root = CheckManager.getRoot(_clip);
        setTimeout(initWidget, 10);
    };


    function initWidget(){
        _slider1 = _clip.slider1;
        _slider2 = _clip.slider2;
        _slider1.addEventListener('drag',onDrag1);
        _slider2.addEventListener('drag',onDrag2);

        _constraint1 = _clip.constraint1;
        _constraint2 = _clip.constraint2;

        initConstraint(_constraint1);
        initConstraint(_constraint2);
        behavior.draggable(_slider1);
        behavior.draggable(_slider2);
        _slider1.draggable.constraints = _constraint1;
        _slider2.draggable.constraints = _constraint2;

        _frameSlave1 = _clip.frameSlave_1;
        _frameSlave2 = _clip.frameSlave_2;
        _frameSlave3 = _clip.frameSlave_3;
        _frameSlave1.gotoAndStop(0);
        _frameSlave2.gotoAndStop(0);
        _frameSlave3.gotoAndStop(0);
    }

    function initConstraint(clip) {
        var bounds = getClipBounds(clip);
        if(clip.name == "constraint1" ) {
            _constraint1 = {
                x: bounds.x,
                y: bounds.y,
                width: bounds.width - 1, // minus 1 weil ein constraint von 1 pixel = 0 Freiheitsgrad bedeutet
                height: bounds.height - 1
            };
        }
        if(clip.name == "constraint2" ) {
            _constraint2 = {
                x: bounds.x,
                y: bounds.y,
                width: bounds.width - 1, // minus 1 weil ein constraint von 1 pixel = 0 Freiheitsgrad bedeutet
                height: bounds.height - 1
            };
        }
    }

    function getClipBounds(clip){
        var bounds = {
            x:parseInt(clip.x,10),
            y:parseInt(clip.y,10),
            width:parseInt(clip.nominalBounds.width*clip.scaleX,10),
            height:parseInt(clip.nominalBounds.height*clip.scaleY,10)
        } ;

        return bounds;
    }


    //Voltage
    function onDrag1(e){
        //console.log("onDrag1v "  +  _slider1.draggable.vRatio);
        var frame = Math.round(_frameSlave1.totalFrames*((_slider1.draggable.hRatio)*(_slider1.draggable.vRatio)));
        if(frame > _frameSlave1.totalFrames-1){
            frame = _frameSlave1.totalFrames-1;
        }
        _frameSlave1.gotoAndStop(frame);
        calculateSlave3();
    }


    //Resistance
    function onDrag2(e){
       // console.log("onDrag2h "  +  _slider2.draggable.hRatio);
        var frame = Math.round(_frameSlave2.totalFrames*(_slider2.draggable.hRatio*_slider2.draggable.vRatio));
        if(frame > _frameSlave2.totalFrames-1){
            frame = _frameSlave2.totalFrames-1;
        }
        _frameSlave2.gotoAndStop(frame);
        calculateSlave3();

    }

    //Currencv
    function calculateSlave3(){
        var currency;
        var factorS1 = (1-_slider1.draggable.vRatio)/10;// : 10 because  basic Resistance = 0.1 (Lamp) --> 1.0 reached
        if (_slider2.draggable.hRatio > 0.1 ){
            currency = factorS1 / _slider2.draggable.hRatio;
        }else{
            currency =  factorS1 / 0.1;
        }

        /*console.log(" 1-_slider1.draggable.vRatio "  +  factorS1);
        console.log("_slider2.draggable.hRatio "  +  _slider2.draggable.hRatio);
        console.log("currency "  +  currency);*/

        var frame = Math.round(_frameSlave3.totalFrames*(1-currency));

        if(frame > _frameSlave3.totalFrames-1){
            frame = _frameSlave3.totalFrames-1;
        }
        _frameSlave3.gotoAndStop(frame);
    }


});

//- - - - - - - - - - - - - - - - - - - - - - 140 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/widget/button/porscheserviceberater/PorscheServiceberaterScrollToTopButtonWidget.js
/**
 * Created by cduerbeck on 24.09.18.
 */


var PorscheServiceberaterScrollToTopButtonWidget = Class.extend(function () {

    var _clip;
    var _root;

    this.init = function (clip) {
        _clip = clip;
        _root = CheckManager.getRoot(_clip);
        configureListener();
    };

    function configureListener() {
        _clip.addEventListener("click", onClick);
    }

    function onClick() {
        _clip.parent.gotoAndStop(0);
        _root.parent.dispatchEvent("START");
        _root.parent.dispatchEvent({type:"STEPNUM",detail:0, bubbles:true});
        setTimeout(function(){_root.parent.dispatchEvent("FIRST_STEP")},250);

    }

});


//- - - - - - - - - - - - - - - - - - - - - - 141 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/widget/button/porschepanamerast/PorschePanameraStExitButtonWidget.js
/**
 * Created by fseng on 25.01.2017.
 */

var PorschePanameraStExitButtonWidget = Class.extend(function () {

    var _clip;

    this.init = function (clip) {
        _clip = clip;
        configureListener();
    };

    function configureListener() {
        _clip.cursor = 'pointer';
        _clip.addEventListener("click", onClick);
    }

    function onClick() {
        window.top.close();
    }
});

//- - - - - - - - - - - - - - - - - - - - - - 142 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/widget/button/porschepanamerast/PorschePanameraStToggleButtonWidget.js
/**
 * Created by cduerbeck on 26.04.17.
 */

var PorschePanameraStToggleButtonWidget = Class.extend(function () {

    var pub = this;
    var _target;
    var _clip;

    this.init = function (clip) {
        _clip = clip;
        clip.gotoAndStop("start");
        getTarget(clip);
        configureListener(clip);
    };

    function getTarget(clip) {
        var targetName = clip.name.split('_')[1];
        if (targetName === 'root'){
            _target = CheckManager.getRoot(clip);
        } else if (targetName === 'parent'){
            _target = clip.parent;
        } else{
            _target = ObjectService.getObjectFromClipByRegExp(CheckManager.getRoot(clip), new RegExp( 'action_' + targetName), null )[0];
        }
        _target.stop();
    }


    function configureListener(clip) {
        clip.addEventListener("click", onClick);
       // clip.addEventListener("unstaged", pub.remove);
       clip.addEventListener("RESET", onReset);
    }

    function onReset(e){
        _target.gotoAndStop(0);
        _clip.removeEventListener("tick", onTick);
        _clip.gotoAndStop("start");
    };



    function onClick() {
       // console.log("_target.paused?: " + _target.paused);
        if(_clip.currentLabel === "start"){
            _clip.addEventListener("tick", onTick);
            if(_target.currentFrame >= _target.totalFrames - 1) {
                _target.gotoAndPlay(0);
            }else{
                _target.play();
            }
            _clip.gotoAndStop("stop");
        }else{
            _clip.removeEventListener("tick", onTick);
            _target.stop();
            _clip.gotoAndStop("start");
        }
    }

    function onTick(e) {
        console.log("_target.currentFrame: " + _target.currentFrame);
        if(_target.currentFrame >= _target.totalFrames - 1) {
            console.log("----_target.totalFrames: " + _target.totalFrames);
            _clip.removeEventListener("tick", onTick);
            _target.gotoAndStop(_target.totalFrames - 1);
            _clip.gotoAndStop("start");
           // pub.remove();
        }
    }

     /*this.remove = function(){
         _clip.removeEventListener("tick", onTick);
     };*/

});


//- - - - - - - - - - - - - - - - - - - - - - 143 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/widget/slide/porscheserviceberater/PorscheServiceberaterTimelineJumpWidget.js
/**
 * Created by cduerbeck on 24.09.18.
 */

var PorscheServiceberaterTimelineJumpWidget = Class.extend(function (){

    var _clip;
    var _root;
    var _stepList;
    var _visitedSteps;
    var _lastStepFrame;
    var _status;
    var _rootParent;
    var _stepsCompleted = false;

    this.init = function(clip){
        _clip = clip;
        _root = CheckManager.getRoot(_clip);
        _rootParent = _root.parent;
        _root.stage.update();

        clip.gotoAndStop(0);
        configureListener();
        _stepList = getStepList();
        _visitedSteps = [];
        if(!_stepList.length || _stepList.length == 0) {
            _root.parent.dispatchEvent("NO_STEP");
        } else {
            _lastStepFrame = _stepList[_stepList.length -1].position;
            setTimeout(checkCompletion,100,_stepList[0].label);
           // checkCompletion(_stepList[0].label);
            _root.parent.dispatchEvent("START");
        }

        _root.parent.dispatchEvent({type:"STEPS_COUNT",detail:_stepList.length, bubbles:true});
        _root.parent.dispatchEvent({type:"STEPNUM",detail:0, bubbles:true});

    };

    function configureListener() {
        _root.parent.addEventListener("PREV_STEP", jumpToPrevStep);
        _root.parent.addEventListener("NEXT_STEP", jumpToNextStep);
        _root.parent.addEventListener("STEP_CLICKED", jumpToClickedStep);
    }


    function getStepList() {
        var allLabels = _clip.labels;
        var stepList = [];
        for(var i=0;i<allLabels.length;i++) {
            if(allLabels[i].label.match("step")) {
                stepList.push(allLabels[i]);
            }
        }
        return stepList;
    }

    function jumpToPrevStep() {

        for(var i=0;i <= _stepList.length -2; i++) {
            var firstStep = 0;
            var tempNext = i+1;
            var prevStep;

            if(_clip.currentFrame > _stepList[i].position && _clip.currentFrame <= _stepList[tempNext].position) {
                prevStep = _stepList[i].label;

                checkCompletion(prevStep);

                if(i <= firstStep) {
                    _status = "START";
                } else {
                    _status = "STEP";
                }
                _clip.gotoAndStop(_stepList[i].position);
                onStepUpdate(i)
                _root.parent.dispatchEvent({type:"STEPNUM",detail:i, bubbles:true});

                dispatchState(_status);
                return;
            }
        }
    }

    function jumpToNextStep() {
        var nextStep;
        for(var i=0;i <= _stepList.length -1; i++) {
            var lastStep = _stepList.length - 1;
            var tempNext = i+1;
            if(_clip.currentFrame >= _stepList[i].position && _clip.currentFrame < _stepList[tempNext].position) {
                nextStep = _stepList[tempNext].label;

                checkCompletion(nextStep);

                if(tempNext >= lastStep) {
                    _status = "END";
                } else {
                    _status = "STEP";
                }
                _clip.gotoAndStop(_stepList[tempNext].position);
                _root.parent.dispatchEvent({type:"STEPNUM",detail:tempNext, bubbles:true});

                dispatchState(_status);
                return;
            }
        }
    }

    function jumpToClickedStep(e) {
        var stepnum = "step" + (e.detail);
        _clip.gotoAndStop(stepnum);
        _root.parent.dispatchEvent({type:"STEPNUM",detail:e.detail-1, bubbles:true});

        checkCompletion(stepnum);

        if (_stepList[_stepList.length - 1].label=== stepnum){
            _status = "END";
        }else{
            if(_stepList[0].label=== stepnum){
                _status = "START";
            }else{
                _status = "STEP";
            }
        }
        dispatchState(_status);
    }

    function onStepUpdate(i){
        if(_stepList && _stepList[i]) {
            console.log(_stepList[i]);
        }
    }

    function checkCompletion(theStep){
        if(_visitedSteps.indexOf(theStep) < 0){
            _visitedSteps.push(theStep);
        }

        if(_visitedSteps.length ==  _stepList.length  && _stepsCompleted == false){
            _stepsCompleted = true;
            _root.dispatchEvent(SimpleContentEvent.PAGE_CONTINUE);
        }
    }


    function dispatchState(status) {

        if(_root.parent) {
            _root.parent.dispatchEvent("TIMELINE_JUMP_WIDGET_CLICKED");
            switch(status) {
                case "START":
                    _root.parent.dispatchEvent("START");
                    break;
                case "STEP":
                    _root.parent.dispatchEvent("STEP");
                    break;
                case "END":
                    _root.parent.dispatchEvent("END");
                   // _root.dispatchEvent(SimpleContentEvent.PAGE_CONTINUE);
                    break;
            }
        }
    }

    this.remove = function() {
        if(_rootParent){
            _rootParent.dispatchEvent("REMOVE_STEPBUTTONS");
        }

        _root.parent.removeEventListener("PREV_STEP", jumpToPrevStep);
        _root.parent.removeEventListener("NEXT_STEP", jumpToNextStep);
        _root.parent.removeEventListener("STEP_CLICKED", jumpToClickedStep);

    };

});


//- - - - - - - - - - - - - - - - - - - - - - 144 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/widget/button/porschepanamerast/PorschePanameraStMenuButtonWidget.js
/**
 * Created by fseng on 30.11.2016.
 */

var PorschePanameraStMenuButtonWidget = Class.extend(function () {

    var _clip;

    this.init = function (clip) {
        _clip = clip;
        configureListener();
    };

    function configureListener() {
        _clip.addEventListener("click", onClick);
    }

    function onClick() {
        Facade.getInstance().sendNotification("SET_VIEW_COMMAND",ViewData.INIT);
        Facade.getInstance().sendNotification("UNLOAD_CONTENT_COMMAND");
        Facade.getInstance().sendNotification("ACTIVATE_SITEMAP_BTN_COMMAND");
    }
});

//- - - - - - - - - - - - - - - - - - - - - - 145 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/widget/sound/porscheaftersales/PorscheAftersalesSoundPlayWidget.js
/**
 * Created by cduerbeck on 03.12.2018.
 */


var PorscheAftersalesSoundPlayWidget = Class.extend(function(){
    var _root;
    var _clip;
    var _animationController;
    var _isBusy;

    this.init = function(clip){
        _clip = clip;
        var currentPageData = Facade.getInstance().retrieveProxy("StructureProxy").getData().currentPageData;
        var contentName = (currentPageData)?ClassManager.getNameByPath(currentPageData.contentPath):"frameContent";
        _root = CheckManager.getRoot(_clip);
        configureListener();
        _animationController = new AnimationController();
        _animationController.init(_clip,{autoPart:false,contentName:contentName});
        _animationController.pause();
        _clip.gotoAndStop(0);
        playit();
    };

    function configureListener(){

        _root.addEventListener(SimpleContentEvent.PAUSE,eventHandler);
        _root.addEventListener(SimpleContentEvent.RESUME,eventHandler);
        _clip.addEventListener(SimpleContentEvent.PAGE_COMPLETE,eventHandler);
        _clip.addEventListener(SimpleContentEvent.PAGE_CONTINUE, eventHandler);
        _clip.addEventListener(SimpleContentEvent.PLAY_SOUND, eventHandler);
        _clip.addEventListener("RESET", onReset);
        if(_root.parent) {
            _root.parent.addEventListener("TIMELINE_JUMP_WIDGET_CLICKED", stepChanged);
        }

    }

    function eventHandler(e){
        switch(e.type) {
            case SimpleContentEvent.PAUSE:
                if (_isBusy) {
                    _animationController.pause();
                    pauseSound();
                }
                break;
            case SimpleContentEvent.RESUME:
                if (_isBusy) {
                    var currentSoundName = getCurrentSoundName();
                    if (currentSoundName) _clip.dispatchEvent(new SimpleContentEvent(SimpleContentEvent.RESUME_SOUND, currentSoundName, true));
                    _animationController.resume();
                }
                break;
            case SimpleContentEvent.PAGE_CONTINUE:
                _animationController.play();
                break;
            case SimpleContentEvent.PLAY_SOUND:
                try{
                    e.stopPropagation();
                }
                catch(error){}

                var event = new createjs.Event(SimpleContentEvent.PLAY_SOUND);
                event.detail = e.detail;
                _root.dispatchEvent(event);
                break;
        }
    }

    function onReset(e){
        playit();
    };

    function stepChanged(e){
        stopSound();
        _isBusy = false;
        _animationController.pause();
        _clip.gotoAndStop(0);
        stopSounds();

    }

    function pauseSound(){
        var currentSoundName = getCurrentSoundName();
        if(currentSoundName)_clip.dispatchEvent(new SimpleContentEvent(SimpleContentEvent.PAUSE_SOUND,currentSoundName,true));
    }

    function playit(){
        _animationController.pageClipService.resetState();
        _clip.gotoAndStop(0);
        _isBusy = true;
        _animationController.runContent();
    }

    function stopSound(){
        var label = _clip.currentLabel;
        if(label && label.substr(0,1) == "S"){
            var soundName = label.substr(1);
            var event = new createjs.Event(SimpleContentEvent.STOP_SOUND);
            event.detail = soundName;
            _root.dispatchEvent(event);
        }
    }

    function getCurrentSoundName() {
        var currentSoundName = _clip.currentLabel;
        if(_clip.currentLabel && _clip.currentLabel.substr(0,1) == "S"){
            return _clip.currentLabel.substr(1);
        }
        return null;
    }

    function stopSounds() {
        for (var key in _clip.labels) {
            var label = _clip.labels[key];
            if(label.label.substr(0,1) == "S"){
                var soundName =  label.label.substr(1);
                var event = new createjs.Event(SimpleContentEvent.STOP_SOUND);
                event.detail = soundName;
                _clip.dispatchEvent(event,true);
            }
        }
    }
});

//- - - - - - - - - - - - - - - - - - - - - - 146 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/mediator/page/simple/SimplePageMediator.js
/**
 * Created by tnguyen on 02.05.2016.
 */
var SimplePageMediator = Mediator.extend(function(){
    var pub = this;

    var _contentComp;
    var _pageData;
    var _pageController;
    var _structureProxy;
    var _userProxy;

    this.constructor = function(viewComponent){
        this.super.constructor(viewComponent);
        pub.init();
    };

    this.init = function(){
        //console.log('init SimplePageMediator');
        _structureProxy = Facade.getInstance().retrieveProxy("StructureProxy");
        _userProxy = Facade.getInstance().retrieveProxy("UserProxy");
        var configProxy = Facade.getInstance().retrieveProxy("ConfigProxy");
        _pageController = new SimplePageController();
        _pageController.exerciseDict = configProxy.getData().exerciseDict;
        _contentComp = Facade.getInstance().retrieveMediator("ContentMediator").getViewComponent();
    };

    this.listNotifications = function(){
        var list = this.super.listNotifications();
        list.push("DESTROY_CONTENT_COMMAND");
        list.push("START_CONTENT_COMMAND");
        list.push("RUN_CONTENT_COMMAND");
        list.push("PAUSE_CONTENT_COMMAND");
        list.push("RESUME_CONTENT_COMMAND");
        list.push("PLAY_CONTENT_COMMAND");
        list.push("NEXT_PART_COMMAND");
        list.push("PREVIOUS_PART_COMMAND");
        list.push("RESTART_PART_COMMAND");
        list.push("SET_PART_COMMAND");
        list.push("ACTIVATE_SOUNDCLIPSERVICE_COMMAND");
        list.push("SOUND_COMMAND");
        return list;
    };

    this.handleNotification = function(notification){
        //console.log(notification.getName());
        switch(notification.getName()){
            case "DESTROY_CONTENT_COMMAND":
                _pageController.remove();
                Facade.getInstance().removeMediator(pub.name);
                break;
            case "START_CONTENT_COMMAND":
                var component = pub.getViewComponent();
                _pageData = notification.getBody();
                pub.removeEventListener();
                pub.configureListener(component);
                _pageController.init(component,_pageData);
                if(_pageData && _pageData.textXML){
                    _pageController.initText(_pageData.textXML);
                }
                component.visible = true;
                _pageController.runContent();
                break;
            case "RUN_CONTENT_COMMAND":
                _pageController.runContent();
                break;
            case "PAUSE_CONTENT_COMMAND":
                _pageController.pause();
                break;
            case "RESUME_CONTENT_COMMAND":
                _pageController.resume();
                break;
            case "PLAY_CONTENT_COMMAND":
                _pageController.play();
                break;
            case "NEXT_PART_COMMAND":
                _pageController.nextPart();
                break;
            case "PREVIOUS_PART_COMMAND":
                _pageController.previousPart();
                break;
            case "RESTART_PART_COMMAND":
                _pageController.restartPart();
                break;
            case "SET_PART_COMMAND":
                pub.sendNotification("SOUND_COMMAND",null,"STOP_SOUND");
                _pageController.setPart(notification.getBody());
                break;
            case "ACTIVATE_SOUNDCLIPSERVICE_COMMAND":
                _pageController.activateSoundClipService();
                break;
            case "SOUND_COMMAND":
                if(notification.getType() == "VOLUME"){
                    _pageController.setVolume(notification.getBody())
;                }
                break;
        }
    };

    this.setViewComponent = function(viewComponent){
        this.super.setViewComponent(viewComponent);
        pub.removeEventListener();
        pub.configureListener(viewComponent);
    };

    this.configureListener = function(clip){
        clip.addEventListener(SimpleContentEvent.NEXT_PAGE,pub.controllerHandler);
        clip.addEventListener(SimpleContentEvent.PART_COMPLETE,pub.controllerHandler);
        clip.addEventListener(SimpleContentEvent.PAGE_COMPLETE,pub.controllerHandler);
        clip.addEventListener(SimpleContentEvent.PAGE_CONTINUE,pub.controllerHandler);

        clip.addEventListener(SimpleContentEvent.LOOP_SOUND,pub.controllerHandler);
        clip.addEventListener(SimpleContentEvent.PLAY_SOUND,pub.controllerHandler);
        clip.addEventListener(SimpleContentEvent.PLAY_EXTRA_SOUND,pub.controllerHandler);
        clip.addEventListener(SimpleContentEvent.STOP_SOUND,pub.controllerHandler);
        clip.addEventListener(SimpleContentEvent.PAUSE_SOUND,pub.controllerHandler);
        clip.addEventListener(SimpleContentEvent.RESUME_SOUND,pub.controllerHandler);
        clip.addEventListener(SimpleContentEvent.ADD_SOUND_LIST,pub.controllerHandler);

        clip.addEventListener(SimpleContentEvent.EXERCISE_CORRECT,pub.controllerHandler);
        clip.addEventListener(SimpleContentEvent.EXERCISE_WRONG,pub.controllerHandler);
        clip.addEventListener(SimpleContentEvent.EXERCISE_PARTLY_CORRECT,pub.controllerHandler);
        clip.addEventListener(SimpleContentEvent.EXERCISE_COMPLETE,pub.controllerHandler);
        clip.addEventListener(SimpleContentEvent.EXERCISE_RESULT,pub.controllerHandler);
        clip.addEventListener(SimpleContentEvent.EXERCISE_NOTIFICATION,pub.controllerHandler);
        clip.addEventListener(SimpleContentEvent.GET_PROXY,pub.controllerHandler);

        if(_pageController.textService && !_pageController.textService.hasEvent("FOUND_REPLACE")){
            _pageController.textService.addEvent("FOUND_REPLACE",textServiceHandler);
        }
    };

    function textServiceHandler(e){
        var template = e.data.foundedText.replace("<replace>","").replace("</replace>","");
        var id = template.replace(/\W+/,"");
        var replacement="";

        switch(id){
            case "userName":
                var userName = _userProxy.getData().userName;
                if(userName) replacement = template.replace(id,_userProxy.getData().userName);
                e.data.textField.text = e.data.text.replace(e.data.foundedText, replacement);
                break;
        }
    }

    this.getContentName = function(){
        return ClassManager.getNameByPath(_structureProxy.getData().currentPageData.contentPath);
    }

    this.controllerHandler = function(e){
        if( _structureProxy.getData().currentPageData == null ) return;
        switch(e.type){
            case SimpleContentEvent.NEXT_PAGE:
                pub.sendNotification("NEXT_PAGE_COMMAND");
                break;
            case SimpleContentEvent.PART_COMPLETE:
                pub.sendNotification("PART_COMPLETE_COMMAND");
                break;
            case SimpleContentEvent.PAGE_COMPLETE:
                pub.sendNotification("PAGE_COMPLETE_COMMAND");
                break;
            case SimpleContentEvent.PAGE_CONTINUE:
                pub.sendNotification("PLAY_CONTENT_COMMAND");
                break;
            case SimpleContentEvent.LOOP_SOUND:
            case SimpleContentEvent.PLAY_SOUND:
            case SimpleContentEvent.PLAY_EXTRA_SOUND:
                if(e.detail){
                    pub.sendNotification("SOUND_COMMAND",pub.getContentName()+"_"+e.detail.toString(),e.type);
                    pub.sendNotification("SUBTITLE_COMMAND",e.detail.toString());
                }
                break;
            case SimpleContentEvent.STOP_SOUND:
            case SimpleContentEvent.PAUSE_SOUND:
            case SimpleContentEvent.RESUME_SOUND:
                if(e.detail){
                    pub.sendNotification("SOUND_COMMAND",pub.getContentName()+"_"+e.detail,e.type);
                }
                else{
                    pub.sendNotification("SOUND_COMMAND",e.detail,e.type);
                }
                break;
            case SimpleContentEvent.ADD_SOUND_LIST:
                pub.sendNotification("SOUND_COMMAND", e.detail,e.type);
                break;
            case SimpleContentEvent.EXERCISE_CORRECT:
            case SimpleContentEvent.EXERCISE_WRONG:
            case SimpleContentEvent.EXERCISE_PARTLY_CORRECT:
                pub.sendNotification("EXERCISE_COMMAND",e.detail,e.type);
                break;
            case SimpleContentEvent.EXERCISE_COMPLETE:
                pub.sendNotification("EXERCISE_COMMAND",e.detail,e.type);
                pub.sendNotification("PLAY_CONTENT_COMMAND");
                break;
            case SimpleContentEvent.EXERCISE_RESULT:
                pub.sendNotification("SET_EXERCISE_RESULT_COMMAND",e.detail);
                break;
            case SimpleContentEvent.EXERCISE_NOTIFICATION:
                pub.sendNotification(e.detail.name,e.detail.body,e.detail.type);
                break;
            case SimpleContentEvent.GET_PROXY:
                var clip = e.currentTarget;
                 alert ('CustomEvent? (SimplePageMediator)');
                //clip.dispatchEvent(new CustomEvent(SimpleContentEvent.FOUND_PROXY,Facade.getInstance().retrieveProxy(e.data)));
                break;
        }
    };

    this.removeEventListener = function(){
        if(_pageController && _pageController.clip){
        _pageController.clip.removeEventListener(SimpleContentEvent.PART_COMPLETE,pub.controllerHandler);
        _pageController.clip.removeEventListener(SimpleContentEvent.PAGE_COMPLETE,pub.controllerHandler);
        _pageController.clip.removeEventListener(SimpleContentEvent.LOOP_SOUND,pub.controllerHandler);
        _pageController.clip.removeEventListener(SimpleContentEvent.PLAY_SOUND,pub.controllerHandler);
        _pageController.clip.removeEventListener(SimpleContentEvent.STOP_SOUND,pub.controllerHandler);
        _pageController.clip.removeEventListener(SimpleContentEvent.PAUSE_SOUND,pub.controllerHandler);
        _pageController.clip.removeEventListener(SimpleContentEvent.ADD_SOUND_LIST,pub.controllerHandler);
        _pageController.clip.removeEventListener(SimpleContentEvent.EXERCISE_CORRECT,pub.controllerHandler);
        _pageController.clip.removeEventListener(SimpleContentEvent.EXERCISE_WRONG,pub.controllerHandler);
        _pageController.clip.removeEventListener(SimpleContentEvent.EXERCISE_PARTLY_CORRECT,pub.controllerHandler);
        _pageController.clip.removeEventListener(SimpleContentEvent.EXERCISE_COMPLETE,pub.controllerHandler);
        _pageController.clip.removeEventListener(SimpleContentEvent.EXERCISE_NOTIFICATION,pub.controllerHandler);
        }
    };

    Object.defineProperty(this,"pageController",{
        get: function(){
            return _pageController;
        },
        set: function(value){
            _pageController = value;
        }
    });

    Object.defineProperty(this,"structureProxy",{
        get: function(){
            return _structureProxy;
        }
    });

    Object.defineProperty(this,"userProxy",{
        get: function(){
            return _userProxy;
        }
    });

    Object.defineProperty(this,"contentComp",{
        get: function(){
            return _contentComp;
        }
    });

    Object.defineProperty(this,"pageData",{
        get: function(){
            return _pageData;
        },
        set: function(value){
            _pageData = value;
        }
    });
});



if (window['parent'] && window['parent']['ReviewConnector']){
    // WBT is running in FKC-Debug-Frame
    GLOBAL_CONFIG.mediatorDict._ReviewMediator = "de/fkc/mediator/debug/ReviewMediator.js";
}



//- - - - - - - - - - - - - - - - - - - - - - 85 - - - - - - - - - - - - - - - - - - - - - -
//de/fkc/mediator/debug/ReviewMediator.js
/**
 * Created by Tilo
 */
var ReviewMediator = Mediator.extend(function(){

    var _review, _structureData, _contentProxy, _userData, _content, _checkInterval, _currentInfo, _content;
    var EMPTY = "", CHECK_INTERVAL = '40';
    var pub = this;

    var _infos= {}

    this.init = function(){
        _review = window['parent']['ReviewConnector'];
        _review.setListener(onReviewMessage);
        _structureData = Facade.getInstance().retrieveProxy("StructureProxy").getData();
        if(_review){
            _review.pages = _structureData;
        }
        _userData = Facade.getInstance().retrieveProxy("UserProxy").getData();
        _contentProxy = Facade.getInstance().retrieveProxy("ContentProxy");
        _content = Facade.getInstance().retrieveMediator("ContentMediator").getViewComponent();
        _content.addEventListener("STEPNUM", onContentData);
    };

    function onContentData(data) {
        switch (data.type) {
            case 'STEPNUM':
                updateInfo('stepNum', data.detail+1);
                break;
        }

    }

     this.listNotifications = function(){
        var list = this.super.listNotifications();
        list.push("STATE_CHANGED_COMMAND");
        list.push("CURRENT_PAGE_DATA_CHANGED_COMMAND");
        list.push("PAGE_COMPLETE_EVENT");
        list.push("SOUND_COMMAND");
        list.push("SETUP_CONTENT_COMMAND");
        list.push("START_CONTENT_COMMAND");
        list.push("START_CONTENT_COMMAND");
        list.push("USER_DATA_COMMAND");
        list.push("VIEW_CHANGED_COMMAND");
        return list;
    };

    this.handleNotification = function(notification){
        this.super.handleNotification(notification);
        switch(notification.getName()){
            case "STATE_CHANGED_COMMAND":
            case "PAGE_COMPLETE_EVENT":
            case "CURRENT_PAGE_DATA_CHANGED_COMMAND":
            case "USER_DATA_COMMAND":
                var data = _structureData.currentPageData;
                updateInfo('pageID', data.id);
                updateInfo('pageState', data.state);
                updateInfo('pageName', data.name);
                updateInfo('wbtCompleted', _userData.success||_userData.completed);
                updateInfo('wbtProgress', _userData.progressMeasure);
                break;
            case "SOUND_COMMAND":
                switch (notification.getType()){
                    case "PLAY_SOUND":notification.getBody()
                        updateInfo('audioID',notification.getBody());
                        break;
                    case "STOP_SOUND":
                        updateInfo('audioID',EMPTY);
                        break;
                }
                break;
            case "SETUP_CONTENT_COMMAND":
                _infos = {}
                _content = null;
                clearInterval(_checkInterval);
                updateInfo('audioID',EMPTY);
                updateInfo('viewName','main');
                break;
            case "START_CONTENT_COMMAND":
                updateInfo('viewName','main');
                _content = _contentProxy.currentContent;
                _checkInterval = setInterval(onInterval,CHECK_INTERVAL)
                break;
            case "VIEW_CHANGED_COMMAND":
                var name  = notification.getBody();
                if(name == 'INIT' || name == '') name = 'main';
                name = name.replace(/_VIEW$/,'').toLowerCase();
                updateInfo('viewName',name);
                break;
        }
    };

    function onReviewMessage (data) {
        console.log('onReviewMessage',data);
        if(data.command) return execCommand(data);
    }

    function execCommand (data) {
        switch (data.command) {
            case 'pause':
                pub.sendNotification("PAUSE_COMMAND");
                break;
            case 'goto':
                goto(data.to);
                break;
            default:
               //pub.sendNotification(data.command);
        }
    }
    function goto(to){
       var pageData  = _structureData.getDataById(to);
       if(pageData) {
       pub.sendNotification("SETUP_CONTENT_COMMAND",pageData);
           //pub.sendNotification("SET_VIEW_COMMAND",ViewData.INIT);
       }
    }

    function updateInfo(id, value){
        if (_infos[id] != value) {
            _infos[id] = value;
            _review.setValue(id,value);
        }
    }

    function onInterval(){
        if(_content){
           var frameInfo = (_content.currentFrame+1)+'/'+_content.totalFrames;
           var labelInfo = _content.currentLabel || EMPTY
           if(_currentInfo != frameInfo+labelInfo) {
               updateInfo('frameInfo',frameInfo);
               updateInfo('labelInfo',labelInfo)
           }
           _currentInfo = frameInfo+labelInfo;
        }
    }


});
